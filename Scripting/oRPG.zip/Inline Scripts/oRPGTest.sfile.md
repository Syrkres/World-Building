oRPG Unit tests for customjs oRPG

__
```
^oRPGTestGenerateRul ?([a-zA-Z]*)$
```
__
```js
// A comment
console.log("oRPG Test generateRul:", $1);
if ($1 === "") {
    $1 = "TESTRULESET";
}
const {oRPG} = customJS;
const result=oRPG.generateRul($1);
return result;
```
__
oRPGTestGenerateRul {rule: text} - Generates a string based on the rule passed in (default)
  - __Parameters:__
    - __rule__ (Optional) The rule you want to generate.
  - __Examples:__
    - `;;oRPGTestGenerateRul RUMORS::`
    - `;;oRPGTestGenerateRul SMALLVALUE::`
    - `;;oRPGTestGenerateRul::`



__
```
^oRPGTestGenerateFullName ?([a-zA-Z]*) ?(m*|f*|male*|female*)$
```
__
```js
// A comment
console.log("oRPG Test generateRul:", $1);
const {oRPG} = customJS;
console.log("Calling Helper:" + _helperFunction());
const result=oRPG.generateFullName($1, $2, "");
return result;
```
__
oRPGTestGenerateFullName {race: text} {gender: m|f|male|female} - Generates a name based on race and gender
  - __Parameters:__
    - __race__ (Optional) Name based on race
    - __gender__ (Optional) Name based on gender
  - __Examples:__
    - `;;oRPGTestGenerateFullName halfling::`
    - `;;oRPGTestGenerateFullName halfling female::`
    - `;;oRPGTestGenerateFullName::`



__
```
^oRPGTestGenerateCharacter ?([a-zA-Z]*) ?(m*|f*|male*|female*)$
```
__
```js
// A comment
console.log("oRPG Test generateCharacter:", $1);
const {oRPG} = customJS;
const result=oRPG.generateCharacter({});  
return result;
```
__
oRPGTestGenerateCharacter {race name: text} {gender: m|f|male|female} - Randomly selects a NPC from Folder(variable: npcFolderPath).
  - __Parameters:__
    - __race__ (Optional) The race you are searching for (human/halfling/half-elf/etc). 
    - __gender__ (Optional) The gender you are looking for (m|f|male|female). Race must be passed in to pass in gender.
  - __Examples:__
    - `;;getNPC halfling female::`
    - `;;getNPC halfling::`
    - `;;getNPC::`



