oRPG inline scripts using customjs oRPG

__
```
^genRul ([a-zA-Z]*)$
```
__
```js
// A comment
//console.log("generateRul:", $1);
const {oRPG} = customJS;
const result=oRPG.generateRul($1);
return result;
```
__
genRul {rule: text} - Generates a string based on the rule passed in (default)
  - __Parameters:__
    - __rule__ (Optional) The rule you want to generate.
  - __Examples:__
    - `;;oRPGTestGenerateRul RUMORS::`
    - `;;oRPGTestGenerateRul SMALLVALUE::`
    - `;;oRPGTestGenerateRul::`

__
```
^genRumors ?([0-9]*)$
```
__
```js
// List all the ruls
if (!$1  || isNaN($1)) {
    $1 = 1;
}
const {oRPG} = customJS;
let result="";
if ($1 > 1) {
    result += "- ";
}
for (let i = 0; i < $1; i++) {
    result += oRPG.generateRul("RUMORS");
    console.log("Result:" + result);
    if (($1 > 1) && (i+1 < $1)) {
        result += "\n- ";
    }
}
return result;
```
__
genRumors {count: number}- generate 1 or more rumors
  - __Parameters:__
    - __count__ (Optional) The number of rumors you want to generate.
  - __Examples:__
    - `;;genRumors::`
    - `;;genRumors 3::`


__
```
^genBookDetails ?([0-9]*)$
```
__
```js
if (!$1  || isNaN($1)) {
    $1 = 1;
}
const {oRPG} = customJS;
let result="";
for (let i = 0; i < $1; i++) {
    result += oRPG.generateWrittenBook();
    if (($1 > 1) && (i+1 < $1)) {
        result += "\n\n";
    }
}
return result;
```
__
genBookDetails {count: number}- generate 1 or more rumors
  - __Parameters:__
    - __count__ (Optional) The number of books you want to generate.
  - __Examples:__
    - `;;genBookDetails::`
    - `;;genBookDetails  3::`



__
```
^listRul$
```
__
```js
// List all the ruls
const {oRPG} = customJS;
const result=oRPG.listRules();
return result;
```
__
listRul - List all the current ruls
  - __Examples:__
    - `;;listRul::`


__
```
^fullName ?([a-zA-Z]*) ?(m*|f*|male*|female*)$
```
__
```js
// A comment
const {oRPG} = customJS;
const result=oRPG.generateFullName($1, $2, "");
return result;
```
__
fullName {race: text} {gender: m|f|male|female} - Generates a name based on race and gender
  - __Parameters:__
    - __race__ (Optional) Name based on race
    - __gender__ (Optional) Name based on gender
  - __Examples:__
    - `;;oRPGTestGenerateFullName halfling::`
    - `;;oRPGTestGenerateFullName halfling female::`
    - `;;oRPGTestGenerateFullName::`



__
```
^npc ?([a-zA-Z]*) ?(m*|f*|male*|female*)$
```
__
```js
// A comment
const {oRPG} = customJS;
const result=oRPG.generateCharacter({});  
return result;
```
__
npc {race name: text} {gender: m|f|male|female} - Randomly selects a NPC from Folder(variable: npcFolderPath).
  - __Parameters:__
    - __race__ (Optional) The race you are searching for (human/halfling/half-elf/etc). 
    - __gender__ (Optional) The gender you are looking for (m|f|male|female). Race must be passed in to pass in gender.
  - __Examples:__
    - `;;getNPC halfling female::`
    - `;;getNPC halfling::`
    - `;;getNPC::`



__
```
^genSpirit ?([a-zA-Z]*)$
```
__
```js
// A comment
const {oRPG} = customJS;
const result=oRPG.generateSpirit();  
return result;
```
__
genSpirit {race name: text} - Randomly generates a spirit.female). 
  - __Parameters:__
    - __race__ (Optional) The race you are searching for (human/halfling/half-elf/etc). 
  - __Examples:__
    - `;;genSpirit halfling::`
    - `;;genSpirit::`



