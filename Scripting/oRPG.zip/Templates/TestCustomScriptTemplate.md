<%*
const {RULGenerator} = customJS;
tR += RULGenerator.generateRul("BARRELSMALL");
tR += "\n" + TestCustomScripts.test();
%>