<%*
const {generator} = oRPGjs;
tR += generator.generateWrittenBook();
%>