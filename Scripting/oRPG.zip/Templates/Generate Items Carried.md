<%*
let qcType = await  tp.system.suggester(["Ranged", "Melee", "Skirmish"], ["RANGED", "MELEE", "SKIRMISH"])
npcType = qcType
_%>
<%*
const { oRPG} = customJS;
tR += oRPG.generateNPCCarrying(npcType);
%>