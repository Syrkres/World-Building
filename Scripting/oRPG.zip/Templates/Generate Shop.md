<%*
let qcShop = await  tp.system.suggester(["Grocer", "Trading Post", "Smith", "Alchemist", "Apothecary", "Armor Smith", "Blacksmith",  "Book Binder", "Carpenter", "Church", "Brothel", "Pawnbroker", "Sage", "Stable", "Tavern", "Tinkerer", "Weaponsmith"], ["GROCERSHOPNAME", "TRADINGPOSTSHOPNAME", "SMITHSHOPNAME", "ALCHEMISTSHOPNAME", "APOTHECARYSHOPNAME", "ARMORSMITHSHOPNAME", "BLACKSMITHSHOPNAME", "BOOKBINDERSHOPNAME", "CARPENTERSHOPNAME", "CLERICSHOPNAME", "BROTHELKEEPERSHOPNAME", "PAWNBROKERSHOPNAME", "SAGESHOPNAME", "STABLERSHOPNAME", "TAVERNKEEPERSHOPNAME", "TINKERSHOPNAME", "WEAPONSMITHSHOPNAME" ])
shopType = qcShop
_%>
<%*
const {Names, oRPG} = customJS;
let nameListString = Names.listNameArray()
const nameArray = nameListString.split(",");
let name = await  tp.system.suggester(nameArray, nameArray)
nameSrc = name
_%>
<%*
let qcGender = await  tp.system.suggester(["male", "female"], ["male", "female"])
gender = qcGender
_%>
<%*
generatedShop = oRPG.generateShopTbl(shopType, nameSrc, gender)
_%>
<% generatedShop %>