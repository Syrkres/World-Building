---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barber 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Barbershop 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Carlyle (Young Adult ) Female who is Well  
- Hartford (Teen ) Male who is Well  
services: 
- Specialty Service( Low   quality, Below Average  costs) 
- Surgery( Good   quality, Average  costs) 
exterior: An long two story building with shingled siding with a missing tall window. The roof is Canopy. A Yellow Birch shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Specialty Service |  Low   quality |  Below Average  costs | 
> | Surgery |  Good   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Carlyle  | Young Adult  |  Female who is Well   | 
>> | Hartford  | Teen  |  Male who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

