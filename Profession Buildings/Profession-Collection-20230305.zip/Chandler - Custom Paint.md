---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chandler 
merchantCategory: Chandler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Custom Paint 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Dayton (Child ) Female who is Healthy  
services: 
- Merchant( Horrible   quality, Below Average  costs) 
- Boat/Ship Merchant( Excellent   quality, High  costs) 
exterior: An old long two story building with faded paint and with shingled siding with a few windows. The roof is Canopy. A Beech shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Horrible   quality |  Below Average  costs | 
> | Boat/Ship Merchant |  Excellent   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Dayton  | Child  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

