---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bather 
merchantCategory: Specialty Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The old soak shop 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Camden (Young Adult ) Male who is Healthy  
services: 
- Specialty Service( Excellent   quality, Below Average  costs) 
- Wash( Good   quality, Below Average  costs) 
exterior: An one story building with faded paint and with planked siding with a few round windows. The roof is Ceiling. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Specialty Service |  Excellent   quality |  Below Average  costs | 
> | Wash |  Good   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Camden  | Young Adult  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

