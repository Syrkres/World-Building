---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Astrologist 
merchantCategory: Sage
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Stargazer 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Huxley (Teen ) Female who is All Right  
- Blankley (Teen ) Male who is Dying  
services: 
- Entertainer( Average   quality, Below Average  costs) 
- Performance( Low   quality, Average  costs) 
exterior: An new tall building with brick siding with a missing tall window. The roof is Canopy. A Hickory pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Entertainer |  Average   quality |  Below Average  costs | 
> | Performance |  Low   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Huxley  | Teen  |  Female who is All Right   | 
>> | Blankley  | Teen  |  Male who is Dying   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

