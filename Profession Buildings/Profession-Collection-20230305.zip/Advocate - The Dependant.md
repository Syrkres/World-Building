---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Advocate 
merchantCategory: Elected Official
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Dependant 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Norton (Adult ) Female who is Dying  
- Barney (Young Adult ) Male who is Sick  
services: 
- Professional Specialties( Good   quality, Average  costs) 
- Advocate( Good   quality, Average  costs) 
exterior: An old long tall building with new paint and with shingled siding with a missing short window. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Good   quality |  Average  costs | 
> | Advocate |  Good   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Norton  | Adult  |  Female who is Dying   | 
>> | Barney  | Young Adult  |  Male who is Sick   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

