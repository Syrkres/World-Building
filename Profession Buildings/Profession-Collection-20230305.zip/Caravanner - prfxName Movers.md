---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Caravanner 
merchantCategory: Animal Handler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: TANNERY,FARM,STABLE
title: prfxName Movers 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Wakefield (Young Adult ) Female who is Healthy  
- Tindall (Teen ) Male who is All Right  
services: 
- Animal Handler( Low   quality, Average  costs) 
- Transportation( Excellent   quality, Average  costs) 
- Animal ( Average   quality, Above Average  costs) 
exterior: An old narrow tall building with planked siding. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Low   quality |  Average  costs | 
> | Transportation |  Excellent   quality |  Average  costs | 
> | Animal  |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Wakefield  | Young Adult  |  Female who is Healthy   | 
>> | Tindall  | Teen  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

