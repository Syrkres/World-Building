---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dairy Seller 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: Ye Cattle Milk Shop 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Rutland (Young Adult ) Male who is Scraped up  
services: 
- Farmer( Low   quality, Above Average  costs) 
- Food( Low   quality, Average  costs) 
exterior: An narrow two story building with new paint and with stoned siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Low   quality |  Above Average  costs | 
> | Food |  Low   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Rutland  | Young Adult  |  Male who is Scraped up   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

