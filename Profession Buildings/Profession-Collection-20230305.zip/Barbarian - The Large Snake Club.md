---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian 
merchantCategory: Tracker
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,STABLE
title: The Large Snake Club 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Compton (Young Adult ) Female who is Fit  
- Harrington (Young Adult ) Female who is Healthy  
services: 
- Mercenary( Average   quality, Below Average  costs) 
- Tracking( Horrible   quality, Above Average  costs) 
exterior: An one story building with shingled siding. The roof is Ceiling. A Cherry shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Average   quality |  Below Average  costs | 
> | Tracking |  Horrible   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Compton  | Young Adult  |  Female who is Fit   | 
>> | Harrington  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

