---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Caravanner 
merchantCategory: Animal Handler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: TANNERY,FARM,STABLE
title: Rabbit Movers 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Digby (Adult ) Male who is Well  
- Astley (Teen ) Female who is Well  
services: 
- Animal Handler( Average   quality, Below Average  costs) 
- Transportation( Poor   quality, Low  costs) 
- Animal ( Average   quality, Above Average  costs) 
exterior: An building with faded paint and with brick siding with a few short shuttered windows. The roof is House. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Average   quality |  Below Average  costs | 
> | Transportation |  Poor   quality |  Low  costs | 
> | Animal  |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Digby  | Adult  |  Male who is Well   | 
>> | Astley  | Teen  |  Female who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

