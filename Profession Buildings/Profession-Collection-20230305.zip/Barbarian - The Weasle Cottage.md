---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian 
merchantCategory: Tracker
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,STABLE
title: The Weasle Cottage 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Carlyle (Teen ) Female who is Fine  
services: 
- Mercenary( Average   quality, Above Average  costs) 
- Tracking( Poor   quality, Average  costs) 
exterior: An long building with faded paint and with planked siding with a front round shuttered window that has a carved sign hanging to the side with the merchants name. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Average   quality |  Above Average  costs | 
> | Tracking |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Carlyle  | Teen  |  Female who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

