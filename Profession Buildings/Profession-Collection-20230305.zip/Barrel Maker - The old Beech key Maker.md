---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barrel Maker 
merchantCategory: Wood Workers
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The old Beech key Maker 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Underhill (Young Adult ) Male who is Healthy  
- Rylan (Teen ) Male who is Fit  
services: 
- Craftsman( Average   quality, Average  costs) 
- Barrel Crafting( Poor   quality, High  costs) 
exterior: An long two story building with planked siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Average   quality |  Average  costs | 
> | Barrel Crafting |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Underhill  | Young Adult  |  Male who is Healthy   | 
>> | Rylan  | Teen  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

