---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian 
merchantCategory: Tracker
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,STABLE
title: The Lizardman   Lodge 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Snape (Adult ) Male who is Healthy  
services: 
- Mercenary( Poor   quality, Above Average  costs) 
- Tracking( Average   quality, Average  costs) 
exterior: An new two story building with stoned siding with a front tall window that has a sign hanging above with the merchants name. The roof is Dome. A Beech pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Poor   quality |  Above Average  costs | 
> | Tracking |  Average   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Snape  | Adult  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

