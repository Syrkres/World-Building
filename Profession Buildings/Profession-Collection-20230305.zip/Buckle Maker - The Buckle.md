---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Buckle Maker 
merchantCategory: Garment Trade
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Buckle 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Crawford (Teen ) Male who is Ailing  
services: 
- Garment Trade( Excellent   quality, Average  costs) 
- Crafting( Excellent   quality, Low  costs) 
exterior: An new long one story building with new paint and with shingled siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Excellent   quality |  Average  costs | 
> | Crafting |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Crawford  | Teen  |  Male who is Ailing   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

