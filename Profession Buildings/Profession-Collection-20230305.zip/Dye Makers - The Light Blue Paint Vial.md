---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dye Makers 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: The Light Blue Paint Vial 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Sage( Poor   quality, Average  costs) 
- Arcane Research( Horrible   quality, High  costs) 
- Potion Brewing( Horrible   quality, Low  costs) 
exterior: An old building with stoned siding with a front tall shuttered window that has a painted sign hanging above with the merchants name. The roof is Canopy. A Red Oak pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Poor   quality |  Average  costs | 
> | Arcane Research |  Horrible   quality |  High  costs | 
> | Potion Brewing |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

