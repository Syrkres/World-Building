---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armor Dealer 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,SMITHY
title: The Bronze Chainmail              Peddler 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Leighton (Adult ) Male who is Deceased  
services: 
- Merchant( Excellent   quality, Below Average  costs) 
- Armor Crafting( Excellent   quality, Low  costs) 
exterior: An tall building with stoned siding with a few broken windows. The roof is Canopy. A Pine shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Excellent   quality |  Below Average  costs | 
> | Armor Crafting |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Leighton  | Adult  |  Male who is Deceased   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

