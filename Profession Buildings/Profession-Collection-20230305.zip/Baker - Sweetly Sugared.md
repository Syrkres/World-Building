---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Sweetly Sugared 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Pickering (Child ) Male who is Healthy  
- Soames (Teen ) Male who is Impaired  
services: 
- Cook( Good   quality, Average  costs) 
- Bread and Pastry Making( Low   quality, High  costs) 
exterior: An old narrow one story building with stoned siding with a missing window. The roof is Canopy. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Good   quality |  Average  costs | 
> | Bread and Pastry Making |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Pickering  | Child  |  Male who is Healthy   | 
>> | Soames  | Teen  |  Male who is Impaired   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

