---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cobbler 
merchantCategory: Garment Trade
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Shoe Maker 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Dryden (Young Adult ) Female who is Well  
- Kendall (Teen ) Female who is Healthy  
services: 
- Garment Trade( Horrible   quality, Above Average  costs) 
- Shoe Repair( Low   quality, Average  costs) 
exterior: An new narrow building with shingled siding. The roof is Roof. A Cherry pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Horrible   quality |  Above Average  costs | 
> | Shoe Repair |  Low   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Dryden  | Young Adult  |  Female who is Well   | 
>> | Kendall  | Teen  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

