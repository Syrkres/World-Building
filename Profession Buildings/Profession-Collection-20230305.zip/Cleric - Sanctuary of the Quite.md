---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric 
merchantCategory: Clergy
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHRINE,HOUSE
title: Sanctuary of the Quite 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Dayton (Teen ) Female who is All Right  
- Cumberbatch (Teen ) Female who is All Right  
services: 
- Clergy( Horrible   quality, Average  costs) 
- Religion( Poor   quality, Below Average  costs) 
- House of Worship( Average   quality, Average  costs) 
- Curse Removal( Good   quality, Average  costs) 
- Spell Research( Average   quality, High  costs) 
- Healing( Average   quality, Average  costs) 
- Potions( Poor   quality, Average  costs) 
exterior: An two story building with faded paint and with shingled siding. The roof is Ceiling. A Beech shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Horrible   quality |  Average  costs | 
> | Religion |  Poor   quality |  Below Average  costs | 
> | House of Worship |  Average   quality |  Average  costs | 
> | Curse Removal |  Good   quality |  Average  costs | 
> | Spell Research |  Average   quality |  High  costs | 
> | Healing |  Average   quality |  Average  costs | 
> | Potions |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Dayton  | Teen  |  Female who is All Right   | 
>> | Cumberbatch  | Teen  |  Female who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

