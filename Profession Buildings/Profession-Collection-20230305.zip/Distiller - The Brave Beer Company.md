---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Distiller 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Brave Beer Company 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Dryden (Teen ) Male who is All Right  
- Riley (Young Adult ) Male who is All Right  
services: 
- Ale Sales( Poor   quality, Low  costs) 
exterior: An new building with new paint and with shingled siding. The roof is House. A Beech pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Ale Sales |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Dryden  | Teen  |  Male who is All Right   | 
>> | Riley  | Young Adult  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

