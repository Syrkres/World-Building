---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chicken Butcher 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Ye Plucked Egret 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Allerton (Teen ) Female who is Fit as a fiddle  
- Compton (Mature Adult ) Male who is Under the weather  
services: 
- Cook( Horrible   quality, Average  costs) 
- Meat Processing( Horrible   quality, High  costs) 
exterior: An one story building with new paint and with shingled siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Horrible   quality |  Average  costs | 
> | Meat Processing |  Horrible   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Allerton  | Teen  |  Female who is Fit as a fiddle   | 
>> | Compton  | Mature Adult  |  Male who is Under the weather   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

