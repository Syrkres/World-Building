---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cabbage 
merchantCategory: Homesteader
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: The Farm 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Ainsworth (Teen ) Male who is Maimed  
- Benson (Mature Adult ) Female who is Healthy  
services: 
- Farmer( Average   quality, Above Average  costs) 
- Food( Excellent   quality, High  costs) 
exterior: An new two story building with faded paint and with shingled siding with a missing tall window. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Average   quality |  Above Average  costs | 
> | Food |  Excellent   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Ainsworth  | Teen  |  Male who is Maimed   | 
>> | Benson  | Mature Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

