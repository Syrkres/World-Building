---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Book Binder 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,ALCHEMIST
title: Earmarks 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Richmond (Young Adult ) Male who is Scraped up  
services: 
- Professional Specialties( Poor   quality, High  costs) 
- Book Binding( Poor   quality, Low  costs) 
exterior: An new long building with shingled siding with a few windows. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Poor   quality |  High  costs | 
> | Book Binding |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Richmond  | Young Adult  |  Male who is Scraped up   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

