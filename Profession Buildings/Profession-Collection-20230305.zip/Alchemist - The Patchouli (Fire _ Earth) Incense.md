---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Alchemist 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: The Patchouli (Fire / Earth) Incense 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Allerton (Teen ) Female who is Sick  
- Wallace (Teen ) Female who is At death's door  
services: 
- Sage( Average   quality, Below Average  costs) 
- Arcane Research( Poor   quality, High  costs) 
- Potion Brewing( Good   quality, Below Average  costs) 
exterior: An new building with brick siding with a few shuttered windows. The roof is House. A Beech shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Average   quality |  Below Average  costs | 
> | Arcane Research |  Poor   quality |  High  costs | 
> | Potion Brewing |  Good   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Allerton  | Teen  |  Female who is Sick   | 
>> | Wallace  | Teen  |  Female who is At death's door   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

