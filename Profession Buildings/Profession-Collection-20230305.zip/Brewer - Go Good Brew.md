---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brewer 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: Go Good Brew 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Yeardley (Young Adult ) Female who is Healthy  
services: 
- Sage( Excellent   quality, Low  costs) 
- Arcane Research( Poor   quality, Above Average  costs) 
- Potion Brewing( Excellent   quality, Above Average  costs) 
exterior: An new long tall building with faded paint and with brick siding. The roof is Roof. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Excellent   quality |  Low  costs | 
> | Arcane Research |  Poor   quality |  Above Average  costs | 
> | Potion Brewing |  Excellent   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Yeardley  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

