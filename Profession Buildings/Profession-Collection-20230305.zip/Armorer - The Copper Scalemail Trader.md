---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armorer 
merchantCategory: Forger
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,SMITHY
title: The Copper Scalemail Trader 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Blacksmith( Average   quality, High  costs) 
- Armor Crafting( Horrible   quality, High  costs) 
- Item Crafting( Poor   quality, Below Average  costs) 
exterior: An building with new paint and with stoned siding with a few round shuttered windows. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Blacksmith |  Average   quality |  High  costs | 
> | Armor Crafting |  Horrible   quality |  High  costs | 
> | Item Crafting |  Poor   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

