---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Draper 
merchantCategory: Garment Trade
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Garment Dealer 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Acton (Adult ) Female who is Fit  
- Rowley (Teen ) Female who is Healthy  
services: 
- Garment Trade( Low   quality, Average  costs) 
- Trader( Good   quality, Above Average  costs) 
exterior: An long tall building with new paint and with stoned siding. The roof is House. A Cherry pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Low   quality |  Average  costs | 
> | Trader |  Good   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Acton  | Adult  |  Female who is Fit   | 
>> | Rowley  | Teen  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

