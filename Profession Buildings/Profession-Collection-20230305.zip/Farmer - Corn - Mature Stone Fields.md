---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Corn 
merchantCategory: Homesteader
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: Mature Stone Fields 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Rodney (Young Adult ) Female who is Dead  
- Preston (Young Adult ) Female who is Inured  
services: 
- Farmer( Low   quality, Below Average  costs) 
- Food( Low   quality, High  costs) 
exterior: An new one story building with faded paint and with brick siding. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Low   quality |  Below Average  costs | 
> | Food |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Rodney  | Young Adult  |  Female who is Dead   | 
>> | Preston  | Young Adult  |  Female who is Inured   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

