---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bookseller 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: prfxName Book Parlor 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Harley (Teen ) Female who is Fit  
- Beckwith (Mature Adult ) Male who is Nauseos  
services: 
- Craftsman( Poor   quality, Average  costs) 
- Toy Making( Average   quality, Below Average  costs) 
- Clock Making( Excellent   quality, Average  costs) 
- Tinkerer( Excellent   quality, Low  costs) 
exterior: An tall building with brick siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Poor   quality |  Average  costs | 
> | Toy Making |  Average   quality |  Below Average  costs | 
> | Clock Making |  Excellent   quality |  Average  costs | 
> | Tinkerer |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Harley  | Teen  |  Female who is Fit   | 
>> | Beckwith  | Mature Adult  |  Male who is Nauseos   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

