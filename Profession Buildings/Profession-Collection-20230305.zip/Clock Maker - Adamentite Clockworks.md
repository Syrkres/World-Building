---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Clock Maker 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Adamentite Clockworks 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Merton (Teen ) Female who is At death's door  
services: 
- Craftsman( Average   quality, Above Average  costs) 
- Toy Making( Low   quality, Average  costs) 
- Clock Making( Excellent   quality, High  costs) 
- Tinkerer( Horrible   quality, Low  costs) 
exterior: An new tall building with faded paint and with shingled siding with a few broken windows. The roof is House. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Average   quality |  Above Average  costs | 
> | Toy Making |  Low   quality |  Average  costs | 
> | Clock Making |  Excellent   quality |  High  costs | 
> | Tinkerer |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Merton  | Teen  |  Female who is At death's door   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

