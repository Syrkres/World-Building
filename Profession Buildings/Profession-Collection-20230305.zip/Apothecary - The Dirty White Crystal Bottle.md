---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Apothecary 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,ALCHEMIST
title: The Dirty White Crystal Bottle 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Professional Specialties( Poor   quality, High  costs) 
- Healing( Average   quality, Average  costs) 
- Potion Brewing( Low   quality, Average  costs) 
- Remedy Crafting( Horrible   quality, Above Average  costs) 
exterior: An building with faded paint and with stoned siding. The roof is Dome. A Elm shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Poor   quality |  High  costs | 
> | Healing |  Average   quality |  Average  costs | 
> | Potion Brewing |  Low   quality |  Average  costs | 
> | Remedy Crafting |  Horrible   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

