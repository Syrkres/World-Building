---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baron 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Alby's Structure 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Wharton (Mature Adult ) Female who is Healthy  
services: 
- Diplomacy( Low   quality, High  costs) 
exterior: An long two story building with stoned siding with a missing window. The roof is Canopy. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Diplomacy |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Wharton  | Mature Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

