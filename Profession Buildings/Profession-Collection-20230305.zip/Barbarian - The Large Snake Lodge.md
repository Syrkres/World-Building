---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian 
merchantCategory: Tracker
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,STABLE
title: The Large Snake Lodge 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Walpole (Teen ) Female who is Inured  
- Whitby (Young Adult ) Female who is Healthy  
services: 
- Mercenary( Poor   quality, Below Average  costs) 
- Tracking( Good   quality, Average  costs) 
exterior: An old narrow tall building with brick siding with a front round boarded window that has a sign hanging above with the merchants name. The roof is House. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Poor   quality |  Below Average  costs | 
> | Tracking |  Good   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Walpole  | Teen  |  Female who is Inured   | 
>> | Whitby  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

