---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Count 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Graham's Court 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Snape (Child ) Female who is Fit  
- Atherton (Adult ) Female who is Dying  
services: 
- Offical( Good   quality, Average  costs) 
- Diplomacy( Horrible   quality, Average  costs) 
exterior: An narrow building with new paint and with brick siding with a few tall boarded windows. The roof is House. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Offical |  Good   quality |  Average  costs | 
> | Diplomacy |  Horrible   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Snape  | Child  |  Female who is Fit   | 
>> | Atherton  | Adult  |  Female who is Dying   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

