---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer 
merchantCategory: Animal Handler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: TANNERY,FARM,STABLE
title: Paws Buddy 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Peyton (Teen ) Female who is All Right  
- Westbrook (Young Adult ) Male who is Fine  
services: 
- Animal Handler( Horrible   quality, High  costs) 
- Pet Training( Good   quality, Above Average  costs) 
- Animal Training( Average   quality, Average  costs) 
exterior: An old building with new paint and with planked siding with a missing short window. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Horrible   quality |  High  costs | 
> | Pet Training |  Good   quality |  Above Average  costs | 
> | Animal Training |  Average   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Peyton  | Teen  |  Female who is All Right   | 
>> | Westbrook  | Young Adult  |  Male who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

