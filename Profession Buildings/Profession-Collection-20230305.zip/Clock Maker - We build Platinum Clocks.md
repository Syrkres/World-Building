---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Clock Maker 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We build Platinum Clocks 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Clifford (Adult ) Female who is Healthy  
services: 
- Craftsman( Excellent   quality, High  costs) 
- Toy Making( Average   quality, Low  costs) 
- Clock Making( Poor   quality, Low  costs) 
- Tinkerer( Average   quality, Low  costs) 
exterior: An new tall building with stoned siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Excellent   quality |  High  costs | 
> | Toy Making |  Average   quality |  Low  costs | 
> | Clock Making |  Poor   quality |  Low  costs | 
> | Tinkerer |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Clifford  | Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

