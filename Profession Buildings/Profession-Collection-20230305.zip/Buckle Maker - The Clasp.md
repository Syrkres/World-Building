---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Buckle Maker 
merchantCategory: Garment Trade
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Clasp 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Kendall (Teen ) Female who is Healthy  
services: 
- Garment Trade( Good   quality, High  costs) 
- Crafting( Average   quality, Low  costs) 
exterior: An new narrow building with shingled siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Good   quality |  High  costs | 
> | Crafting |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Kendall  | Teen  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

