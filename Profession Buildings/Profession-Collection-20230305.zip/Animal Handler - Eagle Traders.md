---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Handler 
merchantCategory: Animal Handler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Eagle Traders 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Atherton (Child ) Male who is Indisposed  
- Clapham (Teen ) Male who is All Right  
services: 
- Animal Handler( Good   quality, Below Average  costs) 
- Stabler( Excellent   quality, Below Average  costs) 
exterior: An new long building with shingled siding. The roof is Ceiling. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Good   quality |  Below Average  costs | 
> | Stabler |  Excellent   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Atherton  | Child  |  Male who is Indisposed   | 
>> | Clapham  | Teen  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

