---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,EXOTIC ARTISAN
title: The Worn new The new Adamentite Sword   
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Astley (Child ) Female who is All Right  
- Snowdon (Young Adult ) Male who is All Right  
services: 
- Merchant( Average   quality, High  costs) 
- Item Research( Low   quality, Average  costs) 
exterior: An new building with faded paint and with stoned siding with a missing short window. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Average   quality |  High  costs | 
> | Item Research |  Low   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Astley  | Child  |  Female who is All Right   | 
>> | Snowdon  | Young Adult  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

