---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barber 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Insane Cutz 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Prescott (Child ) Male who is Dead  
services: 
- Specialty Service( Low   quality, Below Average  costs) 
- Surgery( Low   quality, Low  costs) 
exterior: An one story building with stoned siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Specialty Service |  Low   quality |  Below Average  costs | 
> | Surgery |  Low   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Prescott  | Child  |  Male who is Dead   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

