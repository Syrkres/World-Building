---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric 
merchantCategory: Clergy
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHRINE,HOUSE
title: Holy Place of the Deferential 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Clergy( Excellent   quality, Below Average  costs) 
- Religion( Low   quality, High  costs) 
- House of Worship( Poor   quality, Above Average  costs) 
- Curse Removal( Excellent   quality, Above Average  costs) 
- Spell Research( Excellent   quality, High  costs) 
- Healing( Poor   quality, High  costs) 
- Potions( Good   quality, Low  costs) 
exterior: An two story building with planked siding. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Excellent   quality |  Below Average  costs | 
> | Religion |  Low   quality |  High  costs | 
> | House of Worship |  Poor   quality |  Above Average  costs | 
> | Curse Removal |  Excellent   quality |  Above Average  costs | 
> | Spell Research |  Excellent   quality |  High  costs | 
> | Healing |  Poor   quality |  High  costs | 
> | Potions |  Good   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

