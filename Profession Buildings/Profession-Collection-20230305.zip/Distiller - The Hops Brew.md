---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Distiller 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Hops Brew 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Langley (Young Adult ) Male who is Well  
- Coombs (Teen ) Female who is Fine  
services: 
- Ale Sales( Poor   quality, Average  costs) 
exterior: An building with new paint and with stoned siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Ale Sales |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Langley  | Young Adult  |  Male who is Well   | 
>> | Coombs  | Teen  |  Female who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

