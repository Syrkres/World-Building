---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Blacksmith 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,SMITHY
title: Bristol's Smith 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Colton (Child ) Female who is Healthy  
services: 
- Metal Craftsman( Excellent   quality, Above Average  costs) 
- Blacksmithing( Low   quality, Average  costs) 
exterior: An building with faded paint and with shingled siding with a missing short window. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Metal Craftsman |  Excellent   quality |  Above Average  costs | 
> | Blacksmithing |  Low   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Colton  | Child  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

