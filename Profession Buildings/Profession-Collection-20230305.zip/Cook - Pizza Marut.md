---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cook 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Pizza Marut 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Mitchell (Adult ) Male who is Sick  
- Westbrook (Young Adult ) Female who is All Right  
services: 
- Cook( Poor   quality, High  costs) 
exterior: An long one story building with faded paint and with stoned siding. The roof is House. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Mitchell  | Adult  |  Male who is Sick   | 
>> | Westbrook  | Young Adult  |  Female who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

