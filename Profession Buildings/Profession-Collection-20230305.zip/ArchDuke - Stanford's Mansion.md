---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: ArchDuke 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Stanford's Mansion 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Cromwell (Young Adult ) Female who is All Right  
- Reed (Adult ) Male who is Fit  
services: 
- Noble( Average   quality, Low  costs) 
- Diplomacy( Low   quality, Above Average  costs) 
- Advise( Average   quality, High  costs) 
exterior: An old narrow building with brick siding with a missing window. The roof is Canopy. A Yellow Birch shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Noble |  Average   quality |  Low  costs | 
> | Diplomacy |  Low   quality |  Above Average  costs | 
> | Advise |  Average   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Cromwell  | Young Adult  |  Female who is All Right   | 
>> | Reed  | Adult  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

