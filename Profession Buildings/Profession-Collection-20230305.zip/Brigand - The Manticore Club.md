---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand 
merchantCategory: Criminal
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: JAIL,HOUSE
title: The Manticore Club 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Fawcett (Teen ) Male who is Healthy  
- Hallewell (Young Adult ) Female who is Sick  
services: 
- Mercenary( Poor   quality, Above Average  costs) 
- Enforcement( Horrible   quality, Average  costs) 
- Intimidation( Excellent   quality, Below Average  costs) 
exterior: An old building with new paint and with stoned siding with a few round windows. The roof is Dome. A Red Oak shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Poor   quality |  Above Average  costs | 
> | Enforcement |  Horrible   quality |  Average  costs | 
> | Intimidation |  Excellent   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Fawcett  | Teen  |  Male who is Healthy   | 
>> | Hallewell  | Young Adult  |  Female who is Sick   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

