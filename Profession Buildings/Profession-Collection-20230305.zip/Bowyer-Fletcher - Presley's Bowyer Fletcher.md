---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bowyer-Fletcher 
merchantCategory: Wood Workers
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Presley's Bowyer Fletcher 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Hampton (Adult ) Female who is Fit as a fiddle  
- Reid (Young Adult ) Female who is Sick  
services: 
- Artisan( Average   quality, Above Average  costs) 
- Wood Carver( Low   quality, High  costs) 
exterior: An old long tall building with brick siding. The roof is Dome. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Artisan |  Average   quality |  Above Average  costs | 
> | Wood Carver |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hampton  | Adult  |  Female who is Fit as a fiddle   | 
>> | Reid  | Young Adult  |  Female who is Sick   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

