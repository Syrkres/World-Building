---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cartographer 
merchantCategory: Tracker
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We map it 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Bing (Teen ) Female who is Healthy  
services: 
- Professional Specialties( Horrible   quality, Below Average  costs) 
- Mapping( Horrible   quality, Low  costs) 
- Map Translation( Good   quality, Above Average  costs) 
exterior: An narrow one story building with faded paint and with shingled siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Horrible   quality |  Below Average  costs | 
> | Mapping |  Horrible   quality |  Low  costs | 
> | Map Translation |  Good   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Bing  | Teen  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

