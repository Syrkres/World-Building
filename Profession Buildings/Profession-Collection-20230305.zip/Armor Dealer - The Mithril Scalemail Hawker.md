---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armor Dealer 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,SMITHY
title: The Mithril Scalemail Hawker 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Carlisle (Teen ) Male who is Fine  
- Landon (Mature Adult ) Male who is Fit  
services: 
- Merchant( Low   quality, High  costs) 
- Armor Crafting( Good   quality, High  costs) 
exterior: An long tall building with faded paint and with stoned siding with a front shuttered window that has a painted sign hanging above with the merchants name. The roof is Roof. A Ceder shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Low   quality |  High  costs | 
> | Armor Crafting |  Good   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Carlisle  | Teen  |  Male who is Fine   | 
>> | Landon  | Mature Adult  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

