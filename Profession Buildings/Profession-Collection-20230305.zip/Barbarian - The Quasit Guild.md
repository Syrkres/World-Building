---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian 
merchantCategory: Tracker
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,STABLE
title: The Quasit Guild 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Mercenary( Good   quality, Average  costs) 
- Tracking( Average   quality, Average  costs) 
exterior: An long building with new paint and with stoned siding with a few tall boarded windows. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Good   quality |  Average  costs | 
> | Tracking |  Average   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

