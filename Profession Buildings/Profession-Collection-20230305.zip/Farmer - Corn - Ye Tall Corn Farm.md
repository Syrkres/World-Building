---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Corn 
merchantCategory: Homesteader
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: Ye Tall Corn Farm 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Emsworth (Young Adult ) Female who is Healthy  
- Chatham (Adult ) Male who is Maimed  
services: 
- Farmer( Horrible   quality, Above Average  costs) 
- Food( Poor   quality, Low  costs) 
exterior: An old building with planked siding with a front shuttered window that has a carved sign hanging to the side with the merchants name. The roof is Roof. A Pine shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Horrible   quality |  Above Average  costs | 
> | Food |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Emsworth  | Young Adult  |  Female who is Healthy   | 
>> | Chatham  | Adult  |  Male who is Maimed   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

