---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brothel Keeper 
merchantCategory: Hosteler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Hook 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Stanton (Teen ) Male who is Inured  
- Southey (Adult ) Male who is Healthy  
services: 
- Room (Pleasure)( Good   quality, Low  costs) 
- Common Room (Sleeping)( Good   quality, Below Average  costs) 
- Room (Meeting)( Average   quality, Low  costs) 
exterior: An tall building with faded paint and with shingled siding. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Room  | Pleasure | ( Good   quality | 
> | Common Room  | Sleeping | ( Good   quality | 
> | Room  | Meeting | ( Average   quality | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Stanton  | Teen  |  Male who is Inured   | 
>> | Southey  | Adult  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

