---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barrel Maker 
merchantCategory: Wood Workers
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Beech crate Maker 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Craftsman( Excellent   quality, High  costs) 
- Barrel Crafting( Low   quality, High  costs) 
exterior: An building with shingled siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is Ceiling. A Red Oak pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Excellent   quality |  High  costs | 
> | Barrel Crafting |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

