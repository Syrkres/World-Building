---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cook 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Wight Castle 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Benson (Teen ) Female who is Healthy  
- Hayes (Teen ) Male who is All Right  
services: 
- Cook( Horrible   quality, Low  costs) 
exterior: An new building with new paint and with shingled siding. The roof is Roof. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Benson  | Teen  |  Female who is Healthy   | 
>> | Hayes  | Teen  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

