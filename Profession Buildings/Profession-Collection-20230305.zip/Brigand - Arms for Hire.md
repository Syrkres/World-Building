---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand 
merchantCategory: Criminal
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: JAIL,HOUSE
title: Arms for Hire 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Lancaster (Teen ) Female who is Fit  
- Walcott (Adult ) Female who is All Right  
services: 
- Mercenary( Low   quality, Average  costs) 
- Enforcement( Average   quality, Below Average  costs) 
- Intimidation( Horrible   quality, Low  costs) 
exterior: An new tall building with stoned siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Low   quality |  Average  costs | 
> | Enforcement |  Average   quality |  Below Average  costs | 
> | Intimidation |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Lancaster  | Teen  |  Female who is Fit   | 
>> | Walcott  | Adult  |  Female who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

