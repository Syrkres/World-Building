---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cabbage 
merchantCategory: Homesteader
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: The Fat Wren Hill Farm 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Richmond (Teen ) Male who is Healthy  
- Walcott (Teen ) Male who is Sick  
services: 
- Farmer( Good   quality, Above Average  costs) 
- Food( Average   quality, Average  costs) 
exterior: An building with brick siding with a missing window. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Good   quality |  Above Average  costs | 
> | Food |  Average   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Richmond  | Teen  |  Male who is Healthy   | 
>> | Walcott  | Teen  |  Male who is Sick   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

