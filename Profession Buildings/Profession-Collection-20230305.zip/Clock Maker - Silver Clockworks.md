---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Clock Maker 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Silver Clockworks 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Ashley (Teen ) Male who is Fine  
- Langdon (Teen ) Male who is All Right  
services: 
- Craftsman( Good   quality, Average  costs) 
- Toy Making( Excellent   quality, Above Average  costs) 
- Clock Making( Horrible   quality, High  costs) 
- Tinkerer( Horrible   quality, Low  costs) 
exterior: An narrow two story building with new paint and with shingled siding with a few broken windows. The roof is Ceiling. A Pine shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Good   quality |  Average  costs | 
> | Toy Making |  Excellent   quality |  Above Average  costs | 
> | Clock Making |  Horrible   quality |  High  costs | 
> | Tinkerer |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Ashley  | Teen  |  Male who is Fine   | 
>> | Langdon  | Teen  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

