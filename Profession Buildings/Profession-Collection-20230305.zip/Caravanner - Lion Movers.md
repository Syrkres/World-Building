---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Caravanner 
merchantCategory: Animal Handler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: TANNERY,FARM,STABLE
title: Lion Movers 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Asheton (Teen ) Male who is Sick  
- Presley (Child ) Female who is Sick  
services: 
- Animal Handler( Average   quality, Low  costs) 
- Transportation( Horrible   quality, High  costs) 
- Animal ( Horrible   quality, Above Average  costs) 
exterior: An long building with faded paint and with brick siding. The roof is Ceiling. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Average   quality |  Low  costs | 
> | Transportation |  Horrible   quality |  High  costs | 
> | Animal  |  Horrible   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Asheton  | Teen  |  Male who is Sick   | 
>> | Presley  | Child  |  Female who is Sick   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

