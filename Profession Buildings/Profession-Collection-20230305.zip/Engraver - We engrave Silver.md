---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Engraver 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We engrave Silver 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Weld (Teen ) Female who is Unwell  
services: 
- Craftsman( Average   quality, Below Average  costs) 
- Toy Making( Good   quality, High  costs) 
- Clock Making( Poor   quality, Below Average  costs) 
- Tinkerer( Average   quality, Below Average  costs) 
exterior: An long building with new paint and with planked siding with a few windows. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Average   quality |  Below Average  costs | 
> | Toy Making |  Good   quality |  High  costs | 
> | Clock Making |  Poor   quality |  Below Average  costs | 
> | Tinkerer |  Average   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Weld  | Teen  |  Female who is Unwell   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

