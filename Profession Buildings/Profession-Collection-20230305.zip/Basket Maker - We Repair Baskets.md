---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Basket Maker 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We Repair Baskets 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Nash (Teen ) Female who is Fit  
- Clare (Young Adult ) Female who is Well  
services: 
- Craftsman( Excellent   quality, Above Average  costs) 
- Toy Making( Horrible   quality, Low  costs) 
- Clock Making( Good   quality, High  costs) 
- Tinkerer( Poor   quality, Low  costs) 
exterior: An old long building with shingled siding with a missing tall window. The roof is Roof. A Red Oak shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Excellent   quality |  Above Average  costs | 
> | Toy Making |  Horrible   quality |  Low  costs | 
> | Clock Making |  Good   quality |  High  costs | 
> | Tinkerer |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Nash  | Teen  |  Female who is Fit   | 
>> | Clare  | Young Adult  |  Female who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

