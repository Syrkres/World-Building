---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Acrobat 
merchantCategory: Entertainer
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: THEATER,TAVERN
title: The Leopard 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Ashley (Adult ) Male who is Healthy  
services: 
- Entertainer( Excellent   quality, High  costs) 
- Performance( Poor   quality, Below Average  costs) 
exterior: An old long tall building with planked siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Entertainer |  Excellent   quality |  High  costs | 
> | Performance |  Poor   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Ashley  | Adult  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

