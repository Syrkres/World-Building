---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian 
merchantCategory: Tracker
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,STABLE
title: The Large Snake Guild 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Spalding (Teen ) Female who is Inured  
services: 
- Mercenary( Low   quality, Average  costs) 
- Tracking( Poor   quality, Low  costs) 
exterior: An building with stoned siding. The roof is Canopy. A Oak pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Low   quality |  Average  costs | 
> | Tracking |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Spalding  | Teen  |  Female who is Inured   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

