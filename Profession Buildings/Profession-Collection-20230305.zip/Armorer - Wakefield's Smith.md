---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armorer 
merchantCategory: Forger
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,SMITHY
title: Wakefield's Smith 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Perry (Young Adult ) Male who is Fine  
services: 
- Blacksmith( Average   quality, High  costs) 
- Armor Crafting( Excellent   quality, Average  costs) 
- Item Crafting( Horrible   quality, Below Average  costs) 
exterior: An old one story building with new paint and with planked siding with a front short shuttered window that has a painted sign hanging above with the merchants name. The roof is Ceiling. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Blacksmith |  Average   quality |  High  costs | 
> | Armor Crafting |  Excellent   quality |  Average  costs | 
> | Item Crafting |  Horrible   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Perry  | Young Adult  |  Male who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

