---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric 
merchantCategory: Clergy
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHRINE,HOUSE
title: Shrine of the Unreliable 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Webley (Teen ) Female who is Well  
services: 
- Clergy( Horrible   quality, Low  costs) 
- Religion( Low   quality, High  costs) 
- House of Worship( Horrible   quality, Average  costs) 
- Curse Removal( Average   quality, Below Average  costs) 
- Spell Research( Average   quality, High  costs) 
- Healing( Poor   quality, Low  costs) 
- Potions( Horrible   quality, Below Average  costs) 
exterior: An building with faded paint and with shingled siding with a few broken windows. The roof is Ceiling. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Horrible   quality |  Low  costs | 
> | Religion |  Low   quality |  High  costs | 
> | House of Worship |  Horrible   quality |  Average  costs | 
> | Curse Removal |  Average   quality |  Below Average  costs | 
> | Spell Research |  Average   quality |  High  costs | 
> | Healing |  Poor   quality |  Low  costs | 
> | Potions |  Horrible   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Webley  | Teen  |  Female who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

