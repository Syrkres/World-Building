---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder 
merchantCategory: Homesteader
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: Ye Gnomish Hill Meadows 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Brady (Teen ) Female who is Healthy  
services: 
- Farmer( Good   quality, Below Average  costs) 
- Food( Horrible   quality, Low  costs) 
exterior: An narrow building with new paint and with planked siding with a front broken window that has a carved sign hanging to the side with the merchants name. The roof is House. A Maple shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Good   quality |  Below Average  costs | 
> | Food |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Brady  | Teen  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

