---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armor Dealer 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,SMITHY
title: The Silver Scalemail Hawker 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Milton (Mature Adult ) Male who is Unwell  
- Wentworth (Adult ) Female who is Incapacitaed  
services: 
- Merchant( Average   quality, Low  costs) 
- Armor Crafting( Poor   quality, Average  costs) 
exterior: An new building with new paint and with planked siding. The roof is House. A Elm pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Average   quality |  Low  costs | 
> | Armor Crafting |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Milton  | Mature Adult  |  Male who is Unwell   | 
>> | Wentworth  | Adult  |  Female who is Incapacitaed   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

