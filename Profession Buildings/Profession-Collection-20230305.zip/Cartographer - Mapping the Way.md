---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cartographer 
merchantCategory: Tracker
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Mapping the Way 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Livingstone (Young Adult ) Female who is Fit as a fiddle  
services: 
- Professional Specialties( Good   quality, Below Average  costs) 
- Mapping( Excellent   quality, High  costs) 
- Map Translation( Low   quality, Above Average  costs) 
exterior: An narrow building with shingled siding. The roof is Roof. A Cherry pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Good   quality |  Below Average  costs | 
> | Mapping |  Excellent   quality |  High  costs | 
> | Map Translation |  Low   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Livingstone  | Young Adult  |  Female who is Fit as a fiddle   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

