---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cobbler 
merchantCategory: Garment Trade
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Ye Shoe Maker 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Willoughby (Teen ) Female who is Healthy  
- Braxton (Young Adult ) Male who is Healthy  
services: 
- Garment Trade( Low   quality, Above Average  costs) 
- Shoe Repair( Good   quality, Low  costs) 
exterior: An new building with brick siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Low   quality |  Above Average  costs | 
> | Shoe Repair |  Good   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Willoughby  | Teen  |  Female who is Healthy   | 
>> | Braxton  | Young Adult  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

