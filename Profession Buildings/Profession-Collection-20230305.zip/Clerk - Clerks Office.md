---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Clerk 
merchantCategory: Elected Official
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHRINE,CLERK
title: Clerks Office 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Kelsey (Mature Adult ) Female who is Unwell  
- Deighton (Adult ) Female who is Impaired  
services: 
- Elected Official( Low   quality, Below Average  costs) 
- Diplomacy( Poor   quality, High  costs) 
- Note Taking( Average   quality, Above Average  costs) 
exterior: An long building with brick siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Elected Official |  Low   quality |  Below Average  costs | 
> | Diplomacy |  Poor   quality |  High  costs | 
> | Note Taking |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Kelsey  | Mature Adult  |  Female who is Unwell   | 
>> | Deighton  | Adult  |  Female who is Impaired   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

