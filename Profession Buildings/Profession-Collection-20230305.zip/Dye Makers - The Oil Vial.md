---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dye Makers 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: The Oil Vial 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Sage( Poor   quality, Below Average  costs) 
- Arcane Research( Excellent   quality, Above Average  costs) 
- Potion Brewing( Average   quality, High  costs) 
exterior: An new building with faded paint and with shingled siding. The roof is Canopy. A Beech shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Poor   quality |  Below Average  costs | 
> | Arcane Research |  Excellent   quality |  Above Average  costs | 
> | Potion Brewing |  Average   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

