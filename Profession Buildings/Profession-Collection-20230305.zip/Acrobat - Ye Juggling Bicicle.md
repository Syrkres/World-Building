---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Acrobat 
merchantCategory: Entertainer
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: THEATER,TAVERN
title: Ye Juggling Bicicle 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Hackney (Young Adult ) Male who is Dying  
services: 
- Entertainer( Horrible   quality, High  costs) 
- Performance( Poor   quality, High  costs) 
exterior: An narrow building with new paint and with shingled siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Entertainer |  Horrible   quality |  High  costs | 
> | Performance |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hackney  | Young Adult  |  Male who is Dying   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

