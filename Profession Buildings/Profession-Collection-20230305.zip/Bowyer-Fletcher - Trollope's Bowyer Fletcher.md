---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bowyer-Fletcher 
merchantCategory: Wood Workers
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Trollope's Bowyer Fletcher 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Oakes (Young Adult ) Female who is Healthy  
services: 
- Artisan( Poor   quality, Average  costs) 
- Wood Carver( Excellent   quality, Average  costs) 
exterior: An old tall building with new paint and with shingled siding. The roof is Roof. A Elm pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Artisan |  Poor   quality |  Average  costs | 
> | Wood Carver |  Excellent   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Oakes  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

