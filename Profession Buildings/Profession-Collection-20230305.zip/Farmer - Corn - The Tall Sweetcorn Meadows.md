---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Corn 
merchantCategory: Homesteader
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: The Tall Sweetcorn Meadows 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Hayes (Young Adult ) Female who is Well  
- Kelsey (Young Adult ) Female who is Fit  
services: 
- Farmer( Poor   quality, Low  costs) 
- Food( Excellent   quality, Average  costs) 
exterior: An old narrow building with new paint and with brick siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Poor   quality |  Low  costs | 
> | Food |  Excellent   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hayes  | Young Adult  |  Female who is Well   | 
>> | Kelsey  | Young Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

