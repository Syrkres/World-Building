---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Alchemist 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: The Jasmine (Water / Earth) Incense 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Sage( Good   quality, Above Average  costs) 
- Arcane Research( Poor   quality, Above Average  costs) 
- Potion Brewing( Horrible   quality, High  costs) 
exterior: An one story building with new paint and with brick siding with a few shuttered windows. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Good   quality |  Above Average  costs | 
> | Arcane Research |  Poor   quality |  Above Average  costs | 
> | Potion Brewing |  Horrible   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

