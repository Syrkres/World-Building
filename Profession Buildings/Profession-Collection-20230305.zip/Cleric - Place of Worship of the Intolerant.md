---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric 
merchantCategory: Clergy
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHRINE,HOUSE
title: Place of Worship of the Intolerant 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Clergy( Average   quality, Below Average  costs) 
- Religion( Poor   quality, Low  costs) 
- House of Worship( Horrible   quality, Above Average  costs) 
- Curse Removal( Horrible   quality, High  costs) 
- Spell Research( Excellent   quality, High  costs) 
- Healing( Excellent   quality, Average  costs) 
- Potions( Poor   quality, Average  costs) 
exterior: An new long building with brick siding. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Average   quality |  Below Average  costs | 
> | Religion |  Poor   quality |  Low  costs | 
> | House of Worship |  Horrible   quality |  Above Average  costs | 
> | Curse Removal |  Horrible   quality |  High  costs | 
> | Spell Research |  Excellent   quality |  High  costs | 
> | Healing |  Excellent   quality |  Average  costs | 
> | Potions |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

