---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cooper 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We Make Drum 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Davenport (Child ) Female who is Healthy  
- Charlton (Adult ) Male who is Incapacitaed  
services: 
- Craftsman( Average   quality, Average  costs) 
- Toy Making( Excellent   quality, Below Average  costs) 
- Clock Making( Poor   quality, Below Average  costs) 
- Tinkerer( Horrible   quality, Below Average  costs) 
exterior: An old tall building with shingled siding. The roof is Dome. A Elm shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Average   quality |  Average  costs | 
> | Toy Making |  Excellent   quality |  Below Average  costs | 
> | Clock Making |  Poor   quality |  Below Average  costs | 
> | Tinkerer |  Horrible   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Davenport  | Child  |  Female who is Healthy   | 
>> | Charlton  | Adult  |  Male who is Incapacitaed   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

