---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric 
merchantCategory: Clergy
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHRINE,HOUSE
title: Sanctuary of the Talkative 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Clergy( Average   quality, Below Average  costs) 
- Religion( Excellent   quality, Below Average  costs) 
- House of Worship( Horrible   quality, Average  costs) 
- Curse Removal( Average   quality, Below Average  costs) 
- Spell Research( Average   quality, High  costs) 
- Healing( Good   quality, Above Average  costs) 
- Potions( Low   quality, Below Average  costs) 
exterior: An new tall building with faded paint and with stoned siding with a few shuttered windows. The roof is Dome. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Average   quality |  Below Average  costs | 
> | Religion |  Excellent   quality |  Below Average  costs | 
> | House of Worship |  Horrible   quality |  Average  costs | 
> | Curse Removal |  Average   quality |  Below Average  costs | 
> | Spell Research |  Average   quality |  High  costs | 
> | Healing |  Good   quality |  Above Average  costs | 
> | Potions |  Low   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

