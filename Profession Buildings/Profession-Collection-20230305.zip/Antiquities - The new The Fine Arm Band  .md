---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,EXOTIC ARTISAN
title: The new The Fine Arm Band   
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Bentham (Teen ) Male who is Nauseos  
services: 
- Merchant( Low   quality, Below Average  costs) 
- Item Research( Horrible   quality, High  costs) 
exterior: An narrow building with stoned siding with a front tall broken window that has a carved sign hanging to the side with the merchants name. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Low   quality |  Below Average  costs | 
> | Item Research |  Horrible   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Bentham  | Teen  |  Male who is Nauseos   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

