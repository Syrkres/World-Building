---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Captain 
merchantCategory: Guard
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: JAIL
title: The Narrow Captain Pub 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Mercenary( Poor   quality, Low  costs) 
- Leadership( Good   quality, Average  costs) 
exterior: An old tall building with new paint and with planked siding. The roof is Dome. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Poor   quality |  Low  costs | 
> | Leadership |  Good   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

