---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand 
merchantCategory: Criminal
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: JAIL,HOUSE
title: The Rough Rabbit Guild 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Oakes (Mature Adult ) Male who is At death's door  
services: 
- Mercenary( Excellent   quality, Low  costs) 
- Enforcement( Average   quality, Average  costs) 
- Intimidation( Horrible   quality, High  costs) 
exterior: An one story building with faded paint and with brick siding with a missing window. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Excellent   quality |  Low  costs | 
> | Enforcement |  Average   quality |  Average  costs | 
> | Intimidation |  Horrible   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Oakes  | Mature Adult  |  Male who is At death's door   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

