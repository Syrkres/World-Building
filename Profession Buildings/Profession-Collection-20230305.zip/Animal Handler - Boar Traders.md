---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Handler 
merchantCategory: Animal Handler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Boar Traders 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Tyndall (Young Adult ) Male who is Nauseos  
- Hallewell (Young Adult ) Male who is Fit  
services: 
- Animal Handler( Horrible   quality, High  costs) 
- Stabler( Excellent   quality, Low  costs) 
exterior: An long building with new paint and with shingled siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Horrible   quality |  High  costs | 
> | Stabler |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Tyndall  | Young Adult  |  Male who is Nauseos   | 
>> | Hallewell  | Young Adult  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

