---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Apothecary 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,ALCHEMIST
title: The White Glass Vial 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Morton (Teen ) Male who is Well  
- Dryden (Young Adult ) Male who is All Right  
services: 
- Professional Specialties( Average   quality, Below Average  costs) 
- Healing( Horrible   quality, Below Average  costs) 
- Potion Brewing( Excellent   quality, Low  costs) 
- Remedy Crafting( Low   quality, Average  costs) 
exterior: An old tall building with faded paint and with planked siding. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Average   quality |  Below Average  costs | 
> | Healing |  Horrible   quality |  Below Average  costs | 
> | Potion Brewing |  Excellent   quality |  Low  costs | 
> | Remedy Crafting |  Low   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Morton  | Teen  |  Male who is Well   | 
>> | Dryden  | Young Adult  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

