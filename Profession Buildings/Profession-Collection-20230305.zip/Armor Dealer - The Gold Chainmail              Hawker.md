---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armor Dealer 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,SMITHY
title: The Gold Chainmail              Hawker 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Kimberly (Teen ) Male who is Fine  
- Tindall (Child ) Male who is Healthy  
services: 
- Merchant( Good   quality, Average  costs) 
- Armor Crafting( Poor   quality, Low  costs) 
exterior: An old narrow building with planked siding with a missing window. The roof is Roof. A Cherry shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Good   quality |  Average  costs | 
> | Armor Crafting |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Kimberly  | Teen  |  Male who is Fine   | 
>> | Tindall  | Child  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

