---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crook 
merchantCategory: Criminal
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Pawn Parlor 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Berkeley (Adult ) Male who is Fine  
- Huckabee (Teen ) Male who is Expired  
services: 
- Criminal( Poor   quality, High  costs) 
- Deception( Horrible   quality, Low  costs) 
- Theft( Good   quality, Below Average  costs) 
exterior: An new narrow building with faded paint and with shingled siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Criminal |  Poor   quality |  High  costs | 
> | Deception |  Horrible   quality |  Low  costs | 
> | Theft |  Good   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Berkeley  | Adult  |  Male who is Fine   | 
>> | Huckabee  | Teen  |  Male who is Expired   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

