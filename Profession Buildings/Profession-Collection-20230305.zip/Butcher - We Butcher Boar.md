---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Butcher 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We Butcher Boar 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Darlington (Child ) Female who is Out of sorts  
services: 
- Cook( Good   quality, Low  costs) 
- Meat Processing( Horrible   quality, Average  costs) 
exterior: An old long tall building with new paint and with shingled siding with a few boarded windows. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Good   quality |  Low  costs | 
> | Meat Processing |  Horrible   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Darlington  | Child  |  Female who is Out of sorts   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

