---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chicken Butcher 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Plucked Goldfinch 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Alston (Adult ) Male who is Fit  
- Appleton (Young Adult ) Male who is Well  
services: 
- Cook( Good   quality, Average  costs) 
- Meat Processing( Excellent   quality, Above Average  costs) 
exterior: An new narrow building with shingled siding. The roof is Canopy. A Pine shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Good   quality |  Average  costs | 
> | Meat Processing |  Excellent   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Alston  | Adult  |  Male who is Fit   | 
>> | Appleton  | Young Adult  |  Male who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

