---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Engraver 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Silver Engraver Reseller 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- York (Teen ) Female who is Sick  
services: 
- Craftsman( Good   quality, Below Average  costs) 
- Toy Making( Poor   quality, Above Average  costs) 
- Clock Making( Low   quality, Low  costs) 
- Tinkerer( Poor   quality, Low  costs) 
exterior: An long one story building with planked siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Good   quality |  Below Average  costs | 
> | Toy Making |  Poor   quality |  Above Average  costs | 
> | Clock Making |  Low   quality |  Low  costs | 
> | Tinkerer |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | York  | Teen  |  Female who is Sick   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

