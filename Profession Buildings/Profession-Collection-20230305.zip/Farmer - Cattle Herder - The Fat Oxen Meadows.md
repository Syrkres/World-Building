---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder 
merchantCategory: Homesteader
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: The Fat Oxen Meadows 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Wesley (Young Adult ) Male who is Fine  
services: 
- Farmer( Poor   quality, Average  costs) 
- Food( Low   quality, Average  costs) 
exterior: An two story building with shingled siding with a missing window. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Poor   quality |  Average  costs | 
> | Food |  Low   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Wesley  | Young Adult  |  Male who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

