---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dairy Seller 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: Ye Milk Farm 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Garfield (Teen ) Male who is Maimed  
- Acton (Teen ) Male who is Sick  
services: 
- Farmer( Good   quality, Low  costs) 
- Food( Excellent   quality, Below Average  costs) 
exterior: An new narrow tall building with brick siding. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Good   quality |  Low  costs | 
> | Food |  Excellent   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Garfield  | Teen  |  Male who is Maimed   | 
>> | Acton  | Teen  |  Male who is Sick   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

