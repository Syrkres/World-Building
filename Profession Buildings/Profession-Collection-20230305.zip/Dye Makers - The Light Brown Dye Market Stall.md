---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dye Makers 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: The Light Brown Dye Market Stall 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Asheton (Young Adult ) Female who is Dying  
services: 
- Sage( Low   quality, High  costs) 
- Arcane Research( Good   quality, High  costs) 
- Potion Brewing( Excellent   quality, Average  costs) 
exterior: An building with new paint and with shingled siding with a few windows. The roof is Canopy. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Low   quality |  High  costs | 
> | Arcane Research |  Good   quality |  High  costs | 
> | Potion Brewing |  Excellent   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Asheton  | Young Adult  |  Female who is Dying   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

