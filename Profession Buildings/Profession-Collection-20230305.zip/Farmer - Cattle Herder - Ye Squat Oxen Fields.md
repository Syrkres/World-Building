---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder 
merchantCategory: Homesteader
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: Ye Squat Oxen Fields 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Winthrop (Young Adult ) Male who is Healthy  
- Langdon (Teen ) Male who is Fine  
services: 
- Farmer( Horrible   quality, Above Average  costs) 
- Food( Low   quality, High  costs) 
exterior: An old narrow two story building with new paint and with stoned siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Horrible   quality |  Above Average  costs | 
> | Food |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Winthrop  | Young Adult  |  Male who is Healthy   | 
>> | Langdon  | Teen  |  Male who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

