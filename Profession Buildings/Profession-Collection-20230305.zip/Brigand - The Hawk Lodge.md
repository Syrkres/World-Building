---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand 
merchantCategory: Criminal
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: JAIL,HOUSE
title: The Hawk Lodge 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Pickering (Teen ) Female who is Fine  
services: 
- Mercenary( Low   quality, Below Average  costs) 
- Enforcement( Average   quality, Average  costs) 
- Intimidation( Poor   quality, Above Average  costs) 
exterior: An old building with faded paint and with stoned siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is House. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Low   quality |  Below Average  costs | 
> | Enforcement |  Average   quality |  Average  costs | 
> | Intimidation |  Poor   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Pickering  | Teen  |  Female who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

