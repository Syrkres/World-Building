---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Earl 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Kendall's Mansion 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Preston (Young Adult ) Female who is Healthy  
services: 
- Noble( Good   quality, Average  costs) 
- Diplomacy( Poor   quality, Average  costs) 
- Advise( Excellent   quality, Below Average  costs) 
exterior: An new building with stoned siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Noble |  Good   quality |  Average  costs | 
> | Diplomacy |  Poor   quality |  Average  costs | 
> | Advise |  Excellent   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Preston  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

