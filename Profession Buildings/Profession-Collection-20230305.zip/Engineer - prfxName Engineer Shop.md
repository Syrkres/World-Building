---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Engineer 
merchantCategory: Construction
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: prfxName Engineer Shop 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Mitchell (Young Adult ) Male who is Healthy  
- Bristol (Young Adult ) Female who is Healthy  
services: 
- Laborer( Poor   quality, Low  costs) 
exterior: An old narrow building with new paint and with shingled siding with a front tall window that has a painted sign hanging above with the merchants name. The roof is House. A Beech shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Laborer |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Mitchell  | Young Adult  |  Male who is Healthy   | 
>> | Bristol  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

