---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brewer 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: Barrel Fresh Beer 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Branson (Adult ) Female who is Expired  
services: 
- Sage( Low   quality, Below Average  costs) 
- Arcane Research( Poor   quality, Low  costs) 
- Potion Brewing( Low   quality, Above Average  costs) 
exterior: An old building with stoned siding. The roof is Roof. A Cherry shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Low   quality |  Below Average  costs | 
> | Arcane Research |  Poor   quality |  Low  costs | 
> | Potion Brewing |  Low   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Branson  | Adult  |  Female who is Expired   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

