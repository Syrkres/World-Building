---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bather 
merchantCategory: Specialty Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The old wash shop 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Darlington (Teen ) Male who is Scraped up  
services: 
- Specialty Service( Horrible   quality, Above Average  costs) 
- Wash( Low   quality, High  costs) 
exterior: An building with brick siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Specialty Service |  Horrible   quality |  Above Average  costs | 
> | Wash |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Darlington  | Teen  |  Male who is Scraped up   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

