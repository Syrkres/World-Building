---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Caravanner 
merchantCategory: Animal Handler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: TANNERY,FARM,STABLE
title: We move stuff 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Animal Handler( Excellent   quality, Low  costs) 
- Transportation( Poor   quality, Low  costs) 
- Animal ( Horrible   quality, Low  costs) 
exterior: An old building with stoned siding. The roof is House. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Excellent   quality |  Low  costs | 
> | Transportation |  Poor   quality |  Low  costs | 
> | Animal  |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

