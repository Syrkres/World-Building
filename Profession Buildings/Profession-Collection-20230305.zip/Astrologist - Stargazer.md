---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Astrologist 
merchantCategory: Sage
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Stargazer 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Richmond (Young Adult ) Male who is All Right  
services: 
- Entertainer( Average   quality, Low  costs) 
- Performance( Average   quality, Above Average  costs) 
exterior: An building with faded paint and with shingled siding with a few broken windows. The roof is Roof. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Entertainer |  Average   quality |  Low  costs | 
> | Performance |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Richmond  | Young Adult  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

