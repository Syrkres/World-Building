---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dairy Seller 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: Ye Milk Fields 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Langley (Teen ) Female who is Deceased  
- Allerton (Adult ) Male who is Sick  
services: 
- Farmer( Good   quality, Average  costs) 
- Food( Excellent   quality, Below Average  costs) 
exterior: An two story building with new paint and with brick siding. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Good   quality |  Average  costs | 
> | Food |  Excellent   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Langley  | Teen  |  Female who is Deceased   | 
>> | Allerton  | Adult  |  Male who is Sick   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

