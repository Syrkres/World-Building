---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barrel Maker 
merchantCategory: Wood Workers
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Oak barrel Maker 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Westbrook (Teen ) Female who is Inured  
services: 
- Craftsman( Low   quality, Low  costs) 
- Barrel Crafting( Low   quality, Average  costs) 
exterior: An one story building with faded paint and with brick siding with a front broken window that has a painted sign hanging above with the merchants name. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Low   quality |  Low  costs | 
> | Barrel Crafting |  Low   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Westbrook  | Teen  |  Female who is Inured   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

