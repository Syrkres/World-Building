---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Clock Maker 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Iron Clockworks 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Craftsman( Poor   quality, Below Average  costs) 
- Toy Making( Horrible   quality, Low  costs) 
- Clock Making( Low   quality, High  costs) 
- Tinkerer( Horrible   quality, Below Average  costs) 
exterior: An old two story building with new paint and with brick siding with a front boarded window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Poor   quality |  Below Average  costs | 
> | Toy Making |  Horrible   quality |  Low  costs | 
> | Clock Making |  Low   quality |  High  costs | 
> | Tinkerer |  Horrible   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

