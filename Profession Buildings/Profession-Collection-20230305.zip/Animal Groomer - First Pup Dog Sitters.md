---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer 
merchantCategory: Animal Handler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: TANNERY,FARM,STABLE
title: First Pup Dog Sitters 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Marston (Young Adult ) Female who is Ill  
services: 
- Animal Handler( Excellent   quality, High  costs) 
- Pet Training( Horrible   quality, Low  costs) 
- Animal Training( Average   quality, High  costs) 
exterior: An old narrow one story building with brick siding with a front window that has a painted sign hanging above with the merchants name. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Excellent   quality |  High  costs | 
> | Pet Training |  Horrible   quality |  Low  costs | 
> | Animal Training |  Average   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Marston  | Young Adult  |  Female who is Ill   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

