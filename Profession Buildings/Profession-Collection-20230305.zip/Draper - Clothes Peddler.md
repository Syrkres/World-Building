---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Draper 
merchantCategory: Garment Trade
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Clothes Peddler 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Rodney (Adult ) Male who is Healthy  
services: 
- Garment Trade( Poor   quality, High  costs) 
- Trader( Good   quality, Below Average  costs) 
exterior: An narrow building with brick siding with a front broken window that has a sign hanging above with the merchants name. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Poor   quality |  High  costs | 
> | Trader |  Good   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Rodney  | Adult  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

