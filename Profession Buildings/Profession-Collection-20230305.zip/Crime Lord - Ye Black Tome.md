---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crime Lord 
merchantCategory: Criminal
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Ye Black Tome 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Blackmarket( Low   quality, High  costs) 
- Merchant( Poor   quality, Low  costs) 
- Transfer of Goods( Poor   quality, Above Average  costs) 
exterior: An old tall building with planked siding with a missing tall window. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Blackmarket |  Low   quality |  High  costs | 
> | Merchant |  Poor   quality |  Low  costs | 
> | Transfer of Goods |  Poor   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

