---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bookseller 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Under Covers 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Craftsman( Excellent   quality, Low  costs) 
- Toy Making( Average   quality, Low  costs) 
- Clock Making( Excellent   quality, Average  costs) 
- Tinkerer( Excellent   quality, Low  costs) 
exterior: An new long tall building with stoned siding with a front round window that has a painted sign hanging above with the merchants name. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Excellent   quality |  Low  costs | 
> | Toy Making |  Average   quality |  Low  costs | 
> | Clock Making |  Excellent   quality |  Average  costs | 
> | Tinkerer |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

