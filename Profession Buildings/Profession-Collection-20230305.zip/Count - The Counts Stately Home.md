---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Count 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Counts Stately Home 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Hartford (Teen ) Female who is Healthy as a horse  
- Middleton (Teen ) Male who is All Right  
services: 
- Offical( Horrible   quality, Average  costs) 
- Diplomacy( Poor   quality, Average  costs) 
exterior: An new tall building with stoned siding. The roof is Canopy. A Cherry shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Offical |  Horrible   quality |  Average  costs | 
> | Diplomacy |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hartford  | Teen  |  Female who is Healthy as a horse   | 
>> | Middleton  | Teen  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

