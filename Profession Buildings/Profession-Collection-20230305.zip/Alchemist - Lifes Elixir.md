---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Alchemist 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: Lifes Elixir 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Southey (Teen ) Male who is Fit  
- Spalding (Young Adult ) Male who is Fit  
services: 
- Sage( Good   quality, High  costs) 
- Arcane Research( Excellent   quality, Low  costs) 
- Potion Brewing( Good   quality, Average  costs) 
exterior: An one story building with new paint and with brick siding. The roof is Ceiling. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Good   quality |  High  costs | 
> | Arcane Research |  Excellent   quality |  Low  costs | 
> | Potion Brewing |  Good   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Southey  | Teen  |  Male who is Fit   | 
>> | Spalding  | Young Adult  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

