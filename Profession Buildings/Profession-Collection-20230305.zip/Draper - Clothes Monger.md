---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Draper 
merchantCategory: Garment Trade
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Clothes Monger 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Wellington (Young Adult ) Female who is Fit  
services: 
- Garment Trade( Average   quality, Below Average  costs) 
- Trader( Average   quality, Above Average  costs) 
exterior: An narrow two story building with new paint and with brick siding with a front round window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Average   quality |  Below Average  costs | 
> | Trader |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Wellington  | Young Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

