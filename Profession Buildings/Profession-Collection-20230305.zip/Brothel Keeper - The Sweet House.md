---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brothel Keeper 
merchantCategory: Hosteler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Sweet House 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Oakley (Young Adult ) Male who is Not oneself  
- Alston (Teen ) Female who is Healthy  
services: 
- Room (Pleasure)( Excellent   quality, Average  costs) 
- Common Room (Sleeping)( Horrible   quality, Low  costs) 
- Room (Meeting)( Poor   quality, Below Average  costs) 
exterior: An new building with planked siding with a front tall boarded window that has a carved sign hanging to the side with the merchants name. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Room  | Pleasure | ( Excellent   quality | 
> | Common Room  | Sleeping | ( Horrible   quality | 
> | Room  | Meeting | ( Poor   quality | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Oakley  | Young Adult  |  Male who is Not oneself   | 
>> | Alston  | Teen  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

