---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian 
merchantCategory: Tracker
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,STABLE
title: The Fish Lodge 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Berkeley (Adult ) Female who is Fit  
services: 
- Mercenary( Excellent   quality, Low  costs) 
- Tracking( Horrible   quality, High  costs) 
exterior: An old tall building with new paint and with stoned siding with a front tall broken window that has a carved sign hanging to the side with the merchants name. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Excellent   quality |  Low  costs | 
> | Tracking |  Horrible   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Berkeley  | Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

