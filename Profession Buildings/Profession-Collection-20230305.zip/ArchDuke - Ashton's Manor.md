---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: ArchDuke 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Ashton's Manor 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Addington (Young Adult ) Female who is Well  
services: 
- Noble( Excellent   quality, Low  costs) 
- Diplomacy( Poor   quality, High  costs) 
- Advise( Horrible   quality, High  costs) 
exterior: An building with faded paint and with stoned siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Noble |  Excellent   quality |  Low  costs | 
> | Diplomacy |  Poor   quality |  High  costs | 
> | Advise |  Horrible   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Addington  | Young Adult  |  Female who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

