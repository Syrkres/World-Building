---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Draper 
merchantCategory: Garment Trade
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Used hat Garmets 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Perry (Teen ) Female who is Dying  
- Beckwith (Young Adult ) Female who is Sick  
services: 
- Garment Trade( Poor   quality, Average  costs) 
- Trader( Poor   quality, Above Average  costs) 
exterior: An building with brick siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Poor   quality |  Average  costs | 
> | Trader |  Poor   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Perry  | Teen  |  Female who is Dying   | 
>> | Beckwith  | Young Adult  |  Female who is Sick   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

