---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Earl 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Altham's Manor 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Livingstone (Young Adult ) Male who is Hurt  
services: 
- Noble( Good   quality, Above Average  costs) 
- Diplomacy( Average   quality, Average  costs) 
- Advise( Excellent   quality, High  costs) 
exterior: An old building with faded paint and with planked siding with a few round windows. The roof is Dome. A Beech shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Noble |  Good   quality |  Above Average  costs | 
> | Diplomacy |  Average   quality |  Average  costs | 
> | Advise |  Excellent   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Livingstone  | Young Adult  |  Male who is Hurt   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

