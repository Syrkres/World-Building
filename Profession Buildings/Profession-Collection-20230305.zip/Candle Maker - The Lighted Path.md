---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Candle Maker 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Lighted Path 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Clinton (Teen ) Male who is Out of sorts  
services: 
- Specialty Service( Good   quality, Above Average  costs) 
- Candle Making( Average   quality, Below Average  costs) 
exterior: An long two story building with stoned siding with a front window that has a painted sign hanging above with the merchants name. The roof is Dome. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Specialty Service |  Good   quality |  Above Average  costs | 
> | Candle Making |  Average   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Clinton  | Teen  |  Male who is Out of sorts   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

