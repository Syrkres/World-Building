---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Duke 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Dukes Mansion 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Bristol (Adult ) Male who is Healthy  
- Bentham (Teen ) Male who is Fit as a fiddle  
services: 
- Noble( Average   quality, Below Average  costs) 
- Diplomacy( Average   quality, Above Average  costs) 
- Advise( Good   quality, Above Average  costs) 
exterior: An new narrow building with faded paint and with stoned siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Noble |  Average   quality |  Below Average  costs | 
> | Diplomacy |  Average   quality |  Above Average  costs | 
> | Advise |  Good   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Bristol  | Adult  |  Male who is Healthy   | 
>> | Bentham  | Teen  |  Male who is Fit as a fiddle   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

