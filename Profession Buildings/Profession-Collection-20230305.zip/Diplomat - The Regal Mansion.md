---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Diplomat 
merchantCategory: Elected Official
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Regal Mansion 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Allerton (Young Adult ) Female who is Fit  
services: 
- Professional Specialties( Poor   quality, Above Average  costs) 
- Advocate( Horrible   quality, High  costs) 
exterior: An new building with planked siding with a front shuttered window that has a painted sign hanging above with the merchants name. The roof is House. A Ceder shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Poor   quality |  Above Average  costs | 
> | Advocate |  Horrible   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Allerton  | Young Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

