---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Engraver 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Ye Silver Engraver Store 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Preston (Teen ) Male who is At death's door  
services: 
- Craftsman( Low   quality, High  costs) 
- Toy Making( Excellent   quality, Average  costs) 
- Clock Making( Average   quality, Below Average  costs) 
- Tinkerer( Average   quality, Low  costs) 
exterior: An new long building with shingled siding with a missing window. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Low   quality |  High  costs | 
> | Toy Making |  Excellent   quality |  Average  costs | 
> | Clock Making |  Average   quality |  Below Average  costs | 
> | Tinkerer |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Preston  | Teen  |  Male who is At death's door   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

