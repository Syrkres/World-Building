---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Sweet It 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Bing (Young Adult ) Female who is Healthy  
- Churchill (Young Adult ) Male who is All Right  
services: 
- Cook( Average   quality, Above Average  costs) 
- Bread and Pastry Making( Average   quality, High  costs) 
exterior: An building with planked siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Average   quality |  Above Average  costs | 
> | Bread and Pastry Making |  Average   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Bing  | Young Adult  |  Female who is Healthy   | 
>> | Churchill  | Young Adult  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

