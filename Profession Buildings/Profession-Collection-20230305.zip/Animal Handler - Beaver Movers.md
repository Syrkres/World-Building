---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Handler 
merchantCategory: Animal Handler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Beaver Movers 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Barney (Young Adult ) Female who is Indisposed  
- Winthrop (Teen ) Male who is All Right  
services: 
- Animal Handler( Excellent   quality, High  costs) 
- Stabler( Good   quality, Above Average  costs) 
exterior: An new narrow building with new paint and with shingled siding. The roof is Dome. A Cherry shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Excellent   quality |  High  costs | 
> | Stabler |  Good   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Barney  | Young Adult  |  Female who is Indisposed   | 
>> | Winthrop  | Teen  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

