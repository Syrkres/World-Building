---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cabbage 
merchantCategory: Homesteader
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: This Senior farm 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Presley (Adult ) Female who is Healthy  
services: 
- Farmer( Poor   quality, High  costs) 
- Food( Poor   quality, Above Average  costs) 
exterior: An tall building with new paint and with stoned siding. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Poor   quality |  High  costs | 
> | Food |  Poor   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Presley  | Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

