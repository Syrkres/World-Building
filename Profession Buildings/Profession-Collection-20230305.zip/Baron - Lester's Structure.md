---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baron 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Lester's Structure 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Kimberly (Young Adult ) Female who is Unwell  
- Dudley (Teen ) Female who is Sick  
services: 
- Diplomacy( Poor   quality, Low  costs) 
exterior: An two story building with planked siding. The roof is Canopy. A Oak shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Diplomacy |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Kimberly  | Young Adult  |  Female who is Unwell   | 
>> | Dudley  | Teen  |  Female who is Sick   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

