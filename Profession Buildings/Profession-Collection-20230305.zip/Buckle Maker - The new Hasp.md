---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Buckle Maker 
merchantCategory: Garment Trade
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The new Hasp 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Reed (Young Adult ) Female who is Well  
services: 
- Garment Trade( Horrible   quality, Average  costs) 
- Crafting( Average   quality, Below Average  costs) 
exterior: An new one story building with faded paint and with planked siding with a missing window. The roof is Dome. A Beech pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Horrible   quality |  Average  costs | 
> | Crafting |  Average   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Reed  | Young Adult  |  Female who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

