---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Book Binder 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,ALCHEMIST
title: Verbatim 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Acton (Adult ) Female who is Nauseos  
services: 
- Professional Specialties( Excellent   quality, Above Average  costs) 
- Book Binding( Low   quality, High  costs) 
exterior: An new narrow one story building with faded paint and with planked siding with a front round broken window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Excellent   quality |  Above Average  costs | 
> | Book Binding |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Acton  | Adult  |  Female who is Nauseos   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

