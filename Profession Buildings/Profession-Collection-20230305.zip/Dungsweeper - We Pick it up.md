---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dungsweeper 
merchantCategory: Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We Pick it up 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Preston (Teen ) Male who is Healthy  
- Lancaster (Teen ) Female who is Impaired  
services: 
- Laborer( Average   quality, Low  costs) 
exterior: An building with faded paint and with planked siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Laborer |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Preston  | Teen  |  Male who is Healthy   | 
>> | Lancaster  | Teen  |  Female who is Impaired   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

