---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Draper 
merchantCategory: Garment Trade
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Used pants Garmets 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Reed (Young Adult ) Female who is Fine  
services: 
- Garment Trade( Average   quality, Low  costs) 
- Trader( Poor   quality, High  costs) 
exterior: An tall building with planked siding. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Average   quality |  Low  costs | 
> | Trader |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Reed  | Young Adult  |  Female who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

