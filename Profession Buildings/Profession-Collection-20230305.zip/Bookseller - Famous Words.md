---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bookseller 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Famous Words 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Morley (Teen ) Male who is Healthy  
services: 
- Craftsman( Low   quality, Below Average  costs) 
- Toy Making( Poor   quality, Above Average  costs) 
- Clock Making( Horrible   quality, Above Average  costs) 
- Tinkerer( Poor   quality, Low  costs) 
exterior: An old one story building with brick siding. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Low   quality |  Below Average  costs | 
> | Toy Making |  Poor   quality |  Above Average  costs | 
> | Clock Making |  Horrible   quality |  Above Average  costs | 
> | Tinkerer |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Morley  | Teen  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

