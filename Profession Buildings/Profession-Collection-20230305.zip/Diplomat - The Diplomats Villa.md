---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Diplomat 
merchantCategory: Elected Official
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Diplomats Villa 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Clayden (Teen ) Female who is Wounded  
- Blythe (Young Adult ) Male who is Healthy  
services: 
- Professional Specialties( Average   quality, Below Average  costs) 
- Advocate( Poor   quality, Average  costs) 
exterior: An long one story building with faded paint and with shingled siding with a missing short window. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Average   quality |  Below Average  costs | 
> | Advocate |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Clayden  | Teen  |  Female who is Wounded   | 
>> | Blythe  | Young Adult  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

