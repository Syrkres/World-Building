---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Astrologist 
merchantCategory: Sage
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Card Reader 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Sutton (Teen ) Female who is Fit  
services: 
- Entertainer( Average   quality, Average  costs) 
- Performance( Average   quality, Average  costs) 
exterior: An new building with new paint and with stoned siding with a front tall window that has a sign hanging above with the merchants name. The roof is Ceiling. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Entertainer |  Average   quality |  Average  costs | 
> | Performance |  Average   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Sutton  | Teen  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

