---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chicken Butcher 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Plump Fledgling Chicken 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Weston (Young Adult ) Male who is Scraped up  
- Rutland (Teen ) Male who is Well  
services: 
- Cook( Average   quality, High  costs) 
- Meat Processing( Poor   quality, Above Average  costs) 
exterior: An building with faded paint and with planked siding with a front round window that has a carved sign hanging to the side with the merchants name. The roof is Roof. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Average   quality |  High  costs | 
> | Meat Processing |  Poor   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Weston  | Young Adult  |  Male who is Scraped up   | 
>> | Rutland  | Teen  |  Male who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

