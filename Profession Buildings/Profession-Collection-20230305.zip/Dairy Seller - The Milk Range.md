---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dairy Seller 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: The Milk Range 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Wheatley (Mature Adult ) Male who is Out of sorts  
- Garfield (Teen ) Female who is Fine  
services: 
- Farmer( Average   quality, Below Average  costs) 
- Food( Good   quality, Average  costs) 
exterior: An new narrow one story building with stoned siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Average   quality |  Below Average  costs | 
> | Food |  Good   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Wheatley  | Mature Adult  |  Male who is Out of sorts   | 
>> | Garfield  | Teen  |  Female who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

