---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armorer 
merchantCategory: Forger
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,SMITHY
title: The Gold Scalemail Maker 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Spalding (Teen ) Female who is Ailing  
- Cotton (Teen ) Male who is All Right  
services: 
- Blacksmith( Horrible   quality, Low  costs) 
- Armor Crafting( Horrible   quality, Above Average  costs) 
- Item Crafting( Average   quality, Below Average  costs) 
exterior: An new building with faded paint and with planked siding. The roof is Canopy. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Blacksmith |  Horrible   quality |  Low  costs | 
> | Armor Crafting |  Horrible   quality |  Above Average  costs | 
> | Item Crafting |  Average   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Spalding  | Teen  |  Female who is Ailing   | 
>> | Cotton  | Teen  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

