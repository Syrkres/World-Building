---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Earl 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Earl Stately Home 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Rodney (Child ) Female who is Well  
services: 
- Noble( Low   quality, Low  costs) 
- Diplomacy( Horrible   quality, Above Average  costs) 
- Advise( Horrible   quality, Above Average  costs) 
exterior: An building with stoned siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is Dome. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Noble |  Low   quality |  Low  costs | 
> | Diplomacy |  Horrible   quality |  Above Average  costs | 
> | Advise |  Horrible   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Rodney  | Child  |  Female who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

