---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: ArchDuke 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Hayden's Court 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Noble( Horrible   quality, Below Average  costs) 
- Diplomacy( Low   quality, High  costs) 
- Advise( Low   quality, Average  costs) 
exterior: An old building with new paint and with shingled siding. The roof is Dome. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Noble |  Horrible   quality |  Below Average  costs | 
> | Diplomacy |  Low   quality |  High  costs | 
> | Advise |  Low   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

