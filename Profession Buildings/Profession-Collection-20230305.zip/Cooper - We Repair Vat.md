---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cooper 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We Repair Vat 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Carlyle (Young Adult ) Male who is All Right  
services: 
- Craftsman( Horrible   quality, Low  costs) 
- Toy Making( Average   quality, Above Average  costs) 
- Clock Making( Poor   quality, High  costs) 
- Tinkerer( Low   quality, Average  costs) 
exterior: An building with shingled siding. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Horrible   quality |  Low  costs | 
> | Toy Making |  Average   quality |  Above Average  costs | 
> | Clock Making |  Poor   quality |  High  costs | 
> | Tinkerer |  Low   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Carlyle  | Young Adult  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

