---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dye Makers 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: The Dark Brown Glass Bottle 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Clifton (Young Adult ) Female who is Healthy  
services: 
- Sage( Low   quality, Low  costs) 
- Arcane Research( Good   quality, High  costs) 
- Potion Brewing( Good   quality, High  costs) 
exterior: An new one story building with planked siding. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Low   quality |  Low  costs | 
> | Arcane Research |  Good   quality |  High  costs | 
> | Potion Brewing |  Good   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Clifton  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

