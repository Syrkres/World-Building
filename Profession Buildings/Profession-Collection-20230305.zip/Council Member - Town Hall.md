---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Council Member 
merchantCategory: Elected Official
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Town Hall 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Elected Official( Poor   quality, Average  costs) 
- Diplomacy( Horrible   quality, Average  costs) 
- Advise( Excellent   quality, Above Average  costs) 
exterior: An building with stoned siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Elected Official |  Poor   quality |  Average  costs | 
> | Diplomacy |  Horrible   quality |  Average  costs | 
> | Advise |  Excellent   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

