---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brothel Keeper 
merchantCategory: Hosteler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Great Bucking 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Atherton (Teen ) Female who is Healthy  
- Camden (Adult ) Female who is Fine  
services: 
- Room (Pleasure)( Average   quality, Above Average  costs) 
- Common Room (Sleeping)( Horrible   quality, Average  costs) 
- Room (Meeting)( Good   quality, Below Average  costs) 
exterior: An building with stoned siding. The roof is Ceiling. A Maple pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Room  | Pleasure | ( Average   quality | 
> | Common Room  | Sleeping | ( Horrible   quality | 
> | Room  | Meeting | ( Good   quality | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Atherton  | Teen  |  Female who is Healthy   | 
>> | Camden  | Adult  |  Female who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

