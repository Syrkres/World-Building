---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Buckle Maker 
merchantCategory: Garment Trade
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Rusted Buckle 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Shelby (Teen ) Male who is At death's door  
services: 
- Garment Trade( Poor   quality, Below Average  costs) 
- Crafting( Poor   quality, Below Average  costs) 
exterior: An two story building with stoned siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Poor   quality |  Below Average  costs | 
> | Crafting |  Poor   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Shelby  | Teen  |  Male who is At death's door   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

