---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Captain 
merchantCategory: Guard
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: JAIL
title: The Different Brigantine Bar 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Alston (Young Adult ) Female who is Fine  
- Hayhurst (Young Adult ) Female who is Fit  
services: 
- Mercenary( Horrible   quality, Above Average  costs) 
- Leadership( Average   quality, High  costs) 
exterior: An new building with faded paint and with shingled siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Horrible   quality |  Above Average  costs | 
> | Leadership |  Average   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Alston  | Young Adult  |  Female who is Fine   | 
>> | Hayhurst  | Young Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

