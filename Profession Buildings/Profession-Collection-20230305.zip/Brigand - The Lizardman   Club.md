---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand 
merchantCategory: Criminal
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: JAIL,HOUSE
title: The Lizardman   Club 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Milton (Teen ) Female who is Healthy  
services: 
- Mercenary( Average   quality, Below Average  costs) 
- Enforcement( Poor   quality, Low  costs) 
- Intimidation( Poor   quality, Average  costs) 
exterior: An long one story building with brick siding with a few windows. The roof is Roof. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Average   quality |  Below Average  costs | 
> | Enforcement |  Poor   quality |  Low  costs | 
> | Intimidation |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Milton  | Teen  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

