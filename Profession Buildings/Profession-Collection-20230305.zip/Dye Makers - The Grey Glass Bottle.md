---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dye Makers 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: The Grey Glass Bottle 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Sage( Excellent   quality, Above Average  costs) 
- Arcane Research( Low   quality, High  costs) 
- Potion Brewing( Average   quality, Average  costs) 
exterior: An narrow tall building with faded paint and with planked siding with a missing window. The roof is House. A Yellow Birch shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Excellent   quality |  Above Average  costs | 
> | Arcane Research |  Low   quality |  High  costs | 
> | Potion Brewing |  Average   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

