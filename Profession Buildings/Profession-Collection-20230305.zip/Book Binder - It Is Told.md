---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Book Binder 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,ALCHEMIST
title: It Is Told 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Rodney (Teen ) Male who is Well  
services: 
- Professional Specialties( Horrible   quality, Average  costs) 
- Book Binding( Low   quality, High  costs) 
exterior: An new building with faded paint and with shingled siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Horrible   quality |  Average  costs | 
> | Book Binding |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Rodney  | Teen  |  Male who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

