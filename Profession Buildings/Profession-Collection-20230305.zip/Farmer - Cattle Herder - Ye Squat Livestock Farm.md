---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder 
merchantCategory: Homesteader
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: Ye Squat Livestock Farm 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Sydney (Teen ) Male who is Healthy  
- Winterbourne (Teen ) Male who is Deceased  
services: 
- Farmer( Excellent   quality, Below Average  costs) 
- Food( Poor   quality, Below Average  costs) 
exterior: An narrow tall building with planked siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Excellent   quality |  Below Average  costs | 
> | Food |  Poor   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Sydney  | Teen  |  Male who is Healthy   | 
>> | Winterbourne  | Teen  |  Male who is Deceased   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

