---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bricklayer 
merchantCategory: Construction
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Brick Layer 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Dalton (Adult ) Female who is Fit  
- Spaulding (Teen ) Female who is Healthy  
services: 
- Laborer( Poor   quality, Low  costs) 
exterior: An new building with stoned siding. The roof is Dome. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Laborer |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Dalton  | Adult  |  Female who is Fit   | 
>> | Spaulding  | Teen  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

