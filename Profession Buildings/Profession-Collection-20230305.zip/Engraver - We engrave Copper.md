---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Engraver 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We engrave Copper 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Bradly (Teen ) Male who is Healthy  
- Bradley (Young Adult ) Male who is Unwell  
services: 
- Craftsman( Horrible   quality, Low  costs) 
- Toy Making( Horrible   quality, Above Average  costs) 
- Clock Making( Good   quality, High  costs) 
- Tinkerer( Good   quality, Low  costs) 
exterior: An two story building with planked siding with a missing window. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Horrible   quality |  Low  costs | 
> | Toy Making |  Horrible   quality |  Above Average  costs | 
> | Clock Making |  Good   quality |  High  costs | 
> | Tinkerer |  Good   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Bradly  | Teen  |  Male who is Healthy   | 
>> | Bradley  | Young Adult  |  Male who is Unwell   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

