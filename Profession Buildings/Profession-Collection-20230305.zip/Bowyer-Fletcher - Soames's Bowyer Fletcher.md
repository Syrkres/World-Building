---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bowyer-Fletcher 
merchantCategory: Wood Workers
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Soames's Bowyer Fletcher 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Hornsby (Child ) Female who is Fine  
- Fawcett (Teen ) Male who is Fine  
services: 
- Artisan( Excellent   quality, Average  costs) 
- Wood Carver( Poor   quality, High  costs) 
exterior: An narrow building with faded paint and with brick siding. The roof is Roof. A Cherry pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Artisan |  Excellent   quality |  Average  costs | 
> | Wood Carver |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hornsby  | Child  |  Female who is Fine   | 
>> | Fawcett  | Teen  |  Male who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

