---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Sweeter Side 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Chester (Teen ) Male who is Healthy  
- Kirby (Adult ) Male who is Healthy  
services: 
- Cook( Average   quality, Low  costs) 
- Bread and Pastry Making( Horrible   quality, Low  costs) 
exterior: An tall building with planked siding with a front round window that has a carved sign hanging to the side with the merchants name. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Average   quality |  Low  costs | 
> | Bread and Pastry Making |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Chester  | Teen  |  Male who is Healthy   | 
>> | Kirby  | Adult  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

