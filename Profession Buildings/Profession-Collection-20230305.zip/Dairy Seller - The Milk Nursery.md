---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dairy Seller 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: The Milk Nursery 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Marlowe (Young Adult ) Male who is Dying  
- Sutton (Teen ) Female who is Nauseos  
services: 
- Farmer( Poor   quality, Low  costs) 
- Food( Good   quality, Above Average  costs) 
exterior: An new narrow tall building with brick siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Poor   quality |  Low  costs | 
> | Food |  Good   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Marlowe  | Young Adult  |  Male who is Dying   | 
>> | Sutton  | Teen  |  Female who is Nauseos   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

