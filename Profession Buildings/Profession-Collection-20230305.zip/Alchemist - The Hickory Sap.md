---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Alchemist 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: The Hickory Sap 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Dalton (Teen ) Female who is Healthy  
services: 
- Sage( Good   quality, Average  costs) 
- Arcane Research( Low   quality, High  costs) 
- Potion Brewing( Good   quality, Below Average  costs) 
exterior: An narrow one story building with new paint and with shingled siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Good   quality |  Average  costs | 
> | Arcane Research |  Low   quality |  High  costs | 
> | Potion Brewing |  Good   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Dalton  | Teen  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

