---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Astrologist 
merchantCategory: Sage
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Astrologist 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Benson (Child ) Male who is Hurt  
services: 
- Entertainer( Average   quality, Low  costs) 
- Performance( Good   quality, Below Average  costs) 
exterior: An building with faded paint and with brick siding with a front round shuttered window that has a carved sign hanging to the side with the merchants name. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Entertainer |  Average   quality |  Low  costs | 
> | Performance |  Good   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Benson  | Child  |  Male who is Hurt   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

