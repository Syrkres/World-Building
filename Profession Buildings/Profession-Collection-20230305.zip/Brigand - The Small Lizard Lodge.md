---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand 
merchantCategory: Criminal
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: JAIL,HOUSE
title: The Small Lizard Lodge 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- York (Mature Adult ) Female who is Healthy  
- Rylan (Teen ) Female who is Out of sorts  
services: 
- Mercenary( Poor   quality, Low  costs) 
- Enforcement( Horrible   quality, Average  costs) 
- Intimidation( Horrible   quality, Low  costs) 
exterior: An tall building with stoned siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Poor   quality |  Low  costs | 
> | Enforcement |  Horrible   quality |  Average  costs | 
> | Intimidation |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | York  | Mature Adult  |  Female who is Healthy   | 
>> | Rylan  | Teen  |  Female who is Out of sorts   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

