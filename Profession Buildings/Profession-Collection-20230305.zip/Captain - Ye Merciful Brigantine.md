---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Captain 
merchantCategory: Guard
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: JAIL
title: Ye Merciful Brigantine 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Mercenary( Good   quality, Below Average  costs) 
- Leadership( Poor   quality, Above Average  costs) 
exterior: An new one story building with new paint and with planked siding. The roof is Roof. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Good   quality |  Below Average  costs | 
> | Leadership |  Poor   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

