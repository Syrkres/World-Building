---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barber 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Insane Cuts 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Bradley (Adult ) Female who is Under the weather  
services: 
- Specialty Service( Excellent   quality, Above Average  costs) 
- Surgery( Low   quality, Low  costs) 
exterior: An long tall building with new paint and with stoned siding with a few shuttered windows. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Specialty Service |  Excellent   quality |  Above Average  costs | 
> | Surgery |  Low   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Bradley  | Adult  |  Female who is Under the weather   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

