---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barrel Maker 
merchantCategory: Wood Workers
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The new Yellow Birch barrel Maker 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Deighton (Teen ) Female who is Fit  
services: 
- Craftsman( Good   quality, High  costs) 
- Barrel Crafting( Poor   quality, High  costs) 
exterior: An new tall building with faded paint and with shingled siding with a front short window that has a carved sign hanging to the side with the merchants name. The roof is Ceiling. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Good   quality |  High  costs | 
> | Barrel Crafting |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Deighton  | Teen  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

