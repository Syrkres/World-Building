---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dye Makers 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: The Orange Paint Bottle 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Livingstone (Teen ) Female who is Nauseos  
services: 
- Sage( Good   quality, Average  costs) 
- Arcane Research( Good   quality, Average  costs) 
- Potion Brewing( Good   quality, High  costs) 
exterior: An two story building with faded paint and with stoned siding. The roof is House. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Good   quality |  Average  costs | 
> | Arcane Research |  Good   quality |  Average  costs | 
> | Potion Brewing |  Good   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Livingstone  | Teen  |  Female who is Nauseos   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

