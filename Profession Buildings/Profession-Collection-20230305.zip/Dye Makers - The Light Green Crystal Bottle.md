---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dye Makers 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: The Light Green Crystal Bottle 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Payton (Young Adult ) Male who is Deceased  
- Hampton (Teen ) Male who is Fine  
services: 
- Sage( Average   quality, High  costs) 
- Arcane Research( Poor   quality, Above Average  costs) 
- Potion Brewing( Average   quality, Above Average  costs) 
exterior: An old long tall building with brick siding. The roof is Roof. A Oak shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Average   quality |  High  costs | 
> | Arcane Research |  Poor   quality |  Above Average  costs | 
> | Potion Brewing |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Payton  | Young Adult  |  Male who is Deceased   | 
>> | Hampton  | Teen  |  Male who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

