---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Butcher 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Goat Cutters 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Wilberforce (Adult ) Female who is Expired  
services: 
- Cook( Average   quality, High  costs) 
- Meat Processing( Average   quality, Above Average  costs) 
exterior: An one story building with shingled siding with a few broken windows. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Average   quality |  High  costs | 
> | Meat Processing |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Wilberforce  | Adult  |  Female who is Expired   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

