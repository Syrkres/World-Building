---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer 
merchantCategory: Animal Handler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: TANNERY,FARM,STABLE
title: Pawslance Groomers 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Alby (Teen ) Female who is Healthy  
- Rutland (Young Adult ) Male who is Ailing  
services: 
- Animal Handler( Average   quality, Below Average  costs) 
- Pet Training( Average   quality, Average  costs) 
- Animal Training( Good   quality, Low  costs) 
exterior: An new tall building with stoned siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Average   quality |  Below Average  costs | 
> | Pet Training |  Average   quality |  Average  costs | 
> | Animal Training |  Good   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Alby  | Teen  |  Female who is Healthy   | 
>> | Rutland  | Young Adult  |  Male who is Ailing   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

