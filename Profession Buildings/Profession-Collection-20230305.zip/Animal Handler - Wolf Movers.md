---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Handler 
merchantCategory: Animal Handler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Wolf Movers 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Carlton (Teen ) Female who is Inured  
- Stafford (Teen ) Female who is Deceased  
services: 
- Animal Handler( Poor   quality, Low  costs) 
- Stabler( Average   quality, Average  costs) 
exterior: An new two story building with faded paint and with planked siding with a few boarded windows. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Poor   quality |  Low  costs | 
> | Stabler |  Average   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Carlton  | Teen  |  Female who is Inured   | 
>> | Stafford  | Teen  |  Female who is Deceased   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

