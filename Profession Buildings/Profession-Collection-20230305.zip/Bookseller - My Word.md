---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bookseller 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: My Word 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Craftsman( Poor   quality, Below Average  costs) 
- Toy Making( Horrible   quality, Above Average  costs) 
- Clock Making( Good   quality, Average  costs) 
- Tinkerer( Good   quality, Low  costs) 
exterior: An two story building with planked siding. The roof is Dome. A Maple pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Poor   quality |  Below Average  costs | 
> | Toy Making |  Horrible   quality |  Above Average  costs | 
> | Clock Making |  Good   quality |  Average  costs | 
> | Tinkerer |  Good   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

