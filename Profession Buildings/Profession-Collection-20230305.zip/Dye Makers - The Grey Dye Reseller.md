---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dye Makers 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: The Grey Dye Reseller 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Dryden (Teen ) Male who is Scraped up  
services: 
- Sage( Poor   quality, Average  costs) 
- Arcane Research( Average   quality, Above Average  costs) 
- Potion Brewing( Good   quality, Below Average  costs) 
exterior: An old one story building with new paint and with brick siding with a missing window. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Poor   quality |  Average  costs | 
> | Arcane Research |  Average   quality |  Above Average  costs | 
> | Potion Brewing |  Good   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Dryden  | Teen  |  Male who is Scraped up   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

