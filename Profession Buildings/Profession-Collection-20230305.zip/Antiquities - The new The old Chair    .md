---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,EXOTIC ARTISAN
title: The new The old Chair     
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Alton (Young Adult ) Female who is Healthy as a horse  
- Harley (Adult ) Female who is Healthy  
services: 
- Merchant( Poor   quality, Low  costs) 
- Item Research( Excellent   quality, Low  costs) 
exterior: An new narrow building with shingled siding with a few tall shuttered windows. The roof is House. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Poor   quality |  Low  costs | 
> | Item Research |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Alton  | Young Adult  |  Female who is Healthy as a horse   | 
>> | Harley  | Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

