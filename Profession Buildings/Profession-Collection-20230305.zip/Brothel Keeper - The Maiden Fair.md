---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brothel Keeper 
merchantCategory: Hosteler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Maiden Fair 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Ryley (Young Adult ) Female who is Fine  
services: 
- Room (Pleasure)( Excellent   quality, Below Average  costs) 
- Common Room (Sleeping)( Average   quality, High  costs) 
- Room (Meeting)( Good   quality, Average  costs) 
exterior: An new long building with shingled siding. The roof is House. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Room  | Pleasure | ( Excellent   quality | 
> | Common Room  | Sleeping | ( Average   quality | 
> | Room  | Meeting | ( Good   quality | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Ryley  | Young Adult  |  Female who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

