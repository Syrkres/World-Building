---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Sweet Dough Desserts 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Clinton (Adult ) Female who is Out of sorts  
- Ainsworth (Teen ) Male who is Unwell  
services: 
- Cook( Low   quality, Low  costs) 
- Bread and Pastry Making( Excellent   quality, Below Average  costs) 
exterior: An old building with stoned siding. The roof is House. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Low   quality |  Low  costs | 
> | Bread and Pastry Making |  Excellent   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Clinton  | Adult  |  Female who is Out of sorts   | 
>> | Ainsworth  | Teen  |  Male who is Unwell   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

