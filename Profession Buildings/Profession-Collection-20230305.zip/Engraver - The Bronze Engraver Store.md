---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Engraver 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Bronze Engraver Store 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Kendal (Young Adult ) Female who is Indisposed  
- Asheton (Young Adult ) Female who is Under the weather  
services: 
- Craftsman( Low   quality, Low  costs) 
- Toy Making( Excellent   quality, Below Average  costs) 
- Clock Making( Average   quality, Low  costs) 
- Tinkerer( Poor   quality, Low  costs) 
exterior: An old one story building with new paint and with stoned siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Low   quality |  Low  costs | 
> | Toy Making |  Excellent   quality |  Below Average  costs | 
> | Clock Making |  Average   quality |  Low  costs | 
> | Tinkerer |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Kendal  | Young Adult  |  Female who is Indisposed   | 
>> | Asheton  | Young Adult  |  Female who is Under the weather   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

