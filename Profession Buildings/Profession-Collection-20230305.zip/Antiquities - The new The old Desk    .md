---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,EXOTIC ARTISAN
title: The new The old Desk     
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Blackwood (Young Adult ) Male who is Not oneself  
- Riley (Teen ) Male who is Healthy  
services: 
- Merchant( Good   quality, Low  costs) 
- Item Research( Average   quality, High  costs) 
exterior: An new one story building with faded paint and with stoned siding with a front round window that has a painted sign hanging above with the merchants name. The roof is Ceiling. A Cherry pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Good   quality |  Low  costs | 
> | Item Research |  Average   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Blackwood  | Young Adult  |  Male who is Not oneself   | 
>> | Riley  | Teen  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

