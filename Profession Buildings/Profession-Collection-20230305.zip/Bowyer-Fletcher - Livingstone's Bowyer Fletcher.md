---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bowyer-Fletcher 
merchantCategory: Wood Workers
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Livingstone's Bowyer Fletcher 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Wharton (Adult ) Male who is Nauseos  
- Lincoln (Teen ) Male who is Unwell  
services: 
- Artisan( Average   quality, Below Average  costs) 
- Wood Carver( Horrible   quality, Low  costs) 
exterior: An narrow building with faded paint and with stoned siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Artisan |  Average   quality |  Below Average  costs | 
> | Wood Carver |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Wharton  | Adult  |  Male who is Nauseos   | 
>> | Lincoln  | Teen  |  Male who is Unwell   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

