---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Diplomat 
merchantCategory: Elected Official
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Ye Diplomats Mansion 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Barney (Child ) Male who is Fine  
- Oakes (Young Adult ) Male who is Fit  
services: 
- Professional Specialties( Horrible   quality, Below Average  costs) 
- Advocate( Excellent   quality, Average  costs) 
exterior: An narrow two story building with planked siding with a front short window that has a painted sign hanging above with the merchants name. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Horrible   quality |  Below Average  costs | 
> | Advocate |  Excellent   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Barney  | Child  |  Male who is Fine   | 
>> | Oakes  | Young Adult  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

