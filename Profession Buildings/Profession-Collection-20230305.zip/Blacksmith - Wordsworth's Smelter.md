---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Blacksmith 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,SMITHY
title: Wordsworth's Smelter 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Hayhurst (Teen ) Male who is Healthy  
- Stanley (Teen ) Male who is Healthy  
services: 
- Metal Craftsman( Low   quality, Low  costs) 
- Blacksmithing( Average   quality, Above Average  costs) 
exterior: An old one story building with faded paint and with shingled siding. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Metal Craftsman |  Low   quality |  Low  costs | 
> | Blacksmithing |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hayhurst  | Teen  |  Male who is Healthy   | 
>> | Stanley  | Teen  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

