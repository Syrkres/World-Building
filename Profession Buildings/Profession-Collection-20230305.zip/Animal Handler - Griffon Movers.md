---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Handler 
merchantCategory: Animal Handler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Griffon Movers 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Barton (Teen ) Male who is Deceased  
services: 
- Animal Handler( Good   quality, Average  costs) 
- Stabler( Average   quality, Low  costs) 
exterior: An tall building with new paint and with brick siding. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Good   quality |  Average  costs | 
> | Stabler |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Barton  | Teen  |  Male who is Deceased   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

