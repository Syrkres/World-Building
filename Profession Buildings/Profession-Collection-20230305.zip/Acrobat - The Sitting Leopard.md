---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Acrobat 
merchantCategory: Entertainer
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: THEATER,TAVERN
title: The Sitting Leopard 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Wedgwood (Teen ) Female who is Fine  
services: 
- Entertainer( Low   quality, Low  costs) 
- Performance( Horrible   quality, Low  costs) 
exterior: An old building with faded paint and with planked siding with a missing window. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Entertainer |  Low   quality |  Low  costs | 
> | Performance |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Wedgwood  | Teen  |  Female who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

