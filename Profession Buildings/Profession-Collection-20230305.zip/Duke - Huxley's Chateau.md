---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Duke 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Huxley's Chateau 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Read (Young Adult ) Female who is Fit  
services: 
- Noble( Poor   quality, Above Average  costs) 
- Diplomacy( Low   quality, High  costs) 
- Advise( Excellent   quality, Low  costs) 
exterior: An two story building with new paint and with shingled siding with a front short boarded window that has a painted sign hanging above with the merchants name. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Noble |  Poor   quality |  Above Average  costs | 
> | Diplomacy |  Low   quality |  High  costs | 
> | Advise |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Read  | Young Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

