---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Book Binder 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,ALCHEMIST
title: Hooked On Books 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Benson (Mature Adult ) Male who is Healthy  
- Colton (Young Adult ) Female who is All Right  
services: 
- Professional Specialties( Excellent   quality, Below Average  costs) 
- Book Binding( Good   quality, Low  costs) 
exterior: An long building with shingled siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Excellent   quality |  Below Average  costs | 
> | Book Binding |  Good   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Benson  | Mature Adult  |  Male who is Healthy   | 
>> | Colton  | Young Adult  |  Female who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

