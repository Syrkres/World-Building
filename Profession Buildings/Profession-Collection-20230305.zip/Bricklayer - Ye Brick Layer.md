---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bricklayer 
merchantCategory: Construction
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Ye Brick Layer 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Haley (Adult ) Female who is Healthy  
- Hailey (Teen ) Female who is Deceased  
services: 
- Laborer( Excellent   quality, Low  costs) 
exterior: An long building with faded paint and with brick siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Laborer |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Haley  | Adult  |  Female who is Healthy   | 
>> | Hailey  | Teen  |  Female who is Deceased   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

