---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Buckle Maker 
merchantCategory: Garment Trade
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Silver Clasp 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Burton (Teen ) Male who is Wounded  
- Winthrop (Young Adult ) Female who is All Right  
services: 
- Garment Trade( Average   quality, Average  costs) 
- Crafting( Poor   quality, Average  costs) 
exterior: An old tall building with new paint and with shingled siding with a missing round window. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Average   quality |  Average  costs | 
> | Crafting |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Burton  | Teen  |  Male who is Wounded   | 
>> | Winthrop  | Young Adult  |  Female who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

