---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Distiller 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Happy Hops Beer Co 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Sutherland (Young Adult ) Female who is Healthy  
- Barlow (Teen ) Female who is Ill  
services: 
- Ale Sales( Average   quality, Low  costs) 
exterior: An old building with faded paint and with brick siding with a front window that has a painted sign hanging above with the merchants name. The roof is Canopy. A Oak pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Ale Sales |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Sutherland  | Young Adult  |  Female who is Healthy   | 
>> | Barlow  | Teen  |  Female who is Ill   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

