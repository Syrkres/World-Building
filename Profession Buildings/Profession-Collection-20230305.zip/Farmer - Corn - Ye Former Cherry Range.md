---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Corn 
merchantCategory: Homesteader
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: Ye Former Cherry Range 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Morton (Young Adult ) Female who is Expired  
- Branson (Adult ) Male who is Fit as a fiddle  
services: 
- Farmer( Poor   quality, Low  costs) 
- Food( Low   quality, Low  costs) 
exterior: An building with brick siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Poor   quality |  Low  costs | 
> | Food |  Low   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Morton  | Young Adult  |  Female who is Expired   | 
>> | Branson  | Adult  |  Male who is Fit as a fiddle   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

