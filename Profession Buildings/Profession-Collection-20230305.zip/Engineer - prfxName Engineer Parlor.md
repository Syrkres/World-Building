---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Engineer 
merchantCategory: Construction
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: prfxName Engineer Parlor 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Hastings (Mature Adult ) Female who is Healthy  
- Ogden (Teen ) Male who is Under the weather  
services: 
- Laborer( Excellent   quality, High  costs) 
exterior: An old long tall building with shingled siding. The roof is Roof. A Yellow Birch shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Laborer |  Excellent   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hastings  | Mature Adult  |  Female who is Healthy   | 
>> | Ogden  | Teen  |  Male who is Under the weather   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

