---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bleacher 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The White Dye 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Lester (Teen ) Male who is Healthy  
services: 
- Laborer( Excellent   quality, Above Average  costs) 
- Bleaching( Excellent   quality, Above Average  costs) 
exterior: An one story building with new paint and with planked siding. The roof is Canopy. A Elm shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Laborer |  Excellent   quality |  Above Average  costs | 
> | Bleaching |  Excellent   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Lester  | Teen  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

