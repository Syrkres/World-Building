---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chicken Butcher 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Plump Fowl 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Fulton (Teen ) Female who is Fine  
services: 
- Cook( Low   quality, Average  costs) 
- Meat Processing( Excellent   quality, Below Average  costs) 
exterior: An long building with brick siding with a front round window that has a carved sign hanging to the side with the merchants name. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Low   quality |  Average  costs | 
> | Meat Processing |  Excellent   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Fulton  | Teen  |  Female who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

