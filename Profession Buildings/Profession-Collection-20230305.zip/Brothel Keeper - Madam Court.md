---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brothel Keeper 
merchantCategory: Hosteler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Madam Court 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Wedgwood (Child ) Male who is Hurt  
- Payton (Teen ) Female who is All Right  
services: 
- Room (Pleasure)( Low   quality, Average  costs) 
- Common Room (Sleeping)( Low   quality, Average  costs) 
- Room (Meeting)( Poor   quality, High  costs) 
exterior: An new building with new paint and with planked siding. The roof is Canopy. A Beech pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Room  | Pleasure | ( Low   quality | 
> | Common Room  | Sleeping | ( Low   quality | 
> | Room  | Meeting | ( Poor   quality | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Wedgwood  | Child  |  Male who is Hurt   | 
>> | Payton  | Teen  |  Female who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

