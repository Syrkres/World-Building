---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Blacksmith 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,SMITHY
title: Mithril Armor 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Rylan (Young Adult ) Male who is Under the weather  
- Hampton (Adult ) Female who is Healthy  
services: 
- Metal Craftsman( Good   quality, Low  costs) 
- Blacksmithing( Poor   quality, Below Average  costs) 
exterior: An old tall building with faded paint and with brick siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Metal Craftsman |  Good   quality |  Low  costs | 
> | Blacksmithing |  Poor   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Rylan  | Young Adult  |  Male who is Under the weather   | 
>> | Hampton  | Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

