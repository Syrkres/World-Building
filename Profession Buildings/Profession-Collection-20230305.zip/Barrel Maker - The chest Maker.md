---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barrel Maker 
merchantCategory: Wood Workers
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The chest Maker 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Cromwell (Adult ) Male who is Fit  
services: 
- Craftsman( Horrible   quality, Average  costs) 
- Barrel Crafting( Poor   quality, Average  costs) 
exterior: An tall building with faded paint and with planked siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Horrible   quality |  Average  costs | 
> | Barrel Crafting |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Cromwell  | Adult  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

