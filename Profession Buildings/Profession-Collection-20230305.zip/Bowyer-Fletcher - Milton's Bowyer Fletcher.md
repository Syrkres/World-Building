---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bowyer-Fletcher 
merchantCategory: Wood Workers
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Milton's Bowyer Fletcher 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Webley (Young Adult ) Female who is Healthy  
services: 
- Artisan( Good   quality, Below Average  costs) 
- Wood Carver( Excellent   quality, Above Average  costs) 
exterior: An old building with new paint and with shingled siding with a missing window. The roof is Dome. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Artisan |  Good   quality |  Below Average  costs | 
> | Wood Carver |  Excellent   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Webley  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

