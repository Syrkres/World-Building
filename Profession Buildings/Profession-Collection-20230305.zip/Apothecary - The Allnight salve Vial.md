---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Apothecary 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,ALCHEMIST
title: The Allnight salve Vial 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Elton (Young Adult ) Male who is Dead  
services: 
- Professional Specialties( Excellent   quality, Above Average  costs) 
- Healing( Low   quality, Low  costs) 
- Potion Brewing( Excellent   quality, High  costs) 
- Remedy Crafting( Low   quality, High  costs) 
exterior: An two story building with planked siding with a missing round window. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Excellent   quality |  Above Average  costs | 
> | Healing |  Low   quality |  Low  costs | 
> | Potion Brewing |  Excellent   quality |  High  costs | 
> | Remedy Crafting |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Elton  | Young Adult  |  Male who is Dead   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

