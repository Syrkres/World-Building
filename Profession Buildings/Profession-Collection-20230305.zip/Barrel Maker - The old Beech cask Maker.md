---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barrel Maker 
merchantCategory: Wood Workers
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The old Beech cask Maker 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Rutherford (Mature Adult ) Male who is Healthy  
- Blythe (Young Adult ) Female who is Fit  
services: 
- Craftsman( Low   quality, Average  costs) 
- Barrel Crafting( Excellent   quality, High  costs) 
exterior: An new tall building with shingled siding with a few broken windows. The roof is House. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Low   quality |  Average  costs | 
> | Barrel Crafting |  Excellent   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Rutherford  | Mature Adult  |  Male who is Healthy   | 
>> | Blythe  | Young Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

