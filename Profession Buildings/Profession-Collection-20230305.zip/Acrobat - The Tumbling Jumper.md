---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Acrobat 
merchantCategory: Entertainer
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: THEATER,TAVERN
title: The Tumbling Jumper 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Tyndall (Young Adult ) Male who is Maimed  
services: 
- Entertainer( Good   quality, High  costs) 
- Performance( Average   quality, Above Average  costs) 
exterior: An new two story building with shingled siding. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Entertainer |  Good   quality |  High  costs | 
> | Performance |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Tyndall  | Young Adult  |  Male who is Maimed   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

