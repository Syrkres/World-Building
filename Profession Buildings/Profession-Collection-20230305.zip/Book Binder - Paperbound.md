---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Book Binder 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,ALCHEMIST
title: Paperbound 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Bing (Teen ) Female who is Fit  
- Benson (Teen ) Female who is Healthy  
services: 
- Professional Specialties( Poor   quality, Low  costs) 
- Book Binding( Average   quality, Low  costs) 
exterior: An new long one story building with new paint and with stoned siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Poor   quality |  Low  costs | 
> | Book Binding |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Bing  | Teen  |  Female who is Fit   | 
>> | Benson  | Teen  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

