---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Duke 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Barton's Manor 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Rodney (Young Adult ) Female who is Healthy  
services: 
- Noble( Good   quality, Low  costs) 
- Diplomacy( Low   quality, Above Average  costs) 
- Advise( Good   quality, Average  costs) 
exterior: An building with new paint and with stoned siding with a few shuttered windows. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Noble |  Good   quality |  Low  costs | 
> | Diplomacy |  Low   quality |  Above Average  costs | 
> | Advise |  Good   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Rodney  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

