---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand 
merchantCategory: Criminal
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: JAIL,HOUSE
title: The Lizardman   Cottage 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Mercenary( Excellent   quality, Low  costs) 
- Enforcement( Average   quality, Above Average  costs) 
- Intimidation( Excellent   quality, Below Average  costs) 
exterior: An old building with planked siding with a few shuttered windows. The roof is Ceiling. A Beech shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Excellent   quality |  Low  costs | 
> | Enforcement |  Average   quality |  Above Average  costs | 
> | Intimidation |  Excellent   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

