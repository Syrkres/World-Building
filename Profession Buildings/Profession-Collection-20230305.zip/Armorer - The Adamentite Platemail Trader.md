---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armorer 
merchantCategory: Forger
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,SMITHY
title: The Adamentite Platemail Trader 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Denholm (Young Adult ) Female who is Healthy  
- Stansfield (Teen ) Male who is Ill  
services: 
- Blacksmith( Good   quality, Low  costs) 
- Armor Crafting( Poor   quality, Above Average  costs) 
- Item Crafting( Horrible   quality, Low  costs) 
exterior: An long building with shingled siding with a few short boarded windows. The roof is House. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Blacksmith |  Good   quality |  Low  costs | 
> | Armor Crafting |  Poor   quality |  Above Average  costs | 
> | Item Crafting |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Denholm  | Young Adult  |  Female who is Healthy   | 
>> | Stansfield  | Teen  |  Male who is Ill   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

