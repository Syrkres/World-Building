---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Candle Maker 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Ye Candle 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Ramsay (Mature Adult ) Male who is Healthy  
- Whitby (Young Adult ) Female who is Healthy  
services: 
- Specialty Service( Poor   quality, Average  costs) 
- Candle Making( Poor   quality, High  costs) 
exterior: An building with shingled siding. The roof is Ceiling. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Specialty Service |  Poor   quality |  Average  costs | 
> | Candle Making |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Ramsay  | Mature Adult  |  Male who is Healthy   | 
>> | Whitby  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

