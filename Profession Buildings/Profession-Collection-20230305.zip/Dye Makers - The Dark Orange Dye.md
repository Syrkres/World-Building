---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dye Makers 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: The Dark Orange Dye 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Bing (Young Adult ) Male who is All Right  
services: 
- Sage( Horrible   quality, Below Average  costs) 
- Arcane Research( Low   quality, Average  costs) 
- Potion Brewing( Average   quality, Below Average  costs) 
exterior: An new long two story building with faded paint and with planked siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Horrible   quality |  Below Average  costs | 
> | Arcane Research |  Low   quality |  Average  costs | 
> | Potion Brewing |  Average   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Bing  | Young Adult  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

