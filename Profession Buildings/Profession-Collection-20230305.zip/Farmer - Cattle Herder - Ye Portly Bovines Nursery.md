---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder 
merchantCategory: Homesteader
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: Ye Portly Bovines Nursery 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Asheton (Teen ) Female who is Healthy  
- Wakefield (Child ) Male who is Sick  
services: 
- Farmer( Poor   quality, Low  costs) 
- Food( Low   quality, Low  costs) 
exterior: An building with shingled siding with a few round boarded windows. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Poor   quality |  Low  costs | 
> | Food |  Low   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Asheton  | Teen  |  Female who is Healthy   | 
>> | Wakefield  | Child  |  Male who is Sick   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

