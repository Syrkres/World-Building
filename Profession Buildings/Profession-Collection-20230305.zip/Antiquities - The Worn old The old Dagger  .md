---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,EXOTIC ARTISAN
title: The Worn old The old Dagger   
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Hayley (Teen ) Male who is Impaired  
- Ramsey (Adult ) Female who is Deceased  
services: 
- Merchant( Good   quality, Above Average  costs) 
- Item Research( Poor   quality, High  costs) 
exterior: An new building with shingled siding with a few boarded windows. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Good   quality |  Above Average  costs | 
> | Item Research |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hayley  | Teen  |  Male who is Impaired   | 
>> | Ramsey  | Adult  |  Female who is Deceased   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

