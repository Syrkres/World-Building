---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bather 
merchantCategory: Specialty Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Cool soak shop 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Thorpe (Teen ) Female who is Fit as a fiddle  
- Colby (Mature Adult ) Male who is Fine  
services: 
- Specialty Service( Low   quality, High  costs) 
- Wash( Excellent   quality, High  costs) 
exterior: An tall building with faded paint and with shingled siding with a front short shuttered window that has a carved sign hanging to the side with the merchants name. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Specialty Service |  Low   quality |  High  costs | 
> | Wash |  Excellent   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Thorpe  | Teen  |  Female who is Fit as a fiddle   | 
>> | Colby  | Mature Adult  |  Male who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

