---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brothel Keeper 
merchantCategory: Hosteler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Aunt Fannies Bloomers 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Room (Pleasure)( Good   quality, Above Average  costs) 
- Common Room (Sleeping)( Excellent   quality, Average  costs) 
- Room (Meeting)( Excellent   quality, Above Average  costs) 
exterior: An old building with shingled siding with a missing window. The roof is Ceiling. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Room  | Pleasure | ( Good   quality | 
> | Common Room  | Sleeping | ( Excellent   quality | 
> | Room  | Meeting | ( Excellent   quality | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

