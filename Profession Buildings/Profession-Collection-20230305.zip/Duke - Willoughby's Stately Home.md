---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Duke 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Willoughby's Stately Home 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Churchill (Mature Adult ) Female who is Healthy  
- Enfield (Teen ) Male who is Incapacitaed  
services: 
- Noble( Good   quality, Average  costs) 
- Diplomacy( Good   quality, High  costs) 
- Advise( Poor   quality, High  costs) 
exterior: An new building with shingled siding. The roof is Dome. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Noble |  Good   quality |  Average  costs | 
> | Diplomacy |  Good   quality |  High  costs | 
> | Advise |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Churchill  | Mature Adult  |  Female who is Healthy   | 
>> | Enfield  | Teen  |  Male who is Incapacitaed   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

