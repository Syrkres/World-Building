---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric 
merchantCategory: Clergy
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHRINE,HOUSE
title: Shrine of the Depressed 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Churchill (Young Adult ) Male who is Sick  
- Crawford (Young Adult ) Female who is All Right  
services: 
- Clergy( Poor   quality, Below Average  costs) 
- Religion( Excellent   quality, Below Average  costs) 
- House of Worship( Horrible   quality, Above Average  costs) 
- Curse Removal( Excellent   quality, High  costs) 
- Spell Research( Low   quality, Below Average  costs) 
- Healing( Horrible   quality, Average  costs) 
- Potions( Horrible   quality, Average  costs) 
exterior: An one story building with planked siding. The roof is Dome. A Cherry pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Poor   quality |  Below Average  costs | 
> | Religion |  Excellent   quality |  Below Average  costs | 
> | House of Worship |  Horrible   quality |  Above Average  costs | 
> | Curse Removal |  Excellent   quality |  High  costs | 
> | Spell Research |  Low   quality |  Below Average  costs | 
> | Healing |  Horrible   quality |  Average  costs | 
> | Potions |  Horrible   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Churchill  | Young Adult  |  Male who is Sick   | 
>> | Crawford  | Young Adult  |  Female who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

