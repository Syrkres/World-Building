---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Butcher 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We Butcher Rabbit 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Blankley (Young Adult ) Male who is Ailing  
- Eastoft (Mature Adult ) Female who is Healthy  
services: 
- Cook( Excellent   quality, Above Average  costs) 
- Meat Processing( Horrible   quality, Low  costs) 
exterior: An new building with brick siding. The roof is Canopy. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Excellent   quality |  Above Average  costs | 
> | Meat Processing |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Blankley  | Young Adult  |  Male who is Ailing   | 
>> | Eastoft  | Mature Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

