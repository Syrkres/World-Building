---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Artist 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: prfxName Art Reseller 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Rutland (Teen ) Female who is Inured  
services: 
- Craftsman( Horrible   quality, Average  costs) 
- Glass Blowing( Poor   quality, Above Average  costs) 
exterior: An new tall building with new paint and with planked siding with a front short shuttered window that has a sign hanging above with the merchants name. The roof is House. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Horrible   quality |  Average  costs | 
> | Glass Blowing |  Poor   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Rutland  | Teen  |  Female who is Inured   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

