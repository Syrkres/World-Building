---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric 
merchantCategory: Clergy
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHRINE,HOUSE
title: Sanctuary of the Manticore 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Eastoft (Teen ) Female who is Healthy  
services: 
- Clergy( Low   quality, Average  costs) 
- Religion( Good   quality, Above Average  costs) 
- House of Worship( Poor   quality, High  costs) 
- Curse Removal( Good   quality, Above Average  costs) 
- Spell Research( Poor   quality, Below Average  costs) 
- Healing( Low   quality, Above Average  costs) 
- Potions( Average   quality, Low  costs) 
exterior: An narrow two story building with faded paint and with shingled siding. The roof is Canopy. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Low   quality |  Average  costs | 
> | Religion |  Good   quality |  Above Average  costs | 
> | House of Worship |  Poor   quality |  High  costs | 
> | Curse Removal |  Good   quality |  Above Average  costs | 
> | Spell Research |  Poor   quality |  Below Average  costs | 
> | Healing |  Low   quality |  Above Average  costs | 
> | Potions |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Eastoft  | Teen  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

