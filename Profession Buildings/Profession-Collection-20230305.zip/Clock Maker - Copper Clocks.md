---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Clock Maker 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Copper Clocks 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Davenport (Teen ) Male who is Impaired  
- Haley (Teen ) Male who is Healthy  
services: 
- Craftsman( Average   quality, Below Average  costs) 
- Toy Making( Excellent   quality, Above Average  costs) 
- Clock Making( Low   quality, Average  costs) 
- Tinkerer( Poor   quality, Average  costs) 
exterior: An narrow building with shingled siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Average   quality |  Below Average  costs | 
> | Toy Making |  Excellent   quality |  Above Average  costs | 
> | Clock Making |  Low   quality |  Average  costs | 
> | Tinkerer |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Davenport  | Teen  |  Male who is Impaired   | 
>> | Haley  | Teen  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

