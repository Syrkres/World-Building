---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Artist 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: prfxName Art Shop 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Shelly (Adult ) Female who is Healthy  
services: 
- Craftsman( Horrible   quality, Average  costs) 
- Glass Blowing( Poor   quality, Above Average  costs) 
exterior: An old building with faded paint and with stoned siding. The roof is Roof. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Horrible   quality |  Average  costs | 
> | Glass Blowing |  Poor   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Shelly  | Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

