---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder 
merchantCategory: Homesteader
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: Ye Plump Livestock Range 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Sherwood (Young Adult ) Male who is Nauseos  
- Gresham (Teen ) Female who is Expired  
services: 
- Farmer( Average   quality, Low  costs) 
- Food( Good   quality, Low  costs) 
exterior: An new narrow tall building with planked siding. The roof is Ceiling. A Ceder shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Average   quality |  Low  costs | 
> | Food |  Good   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Sherwood  | Young Adult  |  Male who is Nauseos   | 
>> | Gresham  | Teen  |  Female who is Expired   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

