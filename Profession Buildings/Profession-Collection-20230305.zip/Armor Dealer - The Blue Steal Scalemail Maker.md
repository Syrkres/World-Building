---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armor Dealer 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,SMITHY
title: The Blue Steal Scalemail Maker 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Merchant( Horrible   quality, High  costs) 
- Armor Crafting( Poor   quality, Low  costs) 
exterior: An old building with brick siding. The roof is Ceiling. A Elm shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Horrible   quality |  High  costs | 
> | Armor Crafting |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

