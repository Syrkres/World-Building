---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer 
merchantCategory: Animal Handler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: TANNERY,FARM,STABLE
title: Paws Clean Ahead 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Stafford (Teen ) Female who is Fit  
services: 
- Animal Handler( Good   quality, Low  costs) 
- Pet Training( Horrible   quality, Average  costs) 
- Animal Training( Low   quality, Below Average  costs) 
exterior: An old tall building with shingled siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Good   quality |  Low  costs | 
> | Pet Training |  Horrible   quality |  Average  costs | 
> | Animal Training |  Low   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Stafford  | Teen  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

