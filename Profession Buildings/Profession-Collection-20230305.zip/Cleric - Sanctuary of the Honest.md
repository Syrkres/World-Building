---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric 
merchantCategory: Clergy
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHRINE,HOUSE
title: Sanctuary of the Honest 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Asheton (Teen ) Female who is Well  
- Kirby (Teen ) Male who is All Right  
services: 
- Clergy( Poor   quality, Below Average  costs) 
- Religion( Average   quality, Below Average  costs) 
- House of Worship( Average   quality, Average  costs) 
- Curse Removal( Poor   quality, Low  costs) 
- Spell Research( Good   quality, Average  costs) 
- Healing( Low   quality, High  costs) 
- Potions( Good   quality, Below Average  costs) 
exterior: An building with planked siding. The roof is Dome. A Red Oak shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Poor   quality |  Below Average  costs | 
> | Religion |  Average   quality |  Below Average  costs | 
> | House of Worship |  Average   quality |  Average  costs | 
> | Curse Removal |  Poor   quality |  Low  costs | 
> | Spell Research |  Good   quality |  Average  costs | 
> | Healing |  Low   quality |  High  costs | 
> | Potions |  Good   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Asheton  | Teen  |  Female who is Well   | 
>> | Kirby  | Teen  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

