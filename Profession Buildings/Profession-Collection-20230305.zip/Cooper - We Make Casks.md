---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cooper 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We Make Casks 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Oakes (Adult ) Female who is Healthy  
services: 
- Craftsman( Low   quality, High  costs) 
- Toy Making( Good   quality, Average  costs) 
- Clock Making( Low   quality, Above Average  costs) 
- Tinkerer( Poor   quality, Low  costs) 
exterior: An new two story building with shingled siding with a missing round window. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Low   quality |  High  costs | 
> | Toy Making |  Good   quality |  Average  costs | 
> | Clock Making |  Low   quality |  Above Average  costs | 
> | Tinkerer |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Oakes  | Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

