---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Corn 
merchantCategory: Homesteader
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: FARM,HOUSE
title: Ye Tall Indian Corn Range 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Livingstone (Teen ) Female who is Maimed  
services: 
- Farmer( Horrible   quality, Below Average  costs) 
- Food( Poor   quality, Average  costs) 
exterior: An new one story building with planked siding with a front shuttered window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Horrible   quality |  Below Average  costs | 
> | Food |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Livingstone  | Teen  |  Female who is Maimed   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

