---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,EXOTIC ARTISAN
title: The new The new Desk     
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Thackeray (Teen ) Female who is Well  
services: 
- Merchant( Excellent   quality, Low  costs) 
- Item Research( Poor   quality, Low  costs) 
exterior: An narrow building with stoned siding. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Excellent   quality |  Low  costs | 
> | Item Research |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Thackeray  | Teen  |  Female who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

