---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Beer Merchant 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Cold Craft 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Bing (Adult ) Female who is Fit  
- Sutton (Adult ) Female who is Sick  
services: 
- Ale Sales( Average   quality, Low  costs) 
exterior: An old long one story building with new paint and with brick siding with a missing tall window. The roof is House. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Ale Sales |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Bing  | Adult  |  Female who is Fit   | 
>> | Sutton  | Adult  |  Female who is Sick   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

