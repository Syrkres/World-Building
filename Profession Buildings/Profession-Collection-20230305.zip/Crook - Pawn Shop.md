---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crook 
merchantCategory: Criminal
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Pawn Shop 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Copeland (Teen ) Male who is At death's door  
- Tyndall (Teen ) Male who is All Right  
services: 
- Criminal( Excellent   quality, High  costs) 
- Deception( Average   quality, High  costs) 
- Theft( Low   quality, High  costs) 
exterior: An one story building with planked siding. The roof is Dome. A Oak shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Criminal |  Excellent   quality |  High  costs | 
> | Deception |  Average   quality |  High  costs | 
> | Theft |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Copeland  | Teen  |  Male who is At death's door   | 
>> | Tyndall  | Teen  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

