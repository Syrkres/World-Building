---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chandler 
merchantCategory: Chandler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Smooth Soap 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Bentley (Adult ) Female who is Healthy  
- Allerton (Child ) Female who is Healthy  
services: 
- Merchant( Low   quality, Above Average  costs) 
- Boat/Ship Merchant( Good   quality, Average  costs) 
exterior: An old building with faded paint and with shingled siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Low   quality |  Above Average  costs | 
> | Boat/Ship Merchant |  Good   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Bentley  | Adult  |  Female who is Healthy   | 
>> | Allerton  | Child  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

