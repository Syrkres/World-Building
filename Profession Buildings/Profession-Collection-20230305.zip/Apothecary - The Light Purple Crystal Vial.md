---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Apothecary 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,ALCHEMIST
title: The Light Purple Crystal Vial 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Hartford (Teen ) Male who is Expired  
- Clifton (Mature Adult ) Female who is Fit  
services: 
- Professional Specialties( Low   quality, Average  costs) 
- Healing( Low   quality, Below Average  costs) 
- Potion Brewing( Average   quality, High  costs) 
- Remedy Crafting( Low   quality, High  costs) 
exterior: An long one story building with faded paint and with shingled siding with a few shuttered windows. The roof is Ceiling. A Beech shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Low   quality |  Average  costs | 
> | Healing |  Low   quality |  Below Average  costs | 
> | Potion Brewing |  Average   quality |  High  costs | 
> | Remedy Crafting |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hartford  | Teen  |  Male who is Expired   | 
>> | Clifton  | Mature Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

