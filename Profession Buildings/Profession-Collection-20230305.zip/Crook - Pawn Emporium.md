---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crook 
merchantCategory: Criminal
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Pawn Emporium 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Ashton (Teen ) Male who is Deceased  
services: 
- Criminal( Horrible   quality, Below Average  costs) 
- Deception( Poor   quality, Average  costs) 
- Theft( Average   quality, Low  costs) 
exterior: An old building with faded paint and with planked siding with a missing window. The roof is Dome. A Maple shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Criminal |  Horrible   quality |  Below Average  costs | 
> | Deception |  Poor   quality |  Average  costs | 
> | Theft |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Ashton  | Teen  |  Male who is Deceased   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

