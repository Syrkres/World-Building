---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Bake Love, Not War 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Brady (Young Adult ) Female who is Dying  
services: 
- Cook( Excellent   quality, Below Average  costs) 
- Bread and Pastry Making( Excellent   quality, Above Average  costs) 
exterior: An old narrow building with faded paint and with planked siding. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Excellent   quality |  Below Average  costs | 
> | Bread and Pastry Making |  Excellent   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Brady  | Young Adult  |  Female who is Dying   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

