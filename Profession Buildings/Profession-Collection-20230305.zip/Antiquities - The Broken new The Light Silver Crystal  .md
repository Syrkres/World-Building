---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,EXOTIC ARTISAN
title: The Broken new The Light Silver Crystal   
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Haley (Teen ) Female who is Dead  
- Windsor (Mature Adult ) Female who is Healthy  
services: 
- Merchant( Average   quality, High  costs) 
- Item Research( Good   quality, Average  costs) 
exterior: An tall building with new paint and with shingled siding. The roof is Roof. A Yellow Birch pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Average   quality |  High  costs | 
> | Item Research |  Good   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Haley  | Teen  |  Female who is Dead   | 
>> | Windsor  | Mature Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

