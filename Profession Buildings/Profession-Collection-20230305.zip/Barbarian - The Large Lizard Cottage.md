---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian 
merchantCategory: Tracker
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,STABLE
title: The Large Lizard Cottage 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Breeden (Teen ) Female who is All Right  
- Garrick (Teen ) Male who is Healthy  
services: 
- Mercenary( Horrible   quality, Average  costs) 
- Tracking( Average   quality, Low  costs) 
exterior: An one story building with new paint and with brick siding with a missing tall window. The roof is Ceiling. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Horrible   quality |  Average  costs | 
> | Tracking |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Breeden  | Teen  |  Female who is All Right   | 
>> | Garrick  | Teen  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

