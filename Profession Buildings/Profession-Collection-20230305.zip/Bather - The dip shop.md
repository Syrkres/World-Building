---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bather 
merchantCategory: Specialty Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The dip shop 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Merton (Adult ) Female who is Healthy  
- Bentley (Young Adult ) Female who is Healthy  
services: 
- Specialty Service( Low   quality, Low  costs) 
- Wash( Good   quality, Above Average  costs) 
exterior: An new long building with new paint and with brick siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Specialty Service |  Low   quality |  Low  costs | 
> | Wash |  Good   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Merton  | Adult  |  Female who is Healthy   | 
>> | Bentley  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

