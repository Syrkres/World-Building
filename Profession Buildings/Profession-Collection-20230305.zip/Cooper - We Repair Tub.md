---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cooper 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We Repair Tub 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Warwick (Adult ) Male who is All Right  
services: 
- Craftsman( Low   quality, Above Average  costs) 
- Toy Making( Low   quality, Below Average  costs) 
- Clock Making( Horrible   quality, Low  costs) 
- Tinkerer( Horrible   quality, Below Average  costs) 
exterior: An building with shingled siding with a few shuttered windows. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Low   quality |  Above Average  costs | 
> | Toy Making |  Low   quality |  Below Average  costs | 
> | Clock Making |  Horrible   quality |  Low  costs | 
> | Tinkerer |  Horrible   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Warwick  | Adult  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

