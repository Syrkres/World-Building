---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer 
merchantCategory: Animal Handler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: TANNERY,FARM,STABLE
title: Handsome Pooches 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Clayden (Teen ) Female who is Unwell  
services: 
- Animal Handler( Good   quality, High  costs) 
- Pet Training( Good   quality, High  costs) 
- Animal Training( Good   quality, Above Average  costs) 
exterior: An long building with faded paint and with planked siding with a few short broken windows. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Good   quality |  High  costs | 
> | Pet Training |  Good   quality |  High  costs | 
> | Animal Training |  Good   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Clayden  | Teen  |  Female who is Unwell   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

