---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Engraver 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We engrave Gold 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Sutton (Teen ) Male who is Healthy  
services: 
- Craftsman( Average   quality, High  costs) 
- Toy Making( Low   quality, Above Average  costs) 
- Clock Making( Poor   quality, Average  costs) 
- Tinkerer( Excellent   quality, Above Average  costs) 
exterior: An tall building with faded paint and with planked siding with a missing short window. The roof is House. A Beech pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Average   quality |  High  costs | 
> | Toy Making |  Low   quality |  Above Average  costs | 
> | Clock Making |  Poor   quality |  Average  costs | 
> | Tinkerer |  Excellent   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Sutton  | Teen  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

