---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Beer Merchant 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Barrel Fresh Beer 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Anderton (Young Adult ) Female who is Fit  
services: 
- Ale Sales( Excellent   quality, Average  costs) 
exterior: An new building with planked siding with a front tall window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. A Oak pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Ale Sales |  Excellent   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Anderton  | Young Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

