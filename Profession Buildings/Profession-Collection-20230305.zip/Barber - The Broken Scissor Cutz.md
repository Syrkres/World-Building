---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barber 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Broken Scissor Cutz 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Specialty Service( Good   quality, Low  costs) 
- Surgery( Poor   quality, High  costs) 
exterior: An narrow tall building with stoned siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Specialty Service |  Good   quality |  Low  costs | 
> | Surgery |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

