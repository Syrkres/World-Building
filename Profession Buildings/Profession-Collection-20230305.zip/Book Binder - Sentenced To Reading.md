---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Book Binder 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,ALCHEMIST
title: Sentenced To Reading 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Perry (Young Adult ) Male who is All Right  
- Ridley (Teen ) Female who is Well  
services: 
- Professional Specialties( Good   quality, High  costs) 
- Book Binding( Average   quality, Average  costs) 
exterior: An tall building with faded paint and with brick siding with a few round windows. The roof is Roof. A Beech shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Good   quality |  High  costs | 
> | Book Binding |  Average   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Perry  | Young Adult  |  Male who is All Right   | 
>> | Ridley  | Teen  |  Female who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

