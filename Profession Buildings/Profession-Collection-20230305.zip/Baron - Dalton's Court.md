---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baron 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Dalton's Court 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Roscoe (Teen ) Female who is Nauseos  
services: 
- Diplomacy( Good   quality, High  costs) 
exterior: An tall building with shingled siding. The roof is Ceiling. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Diplomacy |  Good   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Roscoe  | Teen  |  Female who is Nauseos   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

