---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bowyer-Fletcher 
merchantCategory: Wood Workers
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Blackwood's Bowyer Fletcher 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Lindsay (Adult ) Male who is Healthy  
- Atterton (Adult ) Female who is Maimed  
services: 
- Artisan( Low   quality, Above Average  costs) 
- Wood Carver( Good   quality, Low  costs) 
exterior: An old narrow building with faded paint and with shingled siding. The roof is Canopy. A Beech pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Artisan |  Low   quality |  Above Average  costs | 
> | Wood Carver |  Good   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Lindsay  | Adult  |  Male who is Healthy   | 
>> | Atterton  | Adult  |  Female who is Maimed   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

