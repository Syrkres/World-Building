---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crime Lord 
merchantCategory: Criminal
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Ye Black Manual 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Anderton (Young Adult ) Male who is Ailing  
- Oakes (Young Adult ) Female who is Healthy  
services: 
- Blackmarket( Excellent   quality, Above Average  costs) 
- Merchant( Excellent   quality, Low  costs) 
- Transfer of Goods( Poor   quality, Above Average  costs) 
exterior: An tall building with new paint and with shingled siding with a missing window. The roof is Canopy. A Red Oak shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Blackmarket |  Excellent   quality |  Above Average  costs | 
> | Merchant |  Excellent   quality |  Low  costs | 
> | Transfer of Goods |  Poor   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Anderton  | Young Adult  |  Male who is Ailing   | 
>> | Oakes  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

