---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Draper 
merchantCategory: Garment Trade
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Clothes Trader 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Beverly (Teen ) Male who is All Right  
- Willoughby (Adult ) Female who is Healthy  
services: 
- Garment Trade( Average   quality, Above Average  costs) 
- Trader( Horrible   quality, Average  costs) 
exterior: An long building with faded paint and with shingled siding. The roof is Canopy. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Average   quality |  Above Average  costs | 
> | Trader |  Horrible   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Beverly  | Teen  |  Male who is All Right   | 
>> | Willoughby  | Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

