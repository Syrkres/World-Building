---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bleacher 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Textile Bleaching 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Stanford (Mature Adult ) Male who is Fine  
- Clayden (Young Adult ) Male who is Healthy  
services: 
- Laborer( Good   quality, High  costs) 
- Bleaching( Horrible   quality, Low  costs) 
exterior: An old building with new paint and with brick siding with a front short window that has a carved sign hanging to the side with the merchants name. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Laborer |  Good   quality |  High  costs | 
> | Bleaching |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Stanford  | Mature Adult  |  Male who is Fine   | 
>> | Clayden  | Young Adult  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

