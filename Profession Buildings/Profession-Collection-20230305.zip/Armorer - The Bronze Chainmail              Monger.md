---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armorer 
merchantCategory: Forger
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,SMITHY
title: The Bronze Chainmail              Monger 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Cumberbatch (Adult ) Male who is Healthy  
- Enfield (Teen ) Female who is Ailing  
services: 
- Blacksmith( Low   quality, Average  costs) 
- Armor Crafting( Good   quality, Low  costs) 
- Item Crafting( Poor   quality, Low  costs) 
exterior: An new long building with new paint and with planked siding with a few round windows. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Blacksmith |  Low   quality |  Average  costs | 
> | Armor Crafting |  Good   quality |  Low  costs | 
> | Item Crafting |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Cumberbatch  | Adult  |  Male who is Healthy   | 
>> | Enfield  | Teen  |  Female who is Ailing   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

