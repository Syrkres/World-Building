---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Clock Maker 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We build Copper Clocks 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Eastoft (Teen ) Female who is Healthy  
- Yorke (Adult ) Male who is Well  
services: 
- Craftsman( Average   quality, Below Average  costs) 
- Toy Making( Good   quality, Low  costs) 
- Clock Making( Horrible   quality, High  costs) 
- Tinkerer( Horrible   quality, Average  costs) 
exterior: An tall building with new paint and with planked siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Average   quality |  Below Average  costs | 
> | Toy Making |  Good   quality |  Low  costs | 
> | Clock Making |  Horrible   quality |  High  costs | 
> | Tinkerer |  Horrible   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Eastoft  | Teen  |  Female who is Healthy   | 
>> | Yorke  | Adult  |  Male who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

