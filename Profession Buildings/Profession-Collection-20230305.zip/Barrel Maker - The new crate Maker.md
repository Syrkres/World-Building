---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barrel Maker 
merchantCategory: Wood Workers
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The new crate Maker 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Read (Child ) Female who is Ill  
- Walcott (Young Adult ) Female who is All Right  
services: 
- Craftsman( Horrible   quality, Low  costs) 
- Barrel Crafting( Poor   quality, Average  costs) 
exterior: An tall building with faded paint and with brick siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Horrible   quality |  Low  costs | 
> | Barrel Crafting |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Read  | Child  |  Female who is Ill   | 
>> | Walcott  | Young Adult  |  Female who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

