---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Engraver 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Ye Mithril Engraver Reseller 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Dryden (Young Adult ) Female who is Sick  
services: 
- Craftsman( Poor   quality, Low  costs) 
- Toy Making( Horrible   quality, High  costs) 
- Clock Making( Average   quality, Below Average  costs) 
- Tinkerer( Poor   quality, High  costs) 
exterior: An new long two story building with faded paint and with brick siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Poor   quality |  Low  costs | 
> | Toy Making |  Horrible   quality |  High  costs | 
> | Clock Making |  Average   quality |  Below Average  costs | 
> | Tinkerer |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Dryden  | Young Adult  |  Female who is Sick   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

