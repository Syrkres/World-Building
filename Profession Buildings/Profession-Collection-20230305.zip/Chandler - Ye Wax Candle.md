---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chandler 
merchantCategory: Chandler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Ye Wax Candle 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Barton (Teen ) Female who is Hurt  
services: 
- Merchant( Good   quality, Low  costs) 
- Boat/Ship Merchant( Average   quality, Below Average  costs) 
exterior: An building with new paint and with brick siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Good   quality |  Low  costs | 
> | Boat/Ship Merchant |  Average   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Barton  | Teen  |  Female who is Hurt   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

