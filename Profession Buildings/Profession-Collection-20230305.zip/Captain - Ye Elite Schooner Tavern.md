---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Captain 
merchantCategory: Guard
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: JAIL
title: Ye Elite Schooner Tavern 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Mercenary( Poor   quality, Low  costs) 
- Leadership( Low   quality, Low  costs) 
exterior: An new building with stoned siding. The roof is Dome. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Poor   quality |  Low  costs | 
> | Leadership |  Low   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

