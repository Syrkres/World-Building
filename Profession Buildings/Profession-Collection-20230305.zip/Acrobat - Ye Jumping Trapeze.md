---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Acrobat 
merchantCategory: Entertainer
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: THEATER,TAVERN
title: Ye Jumping Trapeze 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Soames (Teen ) Male who is Dead  
- Digby (Adult ) Male who is Healthy  
services: 
- Entertainer( Average   quality, Average  costs) 
- Performance( Average   quality, Average  costs) 
exterior: An tall building with faded paint and with planked siding with a few tall boarded windows. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Entertainer |  Average   quality |  Average  costs | 
> | Performance |  Average   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Soames  | Teen  |  Male who is Dead   | 
>> | Digby  | Adult  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

