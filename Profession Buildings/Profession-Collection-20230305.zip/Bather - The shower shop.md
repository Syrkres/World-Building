---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bather 
merchantCategory: Specialty Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The shower shop 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Branson (Teen ) Male who is Healthy as a horse  
- Denholm (Young Adult ) Female who is Out of sorts  
services: 
- Specialty Service( Low   quality, High  costs) 
- Wash( Poor   quality, Low  costs) 
exterior: An new one story building with faded paint and with shingled siding with a front short broken window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. A Maple pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Specialty Service |  Low   quality |  High  costs | 
> | Wash |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Branson  | Teen  |  Male who is Healthy as a horse   | 
>> | Denholm  | Young Adult  |  Female who is Out of sorts   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

