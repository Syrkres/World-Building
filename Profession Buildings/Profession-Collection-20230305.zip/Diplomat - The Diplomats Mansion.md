---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Diplomat 
merchantCategory: Elected Official
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Diplomats Mansion 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Barney (Young Adult ) Female who is Fit  
services: 
- Professional Specialties( Horrible   quality, Below Average  costs) 
- Advocate( Excellent   quality, High  costs) 
exterior: An tall building with faded paint and with stoned siding with a few short shuttered windows. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Horrible   quality |  Below Average  costs | 
> | Advocate |  Excellent   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Barney  | Young Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

