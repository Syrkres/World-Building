---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand 
merchantCategory: Criminal
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: JAIL,HOUSE
title: The Small Lizard Guild 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Shelly (Young Adult ) Male who is Fit  
services: 
- Mercenary( Poor   quality, High  costs) 
- Enforcement( Excellent   quality, High  costs) 
- Intimidation( Average   quality, Above Average  costs) 
exterior: An old narrow two story building with new paint and with stoned siding with a missing window. The roof is Dome. A Cherry pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Poor   quality |  High  costs | 
> | Enforcement |  Excellent   quality |  High  costs | 
> | Intimidation |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Shelly  | Young Adult  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

