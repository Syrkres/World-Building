---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: ArchDuke 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Byron's Hall 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Law (Teen ) Female who is Ailing  
services: 
- Noble( Poor   quality, High  costs) 
- Diplomacy( Average   quality, Low  costs) 
- Advise( Low   quality, Average  costs) 
exterior: An narrow building with faded paint and with shingled siding with a front broken window that has a carved sign hanging to the side with the merchants name. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Noble |  Poor   quality |  High  costs | 
> | Diplomacy |  Average   quality |  Low  costs | 
> | Advise |  Low   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Law  | Teen  |  Female who is Ailing   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

