---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian 
merchantCategory: Tracker
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,STABLE
title: The Tigger Guild 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Wellington (Young Adult ) Female who is Fine  
- Wilberforce (Young Adult ) Female who is Fit  
services: 
- Mercenary( Average   quality, Above Average  costs) 
- Tracking( Good   quality, Above Average  costs) 
exterior: An old two story building with shingled siding. The roof is Dome. A Oak pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Average   quality |  Above Average  costs | 
> | Tracking |  Good   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Wellington  | Young Adult  |  Female who is Fine   | 
>> | Wilberforce  | Young Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

