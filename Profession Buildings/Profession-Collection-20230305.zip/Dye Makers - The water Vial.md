---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dye Makers 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: The water Vial 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Blythe (Mature Adult ) Male who is Wounded  
- Blackwood (Teen ) Female who is Healthy  
services: 
- Sage( Excellent   quality, Above Average  costs) 
- Arcane Research( Horrible   quality, Average  costs) 
- Potion Brewing( Average   quality, Average  costs) 
exterior: An two story building with new paint and with shingled siding. The roof is House. A Oak shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Excellent   quality |  Above Average  costs | 
> | Arcane Research |  Horrible   quality |  Average  costs | 
> | Potion Brewing |  Average   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Blythe  | Mature Adult  |  Male who is Wounded   | 
>> | Blackwood  | Teen  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

