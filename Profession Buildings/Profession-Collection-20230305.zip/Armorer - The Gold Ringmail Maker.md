---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armorer 
merchantCategory: Forger
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,SMITHY
title: The Gold Ringmail Maker 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Blacksmith( Average   quality, High  costs) 
- Armor Crafting( Poor   quality, Average  costs) 
- Item Crafting( Excellent   quality, Above Average  costs) 
exterior: An building with new paint and with planked siding with a front tall window that has a painted sign hanging above with the merchants name. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Blacksmith |  Average   quality |  High  costs | 
> | Armor Crafting |  Poor   quality |  Average  costs | 
> | Item Crafting |  Excellent   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

