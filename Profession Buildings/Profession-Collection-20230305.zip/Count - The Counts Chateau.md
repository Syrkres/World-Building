---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Count 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Counts Chateau 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Richmond (Young Adult ) Male who is Healthy  
services: 
- Offical( Excellent   quality, Average  costs) 
- Diplomacy( Good   quality, Average  costs) 
exterior: An narrow tall building with brick siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Offical |  Excellent   quality |  Average  costs | 
> | Diplomacy |  Good   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Richmond  | Young Adult  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

