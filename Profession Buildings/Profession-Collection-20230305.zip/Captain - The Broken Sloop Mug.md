---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Captain 
merchantCategory: Guard
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: JAIL
title: The Broken Sloop Mug 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Thackeray (Teen ) Male who is Healthy  
- Reid (Teen ) Female who is Fit  
services: 
- Mercenary( Poor   quality, Low  costs) 
- Leadership( Excellent   quality, High  costs) 
exterior: An new building with stoned siding. The roof is Ceiling. A Elm shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Poor   quality |  Low  costs | 
> | Leadership |  Excellent   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Thackeray  | Teen  |  Male who is Healthy   | 
>> | Reid  | Teen  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

