---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Buckle Maker 
merchantCategory: Garment Trade
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We help keep it up 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Nash (Teen ) Male who is Out of sorts  
services: 
- Garment Trade( Low   quality, Below Average  costs) 
- Crafting( Horrible   quality, Low  costs) 
exterior: An tall building with brick siding. The roof is Roof. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Low   quality |  Below Average  costs | 
> | Crafting |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Nash  | Teen  |  Male who is Out of sorts   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

