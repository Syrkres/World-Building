---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Carpenter 
merchantCategory: Wood Workers
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We cut it 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Upton (Adult ) Female who is Fit  
services: 
- Construction( Horrible   quality, Low  costs) 
- Crafting( Average   quality, Above Average  costs) 
exterior: An new building with faded paint and with stoned siding. The roof is Canopy. A Ceder pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Construction |  Horrible   quality |  Low  costs | 
> | Crafting |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Upton  | Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

