---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chandler 
merchantCategory: Chandler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: The Wax Candle 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Wellington (Young Adult ) Female who is Healthy  
services: 
- Merchant( Horrible   quality, Above Average  costs) 
- Boat/Ship Merchant( Horrible   quality, High  costs) 
exterior: An tall building with stoned siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Horrible   quality |  Above Average  costs | 
> | Boat/Ship Merchant |  Horrible   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Wellington  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

