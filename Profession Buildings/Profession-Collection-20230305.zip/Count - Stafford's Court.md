---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Count 
merchantCategory: Noble
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Stafford's Court 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Pinkerton (Young Adult ) Male who is Healthy  
- Hayes (Teen ) Male who is At death's door  
services: 
- Offical( Low   quality, Low  costs) 
- Diplomacy( Poor   quality, Below Average  costs) 
exterior: An one story building with stoned siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Offical |  Low   quality |  Low  costs | 
> | Diplomacy |  Poor   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Pinkerton  | Young Adult  |  Male who is Healthy   | 
>> | Hayes  | Teen  |  Male who is At death's door   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

