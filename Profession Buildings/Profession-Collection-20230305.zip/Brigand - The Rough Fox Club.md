---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand 
merchantCategory: Criminal
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: JAIL,HOUSE
title: The Rough Fox Club 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Bentley (Young Adult ) Male who is Healthy  
services: 
- Mercenary( Good   quality, Low  costs) 
- Enforcement( Low   quality, Above Average  costs) 
- Intimidation( Poor   quality, High  costs) 
exterior: An long building with stoned siding with a missing short window. The roof is Roof. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Good   quality |  Low  costs | 
> | Enforcement |  Low   quality |  Above Average  costs | 
> | Intimidation |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Bentley  | Young Adult  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

