---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bookseller 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Storybound 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Thornton (Teen ) Male who is Healthy  
- Kirby (Adult ) Female who is Healthy  
services: 
- Craftsman( Good   quality, Low  costs) 
- Toy Making( Excellent   quality, Above Average  costs) 
- Clock Making( Average   quality, Low  costs) 
- Tinkerer( Average   quality, Above Average  costs) 
exterior: An new building with faded paint and with brick siding with a front round window that has a carved sign hanging to the side with the merchants name. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Good   quality |  Low  costs | 
> | Toy Making |  Excellent   quality |  Above Average  costs | 
> | Clock Making |  Average   quality |  Low  costs | 
> | Tinkerer |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Thornton  | Teen  |  Male who is Healthy   | 
>> | Kirby  | Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

