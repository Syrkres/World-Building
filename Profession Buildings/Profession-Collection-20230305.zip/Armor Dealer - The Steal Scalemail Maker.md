---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armor Dealer 
merchantCategory: Merchant
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,SMITHY
title: The Steal Scalemail Maker 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Pinkerton (Young Adult ) Female who is Healthy  
services: 
- Merchant( Average   quality, Low  costs) 
- Armor Crafting( Horrible   quality, Above Average  costs) 
exterior: An new narrow one story building with new paint and with brick siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. A Yellow Birch shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Average   quality |  Low  costs | 
> | Armor Crafting |  Horrible   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Pinkerton  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

