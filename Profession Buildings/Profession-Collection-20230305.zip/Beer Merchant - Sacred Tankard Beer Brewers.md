---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Beer Merchant 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Sacred Tankard Beer Brewers 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Thorpe (Teen ) Male who is Fine  
- Carlton (Young Adult ) Male who is Incapacitaed  
services: 
- Ale Sales( Poor   quality, Low  costs) 
exterior: An new narrow tall building with new paint and with stoned siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Ale Sales |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Thorpe  | Teen  |  Male who is Fine   | 
>> | Carlton  | Young Adult  |  Male who is Incapacitaed   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

