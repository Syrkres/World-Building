---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric 
merchantCategory: Clergy
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHRINE,HOUSE
title: Shrine of the Loyal 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- No apprentices
services: 
- Clergy( Excellent   quality, Average  costs) 
- Religion( Average   quality, Low  costs) 
- House of Worship( Poor   quality, Below Average  costs) 
- Curse Removal( Poor   quality, High  costs) 
- Spell Research( Excellent   quality, Low  costs) 
- Healing( Low   quality, Average  costs) 
- Potions( Horrible   quality, Low  costs) 
exterior: An narrow two story building with stoned siding. The roof is Ceiling. A Beech shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Excellent   quality |  Average  costs | 
> | Religion |  Average   quality |  Low  costs | 
> | House of Worship |  Poor   quality |  Below Average  costs | 
> | Curse Removal |  Poor   quality |  High  costs | 
> | Spell Research |  Excellent   quality |  Low  costs | 
> | Healing |  Low   quality |  Average  costs | 
> | Potions |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

