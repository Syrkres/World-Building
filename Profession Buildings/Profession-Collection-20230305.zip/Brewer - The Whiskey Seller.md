---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brewer 
merchantCategory: Food Service
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: The Whiskey Seller 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Denholm (Adult ) Female who is Fit  
services: 
- Sage( Poor   quality, Low  costs) 
- Arcane Research( Excellent   quality, High  costs) 
- Potion Brewing( Average   quality, Low  costs) 
exterior: An building with new paint and with shingled siding. The roof is House. A Red Oak pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Poor   quality |  Low  costs | 
> | Arcane Research |  Excellent   quality |  High  costs | 
> | Potion Brewing |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Denholm  | Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

