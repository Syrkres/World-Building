---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Handler 
merchantCategory: Animal Handler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: Rabbit Traders 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Hartford (Teen ) Female who is Ill  
- Rutherford (Mature Adult ) Male who is Fit  
services: 
- Animal Handler( Good   quality, Above Average  costs) 
- Stabler( Poor   quality, Low  costs) 
exterior: An building with planked siding. The roof is Ceiling. A Hickory pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Good   quality |  Above Average  costs | 
> | Stabler |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hartford  | Teen  |  Female who is Ill   | 
>> | Rutherford  | Mature Adult  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

