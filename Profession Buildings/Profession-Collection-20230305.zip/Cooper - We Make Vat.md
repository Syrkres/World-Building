---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cooper 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We Make Vat 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- York (Young Adult ) Female who is Healthy  
services: 
- Craftsman( Average   quality, Low  costs) 
- Toy Making( Low   quality, Above Average  costs) 
- Clock Making( Low   quality, Low  costs) 
- Tinkerer( Good   quality, Above Average  costs) 
exterior: An new long building with new paint and with shingled siding. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Average   quality |  Low  costs | 
> | Toy Making |  Low   quality |  Above Average  costs | 
> | Clock Making |  Low   quality |  Low  costs | 
> | Tinkerer |  Good   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | York  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

