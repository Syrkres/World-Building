---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Apothecary 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,ALCHEMIST
title: The Crystal Bottle 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Hartford (Teen ) Male who is Ill  
- Atherton (Teen ) Female who is All Right  
services: 
- Professional Specialties( Average   quality, Average  costs) 
- Healing( Poor   quality, Average  costs) 
- Potion Brewing( Good   quality, Low  costs) 
- Remedy Crafting( Average   quality, Low  costs) 
exterior: An old building with planked siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Average   quality |  Average  costs | 
> | Healing |  Poor   quality |  Average  costs | 
> | Potion Brewing |  Good   quality |  Low  costs | 
> | Remedy Crafting |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hartford  | Teen  |  Male who is Ill   | 
>> | Atherton  | Teen  |  Female who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

