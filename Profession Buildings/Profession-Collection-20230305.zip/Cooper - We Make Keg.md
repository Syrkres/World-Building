---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cooper 
merchantCategory: Craftsman
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,HOUSE
title: We Make Keg 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Tindall (Young Adult ) Male who is Scraped up  
- Landon (Teen ) Female who is Fit  
services: 
- Craftsman( Good   quality, High  costs) 
- Toy Making( Poor   quality, High  costs) 
- Clock Making( Horrible   quality, Above Average  costs) 
- Tinkerer( Horrible   quality, Above Average  costs) 
exterior: An two story building with faded paint and with brick siding. The roof is Canopy. A Cherry shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Good   quality |  High  costs | 
> | Toy Making |  Poor   quality |  High  costs | 
> | Clock Making |  Horrible   quality |  Above Average  costs | 
> | Tinkerer |  Horrible   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Tindall  | Young Adult  |  Male who is Scraped up   | 
>> | Landon  | Teen  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

