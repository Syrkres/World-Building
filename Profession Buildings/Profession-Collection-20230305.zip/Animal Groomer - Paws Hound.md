---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer 
merchantCategory: Animal Handler
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: TANNERY,FARM,STABLE
title: Paws Hound 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Spalding (Young Adult ) Female who is Dead  
- Birkenhead (Young Adult ) Male who is Well  
services: 
- Animal Handler( Low   quality, Below Average  costs) 
- Pet Training( Low   quality, Low  costs) 
- Animal Training( Horrible   quality, Low  costs) 
exterior: An old two story building with new paint and with planked siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Low   quality |  Below Average  costs | 
> | Pet Training |  Low   quality |  Low  costs | 
> | Animal Training |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Spalding  | Young Adult  |  Female who is Dead   | 
>> | Birkenhead  | Young Adult  |  Male who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

