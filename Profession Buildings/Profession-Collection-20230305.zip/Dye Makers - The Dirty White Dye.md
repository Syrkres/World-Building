---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dye Makers 
merchantCategory: Apothecary
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: ALCHEMIST,BREWERY
title: The Dirty White Dye 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Whitby (Teen ) Male who is Well  
- Trollope (Teen ) Female who is Dying  
services: 
- Sage( Good   quality, High  costs) 
- Arcane Research( Excellent   quality, Below Average  costs) 
- Potion Brewing( Good   quality, Above Average  costs) 
exterior: An old one story building with new paint and with planked siding. The roof is Ceiling. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Good   quality |  High  costs | 
> | Arcane Research |  Excellent   quality |  Below Average  costs | 
> | Potion Brewing |  Good   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Whitby  | Teen  |  Male who is Well   | 
>> | Trollope  | Teen  |  Female who is Dying   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

