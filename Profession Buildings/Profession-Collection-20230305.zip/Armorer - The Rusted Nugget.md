---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armorer 
merchantCategory: Forger
kingdom: 
region: 
settlementName: Not Assigned
wardName: 
structure: SHOP,SMITHY
title: The Rusted Nugget 
ownerName: No Owner Assigned
ownerLink: 
ownerRace: 
apprentices: 
- Preston (Teen ) Male who is Fit  
services: 
- Blacksmith( Poor   quality, Low  costs) 
- Armor Crafting( Excellent   quality, Below Average  costs) 
- Item Crafting( Average   quality, Below Average  costs) 
exterior: An narrow two story building with new paint and with planked siding with a few windows. The roof is Roof. A Pine shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Blacksmith |  Poor   quality |  Low  costs | 
> | Armor Crafting |  Excellent   quality |  Below Average  costs | 
> | Item Crafting |  Average   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Preston  | Teen  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

