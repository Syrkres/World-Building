---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Teamster Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Club Villa 
services: services
owner: Pauling (Half-Orc)
---
> [!oRPG-Layout] 
> #  Club Villa  (Teamster/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Pauling (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Below Average |

##  Club Villa  owned by [[Pauling]] (Half-Orc)
*Teamster / Professional*


**Building Description:**  An new building, with new paint stairs leading up to a Beech wood door with a Cherry frame with brick siding. The roof is planked. A Pine shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short lean build, with green eyes and very long auburn hair. Their face has a beard 
>
> ***Characteristics*** :  Hiccoughs
>
> ***Personality*** :  Confident
>
> ***Trait*** : I'm rude to people who lack my commitment to hard work and fair play.
>
> ***Ideal*** : People. I help people who help me--that's what keeps us alive. (Neutral)
{ .ownerDescription }



