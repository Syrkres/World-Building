---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chicken Butcher Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Plucked Raven 
services: services
owner: Malivoire (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Plucked Raven  (Chicken Butcher/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Malivoire (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Above Average |

##  The Plucked Raven  owned by [[Malivoire]] (Half-Elf)
*Chicken Butcher / Cooks*


**Building Description:**  An new one story building, with faded paint stairs leading up to a set of double Pine wood doors with a Cherry frame, with planked siding. The roof is timber made of Ceder. A Ceder crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Normal average build, with red eyes and streaked red hair. Their face has a broken nose 
>
> ***Characteristics*** :  Rolls eyes when bored/annoyed
>
> ***Personality*** :  Peaceful
>
> ***Trait*** : I'm always picking things up, absently fiddling with them, and sometimes accidentally breaking them.
>
> ***Ideal*** : Generosity. My talents were given to me so that I could use them to benefit the world. (Good)
{ .ownerDescription }



