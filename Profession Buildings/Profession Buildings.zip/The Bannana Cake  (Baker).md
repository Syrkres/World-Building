---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Bannana Cake 
services: services
owner: Halloran (Gnome)
---
> [!oRPG-Layout] 
> #  The Bannana Cake  (Baker/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Halloran (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  The Bannana Cake  owned by [[Halloran]] (Gnome)
*Baker / Cooks*


**Building Description:**  An new long one story building, with new paint a Bronze door with a Ceder frame with stoned siding. The roof is planked.  



> ### Owner Description/Background
> ***Appearance*** : Tall lean build, with red eyes and very long auburn hair. Their face is chiseled 
>
> ***Characteristics*** :  Likes to arm wrestle
>
> ***Personality*** :  Vulgar
>
> ***Trait*** : I watch over my friends as if they were a litter of newborn pups.
>
> ***Ideal*** : Greater Good. It is each person's responsibility to make the most happiness for the whole tribe. (Good)
{ .ownerDescription }



