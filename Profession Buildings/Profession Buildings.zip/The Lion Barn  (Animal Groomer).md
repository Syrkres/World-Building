---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Stables
title:  The Lion Barn 
services: services
owner: Scarlett (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Lion Barn  (Animal Groomer/Entertainer)
> **Structure:** Stables
> **Resides In:** 
>  **Owner:** Scarlett (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Above Average |

##  The Lion Barn  owned by [[Scarlett]] (Half-Elf)
*Animal Groomer / Entertainer*


**Building Description:**  An old narrow two story building with stoned siding with a few round boarded windows. The roof is timber made of Pine. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal athletic build, with blue eyes and streaked red hair. Their face has a distinctive nose 
>
> ***Characteristics*** :  Chews tobacco
>
> ***Personality*** :  Nurturing
>
> ***Trait*** : I think anyone who's nice to me is hiding evil intent.
>
> ***Ideal*** : Might. In life as in war, the stronger force wins. (Evil)
{ .ownerDescription }



