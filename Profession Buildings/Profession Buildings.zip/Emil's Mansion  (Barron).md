---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barron Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Townhall
title:  Emil's Mansion 
services: services
owner: Emil (Halfling)
---
> [!oRPG-Layout] 
> #  Emil's Mansion  (Barron/Offical)
> **Structure:** Townhall
> **Resides In:** 
>  **Owner:** Emil (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  Emil's Mansion  owned by [[Emil]] (Halfling)
*Barron / Offical*


**Building Description:**  An old long building with faded paint and with stoned siding. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Normal lean build, with hazel eyes and dreadlocks brown hair. Their face is pock-marked 
>
> ***Characteristics*** :  Peg-legged
>
> ***Personality*** :  Imitative
>
> ***Trait*** : I once ran twenty-five miles without stopping to warn my clan of an approaching orc horde. I'd do it again if I had to.
>
> ***Ideal*** : People. I'm loyal to my friends, not to any ideals, and everyone else can take a trip down the Styx for all I care. (Neutral)
{ .ownerDescription }



