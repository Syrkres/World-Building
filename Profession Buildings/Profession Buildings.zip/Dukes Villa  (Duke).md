---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Duke Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Dukes Villa 
services: services
owner: Helmwood (Gnome)
---
> [!oRPG-Layout] 
> #  Dukes Villa  (Duke/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Helmwood (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Above Average |

##  Dukes Villa  owned by [[Helmwood]] (Gnome)
*Duke / Offical*


**Building Description:**  An old long two story building, stairs leading up to a set of double Elm wood with Bronze bands doors, with shingled siding with a missing tall window. The roof is timber. A warn Oak crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Average lean build, with blue eyes and streaked blond hair. Their face is pierced 
>
> ***Characteristics*** :  Predilection for certain kind of food
>
> ***Personality*** :  Sardonic
>
> ***Trait*** : I ask a lot of questions.
>
> ***Ideal*** : Self-improvement. The goal of a life of study is the betterment of oneself.
{ .ownerDescription }



