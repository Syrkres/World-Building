---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crime Lord 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Black Book 
services: services
owner: Oberfrank (Elven)
---
> [!oRPG-Layout] 
> #  The Black Book  (Crime Lord/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Oberfrank (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Above Average |

##  The Black Book  owned by [[Oberfrank]] (Elven)
*Crime Lord / *


**Building Description:**  An old building, with faded paint stairs leading up to a Steal door with a Red Oak frame with stoned siding. The roof is thatching made of straw. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Squat fat build, with red eyes and strange hairstyle red hair. Their face is grizzled 
>
> ***Characteristics*** :  Freckled
>
> ***Personality*** :  Depraved
>
> ***Trait*** : I'm a hopeless romantic, always searching for that 'special someone'.
>
> ***Ideal*** : Aspiration. I seek to prove my self worthy of my god's favor by matching my actions against his or her teachings. (Any)
{ .ownerDescription }



