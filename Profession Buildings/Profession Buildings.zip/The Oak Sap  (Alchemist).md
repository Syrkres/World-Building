---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Alchemist Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Oak Sap 
services: services
owner: Logspitter (Halfling)
---
> [!oRPG-Layout] 
> #  The Oak Sap  (Alchemist/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Logspitter (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Low |

##  The Oak Sap  owned by [[Logspitter]] (Halfling)
*Alchemist / Librarian*


**Building Description:**  An new long tall building, with new paint with shingled siding. The roof is shingled. A pergola is attached to the side. A warn Hickory crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Short fat build, with white eyes and long grey hair. Their face has a patch over left eye 
>
> ***Characteristics*** :  Jumps conversation topics
>
> ***Personality*** :  Sadistic
>
> ***Trait*** : I'm willing to listen to every side of an argument before I make my own judgment.
>
> ***Ideal*** : Nation. My city, nation, or people are all that matter. (Any)
{ .ownerDescription }



