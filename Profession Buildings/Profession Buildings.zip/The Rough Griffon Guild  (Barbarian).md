---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Tavern
title:  The Rough Griffon Guild 
services: services
owner: Pavia (Dwarf)
---
> [!oRPG-Layout] 
> #  The Rough Griffon Guild  (Barbarian/Guard)
> **Structure:** Tavern
> **Resides In:** 
>  **Owner:** Pavia (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  The Rough Griffon Guild  owned by [[Pavia]] (Dwarf)
*Barbarian / Guard*


**Building Description:**  An old tall building with new paint and with brick siding. The roof is thatched. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Squat strong build, with blue eyes and limp brown hair. Their face has stained teeth 
>
> ***Characteristics*** :  Prefers to be called by last name
>
> ***Personality*** :  Brash
>
> ***Trait*** : I am horribly, horribly awkward in social situations.
>
> ***Ideal*** : Freedom. Tyrants must not be allowed to oppress the people. (Chaotic)
{ .ownerDescription }



