---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wood Seller 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Pine logs 
services: services
owner: Ott (Elven)
---
> [!oRPG-Layout] 
> #  Pine logs  (Wood Seller/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Ott (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  Pine logs  owned by [[Ott]] (Elven)
*Wood Seller / *


**Building Description:**  An narrow one story building, with faded paint a Yellow Birch wood with Steal bands door with a Red Oak frame with shingled siding. The roof is thatching made of grass. A shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand athletic build, with brown eyes and wavy red hair. Their face is weather-beaten 
>
> ***Characteristics*** :  Refuses to let anyone walk behind them
>
> ***Personality*** :  Modest
>
> ***Trait*** : Thinking is for other people. I prefer action.
>
> ***Ideal*** : People. I'm committed to my crewmates, not to ideals. (Neutral)
{ .ownerDescription }



