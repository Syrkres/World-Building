---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Mercer Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Cloth Reseller 
services: services
owner: Hotton (Dwarf)
---
> [!oRPG-Layout] 
> #  The Cloth Reseller  (Mercer/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hotton (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Cloth Reseller  owned by [[Hotton]] (Dwarf)
*Mercer / Tailor*


**Building Description:**  An new one story building, stairs leading up to a set of double Maple wood doors with a Pine frame, with stoned siding with a few round broken windows. The roof is planked with Yellow Birch planks. A Maple pergola is attached to the side. A Beech crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Tall anorexic build, with red eyes and thinning white hair. Their face has sideburns 
>
> ***Characteristics*** :  Always wears tattered clothes
>
> ***Personality*** :  Caring
>
> ***Trait*** : I'm a hopeless romantic, always searching for that 'special someone'.
>
> ***Ideal*** : Self-improvement. The goal of a life of study is the betterment of oneself.
{ .ownerDescription }



