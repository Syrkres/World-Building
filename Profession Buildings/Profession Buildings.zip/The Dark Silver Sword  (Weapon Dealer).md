---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weapon Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Dark Silver Sword 
services: services
owner: Vexler (Elven)
---
> [!oRPG-Layout] 
> #  The Dark Silver Sword  (Weapon Dealer/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Vexler (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Low |

##  The Dark Silver Sword  owned by [[Vexler]] (Elven)
*Weapon Dealer / *


**Building Description:**  An old long tall building, a set of double Beech wood doors with a Elm frame, with shingled siding. The roof is thatching made of grass. A few Oak barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Short wide build, with hazel eyes and limp auburn hair. Their face is pock-marked 
>
> ***Characteristics*** :  Repeats same phrase over and over
>
> ***Personality*** :  Whimsical
>
> ***Trait*** : I know a story relevant to almost every situation.
>
> ***Ideal*** : Family. Blood runs thicker than water. (Any)
{ .ownerDescription }



