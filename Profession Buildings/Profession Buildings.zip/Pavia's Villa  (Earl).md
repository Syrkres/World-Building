---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Earl Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Pavia's Villa 
services: services
owner: Pavia (Gnome)
---
> [!oRPG-Layout] 
> #  Pavia's Villa  (Earl/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Pavia (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  Pavia's Villa  owned by [[Pavia]] (Gnome)
*Earl / Offical*


**Building Description:**  An narrow tall building, stairs leading up to a set of double Oak wood with Copper bands doors, with shingled siding. The roof is planked with Oak planks. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Squat athletic build, with brown eyes and well groomed brown hair. Their face has small scar on right cheek 
>
> ***Characteristics*** :  Rolls eyes when bored/annoyed
>
> ***Personality*** :  Stoic
>
> ***Trait*** : I am horribly, horribly awkward in social situations.
>
> ***Ideal*** : People. I'm loyal to my friends, not to any ideals, and everyone else can take a trip down the Styx for all I care. (Neutral)
{ .ownerDescription }



