---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cabbage Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Farm 
services: services
owner: Oberfrank (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Farm  (Farmer - Cabbage/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Oberfrank (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Low |

##  The Farm  owned by [[Oberfrank]] (Half-Elf)
*Farmer - Cabbage / Farmer*


**Building Description:**  An new building, stairs leading up to a Yellow Birch wood with Steal bands door with a Pine frame with brick siding. The roof is thatching made of straw. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Tall weak build, with hazel eyes and curly white hair. Their face has acne 
>
> ***Characteristics*** :  Chews tobacco
>
> ***Personality*** :  Fearful
>
> ***Trait*** : I quote the sacred texts and proverbs in almost every situation.
>
> ***Ideal*** : Free Thinking. Inquiry and curiosity are the pillars of progress. (Chaotic)
{ .ownerDescription }



