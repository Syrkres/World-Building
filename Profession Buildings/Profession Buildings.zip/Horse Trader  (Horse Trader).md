---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Horse Trader 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Horse Trader 
services: services
owner: Najor (Human)
---
> [!oRPG-Layout] 
> #  Horse Trader  (Horse Trader/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Najor (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  Horse Trader  owned by [[Najor]] (Human)
*Horse Trader / *


**Building Description:**  An old tall building, with new paint with stoned siding with a few tall broken windows. The roof is planked with Elm planks. A Maple shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Tall anorexic build, with brown eyes and straight auburn hair. Their face has large scar across full face 
>
> ***Characteristics*** :  Nervous muscle twitch
>
> ***Personality*** :  Savage
>
> ***Trait*** : I am working on a grand philosophical theory and love sharing my ideas.
>
> ***Ideal*** : Generosity. My talents were given to me so that I could use them to benefit the world. (Good)
{ .ownerDescription }



