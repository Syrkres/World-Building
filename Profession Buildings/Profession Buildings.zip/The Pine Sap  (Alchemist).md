---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Alchemist Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Pine Sap 
services: services
owner: Benu (Elven)
---
> [!oRPG-Layout] 
> #  The Pine Sap  (Alchemist/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Benu (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Low |

##  The Pine Sap  owned by [[Benu]] (Elven)
*Alchemist / Librarian*


**Building Description:**  An long building, with faded paint a set of double Elm wood doors, with planked siding. The roof is planked with Elm planks. A Maple shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal fat build, with brown eyes and dreadlocks brown hair. Their face is buck-toothed 
>
> ***Characteristics*** :  Interrupts others
>
> ***Personality*** :  Morose
>
> ***Trait*** : I hide scraps of food and trinkets away in my pockets.
>
> ***Ideal*** : Respect. The thing that keeps a ship together is mutual respect between captain and crew. (Good)
{ .ownerDescription }



