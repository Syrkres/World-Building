---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thief Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Broken Dark Grey Gauntlet 
services: services
owner: Aristo (Elven)
---
> [!oRPG-Layout] 
> #  The Broken Dark Grey Gauntlet  (Thief/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Aristo (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  The Broken Dark Grey Gauntlet  owned by [[Aristo]] (Elven)
*Thief / Guard*


**Building Description:**  An old two story building, with new paint a set of double Hickory wood with Iron bands doors, with planked siding with a missing window. The roof is thatched. A Pine pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal lean build, with red eyes and short brown hair. Their face has small scar 
>
> ***Characteristics*** :  Mutters
>
> ***Personality*** :  Vigilant
>
> ***Trait*** : I would rather make a new friend than a new enemy.
>
> ***Ideal*** : Self-improvement. The goal of a life of study is the betterment of oneself.
{ .ownerDescription }



