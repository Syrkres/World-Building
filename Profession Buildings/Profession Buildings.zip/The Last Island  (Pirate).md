---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Pirate Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Last Island 
services: services
owner: Merchant (Elven)
---
> [!oRPG-Layout] 
> #  The Last Island  (Pirate/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Merchant (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  The Last Island  owned by [[Merchant]] (Elven)
*Pirate / Guard*


**Building Description:**  An old tall building, with faded paint a set of double Iron doors, with stoned siding. The roof is planked with Pine planks. A shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal weak build, with blue eyes and very long blond hair. Their face has eyebrow pierced 
>
> ***Characteristics*** :  If unable to recall word, stops conversation and will not give up until can finally remember it
>
> ***Personality*** :  Cowardly
>
> ***Trait*** : I would rather make a new friend than a new enemy.
>
> ***Ideal*** : Beauty. What is beautiful points us beyond itself toward what is true. (Good)
{ .ownerDescription }



