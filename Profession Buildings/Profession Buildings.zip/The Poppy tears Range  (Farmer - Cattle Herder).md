---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Poppy tears Range 
services: services
owner: Hakku (Elven)
---
> [!oRPG-Layout] 
> #  The Poppy tears Range  (Farmer - Cattle Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hakku (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  The Poppy tears Range  owned by [[Hakku]] (Elven)
*Farmer - Cattle Herder / Farmer*


**Building Description:**  An building, stairs leading up to a Maple wood door with stoned siding. The roof is thatching made of grass. A Oak shed is attached to the side. A warn Hickory barrel sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Short thin build, with green eyes and messy auburn hair. Their face is pock-marked 
>
> ***Characteristics*** :  Answers questions with questions
>
> ***Personality*** :  Sadistic
>
> ***Trait*** : Whenever I come to a new place, I collect local rumors and spread gossip.
>
> ***Ideal*** : Knowledge. The path to power and self-improvement is through knowledge. (Neutral)
{ .ownerDescription }



