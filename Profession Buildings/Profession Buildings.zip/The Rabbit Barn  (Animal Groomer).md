---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Stables
title:  The Rabbit Barn 
services: services
owner: Stross (Elven)
---
> [!oRPG-Layout] 
> #  The Rabbit Barn  (Animal Groomer/Entertainer)
> **Structure:** Stables
> **Resides In:** 
>  **Owner:** Stross (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Rabbit Barn  owned by [[Stross]] (Elven)
*Animal Groomer / Entertainer*


**Building Description:**  An two story building with faded paint and with stoned siding. The roof is shingled with Hickory shingles.  



> ### Owner Description/Background
> ***Appearance*** : Short athletic build, with brown eyes and limp black hair. Their face has small scar on right cheek 
>
> ***Characteristics*** :  Believes all animals can talk to each other
>
> ***Personality*** :  Lippy
>
> ***Trait*** : I always want to know how things work and what makes people tick.
>
> ***Ideal*** : Change. Life is like the seasons, in constant change, and we must change with it. (Chaotic)
{ .ownerDescription }



