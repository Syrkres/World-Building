---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Spicer Maker Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Mistletoe Nectar 
services: services
owner: Graf (Dwarf)
---
> [!oRPG-Layout] 
> #  The Mistletoe Nectar  (Spicer Maker/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Graf (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  The Mistletoe Nectar  owned by [[Graf]] (Dwarf)
*Spicer Maker / Cooks*


**Building Description:**  An old two story building, with shingled siding. The roof is thatching made of straw. A shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand strong build, with hazel eyes and long blond hair. Their face has small scar 
>
> ***Characteristics*** :  Hates quiet pauses in conversations
>
> ***Personality*** :  Charming
>
> ***Trait*** : I enjoy sailing into new ports and making new friends over a flagon of ale.
>
> ***Ideal*** : People. I'm committed to the people I care about, not to ideals. (Neutral)
{ .ownerDescription }



