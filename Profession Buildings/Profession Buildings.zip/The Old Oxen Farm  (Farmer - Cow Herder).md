---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cow Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Old Oxen Farm 
services: services
owner: Eskeen (Halfling)
---
> [!oRPG-Layout] 
> #  The Old Oxen Farm  (Farmer - Cow Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Eskeen (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  The Old Oxen Farm  owned by [[Eskeen]] (Halfling)
*Farmer - Cow Herder / Farmer*


**Building Description:**  An new building, with faded paint with planked siding with a few short windows. The roof is shingled. A shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall average build, with red eyes and pony-tail red hair. Their face has no eyebrows 
>
> ***Characteristics*** :  Mispronounces names
>
> ***Personality*** :  Solemn
>
> ***Trait*** : I'm oblivious to etiquette and social expectations.
>
> ***Ideal*** : Knowledge. The path to power and self-improvement is through knowledge. (Neutral)
{ .ownerDescription }



