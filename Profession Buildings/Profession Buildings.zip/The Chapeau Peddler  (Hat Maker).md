---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Chapeau Peddler 
services: services
owner: Taverrrite (Dwarf)
---
> [!oRPG-Layout] 
> #  The Chapeau Peddler  (Hat Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Taverrrite (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Average |

##  The Chapeau Peddler  owned by [[Taverrrite]] (Dwarf)
*Hat Maker / Tailor*


**Building Description:**  An tall building, with brick siding. The roof is thatching made of grass. A shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal lean build, with red eyes and thick white hair. Their face has no eyebrows 
>
> ***Characteristics*** :  Picks at fingernails
>
> ***Personality*** :  Altruistic
>
> ***Trait*** : Thinking is for other people. I prefer action.
>
> ***Ideal*** : Might. The strongest are meant to rule. (Evil)
{ .ownerDescription }



