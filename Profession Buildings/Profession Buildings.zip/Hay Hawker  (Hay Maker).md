---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hay Maker 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Hay Hawker 
services: services
owner: Wonders (Halfling)
---
> [!oRPG-Layout] 
> #  Hay Hawker  (Hay Maker/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Wonders (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  Hay Hawker  owned by [[Wonders]] (Halfling)
*Hay Maker / *


**Building Description:**  An one story building, a set of double Yellow Birch wood doors with a Red Oak frame, with planked siding. The roof is shingled. A shed is attached to the side. A warn Yellow Birch chest sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Squat frail build, with brown eyes and short blond hair. Their face is chiseled 
>
> ***Characteristics*** :  Scarred on Right leg on Left leg on Left arm on Head/Face on Right leg on Left arm on Stomach
>
> ***Personality*** :  Cultured
>
> ***Trait*** : I would rather make a new friend than a new enemy.
>
> ***Ideal*** : Greater Good. Our lot is to lay down our lives in defense of others. (Good)
{ .ownerDescription }



