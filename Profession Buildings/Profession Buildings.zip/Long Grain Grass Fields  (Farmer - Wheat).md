---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Wheat Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Long Grain Grass Fields 
services: services
owner: Lashbrook (Human)
---
> [!oRPG-Layout] 
> #  Long Grain Grass Fields  (Farmer - Wheat/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Lashbrook (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  Long Grain Grass Fields  owned by [[Lashbrook]] (Human)
*Farmer - Wheat / Farmer*


**Building Description:**  An tall building, a set of double Iron doors, with stoned siding with a missing round window. The roof is thatching made of straw. A Oak shed structure is to the side. A pile of Red Oak wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall weak build, with white eyes and wavy grey hair. Their face has nose pierced 
>
> ***Characteristics*** :  Sings
>
> ***Personality*** :  Sultry
>
> ***Trait*** : Nobody stays angry at me or around me for long, since I can defuse any amount of tension.
>
> ***Ideal*** : Beauty. When I perform, I make the world better than it was. (Good)
{ .ownerDescription }



