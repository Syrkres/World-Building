---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Rug Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Carpet Hawker 
services: services
owner: Grieve (Human)
---
> [!oRPG-Layout] 
> #  Carpet Hawker  (Rug Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Grieve (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  Carpet Hawker  owned by [[Grieve]] (Human)
*Rug Maker / Crafter*


**Building Description:**  An old tall building, with new paint with shingled siding with a few short broken windows. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Squat athletic build, with hazel eyes and curly auburn hair. Their face has large scar on right cheek 
>
> ***Characteristics*** :  Refuses to let anyone walk behind them
>
> ***Personality*** :  Docile
>
> ***Trait*** : Nothing can shake my optimistic attitude.
>
> ***Ideal*** : Greater Good. It is each person's responsibility to make the most happiness for the whole tribe. (Good)
{ .ownerDescription }



