---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Tavern
title:  The Rough Fox Lodge 
services: services
owner: Braggs (Human)
---
> [!oRPG-Layout] 
> #  The Rough Fox Lodge  (Barbarian/Guard)
> **Structure:** Tavern
> **Resides In:** 
>  **Owner:** Braggs (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  The Rough Fox Lodge  owned by [[Braggs]] (Human)
*Barbarian / Guard*


**Building Description:**  An one story building with faded paint and with planked siding with a missing short window. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Extra short thin build, with red eyes and short grey hair. Their face has a missing eye 
>
> ***Characteristics*** :  Refuses to sit in chairs
>
> ***Personality*** :  Gentle
>
> ***Trait*** : I can stare down a hellhound without flinching.
>
> ***Ideal*** : Sincerity. There's no good pretending to be something I'm not. (Neutral)
{ .ownerDescription }



