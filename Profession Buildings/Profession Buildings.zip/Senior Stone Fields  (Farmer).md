---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Senior Stone Fields 
services: services
owner: Helstrom (Halfling)
---
> [!oRPG-Layout] 
> #  Senior Stone Fields  (Farmer/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Helstrom (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Average |

##  Senior Stone Fields  owned by [[Helstrom]] (Halfling)
*Farmer / Farmer*


**Building Description:**  An old building, with shingled siding with a missing window. The roof is shingled with Yellow Birch shingles. A shed is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Squat wide build, with green eyes and greasy blond hair. Their face is grizzled 
>
> ***Characteristics*** :  Talks to self
>
> ***Personality*** :  Casual
>
> ***Trait*** : I have a lesson for every situation, drawn from observing nature.
>
> ***Ideal*** : Freedom. Chains are meant to be broken, as are those who would forge them. (Chaotic)
{ .ownerDescription }



