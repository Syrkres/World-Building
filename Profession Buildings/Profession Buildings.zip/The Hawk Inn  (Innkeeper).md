---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Innkeeper 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Hawk Inn 
services: services
owner: Crawdad (Gnome)
---
> [!oRPG-Layout] 
> #  The Hawk Inn  (Innkeeper/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Crawdad (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Above Average |

##  The Hawk Inn  owned by [[Crawdad]] (Gnome)
*Innkeeper / *


**Building Description:**  An new building, with faded paint stairs leading up to a set of double Cherry wood with Iron bands doors with a Elm frame, with planked siding. The roof is shingled. A Elm shed is attached to the side. A Pine barrel sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall anorexic build, with blue eyes and strange hairstyle auburn hair. Their face has small scar on left cheek 
>
> ***Characteristics*** :  Sneezes
>
> ***Personality*** :  Incoherent
>
> ***Trait*** : I'm convinced that people are always trying to steal my secrets.
>
> ***Ideal*** : Respect. All people, rich or poor, deserve respect. (Good)
{ .ownerDescription }



