---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thief Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Black Market 
services: services
owner: Chopping (Elven)
---
> [!oRPG-Layout] 
> #  Black Market  (Thief/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Chopping (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  Black Market  owned by [[Chopping]] (Elven)
*Thief / Guard*


**Building Description:**  An new long building, with faded paint with shingled siding. The roof is thatched. A shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Tall anorexic build, with brown eyes and limp red hair. Their face has large scar on right cheek 
>
> ***Characteristics*** :  Picks at lint or dirt on others' clothes
>
> ***Personality*** :  Attentive
>
> ***Trait*** : No one could doubt by looking at my regal bearing that I am a cut above the unwashed masses.
>
> ***Ideal*** : People. I'm loyal to my friends, not to any ideals, and everyone else can take a trip down the Styx for all I care. (Neutral)
{ .ownerDescription }



