---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Saddler Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Saddle Peddler 
services: services
owner: Roark (Elven)
---
> [!oRPG-Layout] 
> #  Saddle Peddler  (Saddler/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Roark (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Above Average |

##  Saddle Peddler  owned by [[Roark]] (Elven)
*Saddler / Crafter*


**Building Description:**  An new narrow one story building, with faded paint a set of double Beech wood doors, with shingled siding. The roof is planked with Pine planks. A shed is attached to the side. A pile of Red Oak wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal average build, with red eyes and dreadlocks red hair. Their face has stained teeth 
>
> ***Characteristics*** :  Stares
>
> ***Personality*** :  Goofy
>
> ***Trait*** : Despite my birth, I do not place myself above other folk. We all have the same blood.
>
> ***Ideal*** : Respect. The thing that keeps a ship together is mutual respect between captain and crew. (Good)
{ .ownerDescription }



