---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Apothecary 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Oil Vial 
services: services
owner: Roark (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Oil Vial  (Apothecary/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Roark (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  The Oil Vial  owned by [[Roark]] (Half-Orc)
*Apothecary / *


**Building Description:**  An building, a set of double Bronze doors, with shingled siding with a few short boarded windows. The roof is shingled with Oak shingles.  



> ### Owner Description/Background
> ***Appearance*** : Normal fat build, with green eyes and wiry auburn hair. Their face has small scar 
>
> ***Characteristics*** :  Bites fingernails
>
> ***Personality*** :  Violent
>
> ***Trait*** : I am tolerant of other faiths and respect (or condemn) the worship of other gods.
>
> ***Ideal*** : Aspiration. I seek to prove my self worthy of my god's favor by matching my actions against his or her teachings. (Any)
{ .ownerDescription }



