---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crook Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Pawn Market Stall 
services: services
owner: Tufo (Half-Elf)
---
> [!oRPG-Layout] 
> #  Pawn Market Stall  (Crook/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Tufo (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Below Average |

##  Pawn Market Stall  owned by [[Tufo]] (Half-Elf)
*Crook / Guard*


**Building Description:**  An narrow one story building, with planked siding. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall anorexic build, with white eyes and braided blond hair. Their face has a distinctive nose 
>
> ***Characteristics*** :  Double-checks everything
>
> ***Personality*** :  Feisty
>
> ***Trait*** : I get bored easily. When am I going to get on with my destiny.
>
> ***Ideal*** : Power. If I can attain more power, no one will tell me what to do. (Evil)
{ .ownerDescription }



