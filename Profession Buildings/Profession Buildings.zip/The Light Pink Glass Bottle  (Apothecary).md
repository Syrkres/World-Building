---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Apothecary 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Light Pink Glass Bottle 
services: services
owner: Smyj (Human)
---
> [!oRPG-Layout] 
> #  The Light Pink Glass Bottle  (Apothecary/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Smyj (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Average |

##  The Light Pink Glass Bottle  owned by [[Smyj]] (Human)
*Apothecary / *


**Building Description:**  An long building, a Copper door with brick siding. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Average weak build, with blue eyes and very long auburn hair. Their face has a moustache 
>
> ***Characteristics*** :  Interrupts others
>
> ***Personality*** :  Insensitive
>
> ***Trait*** : I...speak...slowly...when talking...to idiots...which...almost...everyone...is...compared ...to me.
>
> ***Ideal*** : Fairness. We all do the work, so we all share in the rewards. (Lawful)
{ .ownerDescription }



