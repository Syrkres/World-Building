---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Laborer Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Guild Hall 
services: services
owner: Rhizor (Human)
---
> [!oRPG-Layout] 
> #  Guild Hall  (Laborer/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Rhizor (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  Guild Hall  owned by [[Rhizor]] (Human)
*Laborer / Professional*


**Building Description:**  An new building, stairs leading up to a set of double Copper doors with a Yellow Birch frame, with stoned siding. The roof is timber made of Hickory.  



> ### Owner Description/Background
> ***Appearance*** : Squat anorexic build, with brown eyes and braided grey hair. Their face is doe-eyed 
>
> ***Characteristics*** :  Insomniac
>
> ***Personality*** :  Unfriendly
>
> ***Trait*** : I feel tremendous empathy for all who suffer.
>
> ***Ideal*** : People. I'm committed to my crewmates, not to ideals. (Neutral)
{ .ownerDescription }



