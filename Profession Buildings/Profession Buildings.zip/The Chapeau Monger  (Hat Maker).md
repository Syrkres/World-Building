---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Chapeau Monger 
services: services
owner: Arkie (Elven)
---
> [!oRPG-Layout] 
> #  The Chapeau Monger  (Hat Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Arkie (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Low |

##  The Chapeau Monger  owned by [[Arkie]] (Elven)
*Hat Maker / Tailor*


**Building Description:**  An narrow tall building, a set of double Maple wood doors with a Hickory frame, with shingled siding with a front round window that has a Elm wood door with the merchants name. The roof is thatching made of straw. A Elm shed is attached to the side. A pile of Beech wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short weak build, with hazel eyes and bald auburn hair. Their face is weather-beaten 
>
> ***Characteristics*** :  Imaginary friend
>
> ***Personality*** :  Introverted
>
> ***Trait*** : My eloquent flattery makes everyone I talk to feel like the most wonderful and important person in the world.
>
> ***Ideal*** : Responsibility. It is my duty to respect the authority of those above me, just as those below me must respect mine. (Lawful)
{ .ownerDescription }



