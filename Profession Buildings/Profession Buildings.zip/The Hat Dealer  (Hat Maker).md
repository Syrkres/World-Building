---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Hat Dealer 
services: services
owner: Singeri (Dwarf)
---
> [!oRPG-Layout] 
> #  The Hat Dealer  (Hat Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Singeri (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Below Average |

##  The Hat Dealer  owned by [[Singeri]] (Dwarf)
*Hat Maker / Tailor*


**Building Description:**  An tall building, stairs leading up to a Iron door with brick siding with a few round windows. The roof is thatching made of straw. A Pine shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Average weak build, with white eyes and limp grey hair. Their face has a bushy eyebrows 
>
> ***Characteristics*** :  Freckled
>
> ***Personality*** :  Disloyal
>
> ***Trait*** : I eat like a pig and have bad manners.
>
> ***Ideal*** : Respect. Respect is due to me because of my position, but all people regardless of station deserve to be treated with dignity. (Good)
{ .ownerDescription }



