---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tutor Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Teachers Federation 
services: services
owner: Vaden (Half-Elf)
---
> [!oRPG-Layout] 
> #  Teachers Federation  (Tutor/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Vaden (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Below Average |

##  Teachers Federation  owned by [[Vaden]] (Half-Elf)
*Tutor / Librarian*


**Building Description:**  An narrow tall building, with faded paint with brick siding. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Normal average build, with red eyes and wiry brown hair. Their face has large scar 
>
> ***Characteristics*** :  Taps feet
>
> ***Personality*** :  Rash
>
> ***Trait*** : I...speak...slowly...when talking...to idiots...which...almost...everyone...is...compared ...to me.
>
> ***Ideal*** : Honor. I don't steal from others in the trade. (Lawful)
{ .ownerDescription }



