---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wood Carver 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Cherry Furniture 
services: services
owner: Rude (Halfling)
---
> [!oRPG-Layout] 
> #  Cherry Furniture  (Wood Carver/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Rude (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  Cherry Furniture  owned by [[Rude]] (Halfling)
*Wood Carver / *


**Building Description:**  An new one story building, with faded paint with brick siding with a few broken windows. The roof is shingled with Elm shingles. A Oak shed is attached to the side. A few Beech chests sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Tall athletic build, with red eyes and well groomed auburn hair. Their face has nose pierced 
>
> ***Characteristics*** :  Insomniac
>
> ***Personality*** :  Playful
>
> ***Trait*** : I have a joke for every occasion, especially occasions where humor is inappropriate.
>
> ***Ideal*** : Fairness. No one should get preferential treatment before the law, and no one is above the law. (Lawful)
{ .ownerDescription }



