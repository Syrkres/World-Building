---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sage Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Sage Emporium 
services: services
owner: Altos (Elven)
---
> [!oRPG-Layout] 
> #  Sage Emporium  (Sage/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Altos (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Average |

##  Sage Emporium  owned by [[Altos]] (Elven)
*Sage / Librarian*


**Building Description:**  An one story building, with brick siding with a missing window. The roof is planked with Cherry planks.  



> ### Owner Description/Background
> ***Appearance*** : Squat weak build, with hazel eyes and messy white hair. Their face has small scar on left cheek 
>
> ***Characteristics*** :  Finishes others' sentences
>
> ***Personality*** :  Doleful
>
> ***Trait*** : I am horribly, horribly awkward in social situations.
>
> ***Ideal*** : Greater Good. My gifts are meant to be shared with all, not used for my own benefit. (Good)
{ .ownerDescription }



