---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Jeweler Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Blue Steal Ring 
services: services
owner: Pohl (Halfling)
---
> [!oRPG-Layout] 
> #  The Blue Steal Ring  (Jeweler/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Pohl (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Average |

##  The Blue Steal Ring  owned by [[Pohl]] (Halfling)
*Jeweler / Crafter*


**Building Description:**  An narrow tall building, with new paint with shingled siding with a front window that has a Steal door with the merchants name. The roof is shingled with Beech shingles.  



> ### Owner Description/Background
> ***Appearance*** : Average lean build, with white eyes and messy black hair. Their face has a missing left eye 
>
> ***Characteristics*** :  Spits
>
> ***Personality*** :  Foolhardy
>
> ***Trait*** : I don't pay attention to the risks in a situation. Never tell me the odds.
>
> ***Ideal*** : Honor. If I dishonor myself, I dishonor my whole clan. (Lawful)
{ .ownerDescription }



