---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Innkeeper 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Leopard Inn 
services: services
owner: Bucossi (Elven)
---
> [!oRPG-Layout] 
> #  The Leopard Inn  (Innkeeper/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bucossi (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Average |

##  The Leopard Inn  owned by [[Bucossi]] (Elven)
*Innkeeper / *


**Building Description:**  An building, a Cherry wood with Steal bands door with a Beech frame with brick siding with a missing round window. The roof is thatching made of straw. A Oak pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Tall thin build, with red eyes and messy auburn hair. Their face has large scar on left cheek 
>
> ***Characteristics*** :  Taps feet
>
> ***Personality*** :  Deceitful
>
> ***Trait*** : I quote the sacred texts and proverbs in almost every situation.
>
> ***Ideal*** : Respect. The thing that keeps a ship together is mutual respect between captain and crew. (Good)
{ .ownerDescription }



