---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Rug Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Carpet Dealer 
services: services
owner: Jeruss (Human)
---
> [!oRPG-Layout] 
> #  Carpet Dealer  (Rug Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Jeruss (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Average |

##  Carpet Dealer  owned by [[Jeruss]] (Human)
*Rug Maker / Crafter*


**Building Description:**  An new long two story building, with brick siding. The roof is shingled.  



> ### Owner Description/Background
> ***Appearance*** : Short lean build, with white eyes and short black hair. Their face has acne 
>
> ***Characteristics*** :  Talks with food in mouth
>
> ***Personality*** :  Unsupportive
>
> ***Trait*** : I feel tremendous empathy for all who suffer.
>
> ***Ideal*** : Faith. I trust that my deity will guide my actions. I have faith that if I work hard, things will go well. (Lawful)
{ .ownerDescription }



