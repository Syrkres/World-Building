---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chicken Butcher Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Plucked Thrush 
services: services
owner: Peps (Human)
---
> [!oRPG-Layout] 
> #  The Plucked Thrush  (Chicken Butcher/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Peps (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  The Plucked Thrush  owned by [[Peps]] (Human)
*Chicken Butcher / Cooks*


**Building Description:**  An old two story building, with faded paint stairs leading up to a Beech wood door with brick siding. The roof is timber. A few new Red Oak chests sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Grand athletic build, with green eyes and strange hairstyle grey hair. Their face has nose pierced 
>
> ***Characteristics*** :  Facial tic
>
> ***Personality*** :  Gossip
>
> ***Trait*** : To me, a tavern brawl is a nice way to get to know a new city.
>
> ***Ideal*** : People. I help people who help me--that's what keeps us alive. (Neutral)
{ .ownerDescription }



