---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: WeaponSmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  Mithril Armor 
services: services
owner: Washtub (Elven)
---
> [!oRPG-Layout] 
> #  Mithril Armor  (WeaponSmith/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Washtub (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  Mithril Armor  owned by [[Washtub]] (Elven)
*WeaponSmith / *


**Building Description:**  A old one story building with a smithy attached to the side. An polished anvil sits in outside smithy. A warn Red Oak barrel filled with water, with a Grappling Hook leaning against the base.  



> ### Owner Description/Background
> ***Appearance*** : Tall weak build, with hazel eyes and strange hairstyle grey hair. Their face has large scar across full face 
>
> ***Characteristics*** :  Picks scabs
>
> ***Personality*** :  Irritable
>
> ***Trait*** : I can find common ground between the fiercest enemies, empathizing with them and always working toward peace.
>
> ***Ideal*** : Glory. I must earn glory in battle, for myself and my clan. (Any)
{ .ownerDescription }



