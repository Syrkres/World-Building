---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Glove Merchant Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Glove Hawker 
services: services
owner: Goddale (Human)
---
> [!oRPG-Layout] 
> #  The Glove Hawker  (Glove Merchant/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Goddale (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Low |

##  The Glove Hawker  owned by [[Goddale]] (Human)
*Glove Merchant / Tailor*


**Building Description:**  An new long tall building, with shingled siding. The roof is planked. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall wide build, with red eyes and braided black hair. Their face has a goatee 
>
> ***Characteristics*** :  Refuses to sit in chairs
>
> ***Personality*** :  Enigmatic
>
> ***Trait*** : I can find common ground between the fiercest enemies, empathizing with them and always working toward peace.
>
> ***Ideal*** : Creativity. The world is in need of new ideas and bold action. (Chaotic)
{ .ownerDescription }



