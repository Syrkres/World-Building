---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Potato Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Old Stone Nursery 
services: services
owner: Olias (Halfling)
---
> [!oRPG-Layout] 
> #  Old Stone Nursery  (Farmer - Potato/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Olias (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Above Average |

##  Old Stone Nursery  owned by [[Olias]] (Halfling)
*Farmer - Potato / Farmer*


**Building Description:**  An long building, with faded paint a set of double Steal doors with a Maple frame, with planked siding with a missing round window. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Average fat build, with hazel eyes and very long black hair. Their face has a distinctive nose 
>
> ***Characteristics*** :  Picks at lint or dirt on others' clothes
>
> ***Personality*** :  Rash
>
> ***Trait*** : I'm a born gambler who can't resist taking a risk for a potential payoff.
>
> ***Ideal*** : Might. In life as in war, the stronger force wins. (Evil)
{ .ownerDescription }



