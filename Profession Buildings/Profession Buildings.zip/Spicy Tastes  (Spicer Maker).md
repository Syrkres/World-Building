---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Spicer Maker Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Spicy Tastes 
services: services
owner: Hunjan (Half-Orc)
---
> [!oRPG-Layout] 
> #  Spicy Tastes  (Spicer Maker/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hunjan (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Average |

##  Spicy Tastes  owned by [[Hunjan]] (Half-Orc)
*Spicer Maker / Cooks*


**Building Description:**  An one story building, with new paint with planked siding. The roof is thatching made of grass. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short average build, with green eyes and curly black hair. Their face has a beard 
>
> ***Characteristics*** :  Facial tic
>
> ***Personality*** :  Tactful
>
> ***Trait*** : I...speak...slowly...when talking...to idiots...which...almost...everyone...is...compared ...to me.
>
> ***Ideal*** : Sincerity. There's no good pretending to be something I'm not. (Neutral)
{ .ownerDescription }



