---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Acrobat Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: House
title:  The Dancing Lion 
services: services
owner: Feyer (Human)
---
> [!oRPG-Layout] 
> #  The Dancing Lion  (Acrobat/Entertainer)
> **Structure:** House
> **Resides In:** 
>  **Owner:** Feyer (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  The Dancing Lion  owned by [[Feyer]] (Human)
*Acrobat / Entertainer*


**Building Description:**  An old tall building with brick siding with a front tall window that has a Maple wood with Copper bands door with a Beech frame with the merchants name. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Squat lean build, with red eyes and dreadlocks grey hair. Their face has acne 
>
> ***Characteristics*** :  Taps fingers
>
> ***Personality*** :  Moralistic
>
> ***Trait*** : I sleep with my back to a wall or tree, with everything I own wrapped in a bundle in my arms.
>
> ***Ideal*** : Charity. I always try to help those in need, no matter what the personal cost. (Good)
{ .ownerDescription }



