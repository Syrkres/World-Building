---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Innkeeper 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Boar Inn 
services: services
owner: Haseltine (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Boar Inn  (Innkeeper/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Haseltine (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  The Boar Inn  owned by [[Haseltine]] (Half-Orc)
*Innkeeper / *


**Building Description:**  An two story building, a set of double Ceder wood with Copper bands doors with a Pine frame, with stoned siding. The roof is shingled. A pile of Beech wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short average build, with white eyes and strange hairstyle black hair. Their face is missing teeth 
>
> ***Characteristics*** :  Constantly asks for divine advice
>
> ***Personality*** :  Communicative
>
> ***Trait*** : I'm used to helping out those who aren't as smart as I am, and I patiently explain anything and everything to others.
>
> ***Ideal*** : Fairness. I never target people who can't afford to lose a few coins. (Lawful)
{ .ownerDescription }



