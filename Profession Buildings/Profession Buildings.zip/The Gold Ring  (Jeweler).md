---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Jeweler Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Gold Ring 
services: services
owner: Rorken (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Gold Ring  (Jeweler/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Rorken (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | High |

##  The Gold Ring  owned by [[Rorken]] (Half-Orc)
*Jeweler / Crafter*


**Building Description:**  An narrow one story building, with brick siding. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Normal average build, with white eyes and messy black hair. Their face is missing teeth 
>
> ***Characteristics*** :  Burps
>
> ***Personality*** :  Nettlesome
>
> ***Trait*** : I see omens in every event and action. The gods try to speak to us, we just need to listen.
>
> ***Ideal*** : Charity. I distribute money I acquire to the people who really need it. (Good)
{ .ownerDescription }



