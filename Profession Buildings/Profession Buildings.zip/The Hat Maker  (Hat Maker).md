---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Hat Maker 
services: services
owner: Janis (Human)
---
> [!oRPG-Layout] 
> #  The Hat Maker  (Hat Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Janis (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Above Average |

##  The Hat Maker  owned by [[Janis]] (Human)
*Hat Maker / Tailor*


**Building Description:**  An old long tall building, with faded paint with brick siding with a few short windows. The roof is timber. A pile of Hickory wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Average frail build, with hazel eyes and limp auburn hair. Their face is toothless 
>
> ***Characteristics*** :  Whistles
>
> ***Personality*** :  Serene
>
> ***Trait*** : I have a joke for every occasion, especially occasions where humor is inappropriate.
>
> ***Ideal*** : Freedom. The sea is freedom--the freedom to go anywhere and do anything. (Chaotic)
{ .ownerDescription }



