---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Oak Fields 
services: services
owner: Braavos (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Oak Fields  (Farmer - Cattle Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Braavos (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  The Oak Fields  owned by [[Braavos]] (Half-Elf)
*Farmer - Cattle Herder / Farmer*


**Building Description:**  An old building, with new paint stairs leading up to a set of double Red Oak wood doors with a Ceder frame, with brick siding. The roof is shingled with Beech shingles. A Yellow Birch shed is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Squat anorexic build, with blue eyes and very long black hair. Their face has small scar on right cheek 
>
> ***Characteristics*** :  Flips a coin
>
> ***Personality*** :  Realistic
>
> ***Trait*** : I see omens in every event and action. The gods try to speak to us, we just need to listen.
>
> ***Ideal*** : Glory. I must earn glory in battle, for myself and my clan. (Any)
{ .ownerDescription }



