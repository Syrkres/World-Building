---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sail Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Sail Patcher 
services: services
owner: Graven (Gnome)
---
> [!oRPG-Layout] 
> #  Sail Patcher  (Sail Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Graven (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Low |

##  Sail Patcher  owned by [[Graven]] (Gnome)
*Sail Maker / Crafter*


**Building Description:**  An building, with new paint with brick siding. The roof is thatching made of straw. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short fat build, with hazel eyes and wavy white hair. Their face has eyebrow pierced 
>
> ***Characteristics*** :  Picks scabs
>
> ***Personality*** :  Annoying
>
> ***Trait*** : I was, in fact, raised by wolves.
>
> ***Ideal*** : People. I like seeing the smiles on people's faces when I perform. That's all that matters. (Neutral)
{ .ownerDescription }



