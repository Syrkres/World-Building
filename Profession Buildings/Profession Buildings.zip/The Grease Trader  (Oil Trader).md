---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Oil Trader Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Grease Trader 
services: services
owner: Altos (Elven)
---
> [!oRPG-Layout] 
> #  The Grease Trader  (Oil Trader/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Altos (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | High |

##  The Grease Trader  owned by [[Altos]] (Elven)
*Oil Trader / Offical*


**Building Description:**  An building, with new paint with shingled siding. The roof is planked with Elm planks. A shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short fat build, with brown eyes and thick red hair. Their face is pierced 
>
> ***Characteristics*** :  Tattooed on Head/Face on Chest on Back on Head/Face on Back on Right leg on Back
>
> ***Personality*** :  Coy
>
> ***Trait*** : I like a job well done, especially if I can convince someone else to do it.
>
> ***Ideal*** : Free Thinking. Inquiry and curiosity are the pillars of progress. (Chaotic)
{ .ownerDescription }



