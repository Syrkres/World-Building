---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chicken Butcher Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Plucked Shrike 
services: services
owner: Olias (Elven)
---
> [!oRPG-Layout] 
> #  The Plucked Shrike  (Chicken Butcher/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Olias (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Plucked Shrike  owned by [[Olias]] (Elven)
*Chicken Butcher / Cooks*


**Building Description:**  An old building, with planked siding. The roof is shingled.  



> ### Owner Description/Background
> ***Appearance*** : Average wide build, with brown eyes and well groomed brown hair. Their face is an missing ear 
>
> ***Characteristics*** :  Covered in sores, boils, or a rash
>
> ***Personality*** :  Shrewd
>
> ***Trait*** : I'm willing to listen to every side of an argument before I make my own judgment.
>
> ***Ideal*** : Fairness. No one should get preferential treatment before the law, and no one is above the law. (Lawful)
{ .ownerDescription }



