---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crime Lord 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Black Manual 
services: services
owner: Wyndehall (Dwarf)
---
> [!oRPG-Layout] 
> #  The Black Manual  (Crime Lord/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Wyndehall (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  The Black Manual  owned by [[Wyndehall]] (Dwarf)
*Crime Lord / *


**Building Description:**  An building, with faded paint with brick siding with a front tall window that has a Cherry wood door with a Beech frame with the merchants name. The roof is planked. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall weak build, with blue eyes and very long blond hair. Their face has a broken nose 
>
> ***Characteristics*** :  Always wears expensive clothes
>
> ***Personality*** :  Wisecracking
>
> ***Trait*** : I have a joke for every occasion, especially occasions where humor is inappropriate.
>
> ***Ideal*** : Charity. I steal from the wealthy so that I can help people in need. (Good)
{ .ownerDescription }



