---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Alchemist Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Musk (Earth) Incense 
services: services
owner: Janis (Dwarf)
---
> [!oRPG-Layout] 
> #  The Musk (Earth) Incense  (Alchemist/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Janis (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Below Average |

##  The Musk (Earth) Incense  owned by [[Janis]] (Dwarf)
*Alchemist / Librarian*


**Building Description:**  An old building, with stoned siding. The roof is timber made of Pine.  



> ### Owner Description/Background
> ***Appearance*** : Grand frail build, with blue eyes and braided white hair. Their face is chiseled 
>
> ***Characteristics*** :  Smiles when angry/annoyed
>
> ***Personality*** :  Bitter
>
> ***Trait*** : I enjoy sailing into new ports and making new friends over a flagon of ale.
>
> ***Ideal*** : Aspiration. I seek to prove my self worthy of my god's favor by matching my actions against his or her teachings. (Any)
{ .ownerDescription }



