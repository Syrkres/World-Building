---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Elected Official Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  County Clerks 
services: services
owner: Tobius (Dwarf)
---
> [!oRPG-Layout] 
> #  County Clerks  (Elected Official/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Tobius (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | High |

##  County Clerks  owned by [[Tobius]] (Dwarf)
*Elected Official / Offical*


**Building Description:**  An old building, with shingled siding. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall lean build, with white eyes and straight black hair. Their face is buck-toothed 
>
> ***Characteristics*** :  Peg-legged
>
> ***Personality*** :  Intolerant
>
> ***Trait*** : Whenever I come to a new place, I collect local rumors and spread gossip.
>
> ***Ideal*** : People. I like seeing the smiles on people's faces when I perform. That's all that matters. (Neutral)
{ .ownerDescription }



