---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The new Silver Spear 
services: services
owner: Revere (Dwarf)
---
> [!oRPG-Layout] 
> #  The new Silver Spear  (Antiquities/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Revere (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Below Average |

##  The new Silver Spear  owned by [[Revere]] (Dwarf)
*Antiquities / Offical*


**Building Description:**  An building, with brick siding with a few windows. The roof is thatching made of grass. A Oak shed is attached to the side. A pile of Ceder wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Average lean build, with red eyes and pony-tail auburn hair. Their face has a broken nose 
>
> ***Characteristics*** :  Lazy eyed
>
> ***Personality*** :  Malicious
>
> ***Trait*** : I'm a hopeless romantic, always searching for that 'special someone'.
>
> ***Ideal*** : People. I'm loyal to my friends, not to any ideals, and everyone else can take a trip down the Styx for all I care. (Neutral)
{ .ownerDescription }



