---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wagon Maker 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Broken Wheel 
services: services
owner: Hidalgo (Human)
---
> [!oRPG-Layout] 
> #  The Broken Wheel  (Wagon Maker/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hidalgo (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  The Broken Wheel  owned by [[Hidalgo]] (Human)
*Wagon Maker / *


**Building Description:**  An old narrow building, with new paint with brick siding. The roof is shingled with Oak shingles. A Ceder barrel sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Normal anorexic build, with brown eyes and thinning black hair. Their face is doe-eyed 
>
> ***Characteristics*** :  Loves the sea and ships
>
> ***Personality*** :  Charming
>
> ***Trait*** : I change my mood or my mind as quickly as I change key in a song.
>
> ***Ideal*** : Fairness. I never target people who can't afford to lose a few coins. (Lawful)
{ .ownerDescription }



