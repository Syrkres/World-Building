---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Harness Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Harness Parlor 
services: services
owner: Omahg (Half-Orc)
---
> [!oRPG-Layout] 
> #  Harness Parlor  (Harness Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Omahg (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  Harness Parlor  owned by [[Omahg]] (Half-Orc)
*Harness Maker / Crafter*


**Building Description:**  An long building, with faded paint stairs leading up to a Steal door with a Beech frame with brick siding with a front window that has a sign hanging above with the merchants name. The roof is planked. A pile of Red Oak wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Average frail build, with brown eyes and bald black hair. Their face has acne 
>
> ***Characteristics*** :  Obsessive gambler
>
> ***Personality*** :  Sexual
>
> ***Trait*** : I...speak...slowly...when talking...to idiots...which...almost...everyone...is...compared ...to me.
>
> ***Ideal*** : Destiny. Nothing and no one can steer me away from my higher calling. (Any)
{ .ownerDescription }



