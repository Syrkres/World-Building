---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Blacksmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Gold Chisel 
services: services
owner: Herzinger (Halfling)
---
> [!oRPG-Layout] 
> #  The Gold Chisel  (Blacksmith/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Herzinger (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Low |

##  The Gold Chisel  owned by [[Herzinger]] (Halfling)
*Blacksmith / *


**Building Description:**  An old narrow building, with planked siding with a few shuttered windows. The roof is thatching made of grass. A Pine pergola is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Tall frail build, with hazel eyes and straight black hair. Their face has a broken nose 
>
> ***Characteristics*** :  Facial tic
>
> ***Personality*** :  Passionate
>
> ***Trait*** : I've read every book in the world's greatest libraries--or like to boast that I have.
>
> ***Ideal*** : No Limits. Nothing should fetter the infinite possibility inherent in all existence. (Chaotic)
{ .ownerDescription }



