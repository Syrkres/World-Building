---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weapon Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Light Blue Flail 
services: services
owner: Salemi (Halfling)
---
> [!oRPG-Layout] 
> #  The Light Blue Flail  (Weapon Dealer/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Salemi (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Light Blue Flail  owned by [[Salemi]] (Halfling)
*Weapon Dealer / *


**Building Description:**  An building, stairs leading up to a Iron door with a Elm frame with stoned siding. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Short anorexic build, with blue eyes and curly auburn hair. Their face is squinty 
>
> ***Characteristics*** :  Ornithophobic (afraid of birds)
>
> ***Personality*** :  Inexorable
>
> ***Trait*** : I hide scraps of food and trinkets away in my pockets.
>
> ***Ideal*** : Knowledge. The path to power and self-improvement is through knowledge. (Neutral)
{ .ownerDescription }



