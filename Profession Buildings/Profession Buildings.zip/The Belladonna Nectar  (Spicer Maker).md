---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Spicer Maker Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Belladonna Nectar 
services: services
owner: Roark (Halfling)
---
> [!oRPG-Layout] 
> #  The Belladonna Nectar  (Spicer Maker/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Roark (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Low |

##  The Belladonna Nectar  owned by [[Roark]] (Halfling)
*Spicer Maker / Cooks*


**Building Description:**  An old one story building, with new paint with stoned siding. The roof is planked with Elm planks. A shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Tall wide build, with brown eyes and straight auburn hair. Their face has large scar on right cheek 
>
> ***Characteristics*** :  Paces
>
> ***Personality*** :  Prudish
>
> ***Trait*** : My friends know they can rely on me, no matter what.
>
> ***Ideal*** : Greater Good. My gifts are meant to be shared with all, not used for my own benefit. (Good)
{ .ownerDescription }



