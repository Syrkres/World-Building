---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wood Carver 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Wood Carvings 
services: services
owner: Jepeth (Half-Orc)
---
> [!oRPG-Layout] 
> #  Wood Carvings  (Wood Carver/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Jepeth (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  Wood Carvings  owned by [[Jepeth]] (Half-Orc)
*Wood Carver / *


**Building Description:**  An narrow one story building, a Beech wood with Steal bands door with a Maple frame with stoned siding. The roof is thatching made of straw. A pile of Maple wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Average weak build, with green eyes and pony-tail black hair. Their face is grizzled 
>
> ***Characteristics*** :  Hates quiet pauses in conversations
>
> ***Personality*** :  Quirky
>
> ***Trait*** : I sleep with my back to a wall or tree, with everything I own wrapped in a bundle in my arms.
>
> ***Ideal*** : Power. Solitude and contemplation are paths toward mystical or magical power. (Evil)
{ .ownerDescription }



