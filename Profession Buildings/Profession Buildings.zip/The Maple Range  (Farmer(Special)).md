---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer(Special) Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Maple Range 
services: services
owner: Arel (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Maple Range  (Farmer(Special)/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Arel (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  The Maple Range  owned by [[Arel]] (Half-Orc)
*Farmer(Special) / Farmer*


**Building Description:**  An new narrow two story building, with new paint a Steal door with planked siding with a missing short window. The roof is shingled. A shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Squat frail build, with hazel eyes and thinning auburn hair. Their face is toothless 
>
> ***Characteristics*** :  Entomophobic (afraid of insects)
>
> ***Personality*** :  Madcap
>
> ***Trait*** : I don't part with my money easily and will haggle tirelessly to get the best deal possible.
>
> ***Ideal*** : Logic. Emotions must not cloud our sense of what is right and true, or our logical thinking. (Lawful)
{ .ownerDescription }



