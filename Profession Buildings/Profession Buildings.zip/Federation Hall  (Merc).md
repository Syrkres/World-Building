---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Merc Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Federation Hall 
services: services
owner: Fedevich (Human)
---
> [!oRPG-Layout] 
> #  Federation Hall  (Merc/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Fedevich (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  Federation Hall  owned by [[Fedevich]] (Human)
*Merc / Guard*


**Building Description:**  An new building, stairs leading up to a set of double Pine wood doors with a Pine frame, with planked siding with a few short boarded windows. The roof is shingled with Pine shingles.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall average build, with blue eyes and limp blond hair. Their face has large scar on right cheek 
>
> ***Characteristics*** :  Scarred on Right leg on Left leg on Left arm on Head/Face on Right leg on Left arm on Stomach on Waist
>
> ***Personality*** :  Irreverent
>
> ***Trait*** : I've spent so long in the temple that I have little practical experience dealing with people in the outside world.
>
> ***Ideal*** : Fairness. We all do the work, so we all share in the rewards. (Lawful)
{ .ownerDescription }



