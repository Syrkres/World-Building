---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Large Large Snake Hill Farm 
services: services
owner: Obin (Elven)
---
> [!oRPG-Layout] 
> #  The Large Large Snake Hill Farm  (Farmer/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Obin (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Above Average |

##  The Large Large Snake Hill Farm  owned by [[Obin]] (Elven)
*Farmer / Farmer*


**Building Description:**  An new building, with faded paint with brick siding. The roof is thatching made of straw. A Pine shed structure is to the side. A warn Oak barrel sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Tall fat build, with blue eyes and strange hairstyle red hair. Their face has large scar on right cheek 
>
> ***Characteristics*** :  Short attention span
>
> ***Personality*** :  Humorous
>
> ***Trait*** : I like a job well done, especially if I can convince someone else to do it.
>
> ***Ideal*** : Ideals aren't worth killing for or going to war for. (Neutral)
{ .ownerDescription }



