---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Kettle Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Bronze Kettle 
services: services
owner: Namber (Halfling)
---
> [!oRPG-Layout] 
> #  The Bronze Kettle  (Kettle Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Namber (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  The Bronze Kettle  owned by [[Namber]] (Halfling)
*Kettle Maker / Crafter*


**Building Description:**  An building, with stoned siding with a front shuttered window that has a sign hanging above with the merchants name. The roof is thatching made of straw. A Oak pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short lean build, with blue eyes and braided white hair. Their face is an missing ear 
>
> ***Characteristics*** :  Refuses to let anyone walk behind them
>
> ***Personality*** :  Distracted
>
> ***Trait*** : Whenever I come to a new place, I collect local rumors and spread gossip.
>
> ***Ideal*** : Independence. I am a free spirit--no one tells me what to do. (Chaotic)
{ .ownerDescription }



