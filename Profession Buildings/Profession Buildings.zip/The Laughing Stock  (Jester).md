---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Jester Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Laughing Stock 
services: services
owner: Vaden (Halfling)
---
> [!oRPG-Layout] 
> #  The Laughing Stock  (Jester/Entertainer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Vaden (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  The Laughing Stock  owned by [[Vaden]] (Halfling)
*Jester / Entertainer*


**Building Description:**  An new tall building, with stoned siding. The roof is planked with Elm planks.  



> ### Owner Description/Background
> ***Appearance*** : Tall fat build, with hazel eyes and bald black hair. Their face has small scar 
>
> ***Characteristics*** :  Unexplained dislike for certain organization
>
> ***Personality*** :  Whimsical
>
> ***Trait*** : Nothing can shake my optimistic attitude.
>
> ***Ideal*** : Power. Knowledge is the path to power and domination. (Evil)
{ .ownerDescription }



