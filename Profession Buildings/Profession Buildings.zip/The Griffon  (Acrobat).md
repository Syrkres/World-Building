---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Acrobat Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: House
title:  The Griffon 
services: services
owner: Emi (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Griffon  (Acrobat/Entertainer)
> **Structure:** House
> **Resides In:** 
>  **Owner:** Emi (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  The Griffon  owned by [[Emi]] (Half-Elf)
*Acrobat / Entertainer*


**Building Description:**  An long building with faded paint and with planked siding. The roof is planked. A Pine shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Squat strong build, with white eyes and long black hair. Their face has no eyebrows 
>
> ***Characteristics*** :  Bites lips
>
> ***Personality*** :  Irritable
>
> ***Trait*** : I'm rude to people who lack my commitment to hard work and fair play.
>
> ***Ideal*** : Independence. When people follow orders blindly they embrace a kind of tyranny. (Chaotic)
{ .ownerDescription }



