---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Acrobat Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: House
title:  The Boar 
services: services
owner: Perlin (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Boar  (Acrobat/Entertainer)
> **Structure:** House
> **Resides In:** 
>  **Owner:** Perlin (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Average |

##  The Boar  owned by [[Perlin]] (Half-Elf)
*Acrobat / Entertainer*


**Building Description:**  An building with faded paint and with brick siding with a front window that has stairs leading up to a Yellow Birch wood with Bronze bands door with the merchants name. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall thin build, with green eyes and bald grey hair. Their face is grizzled 
>
> ***Characteristics*** :  Laughs at own jokes
>
> ***Personality*** :  Arrogant
>
> ***Trait*** : I'm a snob who looks down on those who can't appreciate fine art.
>
> ***Ideal*** : Aspiration. I'm going to prove that I'm worthy of a better life. (Any)
{ .ownerDescription }



