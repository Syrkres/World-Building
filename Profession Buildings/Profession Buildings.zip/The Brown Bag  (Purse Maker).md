---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Purse Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Brown Bag 
services: services
owner: Benu (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Brown Bag  (Purse Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Benu (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Low |

##  The Brown Bag  owned by [[Benu]] (Half-Elf)
*Purse Maker / Tailor*


**Building Description:**  An building, with stoned siding with a front window that has stairs leading up to a Yellow Birch wood with Iron bands door with the merchants name. The roof is thatched. A pile of Beech wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short wide build, with hazel eyes and greasy auburn hair. Their face has a patch over eye 
>
> ***Characteristics*** :  Blinks constantly
>
> ***Personality*** :  Brave
>
> ***Trait*** : I fall in and out of love easily, and am always pursuing someone.
>
> ***Ideal*** : Charity. I distribute money I acquire to the people who really need it. (Good)
{ .ownerDescription }



