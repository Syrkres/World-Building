---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wood Seller 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Hickory logs 
services: services
owner: Kran (Human)
---
> [!oRPG-Layout] 
> #  Hickory logs  (Wood Seller/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kran (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | High |

##  Hickory logs  owned by [[Kran]] (Human)
*Wood Seller / *


**Building Description:**  An old long building, with faded paint a Copper door with a Yellow Birch frame with brick siding with a front short window that has a sign hanging above with the merchants name. The roof is thatching made of grass. A warn Pine crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Normal athletic build, with blue eyes and thinning brown hair. Their face has no eyebrows 
>
> ***Characteristics*** :  Cracks knuckles
>
> ***Personality*** :  Sarcastic
>
> ***Trait*** : I keep multiple holy symbols on me and invoke whatever deity might come in useful at any given moment.
>
> ***Ideal*** : Freedom. Tyrants must not be allowed to oppress the people. (Chaotic)
{ .ownerDescription }



