---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Tavern
title:  The Lion Guild 
services: services
owner: Pauling (Halfling)
---
> [!oRPG-Layout] 
> #  The Lion Guild  (Barbarian/Guard)
> **Structure:** Tavern
> **Resides In:** 
>  **Owner:** Pauling (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Average |

##  The Lion Guild  owned by [[Pauling]] (Halfling)
*Barbarian / Guard*


**Building Description:**  An new building with stoned siding with a few tall windows. The roof is planked. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short wide build, with red eyes and straight blond hair. Their face has eyebrow pierced 
>
> ***Characteristics*** :  Touches people while talking to them
>
> ***Personality*** :  Flamboyant
>
> ***Trait*** : The first thing I do in a new place is note the locations of everything valuable--or where such things could be hidden.
>
> ***Ideal*** : Fairness. We all do the work, so we all share in the rewards. (Lawful)
{ .ownerDescription }



