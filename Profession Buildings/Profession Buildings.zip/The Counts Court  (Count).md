---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Count Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Counts Court 
services: services
owner: Adderfeld (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Counts Court  (Count/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Adderfeld (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Below Average |

##  The Counts Court  owned by [[Adderfeld]] (Half-Orc)
*Count / Offical*


**Building Description:**  An old long one story building, with brick siding. The roof is shingled with Yellow Birch shingles. A shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short lean build, with green eyes and bald black hair. Their face has a patch over right eye 
>
> ***Characteristics*** :  Cracks knuckles
>
> ***Personality*** :  Active
>
> ***Trait*** : I sleep with my back to a wall or tree, with everything I own wrapped in a bundle in my arms.
>
> ***Ideal*** : Respect. People deserve to be treated with dignity and respect. (Good)
{ .ownerDescription }



