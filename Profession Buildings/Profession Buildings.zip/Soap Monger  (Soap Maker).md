---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Soap Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Soap Monger 
services: services
owner: Philmore (Elven)
---
> [!oRPG-Layout] 
> #  Soap Monger  (Soap Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Philmore (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  Soap Monger  owned by [[Philmore]] (Elven)
*Soap Maker / Crafter*


**Building Description:**  An building, with faded paint with stoned siding. The roof is thatching made of grass. A shed is attached to the side. A few Hickory barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Grand frail build, with blue eyes and strange hairstyle grey hair. Their face is missing teeth 
>
> ***Characteristics*** :  Body piercings on Head/Face on Left leg on Head/Face on Right leg on Left leg on Chest on Waist on Waist on Waist
>
> ***Personality*** :  Flippant
>
> ***Trait*** : I always want to know how things work and what makes people tick.
>
> ***Ideal*** : Greater Good. It is each person's responsibility to make the most happiness for the whole tribe. (Good)
{ .ownerDescription }



