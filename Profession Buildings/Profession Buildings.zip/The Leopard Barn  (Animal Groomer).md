---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Stables
title:  The Leopard Barn 
services: services
owner: Ziesmer (Elven)
---
> [!oRPG-Layout] 
> #  The Leopard Barn  (Animal Groomer/Entertainer)
> **Structure:** Stables
> **Resides In:** 
>  **Owner:** Ziesmer (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | High |

##  The Leopard Barn  owned by [[Ziesmer]] (Elven)
*Animal Groomer / Entertainer*


**Building Description:**  An one story building with faded paint and with planked siding with a missing short window. The roof is timber made of Ceder.  



> ### Owner Description/Background
> ***Appearance*** : Extra short frail build, with red eyes and strange hairstyle red hair. Their face has stained teeth 
>
> ***Characteristics*** :  Reads constantly, especially when inappropriate
>
> ***Personality*** :  Enigmatic
>
> ***Trait*** : I keep multiple holy symbols on me and invoke whatever deity might come in useful at any given moment.
>
> ***Ideal*** : People. I like seeing the smiles on people's faces when I perform. That's all that matters. (Neutral)
{ .ownerDescription }



