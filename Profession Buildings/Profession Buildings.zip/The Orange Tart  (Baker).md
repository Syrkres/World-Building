---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Orange Tart 
services: services
owner: Aemos (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Orange Tart  (Baker/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Aemos (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Orange Tart  owned by [[Aemos]] (Half-Orc)
*Baker / Cooks*


**Building Description:**  An old two story building, with new paint stairs leading up to a set of double Bronze doors, with stoned siding with a front window that has a sign hanging above with the merchants name. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Tall fat build, with hazel eyes and very long grey hair. Their face has no eyebrows 
>
> ***Characteristics*** :  Jumps conversation topics
>
> ***Personality*** :  Distraught
>
> ***Trait*** : I always want to know how things work and what makes people tick.
>
> ***Ideal*** : Might. In life as in war, the stronger force wins. (Evil)
{ .ownerDescription }



