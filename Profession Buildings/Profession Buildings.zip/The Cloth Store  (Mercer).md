---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Mercer Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Cloth Store 
services: services
owner: Altos (Dwarf)
---
> [!oRPG-Layout] 
> #  The Cloth Store  (Mercer/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Altos (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Average |

##  The Cloth Store  owned by [[Altos]] (Dwarf)
*Mercer / Tailor*


**Building Description:**  An long one story building, with new paint a set of double Cherry wood with Iron bands doors, with stoned siding with a few shuttered windows. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Normal frail build, with red eyes and straight white hair. Their face has a missing eye 
>
> ***Characteristics*** :  Nervous eye twitch
>
> ***Personality*** :  Vague
>
> ***Trait*** : I can find common ground between the fiercest enemies, empathizing with them and always working toward peace.
>
> ***Ideal*** : Glory. I must earn glory in battle, for myself and my clan. (Any)
{ .ownerDescription }



