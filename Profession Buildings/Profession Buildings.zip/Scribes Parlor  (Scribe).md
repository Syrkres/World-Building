---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Scribe 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Scribes Parlor 
services: services
owner: Uclid (Dwarf)
---
> [!oRPG-Layout] 
> #  Scribes Parlor  (Scribe/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Uclid (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | High |

##  Scribes Parlor  owned by [[Uclid]] (Dwarf)
*Scribe / *


**Building Description:**  An old long tall building, with faded paint with shingled siding with a missing window. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Average anorexic build, with hazel eyes and long red hair. Their face has a patch over right eye 
>
> ***Characteristics*** :  Wears hat or hood
>
> ***Personality*** :  Impatient
>
> ***Trait*** : I believe that everything worth doing is worth doing right. I can't help it--I'm a perfectionist.
>
> ***Ideal*** : Faith. I trust that my deity will guide my actions. I have faith that if I work hard, things will go well. (Lawful)
{ .ownerDescription }



