---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Goat Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Cursed Meadows 
services: services
owner: Comminos (Human)
---
> [!oRPG-Layout] 
> #  The Cursed Meadows  (Farmer - Goat Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Comminos (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Low |

##  The Cursed Meadows  owned by [[Comminos]] (Human)
*Farmer - Goat Herder / Farmer*


**Building Description:**  An old one story building, with brick siding with a front tall window that has a painted sign hanging above with the merchants name. The roof is thatched. A shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Squat anorexic build, with white eyes and limp blond hair. Their face has large scar on left cheek 
>
> ***Characteristics*** :  Ornithophobic (afraid of birds)
>
> ***Personality*** :  Obtuse
>
> ***Trait*** : I am always calm, no matter what the situation. I never raise my voice or let my emotions control me.
>
> ***Ideal*** : Aspiration. I seek to prove my self worthy of my god's favor by matching my actions against his or her teachings. (Any)
{ .ownerDescription }



