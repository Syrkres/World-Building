---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Merc Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Company Hall 
services: services
owner: Gundrun (Half-Orc)
---
> [!oRPG-Layout] 
> #  Company Hall  (Merc/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Gundrun (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  Company Hall  owned by [[Gundrun]] (Half-Orc)
*Merc / Guard*


**Building Description:**  An new narrow building, with faded paint a set of double Iron doors, with planked siding with a missing window. The roof is planked. A few Yellow Birch barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Short anorexic build, with brown eyes and braided grey hair. Their face has a patch over right eye 
>
> ***Characteristics*** :  Clicks tongue
>
> ***Personality*** :  Neurotic
>
> ***Trait*** : When I set my mind to something, I follow through no matter what gets in my way.
>
> ***Ideal*** : Fairness. I never target people who can't afford to lose a few coins. (Lawful)
{ .ownerDescription }



