---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Teamster Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Group Hall 
services: services
owner: Irlam (Dwarf)
---
> [!oRPG-Layout] 
> #  Group Hall  (Teamster/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Irlam (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  Group Hall  owned by [[Irlam]] (Dwarf)
*Teamster / Professional*


**Building Description:**  An tall building, with stoned siding with a few shuttered windows. The roof is shingled.  



> ### Owner Description/Background
> ***Appearance*** : Grand athletic build, with brown eyes and thinning grey hair. Their face has large ears 
>
> ***Characteristics*** :  Sneers
>
> ***Personality*** :  Helpful
>
> ***Trait*** : I ask a lot of questions.
>
> ***Ideal*** : Might. The strongest are meant to rule. (Evil)
{ .ownerDescription }



