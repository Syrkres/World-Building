---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Mercer Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Textiles are Us 
services: services
owner: Singeri (Elven)
---
> [!oRPG-Layout] 
> #  Textiles are Us  (Mercer/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Singeri (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | High |

##  Textiles are Us  owned by [[Singeri]] (Elven)
*Mercer / Tailor*


**Building Description:**  An one story building, with faded paint with brick siding with a missing window. The roof is timber.  



> ### Owner Description/Background
> ***Appearance*** : Short fat build, with red eyes and wiry auburn hair. Their face is squinty 
>
> ***Characteristics*** :  Interrupts others
>
> ***Personality*** :  Flippant
>
> ***Trait*** : I miss-quote the sacred texts and proverbs in almost every situation.
>
> ***Ideal*** : Respect. Respect is due to me because of my position, but all people regardless of station deserve to be treated with dignity. (Good)
{ .ownerDescription }



