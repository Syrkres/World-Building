---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chicken Butcher Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Plucked Jay 
services: services
owner: Logspitter (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Plucked Jay  (Chicken Butcher/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Logspitter (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  The Plucked Jay  owned by [[Logspitter]] (Half-Elf)
*Chicken Butcher / Cooks*


**Building Description:**  An new building, with new paint a set of double Oak wood doors with a Maple frame, with brick siding with a front broken window that has stairs leading up to a Oak wood door with the merchants name. The roof is thatching made of grass. A Cherry pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short athletic build, with blue eyes and thick blond hair. Their face has a broken nose 
>
> ***Characteristics*** :  Covered in sores, boils, or a rash
>
> ***Personality*** :  Loquacious
>
> ***Trait*** : I get bitter if I'm not the center of attention.
>
> ***Ideal*** : Greed. I'm only in it for the money. (Evil)
{ .ownerDescription }



