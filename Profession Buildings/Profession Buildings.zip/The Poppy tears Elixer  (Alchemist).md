---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Alchemist Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Poppy tears Elixer 
services: services
owner: Efe (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Poppy tears Elixer  (Alchemist/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Efe (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  The Poppy tears Elixer  owned by [[Efe]] (Half-Orc)
*Alchemist / Librarian*


**Building Description:**  An building, with faded paint stairs leading up to a Elm wood door with a Hickory frame with shingled siding. The roof is thatched. A Pine shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand thin build, with green eyes and short auburn hair. Their face has a patch over eye 
>
> ***Characteristics*** :  If unable to recall word, stops conversation and will not give up until can finally remember it
>
> ***Personality*** :  Contrary
>
> ***Trait*** : I pocket anything I see that might have some value.
>
> ***Ideal*** : Tradition. The ancient traditions of worship and sacrifice must be preserved and upheld. (Lawful)
{ .ownerDescription }



