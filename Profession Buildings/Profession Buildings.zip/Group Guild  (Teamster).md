---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Teamster Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Group Guild 
services: services
owner: Lavina (Dwarf)
---
> [!oRPG-Layout] 
> #  Group Guild  (Teamster/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Lavina (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Below Average |

##  Group Guild  owned by [[Lavina]] (Dwarf)
*Teamster / Professional*


**Building Description:**  An new building, with new paint a Hickory wood door with a Cherry frame with brick siding. The roof is planked. A shed structure is to the side. A pile of Beech wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Tall strong build, with brown eyes and streaked red hair. Their face is pock-marked 
>
> ***Characteristics*** :  Wears only jewelry of one type of metal
>
> ***Personality*** :  Fatalistic
>
> ***Trait*** : I get bored easily. When am I going to get on with my destiny.
>
> ***Ideal*** : Tradition. The ancient traditions of worship and sacrifice must be preserved and upheld. (Lawful)
{ .ownerDescription }



