---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Ship Builder 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Shipbuilders 
services: services
owner: Forten (Elven)
---
> [!oRPG-Layout] 
> #  Shipbuilders  (Ship Builder/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Forten (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  Shipbuilders  owned by [[Forten]] (Elven)
*Ship Builder / *


**Building Description:**  An one story building, with brick siding with a front broken window that has a painted sign hanging above with the merchants name. The roof is timber made of Red Oak. A few Beech chests sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Short weak build, with blue eyes and thinning blond hair. Their face is missing teeth 
>
> ***Characteristics*** :  Plays with hair
>
> ***Personality*** :  Miserly
>
> ***Trait*** : Despite my birth, I do not place myself above other folk. We all have the same blood.
>
> ***Ideal*** : Redemption. There's a spark of good in everyone. (Good)
{ .ownerDescription }



