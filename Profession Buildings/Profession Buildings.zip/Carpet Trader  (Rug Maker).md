---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Rug Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Carpet Trader 
services: services
owner: Hadouch (Dwarf)
---
> [!oRPG-Layout] 
> #  Carpet Trader  (Rug Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hadouch (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Low |

##  Carpet Trader  owned by [[Hadouch]] (Dwarf)
*Rug Maker / Crafter*


**Building Description:**  An long one story building, with faded paint a set of double Beech wood with Copper bands doors, with stoned siding. The roof is thatched. A shed is attached to the side. A few new Red Oak barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Average strong build, with green eyes and very long grey hair. Their face has a beard 
>
> ***Characteristics*** :  Lazy eyed
>
> ***Personality*** :  Rude
>
> ***Trait*** : I'm rude to people who lack my commitment to hard work and fair play.
>
> ***Ideal*** : Family. Blood runs thicker than water. (Any)
{ .ownerDescription }



