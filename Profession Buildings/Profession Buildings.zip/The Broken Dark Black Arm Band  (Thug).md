---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thug Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Broken Dark Black Arm Band 
services: services
owner: Sonor (Halfling)
---
> [!oRPG-Layout] 
> #  The Broken Dark Black Arm Band  (Thug/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Sonor (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Above Average |

##  The Broken Dark Black Arm Band  owned by [[Sonor]] (Halfling)
*Thug / Guard*


**Building Description:**  An building, with faded paint a Iron door with a Pine frame with shingled siding. The roof is thatching made of straw. A shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal fat build, with red eyes and straight auburn hair. Their face is an missing ear 
>
> ***Characteristics*** :  Freckled
>
> ***Personality*** :  Indomitable
>
> ***Trait*** : I miss-quote the sacred texts and proverbs in almost every situation.
>
> ***Ideal*** : Logic. Emotions must not cloud our sense of what is right and true, or our logical thinking. (Lawful)
{ .ownerDescription }



