---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Large Bovines Range 
services: services
owner: Oedekerk (Halfling)
---
> [!oRPG-Layout] 
> #  The Large Bovines Range  (Farmer - Cattle Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Oedekerk (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  The Large Bovines Range  owned by [[Oedekerk]] (Halfling)
*Farmer - Cattle Herder / Farmer*


**Building Description:**  An new long tall building, with new paint stairs leading up to a Yellow Birch wood door with a Beech frame with shingled siding with a few tall broken windows. The roof is shingled with Hickory shingles.  



> ### Owner Description/Background
> ***Appearance*** : Normal wide build, with hazel eyes and thick black hair. Their face has a missing eye 
>
> ***Characteristics*** :  Hacking cough
>
> ***Personality*** :  Scared
>
> ***Trait*** : I hide scraps of food and trinkets away in my pockets.
>
> ***Ideal*** : People. I'm committed to the people I care about, not to ideals. (Neutral)
{ .ownerDescription }



