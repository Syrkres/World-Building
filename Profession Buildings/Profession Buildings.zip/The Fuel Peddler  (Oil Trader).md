---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Oil Trader Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Fuel Peddler 
services: services
owner: Catlett (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Fuel Peddler  (Oil Trader/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Catlett (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  The Fuel Peddler  owned by [[Catlett]] (Half-Elf)
*Oil Trader / Offical*


**Building Description:**  An new building, with new paint a Red Oak wood door with a Beech frame with stoned siding. The roof is thatching made of grass. A Cherry shed structure is to the side. A few new Hickory chests sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Grand wide build, with blue eyes and bald auburn hair. Their face has large scar 
>
> ***Characteristics*** :  Lazy eyed
>
> ***Personality*** :  Accusative
>
> ***Trait*** : I once ran twenty-five miles without stopping to warn my clan of an approaching orc horde. I'd do it again if I had to.
>
> ***Ideal*** : Greed. I'm only in it for the money and fame. (Evil)
{ .ownerDescription }



