---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wood Seller 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Home Heating 
services: services
owner: Gibberwish (Half-Orc)
---
> [!oRPG-Layout] 
> #  Home Heating  (Wood Seller/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Gibberwish (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  Home Heating  owned by [[Gibberwish]] (Half-Orc)
*Wood Seller / *


**Building Description:**  An tall building, stairs leading up to a Bronze door with a Elm frame with brick siding. The roof is shingled with Elm shingles.  



> ### Owner Description/Background
> ***Appearance*** : Short weak build, with red eyes and well groomed white hair. Their face has large scar on left cheek 
>
> ***Characteristics*** :  Touches people while talking to them
>
> ***Personality*** :  Mousy
>
> ***Trait*** : I miss-quote the sacred texts and proverbs in almost every situation.
>
> ***Ideal*** : Responsibility. I do what I must and obey just authority. (Lawful)
{ .ownerDescription }



