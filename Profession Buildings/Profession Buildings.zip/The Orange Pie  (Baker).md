---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Orange Pie 
services: services
owner: Remer (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Orange Pie  (Baker/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Remer (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | High |

##  The Orange Pie  owned by [[Remer]] (Half-Elf)
*Baker / Cooks*


**Building Description:**  An old narrow building, stairs leading up to a Beech wood door with stoned siding with a missing window. The roof is thatching made of grass. A Maple pergola is attached to the side. A few old Oak barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Tall fat build, with green eyes and curly red hair. Their face has large scar across full face 
>
> ***Characteristics*** :  Plays with own jewelry
>
> ***Personality*** :  Lethargic
>
> ***Trait*** : I'm oblivious to etiquette and social expectations.
>
> ***Ideal*** : Freedom. Chains are meant to be broken, as are those who would forge them. (Chaotic)
{ .ownerDescription }



