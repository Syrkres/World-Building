---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Duke Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Osenga's Villa 
services: services
owner: Osenga (Dwarf)
---
> [!oRPG-Layout] 
> #  Osenga's Villa  (Duke/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Osenga (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  Osenga's Villa  owned by [[Osenga]] (Dwarf)
*Duke / Offical*


**Building Description:**  An new building, with faded paint a set of double Red Oak wood doors, with stoned siding. The roof is thatching made of grass. A shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Squat average build, with brown eyes and wavy grey hair. Their face has a missing eye 
>
> ***Characteristics*** :  Wears only jewelry of one type of metal
>
> ***Personality*** :  Unfriendly
>
> ***Trait*** : I'm driven by a wanderlust that led me away from home.
>
> ***Ideal*** : Tradition. The ancient traditions of worship and sacrifice must be preserved and upheld. (Lawful)
{ .ownerDescription }



