---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Apothecary 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Glass Vial 
services: services
owner: Godwyn (Human)
---
> [!oRPG-Layout] 
> #  The Glass Vial  (Apothecary/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Godwyn (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Above Average |

##  The Glass Vial  owned by [[Godwyn]] (Human)
*Apothecary / *


**Building Description:**  An tall building, with new paint with planked siding. The roof is planked with Pine planks. A shed is attached to the side. A warn Beech chest sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short athletic build, with blue eyes and strange hairstyle red hair. Their face has no eyebrows 
>
> ***Characteristics*** :  Sneezes
>
> ***Personality*** :  Optimistic
>
> ***Trait*** : I am intolerant of other faiths and respect (or condemn) the worship of other gods.
>
> ***Ideal*** : Independence. I must prove that I can handle myself without the coddling of my family. (Chaotic)
{ .ownerDescription }



