---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crime Lord 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Black Tome 
services: services
owner: Dashnaw (Dwarf)
---
> [!oRPG-Layout] 
> #  The Black Tome  (Crime Lord/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Dashnaw (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Above Average |

##  The Black Tome  owned by [[Dashnaw]] (Dwarf)
*Crime Lord / *


**Building Description:**  An building, with faded paint with planked siding. The roof is thatching made of straw. A warn Pine crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short anorexic build, with hazel eyes and curly auburn hair. Their face has large scar 
>
> ***Characteristics*** :  Hates quiet pauses in conversations
>
> ***Personality*** :  Modest
>
> ***Trait*** : I'm well known for my work, and I want to make sure everyone appreciates it. I'm always taken aback when people haven't heard of me.
>
> ***Ideal*** : People. I help people who help me--that's what keeps us alive. (Neutral)
{ .ownerDescription }



