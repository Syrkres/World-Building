---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Alchemist Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Dreamers star Elixer 
services: services
owner: Din (Gnome)
---
> [!oRPG-Layout] 
> #  The Dreamers star Elixer  (Alchemist/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Din (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  The Dreamers star Elixer  owned by [[Din]] (Gnome)
*Alchemist / Librarian*


**Building Description:**  An narrow building, stairs leading up to a set of double Pine wood with Steal bands doors, with stoned siding. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall strong build, with white eyes and long red hair. Their face has a patch over left eye 
>
> ***Characteristics*** :  Unable to figure out which color clothes match
>
> ***Personality*** :  Condescending
>
> ***Trait*** : When I set my mind to something, I follow through no matter what gets in my way.
>
> ***Ideal*** : Self-Knowledge. If you know yourself, there're nothing left to know. (Any)
{ .ownerDescription }



