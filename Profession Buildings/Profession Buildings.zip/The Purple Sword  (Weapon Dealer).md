---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weapon Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Purple Sword 
services: services
owner: Sharan (Halfling)
---
> [!oRPG-Layout] 
> #  The Purple Sword  (Weapon Dealer/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Sharan (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Below Average |

##  The Purple Sword  owned by [[Sharan]] (Halfling)
*Weapon Dealer / *


**Building Description:**  An one story building, with faded paint with brick siding with a missing window. The roof is timber.  



> ### Owner Description/Background
> ***Appearance*** : Extra short frail build, with brown eyes and wiry white hair. Their face has a patch over left eye 
>
> ***Characteristics*** :  Interrupts others
>
> ***Personality*** :  Narrow-minded
>
> ***Trait*** : I face problems head-on. A simple direct solution is the best path to success.
>
> ***Ideal*** : Nature. The natural world is more important than all the constructs of civilization. (Neutral)
{ .ownerDescription }



