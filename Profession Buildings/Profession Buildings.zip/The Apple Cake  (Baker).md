---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Apple Cake 
services: services
owner: Bequin (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Apple Cake  (Baker/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bequin (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | High |

##  The Apple Cake  owned by [[Bequin]] (Half-Elf)
*Baker / Cooks*


**Building Description:**  An building, stairs leading up to a Iron door with shingled siding. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Squat average build, with red eyes and pony-tail auburn hair. Their face has eyebrow pierced 
>
> ***Characteristics*** :  Urinates frequently
>
> ***Personality*** :  Patient
>
> ***Trait*** : I'm haunted by memories of war. I can't get the images of violence out of my mind.
>
> ***Ideal*** : Charity. I steal from the wealthy so that I can help people in need. (Good)
{ .ownerDescription }



