---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Goat Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Farm 
services: services
owner: Gagel (Elven)
---
> [!oRPG-Layout] 
> #  The Farm  (Farmer - Goat Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Gagel (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | High |

##  The Farm  owned by [[Gagel]] (Elven)
*Farmer - Goat Herder / Farmer*


**Building Description:**  An new building, stairs leading up to a set of double Hickory wood doors, with shingled siding. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Short anorexic build, with red eyes and well groomed red hair. Their face has large ears 
>
> ***Characteristics*** :  Shivers
>
> ***Personality*** :  Cavalier
>
> ***Trait*** : I watch over my friends as if they were a litter of newborn pups.
>
> ***Ideal*** : Sincerity. There's no good pretending to be something I'm not. (Neutral)
{ .ownerDescription }



