---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Hat Hawker 
services: services
owner: Eemanda (Dwarf)
---
> [!oRPG-Layout] 
> #  The Hat Hawker  (Hat Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Eemanda (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | High |

##  The Hat Hawker  owned by [[Eemanda]] (Dwarf)
*Hat Maker / Tailor*


**Building Description:**  An new narrow tall building, with new paint with planked siding with a missing window. The roof is shingled. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal frail build, with white eyes and thick grey hair. Their face is an missing ear 
>
> ***Characteristics*** :  Has nightmares
>
> ***Personality*** :  Kind
>
> ***Trait*** : I...speak...slowly...when talking...to idiots...which...almost...everyone...is...compared ...to me.
>
> ***Ideal*** : Respect. All people, rich or poor, deserve respect. (Good)
{ .ownerDescription }



