---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Acrobat Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: House
title:  The Fyling Wolf 
services: services
owner: Brubaker (Human)
---
> [!oRPG-Layout] 
> #  The Fyling Wolf  (Acrobat/Entertainer)
> **Structure:** House
> **Resides In:** 
>  **Owner:** Brubaker (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  The Fyling Wolf  owned by [[Brubaker]] (Human)
*Acrobat / Entertainer*


**Building Description:**  An long building with brick siding. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Extra short average build, with brown eyes and streaked grey hair. Their face has a missing right eye 
>
> ***Characteristics*** :  Needs story before sleeping
>
> ***Personality*** :  Lethargic
>
> ***Trait*** : I'm rude to people who lack my commitment to hard work and fair play.
>
> ***Ideal*** : Might. The strongest are meant to rule. (Evil)
{ .ownerDescription }



