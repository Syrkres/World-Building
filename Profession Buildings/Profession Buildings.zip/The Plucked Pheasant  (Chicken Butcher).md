---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chicken Butcher Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Plucked Pheasant 
services: services
owner: Commodus (Gnome)
---
> [!oRPG-Layout] 
> #  The Plucked Pheasant  (Chicken Butcher/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Commodus (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Below Average |

##  The Plucked Pheasant  owned by [[Commodus]] (Gnome)
*Chicken Butcher / Cooks*


**Building Description:**  An new building, with faded paint stairs leading up to a Copper door with a Elm frame with brick siding. The roof is timber made of Hickory. A shed is attached to the side. A few old Red Oak barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Average strong build, with hazel eyes and very long white hair. Their face has a goatee 
>
> ***Characteristics*** :  Enjoys own body odor
>
> ***Personality*** :  Proud
>
> ***Trait*** : When I set my mind to something, I follow through no matter what gets in my way.
>
> ***Ideal*** : Power. I hope to one day rise to the top of my faith's religious hierarchy. (Lawful)
{ .ownerDescription }



