---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The old Chair 
services: services
owner: Jaidyn (Gnome)
---
> [!oRPG-Layout] 
> #  The old Chair  (Antiquities/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Jaidyn (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  The old Chair  owned by [[Jaidyn]] (Gnome)
*Antiquities / Offical*


**Building Description:**  An long building, with faded paint with shingled siding. The roof is shingled with Beech shingles.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall average build, with hazel eyes and thinning white hair. Their face has a beard 
>
> ***Characteristics*** :  Hallucinates
>
> ***Personality*** :  Dramatic
>
> ***Trait*** : The best way to get me to do something is to tell me I can't do it.
>
> ***Ideal*** : People. I'm committed to my crewmates, not to ideals. (Neutral)
{ .ownerDescription }



