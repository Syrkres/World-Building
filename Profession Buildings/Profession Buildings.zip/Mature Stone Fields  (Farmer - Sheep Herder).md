---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Sheep Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Mature Stone Fields 
services: services
owner: Caelun (Halfling)
---
> [!oRPG-Layout] 
> #  Mature Stone Fields  (Farmer - Sheep Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Caelun (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Above Average |

##  Mature Stone Fields  owned by [[Caelun]] (Halfling)
*Farmer - Sheep Herder / Farmer*


**Building Description:**  An new tall building, with shingled siding with a front boarded window that has a Bronze door with a Ceder frame with the merchants name. The roof is thatching made of straw. A few Hickory barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Short weak build, with hazel eyes and greasy brown hair. Their face has large ears 
>
> ***Characteristics*** :  Hiccoughs
>
> ***Personality*** :  Proper
>
> ***Trait*** : I'm a snob who looks down on those who can't appreciate fine art.
>
> ***Ideal*** : Logic. Emotions must not cloud our logical thinking. (Lawful)
{ .ownerDescription }



