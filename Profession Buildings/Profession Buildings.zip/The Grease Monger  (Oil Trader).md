---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Oil Trader Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Grease Monger 
services: services
owner: San (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Grease Monger  (Oil Trader/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** San (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Average |

##  The Grease Monger  owned by [[San]] (Half-Elf)
*Oil Trader / Offical*


**Building Description:**  An long building, with brick siding with a few shuttered windows. The roof is thatching made of straw. A shed structure is to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Average anorexic build, with hazel eyes and thick red hair. Their face has a patch over left eye 
>
> ***Characteristics*** :  Repeats same phrase over and over
>
> ***Personality*** :  Cocky
>
> ***Trait*** : I never pass up a friendly wager.
>
> ***Ideal*** : Self-improvement. The goal of a life of study is the betterment of oneself.
{ .ownerDescription }



