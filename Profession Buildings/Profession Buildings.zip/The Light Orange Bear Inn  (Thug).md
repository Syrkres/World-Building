---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thug Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Light Orange Bear Inn 
services: services
owner: Malahi (Human)
---
> [!oRPG-Layout] 
> #  The Light Orange Bear Inn  (Thug/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Malahi (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  The Light Orange Bear Inn  owned by [[Malahi]] (Human)
*Thug / Guard*


**Building Description:**  An building, with brick siding with a missing window. The roof is shingled. A few old Hickory barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short average build, with green eyes and very long black hair. Their face is toothless 
>
> ***Characteristics*** :  Whistles
>
> ***Personality*** :  Whimsical
>
> ***Trait*** : The best way to get me to do something is to tell me I can't do it.
>
> ***Ideal*** : Freedom. The sea is freedom--the freedom to go anywhere and do anything. (Chaotic)
{ .ownerDescription }



