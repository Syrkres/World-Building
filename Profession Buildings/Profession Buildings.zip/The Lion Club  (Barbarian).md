---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Tavern
title:  The Lion Club 
services: services
owner: Bartelmew (Gnome)
---
> [!oRPG-Layout] 
> #  The Lion Club  (Barbarian/Guard)
> **Structure:** Tavern
> **Resides In:** 
>  **Owner:** Bartelmew (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Low |

##  The Lion Club  owned by [[Bartelmew]] (Gnome)
*Barbarian / Guard*


**Building Description:**  An two story building with faded paint and with planked siding with a few shuttered windows. The roof is shingled. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short wide build, with green eyes and braided white hair. Their face has a moustache 
>
> ***Characteristics*** :  Hallucinates
>
> ***Personality*** :  Poised
>
> ***Trait*** : I'm rude to people who lack my commitment to hard work and fair play.
>
> ***Ideal*** : Nature. The natural world is more important than all the constructs of civilization. (Neutral)
{ .ownerDescription }



