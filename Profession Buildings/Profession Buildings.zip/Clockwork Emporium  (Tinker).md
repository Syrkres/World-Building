---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tinker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Clockwork Emporium 
services: services
owner: Roentgen (Human)
---
> [!oRPG-Layout] 
> #  Clockwork Emporium  (Tinker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Roentgen (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Average |

##  Clockwork Emporium  owned by [[Roentgen]] (Human)
*Tinker / Crafter*


**Building Description:**  An long building, with shingled siding with a missing short window. The roof is thatching made of grass. A Maple shed is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Grand frail build, with blue eyes and thick black hair. Their face has stained teeth 
>
> ***Characteristics*** :  Warts
>
> ***Personality*** :  Dominating
>
> ***Trait*** : I get bored easily. When am I going to get on with my destiny.
>
> ***Ideal*** : Freedom. Tyrants must not be allowed to oppress the people. (Chaotic)
{ .ownerDescription }



