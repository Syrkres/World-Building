---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Chapeau Dealer 
services: services
owner: Afterman (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Chapeau Dealer  (Hat Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Afterman (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  The Chapeau Dealer  owned by [[Afterman]] (Half-Elf)
*Hat Maker / Tailor*


**Building Description:**  An new one story building, with new paint stairs leading up to a Pine wood door with shingled siding. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Grand thin build, with red eyes and streaked auburn hair. Their face has no eyebrows 
>
> ***Characteristics*** :  Taunts foes
>
> ***Personality*** :  Generous
>
> ***Trait*** : I connect everything that happens to me to a grand cosmic plan.
>
> ***Ideal*** : Greed. I will do whatever it takes to become wealthy. (Evil)
{ .ownerDescription }



