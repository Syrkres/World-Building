---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Count Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Roentgen's Court 
services: services
owner: Roentgen (Halfling)
---
> [!oRPG-Layout] 
> #  Roentgen's Court  (Count/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Roentgen (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | High |

##  Roentgen's Court  owned by [[Roentgen]] (Halfling)
*Count / Offical*


**Building Description:**  An building, a set of double Bronze doors, with brick siding. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Extra short frail build, with brown eyes and wiry auburn hair. Their face is chiseled 
>
> ***Characteristics*** :  Wears flamboyant or outlandish clothes
>
> ***Personality*** :  Humorous
>
> ***Trait*** : I keep multiple holy symbols on me and invoke whatever deity might come in useful at any given moment.
>
> ***Ideal*** : Aspiration. I'm determined to make something of myself. (Any)
{ .ownerDescription }



