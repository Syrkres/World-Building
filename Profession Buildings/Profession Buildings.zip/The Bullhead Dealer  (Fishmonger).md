---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Fishmonger Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Bullhead Dealer 
services: services
owner: Bermejo (Halfling)
---
> [!oRPG-Layout] 
> #  The Bullhead Dealer  (Fishmonger/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bermejo (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Above Average |

##  The Bullhead Dealer  owned by [[Bermejo]] (Halfling)
*Fishmonger / Cooks*


**Building Description:**  An long building, with faded paint stairs leading up to a set of double Ceder wood with Steal bands doors with a Beech frame, with shingled siding with a front round window that has a painted sign hanging above with the merchants name. The roof is shingled. A pergola is attached to the side. A pile of Cherry wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall fat build, with brown eyes and short white hair. Their face has a bushy eyebrows 
>
> ***Characteristics*** :  Narcoleptic
>
> ***Personality*** :  Depraved
>
> ***Trait*** : I face problems head-on. A simple direct solution is the best path to success.
>
> ***Ideal*** : No Limits. Nothing should fetter the infinite possibility inherent in all existence. (Chaotic)
{ .ownerDescription }



