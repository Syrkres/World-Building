---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Pastry Maker Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Sweet Dough 
services: services
owner: Crowsfly (Half-Orc)
---
> [!oRPG-Layout] 
> #  Sweet Dough  (Pastry Maker/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Crowsfly (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | High |

##  Sweet Dough  owned by [[Crowsfly]] (Half-Orc)
*Pastry Maker / Cooks*


**Building Description:**  An old building, with faded paint with brick siding with a few tall windows. The roof is timber made of Cherry. A Hickory shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short anorexic build, with hazel eyes and short red hair. Their face is grizzled 
>
> ***Characteristics*** :  Unable to figure out which color clothes match
>
> ***Personality*** :  Hateful
>
> ***Trait*** : I take great pains to always look my best and follow the latest fashions.
>
> ***Ideal*** : Tradition. The ancient traditions of worship and sacrifice must be preserved and upheld. (Lawful)
{ .ownerDescription }



