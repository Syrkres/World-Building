---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cow Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Goose Hill Range 
services: services
owner: Lores (Gnome)
---
> [!oRPG-Layout] 
> #  The Goose Hill Range  (Farmer - Cow Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Lores (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  The Goose Hill Range  owned by [[Lores]] (Gnome)
*Farmer - Cow Herder / Farmer*


**Building Description:**  An long two story building, with faded paint stairs leading up to a Hickory wood door with brick siding. The roof is thatching made of grass. A shed is attached to the side. A few old Oak chests sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Grand weak build, with blue eyes and curly red hair. Their face has sideburns 
>
> ***Characteristics*** :  Drones on and on while talking
>
> ***Personality*** :  Impetuous
>
> ***Trait*** : I'm full of witty aphorisms and have a proverb for every occasion.
>
> ***Ideal*** : Nature. The natural world is more important than all the constructs of civilization. (Neutral)
{ .ownerDescription }



