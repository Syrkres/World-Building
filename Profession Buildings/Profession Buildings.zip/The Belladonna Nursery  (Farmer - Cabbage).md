---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cabbage Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Belladonna Nursery 
services: services
owner: Goy (Dwarf)
---
> [!oRPG-Layout] 
> #  The Belladonna Nursery  (Farmer - Cabbage/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Goy (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Above Average |

##  The Belladonna Nursery  owned by [[Goy]] (Dwarf)
*Farmer - Cabbage / Farmer*


**Building Description:**  An building, with new paint with stoned siding. The roof is shingled with Elm shingles. A Beech shed structure is to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Tall thin build, with blue eyes and greasy auburn hair. Their face has large scar 
>
> ***Characteristics*** :  Loves children
>
> ***Personality*** :  Dramatic
>
> ***Trait*** : I'm full of inspiring and cautionary tales from my military experience relevant to almost every combat situation.
>
> ***Ideal*** : Fairness. We all do the work, so we all share in the rewards. (Lawful)
{ .ownerDescription }



