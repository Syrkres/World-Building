---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Prince Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Olias's Keep 
services: services
owner: Olias (Half-Orc)
---
> [!oRPG-Layout] 
> #  Olias's Keep  (Prince/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Olias (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  Olias's Keep  owned by [[Olias]] (Half-Orc)
*Prince / Offical*


**Building Description:**  An new tall building, with new paint a Pine wood door with a Elm frame with brick siding with a missing round window. The roof is thatching made of straw. A Ceder shed structure is to the side. A warn Beech crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Tall thin build, with blue eyes and strange hairstyle white hair. Their face has a moustache 
>
> ***Characteristics*** :  Laughs at own jokes
>
> ***Personality*** :  Transparent
>
> ***Trait*** : I idolize a particular hero of my faith and constantly refer to that person's deeds and example.
>
> ***Ideal*** : Freedom. Everyone should be free to pursue his or her livelihood. (Chaotic)
{ .ownerDescription }



