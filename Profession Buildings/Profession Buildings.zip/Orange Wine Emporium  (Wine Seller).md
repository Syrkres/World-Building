---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wine Seller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Orange Wine Emporium 
services: services
owner: Humbolt (Gnome)
---
> [!oRPG-Layout] 
> #  Orange Wine Emporium  (Wine Seller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Humbolt (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  Orange Wine Emporium  owned by [[Humbolt]] (Gnome)
*Wine Seller / Cooks*


**Building Description:**  An new two story building, with planked siding. The roof is timber.  



> ### Owner Description/Background
> ***Appearance*** : Extra short lean build, with white eyes and messy brown hair. Their face has a missing eye 
>
> ***Characteristics*** :  Pathological liar
>
> ***Personality*** :  Friendly
>
> ***Trait*** : Sarcasm and insults are my weapons of choice.
>
> ***Ideal*** : Aspiration. I work hard to be the best there is at my craft. (Any)
{ .ownerDescription }



