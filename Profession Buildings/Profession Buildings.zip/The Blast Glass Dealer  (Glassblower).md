---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Glassblower Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Blast Glass Dealer 
services: services
owner: Milne (Human)
---
> [!oRPG-Layout] 
> #  The Blast Glass Dealer  (Glassblower/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Milne (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | High |

##  The Blast Glass Dealer  owned by [[Milne]] (Human)
*Glassblower / Crafter*


**Building Description:**  An building, with brick siding. The roof is timber made of Pine. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall athletic build, with blue eyes and thinning auburn hair. Their face has small scar on left cheek 
>
> ***Characteristics*** :  Exaggerates
>
> ***Personality*** :  Agreeable
>
> ***Trait*** : I'm confident in my own abilities and do what I can to instill confidence in others.
>
> ***Ideal*** : Power. Solitude and contemplation are paths toward mystical or magical power. (Evil)
{ .ownerDescription }



