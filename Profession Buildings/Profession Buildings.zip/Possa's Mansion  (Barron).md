---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barron Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Townhall
title:  Possa's Mansion 
services: services
owner: Possa (Human)
---
> [!oRPG-Layout] 
> #  Possa's Mansion  (Barron/Offical)
> **Structure:** Townhall
> **Resides In:** 
>  **Owner:** Possa (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Average |

##  Possa's Mansion  owned by [[Possa]] (Human)
*Barron / Offical*


**Building Description:**  An new narrow tall building with planked siding with a front round window that has a sign hanging above with the merchants name. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall frail build, with red eyes and curly red hair. Their face is pock-marked 
>
> ***Characteristics*** :  Aversion to certain kind of food
>
> ***Personality*** :  Irreverent
>
> ***Trait*** : I fall in and out of love easily, and am always pursuing someone.
>
> ***Ideal*** : Logic. Emotions must not cloud our sense of what is right and true, or our logical thinking. (Lawful)
{ .ownerDescription }



