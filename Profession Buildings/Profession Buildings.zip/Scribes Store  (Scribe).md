---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Scribe 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Scribes Store 
services: services
owner: Jeruss (Dwarf)
---
> [!oRPG-Layout] 
> #  Scribes Store  (Scribe/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Jeruss (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  Scribes Store  owned by [[Jeruss]] (Dwarf)
*Scribe / *


**Building Description:**  An new building, with faded paint a Ceder wood with Bronze bands door with shingled siding. The roof is timber.  



> ### Owner Description/Background
> ***Appearance*** : Normal strong build, with hazel eyes and well groomed brown hair. Their face has a bushy eyebrows 
>
> ***Characteristics*** :  Needs story before sleeping
>
> ***Personality*** :  Enigmatic
>
> ***Trait*** : I've lost too many friends, and I'm slow to make new ones.
>
> ***Ideal*** : People. I help people who help me--that's what keeps us alive. (Neutral)
{ .ownerDescription }



