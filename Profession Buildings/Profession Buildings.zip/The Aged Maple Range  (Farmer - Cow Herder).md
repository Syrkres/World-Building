---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cow Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Aged Maple Range 
services: services
owner: Rhizor (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Aged Maple Range  (Farmer - Cow Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Rhizor (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Average |

##  The Aged Maple Range  owned by [[Rhizor]] (Half-Orc)
*Farmer - Cow Herder / Farmer*


**Building Description:**  An long building, stairs leading up to a set of double Cherry wood with Copper bands doors, with planked siding. The roof is thatching made of straw. A shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Squat lean build, with brown eyes and very long white hair. Their face has a moustache 
>
> ***Characteristics*** :  Plays with hair
>
> ***Personality*** :  Savage
>
> ***Trait*** : I never pass up a friendly wager.
>
> ***Ideal*** : Generosity. My talents were given to me so that I could use them to benefit the world. (Good)
{ .ownerDescription }



