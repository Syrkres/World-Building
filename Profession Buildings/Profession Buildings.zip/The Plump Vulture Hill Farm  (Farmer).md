---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Plump Vulture Hill Farm 
services: services
owner: Rraey (Dwarf)
---
> [!oRPG-Layout] 
> #  The Plump Vulture Hill Farm  (Farmer/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Rraey (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  The Plump Vulture Hill Farm  owned by [[Rraey]] (Dwarf)
*Farmer / Farmer*


**Building Description:**  An new building, a set of double Cherry wood with Steal bands doors with a Red Oak frame, with stoned siding with a few tall boarded windows. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Grand anorexic build, with hazel eyes and messy grey hair. Their face has large scar on left cheek 
>
> ***Characteristics*** :  Taps feet
>
> ***Personality*** :  Proud
>
> ***Trait*** : Nothing can shake my optimistic attitude.
>
> ***Ideal*** : Respect. The thing that keeps a ship together is mutual respect between captain and crew. (Good)
{ .ownerDescription }



