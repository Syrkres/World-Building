---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barron Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Townhall
title:  Lise's Mansion 
services: services
owner: Lise (Dwarf)
---
> [!oRPG-Layout] 
> #  Lise's Mansion  (Barron/Offical)
> **Structure:** Townhall
> **Resides In:** 
>  **Owner:** Lise (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Average |

##  Lise's Mansion  owned by [[Lise]] (Dwarf)
*Barron / Offical*


**Building Description:**  An long tall building with faded paint and with shingled siding. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall strong build, with red eyes and braided brown hair. Their face has a broken nose 
>
> ***Characteristics*** :  Nervous eye twitch
>
> ***Personality*** :  Accusative
>
> ***Trait*** : When I set my mind to something, I follow through no matter what gets in my way.
>
> ***Ideal*** : Fairness. We all do the work, so we all share in the rewards. (Lawful)
{ .ownerDescription }



