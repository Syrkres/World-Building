---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crook Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Pawn Parlor 
services: services
owner: Tritio (Elven)
---
> [!oRPG-Layout] 
> #  Pawn Parlor  (Crook/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Tritio (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  Pawn Parlor  owned by [[Tritio]] (Elven)
*Crook / Guard*


**Building Description:**  An building, with shingled siding. The roof is timber. A pergola is attached to the side. A few new Oak barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Squat average build, with blue eyes and streaked white hair. Their face has a missing eye 
>
> ***Characteristics*** :  Wears only jewelry of one type of metal
>
> ***Personality*** :  Intransigent
>
> ***Trait*** : My eloquent flattery makes everyone I talk to feel like the most wonderful and important person in the world.
>
> ***Ideal*** : Aspiration. I work hard to be the best there is at my craft. (Any)
{ .ownerDescription }



