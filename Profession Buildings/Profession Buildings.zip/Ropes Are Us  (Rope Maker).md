---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Rope Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Ropes Are Us 
services: services
owner: Nabil (Elven)
---
> [!oRPG-Layout] 
> #  Ropes Are Us  (Rope Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Nabil (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Average |

##  Ropes Are Us  owned by [[Nabil]] (Elven)
*Rope Maker / Crafter*


**Building Description:**  An old building, stairs leading up to a set of double Yellow Birch wood doors with a Hickory frame, with stoned siding with a few short windows. The roof is shingled with Beech shingles. A few Red Oak chests sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Grand anorexic build, with hazel eyes and thick grey hair. Their face has large scar on right cheek 
>
> ***Characteristics*** :  Collects teeth/hair/claws of slain opponents
>
> ***Personality*** :  Tactful
>
> ***Trait*** : I feel tremendous empathy for all who suffer.
>
> ***Ideal*** : People. I like seeing the smiles on people's faces when I perform. That's all that matters. (Neutral)
{ .ownerDescription }



