---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Book Binder Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Open Book 
services: services
owner: Manley (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Open Book  (Book Binder/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Manley (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Above Average |

##  The Open Book  owned by [[Manley]] (Half-Elf)
*Book Binder / Professional*


**Building Description:**  An old tall building, stairs leading up to a Yellow Birch wood door with a Hickory frame with planked siding. The roof is thatching made of grass. A shed is attached to the side. A Red Oak chest sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Average frail build, with blue eyes and strange hairstyle auburn hair. Their face has a missing right eye 
>
> ***Characteristics*** :  Warts
>
> ***Personality*** :  Proper
>
> ***Trait*** : I'm oblivious to etiquette and social expectations.
>
> ***Ideal*** : Glory. I must earn glory in battle, for myself and my clan. (Any)
{ .ownerDescription }



