---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Teamster Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Guild Hall 
services: services
owner: Zonn (Human)
---
> [!oRPG-Layout] 
> #  Guild Hall  (Teamster/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Zonn (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  Guild Hall  owned by [[Zonn]] (Human)
*Teamster / Professional*


**Building Description:**  An tall building, with new paint with stoned siding with a missing window. The roof is shingled.  



> ### Owner Description/Background
> ***Appearance*** : Normal average build, with blue eyes and very long black hair. Their face has small scar on right cheek 
>
> ***Characteristics*** :  Repeats same phrase over and over
>
> ***Personality*** :  Frightened
>
> ***Trait*** : I use polysyllabic words to convey the impression of great erudition.
>
> ***Ideal*** : Independence. When people follow orders blindly they embrace a kind of tyranny. (Chaotic)
{ .ownerDescription }



