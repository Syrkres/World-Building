---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Potter Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Pot Store 
services: services
owner: Scarlett (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Pot Store  (Potter/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Scarlett (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  The Pot Store  owned by [[Scarlett]] (Half-Orc)
*Potter / Crafter*


**Building Description:**  An long building, a Beech wood with Copper bands door with brick siding with a front boarded window that has a sign hanging above with the merchants name. The roof is timber. A shed is attached to the side. A pile of Cherry wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short strong build, with green eyes and braided black hair. Their face has a patch over right eye 
>
> ***Characteristics*** :  Excessively clean
>
> ***Personality*** :  Nervous
>
> ***Trait*** : I'm a hopeless romantic, always searching for that 'special someone'.
>
> ***Ideal*** : Self-improvement. The goal of a life of study is the betterment of oneself.
{ .ownerDescription }



