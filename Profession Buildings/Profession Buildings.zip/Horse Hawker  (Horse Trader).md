---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Horse Trader 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Horse Hawker 
services: services
owner: Brixia (Dwarf)
---
> [!oRPG-Layout] 
> #  Horse Hawker  (Horse Trader/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Brixia (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Low |

##  Horse Hawker  owned by [[Brixia]] (Dwarf)
*Horse Trader / *


**Building Description:**  An tall building, with faded paint with brick siding with a front window that has stairs leading up to a Steal door with a Cherry frame with the merchants name. The roof is thatching made of straw. A Oak shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short fat build, with white eyes and streaked blond hair. Their face has large scar across full face 
>
> ***Characteristics*** :  Perfumed
>
> ***Personality*** :  Realistic
>
> ***Trait*** : I like a job well done, especially if I can convince someone else to do it.
>
> ***Ideal*** : Respect. Respect is due to me because of my position, but all people regardless of station deserve to be treated with dignity. (Good)
{ .ownerDescription }



