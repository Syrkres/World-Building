---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Innkeeper 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Rabbit Inn 
services: services
owner: Bonaventure (Dwarf)
---
> [!oRPG-Layout] 
> #  The Rabbit Inn  (Innkeeper/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bonaventure (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Average |

##  The Rabbit Inn  owned by [[Bonaventure]] (Dwarf)
*Innkeeper / *


**Building Description:**  An old building, with shingled siding with a few windows. The roof is thatching made of grass. A shed structure is to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Tall weak build, with red eyes and wavy grey hair. Their face has large scar 
>
> ***Characteristics*** :  Refuses to let anyone walk behind them
>
> ***Personality*** :  Lippy
>
> ***Trait*** : I'm a snob who looks down on those who can't appreciate fine art.
>
> ***Ideal*** : Free Thinking. Inquiry and curiosity are the pillars of progress. (Chaotic)
{ .ownerDescription }



