---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Laborer Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  League Hall 
services: services
owner: Ziesmer (Dwarf)
---
> [!oRPG-Layout] 
> #  League Hall  (Laborer/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Ziesmer (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  League Hall  owned by [[Ziesmer]] (Dwarf)
*Laborer / Professional*


**Building Description:**  An old tall building, stairs leading up to a set of double Elm wood doors with a Ceder frame, with stoned siding with a front shuttered window that has stairs leading up to a Red Oak wood door with a Pine frame with the merchants name. The roof is timber. A Yellow Birch shed structure is to the side. A warn Beech crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Tall lean build, with hazel eyes and wavy red hair. Their face has eyebrow pierced 
>
> ***Characteristics*** :  Swears profusely
>
> ***Personality*** :  Sympathetic
>
> ***Trait*** : I'm convinced that people are always trying to steal my secrets.
>
> ***Ideal*** : Retribution. The rich need to be shown what life and death are like in the gutters. (Evil)
{ .ownerDescription }



