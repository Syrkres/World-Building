---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Librarian Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Classic Manual 
services: services
owner: Bronleewe (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Classic Manual  (Librarian/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bronleewe (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Classic Manual  owned by [[Bronleewe]] (Half-Orc)
*Librarian / Librarian*


**Building Description:**  An building, stairs leading up to a Pine wood door with stoned siding with a missing tall window. The roof is shingled. A shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short frail build, with hazel eyes and long red hair. Their face is pierced 
>
> ***Characteristics*** :  Plays practical jokes
>
> ***Personality*** :  Cautious
>
> ***Trait*** : Nobody stays angry at me or around me for long, since I can defuse any amount of tension.
>
> ***Ideal*** : Friendship. Material goods come and go. Bonds of friendship last forever. (Good)
{ .ownerDescription }



