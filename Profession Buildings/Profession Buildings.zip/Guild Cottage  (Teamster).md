---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Teamster Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Guild Cottage 
services: services
owner: Bayona (Half-Elf)
---
> [!oRPG-Layout] 
> #  Guild Cottage  (Teamster/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bayona (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | High |

##  Guild Cottage  owned by [[Bayona]] (Half-Elf)
*Teamster / Professional*


**Building Description:**  An two story building, with faded paint with shingled siding with a missing window. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Extra short average build, with hazel eyes and streaked red hair. Their face has a missing eye 
>
> ***Characteristics*** :  Hydrophobic (afraid of water)
>
> ***Personality*** :  Indolent
>
> ***Trait*** : The leader of my community has something wise to say on every topic, and I am eager to share that wisdom.
>
> ***Ideal*** : Responsibility. I do what I must and obey just authority. (Lawful)
{ .ownerDescription }



