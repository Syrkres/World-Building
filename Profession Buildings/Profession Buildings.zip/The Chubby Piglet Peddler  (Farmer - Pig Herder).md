---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Pig Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Chubby Piglet Peddler 
services: services
owner: Antico (Dwarf)
---
> [!oRPG-Layout] 
> #  The Chubby Piglet Peddler  (Farmer - Pig Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Antico (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Low |

##  The Chubby Piglet Peddler  owned by [[Antico]] (Dwarf)
*Farmer - Pig Herder / Farmer*


**Building Description:**  An long building, with faded paint stairs leading up to a Yellow Birch wood door with shingled siding with a front window that has a Iron door with a Beech frame with the merchants name. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Short anorexic build, with blue eyes and braided white hair. Their face has acne 
>
> ***Characteristics*** :  Nervous eye twitch
>
> ***Personality*** :  Deliberate
>
> ***Trait*** : My eloquent flattery makes everyone I talk to feel like the most wonderful and important person in the world.
>
> ***Ideal*** : Might. The strongest are meant to rule. (Evil)
{ .ownerDescription }



