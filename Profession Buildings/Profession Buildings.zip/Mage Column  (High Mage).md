---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Mage Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Mage Column 
services: services
owner: Nilquist (Human)
---
> [!oRPG-Layout] 
> #  Mage Column  (High Mage/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Nilquist (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | High |

##  Mage Column  owned by [[Nilquist]] (Human)
*High Mage / Librarian*


**Building Description:**  An old building, with new paint stairs leading up to a set of double Ceder wood doors with a Hickory frame, with planked siding. The roof is thatched. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Squat lean build, with blue eyes and long brown hair. Their face has a bushy eyebrows 
>
> ***Characteristics*** :  Taps fingers
>
> ***Personality*** :  Sybarite
>
> ***Trait*** : I get bitter if I'm not the center of attention.
>
> ***Ideal*** : Power. Knowledge is the path to power and domination. (Evil)
{ .ownerDescription }



