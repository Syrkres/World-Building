---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Teamster Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  League Hall 
services: services
owner: Crowther (Dwarf)
---
> [!oRPG-Layout] 
> #  League Hall  (Teamster/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Crowther (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Above Average |

##  League Hall  owned by [[Crowther]] (Dwarf)
*Teamster / Professional*


**Building Description:**  An old building, stairs leading up to a set of double Red Oak wood doors, with stoned siding. The roof is thatching made of straw. A Beech shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall fat build, with hazel eyes and long black hair. Their face has eyebrow pierced 
>
> ***Characteristics*** :  Imaginary friend
>
> ***Personality*** :  Grave
>
> ***Trait*** : I get bored easily. When am I going to get on with my destiny.
>
> ***Ideal*** : Greater Good. It is each person's responsibility to make the most happiness for the whole tribe. (Good)
{ .ownerDescription }



