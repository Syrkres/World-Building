---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Cherry Farm 
services: services
owner: Casbah (Elven)
---
> [!oRPG-Layout] 
> #  The Cherry Farm  (Farmer/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Casbah (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Average |

##  The Cherry Farm  owned by [[Casbah]] (Elven)
*Farmer / Farmer*


**Building Description:**  An new tall building, stairs leading up to a Ceder wood with Iron bands door with a Beech frame with brick siding. The roof is timber. A pile of Pine wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand fat build, with brown eyes and pony-tail black hair. Their face has a beard 
>
> ***Characteristics*** :  Urinates frequently
>
> ***Personality*** :  Cocky
>
> ***Trait*** : I've been isolated for so long that I rarely speak, preferring gestures and the occasional grunt.
>
> ***Ideal*** : Self-improvement. The goal of a life of study is the betterment of oneself.
{ .ownerDescription }



