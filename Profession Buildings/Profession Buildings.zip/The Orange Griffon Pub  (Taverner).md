---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Taverner Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Orange Griffon Pub 
services: services
owner: Feratti (Dwarf)
---
> [!oRPG-Layout] 
> #  The Orange Griffon Pub  (Taverner/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Feratti (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  The Orange Griffon Pub  owned by [[Feratti]] (Dwarf)
*Taverner / Cooks*


**Building Description:**  An building, with shingled siding with a missing window. The roof is planked with Yellow Birch planks. A pergola is attached to the side. A warn Elm crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Average anorexic build, with hazel eyes and streaked grey hair. Their face has large scar across full face 
>
> ***Characteristics*** :  Touches people while talking to them
>
> ***Personality*** :  Morose
>
> ***Trait*** : I idolize a particular hero of my faith and constantly refer to that person's deeds and example.
>
> ***Ideal*** : Knowledge. The path to power and self-improvement is through knowledge. (Neutral)
{ .ownerDescription }



