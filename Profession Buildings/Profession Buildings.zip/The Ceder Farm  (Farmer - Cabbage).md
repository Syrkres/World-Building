---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cabbage Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Ceder Farm 
services: services
owner: Randt (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Ceder Farm  (Farmer - Cabbage/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Randt (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Ceder Farm  owned by [[Randt]] (Half-Elf)
*Farmer - Cabbage / Farmer*


**Building Description:**  An long building, with brick siding. The roof is planked.  



> ### Owner Description/Background
> ***Appearance*** : Grand weak build, with brown eyes and thinning black hair. Their face has a moustache 
>
> ***Characteristics*** :  Talks about self in third-person
>
> ***Personality*** :  Unhinged
>
> ***Trait*** : I can find common ground between the fiercest enemies, empathizing with them and always working toward peace.
>
> ***Ideal*** : Destiny. Nothing and no one can steer me away from my higher calling. (Any)
{ .ownerDescription }



