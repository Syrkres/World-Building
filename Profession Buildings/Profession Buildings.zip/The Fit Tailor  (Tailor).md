---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tailor Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Fit Tailor 
services: services
owner: Aristo (Gnome)
---
> [!oRPG-Layout] 
> #  The Fit Tailor  (Tailor/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Aristo (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Low |

##  The Fit Tailor  owned by [[Aristo]] (Gnome)
*Tailor / Tailor*


**Building Description:**  An new tall building, with faded paint a Iron door with stoned siding with a few boarded windows. The roof is thatched. A shed is attached to the side. A pile of Yellow Birch wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Short thin build, with white eyes and short white hair. Their face has large scar across full face 
>
> ***Characteristics*** :  Taps feet
>
> ***Personality*** :  Tolerant
>
> ***Trait*** : I've enjoyed fine food, drink, and high society among my temple's elite. Rough living grates on me.
>
> ***Ideal*** : Beauty. What is beautiful points us beyond itself toward what is true. (Good)
{ .ownerDescription }



