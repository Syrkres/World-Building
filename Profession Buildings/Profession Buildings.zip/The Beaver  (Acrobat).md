---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Acrobat Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: House
title:  The Beaver 
services: services
owner: Crawley (Gnome)
---
> [!oRPG-Layout] 
> #  The Beaver  (Acrobat/Entertainer)
> **Structure:** House
> **Resides In:** 
>  **Owner:** Crawley (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Below Average |

##  The Beaver  owned by [[Crawley]] (Gnome)
*Acrobat / Entertainer*


**Building Description:**  An narrow one story building with stoned siding with a front window that has stairs leading up to a Elm wood with Copper bands door with the merchants name. The roof is shingled with Cherry shingles. A shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Average anorexic build, with brown eyes and thinning brown hair. Their face has sideburns 
>
> ***Characteristics*** :  Puts garlic on all food
>
> ***Personality*** :  Analytical
>
> ***Trait*** : I like to talk at length about my profession.
>
> ***Ideal*** : Respect. The thing that keeps a ship together is mutual respect between captain and crew. (Good)
{ .ownerDescription }



