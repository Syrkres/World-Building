---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wood Carver 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Pine Furniture 
services: services
owner: Albaara (Dwarf)
---
> [!oRPG-Layout] 
> #  Pine Furniture  (Wood Carver/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Albaara (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Low |

##  Pine Furniture  owned by [[Albaara]] (Dwarf)
*Wood Carver / *


**Building Description:**  An old tall building, with faded paint with stoned siding. The roof is timber made of Red Oak. A pergola is attached to the side. A few Pine crates sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Normal fat build, with hazel eyes and pony-tail auburn hair. Their face is gap-toothed 
>
> ***Characteristics*** :  Excessive body hair
>
> ***Personality*** :  Pugnacious
>
> ***Trait*** : I think anyone who's nice to me is hiding evil intent.
>
> ***Ideal*** : Freedom. Chains are meant to be broken, as are those who would forge them. (Chaotic)
{ .ownerDescription }



