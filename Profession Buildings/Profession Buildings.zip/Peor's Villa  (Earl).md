---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Earl Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Peor's Villa 
services: services
owner: Peor (Elven)
---
> [!oRPG-Layout] 
> #  Peor's Villa  (Earl/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Peor (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Low |

##  Peor's Villa  owned by [[Peor]] (Elven)
*Earl / Offical*


**Building Description:**  An narrow two story building, with faded paint a Yellow Birch wood door with a Beech frame with stoned siding with a missing tall window. The roof is timber made of Yellow Birch. A Cherry shed is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Normal average build, with white eyes and bald brown hair. Their face has a goatee 
>
> ***Characteristics*** :  Hacking cough
>
> ***Personality*** :  Callous
>
> ***Trait*** : I take great pains to always look my best and follow the latest fashions.
>
> ***Ideal*** : Beauty. When I perform, I make the world better than it was. (Good)
{ .ownerDescription }



