---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Book Binder Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Open Codex 
services: services
owner: Fauser (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Open Codex  (Book Binder/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Fauser (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | High |

##  The Open Codex  owned by [[Fauser]] (Half-Orc)
*Book Binder / Professional*


**Building Description:**  An two story building, with faded paint with stoned siding with a few short boarded windows. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Short thin build, with white eyes and wiry grey hair. Their face is pock-marked 
>
> ***Characteristics*** :  Smokes
>
> ***Personality*** :  Sycophantic
>
> ***Trait*** : I'm confident in my own abilities and do what I can to instill confidence in others.
>
> ***Ideal*** : Community. We have to take care of each other, because no one else is going to do it. (Lawful)
{ .ownerDescription }



