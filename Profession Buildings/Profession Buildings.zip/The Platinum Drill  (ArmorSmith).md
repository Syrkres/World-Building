---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: ArmorSmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Platinum Drill 
services: services
owner: Hio (Dwarf)
---
> [!oRPG-Layout] 
> #  The Platinum Drill  (ArmorSmith/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Hio (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  The Platinum Drill  owned by [[Hio]] (Dwarf)
*ArmorSmith / *


**Building Description:**  A old tall building with a smithy attached to the side. An anvil sits in outside smithy a large smith hammer lying across the top.  



> ### Owner Description/Background
> ***Appearance*** : Short frail build, with green eyes and thinning white hair. Their face has acne 
>
> ***Characteristics*** :  Wears flamboyant or outlandish clothes
>
> ***Personality*** :  Insensitive
>
> ***Trait*** : I can find common ground between the fiercest enemies, empathizing with them and always working toward peace.
>
> ***Ideal*** : Friendship. Material goods come and go. Bonds of friendship last forever. (Good)
{ .ownerDescription }



