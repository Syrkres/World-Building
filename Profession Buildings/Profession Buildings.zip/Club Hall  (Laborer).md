---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Laborer Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Club Hall 
services: services
owner: Jarryl (Human)
---
> [!oRPG-Layout] 
> #  Club Hall  (Laborer/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Jarryl (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  Club Hall  owned by [[Jarryl]] (Human)
*Laborer / Professional*


**Building Description:**  An new tall building, with stoned siding. The roof is planked with Yellow Birch planks.  



> ### Owner Description/Background
> ***Appearance*** : Short average build, with white eyes and short grey hair. Their face has no eyebrows 
>
> ***Characteristics*** :  Drools
>
> ***Personality*** :  Irreverent
>
> ***Trait*** : I can stare down a hellhound without flinching.
>
> ***Ideal*** : Power. Solitude and contemplation are paths toward mystical or magical power. (Evil)
{ .ownerDescription }



