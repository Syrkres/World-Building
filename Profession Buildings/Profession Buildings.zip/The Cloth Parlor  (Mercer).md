---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Mercer Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Cloth Parlor 
services: services
owner: Mauna (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Cloth Parlor  (Mercer/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Mauna (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  The Cloth Parlor  owned by [[Mauna]] (Half-Elf)
*Mercer / Tailor*


**Building Description:**  An long building, with faded paint with stoned siding with a front round broken window that has a painted sign hanging above with the merchants name. The roof is shingled with Elm shingles. A Elm pergola is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Normal wide build, with brown eyes and thick white hair. Their face has large scar across full face 
>
> ***Characteristics*** :  Sleeps nude
>
> ***Personality*** :  Realistic
>
> ***Trait*** : Thinking is for other people. I prefer action.
>
> ***Ideal*** : Logic. Emotions must not cloud our sense of what is right and true, or our logical thinking. (Lawful)
{ .ownerDescription }



