---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Wheat Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Long Grain Grass Range 
services: services
owner: Maxilla (Human)
---
> [!oRPG-Layout] 
> #  Long Grain Grass Range  (Farmer - Wheat/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Maxilla (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  Long Grain Grass Range  owned by [[Maxilla]] (Human)
*Farmer - Wheat / Farmer*


**Building Description:**  An one story building, with faded paint stairs leading up to a set of double Beech wood doors with a Beech frame, with brick siding with a missing window. The roof is timber. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra short strong build, with white eyes and limp auburn hair. Their face has a broken nose 
>
> ***Characteristics*** :  Pokes/taps others with finger
>
> ***Personality*** :  Dishonest
>
> ***Trait*** : I'm confident in my own abilities and do what I can to instill confidence in others.
>
> ***Ideal*** : Greater Good. Our lot is to lay down our lives in defense of others. (Good)
{ .ownerDescription }



