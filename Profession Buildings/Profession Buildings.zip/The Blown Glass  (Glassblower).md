---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Glassblower Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Blown Glass 
services: services
owner: Gullstrand (Halfling)
---
> [!oRPG-Layout] 
> #  The Blown Glass  (Glassblower/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Gullstrand (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Low |

##  The Blown Glass  owned by [[Gullstrand]] (Halfling)
*Glassblower / Crafter*


**Building Description:**  An old building, with shingled siding. The roof is planked. A Maple shed structure is to the side. A warn Maple barrel sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Grand strong build, with hazel eyes and pony-tail brown hair. Their face is doe-eyed 
>
> ***Characteristics*** :  Grins evilly
>
> ***Personality*** :  Responsible
>
> ***Trait*** : I am horribly, horribly awkward in social situations.
>
> ***Ideal*** : Live and Let Live. Meddling in the affairs of others only causes trouble. (Neutral)
{ .ownerDescription }



