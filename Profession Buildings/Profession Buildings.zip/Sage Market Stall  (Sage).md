---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sage Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Sage Market Stall 
services: services
owner: Guiboar (Halfling)
---
> [!oRPG-Layout] 
> #  Sage Market Stall  (Sage/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Guiboar (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Average |

##  Sage Market Stall  owned by [[Guiboar]] (Halfling)
*Sage / Librarian*


**Building Description:**  An new building, with faded paint a set of double Hickory wood with Steal bands doors with a Oak frame, with brick siding with a few windows. The roof is planked with Hickory planks. A pile of Cherry wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal anorexic build, with red eyes and well groomed auburn hair. Their face is an missing ear 
>
> ***Characteristics*** :  Scarred on Right leg on Left leg on Left arm on Head/Face on Right leg on Left arm on Stomach on Waist on Back on Head/Face
>
> ***Personality*** :  Teetotaler
>
> ***Trait*** : I feel far more comfortable around animals than people.
>
> ***Ideal*** : Fairness. I never target people who can't afford to lose a few coins. (Lawful)
{ .ownerDescription }



