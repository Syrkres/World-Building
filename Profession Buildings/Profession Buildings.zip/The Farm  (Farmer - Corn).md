---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Corn Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Farm 
services: services
owner: Hidalgo (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Farm  (Farmer - Corn/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hidalgo (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Farm  owned by [[Hidalgo]] (Half-Orc)
*Farmer - Corn / Farmer*


**Building Description:**  An one story building, with brick siding with a few broken windows. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Tall frail build, with white eyes and curly red hair. Their face has lip pierced 
>
> ***Characteristics*** :  Limps
>
> ***Personality*** :  Pessimistic
>
> ***Trait*** : I connect everything that happens to me to a grand cosmic plan.
>
> ***Ideal*** : Honor. If I dishonor myself, I dishonor my whole clan. (Lawful)
{ .ownerDescription }



