---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Fishmonger Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Bullhead Monger 
services: services
owner: Albaara (Elven)
---
> [!oRPG-Layout] 
> #  The Bullhead Monger  (Fishmonger/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Albaara (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  The Bullhead Monger  owned by [[Albaara]] (Elven)
*Fishmonger / Cooks*


**Building Description:**  An new building, with brick siding. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Tall fat build, with blue eyes and messy white hair. Their face is pierced 
>
> ***Characteristics*** :  Peg-legged
>
> ***Personality*** :  Noble
>
> ***Trait*** : I'm confident in my own abilities and do what I can to instill confidence in others.
>
> ***Ideal*** : Responsibility. I do what I must and obey just authority. (Lawful)
{ .ownerDescription }



