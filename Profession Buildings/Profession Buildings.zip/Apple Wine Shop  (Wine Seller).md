---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wine Seller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Apple Wine Shop 
services: services
owner: Hu-Geln (Gnome)
---
> [!oRPG-Layout] 
> #  Apple Wine Shop  (Wine Seller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hu-Geln (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Low |

##  Apple Wine Shop  owned by [[Hu-Geln]] (Gnome)
*Wine Seller / Cooks*


**Building Description:**  An old long two story building, with faded paint with stoned siding. The roof is thatched. A Beech shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short frail build, with blue eyes and wavy red hair. Their face has a missing eye 
>
> ***Characteristics*** :  Plays practical jokes
>
> ***Personality*** :  Sexual
>
> ***Trait*** : My language is as foul as an otyugh nest.
>
> ***Ideal*** : Faith. I trust that my deity will guide my actions. I have faith that if I work hard, things will go well. (Lawful)
{ .ownerDescription }



