---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Pig Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Pig Hawker 
services: services
owner: Milne (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Pig Hawker  (Farmer - Pig Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Milne (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  The Pig Hawker  owned by [[Milne]] (Half-Orc)
*Farmer - Pig Herder / Farmer*


**Building Description:**  An old one story building, with shingled siding. The roof is planked.  



> ### Owner Description/Background
> ***Appearance*** : Grand anorexic build, with green eyes and thick red hair. Their face has a goatee 
>
> ***Characteristics*** :  Drools
>
> ***Personality*** :  Brave
>
> ***Trait*** : If you do me an injury, I will crush you, ruin your name, and salt your fields.
>
> ***Ideal*** : Respect. Respect is due to me because of my position, but all people regardless of station deserve to be treated with dignity. (Good)
{ .ownerDescription }



