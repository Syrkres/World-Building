---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Noble Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Bayona's Villa 
services: services
owner: Bayona (Halfling)
---
> [!oRPG-Layout] 
> #  Bayona's Villa  (Noble/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bayona (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Below Average |

##  Bayona's Villa  owned by [[Bayona]] (Halfling)
*Noble / Offical*


**Building Description:**  An building, with shingled siding. The roof is planked with Pine planks. A Pine pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Tall strong build, with blue eyes and thinning blond hair. Their face has no eyebrows 
>
> ***Characteristics*** :  Bleeding nose
>
> ***Personality*** :  Genial
>
> ***Trait*** : I like to squeeze into small places where no one else can get to me.
>
> ***Ideal*** : Noble Obligation. It is my duty to protect and care for the people beneath me. (Good)
{ .ownerDescription }



