---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Duke Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Obol's Villa 
services: services
owner: Obol (Human)
---
> [!oRPG-Layout] 
> #  Obol's Villa  (Duke/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Obol (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  Obol's Villa  owned by [[Obol]] (Human)
*Duke / Offical*


**Building Description:**  An one story building, with faded paint with brick siding. The roof is thatching made of grass. A Red Oak pergola is attached to the side. A pile of Yellow Birch wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal athletic build, with white eyes and messy grey hair. Their face is gap-toothed 
>
> ***Characteristics*** :  Plays with own jewelry
>
> ***Personality*** :  Conscientious
>
> ***Trait*** : Nobody stays angry at me or around me for long, since I can defuse any amount of tension.
>
> ***Ideal*** : Aspiration. Someday I'll own my own ship and chart my own destiny. (Any)
{ .ownerDescription }



