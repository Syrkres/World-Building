---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Glove Merchant Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Glove Monger 
services: services
owner: Smyj (Dwarf)
---
> [!oRPG-Layout] 
> #  The Glove Monger  (Glove Merchant/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Smyj (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Above Average |

##  The Glove Monger  owned by [[Smyj]] (Dwarf)
*Glove Merchant / Tailor*


**Building Description:**  An new long building, with new paint stairs leading up to a set of double Beech wood with Copper bands doors with a Hickory frame, with shingled siding. The roof is shingled. A Yellow Birch shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall fat build, with red eyes and braided red hair. Their face is missing teeth 
>
> ***Characteristics*** :  Excessive body hair
>
> ***Personality*** :  Cynical
>
> ***Trait*** : I enjoy being strong and like breaking things.
>
> ***Ideal*** : Faith. I trust that my deity will guide my actions. I have faith that if I work hard, things will go well. (Lawful)
{ .ownerDescription }



