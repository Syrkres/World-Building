---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Purse Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Purple Shoulderbag 
services: services
owner: Lise (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Purple Shoulderbag  (Purse Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Lise (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Average |

##  The Purple Shoulderbag  owned by [[Lise]] (Half-Elf)
*Purse Maker / Tailor*


**Building Description:**  An old narrow two story building, with stoned siding. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Average frail build, with hazel eyes and thick white hair. Their face has a missing right eye 
>
> ***Characteristics*** :  Hums
>
> ***Personality*** :  Intransigent
>
> ***Trait*** : I am incredibly slow to trust. Those who seem the fairest often have the most to hide.
>
> ***Ideal*** : Respect. Respect is due to me because of my position, but all people regardless of station deserve to be treated with dignity. (Good)
{ .ownerDescription }



