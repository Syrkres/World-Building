---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Kettle Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Mithril Pot 
services: services
owner: Ligget (Human)
---
> [!oRPG-Layout] 
> #  The Mithril Pot  (Kettle Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Ligget (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Low |

##  The Mithril Pot  owned by [[Ligget]] (Human)
*Kettle Maker / Crafter*


**Building Description:**  An two story building, stairs leading up to a set of double Beech wood with Copper bands doors, with brick siding with a front tall boarded window that has stairs leading up to a Elm wood with Copper bands door with the merchants name. The roof is thatching made of grass. A shed is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall fat build, with hazel eyes and frazzled white hair. Their face has a missing eye 
>
> ***Characteristics*** :  Excessive body hair
>
> ***Personality*** :  Agreeable
>
> ***Trait*** : I'm full of inspiring and cautionary tales from my military experience relevant to almost every combat situation.
>
> ***Ideal*** : Greed. I will do whatever it takes to become wealthy. (Evil)
{ .ownerDescription }



