---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Magical Artisan Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Magical Artisan 
services: services
owner: Antico (Halfling)
---
> [!oRPG-Layout] 
> #  The Magical Artisan  (Magical Artisan/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Antico (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Magical Artisan  owned by [[Antico]] (Halfling)
*Magical Artisan / Librarian*


**Building Description:**  An long two story building, with new paint stairs leading up to a set of double Cherry wood with Copper bands doors, with stoned siding. The roof is thatching made of straw. A few Pine crates sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Tall athletic build, with blue eyes and wiry white hair. Their face has sideburns 
>
> ***Characteristics*** :  Shivers
>
> ***Personality*** :  Vapid
>
> ***Trait*** : I'm a born gambler who can't resist taking a risk for a potential payoff.
>
> ***Ideal*** : Creativity. The world is in need of new ideas and bold action. (Chaotic)
{ .ownerDescription }



