---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: ArmorSmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Right Clank 
services: services
owner: Elam (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Right Clank  (ArmorSmith/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Elam (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  The Right Clank  owned by [[Elam]] (Half-Orc)
*ArmorSmith / *


**Building Description:**  A long building with a smithy attached to the side. An anvil sits in outside shed a large smith hammer lying across the top.  



> ### Owner Description/Background
> ***Appearance*** : Grand weak build, with blue eyes and greasy white hair. Their face has large scar 
>
> ***Characteristics*** :  Picks at lint or dirt on others' clothes
>
> ***Personality*** :  Bossy
>
> ***Trait*** : The best way to get me to do something is to tell me I can't do it.
>
> ***Ideal*** : Master. I'm a predator, and the other ships on the sea are my prey. (Evil)
{ .ownerDescription }



