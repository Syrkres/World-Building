---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Blacksmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Adamentite Arms 
services: services
owner: Roentgen (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Adamentite Arms  (Blacksmith/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Roentgen (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  The Adamentite Arms  owned by [[Roentgen]] (Half-Elf)
*Blacksmith / *


**Building Description:**  An old one story building, with planked siding with a few windows. The roof is shingled.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall thin build, with white eyes and limp auburn hair. Their face has large ears 
>
> ***Characteristics*** :  Distracted easily during conversations
>
> ***Personality*** :  Conformist
>
> ***Trait*** : I keep multiple holy symbols on me and invoke whatever deity might come in useful at any given moment.
>
> ***Ideal*** : Greater Good. Our lot is to lay down our lives in defense of others. (Good)
{ .ownerDescription }



