---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armor Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Blue Steal Chainmail Monger 
services: services
owner: Krislo (Halfling)
---
> [!oRPG-Layout] 
> #  The Blue Steal Chainmail Monger  (Armor Dealer/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Krislo (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Average |

##  The Blue Steal Chainmail Monger  owned by [[Krislo]] (Halfling)
*Armor Dealer / *


**Building Description:**  An new building. An polished anvil sits in outside smithy a large smith hammer lying across the top. A Red Oak crate filled with water, with a Saw leaning against the base.  



> ### Owner Description/Background
> ***Appearance*** : Tall fat build, with blue eyes and wiry black hair. Their face has small scar on left cheek 
>
> ***Characteristics*** :  Entomophobic (afraid of insects)
>
> ***Personality*** :  Sociable
>
> ***Trait*** : I fall in and out of love easily, and am always pursuing someone.
>
> ***Ideal*** : Independence. When people follow orders blindly they embrace a kind of tyranny. (Chaotic)
{ .ownerDescription }



