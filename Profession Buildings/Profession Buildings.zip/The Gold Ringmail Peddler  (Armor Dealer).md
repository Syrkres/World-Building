---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armor Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Gold Ringmail Peddler 
services: services
owner: Grillin (Gnome)
---
> [!oRPG-Layout] 
> #  The Gold Ringmail Peddler  (Armor Dealer/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Grillin (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | High |

##  The Gold Ringmail Peddler  owned by [[Grillin]] (Gnome)
*Armor Dealer / *


**Building Description:**  A long building with a smithy attached to the side. An anvil sits in the corner of the shed with various Mace lying about.  



> ### Owner Description/Background
> ***Appearance*** : Extra short strong build, with hazel eyes and wiry brown hair. Their face has small scar 
>
> ***Characteristics*** :  Needs story before sleeping
>
> ***Personality*** :  Analytical
>
> ***Trait*** : I stretch the truth for the sake of a good story.
>
> ***Ideal*** : Faith. I trust that my deity will guide my actions. I have faith that if I work hard, things will go well. (Lawful)
{ .ownerDescription }



