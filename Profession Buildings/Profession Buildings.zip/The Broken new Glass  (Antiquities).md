---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Broken new Glass 
services: services
owner: Glaw (Halfling)
---
> [!oRPG-Layout] 
> #  The Broken new Glass  (Antiquities/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Glaw (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  The Broken new Glass  owned by [[Glaw]] (Halfling)
*Antiquities / Offical*


**Building Description:**  An building, with faded paint a set of double Copper doors, with planked siding. The roof is thatched. A warn Beech crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Short anorexic build, with red eyes and braided grey hair. Their face is grizzled 
>
> ***Characteristics*** :  Wets bed
>
> ***Personality*** :  Maudlin
>
> ***Trait*** : The first thing I do in a new place is note the locations of everything valuable--or where such things could be hidden.
>
> ***Ideal*** : Honor. I don't steal from others in the trade. (Lawful)
{ .ownerDescription }



