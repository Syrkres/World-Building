---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Goblinvine Fields 
services: services
owner: Perlin (Human)
---
> [!oRPG-Layout] 
> #  The Goblinvine Fields  (Farmer/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Perlin (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Low |

##  The Goblinvine Fields  owned by [[Perlin]] (Human)
*Farmer / Farmer*


**Building Description:**  An long building, with brick siding with a missing window. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Extra short lean build, with red eyes and frazzled auburn hair. Their face is missing teeth 
>
> ***Characteristics*** :  Hands shake
>
> ***Personality*** :  Secretive
>
> ***Trait*** : I enjoy sailing into new ports and making new friends over a flagon of ale.
>
> ***Ideal*** : Nation. My city, nation, or people are all that matter. (Any)
{ .ownerDescription }



