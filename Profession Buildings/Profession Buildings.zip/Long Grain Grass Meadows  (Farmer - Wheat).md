---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Wheat Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Long Grain Grass Meadows 
services: services
owner: Philmore (Half-Orc)
---
> [!oRPG-Layout] 
> #  Long Grain Grass Meadows  (Farmer - Wheat/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Philmore (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Low |

##  Long Grain Grass Meadows  owned by [[Philmore]] (Half-Orc)
*Farmer - Wheat / Farmer*


**Building Description:**  An old two story building, with brick siding with a few tall broken windows. The roof is thatching made of grass. A Beech shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short fat build, with red eyes and braided blond hair. Their face has nose pierced 
>
> ***Characteristics*** :  Scratches
>
> ***Personality*** :  Obstinate
>
> ***Trait*** : I like to talk at length about my profession.
>
> ***Ideal*** : Responsibility. It is my duty to respect the authority of those above me, just as those below me must respect mine. (Lawful)
{ .ownerDescription }



