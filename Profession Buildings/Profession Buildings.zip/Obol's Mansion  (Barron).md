---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barron Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Townhall
title:  Obol's Mansion 
services: services
owner: Obol (Gnome)
---
> [!oRPG-Layout] 
> #  Obol's Mansion  (Barron/Offical)
> **Structure:** Townhall
> **Resides In:** 
>  **Owner:** Obol (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Low |

##  Obol's Mansion  owned by [[Obol]] (Gnome)
*Barron / Offical*


**Building Description:**  An narrow tall building with faded paint and with shingled siding with a few tall shuttered windows. The roof is planked with Oak planks.  



> ### Owner Description/Background
> ***Appearance*** : Normal anorexic build, with white eyes and greasy red hair. Their face has large scar on left cheek 
>
> ***Characteristics*** :  Repeats same phrase over and over
>
> ***Personality*** :  Analytical
>
> ***Trait*** : I miss-quote the sacred texts and proverbs in almost every situation.
>
> ***Ideal*** : Independence. I must prove that I can handle myself without the coddling of my family. (Chaotic)
{ .ownerDescription }



