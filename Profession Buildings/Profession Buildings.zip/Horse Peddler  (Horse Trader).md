---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Horse Trader 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Horse Peddler 
services: services
owner: Labell (Gnome)
---
> [!oRPG-Layout] 
> #  Horse Peddler  (Horse Trader/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Labell (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  Horse Peddler  owned by [[Labell]] (Gnome)
*Horse Trader / *


**Building Description:**  An old two story building, with planked siding with a missing round window. The roof is thatched. A pile of Hickory wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand fat build, with hazel eyes and long black hair. Their face has sideburns 
>
> ***Characteristics*** :  Hemaphobic (afraid of blood)
>
> ***Personality*** :  Jumpy
>
> ***Trait*** : I've lost too many friends, and I'm slow to make new ones.
>
> ***Ideal*** : Might. If I become strong, I can take what I want--what I deserve. (Evil)
{ .ownerDescription }



