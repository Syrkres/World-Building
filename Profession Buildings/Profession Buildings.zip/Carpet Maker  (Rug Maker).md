---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Rug Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Carpet Maker 
services: services
owner: Dashnaw (Elven)
---
> [!oRPG-Layout] 
> #  Carpet Maker  (Rug Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Dashnaw (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  Carpet Maker  owned by [[Dashnaw]] (Elven)
*Rug Maker / Crafter*


**Building Description:**  An tall building, with faded paint with brick siding. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall average build, with white eyes and braided red hair. Their face is an missing ear 
>
> ***Characteristics*** :  Always wears tattered clothes
>
> ***Personality*** :  Distracted
>
> ***Trait*** : The first thing I do in a new place is note the locations of everything valuable--or where such things could be hidden.
>
> ***Ideal*** : Aspiration. I'm going to prove that I'm worthy of a better life. (Any)
{ .ownerDescription }



