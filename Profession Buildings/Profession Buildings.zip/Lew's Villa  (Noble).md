---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Noble Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Lew's Villa 
services: services
owner: Lew (Half-Elf)
---
> [!oRPG-Layout] 
> #  Lew's Villa  (Noble/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Lew (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | High |

##  Lew's Villa  owned by [[Lew]] (Half-Elf)
*Noble / Offical*


**Building Description:**  An long building, with faded paint with shingled siding with a front window that has a painted sign hanging above with the merchants name. The roof is shingled with Hickory shingles. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall wide build, with white eyes and wavy black hair. Their face is buck-toothed 
>
> ***Characteristics*** :  Distinctive jewelry
>
> ***Personality*** :  Rash
>
> ***Trait*** : I'm driven by a wanderlust that led me away from home.
>
> ***Ideal*** : Tradition. The stories, legends, and songs of the past must never be forgotten. (Lawful)
{ .ownerDescription }



