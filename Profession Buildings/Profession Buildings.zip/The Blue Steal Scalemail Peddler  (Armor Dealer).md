---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armor Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Blue Steal Scalemail Peddler 
services: services
owner: Vibben (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Blue Steal Scalemail Peddler  (Armor Dealer/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Vibben (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Blue Steal Scalemail Peddler  owned by [[Vibben]] (Half-Elf)
*Armor Dealer / *


**Building Description:**  A old building with a smithy attached to the side. An rusted anvil sits in outside yard with various Flail scattered about. A warn Yellow Birch crate filled with Steal shavings, with a Hammer leaning against the base.  



> ### Owner Description/Background
> ***Appearance*** : Extra short thin build, with white eyes and messy grey hair. Their face has a patch over eye 
>
> ***Characteristics*** :  Chews with mouth open
>
> ***Personality*** :  Tactful
>
> ***Trait*** : I was, in fact, raised by wolves.
>
> ***Ideal*** : People. I like seeing the smiles on people's faces when I perform. That's all that matters. (Neutral)
{ .ownerDescription }



