---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Broker Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title: 
services: services
owner: Lorde (Halfling)
---
> [!oRPG-Layout] 
> #  (Broker/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Lorde (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Above Average |

##  owned by [[Lorde]] (Halfling)
*Broker / Professional*


**Building Description:**  An old building, with faded paint with planked siding. The roof is thatched. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall lean build, with red eyes and straight grey hair. Their face has no eyebrows 
>
> ***Characteristics*** :  Body piercings on Head/Face on Left leg on Head/Face on Right leg on Left leg on Chest on Waist
>
> ***Personality*** :  Elitist
>
> ***Trait*** : I often get lost in my own thoughts and contemplations, becoming oblivious to my surroundings.
>
> ***Ideal*** : Greed. I'm only in it for the money. (Evil)
{ .ownerDescription }



