---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tinker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Clockwork Store 
services: services
owner: Jonno (Gnome)
---
> [!oRPG-Layout] 
> #  Clockwork Store  (Tinker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Jonno (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Above Average |

##  Clockwork Store  owned by [[Jonno]] (Gnome)
*Tinker / Crafter*


**Building Description:**  An long two story building, with faded paint with stoned siding. The roof is planked with Hickory planks. A shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Average thin build, with red eyes and short brown hair. Their face has large ears 
>
> ***Characteristics*** :  Drools
>
> ***Personality*** :  Nonchalant
>
> ***Trait*** : I'm used to helping out those who aren't as smart as I am, and I patiently explain anything and everything to others.
>
> ***Ideal*** : Family. Blood runs thicker than water. (Any)
{ .ownerDescription }



