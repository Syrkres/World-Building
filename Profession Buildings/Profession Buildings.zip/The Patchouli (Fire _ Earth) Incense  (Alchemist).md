---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Alchemist Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Patchouli (Fire / Earth) Incense 
services: services
owner: Wyndehall (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Patchouli (Fire / Earth) Incense  (Alchemist/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Wyndehall (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Patchouli (Fire / Earth) Incense  owned by [[Wyndehall]] (Half-Orc)
*Alchemist / Librarian*


**Building Description:**  An new building, stairs leading up to a set of double Elm wood with Steal bands doors, with planked siding with a missing round window. The roof is thatching made of grass. A shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal anorexic build, with hazel eyes and curly red hair. Their face has small scar on left cheek 
>
> ***Characteristics*** :  Distinctive jewelry
>
> ***Personality*** :  Scared
>
> ***Trait*** : Despite my birth, I do not place myself above other folk. We all have the same blood.
>
> ***Ideal*** : Destiny. Nothing and no one can steer me away from my higher calling. (Any)
{ .ownerDescription }



