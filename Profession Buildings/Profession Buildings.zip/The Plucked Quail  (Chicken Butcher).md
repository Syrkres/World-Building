---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chicken Butcher Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Plucked Quail 
services: services
owner: Pavia (Human)
---
> [!oRPG-Layout] 
> #  The Plucked Quail  (Chicken Butcher/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Pavia (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Average |

##  The Plucked Quail  owned by [[Pavia]] (Human)
*Chicken Butcher / Cooks*


**Building Description:**  An new tall building, a set of double Oak wood doors with a Red Oak frame, with shingled siding with a few short windows. The roof is planked. A shed is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Squat weak build, with white eyes and thinning black hair. Their face has a missing eye 
>
> ***Characteristics*** :  Chortles
>
> ***Personality*** :  Fanatical
>
> ***Trait*** : I can stare down a hellhound without flinching.
>
> ***Ideal*** : Charity. I always try to help those in need, no matter what the personal cost. (Good)
{ .ownerDescription }



