---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Apple Pie 
services: services
owner: Kauri (Gnome)
---
> [!oRPG-Layout] 
> #  The Apple Pie  (Baker/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kauri (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Low |

##  The Apple Pie  owned by [[Kauri]] (Gnome)
*Baker / Cooks*


**Building Description:**  An narrow building, with faded paint with brick siding with a missing round window. The roof is thatching made of straw. A Cherry shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short average build, with blue eyes and thick red hair. Their face has sideburns 
>
> ***Characteristics*** :  Excessive body hair
>
> ***Personality*** :  Humorous
>
> ***Trait*** : I face problems head-on. A simple direct solution is the best path to success.
>
> ***Ideal*** : Responsibility. I do what I must and obey just authority. (Lawful)
{ .ownerDescription }



