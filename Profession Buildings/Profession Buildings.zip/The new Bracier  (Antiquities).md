---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The new Bracier 
services: services
owner: Oberfrank (Gnome)
---
> [!oRPG-Layout] 
> #  The new Bracier  (Antiquities/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Oberfrank (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  The new Bracier  owned by [[Oberfrank]] (Gnome)
*Antiquities / Offical*


**Building Description:**  An tall building, with faded paint stairs leading up to a Cherry wood door with a Cherry frame with stoned siding with a few windows. The roof is thatched. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Grand lean build, with hazel eyes and thinning blond hair. Their face has large ears 
>
> ***Characteristics*** :  Bad/loud/annoying/shrill laugh
>
> ***Personality*** :  Chivalrous
>
> ***Trait*** : I always have plan for what to do when things go wrong.
>
> ***Ideal*** : Change. Life is like the seasons, in constant change, and we must change with it. (Chaotic)
{ .ownerDescription }



