---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Miller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Phalastin's Mill 
services: services
owner: Phalastin (Half-Elf)
---
> [!oRPG-Layout] 
> #  Phalastin's Mill  (Miller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Phalastin (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  Phalastin's Mill  owned by [[Phalastin]] (Half-Elf)
*Miller / Cooks*


**Building Description:**  An tall building, a set of double Yellow Birch wood doors, with shingled siding. The roof is planked with Yellow Birch planks.  



> ### Owner Description/Background
> ***Appearance*** : Tall weak build, with brown eyes and strange hairstyle white hair. Their face has a missing left eye 
>
> ***Characteristics*** :  Plays with own jewelry
>
> ***Personality*** :  Noble
>
> ***Trait*** : I like to squeeze into small places where no one else can get to me.
>
> ***Ideal*** : Family. Blood runs thicker than water. (Any)
{ .ownerDescription }



