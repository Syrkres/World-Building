---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tracker 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Guild 
services: services
owner: Kant (Gnome)
---
> [!oRPG-Layout] 
> #  Guild  (Tracker/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kant (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Low |

##  Guild  owned by [[Kant]] (Gnome)
*Tracker / *


**Building Description:**  An two story building, with faded paint a set of double Pine wood doors with a Oak frame, with stoned siding. The roof is planked with Red Oak planks. A pile of Elm wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Average fat build, with green eyes and long black hair. Their face has a patch over left eye 
>
> ***Characteristics*** :  Plays with own jewelry
>
> ***Personality*** :  Insecure
>
> ***Trait*** : I like a job well done, especially if I can convince someone else to do it.
>
> ***Ideal*** : Respect. People deserve to be treated with dignity and respect. (Good)
{ .ownerDescription }



