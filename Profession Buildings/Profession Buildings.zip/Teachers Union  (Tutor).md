---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tutor Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Teachers Union 
services: services
owner: Higbee (Human)
---
> [!oRPG-Layout] 
> #  Teachers Union  (Tutor/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Higbee (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Average |

##  Teachers Union  owned by [[Higbee]] (Human)
*Tutor / Librarian*


**Building Description:**  An narrow building, with faded paint a set of double Maple wood with Iron bands doors with a Maple frame, with stoned siding. The roof is thatching made of grass. A Pine shed structure is to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Grand wide build, with blue eyes and streaked red hair. Their face has lip pierced 
>
> ***Characteristics*** :  Hemaphobic (afraid of blood)
>
> ***Personality*** :  Scolding
>
> ***Trait*** : I'm confident in my own abilities and do what I can to instill confidence in others.
>
> ***Ideal*** : Retribution. The rich need to be shown what life and death are like in the gutters. (Evil)
{ .ownerDescription }



