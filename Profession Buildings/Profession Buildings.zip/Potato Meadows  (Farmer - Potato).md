---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Potato Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Potato Meadows 
services: services
owner: Braggs (Elven)
---
> [!oRPG-Layout] 
> #  Potato Meadows  (Farmer - Potato/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Braggs (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  Potato Meadows  owned by [[Braggs]] (Elven)
*Farmer - Potato / Farmer*


**Building Description:**  An old building, with faded paint a set of double Beech wood doors with a Ceder frame, with brick siding. The roof is shingled. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Grand strong build, with green eyes and long auburn hair. Their face is missing teeth 
>
> ***Characteristics*** :  Talks with food in mouth
>
> ***Personality*** :  Smug
>
> ***Trait*** : I feel far more comfortable around animals than people.
>
> ***Ideal*** : Freedom. Tyrants must not be allowed to oppress the people. (Chaotic)
{ .ownerDescription }



