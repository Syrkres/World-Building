---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Saddler Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Saddle Monger 
services: services
owner: Tobius (Half-Orc)
---
> [!oRPG-Layout] 
> #  Saddle Monger  (Saddler/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Tobius (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | High |

##  Saddle Monger  owned by [[Tobius]] (Half-Orc)
*Saddler / Crafter*


**Building Description:**  An new two story building, with faded paint a Maple wood door with a Pine frame with shingled siding with a front broken window that has a Bronze door with the merchants name. The roof is thatching made of grass. A Maple shed structure is to the side. A Beech crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Normal thin build, with brown eyes and strange hairstyle auburn hair. Their face is squinty 
>
> ***Characteristics*** :  Burps
>
> ***Personality*** :  Braggart
>
> ***Trait*** : I enjoy being strong and like breaking things.
>
> ***Ideal*** : Redemption. There's a spark of good in everyone. (Good)
{ .ownerDescription }



