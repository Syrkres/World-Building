---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cow Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Old Stone Farm 
services: services
owner: Eneshan (Halfling)
---
> [!oRPG-Layout] 
> #  Old Stone Farm  (Farmer - Cow Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Eneshan (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  Old Stone Farm  owned by [[Eneshan]] (Halfling)
*Farmer - Cow Herder / Farmer*


**Building Description:**  An new one story building, with faded paint with shingled siding with a front tall broken window that has a sign hanging above with the merchants name. The roof is timber made of Elm.  



> ### Owner Description/Background
> ***Appearance*** : Short weak build, with green eyes and greasy white hair. Their face is grizzled 
>
> ***Characteristics*** :  Always wears as little as possible
>
> ***Personality*** :  Fearless
>
> ***Trait*** : There's nothing I like more than a good mystery.
>
> ***Ideal*** : Creativity. I never run the same con twice. (Chaotic)
{ .ownerDescription }



