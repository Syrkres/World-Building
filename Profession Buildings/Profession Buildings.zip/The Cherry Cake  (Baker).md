---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Cherry Cake 
services: services
owner: Smead (Dwarf)
---
> [!oRPG-Layout] 
> #  The Cherry Cake  (Baker/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Smead (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Average |

##  The Cherry Cake  owned by [[Smead]] (Dwarf)
*Baker / Cooks*


**Building Description:**  An old building, stairs leading up to a set of double Bronze doors with a Ceder frame, with planked siding with a front boarded window that has stairs leading up to a Beech wood with Copper bands door with the merchants name. The roof is thatching made of straw. A pile of Ceder wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Short athletic build, with hazel eyes and dreadlocks blond hair. Their face has acne 
>
> ***Characteristics*** :  Drones on and on while talking
>
> ***Personality*** :  Caring
>
> ***Trait*** : I'm convinced that people are always trying to steal my secrets.
>
> ***Ideal*** : Sincerity. There's no good pretending to be something I'm not. (Neutral)
{ .ownerDescription }



