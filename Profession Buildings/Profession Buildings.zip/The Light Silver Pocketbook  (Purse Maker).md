---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Purse Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Light Silver Pocketbook 
services: services
owner: Denison (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Light Silver Pocketbook  (Purse Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Denison (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Average |

##  The Light Silver Pocketbook  owned by [[Denison]] (Half-Orc)
*Purse Maker / Tailor*


**Building Description:**  An old one story building, with faded paint with brick siding with a few broken windows. The roof is thatched. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Squat weak build, with blue eyes and short blond hair. Their face has a patch over right eye 
>
> ***Characteristics*** :  Sun-burned
>
> ***Personality*** :  Pontificating
>
> ***Trait*** : I place no stock in wealthy or well-mannered folk. Money and manners won't save you from a hungry owlbear.
>
> ***Ideal*** : Respect. All people, rich or poor, deserve respect. (Good)
{ .ownerDescription }



