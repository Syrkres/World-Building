---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Wheat Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Golden Wheat Range 
services: services
owner: Vexler (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Golden Wheat Range  (Farmer - Wheat/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Vexler (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  The Golden Wheat Range  owned by [[Vexler]] (Half-Elf)
*Farmer - Wheat / Farmer*


**Building Description:**  An new long two story building, with planked siding with a front short broken window that has a Yellow Birch wood door with the merchants name. The roof is timber made of Pine. A few Elm crates sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short lean build, with white eyes and strange hairstyle black hair. Their face is toothless 
>
> ***Characteristics*** :  Sweaty
>
> ***Personality*** :  Whimsical
>
> ***Trait*** : I am always calm, no matter what the situation. I never raise my voice or let my emotions control me.
>
> ***Ideal*** : Respect. The thing that keeps a ship together is mutual respect between captain and crew. (Good)
{ .ownerDescription }



