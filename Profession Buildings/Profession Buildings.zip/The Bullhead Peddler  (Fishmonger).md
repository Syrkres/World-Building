---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Fishmonger Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Bullhead Peddler 
services: services
owner: Maxilla (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Bullhead Peddler  (Fishmonger/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Maxilla (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Above Average |

##  The Bullhead Peddler  owned by [[Maxilla]] (Half-Orc)
*Fishmonger / Cooks*


**Building Description:**  An old long building, stairs leading up to a set of double Ceder wood doors with a Oak frame, with brick siding. The roof is thatching made of grass. A pile of Pine wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short athletic build, with brown eyes and straight brown hair. Their face has a goatee 
>
> ***Characteristics*** :  Sleeps nude
>
> ***Personality*** :  Impractical
>
> ***Trait*** : I...speak...slowly...when talking...to idiots...which...almost...everyone...is...compared ...to me.
>
> ***Ideal*** : Responsibility. It is my duty to respect the authority of those above me, just as those below me must respect mine. (Lawful)
{ .ownerDescription }



