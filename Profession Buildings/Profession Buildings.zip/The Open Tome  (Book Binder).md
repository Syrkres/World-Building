---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Book Binder Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Open Tome 
services: services
owner: Gundrun (Gnome)
---
> [!oRPG-Layout] 
> #  The Open Tome  (Book Binder/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Gundrun (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | High |

##  The Open Tome  owned by [[Gundrun]] (Gnome)
*Book Binder / Professional*


**Building Description:**  An old building, with new paint with brick siding with a few shuttered windows. The roof is shingled. A pile of Elm wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall strong build, with red eyes and well groomed blond hair. Their face has a broken nose 
>
> ***Characteristics*** :  Bad with money
>
> ***Personality*** :  Promiscuous
>
> ***Trait*** : I would rather make a new friend than a new enemy.
>
> ***Ideal*** : Community. It is the duty of all civilized people to strengthen the bonds of community and the security of civilization. (Lawful)
{ .ownerDescription }



