---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Earl Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Preece's Villa 
services: services
owner: Preece (Elven)
---
> [!oRPG-Layout] 
> #  Preece's Villa  (Earl/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Preece (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Low |

##  Preece's Villa  owned by [[Preece]] (Elven)
*Earl / Offical*


**Building Description:**  An old narrow one story building, with faded paint stairs leading up to a set of double Maple wood with Iron bands doors, with shingled siding with a missing short window. The roof is thatching made of straw. A shed structure is to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Tall athletic build, with green eyes and thinning white hair. Their face has a patch over left eye 
>
> ***Characteristics*** :  Picks fights
>
> ***Personality*** :  Clueless
>
> ***Trait*** : I am utterly serene, even in the face of disaster.
>
> ***Ideal*** : Greater Good. Our lot is to lay down our lives in defense of others. (Good)
{ .ownerDescription }



