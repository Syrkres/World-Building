---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Purse Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Pink Bag 
services: services
owner: Latocki (Elven)
---
> [!oRPG-Layout] 
> #  The Pink Bag  (Purse Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Latocki (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | High |

##  The Pink Bag  owned by [[Latocki]] (Elven)
*Purse Maker / Tailor*


**Building Description:**  An new long building, with faded paint with stoned siding with a missing round window. The roof is thatching made of straw. A shed is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra short wide build, with white eyes and well groomed black hair. Their face is doe-eyed 
>
> ***Characteristics*** :  Sleeps nude
>
> ***Personality*** :  Sardonic
>
> ***Trait*** : I'm always picking things up, absently fiddling with them, and sometimes accidentally breaking them.
>
> ***Ideal*** : Friendship. Material goods come and go. Bonds of friendship last forever. (Good)
{ .ownerDescription }



