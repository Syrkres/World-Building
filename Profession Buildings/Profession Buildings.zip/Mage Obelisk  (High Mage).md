---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Mage Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Mage Obelisk 
services: services
owner: Whil (Human)
---
> [!oRPG-Layout] 
> #  Mage Obelisk  (High Mage/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Whil (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  Mage Obelisk  owned by [[Whil]] (Human)
*High Mage / Librarian*


**Building Description:**  An old building, a set of double Beech wood with Steal bands doors with a Yellow Birch frame, with shingled siding. The roof is shingled. A Pine shed structure is to the side. A few Yellow Birch chests sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Squat strong build, with white eyes and straight grey hair. Their face is buck-toothed 
>
> ***Characteristics*** :  Talks to inanimate objects
>
> ***Personality*** :  Mousy
>
> ***Trait*** : Nobody stays angry at me or around me for long, since I can defuse any amount of tension.
>
> ***Ideal*** : Nature. The natural world is more important than all the constructs of civilization. (Neutral)
{ .ownerDescription }



