---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Count Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Modo's Court 
services: services
owner: Modo (Half-Elf)
---
> [!oRPG-Layout] 
> #  Modo's Court  (Count/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Modo (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  Modo's Court  owned by [[Modo]] (Half-Elf)
*Count / Offical*


**Building Description:**  An old one story building, with new paint stairs leading up to a set of double Pine wood doors, with stoned siding. The roof is planked with Pine planks. A pile of Beech wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Short fat build, with blue eyes and thinning brown hair. Their face has small scar on right cheek 
>
> ***Characteristics*** :  Always gives vaguest possible answer
>
> ***Personality*** :  Slanderous
>
> ***Trait*** : I am incredibly slow to trust. Those who seem the fairest often have the most to hide.
>
> ***Ideal*** : Self-Knowledge. If you know yourself, there're nothing left to know. (Any)
{ .ownerDescription }



