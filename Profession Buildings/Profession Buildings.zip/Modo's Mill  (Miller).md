---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Miller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Modo's Mill 
services: services
owner: Modo (Gnome)
---
> [!oRPG-Layout] 
> #  Modo's Mill  (Miller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Modo (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Low |

##  Modo's Mill  owned by [[Modo]] (Gnome)
*Miller / Cooks*


**Building Description:**  An new building, with faded paint stairs leading up to a set of double Bronze doors with a Elm frame, with stoned siding with a few tall boarded windows. The roof is shingled with Elm shingles.  



> ### Owner Description/Background
> ***Appearance*** : Average average build, with green eyes and very long brown hair. Their face is doe-eyed 
>
> ***Characteristics*** :  Allergic to food/dust/pollen/animals
>
> ***Personality*** :  Refined
>
> ***Trait*** : I like a job well done, especially if I can convince someone else to do it.
>
> ***Ideal*** : Knowledge. The path to power and self-improvement is through knowledge. (Neutral)
{ .ownerDescription }



