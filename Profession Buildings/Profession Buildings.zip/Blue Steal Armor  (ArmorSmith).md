---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: ArmorSmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  Blue Steal Armor 
services: services
owner: Peps (Half-Elf)
---
> [!oRPG-Layout] 
> #  Blue Steal Armor  (ArmorSmith/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Peps (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  Blue Steal Armor  owned by [[Peps]] (Half-Elf)
*ArmorSmith / *


**Building Description:**  A building with a smithy attached to the side. An polished anvil sits in the corner of the smithy a large smith hammer lying across the top with various Mace lying about.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall fat build, with red eyes and wavy white hair. Their face has a bushy eyebrows 
>
> ***Characteristics*** :  Wets bed
>
> ***Personality*** :  Crabby
>
> ***Trait*** : My language is as foul as an otyugh nest.
>
> ***Ideal*** : Aspiration. I work hard to be the best there is at my craft. (Any)
{ .ownerDescription }



