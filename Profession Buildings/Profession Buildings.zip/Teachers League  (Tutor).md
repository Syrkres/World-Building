---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tutor Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Teachers League 
services: services
owner: Branko (Elven)
---
> [!oRPG-Layout] 
> #  Teachers League  (Tutor/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Branko (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | High |

##  Teachers League  owned by [[Branko]] (Elven)
*Tutor / Librarian*


**Building Description:**  An old one story building, with faded paint stairs leading up to a set of double Beech wood doors, with shingled siding. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall frail build, with hazel eyes and very long white hair. Their face has large scar on left cheek 
>
> ***Characteristics*** :  Wears only jewelry of one type of metal
>
> ***Personality*** :  Earthy
>
> ***Trait*** : I feel far more comfortable around animals than people.
>
> ***Ideal*** : Honor. I don't steal from others in the trade. (Lawful)
{ .ownerDescription }



