---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tinker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Clockwork Market Stall 
services: services
owner: Catlett (Halfling)
---
> [!oRPG-Layout] 
> #  Clockwork Market Stall  (Tinker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Catlett (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  Clockwork Market Stall  owned by [[Catlett]] (Halfling)
*Tinker / Crafter*


**Building Description:**  An building, stairs leading up to a set of double Oak wood with Copper bands doors with a Pine frame, with stoned siding. The roof is planked with Beech planks. A Elm shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Tall frail build, with green eyes and thick white hair. Their face has large scar 
>
> ***Characteristics*** :  Narcoleptic
>
> ***Personality*** :  Apathetic
>
> ***Trait*** : I'm confident in my own abilities and do what I can to instill confidence in others.
>
> ***Ideal*** : Greater Good. Our lot is to lay down our lives in defense of others. (Good)
{ .ownerDescription }



