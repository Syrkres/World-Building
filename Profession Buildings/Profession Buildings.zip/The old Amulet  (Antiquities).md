---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The old Amulet 
services: services
owner: Arel (Half-Orc)
---
> [!oRPG-Layout] 
> #  The old Amulet  (Antiquities/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Arel (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  The old Amulet  owned by [[Arel]] (Half-Orc)
*Antiquities / Offical*


**Building Description:**  An new narrow building, with new paint stairs leading up to a set of double Bronze doors, with brick siding with a missing window. The roof is planked. A pergola is attached to the side. A Ceder barrel sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Squat anorexic build, with white eyes and wiry black hair. Their face has a missing right eye 
>
> ***Characteristics*** :  Picks fights
>
> ***Personality*** :  Wasteful
>
> ***Trait*** : I'm always polite and respectful.
>
> ***Ideal*** : Fairness. No one should get preferential treatment before the law, and no one is above the law. (Lawful)
{ .ownerDescription }



