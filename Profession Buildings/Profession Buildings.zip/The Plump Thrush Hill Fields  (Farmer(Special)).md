---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer(Special) Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Plump Thrush Hill Fields 
services: services
owner: Kubr (Gnome)
---
> [!oRPG-Layout] 
> #  The Plump Thrush Hill Fields  (Farmer(Special)/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kubr (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Plump Thrush Hill Fields  owned by [[Kubr]] (Gnome)
*Farmer(Special) / Farmer*


**Building Description:**  An new tall building, with faded paint stairs leading up to a set of double Beech wood with Bronze bands doors with a Beech frame, with brick siding. The roof is shingled. A shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Squat thin build, with red eyes and straight red hair. Their face has a goatee 
>
> ***Characteristics*** :  Entomophobic (afraid of insects)
>
> ***Personality*** :  Chivalrous
>
> ***Trait*** : I idolize a particular hero of my faith and constantly refer to that person's deeds and example.
>
> ***Ideal*** : Greater Good. My gifts are meant to be shared with all, not used for my own benefit. (Good)
{ .ownerDescription }



