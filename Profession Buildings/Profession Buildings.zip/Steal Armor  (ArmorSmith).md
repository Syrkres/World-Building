---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: ArmorSmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  Steal Armor 
services: services
owner: Branko (Halfling)
---
> [!oRPG-Layout] 
> #  Steal Armor  (ArmorSmith/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Branko (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  Steal Armor  owned by [[Branko]] (Halfling)
*ArmorSmith / *


**Building Description:**  A old building with a smithy attached to the side. An rusted anvil sits in outside yard a large smith hammer lying across the top.  



> ### Owner Description/Background
> ***Appearance*** : Squat fat build, with white eyes and thick white hair. Their face has a patch over eye 
>
> ***Characteristics*** :  Always wears as little as possible
>
> ***Personality*** :  Slanderous
>
> ***Trait*** : I miss-quote the sacred texts and proverbs in almost every situation.
>
> ***Ideal*** : Destiny. Nothing and no one can steer me away from my higher calling. (Any)
{ .ownerDescription }



