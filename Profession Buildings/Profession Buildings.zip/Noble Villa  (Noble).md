---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Noble Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Noble Villa 
services: services
owner: Roche (Human)
---
> [!oRPG-Layout] 
> #  Noble Villa  (Noble/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Roche (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Low |

##  Noble Villa  owned by [[Roche]] (Human)
*Noble / Offical*


**Building Description:**  An one story building, a set of double Ceder wood with Iron bands doors with a Hickory frame, with brick siding. The roof is shingled. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Average lean build, with hazel eyes and thinning blond hair. Their face has a bushy eyebrows 
>
> ***Characteristics*** :  Chortles
>
> ***Personality*** :  Contrary
>
> ***Trait*** : I hide scraps of food and trinkets away in my pockets.
>
> ***Ideal*** : Tradition. The ancient traditions of worship and sacrifice must be preserved and upheld. (Lawful)
{ .ownerDescription }



