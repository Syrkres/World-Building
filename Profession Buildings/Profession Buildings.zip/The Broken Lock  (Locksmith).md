---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Locksmith Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Broken Lock 
services: services
owner: Lucken (Halfling)
---
> [!oRPG-Layout] 
> #  The Broken Lock  (Locksmith/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Lucken (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Low |

##  The Broken Lock  owned by [[Lucken]] (Halfling)
*Locksmith / Crafter*


**Building Description:**  An narrow building, with faded paint with planked siding with a few boarded windows. The roof is thatched. A warn Pine crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short fat build, with red eyes and frazzled blond hair. Their face is gap-toothed 
>
> ***Characteristics*** :  Unable to figure out which color clothes match
>
> ***Personality*** :  Apprehensive
>
> ***Trait*** : I enjoy being strong and like breaking things.
>
> ***Ideal*** : Self-Knowledge. If you know yourself, there're nothing left to know. (Any)
{ .ownerDescription }



