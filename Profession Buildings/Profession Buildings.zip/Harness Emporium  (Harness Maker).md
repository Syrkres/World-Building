---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Harness Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Harness Emporium 
services: services
owner: Pemberly (Human)
---
> [!oRPG-Layout] 
> #  Harness Emporium  (Harness Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Pemberly (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  Harness Emporium  owned by [[Pemberly]] (Human)
*Harness Maker / Crafter*


**Building Description:**  An old long one story building, with faded paint a Red Oak wood door with brick siding with a front tall shuttered window that has a Beech wood door with the merchants name. The roof is thatched. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall average build, with blue eyes and very long white hair. Their face is squinty 
>
> ***Characteristics*** :  Smiles when angry/annoyed
>
> ***Personality*** :  Merciless
>
> ***Trait*** : I was, in fact, raised by wolves.
>
> ***Ideal*** : Respect. Respect is due to me because of my position, but all people regardless of station deserve to be treated with dignity. (Good)
{ .ownerDescription }



