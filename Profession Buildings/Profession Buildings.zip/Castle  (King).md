---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: King Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Castle 
services: services
owner: Cavey (Gnome)
---
> [!oRPG-Layout] 
> #  Castle  (King/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Cavey (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Above Average |

##  Castle  owned by [[Cavey]] (Gnome)
*King / Offical*


**Building Description:**  An building, with new paint stairs leading up to a set of double Beech wood doors with a Beech frame, with stoned siding with a few windows. The roof is shingled with Cherry shingles. A Cherry pergola is attached to the side. A Red Oak crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short frail build, with hazel eyes and pony-tail red hair. Their face is toothless 
>
> ***Characteristics*** :  Taunts foes
>
> ***Personality*** :  Lazy
>
> ***Trait*** : I'm a born gambler who can't resist taking a risk for a potential payoff.
>
> ***Ideal*** : Freedom. Chains are meant to be broken, as are those who would forge them. (Chaotic)
{ .ownerDescription }



