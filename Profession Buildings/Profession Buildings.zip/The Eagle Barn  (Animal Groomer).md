---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Stables
title:  The Eagle Barn 
services: services
owner: Munch (Dwarf)
---
> [!oRPG-Layout] 
> #  The Eagle Barn  (Animal Groomer/Entertainer)
> **Structure:** Stables
> **Resides In:** 
>  **Owner:** Munch (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  The Eagle Barn  owned by [[Munch]] (Dwarf)
*Animal Groomer / Entertainer*


**Building Description:**  An building with planked siding. The roof is timber. A Cherry pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Tall anorexic build, with green eyes and greasy brown hair. Their face has a bushy eyebrows 
>
> ***Characteristics*** :  Refuses to let anyone walk behind them
>
> ***Personality*** :  Suspicious
>
> ***Trait*** : I'll settle for nothing less than perfection.
>
> ***Ideal*** : Honesty. Art should reflect the soul; it should come from within and reveal who we really are. (Any)
{ .ownerDescription }



