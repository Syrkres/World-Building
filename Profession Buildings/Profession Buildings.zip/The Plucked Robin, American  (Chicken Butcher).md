---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chicken Butcher Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Plucked Robin, American 
services: services
owner: Petrellan (Gnome)
---
> [!oRPG-Layout] 
> #  The Plucked Robin, American  (Chicken Butcher/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Petrellan (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  The Plucked Robin, American  owned by [[Petrellan]] (Gnome)
*Chicken Butcher / Cooks*


**Building Description:**  An one story building, with stoned siding. The roof is shingled. A Elm shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short weak build, with green eyes and strange hairstyle red hair. Their face is buck-toothed 
>
> ***Characteristics*** :  Scarred on Right leg on Left leg on Left arm
>
> ***Personality*** :  Catty
>
> ***Trait*** : There's nothing I like more than a good mystery.
>
> ***Ideal*** : Creativity. The world is in need of new ideas and bold action. (Chaotic)
{ .ownerDescription }



