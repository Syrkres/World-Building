---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crook Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Pawn Emporium 
services: services
owner: Casbah (Human)
---
> [!oRPG-Layout] 
> #  Pawn Emporium  (Crook/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Casbah (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Below Average |

##  Pawn Emporium  owned by [[Casbah]] (Human)
*Crook / Guard*


**Building Description:**  An long building, stairs leading up to a set of double Beech wood with Steal bands doors with a Ceder frame, with planked siding with a missing window. The roof is thatching made of grass. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall weak build, with red eyes and well groomed blond hair. Their face is weather-beaten 
>
> ***Characteristics*** :  Taps feet
>
> ***Personality*** :  Deluded
>
> ***Trait*** : I place no stock in wealthy or well-mannered folk. Money and manners won't save you from a hungry owlbear.
>
> ***Ideal*** : Respect. People deserve to be treated with dignity and respect. (Good)
{ .ownerDescription }



