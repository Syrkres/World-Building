---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Beer Seller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Ale Seller 
services: services
owner: Fualla (Gnome)
---
> [!oRPG-Layout] 
> #  The Ale Seller  (Beer Seller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Fualla (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Ale Seller  owned by [[Fualla]] (Gnome)
*Beer Seller / Cooks*


**Building Description:**  An building, stairs leading up to a set of double Pine wood with Steal bands doors, with stoned siding with a missing short window. The roof is shingled with Hickory shingles. A warn Hickory crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Tall thin build, with red eyes and bald white hair. Their face is weather-beaten 
>
> ***Characteristics*** :  Tattooed on Head/Face
>
> ***Personality*** :  Casual
>
> ***Trait*** : I enjoy sailing into new ports and making new friends over a flagon of ale.
>
> ***Ideal*** : Freedom. Everyone should be free to pursue his or her livelihood. (Chaotic)
{ .ownerDescription }



