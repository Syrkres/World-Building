---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Acrobat Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: House
title:  The Fyling Lion 
services: services
owner: Purwin (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Fyling Lion  (Acrobat/Entertainer)
> **Structure:** House
> **Resides In:** 
>  **Owner:** Purwin (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  The Fyling Lion  owned by [[Purwin]] (Half-Orc)
*Acrobat / Entertainer*


**Building Description:**  An new building with faded paint and with planked siding. The roof is thatching made of straw. A Oak shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Tall frail build, with hazel eyes and bald auburn hair. Their face is weather-beaten 
>
> ***Characteristics*** :  Unable to figure out which color clothes match
>
> ***Personality*** :  Wisecracking
>
> ***Trait*** : I eat like a pig and have bad manners.
>
> ***Ideal*** : Honor. I don't steal from others in the trade. (Lawful)
{ .ownerDescription }



