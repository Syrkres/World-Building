---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tracker 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  new Club 
services: services
owner: Bricard (Gnome)
---
> [!oRPG-Layout] 
> #  new Club  (Tracker/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bricard (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  new Club  owned by [[Bricard]] (Gnome)
*Tracker / *


**Building Description:**  An building, a set of double Pine wood doors, with shingled siding. The roof is shingled.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall frail build, with red eyes and curly grey hair. Their face is gap-toothed 
>
> ***Characteristics*** :  Has nightmares
>
> ***Personality*** :  Contrary
>
> ***Trait*** : I change my mood or my mind as quickly as I change key in a song.
>
> ***Ideal*** : Glory. I must earn glory in battle, for myself and my clan. (Any)
{ .ownerDescription }



