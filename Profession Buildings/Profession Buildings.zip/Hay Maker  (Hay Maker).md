---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hay Maker 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Hay Maker 
services: services
owner: Diza (Human)
---
> [!oRPG-Layout] 
> #  Hay Maker  (Hay Maker/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Diza (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Above Average |

##  Hay Maker  owned by [[Diza]] (Human)
*Hay Maker / *


**Building Description:**  An one story building, with faded paint stairs leading up to a Steal door with a Ceder frame with shingled siding with a front window that has a painted sign hanging above with the merchants name. The roof is timber. A Beech shed structure is to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Average wide build, with blue eyes and long auburn hair. Their face has a goatee 
>
> ***Characteristics*** :  Touches people while talking to them
>
> ***Personality*** :  Pensive
>
> ***Trait*** : I once ran twenty-five miles without stopping to warn my clan of an approaching orc horde. I'd do it again if I had to.
>
> ***Ideal*** : Greater Good. My gifts are meant to be shared with all, not used for my own benefit. (Good)
{ .ownerDescription }



