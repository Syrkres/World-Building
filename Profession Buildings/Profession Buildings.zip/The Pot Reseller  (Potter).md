---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Potter Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Pot Reseller 
services: services
owner: Hannier (Halfling)
---
> [!oRPG-Layout] 
> #  The Pot Reseller  (Potter/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hannier (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  The Pot Reseller  owned by [[Hannier]] (Halfling)
*Potter / Crafter*


**Building Description:**  An narrow one story building, with brick siding. The roof is thatching made of straw. A shed structure is to the side. A few old Red Oak chests sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall fat build, with brown eyes and messy red hair. Their face is pierced 
>
> ***Characteristics*** :  Drools
>
> ***Personality*** :  Organized
>
> ***Trait*** : I idolize a particular hero of my faith and constantly refer to that person's deeds and example.
>
> ***Ideal*** : Glory. I must earn glory in battle, for myself and my clan. (Any)
{ .ownerDescription }



