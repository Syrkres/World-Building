---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Cherry Pie 
services: services
owner: Grieve (Elven)
---
> [!oRPG-Layout] 
> #  The Cherry Pie  (Baker/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Grieve (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  The Cherry Pie  owned by [[Grieve]] (Elven)
*Baker / Cooks*


**Building Description:**  An building, with stoned siding. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Grand thin build, with blue eyes and thick red hair. Their face is weather-beaten 
>
> ***Characteristics*** :  Smiles when angry/annoyed
>
> ***Personality*** :  Wistful
>
> ***Trait*** : I know a story relevant to almost every situation.
>
> ***Ideal*** : Aspiration. I'm going to prove that I'm worthy of a better life. (Any)
{ .ownerDescription }



