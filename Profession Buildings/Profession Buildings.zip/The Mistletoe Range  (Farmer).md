---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Mistletoe Range 
services: services
owner: Diza (Human)
---
> [!oRPG-Layout] 
> #  The Mistletoe Range  (Farmer/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Diza (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Above Average |

##  The Mistletoe Range  owned by [[Diza]] (Human)
*Farmer / Farmer*


**Building Description:**  An new narrow building, with new paint with brick siding. The roof is thatched. A pergola is attached to the side. A pile of Oak wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand thin build, with red eyes and thick red hair. Their face has a beard 
>
> ***Characteristics*** :  Giggles
>
> ***Personality*** :  Impetuous
>
> ***Trait*** : I face problems head-on. A simple direct solution is the best path to success.
>
> ***Ideal*** : Aspiration. I'm determined to make something of myself. (Any)
{ .ownerDescription }



