---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer(Special) Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Human Hill Meadows 
services: services
owner: Keone (Gnome)
---
> [!oRPG-Layout] 
> #  The Human Hill Meadows  (Farmer(Special)/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Keone (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  The Human Hill Meadows  owned by [[Keone]] (Gnome)
*Farmer(Special) / Farmer*


**Building Description:**  An building, with new paint with brick siding with a few boarded windows. The roof is shingled.  



> ### Owner Description/Background
> ***Appearance*** : Squat lean build, with red eyes and very long red hair. Their face has a distinctive nose 
>
> ***Characteristics*** :  Sun-burned
>
> ***Personality*** :  Selfish
>
> ***Trait*** : I have a strong sense of fair play and always try to find the most equitable solution to arguments.
>
> ***Ideal*** : Power. I hope to one day rise to the top of my faith's religious hierarchy. (Lawful)
{ .ownerDescription }



