---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barron Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Townhall
title:  Ankley's Mansion 
services: services
owner: Ankley (Halfling)
---
> [!oRPG-Layout] 
> #  Ankley's Mansion  (Barron/Offical)
> **Structure:** Townhall
> **Resides In:** 
>  **Owner:** Ankley (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  Ankley's Mansion  owned by [[Ankley]] (Halfling)
*Barron / Offical*


**Building Description:**  An old tall building with faded paint and with brick siding with a few short windows. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Tall wide build, with white eyes and short red hair. Their face has a missing right eye 
>
> ***Characteristics*** :  Paces
>
> ***Personality*** :  Mysterious
>
> ***Trait*** : I'm a born gambler who can't resist taking a risk for a potential payoff.
>
> ***Ideal*** : Power. Solitude and contemplation are paths toward mystical or magical power. (Evil)
{ .ownerDescription }



