---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Glove Merchant Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Glove Dealer 
services: services
owner: Bruh (Human)
---
> [!oRPG-Layout] 
> #  The Glove Dealer  (Glove Merchant/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bruh (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  The Glove Dealer  owned by [[Bruh]] (Human)
*Glove Merchant / Tailor*


**Building Description:**  An tall building, with new paint a Copper door with stoned siding with a few boarded windows. The roof is planked. A Elm pergola is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Tall average build, with hazel eyes and very long blond hair. Their face is doe-eyed 
>
> ***Characteristics*** :  Excessive body hair
>
> ***Personality*** :  Puerile
>
> ***Trait*** : I'm convinced that people are always trying to steal my secrets.
>
> ***Ideal*** : Community. We have to take care of each other, because no one else is going to do it. (Lawful)
{ .ownerDescription }



