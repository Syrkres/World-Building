---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Miller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Herzinger's Mill 
services: services
owner: Herzinger (Halfling)
---
> [!oRPG-Layout] 
> #  Herzinger's Mill  (Miller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Herzinger (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  Herzinger's Mill  owned by [[Herzinger]] (Halfling)
*Miller / Cooks*


**Building Description:**  An new two story building, with new paint a set of double Copper doors with a Oak frame, with stoned siding with a missing window. The roof is planked with Cherry planks.  



> ### Owner Description/Background
> ***Appearance*** : Extra short strong build, with green eyes and thinning auburn hair. Their face is grizzled 
>
> ***Characteristics*** :  Prefers to be called by last name
>
> ***Personality*** :  Proud
>
> ***Trait*** : I'm well known for my work, and I want to make sure everyone appreciates it. I'm always taken aback when people haven't heard of me.
>
> ***Ideal*** : Independence. When people follow orders blindly they embrace a kind of tyranny. (Chaotic)
{ .ownerDescription }



