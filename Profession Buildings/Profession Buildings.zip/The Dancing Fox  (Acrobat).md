---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Acrobat Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: House
title:  The Dancing Fox 
services: services
owner: Higbee (Dwarf)
---
> [!oRPG-Layout] 
> #  The Dancing Fox  (Acrobat/Entertainer)
> **Structure:** House
> **Resides In:** 
>  **Owner:** Higbee (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Average |

##  The Dancing Fox  owned by [[Higbee]] (Dwarf)
*Acrobat / Entertainer*


**Building Description:**  An new long building with new paint and with shingled siding. The roof is shingled with Hickory shingles.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall anorexic build, with green eyes and messy red hair. Their face has a missing eye 
>
> ***Characteristics*** :  Tattooed on Waist
>
> ***Personality*** :  Mean
>
> ***Trait*** : No one could doubt by looking at my regal bearing that I am a cut above the unwashed masses.
>
> ***Ideal*** : No Limits. Nothing should fetter the infinite possibility inherent in all existence. (Chaotic)
{ .ownerDescription }



