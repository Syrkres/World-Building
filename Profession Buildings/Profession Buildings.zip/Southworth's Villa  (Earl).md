---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Earl Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Southworth's Villa 
services: services
owner: Southworth (Elven)
---
> [!oRPG-Layout] 
> #  Southworth's Villa  (Earl/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Southworth (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  Southworth's Villa  owned by [[Southworth]] (Elven)
*Earl / Offical*


**Building Description:**  An old building, stairs leading up to a set of double Oak wood with Bronze bands doors with a Maple frame, with planked siding. The roof is shingled. A few old Yellow Birch chests sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Short frail build, with hazel eyes and streaked white hair. Their face has nose pierced 
>
> ***Characteristics*** :  Hemaphobic (afraid of blood)
>
> ***Personality*** :  Fanatical
>
> ***Trait*** : I have a crude sense of humor.
>
> ***Ideal*** : Charity. I always try to help those in need, no matter what the personal cost. (Good)
{ .ownerDescription }



