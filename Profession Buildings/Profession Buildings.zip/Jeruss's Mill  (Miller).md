---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Miller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Jeruss's Mill 
services: services
owner: Jeruss (Half-Orc)
---
> [!oRPG-Layout] 
> #  Jeruss's Mill  (Miller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Jeruss (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  Jeruss's Mill  owned by [[Jeruss]] (Half-Orc)
*Miller / Cooks*


**Building Description:**  An old building, with new paint with stoned siding with a missing short window. The roof is planked. A few old Pine barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short lean build, with white eyes and strange hairstyle white hair. Their face is squinty 
>
> ***Characteristics*** :  Always wears expensive clothes
>
> ***Personality*** :  Comforting
>
> ***Trait*** : I am utterly serene, even in the face of disaster.
>
> ***Ideal*** : Honor. I don't steal from others in the trade. (Lawful)
{ .ownerDescription }



