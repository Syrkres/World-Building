---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Stabler 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Stabler 
services: services
owner: Tufo (Elven)
---
> [!oRPG-Layout] 
> #  Stabler  (Stabler/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Tufo (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Low |

##  Stabler  owned by [[Tufo]] (Elven)
*Stabler / *


**Building Description:**  An tall building, with faded paint a set of double Bronze doors, with shingled siding with a few short boarded windows. The roof is timber made of Red Oak. A Elm shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short fat build, with green eyes and short blond hair. Their face has a bushy eyebrows 
>
> ***Characteristics*** :  Excessive body hair
>
> ***Personality*** :  Expressive
>
> ***Trait*** : I'm a born gambler who can't resist taking a risk for a potential payoff.
>
> ***Ideal*** : Aspiration. I work hard to be the best there is at my craft. (Any)
{ .ownerDescription }



