---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Tavern
title:  The Eagle Lodge 
services: services
owner: Jeaux (Gnome)
---
> [!oRPG-Layout] 
> #  The Eagle Lodge  (Barbarian/Guard)
> **Structure:** Tavern
> **Resides In:** 
>  **Owner:** Jeaux (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  The Eagle Lodge  owned by [[Jeaux]] (Gnome)
*Barbarian / Guard*


**Building Description:**  An new narrow one story building with new paint and with planked siding. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Short thin build, with red eyes and very long black hair. Their face has a patch over left eye 
>
> ***Characteristics*** :  Reads constantly, especially when inappropriate
>
> ***Personality*** :  Clumsy
>
> ***Trait*** : I am utterly serene, even in the face of disaster.
>
> ***Ideal*** : Respect. The thing that keeps a ship together is mutual respect between captain and crew. (Good)
{ .ownerDescription }



