---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Goat Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Long Beard Goat Farm 
services: services
owner: Commodus (Halfling)
---
> [!oRPG-Layout] 
> #  Long Beard Goat Farm  (Farmer - Goat Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Commodus (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  Long Beard Goat Farm  owned by [[Commodus]] (Halfling)
*Farmer - Goat Herder / Farmer*


**Building Description:**  An new building, with shingled siding. The roof is thatching made of grass. A Yellow Birch pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand frail build, with white eyes and wiry brown hair. Their face is toothless 
>
> ***Characteristics*** :  Rolls eyes when bored/annoyed
>
> ***Personality*** :  Bookish
>
> ***Trait*** : I'm a snob who looks down on those who can't appreciate fine art.
>
> ***Ideal*** : Logic. Emotions must not cloud our logical thinking. (Lawful)
{ .ownerDescription }



