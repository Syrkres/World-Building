---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sage Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Sage Reseller 
services: services
owner: Hawthorne (Elven)
---
> [!oRPG-Layout] 
> #  Sage Reseller  (Sage/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hawthorne (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Below Average |

##  Sage Reseller  owned by [[Hawthorne]] (Elven)
*Sage / Librarian*


**Building Description:**  An new one story building, a set of double Pine wood doors, with shingled siding with a few boarded windows. The roof is thatched. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short anorexic build, with blue eyes and well groomed white hair. Their face is pock-marked 
>
> ***Characteristics*** :  Swears profusely
>
> ***Personality*** :  Frustrated
>
> ***Trait*** : I like to squeeze into small places where no one else can get to me.
>
> ***Ideal*** : Change. The low are lifted up, and the high and mighty are brought down. Change is the nature of things. (Chaotic)
{ .ownerDescription }



