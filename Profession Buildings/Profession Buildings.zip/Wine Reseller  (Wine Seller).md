---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wine Seller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Wine Reseller 
services: services
owner: Wonders (Dwarf)
---
> [!oRPG-Layout] 
> #  Wine Reseller  (Wine Seller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Wonders (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Below Average |

##  Wine Reseller  owned by [[Wonders]] (Dwarf)
*Wine Seller / Cooks*


**Building Description:**  An building, with faded paint with shingled siding. The roof is shingled with Beech shingles. A shed is attached to the side. A Beech barrel sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Grand athletic build, with hazel eyes and frazzled grey hair. Their face has a missing left eye 
>
> ***Characteristics*** :  Giggles
>
> ***Personality*** :  Affable
>
> ***Trait*** : I'm a hopeless romantic, always searching for that 'special someone'.
>
> ***Ideal*** : Might. The strongest are meant to rule. (Evil)
{ .ownerDescription }



