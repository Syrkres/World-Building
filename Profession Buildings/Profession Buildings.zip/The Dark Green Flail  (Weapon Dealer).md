---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weapon Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Dark Green Flail 
services: services
owner: Chittock (Human)
---
> [!oRPG-Layout] 
> #  The Dark Green Flail  (Weapon Dealer/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Chittock (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Low |

##  The Dark Green Flail  owned by [[Chittock]] (Human)
*Weapon Dealer / *


**Building Description:**  An new tall building, a set of double Ceder wood with Bronze bands doors, with planked siding with a front round broken window that has a sign hanging above with the merchants name. The roof is planked. A Elm chest sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Normal average build, with red eyes and thick blond hair. Their face has a patch over right eye 
>
> ***Characteristics*** :  Urinates frequently
>
> ***Personality*** :  Self-effacing
>
> ***Trait*** : I can find common ground between the fiercest enemies, empathizing with them and always working toward peace.
>
> ***Ideal*** : Freedom. The sea is freedom--the freedom to go anywhere and do anything. (Chaotic)
{ .ownerDescription }



