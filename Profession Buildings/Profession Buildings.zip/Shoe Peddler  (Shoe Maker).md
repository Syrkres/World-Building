---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Shoe Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Shoe Peddler 
services: services
owner: Godbold (Dwarf)
---
> [!oRPG-Layout] 
> #  Shoe Peddler  (Shoe Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Godbold (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  Shoe Peddler  owned by [[Godbold]] (Dwarf)
*Shoe Maker / Tailor*


**Building Description:**  An two story building, with new paint with planked siding with a missing short window. The roof is planked with Beech planks. A shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall fat build, with brown eyes and thinning white hair. Their face is an missing ear 
>
> ***Characteristics*** :  Has nightmares
>
> ***Personality*** :  Proud
>
> ***Trait*** : I don't pay attention to the risks in a situation. Never tell me the odds.
>
> ***Ideal*** : Creativity. I never run the same con twice. (Chaotic)
{ .ownerDescription }



