---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Alchemist Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Lifes Elixir 
services: services
owner: Eusibic (Half-Orc)
---
> [!oRPG-Layout] 
> #  Lifes Elixir  (Alchemist/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Eusibic (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Above Average |

##  Lifes Elixir  owned by [[Eusibic]] (Half-Orc)
*Alchemist / Librarian*


**Building Description:**  An two story building, with faded paint with brick siding. The roof is thatching made of straw. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall thin build, with red eyes and long grey hair. Their face is an missing ear 
>
> ***Characteristics*** :  Stands very close
>
> ***Personality*** :  Nonchalant
>
> ***Trait*** : I don't like to bathe.
>
> ***Ideal*** : Greater Good. My gifts are meant to be shared with all, not used for my own benefit. (Good)
{ .ownerDescription }



