---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Wheat Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Mature Sitting Nursery 
services: services
owner: Smead (Human)
---
> [!oRPG-Layout] 
> #  The Mature Sitting Nursery  (Farmer - Wheat/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Smead (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Mature Sitting Nursery  owned by [[Smead]] (Human)
*Farmer - Wheat / Farmer*


**Building Description:**  An new tall building, stairs leading up to a Bronze door with planked siding with a missing window. The roof is shingled. A warn Red Oak barrel sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Grand fat build, with white eyes and wavy auburn hair. Their face has nose pierced 
>
> ***Characteristics*** :  Ornithophobic (afraid of birds)
>
> ***Personality*** :  Know-it-all
>
> ***Trait*** : I...speak...slowly...when talking...to idiots...which...almost...everyone...is...compared ...to me.
>
> ***Ideal*** : Fairness. No one should get preferential treatment before the law, and no one is above the law. (Lawful)
{ .ownerDescription }



