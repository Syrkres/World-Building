---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thief Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Jade Bar 
services: services
owner: Bonaventure (Gnome)
---
> [!oRPG-Layout] 
> #  The Jade Bar  (Thief/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bonaventure (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  The Jade Bar  owned by [[Bonaventure]] (Gnome)
*Thief / Guard*


**Building Description:**  An old building, with new paint stairs leading up to a set of double Copper doors, with planked siding with a missing window. The roof is thatching made of straw. A Pine shed structure is to the side. A pile of Yellow Birch wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal weak build, with green eyes and wavy red hair. Their face has a goatee 
>
> ***Characteristics*** :  Sneers
>
> ***Personality*** :  Aggressive
>
> ***Trait*** : I like to talk at length about my profession.
>
> ***Ideal*** : Respect. People deserve to be treated with dignity and respect. (Good)
{ .ownerDescription }



