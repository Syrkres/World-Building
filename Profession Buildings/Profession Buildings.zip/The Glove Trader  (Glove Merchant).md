---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Glove Merchant Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Glove Trader 
services: services
owner: Diza (Human)
---
> [!oRPG-Layout] 
> #  The Glove Trader  (Glove Merchant/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Diza (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Below Average |

##  The Glove Trader  owned by [[Diza]] (Human)
*Glove Merchant / Tailor*


**Building Description:**  An old building, with brick siding with a few short boarded windows. The roof is timber. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Short fat build, with brown eyes and greasy blond hair. Their face is buck-toothed 
>
> ***Characteristics*** :  Whistles
>
> ***Personality*** :  Foppish
>
> ***Trait*** : I judge people by their actions, not their words.
>
> ***Ideal*** : Might. The strongest are meant to rule. (Evil)
{ .ownerDescription }



