---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Stables
title:  The Boar Barn 
services: services
owner: Murdin (Gnome)
---
> [!oRPG-Layout] 
> #  The Boar Barn  (Animal Groomer/Entertainer)
> **Structure:** Stables
> **Resides In:** 
>  **Owner:** Murdin (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Average |

##  The Boar Barn  owned by [[Murdin]] (Gnome)
*Animal Groomer / Entertainer*


**Building Description:**  An old building with planked siding with a front tall boarded window that has a painted sign hanging above with the merchants name. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Squat average build, with blue eyes and thick black hair. Their face has a bushy eyebrows 
>
> ***Characteristics*** :  Refuses to let anyone walk behind them
>
> ***Personality*** :  Conformist
>
> ***Trait*** : I'm driven by a wanderlust that led me away from home.
>
> ***Ideal*** : Respect. Respect is due to me because of my position, but all people regardless of station deserve to be treated with dignity. (Good)
{ .ownerDescription }



