---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Horse Trader 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Barn Stables 
services: services
owner: Imre (Gnome)
---
> [!oRPG-Layout] 
> #  Barn Stables  (Horse Trader/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Imre (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Average |

##  Barn Stables  owned by [[Imre]] (Gnome)
*Horse Trader / *


**Building Description:**  An one story building, with new paint with shingled siding. The roof is thatching made of straw. A Hickory shed is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra short athletic build, with white eyes and messy blond hair. Their face has a missing right eye 
>
> ***Characteristics*** :  Rolls eyes when bored/annoyed
>
> ***Personality*** :  Meddlesome
>
> ***Trait*** : I'm confident in my own abilities and do what I can to instill confidence in others.
>
> ***Ideal*** : Greater Good. My gifts are meant to be shared with all, not used for my own benefit. (Good)
{ .ownerDescription }



