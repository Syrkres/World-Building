---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Taverner Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Dancing Bear Inn 
services: services
owner: Nabil (Dwarf)
---
> [!oRPG-Layout] 
> #  The Dancing Bear Inn  (Taverner/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Nabil (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Average |

##  The Dancing Bear Inn  owned by [[Nabil]] (Dwarf)
*Taverner / Cooks*


**Building Description:**  An building, with faded paint with stoned siding with a missing window. The roof is shingled.  



> ### Owner Description/Background
> ***Appearance*** : Squat frail build, with white eyes and well groomed blond hair. Their face has stained teeth 
>
> ***Characteristics*** :  Hates children
>
> ***Personality*** :  Communicative
>
> ***Trait*** : I'm rude to people who lack my commitment to hard work and fair play.
>
> ***Ideal*** : Power. Knowledge is the path to power and domination. (Evil)
{ .ownerDescription }



