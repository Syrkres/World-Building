---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wine Seller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Wine Parlor 
services: services
owner: Wrex (Dwarf)
---
> [!oRPG-Layout] 
> #  Wine Parlor  (Wine Seller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Wrex (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  Wine Parlor  owned by [[Wrex]] (Dwarf)
*Wine Seller / Cooks*


**Building Description:**  An new building, with new paint with planked siding with a front window that has stairs leading up to a Iron door with the merchants name. The roof is thatching made of grass. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Squat average build, with blue eyes and streaked brown hair. Their face has a missing right eye 
>
> ***Characteristics*** :  Hates children
>
> ***Personality*** :  Friendly
>
> ***Trait*** : Sarcasm and insults are my weapons of choice.
>
> ***Ideal*** : No Limits. Nothing should fetter the infinite possibility inherent in all existence. (Chaotic)
{ .ownerDescription }



