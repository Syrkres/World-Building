---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thief Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Crying Leopard Bar 
services: services
owner: Fulgrim (Gnome)
---
> [!oRPG-Layout] 
> #  The Crying Leopard Bar  (Thief/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Fulgrim (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Above Average |

##  The Crying Leopard Bar  owned by [[Fulgrim]] (Gnome)
*Thief / Guard*


**Building Description:**  An old long two story building, with faded paint with planked siding. The roof is thatching made of grass. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Grand strong build, with hazel eyes and curly grey hair. Their face has large scar 
>
> ***Characteristics*** :  Distinctive jewelry
>
> ***Personality*** :  Impatient
>
> ***Trait*** : I feel far more comfortable around animals than people.
>
> ***Ideal*** : Honesty. Art should reflect the soul; it should come from within and reveal who we really are. (Any)
{ .ownerDescription }



