---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Horse Trader 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Horse Dealer 
services: services
owner: Bonaventure (Dwarf)
---
> [!oRPG-Layout] 
> #  Horse Dealer  (Horse Trader/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bonaventure (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | High |

##  Horse Dealer  owned by [[Bonaventure]] (Dwarf)
*Horse Trader / *


**Building Description:**  An building, with new paint stairs leading up to a set of double Red Oak wood doors, with brick siding. The roof is thatching made of straw. A Hickory shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short strong build, with brown eyes and well groomed red hair. Their face has large ears 
>
> ***Characteristics*** :  Scratches
>
> ***Personality*** :  Peaceful
>
> ***Trait*** : I've enjoyed fine food, drink, and high society among my temple's elite. Rough living grates on me.
>
> ***Ideal*** : Greed. I'm only in it for the money and fame. (Evil)
{ .ownerDescription }



