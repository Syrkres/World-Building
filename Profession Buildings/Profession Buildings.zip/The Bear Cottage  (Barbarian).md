---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Tavern
title:  The Bear Cottage 
services: services
owner: Braver (Human)
---
> [!oRPG-Layout] 
> #  The Bear Cottage  (Barbarian/Guard)
> **Structure:** Tavern
> **Resides In:** 
>  **Owner:** Braver (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  The Bear Cottage  owned by [[Braver]] (Human)
*Barbarian / Guard*


**Building Description:**  An building with faded paint and with planked siding. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Extra short anorexic build, with hazel eyes and greasy red hair. Their face has a patch over eye 
>
> ***Characteristics*** :  Turns every conversation into story about self
>
> ***Personality*** :  Disrespectful
>
> ***Trait*** : I've been isolated for so long that I rarely speak, preferring gestures and the occasional grunt.
>
> ***Ideal*** : Master. I'm a predator, and the other ships on the sea are my prey. (Evil)
{ .ownerDescription }



