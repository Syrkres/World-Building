---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Potato Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Potato Farm 
services: services
owner: Considine (Human)
---
> [!oRPG-Layout] 
> #  Potato Farm  (Farmer - Potato/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Considine (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  Potato Farm  owned by [[Considine]] (Human)
*Farmer - Potato / Farmer*


**Building Description:**  An long building, a set of double Beech wood with Steal bands doors with a Pine frame, with brick siding. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Normal fat build, with hazel eyes and wiry grey hair. Their face has nose pierced 
>
> ***Characteristics*** :  Always arrives late
>
> ***Personality*** :  Realistic
>
> ***Trait*** : I'm driven by a wanderlust that led me away from home.
>
> ***Ideal*** : Greater Good. It is each person's responsibility to make the most happiness for the whole tribe. (Good)
{ .ownerDescription }



