---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Earl Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Earl Villa 
services: services
owner: Lew (Half-Elf)
---
> [!oRPG-Layout] 
> #  Earl Villa  (Earl/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Lew (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | High |

##  Earl Villa  owned by [[Lew]] (Half-Elf)
*Earl / Offical*


**Building Description:**  An old building, with faded paint with shingled siding. The roof is planked with Pine planks.  



> ### Owner Description/Background
> ***Appearance*** : Short average build, with red eyes and wavy blond hair. Their face has small scar 
>
> ***Characteristics*** :  Collects teeth/hair/claws of slain opponents
>
> ***Personality*** :  Deceitful
>
> ***Trait*** : I lie about almost everything, even when there's no good reason to.
>
> ***Ideal*** : Logic. Emotions must not cloud our logical thinking. (Lawful)
{ .ownerDescription }



