---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Apothecary 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The dirty water Vial 
services: services
owner: Molitor (Human)
---
> [!oRPG-Layout] 
> #  The dirty water Vial  (Apothecary/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Molitor (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Above Average |

##  The dirty water Vial  owned by [[Molitor]] (Human)
*Apothecary / *


**Building Description:**  An building, with faded paint stairs leading up to a Cherry wood door with a Maple frame with brick siding with a few windows. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Short frail build, with green eyes and dreadlocks blond hair. Their face has nose pierced 
>
> ***Characteristics*** :  Bad breath or strong body odor
>
> ***Personality*** :  Irritable
>
> ***Trait*** : I keep multiple holy symbols on me and invoke whatever deity might come in useful at any given moment.
>
> ***Ideal*** : Respect. People deserve to be treated with dignity and respect. (Good)
{ .ownerDescription }



