---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Taverner Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Blue Crown 
services: services
owner: Bai�a (Halfling)
---
> [!oRPG-Layout] 
> #  The Blue Crown  (Taverner/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bai�a (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Above Average |

##  The Blue Crown  owned by [[Bai�a]] (Halfling)
*Taverner / Cooks*


**Building Description:**  An narrow building, with new paint stairs leading up to a set of double Cherry wood with Steal bands doors with a Maple frame, with planked siding. The roof is thatching made of straw. A Red Oak shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short frail build, with red eyes and pony-tail auburn hair. Their face is buck-toothed 
>
> ***Characteristics*** :  Reads constantly, especially when inappropriate
>
> ***Personality*** :  Mouthy
>
> ***Trait*** : I enjoy being strong and like breaking things.
>
> ***Ideal*** : Power. I hope to one day rise to the top of my faith's religious hierarchy. (Lawful)
{ .ownerDescription }



