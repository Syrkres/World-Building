---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Taverner Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Eagle Mug 
services: services
owner: Kibble (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Eagle Mug  (Taverner/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kibble (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  The Eagle Mug  owned by [[Kibble]] (Half-Orc)
*Taverner / Cooks*


**Building Description:**  An long two story building, with new paint with shingled siding with a missing window. The roof is shingled. A Maple pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Tall fat build, with green eyes and bald brown hair. Their face has nose pierced 
>
> ***Characteristics*** :  Reads constantly, especially when inappropriate
>
> ***Personality*** :  Magnanimous
>
> ***Trait*** : I'm full of witty aphorisms and have a proverb for every occasion.
>
> ***Ideal*** : Might. In life as in war, the stronger force wins. (Evil)
{ .ownerDescription }



