---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Innkeeper 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Bear Inn 
services: services
owner: Forten (Gnome)
---
> [!oRPG-Layout] 
> #  The Bear Inn  (Innkeeper/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Forten (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Above Average |

##  The Bear Inn  owned by [[Forten]] (Gnome)
*Innkeeper / *


**Building Description:**  An narrow building, a Steal door with a Red Oak frame with planked siding with a missing window. The roof is thatched. A few Maple barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Average anorexic build, with red eyes and thick red hair. Their face has nose pierced 
>
> ***Characteristics*** :  Plays practical jokes
>
> ***Personality*** :  Cantankerous
>
> ***Trait*** : I connect everything that happens to me to a grand cosmic plan.
>
> ***Ideal*** : Faith. I trust that my deity will guide my actions. I have faith that if I work hard, things will go well. (Lawful)
{ .ownerDescription }



