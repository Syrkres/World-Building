---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hay Maker 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Hay Peddler 
services: services
owner: Ryn (Elven)
---
> [!oRPG-Layout] 
> #  Hay Peddler  (Hay Maker/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Ryn (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | High |

##  Hay Peddler  owned by [[Ryn]] (Elven)
*Hay Maker / *


**Building Description:**  An old tall building, a Cherry wood door with brick siding with a front short window that has stairs leading up to a Iron door with the merchants name. The roof is timber made of Oak. A pergola is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra short fat build, with green eyes and well groomed brown hair. Their face is gap-toothed 
>
> ***Characteristics*** :  Hates animals
>
> ***Personality*** :  Articulate
>
> ***Trait*** : I'm always polite and respectful.
>
> ***Ideal*** : Might. In life as in war, the stronger force wins. (Evil)
{ .ownerDescription }



