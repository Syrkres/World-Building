---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thug Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Broken Dark Orange Crown 
services: services
owner: Nuern (Elven)
---
> [!oRPG-Layout] 
> #  The Broken Dark Orange Crown  (Thug/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Nuern (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  The Broken Dark Orange Crown  owned by [[Nuern]] (Elven)
*Thug / Guard*


**Building Description:**  An new building, with shingled siding. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Normal fat build, with hazel eyes and thinning white hair. Their face has large ears 
>
> ***Characteristics*** :  Always wears tattered clothes
>
> ***Personality*** :  Hopeful
>
> ***Trait*** : I eat like a pig and have bad manners.
>
> ***Ideal*** : Nation. My city, nation, or people are all that matter. (Any)
{ .ownerDescription }



