---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sellspell Holyman
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Casters Reseller 
services: services
owner: Singeri (Dwarf)
---
> [!oRPG-Layout] 
> #  Casters Reseller  (Sellspell/Holyman)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Singeri (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Low |

##  Casters Reseller  owned by [[Singeri]] (Dwarf)
*Sellspell / Holyman*


**Building Description:**  An tall building, with new paint with brick siding with a missing tall window. The roof is shingled.  



> ### Owner Description/Background
> ***Appearance*** : Tall anorexic build, with green eyes and messy brown hair. Their face has small scar on left cheek 
>
> ***Characteristics*** :  Mutters
>
> ***Personality*** :  Miserly
>
> ***Trait*** : I am working on a grand philosophical theory and love sharing my ideas.
>
> ***Ideal*** : Logic. Emotions must not cloud our logical thinking. (Lawful)
{ .ownerDescription }



