---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Roofer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Roof Repair 
services: services
owner: Campbell (Human)
---
> [!oRPG-Layout] 
> #  Roof Repair  (Roofer/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Campbell (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  Roof Repair  owned by [[Campbell]] (Human)
*Roofer / *


**Building Description:**  An new narrow tall building, with faded paint with brick siding. The roof is thatching made of grass. A shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short weak build, with blue eyes and curly white hair. Their face is toothless 
>
> ***Characteristics*** :  Sneezes
>
> ***Personality*** :  Courteous
>
> ***Trait*** : I ask a lot of questions.
>
> ***Ideal*** : Independence. When people follow orders blindly they embrace a kind of tyranny. (Chaotic)
{ .ownerDescription }



