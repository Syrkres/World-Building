---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Missionary Holyman
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Missionary 
services: services
owner: Smead (Elven)
---
> [!oRPG-Layout] 
> #  The Missionary  (Missionary/Holyman)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Smead (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Low |

##  The Missionary  owned by [[Smead]] (Elven)
*Missionary / Holyman*


**Building Description:**  An long one story building, with faded paint a set of double Beech wood doors, with brick siding. The roof is thatching made of straw. A shed structure is to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra short thin build, with hazel eyes and bald white hair. Their face is an missing ear 
>
> ***Characteristics*** :  Unable to figure out which color clothes match
>
> ***Personality*** :  Merry
>
> ***Trait*** : I bluntly say what other people are hinting or hiding.
>
> ***Ideal*** : Honor. If I dishonor myself, I dishonor my whole clan. (Lawful)
{ .ownerDescription }



