---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Kettle Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Blue Steal Cauldron 
services: services
owner: Elam (Human)
---
> [!oRPG-Layout] 
> #  The Blue Steal Cauldron  (Kettle Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Elam (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  The Blue Steal Cauldron  owned by [[Elam]] (Human)
*Kettle Maker / Crafter*


**Building Description:**  An two story building, with faded paint with planked siding with a front tall window that has a painted sign hanging above with the merchants name. The roof is thatching made of straw. A Maple pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short frail build, with green eyes and braided grey hair. Their face has large scar 
>
> ***Characteristics*** :  Loves children
>
> ***Personality*** :  Mean
>
> ***Trait*** : I love a good insult, even one directed at me.
>
> ***Ideal*** : Master. I'm a predator, and the other ships on the sea are my prey. (Evil)
{ .ownerDescription }



