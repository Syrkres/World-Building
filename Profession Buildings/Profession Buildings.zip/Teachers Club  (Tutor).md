---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tutor Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Teachers Club 
services: services
owner: Trahan (Half-Orc)
---
> [!oRPG-Layout] 
> #  Teachers Club  (Tutor/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Trahan (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Low |

##  Teachers Club  owned by [[Trahan]] (Half-Orc)
*Tutor / Librarian*


**Building Description:**  An building, with faded paint a Pine wood with Copper bands door with a Ceder frame with planked siding. The roof is timber. A Red Oak pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Squat anorexic build, with white eyes and strange hairstyle black hair. Their face has a beard 
>
> ***Characteristics*** :  Believes all animals can talk to each other
>
> ***Personality*** :  Rebellious
>
> ***Trait*** : The common folk love me for my kindness and generosity.
>
> ***Ideal*** : Might. In life as in war, the stronger force wins. (Evil)
{ .ownerDescription }



