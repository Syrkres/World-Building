---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Wheat Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Farm 
services: services
owner: Goy (Halfling)
---
> [!oRPG-Layout] 
> #  The Farm  (Farmer - Wheat/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Goy (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Low |

##  The Farm  owned by [[Goy]] (Halfling)
*Farmer - Wheat / Farmer*


**Building Description:**  An new one story building, with faded paint with brick siding. The roof is thatching made of straw. A Elm pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal average build, with white eyes and very long brown hair. Their face is buck-toothed 
>
> ***Characteristics*** :  Puts garlic on all food
>
> ***Personality*** :  Feral
>
> ***Trait*** : I was, in fact, raised by wolves.
>
> ***Ideal*** : Master. I'm a predator, and the other ships on the sea are my prey. (Evil)
{ .ownerDescription }



