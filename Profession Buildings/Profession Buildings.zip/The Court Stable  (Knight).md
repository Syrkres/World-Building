---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Knight Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Court Stable 
services: services
owner: Fedevich (Halfling)
---
> [!oRPG-Layout] 
> #  The Court Stable  (Knight/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Fedevich (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Average |

##  The Court Stable  owned by [[Fedevich]] (Halfling)
*Knight / Guard*


**Building Description:**  An long building, a set of double Steal doors with a Red Oak frame, with stoned siding with a few windows. The roof is planked with Red Oak planks.  



> ### Owner Description/Background
> ***Appearance*** : Short strong build, with white eyes and very long black hair. Their face has a broken nose 
>
> ***Characteristics*** :  Covered in sores, boils, or a rash
>
> ***Personality*** :  Obedient
>
> ***Trait*** : I was, in fact, raised by wolves.
>
> ***Ideal*** : Respect. All people, rich or poor, deserve respect. (Good)
{ .ownerDescription }



