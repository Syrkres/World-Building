---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Pig Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Lichen Meadows 
services: services
owner: Alistare (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Lichen Meadows  (Farmer - Pig Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Alistare (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  The Lichen Meadows  owned by [[Alistare]] (Half-Orc)
*Farmer - Pig Herder / Farmer*


**Building Description:**  An two story building, with faded paint with brick siding. The roof is shingled with Elm shingles. A shed structure is to the side. A pile of Oak wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall weak build, with red eyes and very long grey hair. Their face has sideburns 
>
> ***Characteristics*** :  Freckled
>
> ***Personality*** :  Mischievous
>
> ***Trait*** : I ask a lot of questions.
>
> ***Ideal*** : Responsibility. It is my duty to respect the authority of those above me, just as those below me must respect mine. (Lawful)
{ .ownerDescription }



