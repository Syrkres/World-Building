---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Apothecary 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Glass Bottle 
services: services
owner: Wyndehall (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Glass Bottle  (Apothecary/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Wyndehall (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Low |

##  The Glass Bottle  owned by [[Wyndehall]] (Half-Elf)
*Apothecary / *


**Building Description:**  An old narrow building, with faded paint stairs leading up to a Steal door with shingled siding with a few round windows. The roof is timber. A few old Oak chests sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Tall weak build, with brown eyes and pony-tail brown hair. Their face is grizzled 
>
> ***Characteristics*** :  Clicks tongue
>
> ***Personality*** :  Jolly
>
> ***Trait*** : I once ran twenty-five miles without stopping to warn my clan of an approaching orc horde. I'd do it again if I had to.
>
> ***Ideal*** : Beauty. What is beautiful points us beyond itself toward what is true. (Good)
{ .ownerDescription }



