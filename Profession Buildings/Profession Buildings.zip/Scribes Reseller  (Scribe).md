---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Scribe 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Scribes Reseller 
services: services
owner: Kula (Gnome)
---
> [!oRPG-Layout] 
> #  Scribes Reseller  (Scribe/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kula (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Low |

##  Scribes Reseller  owned by [[Kula]] (Gnome)
*Scribe / *


**Building Description:**  An two story building, with faded paint stairs leading up to a set of double Maple wood with Iron bands doors, with shingled siding with a missing short window. The roof is planked. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal strong build, with white eyes and limp brown hair. Their face has a missing left eye 
>
> ***Characteristics*** :  Loves animals
>
> ***Personality*** :  Caring
>
> ***Trait*** : I'm a born gambler who can't resist taking a risk for a potential payoff.
>
> ***Ideal*** : Might. In life as in war, the stronger force wins. (Evil)
{ .ownerDescription }



