---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cabbage Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Aged Stone Fields 
services: services
owner: Berrak (Gnome)
---
> [!oRPG-Layout] 
> #  Aged Stone Fields  (Farmer - Cabbage/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Berrak (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Above Average |

##  Aged Stone Fields  owned by [[Berrak]] (Gnome)
*Farmer - Cabbage / Farmer*


**Building Description:**  An new one story building, with shingled siding with a few short windows. The roof is planked. A shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Average athletic build, with green eyes and braided brown hair. Their face is grizzled 
>
> ***Characteristics*** :  Hemaphobic (afraid of blood)
>
> ***Personality*** :  Gracious
>
> ***Trait*** : I get bored easily. When am I going to get on with my destiny.
>
> ***Ideal*** : Greed. I'm only in it for the money. (Evil)
{ .ownerDescription }



