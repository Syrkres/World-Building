---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thief Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Lion Tavern 
services: services
owner: Chesloff (Halfling)
---
> [!oRPG-Layout] 
> #  The Lion Tavern  (Thief/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Chesloff (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  The Lion Tavern  owned by [[Chesloff]] (Halfling)
*Thief / Guard*


**Building Description:**  An old building, with faded paint stairs leading up to a Bronze door with stoned siding with a front short boarded window that has a Yellow Birch wood door with a Cherry frame with the merchants name. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Short fat build, with brown eyes and greasy red hair. Their face is toothless 
>
> ***Characteristics*** :  Limps
>
> ***Personality*** :  Condescending
>
> ***Trait*** : I'm driven by a wanderlust that led me away from home.
>
> ***Ideal*** : Responsibility. I do what I must and obey just authority. (Lawful)
{ .ownerDescription }



