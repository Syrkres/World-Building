---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armor Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Copper Scalemail Trader 
services: services
owner: Yubi (Human)
---
> [!oRPG-Layout] 
> #  The Copper Scalemail Trader  (Armor Dealer/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Yubi (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Below Average |

##  The Copper Scalemail Trader  owned by [[Yubi]] (Human)
*Armor Dealer / *


**Building Description:**  A old tall building with a smithy structure to the side. An anvil sits in outside shed a large smith hammer lying across the top with various Mace lying about. A saw horse with hay strewn about, a sledge hammer leaning on the edge. A warn Ceder crate filled with water, with a Drill leaning against the base.  



> ### Owner Description/Background
> ***Appearance*** : Extra short frail build, with green eyes and wavy blond hair. Their face has large ears 
>
> ***Characteristics*** :  If unable to recall word, stops conversation and will not give up until can finally remember it
>
> ***Personality*** :  Angry
>
> ***Trait*** : I believe that everything worth doing is worth doing right. I can't help it--I'm a perfectionist.
>
> ***Ideal*** : Family. Blood runs thicker than water. (Any)
{ .ownerDescription }



