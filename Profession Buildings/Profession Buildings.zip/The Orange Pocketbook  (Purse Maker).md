---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Purse Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Orange Pocketbook 
services: services
owner: Lasfe (Halfling)
---
> [!oRPG-Layout] 
> #  The Orange Pocketbook  (Purse Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Lasfe (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Below Average |

##  The Orange Pocketbook  owned by [[Lasfe]] (Halfling)
*Purse Maker / Tailor*


**Building Description:**  An new narrow tall building, a set of double Oak wood doors, with brick siding. The roof is thatched. A Ceder shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall thin build, with green eyes and short grey hair. Their face is buck-toothed 
>
> ***Characteristics*** :  Picks scabs
>
> ***Personality*** :  Courteous
>
> ***Trait*** : I...speak...slowly...when talking...to idiots...which...almost...everyone...is...compared ...to me.
>
> ***Ideal*** : Community. It is the duty of all civilized people to strengthen the bonds of community and the security of civilization. (Lawful)
{ .ownerDescription }



