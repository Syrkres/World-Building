---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weapon Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Light Orange Sword 
services: services
owner: Mombril (Elven)
---
> [!oRPG-Layout] 
> #  The Light Orange Sword  (Weapon Dealer/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Mombril (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  The Light Orange Sword  owned by [[Mombril]] (Elven)
*Weapon Dealer / *


**Building Description:**  An new building, with faded paint stairs leading up to a Copper door with a Hickory frame with shingled siding with a few boarded windows. The roof is thatched. A shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short weak build, with brown eyes and braided grey hair. Their face has a missing eye 
>
> ***Characteristics*** :  Loves children
>
> ***Personality*** :  Dramatic
>
> ***Trait*** : I know a story relevant to almost every situation.
>
> ***Ideal*** : Tradition. The stories, legends, and songs of the past must never be forgotten. (Lawful)
{ .ownerDescription }



