---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: ArmorSmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Platinum Ringmail Smith 
services: services
owner: Janis (Elven)
---
> [!oRPG-Layout] 
> #  The Platinum Ringmail Smith  (ArmorSmith/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Janis (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Above Average |

##  The Platinum Ringmail Smith  owned by [[Janis]] (Elven)
*ArmorSmith / *


**Building Description:**  An two story building. An rusted anvil sits in the corner of the yard a large smith hammer lying across the top.  



> ### Owner Description/Background
> ***Appearance*** : Extra short thin build, with white eyes and wiry red hair. Their face has a patch over right eye 
>
> ***Characteristics*** :  Picks fights
>
> ***Personality*** :  Quirky
>
> ***Trait*** : I have a lesson for every situation, drawn from observing nature.
>
> ***Ideal*** : Ideals aren't worth killing for or going to war for. (Neutral)
{ .ownerDescription }



