---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer(Special) Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Aged Beech Nursery 
services: services
owner: Adderfeld (Dwarf)
---
> [!oRPG-Layout] 
> #  The Aged Beech Nursery  (Farmer(Special)/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Adderfeld (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Aged Beech Nursery  owned by [[Adderfeld]] (Dwarf)
*Farmer(Special) / Farmer*


**Building Description:**  An new building, a Steal door with a Maple frame with stoned siding with a missing window. The roof is planked. A pile of Pine wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Tall fat build, with white eyes and wavy white hair. Their face has a patch over right eye 
>
> ***Characteristics*** :  Blinks constantly
>
> ***Personality*** :  Odd
>
> ***Trait*** : I'm confident in my own abilities and do what I can to instill confidence in others.
>
> ***Ideal*** : Might. In life as in war, the stronger force wins. (Evil)
{ .ownerDescription }



