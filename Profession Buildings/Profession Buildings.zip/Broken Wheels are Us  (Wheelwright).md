---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wheelwright 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Broken Wheels are Us 
services: services
owner: Considine (Gnome)
---
> [!oRPG-Layout] 
> #  Broken Wheels are Us  (Wheelwright/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Considine (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Average |

##  Broken Wheels are Us  owned by [[Considine]] (Gnome)
*Wheelwright / *


**Building Description:**  An new narrow building, with new paint with shingled siding. The roof is planked with Maple planks. A Yellow Birch shed is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Squat fat build, with blue eyes and strange hairstyle grey hair. Their face is an missing ear 
>
> ***Characteristics*** :  Wears hat or hood
>
> ***Personality*** :  Chivalrous
>
> ***Trait*** : The first thing I do in a new place is note the locations of everything valuable--or where such things could be hidden.
>
> ***Ideal*** : Master. I'm a predator, and the other ships on the sea are my prey. (Evil)
{ .ownerDescription }



