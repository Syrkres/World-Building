---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cow Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Old Bull Range 
services: services
owner: Mehmet (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Old Bull Range  (Farmer - Cow Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Mehmet (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Low |

##  The Old Bull Range  owned by [[Mehmet]] (Half-Elf)
*Farmer - Cow Herder / Farmer*


**Building Description:**  An new narrow building, with new paint stairs leading up to a Beech wood door with stoned siding. The roof is thatched. A shed is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Squat wide build, with brown eyes and thick black hair. Their face has lip pierced 
>
> ***Characteristics*** :  Chortles
>
> ***Personality*** :  Proud
>
> ***Trait*** : I change my mood or my mind as quickly as I change key in a song.
>
> ***Ideal*** : Freedom. Tyrants must not be allowed to oppress the people. (Chaotic)
{ .ownerDescription }



