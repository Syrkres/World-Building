---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Wheat Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Long Grain Grass Farm 
services: services
owner: Mauna (Human)
---
> [!oRPG-Layout] 
> #  Long Grain Grass Farm  (Farmer - Wheat/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Mauna (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  Long Grain Grass Farm  owned by [[Mauna]] (Human)
*Farmer - Wheat / Farmer*


**Building Description:**  An building, with planked siding with a front short broken window that has a Hickory wood with Bronze bands door with the merchants name. The roof is thatching made of straw. A Maple shed is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Grand frail build, with white eyes and thick blond hair. Their face has a moustache 
>
> ***Characteristics*** :  Birthmark on Back on Waist
>
> ***Personality*** :  Agreeable
>
> ***Trait*** : I am tolerant of other faiths and respect (or condemn) the worship of other gods.
>
> ***Ideal*** : Responsibility. It is my duty to respect the authority of those above me, just as those below me must respect mine. (Lawful)
{ .ownerDescription }



