---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Teamster Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Order Structure 
services: services
owner: Forten (Dwarf)
---
> [!oRPG-Layout] 
> #  Order Structure  (Teamster/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Forten (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Low |

##  Order Structure  owned by [[Forten]] (Dwarf)
*Teamster / Professional*


**Building Description:**  An new building, a Maple wood with Copper bands door with stoned siding with a missing window. The roof is thatching made of grass. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra short fat build, with green eyes and thinning black hair. Their face has no eyebrows 
>
> ***Characteristics*** :  Sleeps late
>
> ***Personality*** :  Modest
>
> ***Trait*** : I don't part with my money easily and will haggle tirelessly to get the best deal possible.
>
> ***Ideal*** : Greater Good. My gifts are meant to be shared with all, not used for my own benefit. (Good)
{ .ownerDescription }



