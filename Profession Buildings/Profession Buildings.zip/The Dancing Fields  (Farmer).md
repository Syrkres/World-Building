---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Dancing Fields 
services: services
owner: Gupta (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Dancing Fields  (Farmer/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Gupta (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Low |

##  The Dancing Fields  owned by [[Gupta]] (Half-Elf)
*Farmer / Farmer*


**Building Description:**  An old building, a set of double Steal doors with a Cherry frame, with brick siding with a few boarded windows. The roof is thatching made of straw. A shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Average strong build, with green eyes and braided red hair. Their face is squinty 
>
> ***Characteristics*** :  Hemaphobic (afraid of blood)
>
> ***Personality*** :  Sober
>
> ***Trait*** : The common folk love me for my kindness and generosity.
>
> ***Ideal*** : Responsibility. It is my duty to respect the authority of those above me, just as those below me must respect mine. (Lawful)
{ .ownerDescription }



