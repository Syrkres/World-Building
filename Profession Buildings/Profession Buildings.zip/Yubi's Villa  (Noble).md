---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Noble Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Yubi's Villa 
services: services
owner: Yubi (Halfling)
---
> [!oRPG-Layout] 
> #  Yubi's Villa  (Noble/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Yubi (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Low |

##  Yubi's Villa  owned by [[Yubi]] (Halfling)
*Noble / Offical*


**Building Description:**  An old building, with new paint a Elm wood with Copper bands door with a Hickory frame with brick siding with a missing tall window. The roof is thatching made of straw. A Maple shed is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Short thin build, with brown eyes and straight grey hair. Their face has eyebrow pierced 
>
> ***Characteristics*** :  Smokes
>
> ***Personality*** :  Flamboyant
>
> ***Trait*** : I am intolerant of other faiths and respect (or condemn) the worship of other gods.
>
> ***Ideal*** : Aspiration. I seek to prove my self worthy of my god's favor by matching my actions against his or her teachings. (Any)
{ .ownerDescription }



