---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The new Broach 
services: services
owner: Rraey (Elven)
---
> [!oRPG-Layout] 
> #  The new Broach  (Antiquities/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Rraey (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Above Average |

##  The new Broach  owned by [[Rraey]] (Elven)
*Antiquities / Offical*


**Building Description:**  An new two story building, stairs leading up to a set of double Steal doors with a Yellow Birch frame, with stoned siding with a missing window. The roof is planked with Beech planks. A Elm shed structure is to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Normal fat build, with hazel eyes and well groomed red hair. Their face is buck-toothed 
>
> ***Characteristics*** :  Thinks they are very lucky
>
> ***Personality*** :  Shallow
>
> ***Trait*** : I don't part with my money easily and will haggle tirelessly to get the best deal possible.
>
> ***Ideal*** : Freedom. The sea is freedom--the freedom to go anywhere and do anything. (Chaotic)
{ .ownerDescription }



