---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Bannana Tart 
services: services
owner: Shiga (Gnome)
---
> [!oRPG-Layout] 
> #  The Bannana Tart  (Baker/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Shiga (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | High |

##  The Bannana Tart  owned by [[Shiga]] (Gnome)
*Baker / Cooks*


**Building Description:**  An two story building, stairs leading up to a set of double Elm wood with Bronze bands doors, with planked siding with a missing short window. The roof is timber made of Oak. A Maple pergola is attached to the side. A pile of Beech wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Short lean build, with red eyes and greasy white hair. Their face has a broken nose 
>
> ***Characteristics*** :  Swears profusely
>
> ***Personality*** :  Rascal
>
> ***Trait*** : I once ran twenty-five miles without stopping to warn my clan of an approaching orc horde. I'd do it again if I had to.
>
> ***Ideal*** : Aspiration. I'm determined to make something of myself. (Any)
{ .ownerDescription }



