---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Chubby Oxen Nursery 
services: services
owner: Risso (Dwarf)
---
> [!oRPG-Layout] 
> #  The Chubby Oxen Nursery  (Farmer - Cattle Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Risso (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | High |

##  The Chubby Oxen Nursery  owned by [[Risso]] (Dwarf)
*Farmer - Cattle Herder / Farmer*


**Building Description:**  An old building, with planked siding with a few short windows. The roof is timber made of Hickory. A shed is attached to the side. A few Ceder crates sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Tall thin build, with blue eyes and frazzled auburn hair. Their face is an missing ear 
>
> ***Characteristics*** :  Claustrophobic (afraid of small spaces)
>
> ***Personality*** :  Confident
>
> ***Trait*** : I can find common ground between the fiercest enemies, empathizing with them and always working toward peace.
>
> ***Ideal*** : Greater Good. Our lot is to lay down our lives in defense of others. (Good)
{ .ownerDescription }



