---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Saddler Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Saddle Maker 
services: services
owner: Higbee (Human)
---
> [!oRPG-Layout] 
> #  Saddle Maker  (Saddler/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Higbee (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Low |

##  Saddle Maker  owned by [[Higbee]] (Human)
*Saddler / Crafter*


**Building Description:**  An long building, a set of double Cherry wood with Bronze bands doors with a Cherry frame, with stoned siding with a front short window that has a Steal door with the merchants name. The roof is shingled.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall weak build, with red eyes and pony-tail red hair. Their face has small scar 
>
> ***Characteristics*** :  Tone-deaf
>
> ***Personality*** :  Analytical
>
> ***Trait*** : I don't like to get my hands dirty, and I won't be caught dead in unsuitable accommodations.
>
> ***Ideal*** : Self-Knowledge. If you know yourself, there're nothing left to know. (Any)
{ .ownerDescription }



