---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Acrobat Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: House
title:  The Crying Griffon 
services: services
owner: Omar (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Crying Griffon  (Acrobat/Entertainer)
> **Structure:** House
> **Resides In:** 
>  **Owner:** Omar (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Low |

##  The Crying Griffon  owned by [[Omar]] (Half-Elf)
*Acrobat / Entertainer*


**Building Description:**  An old building with faded paint and with brick siding with a front window that has stairs leading up to a Bronze door with the merchants name. The roof is thatching made of straw. A Elm pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand athletic build, with brown eyes and limp red hair. Their face has a distinctive nose 
>
> ***Characteristics*** :  Excessively clean
>
> ***Personality*** :  Magnanimous
>
> ***Trait*** : If someone is in trouble, I'm always willing to lend help.
>
> ***Ideal*** : Freedom. Everyone should be free to pursue his or her livelihood. (Chaotic)
{ .ownerDescription }



