---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Mage Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Mage Spire 
services: services
owner: Bronleewe (Human)
---
> [!oRPG-Layout] 
> #  Mage Spire  (High Mage/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bronleewe (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Low |

##  Mage Spire  owned by [[Bronleewe]] (Human)
*High Mage / Librarian*


**Building Description:**  An old one story building, stairs leading up to a set of double Copper doors with a Red Oak frame, with shingled siding with a missing window. The roof is thatched. A Beech shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short anorexic build, with white eyes and long auburn hair. Their face has a distinctive nose 
>
> ***Characteristics*** :  Sings
>
> ***Personality*** :  Treacherous
>
> ***Trait*** : I fall in and out of love easily, and am always pursuing someone.
>
> ***Ideal*** : Fairness. I never target people who can't afford to lose a few coins. (Lawful)
{ .ownerDescription }



