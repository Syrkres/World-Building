---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Prince Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Ott's Keep 
services: services
owner: Ott (Dwarf)
---
> [!oRPG-Layout] 
> #  Ott's Keep  (Prince/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Ott (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Below Average |

##  Ott's Keep  owned by [[Ott]] (Dwarf)
*Prince / Offical*


**Building Description:**  An long building, with planked siding with a few windows. The roof is thatching made of grass. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Normal fat build, with red eyes and very long black hair. Their face has large scar on right cheek 
>
> ***Characteristics*** :  Loves the sea and ships
>
> ***Personality*** :  Sociable
>
> ***Trait*** : I never pass up a friendly wager.
>
> ***Ideal*** : Glory. I must earn glory in battle, for myself and my clan. (Any)
{ .ownerDescription }



