---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: WeaponSmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Dark Grey Sword 
services: services
owner: Fowlton (Gnome)
---
> [!oRPG-Layout] 
> #  The Dark Grey Sword  (WeaponSmith/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Fowlton (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  The Dark Grey Sword  owned by [[Fowlton]] (Gnome)
*WeaponSmith / *


**Building Description:**  An building with faded paint. An anvil sits in outside yard a large smith hammer lying across the top with various Spear lying about. A Elm crate filled with water, with a Grappling Hook leaning against the base.  



> ### Owner Description/Background
> ***Appearance*** : Tall strong build, with brown eyes and frazzled grey hair. Their face is grizzled 
>
> ***Characteristics*** :  Clicks tongue
>
> ***Personality*** :  Unruly
>
> ***Trait*** : I'm convinced that people are always trying to steal my secrets.
>
> ***Ideal*** : Greed. I'm only in it for the money. (Evil)
{ .ownerDescription }



