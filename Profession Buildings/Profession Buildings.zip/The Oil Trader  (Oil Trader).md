---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Oil Trader Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Oil Trader 
services: services
owner: Gupta (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Oil Trader  (Oil Trader/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Gupta (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  The Oil Trader  owned by [[Gupta]] (Half-Orc)
*Oil Trader / Offical*


**Building Description:**  An new building, stairs leading up to a set of double Oak wood doors, with brick siding. The roof is planked with Elm planks. A warn Beech crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall weak build, with green eyes and greasy red hair. Their face has a missing eye 
>
> ***Characteristics*** :  Leers
>
> ***Personality*** :  Furtive
>
> ***Trait*** : Thinking is for other people. I prefer action.
>
> ***Ideal*** : Destiny. Nothing and no one can steer me away from my higher calling. (Any)
{ .ownerDescription }



