---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Laborer Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Company Hall 
services: services
owner: Rorken (Halfling)
---
> [!oRPG-Layout] 
> #  Company Hall  (Laborer/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Rorken (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  Company Hall  owned by [[Rorken]] (Halfling)
*Laborer / Professional*


**Building Description:**  An building, with faded paint with brick siding. The roof is shingled with Cherry shingles. A pergola is attached to the side. A pile of Ceder wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall frail build, with blue eyes and short grey hair. Their face is squinty 
>
> ***Characteristics*** :  Needs story before sleeping
>
> ***Personality*** :  Frivolous
>
> ***Trait*** : If you do me an injury, I will crush you, ruin your name, and salt your fields.
>
> ***Ideal*** : Fairness. We all do the work, so we all share in the rewards. (Lawful)
{ .ownerDescription }



