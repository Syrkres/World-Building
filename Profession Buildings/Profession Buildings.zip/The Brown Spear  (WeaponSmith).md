---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: WeaponSmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Brown Spear 
services: services
owner: Heldane (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Brown Spear  (WeaponSmith/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Heldane (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  The Brown Spear  owned by [[Heldane]] (Half-Orc)
*WeaponSmith / *


**Building Description:**  A old building with a smithy structure to the side. An polished anvil sits in the corner of the yard a large smith hammer lying across the top with various Mace lying about. A Beech barrel filled with water, with a Grappling Hook leaning against the base. A Beech barrel filled with water, with a Glass Cutter leaning against the base.  



> ### Owner Description/Background
> ***Appearance*** : Extra short average build, with blue eyes and greasy blond hair. Their face has a moustache 
>
> ***Characteristics*** :  Bad/loud/annoying/shrill laugh
>
> ***Personality*** :  Shrewd
>
> ***Trait*** : If you do me an injury, I will crush you, ruin your name, and salt your fields.
>
> ***Ideal*** : Beauty. When I perform, I make the world better than it was. (Good)
{ .ownerDescription }



