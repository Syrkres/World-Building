---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Beer Seller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Grog Seller 
services: services
owner: Heldane (Halfling)
---
> [!oRPG-Layout] 
> #  The Grog Seller  (Beer Seller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Heldane (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  The Grog Seller  owned by [[Heldane]] (Halfling)
*Beer Seller / Cooks*


**Building Description:**  An one story building, with faded paint with brick siding. The roof is thatching made of grass. A Maple pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short athletic build, with white eyes and short red hair. Their face has a missing left eye 
>
> ***Characteristics*** :  Hydrophobic (afraid of water)
>
> ***Personality*** :  Drunkard
>
> ***Trait*** : I'm used to helping out those who aren't as smart as I am, and I patiently explain anything and everything to others.
>
> ***Ideal*** : Aspiration. I seek to prove my self worthy of my god's favor by matching my actions against his or her teachings. (Any)
{ .ownerDescription }



