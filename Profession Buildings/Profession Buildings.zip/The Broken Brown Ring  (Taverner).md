---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Taverner Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Broken Brown Ring 
services: services
owner: Hurlie (Dwarf)
---
> [!oRPG-Layout] 
> #  The Broken Brown Ring  (Taverner/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hurlie (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Broken Brown Ring  owned by [[Hurlie]] (Dwarf)
*Taverner / Cooks*


**Building Description:**  An old narrow building, with faded paint a set of double Iron doors with a Beech frame, with brick siding. The roof is planked. A Oak shed is attached to the side. A Pine chest sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short average build, with hazel eyes and long brown hair. Their face is gap-toothed 
>
> ***Characteristics*** :  Thinks they are very lucky
>
> ***Personality*** :  Braggart
>
> ***Trait*** : I'm rude to people who lack my commitment to hard work and fair play.
>
> ***Ideal*** : Fairness. We all do the work, so we all share in the rewards. (Lawful)
{ .ownerDescription }



