---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Fishmonger Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Catfish Monger 
services: services
owner: Crote (Dwarf)
---
> [!oRPG-Layout] 
> #  The Catfish Monger  (Fishmonger/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Crote (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Average |

##  The Catfish Monger  owned by [[Crote]] (Dwarf)
*Fishmonger / Cooks*


**Building Description:**  An new building, with new paint a set of double Oak wood with Copper bands doors, with brick siding with a missing window. The roof is timber made of Beech. A shed structure is to the side. A pile of Oak wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Average fat build, with brown eyes and limp black hair. Their face has large scar 
>
> ***Characteristics*** :  Plays practical jokes
>
> ***Personality*** :  Excited
>
> ***Trait*** : I am utterly serene, even in the face of disaster.
>
> ***Ideal*** : Self-improvement. The goal of a life of study is the betterment of oneself.
{ .ownerDescription }



