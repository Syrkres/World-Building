---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tinker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Clockwork Reseller 
services: services
owner: Eusibic (Half-Orc)
---
> [!oRPG-Layout] 
> #  Clockwork Reseller  (Tinker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Eusibic (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  Clockwork Reseller  owned by [[Eusibic]] (Half-Orc)
*Tinker / Crafter*


**Building Description:**  An old building, with shingled siding. The roof is thatching made of straw. A pergola is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall fat build, with red eyes and wavy brown hair. Their face has a patch over eye 
>
> ***Characteristics*** :  Dirty
>
> ***Personality*** :  Sadistic
>
> ***Trait*** : I have a crude sense of humor.
>
> ***Ideal*** : Aspiration. I'm going to prove that I'm worthy of a better life. (Any)
{ .ownerDescription }



