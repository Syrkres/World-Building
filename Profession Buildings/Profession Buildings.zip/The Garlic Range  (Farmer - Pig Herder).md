---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Pig Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Garlic Range 
services: services
owner: Sonor (Elven)
---
> [!oRPG-Layout] 
> #  The Garlic Range  (Farmer - Pig Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Sonor (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Low |

##  The Garlic Range  owned by [[Sonor]] (Elven)
*Farmer - Pig Herder / Farmer*


**Building Description:**  An two story building, stairs leading up to a set of double Iron doors with a Ceder frame, with shingled siding with a few tall shuttered windows. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Extra short strong build, with blue eyes and straight grey hair. Their face has sideburns 
>
> ***Characteristics*** :  Hemaphobic (afraid of blood)
>
> ***Personality*** :  Foppish
>
> ***Trait*** : Nobody stays angry at me or around me for long, since I can defuse any amount of tension.
>
> ***Ideal*** : Greed. I'm only in it for the money and fame. (Evil)
{ .ownerDescription }



