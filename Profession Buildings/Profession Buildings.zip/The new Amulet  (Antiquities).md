---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The new Amulet 
services: services
owner: Tanko-brey (Gnome)
---
> [!oRPG-Layout] 
> #  The new Amulet  (Antiquities/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Tanko-brey (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | High |

##  The new Amulet  owned by [[Tanko-brey]] (Gnome)
*Antiquities / Offical*


**Building Description:**  An tall building, with shingled siding with a few windows. The roof is shingled with Maple shingles. A shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short wide build, with hazel eyes and streaked white hair. Their face is missing teeth 
>
> ***Characteristics*** :  Always has something in hands
>
> ***Personality*** :  Feisty
>
> ***Trait*** : I don't pay attention to the risks in a situation. Never tell me the odds.
>
> ***Ideal*** : Freedom. Tyrants must not be allowed to oppress the people. (Chaotic)
{ .ownerDescription }



