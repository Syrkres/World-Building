---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Orange Cake 
services: services
owner: Roche (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Orange Cake  (Baker/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Roche (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  The Orange Cake  owned by [[Roche]] (Half-Orc)
*Baker / Cooks*


**Building Description:**  An new building, with new paint stairs leading up to a set of double Beech wood doors, with brick siding. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Tall athletic build, with white eyes and dreadlocks blond hair. Their face is grizzled 
>
> ***Characteristics*** :  Limps
>
> ***Personality*** :  Sensitive
>
> ***Trait*** : I use polysyllabic words to convey the impression of great erudition.
>
> ***Ideal*** : Logic. Emotions must not cloud our sense of what is right and true, or our logical thinking. (Lawful)
{ .ownerDescription }



