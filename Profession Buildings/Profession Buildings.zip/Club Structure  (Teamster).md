---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Teamster Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Club Structure 
services: services
owner: Crawley (Half-Orc)
---
> [!oRPG-Layout] 
> #  Club Structure  (Teamster/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Crawley (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Low |

##  Club Structure  owned by [[Crawley]] (Half-Orc)
*Teamster / Professional*


**Building Description:**  An tall building, with faded paint with shingled siding. The roof is shingled with Beech shingles. A few new Oak crates sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Short frail build, with red eyes and streaked blond hair. Their face is weather-beaten 
>
> ***Characteristics*** :  Always wears same color
>
> ***Personality*** :  Excited
>
> ***Trait*** : The common folk love me for my kindness and generosity.
>
> ***Ideal*** : Freedom. Everyone should be free to pursue his or her livelihood. (Chaotic)
{ .ownerDescription }



