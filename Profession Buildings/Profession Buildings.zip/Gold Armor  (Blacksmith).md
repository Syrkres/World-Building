---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Blacksmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Gold Armor 
services: services
owner: Ham (Elven)
---
> [!oRPG-Layout] 
> #  Gold Armor  (Blacksmith/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Ham (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Average |

##  Gold Armor  owned by [[Ham]] (Elven)
*Blacksmith / *


**Building Description:**  An building, with faded paint with brick siding with a front broken window that has stairs leading up to a Steal door with the merchants name. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Squat weak build, with red eyes and greasy black hair. Their face has no eyebrows 
>
> ***Characteristics*** :  Dandruff
>
> ***Personality*** :  Furtive
>
> ***Trait*** : My favor, once lost, is lost forever.
>
> ***Ideal*** : Destiny. Nothing and no one can steer me away from my higher calling. (Any)
{ .ownerDescription }



