---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Stables
title:  The Griffon Barn 
services: services
owner: Patricio (Halfling)
---
> [!oRPG-Layout] 
> #  The Griffon Barn  (Animal Groomer/Entertainer)
> **Structure:** Stables
> **Resides In:** 
>  **Owner:** Patricio (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  The Griffon Barn  owned by [[Patricio]] (Halfling)
*Animal Groomer / Entertainer*


**Building Description:**  An building with faded paint and with planked siding with a few tall boarded windows. The roof is planked with Beech planks.  



> ### Owner Description/Background
> ***Appearance*** : Tall athletic build, with white eyes and thick grey hair. Their face is chiseled 
>
> ***Characteristics*** :  Leers
>
> ***Personality*** :  Surly
>
> ***Trait*** : I can stare down a hellhound without flinching.
>
> ***Ideal*** : Self-improvement. The goal of a life of study is the betterment of oneself.
{ .ownerDescription }



