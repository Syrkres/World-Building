---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Candle Maker Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Lighted Path 
services: services
owner: Raboso (Human)
---
> [!oRPG-Layout] 
> #  The Lighted Path  (Candle Maker/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Raboso (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Lighted Path  owned by [[Raboso]] (Human)
*Candle Maker / Professional*


**Building Description:**  An new narrow two story building, with faded paint stairs leading up to a set of double Cherry wood doors, with shingled siding with a few short broken windows. The roof is shingled.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall lean build, with green eyes and streaked red hair. Their face has eyebrow pierced 
>
> ***Characteristics*** :  Hates animals
>
> ***Personality*** :  Rebellious
>
> ***Trait*** : I like to squeeze into small places where no one else can get to me.
>
> ***Ideal*** : People. I'm committed to my crewmates, not to ideals. (Neutral)
{ .ownerDescription }



