---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tracker 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Cottage 
services: services
owner: Hio (Half-Elf)
---
> [!oRPG-Layout] 
> #  Cottage  (Tracker/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hio (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Above Average |

##  Cottage  owned by [[Hio]] (Half-Elf)
*Tracker / *


**Building Description:**  An tall building, with faded paint with shingled siding with a front tall window that has a painted sign hanging above with the merchants name. The roof is thatching made of grass. A Cherry shed structure is to the side. A Red Oak crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short weak build, with blue eyes and thinning brown hair. Their face has lip pierced 
>
> ***Characteristics*** :  Answers questions with questions
>
> ***Personality*** :  Honest
>
> ***Trait*** : The leader of my community has something wise to say on every topic, and I am eager to share that wisdom.
>
> ***Ideal*** : Generosity. My talents were given to me so that I could use them to benefit the world. (Good)
{ .ownerDescription }



