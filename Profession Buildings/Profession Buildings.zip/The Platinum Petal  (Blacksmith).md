---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Blacksmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Platinum Petal 
services: services
owner: Linka (Human)
---
> [!oRPG-Layout] 
> #  The Platinum Petal  (Blacksmith/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Linka (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | High |

##  The Platinum Petal  owned by [[Linka]] (Human)
*Blacksmith / *


**Building Description:**  An one story building, stairs leading up to a set of double Bronze doors with a Oak frame, with stoned siding. The roof is planked with Pine planks. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand thin build, with hazel eyes and strange hairstyle auburn hair. Their face has acne 
>
> ***Characteristics*** :  Hook for a hand
>
> ***Personality*** :  Bigoted
>
> ***Trait*** : I am utterly serene, even in the face of disaster.
>
> ***Ideal*** : No Limits. Nothing should fetter the infinite possibility inherent in all existence. (Chaotic)
{ .ownerDescription }



