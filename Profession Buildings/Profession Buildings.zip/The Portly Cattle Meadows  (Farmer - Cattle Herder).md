---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Portly Cattle Meadows 
services: services
owner: Namber (Elven)
---
> [!oRPG-Layout] 
> #  The Portly Cattle Meadows  (Farmer - Cattle Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Namber (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Low |

##  The Portly Cattle Meadows  owned by [[Namber]] (Elven)
*Farmer - Cattle Herder / Farmer*


**Building Description:**  An long building, with planked siding with a front tall shuttered window that has a sign hanging above with the merchants name. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Grand weak build, with white eyes and straight blond hair. Their face has a broken nose 
>
> ***Characteristics*** :  Narcoleptic
>
> ***Personality*** :  Defensive
>
> ***Trait*** : I take great pains to always look my best and follow the latest fashions.
>
> ***Ideal*** : Nature. The natural world is more important than all the constructs of civilization. (Neutral)
{ .ownerDescription }



