---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armor Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Blue Steal Scalemail Hawker 
services: services
owner: Cainen (Elven)
---
> [!oRPG-Layout] 
> #  The Blue Steal Scalemail Hawker  (Armor Dealer/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Cainen (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Below Average |

##  The Blue Steal Scalemail Hawker  owned by [[Cainen]] (Elven)
*Armor Dealer / *


**Building Description:**  An building with faded paint. An polished anvil sits in outside smithy with various Spear lying about.  



> ### Owner Description/Background
> ***Appearance*** : Average average build, with green eyes and streaked auburn hair. Their face has small scar 
>
> ***Characteristics*** :  Drools
>
> ***Personality*** :  Thrifty
>
> ***Trait*** : I'm a born gambler who can't resist taking a risk for a potential payoff.
>
> ***Ideal*** : Freedom. Everyone should be free to pursue his or her livelihood. (Chaotic)
{ .ownerDescription }



