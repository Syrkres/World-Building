---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armor Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Gold Ringmail Trader 
services: services
owner: Jardyn (Human)
---
> [!oRPG-Layout] 
> #  The Gold Ringmail Trader  (Armor Dealer/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Jardyn (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  The Gold Ringmail Trader  owned by [[Jardyn]] (Human)
*Armor Dealer / *


**Building Description:**  A old long two story building with a smithy attached to the side. An rusted anvil sits in the corner of the yard a large smith hammer lying across the top with various Flail lying about. A warn Oak barrel filled with Iron bars, with a Saw leaning against the base. A saw horse with hay strewn about, a sledge hammer leaning on the edge.  



> ### Owner Description/Background
> ***Appearance*** : Extra short fat build, with red eyes and short red hair. Their face is pock-marked 
>
> ***Characteristics*** :  Stands very close
>
> ***Personality*** :  Secretive
>
> ***Trait*** : I like to squeeze into small places where no one else can get to me.
>
> ***Ideal*** : Respect. All people, rich or poor, deserve respect. (Good)
{ .ownerDescription }



