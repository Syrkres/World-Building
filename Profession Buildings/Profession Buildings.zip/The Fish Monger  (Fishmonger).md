---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Fishmonger Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Fish Monger 
services: services
owner: Cadger (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Fish Monger  (Fishmonger/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Cadger (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  The Fish Monger  owned by [[Cadger]] (Half-Orc)
*Fishmonger / Cooks*


**Building Description:**  An old narrow tall building, stairs leading up to a set of double Bronze doors with a Red Oak frame, with planked siding. The roof is timber made of Beech. A Yellow Birch shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal fat build, with hazel eyes and messy blond hair. Their face has a beard 
>
> ***Characteristics*** :  Pathological liar
>
> ***Personality*** :  Playful
>
> ***Trait*** : I place no stock in wealthy or well-mannered folk. Money and manners won't save you from a hungry owlbear.
>
> ***Ideal*** : Responsibility. It is my duty to respect the authority of those above me, just as those below me must respect mine. (Lawful)
{ .ownerDescription }



