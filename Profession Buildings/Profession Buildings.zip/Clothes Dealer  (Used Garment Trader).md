---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Used Garment Trader Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Clothes Dealer 
services: services
owner: Keplynger (Gnome)
---
> [!oRPG-Layout] 
> #  Clothes Dealer  (Used Garment Trader/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Keplynger (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Above Average |

##  Clothes Dealer  owned by [[Keplynger]] (Gnome)
*Used Garment Trader / Tailor*


**Building Description:**  An two story building, with faded paint a Cherry wood door with a Beech frame with stoned siding with a front window that has a sign hanging above with the merchants name. The roof is thatching made of grass. A Beech pergola is attached to the side. A Red Oak barrel sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Squat anorexic build, with brown eyes and streaked black hair. Their face has a missing right eye 
>
> ***Characteristics*** :  Limps
>
> ***Personality*** :  Blustering
>
> ***Trait*** : Whenever I come to a new place, I collect local rumors and spread gossip.
>
> ***Ideal*** : Friendship. Material goods come and go. Bonds of friendship last forever. (Good)
{ .ownerDescription }



