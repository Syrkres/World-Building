---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Sheep Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Farm 
services: services
owner: Lucken (Halfling)
---
> [!oRPG-Layout] 
> #  The Farm  (Farmer - Sheep Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Lucken (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Farm  owned by [[Lucken]] (Halfling)
*Farmer - Sheep Herder / Farmer*


**Building Description:**  An two story building, with brick siding. The roof is thatching made of straw. A Beech shed structure is to the side. A few new Pine crates sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Tall frail build, with red eyes and short auburn hair. Their face has a missing left eye 
>
> ***Characteristics*** :  Altophobic (afraid of heights)
>
> ***Personality*** :  Foolhardy
>
> ***Trait*** : There's nothing I like more than a good mystery.
>
> ***Ideal*** : Greed. I will do whatever it takes to become wealthy. (Evil)
{ .ownerDescription }



