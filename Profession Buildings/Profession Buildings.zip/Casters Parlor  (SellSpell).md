---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sellspell Holyman
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Casters Parlor 
services: services
owner: Kupher (Half-Orc)
---
> [!oRPG-Layout] 
> #  Casters Parlor  (Sellspell/Holyman)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kupher (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  Casters Parlor  owned by [[Kupher]] (Half-Orc)
*Sellspell / Holyman*


**Building Description:**  An old narrow building, a set of double Red Oak wood doors, with stoned siding. The roof is timber. A Pine shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Average fat build, with green eyes and braided black hair. Their face has a goatee 
>
> ***Characteristics*** :  Gesticulates wildly
>
> ***Personality*** :  Graceful
>
> ***Trait*** : I would rather make a new friend than a new enemy.
>
> ***Ideal*** : Creativity. I never run the same con twice. (Chaotic)
{ .ownerDescription }



