---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Oil Trader Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Grease Hawker 
services: services
owner: Labell (Halfling)
---
> [!oRPG-Layout] 
> #  The Grease Hawker  (Oil Trader/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Labell (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | High |

##  The Grease Hawker  owned by [[Labell]] (Halfling)
*Oil Trader / Offical*


**Building Description:**  An new narrow building, with stoned siding. The roof is timber made of Oak. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Normal frail build, with green eyes and curly red hair. Their face has a missing left eye 
>
> ***Characteristics*** :  Drones on and on while talking
>
> ***Personality*** :  Bitter
>
> ***Trait*** : I know a story relevant to almost every situation.
>
> ***Ideal*** : Freedom. Tyrants must not be allowed to oppress the people. (Chaotic)
{ .ownerDescription }



