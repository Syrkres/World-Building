---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Fishmonger Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Pike Peddler 
services: services
owner: Estabrook (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Pike Peddler  (Fishmonger/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Estabrook (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  The Pike Peddler  owned by [[Estabrook]] (Half-Orc)
*Fishmonger / Cooks*


**Building Description:**  An new building, with stoned siding with a front tall shuttered window that has stairs leading up to a Iron door with a Maple frame with the merchants name. The roof is thatched. A Hickory crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Short athletic build, with blue eyes and well groomed auburn hair. Their face is missing teeth 
>
> ***Characteristics*** :  Picks fights
>
> ***Personality*** :  Frustrated
>
> ***Trait*** : I keep multiple holy symbols on me and invoke whatever deity might come in useful at any given moment.
>
> ***Ideal*** : Responsibility. I do what I must and obey just authority. (Lawful)
{ .ownerDescription }



