---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Mercer Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Cloth Emporium 
services: services
owner: DeGarmo (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Cloth Emporium  (Mercer/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** DeGarmo (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Low |

##  The Cloth Emporium  owned by [[DeGarmo]] (Half-Elf)
*Mercer / Tailor*


**Building Description:**  An new long tall building, with new paint stairs leading up to a Elm wood door with brick siding with a few windows. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall average build, with blue eyes and messy brown hair. Their face has a patch over eye 
>
> ***Characteristics*** :  Plays practical jokes
>
> ***Personality*** :  Altruistic
>
> ***Trait*** : I lie about almost everything, even when there's no good reason to.
>
> ***Ideal*** : Change. We must help bring about the changes the gods are constantly working in the world. (Chaotic)
{ .ownerDescription }



