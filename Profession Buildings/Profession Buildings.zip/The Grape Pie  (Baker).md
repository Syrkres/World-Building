---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Grape Pie 
services: services
owner: Tufo (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Grape Pie  (Baker/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Tufo (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Low |

##  The Grape Pie  owned by [[Tufo]] (Half-Elf)
*Baker / Cooks*


**Building Description:**  An old narrow building, with new paint with planked siding with a front window that has a sign hanging above with the merchants name. The roof is thatched. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Squat anorexic build, with hazel eyes and short auburn hair. Their face has a goatee 
>
> ***Characteristics*** :  Easily confused
>
> ***Personality*** :  Generous
>
> ***Trait*** : The common folk love me for my kindness and generosity.
>
> ***Ideal*** : Respect. All people, rich or poor, deserve respect. (Good)
{ .ownerDescription }



