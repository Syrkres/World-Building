---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Goat Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Old Stone Fields 
services: services
owner: Clinton (Half-Orc)
---
> [!oRPG-Layout] 
> #  Old Stone Fields  (Farmer - Goat Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Clinton (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  Old Stone Fields  owned by [[Clinton]] (Half-Orc)
*Farmer - Goat Herder / Farmer*


**Building Description:**  An new narrow two story building, stairs leading up to a set of double Beech wood doors, with shingled siding. The roof is planked. A Ceder shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall athletic build, with hazel eyes and frazzled red hair. Their face has large ears 
>
> ***Characteristics*** :  Perfumed
>
> ***Personality*** :  Imaginative
>
> ***Trait*** : I watch over my friends as if they were a litter of newborn pups.
>
> ***Ideal*** : Tradition. The ancient traditions of worship and sacrifice must be preserved and upheld. (Lawful)
{ .ownerDescription }



