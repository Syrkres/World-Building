---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Fine new Glass 
services: services
owner: Hansaard (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Fine new Glass  (Antiquities/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hansaard (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  The Fine new Glass  owned by [[Hansaard]] (Half-Elf)
*Antiquities / Offical*


**Building Description:**  An building, with new paint stairs leading up to a Yellow Birch wood with Steal bands door with planked siding. The roof is timber made of Ceder. A Oak chest sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Short fat build, with hazel eyes and long black hair. Their face is grizzled 
>
> ***Characteristics*** :  Spits
>
> ***Personality*** :  Grouchy
>
> ***Trait*** : I think anyone who's nice to me is hiding evil intent.
>
> ***Ideal*** : Change. Life is like the seasons, in constant change, and we must change with it. (Chaotic)
{ .ownerDescription }



