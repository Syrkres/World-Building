---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Book Binder Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Open Manual 
services: services
owner: Scaveleur (Halfling)
---
> [!oRPG-Layout] 
> #  The Open Manual  (Book Binder/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Scaveleur (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Open Manual  owned by [[Scaveleur]] (Halfling)
*Book Binder / Professional*


**Building Description:**  An narrow building, with planked siding with a missing window. The roof is timber. A Ceder shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short weak build, with hazel eyes and long white hair. Their face is missing teeth 
>
> ***Characteristics*** :  Hydrophobic (afraid of water)
>
> ***Personality*** :  Wisecracking
>
> ***Trait*** : I always have plan for what to do when things go wrong.
>
> ***Ideal*** : Community. It is the duty of all civilized people to strengthen the bonds of community and the security of civilization. (Lawful)
{ .ownerDescription }



