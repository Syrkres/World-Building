---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Scribe 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Scribes Market Stall 
services: services
owner: Bodger (Half-Elf)
---
> [!oRPG-Layout] 
> #  Scribes Market Stall  (Scribe/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bodger (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Low |

##  Scribes Market Stall  owned by [[Bodger]] (Half-Elf)
*Scribe / *


**Building Description:**  An old narrow building, with faded paint with shingled siding. The roof is shingled. A Ceder shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short weak build, with green eyes and bald white hair. Their face has large scar 
>
> ***Characteristics*** :  Taps feet
>
> ***Personality*** :  Joking
>
> ***Trait*** : I never pass up a friendly wager.
>
> ***Ideal*** : Charity. I distribute money I acquire to the people who really need it. (Good)
{ .ownerDescription }



