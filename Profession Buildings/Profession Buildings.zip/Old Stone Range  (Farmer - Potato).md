---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Potato Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Old Stone Range 
services: services
owner: Clave (Human)
---
> [!oRPG-Layout] 
> #  Old Stone Range  (Farmer - Potato/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Clave (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Low |

##  Old Stone Range  owned by [[Clave]] (Human)
*Farmer - Potato / Farmer*


**Building Description:**  An new long building, with faded paint stairs leading up to a Beech wood door with a Pine frame with stoned siding. The roof is thatched. A shed is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra short strong build, with hazel eyes and streaked white hair. Their face is an missing ear 
>
> ***Characteristics*** :  Wears flamboyant or outlandish clothes
>
> ***Personality*** :  Snobbish
>
> ***Trait*** : I'm convinced that people are always trying to steal my secrets.
>
> ***Ideal*** : Community. It is the duty of all civilized people to strengthen the bonds of community and the security of civilization. (Lawful)
{ .ownerDescription }



