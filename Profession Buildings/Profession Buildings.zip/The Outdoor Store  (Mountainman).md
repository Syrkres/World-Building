---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Mountainman Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Outdoor Store 
services: services
owner: Betancore (Halfling)
---
> [!oRPG-Layout] 
> #  The Outdoor Store  (Mountainman/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Betancore (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Average |

##  The Outdoor Store  owned by [[Betancore]] (Halfling)
*Mountainman / Guard*


**Building Description:**  An new building, stairs leading up to a set of double Red Oak wood doors, with shingled siding with a front tall window that has stairs leading up to a Pine wood with Iron bands door with the merchants name. The roof is shingled with Yellow Birch shingles. A shed is attached to the side. A few Elm crates sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Squat average build, with green eyes and pony-tail red hair. Their face is toothless 
>
> ***Characteristics*** :  Refuses to let anyone walk behind them
>
> ***Personality*** :  Truthful
>
> ***Trait*** : I feel tremendous empathy for all who suffer.
>
> ***Ideal*** : Aspiration. I work hard to be the best there is at my craft. (Any)
{ .ownerDescription }



