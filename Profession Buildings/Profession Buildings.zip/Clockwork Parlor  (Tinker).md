---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tinker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Clockwork Parlor 
services: services
owner: Kaney (Human)
---
> [!oRPG-Layout] 
> #  Clockwork Parlor  (Tinker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kaney (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  Clockwork Parlor  owned by [[Kaney]] (Human)
*Tinker / Crafter*


**Building Description:**  An building, with faded paint with planked siding. The roof is thatching made of grass. A Yellow Birch shed is attached to the side. A few Pine chests sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Normal frail build, with hazel eyes and well groomed grey hair. Their face has a broken nose 
>
> ***Characteristics*** :  Nervous muscle twitch
>
> ***Personality*** :  Gregarious
>
> ***Trait*** : I'm well known for my work, and I want to make sure everyone appreciates it. I'm always taken aback when people haven't heard of me.
>
> ***Ideal*** : Independence. When people follow orders blindly they embrace a kind of tyranny. (Chaotic)
{ .ownerDescription }



