---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Used Garment Trader Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Clothes Maker 
services: services
owner: Siglin (Human)
---
> [!oRPG-Layout] 
> #  Clothes Maker  (Used Garment Trader/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Siglin (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Low |

##  Clothes Maker  owned by [[Siglin]] (Human)
*Used Garment Trader / Tailor*


**Building Description:**  An old long building, with stoned siding with a missing short window. The roof is planked. A warn Red Oak chest sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Short athletic build, with green eyes and frazzled grey hair. Their face has large scar across full face 
>
> ***Characteristics*** :  Hemaphobic (afraid of blood)
>
> ***Personality*** :  Cheerful
>
> ***Trait*** : I miss-quote the sacred texts and proverbs in almost every situation.
>
> ***Ideal*** : Beauty. When I perform, I make the world better than it was. (Good)
{ .ownerDescription }



