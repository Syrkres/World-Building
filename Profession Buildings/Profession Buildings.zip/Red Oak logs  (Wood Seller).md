---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wood Seller 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Red Oak logs 
services: services
owner: Lederman (Half-Orc)
---
> [!oRPG-Layout] 
> #  Red Oak logs  (Wood Seller/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Lederman (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Below Average |

##  Red Oak logs  owned by [[Lederman]] (Half-Orc)
*Wood Seller / *


**Building Description:**  An new building, with shingled siding. The roof is thatching made of grass. A few Ceder crates sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall anorexic build, with brown eyes and braided grey hair. Their face has lip pierced 
>
> ***Characteristics*** :  Picks nose
>
> ***Personality*** :  Spendthrift
>
> ***Trait*** : I think anyone who's nice to me is hiding evil intent.
>
> ***Ideal*** : Freedom. Chains are meant to be broken, as are those who would forge them. (Chaotic)
{ .ownerDescription }



