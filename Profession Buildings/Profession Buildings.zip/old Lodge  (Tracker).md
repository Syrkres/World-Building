---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tracker 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  old Lodge 
services: services
owner: Diza (Dwarf)
---
> [!oRPG-Layout] 
> #  old Lodge  (Tracker/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Diza (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Below Average |

##  old Lodge  owned by [[Diza]] (Dwarf)
*Tracker / *


**Building Description:**  An building, stairs leading up to a set of double Maple wood doors with a Oak frame, with stoned siding. The roof is thatching made of straw. A pergola is attached to the side. A few Elm barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Short fat build, with white eyes and bald brown hair. Their face is toothless 
>
> ***Characteristics*** :  Stands very close
>
> ***Personality*** :  Passionate
>
> ***Trait*** : I would rather make a new friend than a new enemy.
>
> ***Ideal*** : People. I'm committed to the people I care about, not to ideals. (Neutral)
{ .ownerDescription }



