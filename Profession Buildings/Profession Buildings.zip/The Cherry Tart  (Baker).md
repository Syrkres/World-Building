---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Cherry Tart 
services: services
owner: Obin (Elven)
---
> [!oRPG-Layout] 
> #  The Cherry Tart  (Baker/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Obin (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  The Cherry Tart  owned by [[Obin]] (Elven)
*Baker / Cooks*


**Building Description:**  An old two story building, with faded paint stairs leading up to a set of double Elm wood doors with a Maple frame, with stoned siding. The roof is timber made of Elm.  



> ### Owner Description/Background
> ***Appearance*** : Grand average build, with brown eyes and braided white hair. Their face has large ears 
>
> ***Characteristics*** :  Entomophobic (afraid of insects)
>
> ***Personality*** :  Lewd
>
> ***Trait*** : I'm rude to people who lack my commitment to hard work and fair play.
>
> ***Ideal*** : Creativity. I never run the same con twice. (Chaotic)
{ .ownerDescription }



