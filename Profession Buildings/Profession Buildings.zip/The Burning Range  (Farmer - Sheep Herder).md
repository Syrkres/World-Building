---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Sheep Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Burning Range 
services: services
owner: Roca (Gnome)
---
> [!oRPG-Layout] 
> #  The Burning Range  (Farmer - Sheep Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Roca (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | High |

##  The Burning Range  owned by [[Roca]] (Gnome)
*Farmer - Sheep Herder / Farmer*


**Building Description:**  An narrow two story building, with new paint with brick siding with a front round window that has a Copper door with the merchants name. The roof is thatching made of straw. A Hickory barrel sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Normal fat build, with red eyes and thick black hair. Their face has a moustache 
>
> ***Characteristics*** :  Jumps conversation topics
>
> ***Personality*** :  Stubborn
>
> ***Trait*** : My friends know they can rely on me, no matter what.
>
> ***Ideal*** : Aspiration. I'm determined to make something of myself. (Any)
{ .ownerDescription }



