---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wood Carver 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Oak Furniture 
services: services
owner: Jaspers (Gnome)
---
> [!oRPG-Layout] 
> #  Oak Furniture  (Wood Carver/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Jaspers (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Low |

##  Oak Furniture  owned by [[Jaspers]] (Gnome)
*Wood Carver / *


**Building Description:**  An new narrow tall building, with new paint with planked siding with a few short shuttered windows. The roof is thatching made of grass. A Elm shed structure is to the side. A Beech barrel sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Squat lean build, with green eyes and well groomed white hair. Their face is squinty 
>
> ***Characteristics*** :  Claustrophobic (afraid of small spaces)
>
> ***Personality*** :  Unpredictable
>
> ***Trait*** : I think anyone who's nice to me is hiding evil intent.
>
> ***Ideal*** : Free Thinking. Inquiry and curiosity are the pillars of progress. (Chaotic)
{ .ownerDescription }



