---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Headgear Peddler 
services: services
owner: Pohl (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Headgear Peddler  (Hat Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Pohl (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  The Headgear Peddler  owned by [[Pohl]] (Half-Orc)
*Hat Maker / Tailor*


**Building Description:**  An old building, with faded paint with shingled siding with a front window that has a Steal door with the merchants name. The roof is thatching made of grass. A warn Hickory crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short weak build, with red eyes and very long red hair. Their face has nose pierced 
>
> ***Characteristics*** :  Sleeps late
>
> ***Personality*** :  Contentious
>
> ***Trait*** : I've spent so long in the temple that I have little practical experience dealing with people in the outside world.
>
> ***Ideal*** : Community. It is the duty of all civilized people to strengthen the bonds of community and the security of civilization. (Lawful)
{ .ownerDescription }



