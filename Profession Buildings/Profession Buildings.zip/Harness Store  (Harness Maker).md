---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Harness Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Harness Store 
services: services
owner: Esto (Elven)
---
> [!oRPG-Layout] 
> #  Harness Store  (Harness Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Esto (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Average |

##  Harness Store  owned by [[Esto]] (Elven)
*Harness Maker / Crafter*


**Building Description:**  An new building, with faded paint with planked siding. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Squat thin build, with hazel eyes and short blond hair. Their face is pock-marked 
>
> ***Characteristics*** :  Blinks constantly
>
> ***Personality*** :  Whiny
>
> ***Trait*** : I get bored easily. When am I going to get on with my destiny.
>
> ***Ideal*** : Power. I hope to one day rise to the top of my faith's religious hierarchy. (Lawful)
{ .ownerDescription }



