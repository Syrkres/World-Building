---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Miller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Mill 
services: services
owner: Irlam (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Mill  (Miller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Irlam (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Mill  owned by [[Irlam]] (Half-Orc)
*Miller / Cooks*


**Building Description:**  An long building, with new paint a Copper door with a Elm frame with shingled siding. The roof is thatched. A Hickory shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Squat average build, with blue eyes and limp grey hair. Their face has large scar 
>
> ***Characteristics*** :  Likes to arm wrestle
>
> ***Personality*** :  Childish
>
> ***Trait*** : I always want to know how things work and what makes people tick.
>
> ***Ideal*** : Greater Good. It is each person's responsibility to make the most happiness for the whole tribe. (Good)
{ .ownerDescription }



