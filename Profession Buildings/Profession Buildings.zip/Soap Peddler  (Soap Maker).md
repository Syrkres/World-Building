---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Soap Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Soap Peddler 
services: services
owner: Manhard (Halfling)
---
> [!oRPG-Layout] 
> #  Soap Peddler  (Soap Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Manhard (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Above Average |

##  Soap Peddler  owned by [[Manhard]] (Halfling)
*Soap Maker / Crafter*


**Building Description:**  An new long building, with faded paint a set of double Beech wood doors, with brick siding. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Average strong build, with green eyes and strange hairstyle white hair. Their face has nose pierced 
>
> ***Characteristics*** :  Always wears tattered clothes
>
> ***Personality*** :  Irresponsible
>
> ***Trait*** : I like a job well done, especially if I can convince someone else to do it.
>
> ***Ideal*** : Beauty. When I perform, I make the world better than it was. (Good)
{ .ownerDescription }



