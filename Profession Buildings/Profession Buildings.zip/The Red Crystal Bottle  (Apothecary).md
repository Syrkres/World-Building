---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Apothecary 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Red Crystal Bottle 
services: services
owner: Altos (Human)
---
> [!oRPG-Layout] 
> #  The Red Crystal Bottle  (Apothecary/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Altos (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | High |

##  The Red Crystal Bottle  owned by [[Altos]] (Human)
*Apothecary / *


**Building Description:**  An tall building, a set of double Maple wood doors with a Yellow Birch frame, with stoned siding with a missing round window. The roof is timber.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall strong build, with brown eyes and bald black hair. Their face has small scar on left cheek 
>
> ***Characteristics*** :  Achluophobic (afraid of darkness)
>
> ***Personality*** :  Morbid
>
> ***Trait*** : I connect everything that happens to me to a grand cosmic plan.
>
> ***Ideal*** : Responsibility. I do what I must and obey just authority. (Lawful)
{ .ownerDescription }



