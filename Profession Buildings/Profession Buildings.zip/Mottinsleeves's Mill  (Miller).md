---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Miller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Mottinsleeves's Mill 
services: services
owner: Mottinsleeves (Halfling)
---
> [!oRPG-Layout] 
> #  Mottinsleeves's Mill  (Miller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Mottinsleeves (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  Mottinsleeves's Mill  owned by [[Mottinsleeves]] (Halfling)
*Miller / Cooks*


**Building Description:**  An long building, with faded paint a Cherry wood door with a Oak frame with brick siding with a front shuttered window that has a Iron door with a Hickory frame with the merchants name. The roof is thatched. A shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Squat thin build, with green eyes and wavy black hair. Their face has large scar 
>
> ***Characteristics*** :  Smiles when angry/annoyed
>
> ***Personality*** :  Lust
>
> ***Trait*** : I'm driven by a wanderlust that led me away from home.
>
> ***Ideal*** : Responsibility. It is my duty to respect the authority of those above me, just as those below me must respect mine. (Lawful)
{ .ownerDescription }



