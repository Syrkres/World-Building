---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: ArmorSmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Blue Steal Platemail Smith 
services: services
owner: Taverrrite (Dwarf)
---
> [!oRPG-Layout] 
> #  The Blue Steal Platemail Smith  (ArmorSmith/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Taverrrite (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Average |

##  The Blue Steal Platemail Smith  owned by [[Taverrrite]] (Dwarf)
*ArmorSmith / *


**Building Description:**  A long one story building with a smithy attached to the side. An rusted anvil sits in the corner of the smithy. A Beech barrel filled with Steal bars. A Elm chest filled with Steal bars.  



> ### Owner Description/Background
> ***Appearance*** : Average frail build, with hazel eyes and pony-tail black hair. Their face has a goatee 
>
> ***Characteristics*** :  Bites fingernails
>
> ***Personality*** :  Fastidious
>
> ***Trait*** : I'm always picking things up, absently fiddling with them, and sometimes accidentally breaking them.
>
> ***Ideal*** : Community. It is the duty of all civilized people to strengthen the bonds of community and the security of civilization. (Lawful)
{ .ownerDescription }



