---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barber Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Barbershop 
services: services
owner: Sitarz (Gnome)
---
> [!oRPG-Layout] 
> #  The Barbershop  (Barber/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Sitarz (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  The Barbershop  owned by [[Sitarz]] (Gnome)
*Barber / Professional*


**Building Description:**  An tall building, with faded paint with stoned siding. The roof is thatching made of straw. A pile of Red Oak wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal anorexic build, with red eyes and pony-tail brown hair. Their face has large scar across full face 
>
> ***Characteristics*** :  Swears profusely
>
> ***Personality*** :  Forgiving
>
> ***Trait*** : No one could doubt by looking at my regal bearing that I am a cut above the unwashed masses.
>
> ***Ideal*** : Respect. Respect is due to me because of my position, but all people regardless of station deserve to be treated with dignity. (Good)
{ .ownerDescription }



