---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Shoe Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Shoe Hawker 
services: services
owner: Bucaro (Human)
---
> [!oRPG-Layout] 
> #  Shoe Hawker  (Shoe Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bucaro (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | High |

##  Shoe Hawker  owned by [[Bucaro]] (Human)
*Shoe Maker / Tailor*


**Building Description:**  An new two story building, a set of double Steal doors with a Maple frame, with planked siding with a front broken window that has a Beech wood door with a Ceder frame with the merchants name. The roof is thatching made of grass. A Hickory shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand fat build, with white eyes and greasy red hair. Their face has a missing eye 
>
> ***Characteristics*** :  Sucks teeth
>
> ***Personality*** :  Loving
>
> ***Trait*** : My favor, once lost, is lost forever.
>
> ***Ideal*** : Greater Good. It is each person's responsibility to make the most happiness for the whole tribe. (Good)
{ .ownerDescription }



