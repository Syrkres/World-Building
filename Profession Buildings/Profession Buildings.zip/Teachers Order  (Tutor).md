---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tutor Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Teachers Order 
services: services
owner: Kaiden (Half-Elf)
---
> [!oRPG-Layout] 
> #  Teachers Order  (Tutor/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kaiden (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  Teachers Order  owned by [[Kaiden]] (Half-Elf)
*Tutor / Librarian*


**Building Description:**  An new two story building, with planked siding with a front round shuttered window that has a Oak wood with Steal bands door with a Ceder frame with the merchants name. The roof is thatched. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Grand athletic build, with white eyes and well groomed blond hair. Their face has a missing left eye 
>
> ***Characteristics*** :  Predilection for certain kind of food
>
> ***Personality*** :  Repellent
>
> ***Trait*** : I judge people by their actions, not their words.
>
> ***Ideal*** : Self-improvement. The goal of a life of study is the betterment of oneself.
{ .ownerDescription }



