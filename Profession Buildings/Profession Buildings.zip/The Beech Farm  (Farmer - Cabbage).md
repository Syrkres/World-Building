---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cabbage Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Beech Farm 
services: services
owner: Hice (Elven)
---
> [!oRPG-Layout] 
> #  The Beech Farm  (Farmer - Cabbage/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hice (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  The Beech Farm  owned by [[Hice]] (Elven)
*Farmer - Cabbage / Farmer*


**Building Description:**  An old building, with faded paint a Beech wood door with a Ceder frame with planked siding with a missing window. The roof is planked with Elm planks.  



> ### Owner Description/Background
> ***Appearance*** : Normal athletic build, with green eyes and streaked red hair. Their face is doe-eyed 
>
> ***Characteristics*** :  Narcoleptic
>
> ***Personality*** :  Extroverted
>
> ***Trait*** : I believe that everything worth doing is worth doing right. I can't help it--I'm a perfectionist.
>
> ***Ideal*** : Respect. All people, rich or poor, deserve respect. (Good)
{ .ownerDescription }



