---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Jeweler Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Adamentite Ring 
services: services
owner: Grogan (Dwarf)
---
> [!oRPG-Layout] 
> #  The Adamentite Ring  (Jeweler/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Grogan (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  The Adamentite Ring  owned by [[Grogan]] (Dwarf)
*Jeweler / Crafter*


**Building Description:**  An one story building, with brick siding. The roof is timber made of Maple. A pile of Beech wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Squat average build, with blue eyes and well groomed blond hair. Their face has a bushy eyebrows 
>
> ***Characteristics*** :  Sings
>
> ***Personality*** :  Mousy
>
> ***Trait*** : I've lost too many friends, and I'm slow to make new ones.
>
> ***Ideal*** : Greater Good. It is each person's responsibility to make the most happiness for the whole tribe. (Good)
{ .ownerDescription }



