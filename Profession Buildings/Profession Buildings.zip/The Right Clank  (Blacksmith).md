---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Blacksmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Right Clank 
services: services
owner: Uriel (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Right Clank  (Blacksmith/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Uriel (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  The Right Clank  owned by [[Uriel]] (Half-Orc)
*Blacksmith / *


**Building Description:**  An old long two story building, with new paint stairs leading up to a Bronze door with stoned siding with a few broken windows. The roof is thatching made of straw. A shed structure is to the side. A Beech barrel sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Grand lean build, with red eyes and streaked black hair. Their face has a bushy eyebrows 
>
> ***Characteristics*** :  Loves children
>
> ***Personality*** :  Restless
>
> ***Trait*** : I'm a born gambler who can't resist taking a risk for a potential payoff.
>
> ***Ideal*** : Redemption. There's a spark of good in everyone. (Good)
{ .ownerDescription }



