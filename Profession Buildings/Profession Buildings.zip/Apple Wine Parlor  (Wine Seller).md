---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wine Seller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Apple Wine Parlor 
services: services
owner: Roark (Elven)
---
> [!oRPG-Layout] 
> #  Apple Wine Parlor  (Wine Seller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Roark (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  Apple Wine Parlor  owned by [[Roark]] (Elven)
*Wine Seller / Cooks*


**Building Description:**  An building, with faded paint with brick siding. The roof is timber. A Ceder shed structure is to the side. A few new Ceder barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Average fat build, with green eyes and pony-tail black hair. Their face has no eyebrows 
>
> ***Characteristics*** :  Drools
>
> ***Personality*** :  Disingenuous
>
> ***Trait*** : I lie about almost everything, even when there's no good reason to.
>
> ***Ideal*** : Charity. I always try to help those in need, no matter what the personal cost. (Good)
{ .ownerDescription }



