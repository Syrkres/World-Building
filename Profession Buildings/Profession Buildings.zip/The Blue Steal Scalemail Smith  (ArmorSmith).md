---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: ArmorSmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Blue Steal Scalemail Smith 
services: services
owner: Washtub (Elven)
---
> [!oRPG-Layout] 
> #  The Blue Steal Scalemail Smith  (ArmorSmith/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Washtub (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  The Blue Steal Scalemail Smith  owned by [[Washtub]] (Elven)
*ArmorSmith / *


**Building Description:**  A long one story building with a smithy attached to the side. An polished anvil sits in outside smithy a large smith hammer lying across the top with various Mace lying about. A Maple barrel filled with water, with a Grappling Hook leaning against the base.  



> ### Owner Description/Background
> ***Appearance*** : Tall athletic build, with brown eyes and wiry black hair. Their face has eyebrow pierced 
>
> ***Characteristics*** :  Insomniac
>
> ***Personality*** :  Sardonic
>
> ***Trait*** : I like a job well done, especially if I can convince someone else to do it.
>
> ***Ideal*** : Noble Obligation. It is my duty to protect and care for the people beneath me. (Good)
{ .ownerDescription }



