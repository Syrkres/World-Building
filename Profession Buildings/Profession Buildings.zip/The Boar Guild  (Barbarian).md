---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Tavern
title:  The Boar Guild 
services: services
owner: Lazlo (Human)
---
> [!oRPG-Layout] 
> #  The Boar Guild  (Barbarian/Guard)
> **Structure:** Tavern
> **Resides In:** 
>  **Owner:** Lazlo (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  The Boar Guild  owned by [[Lazlo]] (Human)
*Barbarian / Guard*


**Building Description:**  An narrow building with brick siding with a missing short window. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Average wide build, with hazel eyes and wiry blond hair. Their face has small scar on right cheek 
>
> ***Characteristics*** :  Foams at mouth when excited/angry
>
> ***Personality*** :  Frivolous
>
> ***Trait*** : I'm convinced that people are always trying to steal my secrets.
>
> ***Ideal*** : Retribution. The rich need to be shown what life and death are like in the gutters. (Evil)
{ .ownerDescription }



