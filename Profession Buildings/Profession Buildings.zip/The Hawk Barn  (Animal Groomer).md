---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Stables
title:  The Hawk Barn 
services: services
owner: Albaara (Human)
---
> [!oRPG-Layout] 
> #  The Hawk Barn  (Animal Groomer/Entertainer)
> **Structure:** Stables
> **Resides In:** 
>  **Owner:** Albaara (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Low |

##  The Hawk Barn  owned by [[Albaara]] (Human)
*Animal Groomer / Entertainer*


**Building Description:**  An old one story building with new paint and with planked siding. The roof is timber. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand strong build, with blue eyes and pony-tail black hair. Their face has a distinctive nose 
>
> ***Characteristics*** :  Refuses to sit in chairs
>
> ***Personality*** :  Implacable
>
> ***Trait*** : I am utterly serene, even in the face of disaster.
>
> ***Ideal*** : Family. Blood runs thicker than water. (Any)
{ .ownerDescription }



