---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thug Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Dark Green Bracelet 
services: services
owner: Mackin (Halfling)
---
> [!oRPG-Layout] 
> #  The Dark Green Bracelet  (Thug/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Mackin (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  The Dark Green Bracelet  owned by [[Mackin]] (Halfling)
*Thug / Guard*


**Building Description:**  An narrow building, with planked siding. The roof is shingled. A Oak pergola is attached to the side. A few Red Oak barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Squat thin build, with white eyes and dreadlocks red hair. Their face has a missing eye 
>
> ***Characteristics*** :  Agoraphobic (afraid of open spaces)
>
> ***Personality*** :  Gracious
>
> ***Trait*** : When I set my mind to something, I follow through no matter what gets in my way.
>
> ***Ideal*** : People. I'm loyal to my friends, not to any ideals, and everyone else can take a trip down the Styx for all I care. (Neutral)
{ .ownerDescription }



