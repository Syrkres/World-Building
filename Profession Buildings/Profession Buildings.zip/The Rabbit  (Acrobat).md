---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Acrobat Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: House
title:  The Rabbit 
services: services
owner: Altos (Elven)
---
> [!oRPG-Layout] 
> #  The Rabbit  (Acrobat/Entertainer)
> **Structure:** House
> **Resides In:** 
>  **Owner:** Altos (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Rabbit  owned by [[Altos]] (Elven)
*Acrobat / Entertainer*


**Building Description:**  An one story building with new paint and with shingled siding. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Squat fat build, with blue eyes and braided black hair. Their face has a moustache 
>
> ***Characteristics*** :  Burps
>
> ***Personality*** :  Malicious
>
> ***Trait*** : My friends know they can rely on me, no matter what.
>
> ***Ideal*** : Power. Knowledge is the path to power and domination. (Evil)
{ .ownerDescription }



