---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Count Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Cotrell's Court 
services: services
owner: Cotrell (Gnome)
---
> [!oRPG-Layout] 
> #  Cotrell's Court  (Count/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Cotrell (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Average |

##  Cotrell's Court  owned by [[Cotrell]] (Gnome)
*Count / Offical*


**Building Description:**  An old two story building, with faded paint with stoned siding. The roof is thatching made of grass. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Average fat build, with brown eyes and long brown hair. Their face is an missing ear 
>
> ***Characteristics*** :  Has nightmares
>
> ***Personality*** :  Transparent
>
> ***Trait*** : If someone is in trouble, I'm always willing to lend help.
>
> ***Ideal*** : People. I help people who help me--that's what keeps us alive. (Neutral)
{ .ownerDescription }



