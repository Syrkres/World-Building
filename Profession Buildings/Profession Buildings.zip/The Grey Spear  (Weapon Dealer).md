---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weapon Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Grey Spear 
services: services
owner: Albaara (Dwarf)
---
> [!oRPG-Layout] 
> #  The Grey Spear  (Weapon Dealer/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Albaara (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  The Grey Spear  owned by [[Albaara]] (Dwarf)
*Weapon Dealer / *


**Building Description:**  An new building, with new paint with stoned siding. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Squat fat build, with green eyes and frazzled blond hair. Their face has a broken nose 
>
> ***Characteristics*** :  Taps feet
>
> ***Personality*** :  Loquacious
>
> ***Trait*** : I always want to know how things work and what makes people tick.
>
> ***Ideal*** : Power. If I can attain more power, no one will tell me what to do. (Evil)
{ .ownerDescription }



