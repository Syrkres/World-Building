---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Broken new Bracelet 
services: services
owner: Wigner (Elven)
---
> [!oRPG-Layout] 
> #  The Broken new Bracelet  (Antiquities/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Wigner (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Broken new Bracelet  owned by [[Wigner]] (Elven)
*Antiquities / Offical*


**Building Description:**  An old building, a set of double Oak wood with Steal bands doors with a Hickory frame, with brick siding. The roof is thatched. A Hickory pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand strong build, with hazel eyes and well groomed black hair. Their face has large scar on right cheek 
>
> ***Characteristics*** :  Plays practical jokes
>
> ***Personality*** :  Lippy
>
> ***Trait*** : I place no stock in wealthy or well-mannered folk. Money and manners won't save you from a hungry owlbear.
>
> ***Ideal*** : Might. If I become strong, I can take what I want--what I deserve. (Evil)
{ .ownerDescription }



