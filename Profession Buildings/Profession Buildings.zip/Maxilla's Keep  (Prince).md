---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Prince Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Maxilla's Keep 
services: services
owner: Maxilla (Gnome)
---
> [!oRPG-Layout] 
> #  Maxilla's Keep  (Prince/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Maxilla (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  Maxilla's Keep  owned by [[Maxilla]] (Gnome)
*Prince / Offical*


**Building Description:**  An building, with faded paint with shingled siding. The roof is thatching made of grass. A shed is attached to the side. A pile of Ceder wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal frail build, with green eyes and dreadlocks grey hair. Their face has a distinctive nose 
>
> ***Characteristics*** :  Bleeding nose
>
> ***Personality*** :  Irreligious
>
> ***Trait*** : I enjoy sailing into new ports and making new friends over a flagon of ale.
>
> ***Ideal*** : People. I'm committed to my crewmates, not to ideals. (Neutral)
{ .ownerDescription }



