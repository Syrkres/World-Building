---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Count Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Kramme's Court 
services: services
owner: Kramme (Human)
---
> [!oRPG-Layout] 
> #  Kramme's Court  (Count/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kramme (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  Kramme's Court  owned by [[Kramme]] (Human)
*Count / Offical*


**Building Description:**  An old long one story building, with new paint stairs leading up to a set of double Maple wood doors with a Pine frame, with brick siding with a few tall windows. The roof is thatching made of grass. A Red Oak pergola is attached to the side. A few old Beech crates sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Normal average build, with hazel eyes and pony-tail white hair. Their face is toothless 
>
> ***Characteristics*** :  Scratches
>
> ***Personality*** :  Nurturing
>
> ***Trait*** : I take great pains to always look my best and follow the latest fashions.
>
> ***Ideal*** : Power. I hope to one day rise to the top of my faith's religious hierarchy. (Lawful)
{ .ownerDescription }



