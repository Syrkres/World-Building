---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Count Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Guiboar's Court 
services: services
owner: Guiboar (Half-Orc)
---
> [!oRPG-Layout] 
> #  Guiboar's Court  (Count/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Guiboar (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | High |

##  Guiboar's Court  owned by [[Guiboar]] (Half-Orc)
*Count / Offical*


**Building Description:**  An building, stairs leading up to a Cherry wood with Bronze bands door with a Ceder frame with stoned siding with a few windows. The roof is thatched. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Squat lean build, with hazel eyes and long grey hair. Their face has large ears 
>
> ***Characteristics*** :  Entomophobic (afraid of insects)
>
> ***Personality*** :  Angry
>
> ***Trait*** : I don't part with my money easily and will haggle tirelessly to get the best deal possible.
>
> ***Ideal*** : People. I'm loyal to my friends, not to any ideals, and everyone else can take a trip down the Styx for all I care. (Neutral)
{ .ownerDescription }



