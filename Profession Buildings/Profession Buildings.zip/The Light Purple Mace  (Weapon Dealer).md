---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weapon Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Light Purple Mace 
services: services
owner: Heldane (Elven)
---
> [!oRPG-Layout] 
> #  The Light Purple Mace  (Weapon Dealer/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Heldane (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Low |

##  The Light Purple Mace  owned by [[Heldane]] (Elven)
*Weapon Dealer / *


**Building Description:**  An long building, a set of double Maple wood with Steal bands doors with a Yellow Birch frame, with shingled siding. The roof is timber made of Ceder. A pergola is attached to the side. A warn Pine barrel sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Grand frail build, with green eyes and limp grey hair. Their face is gap-toothed 
>
> ***Characteristics*** :  Urinates frequently
>
> ***Personality*** :  Feisty
>
> ***Trait*** : I keep multiple holy symbols on me and invoke whatever deity might come in useful at any given moment.
>
> ***Ideal*** : Community. It is the duty of all civilized people to strengthen the bonds of community and the security of civilization. (Lawful)
{ .ownerDescription }



