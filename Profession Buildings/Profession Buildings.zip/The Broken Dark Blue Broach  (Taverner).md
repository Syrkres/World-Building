---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Taverner Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Broken Dark Blue Broach 
services: services
owner: Trahan (Elven)
---
> [!oRPG-Layout] 
> #  The Broken Dark Blue Broach  (Taverner/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Trahan (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Below Average |

##  The Broken Dark Blue Broach  owned by [[Trahan]] (Elven)
*Taverner / Cooks*


**Building Description:**  An long one story building, with planked siding with a missing window. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Short strong build, with red eyes and very long grey hair. Their face is chiseled 
>
> ***Characteristics*** :  Warts
>
> ***Personality*** :  Melancholy
>
> ***Trait*** : No one could doubt by looking at my regal bearing that I am a cut above the unwashed masses.
>
> ***Ideal*** : Honor. I don't steal from others in the trade. (Lawful)
{ .ownerDescription }



