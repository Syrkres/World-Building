---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Goon Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  TAVERNSHOPNAME 
services: services
owner: Guiboar (Dwarf)
---
> [!oRPG-Layout] 
> #  TAVERNSHOPNAME  (Goon/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Guiboar (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Low |

##  TAVERNSHOPNAME  owned by [[Guiboar]] (Dwarf)
*Goon / Guard*


**Building Description:**  An old building, with new paint stairs leading up to a set of double Elm wood with Bronze bands doors with a Yellow Birch frame, with stoned siding with a missing tall window. The roof is thatched. A Pine shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand weak build, with red eyes and very long white hair. Their face has a bushy eyebrows 
>
> ***Characteristics*** :  Picks at teeth
>
> ***Personality*** :  Mean
>
> ***Trait*** : If someone is in trouble, I'm always willing to lend help.
>
> ***Ideal*** : Might. If I become strong, I can take what I want--what I deserve. (Evil)
{ .ownerDescription }



