---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barron Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Townhall
title:  Bonaventure's Mansion 
services: services
owner: Bonaventure (Human)
---
> [!oRPG-Layout] 
> #  Bonaventure's Mansion  (Barron/Offical)
> **Structure:** Townhall
> **Resides In:** 
>  **Owner:** Bonaventure (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | High |

##  Bonaventure's Mansion  owned by [[Bonaventure]] (Human)
*Barron / Offical*


**Building Description:**  An new long building with brick siding with a missing tall window. The roof is timber made of Pine.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall strong build, with blue eyes and braided auburn hair. Their face has large scar across full face 
>
> ***Characteristics*** :  Limps
>
> ***Personality*** :  Caring
>
> ***Trait*** : The leader of my community has something wise to say on every topic, and I am eager to share that wisdom.
>
> ***Ideal*** : Respect. The thing that keeps a ship together is mutual respect between captain and crew. (Good)
{ .ownerDescription }



