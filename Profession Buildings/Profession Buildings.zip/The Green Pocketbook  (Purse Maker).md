---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Purse Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Green Pocketbook 
services: services
owner: Heartline (Gnome)
---
> [!oRPG-Layout] 
> #  The Green Pocketbook  (Purse Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Heartline (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Average |

##  The Green Pocketbook  owned by [[Heartline]] (Gnome)
*Purse Maker / Tailor*


**Building Description:**  An one story building, stairs leading up to a set of double Bronze doors, with stoned siding. The roof is thatched. A Yellow Birch chest sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short average build, with white eyes and long white hair. Their face has a patch over right eye 
>
> ***Characteristics*** :  Haphephobic (afraid of being touched)
>
> ***Personality*** :  Ornery
>
> ***Trait*** : I once ran twenty-five miles without stopping to warn my clan of an approaching orc horde. I'd do it again if I had to.
>
> ***Ideal*** : Charity. I steal from the wealthy so that I can help people in need. (Good)
{ .ownerDescription }



