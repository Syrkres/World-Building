---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Hat Monger 
services: services
owner: Raboso (Gnome)
---
> [!oRPG-Layout] 
> #  The Hat Monger  (Hat Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Raboso (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Low |

##  The Hat Monger  owned by [[Raboso]] (Gnome)
*Hat Maker / Tailor*


**Building Description:**  An old one story building, with new paint a Bronze door with a Yellow Birch frame with stoned siding with a front tall window that has stairs leading up to a Iron door with a Beech frame with the merchants name. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Short thin build, with hazel eyes and greasy blond hair. Their face has a missing right eye 
>
> ***Characteristics*** :  Bad breath or strong body odor
>
> ***Personality*** :  Foolhardy
>
> ***Trait*** : I am incredibly slow to trust. Those who seem the fairest often have the most to hide.
>
> ***Ideal*** : Aspiration. I seek to prove my self worthy of my god's favor by matching my actions against his or her teachings. (Any)
{ .ownerDescription }



