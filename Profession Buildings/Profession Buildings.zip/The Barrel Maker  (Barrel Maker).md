---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barrel Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Barrel Maker 
services: services
owner: Wrex (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Barrel Maker  (Barrel Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Wrex (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  The Barrel Maker  owned by [[Wrex]] (Half-Elf)
*Barrel Maker / Crafter*


**Building Description:**  An tall building, with shingled siding with a few short shuttered windows. The roof is thatching made of straw. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Grand anorexic build, with brown eyes and braided blond hair. Their face has a moustache 
>
> ***Characteristics*** :  Stands very close
>
> ***Personality*** :  Senile
>
> ***Trait*** : My language is as foul as an otyugh nest.
>
> ***Ideal*** : Destiny. Nothing and no one can steer me away from my higher calling. (Any)
{ .ownerDescription }



