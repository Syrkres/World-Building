---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weapon Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Black Sword 
services: services
owner: Philmore (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Black Sword  (Weapon Dealer/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Philmore (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  The Black Sword  owned by [[Philmore]] (Half-Orc)
*Weapon Dealer / *


**Building Description:**  An narrow tall building, with faded paint a Bronze door with stoned siding. The roof is thatching made of straw. A Red Oak pergola is attached to the side. A pile of Oak wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall wide build, with white eyes and thick black hair. Their face has large ears 
>
> ***Characteristics*** :  Talks with food in mouth
>
> ***Personality*** :  Snobbish
>
> ***Trait*** : I'm confident in my own abilities and do what I can to instill confidence in others.
>
> ***Ideal*** : Might. In life as in war, the stronger force wins. (Evil)
{ .ownerDescription }



