---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The old Stool 
services: services
owner: Dunner (Dwarf)
---
> [!oRPG-Layout] 
> #  The old Stool  (Antiquities/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Dunner (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  The old Stool  owned by [[Dunner]] (Dwarf)
*Antiquities / Offical*


**Building Description:**  An two story building, with stoned siding. The roof is timber made of Hickory. A pile of Elm wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal average build, with white eyes and thinning grey hair. Their face has large ears 
>
> ***Characteristics*** :  Easily confused
>
> ***Personality*** :  Altruistic
>
> ***Trait*** : I'm confident in my own abilities and do what I can to instill confidence in others.
>
> ***Ideal*** : Logic. Emotions must not cloud our logical thinking. (Lawful)
{ .ownerDescription }



