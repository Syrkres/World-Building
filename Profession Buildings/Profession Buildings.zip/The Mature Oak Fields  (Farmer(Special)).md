---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer(Special) Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Mature Oak Fields 
services: services
owner: Bonz (Dwarf)
---
> [!oRPG-Layout] 
> #  The Mature Oak Fields  (Farmer(Special)/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bonz (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Mature Oak Fields  owned by [[Bonz]] (Dwarf)
*Farmer(Special) / Farmer*


**Building Description:**  An building, a Steal door with stoned siding. The roof is thatching made of straw. A pergola is attached to the side. A warn Beech crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Tall lean build, with white eyes and braided white hair. Their face has nose pierced 
>
> ***Characteristics*** :  Missing finger
>
> ***Personality*** :  Lethargic
>
> ***Trait*** : I am tolerant of other faiths and respect (or condemn) the worship of other gods.
>
> ***Ideal*** : Beauty. What is beautiful points us beyond itself toward what is true. (Good)
{ .ownerDescription }



