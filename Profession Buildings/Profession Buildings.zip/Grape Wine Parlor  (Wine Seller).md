---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wine Seller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Grape Wine Parlor 
services: services
owner: Fedevich (Half-Orc)
---
> [!oRPG-Layout] 
> #  Grape Wine Parlor  (Wine Seller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Fedevich (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Low |

##  Grape Wine Parlor  owned by [[Fedevich]] (Half-Orc)
*Wine Seller / Cooks*


**Building Description:**  An building, with new paint stairs leading up to a Red Oak wood door with shingled siding. The roof is timber made of Cherry. A pergola is attached to the side. A few old Ceder chests sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Grand wide build, with brown eyes and bald brown hair. Their face has nose pierced 
>
> ***Characteristics*** :  Aversion to certain kind of food
>
> ***Personality*** :  Lust
>
> ***Trait*** : Flattery is my preferred trick for getting what I want.
>
> ***Ideal*** : Might. If I become strong, I can take what I want--what I deserve. (Evil)
{ .ownerDescription }



