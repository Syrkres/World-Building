---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Alchemist Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Ginger (Fire) Incense 
services: services
owner: Jahn (Gnome)
---
> [!oRPG-Layout] 
> #  The Ginger (Fire) Incense  (Alchemist/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Jahn (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | High |

##  The Ginger (Fire) Incense  owned by [[Jahn]] (Gnome)
*Alchemist / Librarian*


**Building Description:**  An new building, with faded paint with brick siding with a few windows. The roof is timber. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Tall thin build, with red eyes and wavy brown hair. Their face has acne 
>
> ***Characteristics*** :  Likes to arm wrestle
>
> ***Personality*** :  Inattentive
>
> ***Trait*** : Thinking is for other people. I prefer action.
>
> ***Ideal*** : Community. It is the duty of all civilized people to strengthen the bonds of community and the security of civilization. (Lawful)
{ .ownerDescription }



