---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Mage Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Mage Tower 
services: services
owner: Obol (Half-Orc)
---
> [!oRPG-Layout] 
> #  Mage Tower  (High Mage/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Obol (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  Mage Tower  owned by [[Obol]] (Half-Orc)
*High Mage / Librarian*


**Building Description:**  An new tall building, with new paint stairs leading up to a set of double Elm wood with Iron bands doors with a Oak frame, with shingled siding with a front shuttered window that has stairs leading up to a Maple wood with Bronze bands door with the merchants name. The roof is planked with Ceder planks. A shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand wide build, with brown eyes and greasy auburn hair. Their face has nose pierced 
>
> ***Characteristics*** :  Hates quiet pauses in conversations
>
> ***Personality*** :  Tawdry
>
> ***Trait*** : Flattery is my preferred trick for getting what I want.
>
> ***Ideal*** : Aspiration. I'm going to prove that I'm worthy of a better life. (Any)
{ .ownerDescription }



