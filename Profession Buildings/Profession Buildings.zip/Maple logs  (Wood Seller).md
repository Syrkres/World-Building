---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wood Seller 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Maple logs 
services: services
owner: Charden (Human)
---
> [!oRPG-Layout] 
> #  Maple logs  (Wood Seller/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Charden (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  Maple logs  owned by [[Charden]] (Human)
*Wood Seller / *


**Building Description:**  An one story building, with brick siding with a missing short window. The roof is planked with Oak planks. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal weak build, with white eyes and wavy white hair. Their face has large scar 
>
> ***Characteristics*** :  Unexplained dislike for certain organization
>
> ***Personality*** :  Serene
>
> ***Trait*** : I'm full of witty aphorisms and have a proverb for every occasion.
>
> ***Ideal*** : Ideals aren't worth killing for or going to war for. (Neutral)
{ .ownerDescription }


