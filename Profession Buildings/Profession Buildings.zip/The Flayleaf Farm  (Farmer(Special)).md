---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer(Special) Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Flayleaf Farm 
services: services
owner: Sanaj (Elven)
---
> [!oRPG-Layout] 
> #  The Flayleaf Farm  (Farmer(Special)/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Sanaj (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | High |

##  The Flayleaf Farm  owned by [[Sanaj]] (Elven)
*Farmer(Special) / Farmer*


**Building Description:**  An building, stairs leading up to a set of double Copper doors, with planked siding with a front broken window that has a sign hanging above with the merchants name. The roof is shingled.  



> ### Owner Description/Background
> ***Appearance*** : Grand anorexic build, with red eyes and bald auburn hair. Their face is chiseled 
>
> ***Characteristics*** :  Dandruff
>
> ***Personality*** :  Impatient
>
> ***Trait*** : The common folk love me for my kindness and generosity.
>
> ***Ideal*** : Ideals aren't worth killing for or going to war for. (Neutral)
{ .ownerDescription }



