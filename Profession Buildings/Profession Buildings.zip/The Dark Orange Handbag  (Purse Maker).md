---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Purse Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Dark Orange Handbag 
services: services
owner: Montlegum (Human)
---
> [!oRPG-Layout] 
> #  The Dark Orange Handbag  (Purse Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Montlegum (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Below Average |

##  The Dark Orange Handbag  owned by [[Montlegum]] (Human)
*Purse Maker / Tailor*


**Building Description:**  An new tall building, stairs leading up to a Maple wood door with a Pine frame with planked siding. The roof is shingled. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Average average build, with brown eyes and pony-tail grey hair. Their face has a goatee 
>
> ***Characteristics*** :  Talks to inanimate objects
>
> ***Personality*** :  Loyal
>
> ***Trait*** : I have a crude sense of humor.
>
> ***Ideal*** : Independence. I must prove that I can handle myself without the coddling of my family. (Chaotic)
{ .ownerDescription }



