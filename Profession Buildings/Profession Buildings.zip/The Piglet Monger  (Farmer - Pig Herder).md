---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Pig Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Piglet Monger 
services: services
owner: Machleit (Human)
---
> [!oRPG-Layout] 
> #  The Piglet Monger  (Farmer - Pig Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Machleit (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Low |

##  The Piglet Monger  owned by [[Machleit]] (Human)
*Farmer - Pig Herder / Farmer*


**Building Description:**  An long one story building, with faded paint with brick siding. The roof is planked. A Elm chest sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Grand strong build, with green eyes and long white hair. Their face is weather-beaten 
>
> ***Characteristics*** :  Distinctive jewelry
>
> ***Personality*** :  Moody
>
> ***Trait*** : Whenever I come to a new place, I collect local rumors and spread gossip.
>
> ***Ideal*** : Greed. I will do whatever it takes to become wealthy. (Evil)
{ .ownerDescription }



