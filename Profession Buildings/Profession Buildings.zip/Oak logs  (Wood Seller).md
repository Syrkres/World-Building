---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wood Seller 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Oak logs 
services: services
owner: Bequin (Halfling)
---
> [!oRPG-Layout] 
> #  Oak logs  (Wood Seller/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bequin (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Low |

##  Oak logs  owned by [[Bequin]] (Halfling)
*Wood Seller / *


**Building Description:**  An old one story building, with stoned siding. The roof is shingled.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall anorexic build, with brown eyes and long white hair. Their face is pierced 
>
> ***Characteristics*** :  Altophobic (afraid of heights)
>
> ***Personality*** :  Argumentative
>
> ***Trait*** : I am horribly, horribly awkward in social situations.
>
> ***Ideal*** : Might. If I become strong, I can take what I want--what I deserve. (Evil)
{ .ownerDescription }



