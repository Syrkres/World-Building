---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crime Lord 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Black Codex 
services: services
owner: Bray (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Black Codex  (Crime Lord/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bray (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Black Codex  owned by [[Bray]] (Half-Orc)
*Crime Lord / *


**Building Description:**  An narrow building, with new paint with shingled siding with a missing window. The roof is thatching made of straw. A Oak shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal thin build, with red eyes and very long brown hair. Their face is squinty 
>
> ***Characteristics*** :  Dandruff
>
> ***Personality*** :  Rascal
>
> ***Trait*** : The first thing I do in a new place is note the locations of everything valuable--or where such things could be hidden.
>
> ***Ideal*** : Generosity. My talents were given to me so that I could use them to benefit the world. (Good)
{ .ownerDescription }



