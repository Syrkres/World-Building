---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barron Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Townhall
title:  Onsen's Mansion 
services: services
owner: Onsen (Half-Elf)
---
> [!oRPG-Layout] 
> #  Onsen's Mansion  (Barron/Offical)
> **Structure:** Townhall
> **Resides In:** 
>  **Owner:** Onsen (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Average |

##  Onsen's Mansion  owned by [[Onsen]] (Half-Elf)
*Barron / Offical*


**Building Description:**  An old narrow tall building with planked siding with a few short boarded windows. The roof is shingled with Beech shingles.  



> ### Owner Description/Background
> ***Appearance*** : Tall strong build, with white eyes and pony-tail grey hair. Their face has a patch over right eye 
>
> ***Characteristics*** :  Hacking cough
>
> ***Personality*** :  Contentious
>
> ***Trait*** : Whenever I come to a new place, I collect local rumors and spread gossip.
>
> ***Ideal*** : Might. If I become strong, I can take what I want--what I deserve. (Evil)
{ .ownerDescription }



