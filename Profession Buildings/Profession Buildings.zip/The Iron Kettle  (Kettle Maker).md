---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Kettle Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Iron Kettle 
services: services
owner: Aristo (Dwarf)
---
> [!oRPG-Layout] 
> #  The Iron Kettle  (Kettle Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Aristo (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  The Iron Kettle  owned by [[Aristo]] (Dwarf)
*Kettle Maker / Crafter*


**Building Description:**  An long building, with brick siding with a few short windows. The roof is planked with Hickory planks.  



> ### Owner Description/Background
> ***Appearance*** : Extra short wide build, with red eyes and wavy grey hair. Their face has a missing left eye 
>
> ***Characteristics*** :  Bad with money
>
> ***Personality*** :  Nervous
>
> ***Trait*** : I sleep with my back to a wall or tree, with everything I own wrapped in a bundle in my arms.
>
> ***Ideal*** : Power. Knowledge is the path to power and domination. (Evil)
{ .ownerDescription }



