---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cabbage Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Merciful Meadows 
services: services
owner: Peper (Dwarf)
---
> [!oRPG-Layout] 
> #  The Merciful Meadows  (Farmer - Cabbage/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Peper (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  The Merciful Meadows  owned by [[Peper]] (Dwarf)
*Farmer - Cabbage / Farmer*


**Building Description:**  An building, a Elm wood door with planked siding with a front boarded window that has a Steal door with the merchants name. The roof is timber. A shed is attached to the side. A pile of Beech wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall weak build, with blue eyes and very long grey hair. Their face has small scar on right cheek 
>
> ***Characteristics*** :  Haphephobic (afraid of being touched)
>
> ***Personality*** :  Wicked
>
> ***Trait*** : I've lost too many friends, and I'm slow to make new ones.
>
> ***Ideal*** : Honor. If I dishonor myself, I dishonor my whole clan. (Lawful)
{ .ownerDescription }



