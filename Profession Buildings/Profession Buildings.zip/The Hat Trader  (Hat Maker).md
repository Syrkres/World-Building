---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Hat Trader 
services: services
owner: Sula (Elven)
---
> [!oRPG-Layout] 
> #  The Hat Trader  (Hat Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Sula (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  The Hat Trader  owned by [[Sula]] (Elven)
*Hat Maker / Tailor*


**Building Description:**  An one story building, with faded paint with brick siding. The roof is thatched. A shed is attached to the side. A warn Maple barrel sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall lean build, with hazel eyes and streaked brown hair. Their face has a moustache 
>
> ***Characteristics*** :  Always wears as little as possible
>
> ***Personality*** :  Ornery
>
> ***Trait*** : I get bitter if I'm not the center of attention.
>
> ***Ideal*** : Freedom. Chains are meant to be broken, as are those who would forge them. (Chaotic)
{ .ownerDescription }



