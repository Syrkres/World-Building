---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Miller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Belaamin's Mill 
services: services
owner: Belaamin (Elven)
---
> [!oRPG-Layout] 
> #  Belaamin's Mill  (Miller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Belaamin (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Below Average |

##  Belaamin's Mill  owned by [[Belaamin]] (Elven)
*Miller / Cooks*


**Building Description:**  An old one story building, with shingled siding. The roof is thatching made of straw. A pile of Pine wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Short strong build, with red eyes and streaked white hair. Their face has large scar 
>
> ***Characteristics*** :  Bites fingernails
>
> ***Personality*** :  Spiteful
>
> ***Trait*** : I'm well known for my work, and I want to make sure everyone appreciates it. I'm always taken aback when people haven't heard of me.
>
> ***Ideal*** : Free Thinking. Inquiry and curiosity are the pillars of progress. (Chaotic)
{ .ownerDescription }



