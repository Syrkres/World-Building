---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: ArmorSmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Gold Chainmail Smith 
services: services
owner: Linka (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Gold Chainmail Smith  (ArmorSmith/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Linka (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  The Gold Chainmail Smith  owned by [[Linka]] (Half-Orc)
*ArmorSmith / *


**Building Description:**  A new long building with a smithy attached to the side. An anvil sits in the corner of the yard.  



> ### Owner Description/Background
> ***Appearance*** : Squat weak build, with brown eyes and curly white hair. Their face is doe-eyed 
>
> ***Characteristics*** :  Warts
>
> ***Personality*** :  Defensive
>
> ***Trait*** : Despite my birth, I do not place myself above other folk. We all have the same blood.
>
> ***Ideal*** : Fairness. I never target people who can't afford to lose a few coins. (Lawful)
{ .ownerDescription }



