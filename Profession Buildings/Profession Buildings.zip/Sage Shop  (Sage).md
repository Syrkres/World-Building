---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sage Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Sage Shop 
services: services
owner: Covell (Half-Elf)
---
> [!oRPG-Layout] 
> #  Sage Shop  (Sage/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Covell (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Low |

##  Sage Shop  owned by [[Covell]] (Half-Elf)
*Sage / Librarian*


**Building Description:**  An new narrow one story building, with brick siding with a missing window. The roof is thatching made of straw. A shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand weak build, with green eyes and streaked black hair. Their face has a moustache 
>
> ***Characteristics*** :  Uses wrong word and refuses to acknowledge correct word
>
> ***Personality*** :  Phony
>
> ***Trait*** : I eat like a pig and have bad manners.
>
> ***Ideal*** : Beauty. What is beautiful points us beyond itself toward what is true. (Good)
{ .ownerDescription }



