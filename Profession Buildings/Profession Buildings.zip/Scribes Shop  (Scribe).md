---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Scribe 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Scribes Shop 
services: services
owner: Delarue (Dwarf)
---
> [!oRPG-Layout] 
> #  Scribes Shop  (Scribe/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Delarue (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Below Average |

##  Scribes Shop  owned by [[Delarue]] (Dwarf)
*Scribe / *


**Building Description:**  An new long building, with new paint stairs leading up to a set of double Iron doors, with shingled siding. The roof is timber made of Beech. A Pine shed structure is to the side. A pile of Beech wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Tall weak build, with blue eyes and dreadlocks blond hair. Their face has a broken nose 
>
> ***Characteristics*** :  Uses wrong word and refuses to acknowledge correct word
>
> ***Personality*** :  Chaste
>
> ***Trait*** : I am always calm, no matter what the situation. I never raise my voice or let my emotions control me.
>
> ***Ideal*** : Beauty. When I perform, I make the world better than it was. (Good)
{ .ownerDescription }



