---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Alchemist Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Mixed Lichen Elixer 
services: services
owner: Forster (Gnome)
---
> [!oRPG-Layout] 
> #  The Mixed Lichen Elixer  (Alchemist/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Forster (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Low |

##  The Mixed Lichen Elixer  owned by [[Forster]] (Gnome)
*Alchemist / Librarian*


**Building Description:**  An new two story building, with new paint a Red Oak wood door with a Pine frame with shingled siding. The roof is timber. A Elm shed is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Normal wide build, with green eyes and strange hairstyle black hair. Their face is chiseled 
>
> ***Characteristics*** :  Chews tobacco
>
> ***Personality*** :  Gruff
>
> ***Trait*** : There's nothing I like more than a good mystery.
>
> ***Ideal*** : Change. Life is like the seasons, in constant change, and we must change with it. (Chaotic)
{ .ownerDescription }



