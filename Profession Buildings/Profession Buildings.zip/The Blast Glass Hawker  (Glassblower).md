---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Glassblower Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Blast Glass Hawker 
services: services
owner: Considine (Gnome)
---
> [!oRPG-Layout] 
> #  The Blast Glass Hawker  (Glassblower/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Considine (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | High |

##  The Blast Glass Hawker  owned by [[Considine]] (Gnome)
*Glassblower / Crafter*


**Building Description:**  An new long one story building, with faded paint with shingled siding with a few boarded windows. The roof is planked. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Average fat build, with white eyes and wavy blond hair. Their face is pierced 
>
> ***Characteristics*** :  Dirty
>
> ***Personality*** :  Sultry
>
> ***Trait*** : I...speak...slowly...when talking...to idiots...which...almost...everyone...is...compared ...to me.
>
> ***Ideal*** : Greater Good. My gifts are meant to be shared with all, not used for my own benefit. (Good)
{ .ownerDescription }



