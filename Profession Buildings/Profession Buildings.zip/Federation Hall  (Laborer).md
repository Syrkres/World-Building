---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Laborer Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Federation Hall 
services: services
owner: Troyer (Halfling)
---
> [!oRPG-Layout] 
> #  Federation Hall  (Laborer/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Troyer (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | High |

##  Federation Hall  owned by [[Troyer]] (Halfling)
*Laborer / Professional*


**Building Description:**  An old building, with faded paint stairs leading up to a set of double Bronze doors, with brick siding with a front window that has a Cherry wood door with the merchants name. The roof is thatching made of grass. A Pine shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall anorexic build, with green eyes and well groomed red hair. Their face has eyebrow pierced 
>
> ***Characteristics*** :  Touches people while talking to them
>
> ***Personality*** :  Serious
>
> ***Trait*** : The best way to get me to do something is to tell me I can't do it.
>
> ***Ideal*** : Free Thinking. Inquiry and curiosity are the pillars of progress. (Chaotic)
{ .ownerDescription }



