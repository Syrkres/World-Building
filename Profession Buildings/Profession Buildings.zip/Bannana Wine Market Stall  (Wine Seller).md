---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wine Seller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Bannana Wine Market Stall 
services: services
owner: Hice (Half-Elf)
---
> [!oRPG-Layout] 
> #  Bannana Wine Market Stall  (Wine Seller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hice (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  Bannana Wine Market Stall  owned by [[Hice]] (Half-Elf)
*Wine Seller / Cooks*


**Building Description:**  An narrow two story building, with new paint a Hickory wood with Iron bands door with shingled siding. The roof is planked with Elm planks. A few new Beech barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short wide build, with green eyes and thick blond hair. Their face has a missing eye 
>
> ***Characteristics*** :  Dirty
>
> ***Personality*** :  Hostile
>
> ***Trait*** : I pocket anything I see that might have some value.
>
> ***Ideal*** : Change. The low are lifted up, and the high and mighty are brought down. Change is the nature of things. (Chaotic)
{ .ownerDescription }



