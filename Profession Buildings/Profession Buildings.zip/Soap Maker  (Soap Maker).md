---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Soap Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Soap Maker 
services: services
owner: Hidalgo (Elven)
---
> [!oRPG-Layout] 
> #  Soap Maker  (Soap Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hidalgo (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | High |

##  Soap Maker  owned by [[Hidalgo]] (Elven)
*Soap Maker / Crafter*


**Building Description:**  An two story building, with faded paint a Beech wood with Bronze bands door with a Beech frame with shingled siding. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Tall athletic build, with white eyes and strange hairstyle grey hair. Their face has nose pierced 
>
> ***Characteristics*** :  Has nightmares
>
> ***Personality*** :  Obsequious
>
> ***Trait*** : My eloquent flattery makes everyone I talk to feel like the most wonderful and important person in the world.
>
> ***Ideal*** : Responsibility. I do what I must and obey just authority. (Lawful)
{ .ownerDescription }



