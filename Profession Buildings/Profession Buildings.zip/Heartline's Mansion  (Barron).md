---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barron Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Townhall
title:  Heartline's Mansion 
services: services
owner: Heartline (Halfling)
---
> [!oRPG-Layout] 
> #  Heartline's Mansion  (Barron/Offical)
> **Structure:** Townhall
> **Resides In:** 
>  **Owner:** Heartline (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Below Average |

##  Heartline's Mansion  owned by [[Heartline]] (Halfling)
*Barron / Offical*


**Building Description:**  An new tall building with planked siding. The roof is thatching made of grass. A Elm shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand athletic build, with white eyes and well groomed red hair. Their face has nose pierced 
>
> ***Characteristics*** :  Wears only jewelry of one type of metal
>
> ***Personality*** :  Humorous
>
> ***Trait*** : I've lost too many friends, and I'm slow to make new ones.
>
> ***Ideal*** : Aspiration. I'm going to prove that I'm worthy of a better life. (Any)
{ .ownerDescription }



