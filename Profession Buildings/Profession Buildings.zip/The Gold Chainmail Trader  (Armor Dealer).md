---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armor Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Gold Chainmail Trader 
services: services
owner: Fualla (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Gold Chainmail Trader  (Armor Dealer/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Fualla (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  The Gold Chainmail Trader  owned by [[Fualla]] (Half-Elf)
*Armor Dealer / *


**Building Description:**  A building with a smithy structure to the side. An anvil sits in outside smithy.  



> ### Owner Description/Background
> ***Appearance*** : Extra short athletic build, with hazel eyes and braided black hair. Their face is toothless 
>
> ***Characteristics*** :  Hates animals
>
> ***Personality*** :  Dominating
>
> ***Trait*** : I am horribly, horribly awkward in social situations.
>
> ***Ideal*** : Knowledge. The path to power and self-improvement is through knowledge. (Neutral)
{ .ownerDescription }



