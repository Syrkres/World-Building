---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Librarian Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Classic Tome 
services: services
owner: Albaara (Elven)
---
> [!oRPG-Layout] 
> #  The Classic Tome  (Librarian/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Albaara (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Average |

##  The Classic Tome  owned by [[Albaara]] (Elven)
*Librarian / Librarian*


**Building Description:**  An narrow one story building, with faded paint with stoned siding. The roof is timber. A Maple shed structure is to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Average athletic build, with brown eyes and frazzled white hair. Their face has large scar 
>
> ***Characteristics*** :  Spits
>
> ***Personality*** :  Risk-taking
>
> ***Trait*** : I am working on a grand philosophical theory and love sharing my ideas.
>
> ***Ideal*** : Responsibility. I do what I must and obey just authority. (Lawful)
{ .ownerDescription }



