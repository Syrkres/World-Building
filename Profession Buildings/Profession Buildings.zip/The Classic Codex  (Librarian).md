---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Librarian Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Classic Codex 
services: services
owner: Obol (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Classic Codex  (Librarian/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Obol (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  The Classic Codex  owned by [[Obol]] (Half-Orc)
*Librarian / Librarian*


**Building Description:**  An narrow two story building, with faded paint with brick siding with a missing round window. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Extra short thin build, with red eyes and wavy white hair. Their face has sideburns 
>
> ***Characteristics*** :  Double-checks everything
>
> ***Personality*** :  Rigid
>
> ***Trait*** : I am utterly serene, even in the face of disaster.
>
> ***Ideal*** : Faith. I trust that my deity will guide my actions. I have faith that if I work hard, things will go well. (Lawful)
{ .ownerDescription }



