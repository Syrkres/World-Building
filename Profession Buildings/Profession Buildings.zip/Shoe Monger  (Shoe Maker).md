---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Shoe Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Shoe Monger 
services: services
owner: Aristo (Human)
---
> [!oRPG-Layout] 
> #  Shoe Monger  (Shoe Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Aristo (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  Shoe Monger  owned by [[Aristo]] (Human)
*Shoe Maker / Tailor*


**Building Description:**  An new long building, a set of double Beech wood with Copper bands doors, with brick siding. The roof is thatching made of grass. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Tall anorexic build, with red eyes and straight auburn hair. Their face has lip pierced 
>
> ***Characteristics*** :  Ornithophobic (afraid of birds)
>
> ***Personality*** :  Tempestuous
>
> ***Trait*** : I bluntly say what other people are hinting or hiding.
>
> ***Ideal*** : Responsibility. I do what I must and obey just authority. (Lawful)
{ .ownerDescription }



