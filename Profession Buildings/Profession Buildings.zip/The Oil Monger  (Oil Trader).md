---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Oil Trader Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Oil Monger 
services: services
owner: Afterman (Gnome)
---
> [!oRPG-Layout] 
> #  The Oil Monger  (Oil Trader/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Afterman (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  The Oil Monger  owned by [[Afterman]] (Gnome)
*Oil Trader / Offical*


**Building Description:**  An two story building, stairs leading up to a set of double Iron doors, with stoned siding with a front tall broken window that has stairs leading up to a Pine wood with Steal bands door with the merchants name. The roof is thatched. A few old Ceder barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Grand weak build, with white eyes and messy black hair. Their face has a missing eye 
>
> ***Characteristics*** :  Body piercings on Head/Face on Left leg on Head/Face on Right leg on Left leg on Chest
>
> ***Personality*** :  Frivolous
>
> ***Trait*** : I see omens in every event and action. The gods try to speak to us, we just need to listen.
>
> ***Ideal*** : People. I'm committed to the people I care about, not to ideals. (Neutral)
{ .ownerDescription }



