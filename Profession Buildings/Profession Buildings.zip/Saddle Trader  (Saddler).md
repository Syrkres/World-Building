---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Saddler Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Saddle Trader 
services: services
owner: Wohler (Elven)
---
> [!oRPG-Layout] 
> #  Saddle Trader  (Saddler/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Wohler (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Low |

##  Saddle Trader  owned by [[Wohler]] (Elven)
*Saddler / Crafter*


**Building Description:**  An two story building, with faded paint stairs leading up to a set of double Beech wood doors, with shingled siding with a few broken windows. The roof is planked. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Squat fat build, with blue eyes and curly blond hair. Their face has lip pierced 
>
> ***Characteristics*** :  Refuses to let anyone walk behind them
>
> ***Personality*** :  Enigmatic
>
> ***Trait*** : I am incredibly slow to trust. Those who seem the fairest often have the most to hide.
>
> ***Ideal*** : Honor. If I dishonor myself, I dishonor my whole clan. (Lawful)
{ .ownerDescription }



