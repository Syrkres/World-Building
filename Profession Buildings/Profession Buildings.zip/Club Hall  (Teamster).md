---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Teamster Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Club Hall 
services: services
owner: Lorde (Half-Orc)
---
> [!oRPG-Layout] 
> #  Club Hall  (Teamster/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Lorde (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Below Average |

##  Club Hall  owned by [[Lorde]] (Half-Orc)
*Teamster / Professional*


**Building Description:**  An old tall building, with faded paint a Steal door with a Elm frame with stoned siding with a few round windows. The roof is planked with Elm planks. A Pine pergola is attached to the side. A Maple crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Normal wide build, with blue eyes and braided black hair. Their face is weather-beaten 
>
> ***Characteristics*** :  Imaginary friend
>
> ***Personality*** :  Comforting
>
> ***Trait*** : I can find common ground between the fiercest enemies, empathizing with them and always working toward peace.
>
> ***Ideal*** : Tradition. The ancient traditions of worship and sacrifice must be preserved and upheld. (Lawful)
{ .ownerDescription }



