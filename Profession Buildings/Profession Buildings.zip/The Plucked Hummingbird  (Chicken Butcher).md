---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chicken Butcher Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Plucked Hummingbird 
services: services
owner: Kaiden (Gnome)
---
> [!oRPG-Layout] 
> #  The Plucked Hummingbird  (Chicken Butcher/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kaiden (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Plucked Hummingbird  owned by [[Kaiden]] (Gnome)
*Chicken Butcher / Cooks*


**Building Description:**  An narrow two story building, with new paint stairs leading up to a set of double Bronze doors, with brick siding. The roof is shingled. A Hickory shed structure is to the side. A Red Oak crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Normal fat build, with red eyes and short auburn hair. Their face has a broken nose 
>
> ***Characteristics*** :  Unable to remember names
>
> ***Personality*** :  Proper
>
> ***Trait*** : I stretch the truth for the sake of a good story.
>
> ***Ideal*** : Respect. The thing that keeps a ship together is mutual respect between captain and crew. (Good)
{ .ownerDescription }



