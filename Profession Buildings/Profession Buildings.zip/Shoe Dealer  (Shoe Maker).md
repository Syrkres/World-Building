---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Shoe Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Shoe Dealer 
services: services
owner: Arbogahst (Elven)
---
> [!oRPG-Layout] 
> #  Shoe Dealer  (Shoe Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Arbogahst (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Below Average |

##  Shoe Dealer  owned by [[Arbogahst]] (Elven)
*Shoe Maker / Tailor*


**Building Description:**  An new building, with new paint with shingled siding. The roof is timber.  



> ### Owner Description/Background
> ***Appearance*** : Short frail build, with white eyes and straight blond hair. Their face has a missing right eye 
>
> ***Characteristics*** :  Plays practical jokes
>
> ***Personality*** :  Obtuse
>
> ***Trait*** : My language is as foul as an otyugh nest.
>
> ***Ideal*** : Freedom. The sea is freedom--the freedom to go anywhere and do anything. (Chaotic)
{ .ownerDescription }



