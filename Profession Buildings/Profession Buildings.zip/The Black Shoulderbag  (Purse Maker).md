---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Purse Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Black Shoulderbag 
services: services
owner: Haseltine (Dwarf)
---
> [!oRPG-Layout] 
> #  The Black Shoulderbag  (Purse Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Haseltine (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Black Shoulderbag  owned by [[Haseltine]] (Dwarf)
*Purse Maker / Tailor*


**Building Description:**  An new long tall building, with stoned siding. The roof is shingled. A Oak shed is attached to the side. A pile of Pine wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Tall wide build, with hazel eyes and wavy blond hair. Their face has large scar on right cheek 
>
> ***Characteristics*** :  Sharpens weapon
>
> ***Personality*** :  Prejudiced
>
> ***Trait*** : I ask a lot of questions.
>
> ***Ideal*** : Independence. I am a free spirit--no one tells me what to do. (Chaotic)
{ .ownerDescription }



