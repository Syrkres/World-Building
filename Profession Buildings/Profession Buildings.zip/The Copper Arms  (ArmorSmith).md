---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: ArmorSmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Copper Arms 
services: services
owner: Bequin (Dwarf)
---
> [!oRPG-Layout] 
> #  The Copper Arms  (ArmorSmith/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Bequin (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Above Average |

##  The Copper Arms  owned by [[Bequin]] (Dwarf)
*ArmorSmith / *


**Building Description:**  A building with a smithy attached to the side. An polished anvil sits in outside yard a large smith hammer lying across the top with various Flail lying about. A Hickory chest filled with water, with a Hammer leaning against the base.  



> ### Owner Description/Background
> ***Appearance*** : Average anorexic build, with white eyes and wiry brown hair. Their face has stained teeth 
>
> ***Characteristics*** :  Giggles
>
> ***Personality*** :  Outgoing
>
> ***Trait*** : I think anyone who's nice to me is hiding evil intent.
>
> ***Ideal*** : Change. We must help bring about the changes the gods are constantly working in the world. (Chaotic)
{ .ownerDescription }



