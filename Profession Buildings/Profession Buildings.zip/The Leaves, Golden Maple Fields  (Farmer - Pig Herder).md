---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Pig Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Leaves, Golden Maple Fields 
services: services
owner: Kibble (Dwarf)
---
> [!oRPG-Layout] 
> #  The Leaves, Golden Maple Fields  (Farmer - Pig Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kibble (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  The Leaves, Golden Maple Fields  owned by [[Kibble]] (Dwarf)
*Farmer - Pig Herder / Farmer*


**Building Description:**  An new building, a set of double Yellow Birch wood with Iron bands doors with a Beech frame, with planked siding. The roof is thatching made of straw. A Cherry pergola is attached to the side. A warn Maple barrel sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short fat build, with brown eyes and streaked white hair. Their face has a broken nose 
>
> ***Characteristics*** :  Wets bed
>
> ***Personality*** :  Enigmatic
>
> ***Trait*** : I blow up at the slightest insult.
>
> ***Ideal*** : People. I'm committed to the people I care about, not to ideals. (Neutral)
{ .ownerDescription }



