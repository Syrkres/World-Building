---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Potter Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Pot Parlor 
services: services
owner: Adderfeld (Elven)
---
> [!oRPG-Layout] 
> #  The Pot Parlor  (Potter/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Adderfeld (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Average |

##  The Pot Parlor  owned by [[Adderfeld]] (Elven)
*Potter / Crafter*


**Building Description:**  An two story building, with new paint with planked siding. The roof is planked with Pine planks. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall thin build, with white eyes and limp grey hair. Their face is missing teeth 
>
> ***Characteristics*** :  Talks about self in third-person
>
> ***Personality*** :  Humble
>
> ***Trait*** : I watch over my friends as if they were a litter of newborn pups.
>
> ***Ideal*** : People. I'm committed to my crewmates, not to ideals. (Neutral)
{ .ownerDescription }



