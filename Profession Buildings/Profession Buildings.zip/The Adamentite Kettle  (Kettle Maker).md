---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Kettle Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Adamentite Kettle 
services: services
owner: Cynewulf (Dwarf)
---
> [!oRPG-Layout] 
> #  The Adamentite Kettle  (Kettle Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Cynewulf (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  The Adamentite Kettle  owned by [[Cynewulf]] (Dwarf)
*Kettle Maker / Crafter*


**Building Description:**  An two story building, with new paint with brick siding with a few short boarded windows. The roof is shingled with Maple shingles. A pile of Oak wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Average average build, with green eyes and well groomed white hair. Their face has a patch over right eye 
>
> ***Characteristics*** :  Bad breath or strong body odor
>
> ***Personality*** :  Gloomy
>
> ***Trait*** : I pocket anything I see that might have some value.
>
> ***Ideal*** : Fairness. I never target people who can't afford to lose a few coins. (Lawful)
{ .ownerDescription }



