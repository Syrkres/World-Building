---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Used Garment Trader Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Garment Trader 
services: services
owner: Alcala (Halfling)
---
> [!oRPG-Layout] 
> #  Garment Trader  (Used Garment Trader/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Alcala (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  Garment Trader  owned by [[Alcala]] (Halfling)
*Used Garment Trader / Tailor*


**Building Description:**  An long two story building, with faded paint a set of double Pine wood with Iron bands doors with a Red Oak frame, with shingled siding. The roof is planked with Yellow Birch planks. A Red Oak shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal anorexic build, with hazel eyes and thick brown hair. Their face is weather-beaten 
>
> ***Characteristics*** :  Unexplained dislike for certain organization
>
> ***Personality*** :  Prudent
>
> ***Trait*** : I'm always polite and respectful.
>
> ***Ideal*** : Fairness. We all do the work, so we all share in the rewards. (Lawful)
{ .ownerDescription }



