---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armor Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Blue Steal Ringmail Trader 
services: services
owner: Kadmon (Halfling)
---
> [!oRPG-Layout] 
> #  The Blue Steal Ringmail Trader  (Armor Dealer/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Kadmon (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Below Average |

##  The Blue Steal Ringmail Trader  owned by [[Kadmon]] (Halfling)
*Armor Dealer / *


**Building Description:**  A tall building with a smithy attached to the side. An anvil sits in the corner of the smithy a large smith hammer lying across the top with various Dagger lying about.  



> ### Owner Description/Background
> ***Appearance*** : Grand wide build, with white eyes and long red hair. Their face has large scar on right cheek 
>
> ***Characteristics*** :  Wears flamboyant or outlandish clothes
>
> ***Personality*** :  Prudish
>
> ***Trait*** : I'm a born gambler who can't resist taking a risk for a potential payoff.
>
> ***Ideal*** : Creativity. I never run the same con twice. (Chaotic)
{ .ownerDescription }



