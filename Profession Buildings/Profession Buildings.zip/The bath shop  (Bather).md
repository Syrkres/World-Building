---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Bather Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The bath shop 
services: services
owner: Belaamin (Dwarf)
---
> [!oRPG-Layout] 
> #  The bath shop  (Bather/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Belaamin (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  The bath shop  owned by [[Belaamin]] (Dwarf)
*Bather / Professional*


**Building Description:**  An narrow building, with shingled siding. The roof is timber made of Hickory. A Hickory crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Short athletic build, with hazel eyes and thinning blond hair. Their face has acne 
>
> ***Characteristics*** :  Puts garlic on all food
>
> ***Personality*** :  Shameful
>
> ***Trait*** : I've read every book in the world's greatest libraries--or like to boast that I have.
>
> ***Ideal*** : Community. We have to take care of each other, because no one else is going to do it. (Lawful)
{ .ownerDescription }



