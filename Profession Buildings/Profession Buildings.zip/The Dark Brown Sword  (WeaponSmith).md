---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: WeaponSmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Dark Brown Sword 
services: services
owner: Murdin (Gnome)
---
> [!oRPG-Layout] 
> #  The Dark Brown Sword  (WeaponSmith/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Murdin (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  The Dark Brown Sword  owned by [[Murdin]] (Gnome)
*WeaponSmith / *


**Building Description:**  A new one story building with a smithy structure to the side. An anvil sits in the corner of the smithy a large smith hammer lying across the top with various Flail lying about. A saw horse with hay strewn about, a sledge hammer leaning on the edge.  



> ### Owner Description/Background
> ***Appearance*** : Grand weak build, with blue eyes and bald blond hair. Their face has nose pierced 
>
> ***Characteristics*** :  Sweaty
>
> ***Personality*** :  Whimsical
>
> ***Trait*** : I get bitter if I'm not the center of attention.
>
> ***Ideal*** : Beauty. What is beautiful points us beyond itself toward what is true. (Good)
{ .ownerDescription }



