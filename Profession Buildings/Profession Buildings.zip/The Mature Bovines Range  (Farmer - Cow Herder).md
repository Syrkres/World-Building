---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cow Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Mature Bovines Range 
services: services
owner: Crowsfly (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Mature Bovines Range  (Farmer - Cow Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Crowsfly (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Low |

##  The Mature Bovines Range  owned by [[Crowsfly]] (Half-Orc)
*Farmer - Cow Herder / Farmer*


**Building Description:**  An building, with new paint with stoned siding with a few tall boarded windows. The roof is planked with Pine planks. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Average wide build, with red eyes and curly auburn hair. Their face has large scar on right cheek 
>
> ***Characteristics*** :  Wears only jewelry of one type of metal
>
> ***Personality*** :  Obedient
>
> ***Trait*** : I'm a snob who looks down on those who can't appreciate fine art.
>
> ***Ideal*** : Respect. People deserve to be treated with dignity and respect. (Good)
{ .ownerDescription }



