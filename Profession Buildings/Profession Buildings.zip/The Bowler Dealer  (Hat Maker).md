---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Bowler Dealer 
services: services
owner: Onsk (Elven)
---
> [!oRPG-Layout] 
> #  The Bowler Dealer  (Hat Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Onsk (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Average |

##  The Bowler Dealer  owned by [[Onsk]] (Elven)
*Hat Maker / Tailor*


**Building Description:**  An building, with faded paint a Bronze door with stoned siding with a missing window. The roof is thatching made of straw. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall athletic build, with green eyes and pony-tail brown hair. Their face has a missing right eye 
>
> ***Characteristics*** :  Scarred on Right leg on Left leg on Left arm on Head/Face on Right leg on Left arm
>
> ***Personality*** :  Inexorable
>
> ***Trait*** : I always want to know how things work and what makes people tick.
>
> ***Ideal*** : Greed. I'm only in it for the money. (Evil)
{ .ownerDescription }



