---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tutor Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Teachers Guild 
services: services
owner: Cynewulf (Halfling)
---
> [!oRPG-Layout] 
> #  Teachers Guild  (Tutor/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Cynewulf (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | High |

##  Teachers Guild  owned by [[Cynewulf]] (Halfling)
*Tutor / Librarian*


**Building Description:**  An old long building, stairs leading up to a set of double Hickory wood doors, with stoned siding with a few boarded windows. The roof is thatching made of grass. A Pine pergola is attached to the side. A Beech crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Grand anorexic build, with red eyes and bald brown hair. Their face has a moustache 
>
> ***Characteristics*** :  Makes up words
>
> ***Personality*** :  Imaginative
>
> ***Trait*** : When I set my mind to something, I follow through no matter what gets in my way.
>
> ***Ideal*** : Respect. All people, rich or poor, deserve respect. (Good)
{ .ownerDescription }



