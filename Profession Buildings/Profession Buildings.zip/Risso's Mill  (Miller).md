---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Miller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Risso's Mill 
services: services
owner: Risso (Human)
---
> [!oRPG-Layout] 
> #  Risso's Mill  (Miller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Risso (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  Risso's Mill  owned by [[Risso]] (Human)
*Miller / Cooks*


**Building Description:**  An old tall building, with new paint a Copper door with a Maple frame with brick siding. The roof is shingled. A shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short weak build, with red eyes and pony-tail brown hair. Their face is gap-toothed 
>
> ***Characteristics*** :  Dirty
>
> ***Personality*** :  Emotional
>
> ***Trait*** : I am utterly serene, even in the face of disaster.
>
> ***Ideal*** : Aspiration. I work hard to be the best there is at my craft. (Any)
{ .ownerDescription }



