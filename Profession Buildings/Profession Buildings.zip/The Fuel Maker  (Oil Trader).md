---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Oil Trader Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Fuel Maker 
services: services
owner: Munch (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Fuel Maker  (Oil Trader/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Munch (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | High |

##  The Fuel Maker  owned by [[Munch]] (Half-Orc)
*Oil Trader / Offical*


**Building Description:**  An two story building, a set of double Oak wood doors with a Beech frame, with planked siding with a few round windows. The roof is timber made of Maple. A Beech pergola is attached to the side. A Ceder chest sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Average frail build, with brown eyes and braided auburn hair. Their face has small scar on right cheek 
>
> ***Characteristics*** :  Unable to let a joke die
>
> ***Personality*** :  Impetuous
>
> ***Trait*** : No one could doubt by looking at my regal bearing that I am a cut above the unwashed masses.
>
> ***Ideal*** : Beauty. What is beautiful points us beyond itself toward what is true. (Good)
{ .ownerDescription }



