---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armor Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Platinum Ringmail Monger 
services: services
owner: Machleit (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Platinum Ringmail Monger  (Armor Dealer/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Machleit (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Platinum Ringmail Monger  owned by [[Machleit]] (Half-Elf)
*Armor Dealer / *


**Building Description:**  A long building with a smithy attached to the side. An polished anvil sits in outside shed a large smith hammer lying across the top with various Sword scattered about. A Red Oak crate filled with Steal bars, with a Hand shovel leaning against the base.  



> ### Owner Description/Background
> ***Appearance*** : Grand athletic build, with green eyes and pony-tail red hair. Their face has large scar across full face 
>
> ***Characteristics*** :  Imaginary friend
>
> ***Personality*** :  Inexpressive
>
> ***Trait*** : I'm a born gambler who can't resist taking a risk for a potential payoff.
>
> ***Ideal*** : Community. It is the duty of all civilized people to strengthen the bonds of community and the security of civilization. (Lawful)
{ .ownerDescription }



