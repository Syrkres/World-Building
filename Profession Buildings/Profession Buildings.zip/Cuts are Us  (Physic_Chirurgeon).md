---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Physic/Chirurgeon Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Cuts are Us 
services: services
owner: Helmwood (Gnome)
---
> [!oRPG-Layout] 
> #  Cuts are Us  (Physic/Chirurgeon/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Helmwood (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Average |

##  Cuts are Us  owned by [[Helmwood]] (Gnome)
*Physic/Chirurgeon / Professional*


**Building Description:**  An long two story building, with brick siding. The roof is planked with Pine planks.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall wide build, with red eyes and short auburn hair. Their face is toothless 
>
> ***Characteristics*** :  Flatulent
>
> ***Personality*** :  Foolhardy
>
> ***Trait*** : When I set my mind to something, I follow through no matter what gets in my way.
>
> ***Ideal*** : Fairness. We all do the work, so we all share in the rewards. (Lawful)
{ .ownerDescription }



