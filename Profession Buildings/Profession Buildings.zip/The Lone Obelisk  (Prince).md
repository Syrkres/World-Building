---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Prince Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Lone Obelisk 
services: services
owner: Langeven (Dwarf)
---
> [!oRPG-Layout] 
> #  The Lone Obelisk  (Prince/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Langeven (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  The Lone Obelisk  owned by [[Langeven]] (Dwarf)
*Prince / Offical*


**Building Description:**  An new long building, with new paint stairs leading up to a set of double Bronze doors, with shingled siding with a few short windows. The roof is thatching made of straw. A Cherry shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Tall athletic build, with brown eyes and greasy brown hair. Their face has small scar 
>
> ***Characteristics*** :  Hates children
>
> ***Personality*** :  Serious
>
> ***Trait*** : I get bored easily. When am I going to get on with my destiny.
>
> ***Ideal*** : Aspiration. I work hard to be the best there is at my craft. (Any)
{ .ownerDescription }



