---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Pig Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Large Pig Farm 
services: services
owner: Phalastin (Elven)
---
> [!oRPG-Layout] 
> #  The Large Pig Farm  (Farmer - Pig Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Phalastin (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Above Average |

##  The Large Pig Farm  owned by [[Phalastin]] (Elven)
*Farmer - Pig Herder / Farmer*


**Building Description:**  An long building, with planked siding. The roof is thatched. A warn Hickory chest sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Short athletic build, with white eyes and wiry black hair. Their face has nose pierced 
>
> ***Characteristics*** :  Hook for a hand
>
> ***Personality*** :  Temperamental
>
> ***Trait*** : I'm rude to people who lack my commitment to hard work and fair play.
>
> ***Ideal*** : Freedom. The sea is freedom--the freedom to go anywhere and do anything. (Chaotic)
{ .ownerDescription }



