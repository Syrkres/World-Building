---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thief Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Emerald Bar 
services: services
owner: Kutner (Gnome)
---
> [!oRPG-Layout] 
> #  The Emerald Bar  (Thief/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kutner (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Low |

##  The Emerald Bar  owned by [[Kutner]] (Gnome)
*Thief / Guard*


**Building Description:**  An new long one story building, with shingled siding with a front round window that has stairs leading up to a Beech wood with Iron bands door with a Cherry frame with the merchants name. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Squat frail build, with green eyes and curly brown hair. Their face is weather-beaten 
>
> ***Characteristics*** :  Hates children
>
> ***Personality*** :  Savage
>
> ***Trait*** : I eat like a pig and have bad manners.
>
> ***Ideal*** : Logic. Emotions must not cloud our logical thinking. (Lawful)
{ .ownerDescription }



