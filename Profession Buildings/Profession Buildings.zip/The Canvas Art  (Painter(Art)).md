---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Painter(Art) Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Canvas Art 
services: services
owner: Reets (Gnome)
---
> [!oRPG-Layout] 
> #  The Canvas Art  (Painter(Art)/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Reets (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  The Canvas Art  owned by [[Reets]] (Gnome)
*Painter(Art) / Crafter*


**Building Description:**  An old building, with faded paint with brick siding. The roof is timber made of Oak. A Oak shed is attached to the side. A Ceder barrel sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short weak build, with white eyes and short brown hair. Their face has a missing left eye 
>
> ***Characteristics*** :  Finishes others' sentences
>
> ***Personality*** :  Tawdry
>
> ***Trait*** : I once ran twenty-five miles without stopping to warn my clan of an approaching orc horde. I'd do it again if I had to.
>
> ***Ideal*** : Aspiration. Someday I'll own my own ship and chart my own destiny. (Any)
{ .ownerDescription }



