---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Kettle Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Iron Pan 
services: services
owner: Carnevale (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Iron Pan  (Kettle Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Carnevale (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Low |

##  The Iron Pan  owned by [[Carnevale]] (Half-Orc)
*Kettle Maker / Crafter*


**Building Description:**  An long building, with faded paint with brick siding. The roof is thatching made of grass. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short fat build, with blue eyes and thinning grey hair. Their face is gap-toothed 
>
> ***Characteristics*** :  Picks scabs
>
> ***Personality*** :  Irreligious
>
> ***Trait*** : I misuse long words in an attempt to sound smarter.
>
> ***Ideal*** : Aspiration. Someday I'll own my own ship and chart my own destiny. (Any)
{ .ownerDescription }



