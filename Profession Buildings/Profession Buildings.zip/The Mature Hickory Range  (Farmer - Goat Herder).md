---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Goat Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Mature Hickory Range 
services: services
owner: Oback (Elven)
---
> [!oRPG-Layout] 
> #  The Mature Hickory Range  (Farmer - Goat Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Oback (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  The Mature Hickory Range  owned by [[Oback]] (Elven)
*Farmer - Goat Herder / Farmer*


**Building Description:**  An old building, with faded paint with stoned siding. The roof is shingled. A pile of Hickory wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand frail build, with white eyes and thinning grey hair. Their face has nose pierced 
>
> ***Characteristics*** :  Excessive body hair
>
> ***Personality*** :  Clumsy
>
> ***Trait*** : I don't part with my money easily and will haggle tirelessly to get the best deal possible.
>
> ***Ideal*** : Greater Good. Our lot is to lay down our lives in defense of others. (Good)
{ .ownerDescription }



