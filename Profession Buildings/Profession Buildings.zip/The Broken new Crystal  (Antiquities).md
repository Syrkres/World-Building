---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Broken new Crystal 
services: services
owner: Malathia (Human)
---
> [!oRPG-Layout] 
> #  The Broken new Crystal  (Antiquities/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Malathia (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Low |

##  The Broken new Crystal  owned by [[Malathia]] (Human)
*Antiquities / Offical*


**Building Description:**  An new building, with brick siding. The roof is timber. A Yellow Birch shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short wide build, with red eyes and dreadlocks auburn hair. Their face is grizzled 
>
> ***Characteristics*** :  Mutters
>
> ***Personality*** :  Joking
>
> ***Trait*** : I'm willing to listen to every side of an argument before I make my own judgment.
>
> ***Ideal*** : Creativity. I never run the same con twice. (Chaotic)
{ .ownerDescription }



