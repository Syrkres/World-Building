---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer(Special) Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Farm 
services: services
owner: Diza (Elven)
---
> [!oRPG-Layout] 
> #  The Farm  (Farmer(Special)/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Diza (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  The Farm  owned by [[Diza]] (Elven)
*Farmer(Special) / Farmer*


**Building Description:**  An old narrow tall building, with new paint a set of double Oak wood doors, with planked siding. The roof is planked with Hickory planks.  



> ### Owner Description/Background
> ***Appearance*** : Grand strong build, with white eyes and thick brown hair. Their face has a broken nose 
>
> ***Characteristics*** :  Unable to figure out which color clothes match
>
> ***Personality*** :  Contentious
>
> ***Trait*** : The best way to get me to do something is to tell me I can't do it.
>
> ***Ideal*** : Beauty. What is beautiful points us beyond itself toward what is true. (Good)
{ .ownerDescription }



