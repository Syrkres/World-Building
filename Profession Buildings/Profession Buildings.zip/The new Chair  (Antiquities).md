---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The new Chair 
services: services
owner: Kibble (Elven)
---
> [!oRPG-Layout] 
> #  The new Chair  (Antiquities/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kibble (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Below Average |

##  The new Chair  owned by [[Kibble]] (Elven)
*Antiquities / Offical*


**Building Description:**  An old one story building, with planked siding with a front window that has a painted sign hanging above with the merchants name. The roof is thatching made of straw. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Grand average build, with red eyes and thinning white hair. Their face is squinty 
>
> ***Characteristics*** :  Distinctive jewelry
>
> ***Personality*** :  Sympathetic
>
> ***Trait*** : The leader of my community has something wise to say on every topic, and I am eager to share that wisdom.
>
> ***Ideal*** : Might. If I become strong, I can take what I want--what I deserve. (Evil)
{ .ownerDescription }



