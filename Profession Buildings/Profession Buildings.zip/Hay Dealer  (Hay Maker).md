---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hay Maker 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Hay Dealer 
services: services
owner: Crawdad (Half-Elf)
---
> [!oRPG-Layout] 
> #  Hay Dealer  (Hay Maker/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Crawdad (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  Hay Dealer  owned by [[Crawdad]] (Half-Elf)
*Hay Maker / *


**Building Description:**  An new one story building, with new paint stairs leading up to a set of double Hickory wood doors with a Beech frame, with shingled siding with a missing window. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Extra short lean build, with green eyes and frazzled red hair. Their face has a broken nose 
>
> ***Characteristics*** :  Warts
>
> ***Personality*** :  Idealistic
>
> ***Trait*** : I can find common ground between the fiercest enemies, empathizing with them and always working toward peace.
>
> ***Ideal*** : Greed. I'm only in it for the money. (Evil)
{ .ownerDescription }



