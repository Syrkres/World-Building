---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Prince Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Lone Spire 
services: services
owner: Antose (Gnome)
---
> [!oRPG-Layout] 
> #  The Lone Spire  (Prince/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Antose (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Above Average |

##  The Lone Spire  owned by [[Antose]] (Gnome)
*Prince / Offical*


**Building Description:**  An old building, with faded paint stairs leading up to a set of double Yellow Birch wood with Iron bands doors, with brick siding with a front shuttered window that has a painted sign hanging above with the merchants name. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Tall strong build, with green eyes and messy red hair. Their face has large scar 
>
> ***Characteristics*** :  Easily confused
>
> ***Personality*** :  Treacherous
>
> ***Trait*** : I don't part with my money easily and will haggle tirelessly to get the best deal possible.
>
> ***Ideal*** : People. I'm loyal to my friends, not to any ideals, and everyone else can take a trip down the Styx for all I care. (Neutral)
{ .ownerDescription }



