---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Prince Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Antose's Keep 
services: services
owner: Antose (Halfling)
---
> [!oRPG-Layout] 
> #  Antose's Keep  (Prince/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Antose (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Low |

##  Antose's Keep  owned by [[Antose]] (Halfling)
*Prince / Offical*


**Building Description:**  An old long tall building, with faded paint with brick siding. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Squat average build, with green eyes and wavy red hair. Their face has large scar across full face 
>
> ***Characteristics*** :  Collects teeth/hair/claws of slain opponents
>
> ***Personality*** :  Contentious
>
> ***Trait*** : I always want to know how things work and what makes people tick.
>
> ***Ideal*** : Fairness. No one should get preferential treatment before the law, and no one is above the law. (Lawful)
{ .ownerDescription }



