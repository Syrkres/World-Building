---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Taverner Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Ale Tigger 
services: services
owner: Braver (Human)
---
> [!oRPG-Layout] 
> #  The Ale Tigger  (Taverner/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Braver (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Low |

##  The Ale Tigger  owned by [[Braver]] (Human)
*Taverner / Cooks*


**Building Description:**  An building, with shingled siding. The roof is thatching made of straw. A Beech barrel sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short weak build, with hazel eyes and braided red hair. Their face has nose pierced 
>
> ***Characteristics*** :  Drools
>
> ***Personality*** :  Cowardly
>
> ***Trait*** : I...speak...slowly...when talking...to idiots...which...almost...everyone...is...compared ...to me.
>
> ***Ideal*** : Power. If I can attain more power, no one will tell me what to do. (Evil)
{ .ownerDescription }



