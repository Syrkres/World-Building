---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wood Seller 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Cherry logs 
services: services
owner: Scarlett (Halfling)
---
> [!oRPG-Layout] 
> #  Cherry logs  (Wood Seller/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Scarlett (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  Cherry logs  owned by [[Scarlett]] (Halfling)
*Wood Seller / *


**Building Description:**  An building, with shingled siding. The roof is thatched. A pergola is attached to the side. A pile of Maple wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short athletic build, with brown eyes and greasy red hair. Their face has eyebrow pierced 
>
> ***Characteristics*** :  Refuses to sit in chairs
>
> ***Personality*** :  Grave
>
> ***Trait*** : I am always calm, no matter what the situation. I never raise my voice or let my emotions control me.
>
> ***Ideal*** : Charity. I steal from the wealthy so that I can help people in need. (Good)
{ .ownerDescription }



