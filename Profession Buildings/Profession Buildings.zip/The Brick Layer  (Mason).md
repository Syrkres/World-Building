---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Mason Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Brick Layer 
services: services
owner: Seaberg (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Brick Layer  (Mason/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Seaberg (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Average |

##  The Brick Layer  owned by [[Seaberg]] (Half-Orc)
*Mason / Crafter*


**Building Description:**  An building, with new paint stairs leading up to a Cherry wood door with a Pine frame with stoned siding. The roof is planked.  



> ### Owner Description/Background
> ***Appearance*** : Squat strong build, with green eyes and streaked brown hair. Their face has large scar on left cheek 
>
> ***Characteristics*** :  Hallucinates
>
> ***Personality*** :  Ornery
>
> ***Trait*** : I know a story relevant to almost every situation.
>
> ***Ideal*** : Greed. I will do whatever it takes to become wealthy. (Evil)
{ .ownerDescription }



