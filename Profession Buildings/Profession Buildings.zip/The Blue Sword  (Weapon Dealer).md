---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weapon Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Blue Sword 
services: services
owner: Oedekerk (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Blue Sword  (Weapon Dealer/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Oedekerk (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Blue Sword  owned by [[Oedekerk]] (Half-Elf)
*Weapon Dealer / *


**Building Description:**  An old building, a Steal door with a Oak frame with brick siding with a few boarded windows. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Normal frail build, with green eyes and strange hairstyle blond hair. Their face has large scar on left cheek 
>
> ***Characteristics*** :  Entomophobic (afraid of insects)
>
> ***Personality*** :  Enigmatic
>
> ***Trait*** : I know a story relevant to almost every situation.
>
> ***Ideal*** : People. I'm committed to my crewmates, not to ideals. (Neutral)
{ .ownerDescription }



