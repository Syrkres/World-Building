---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cow Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Beech Nursery 
services: services
owner: Tobius (Gnome)
---
> [!oRPG-Layout] 
> #  The Beech Nursery  (Farmer - Cow Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Tobius (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Above Average |

##  The Beech Nursery  owned by [[Tobius]] (Gnome)
*Farmer - Cow Herder / Farmer*


**Building Description:**  An old long building, a set of double Ceder wood with Copper bands doors with a Oak frame, with planked siding with a front round window that has stairs leading up to a Cherry wood with Iron bands door with a Oak frame with the merchants name. The roof is thatching made of straw. A Red Oak shed is attached to the side. A few Yellow Birch chests sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short thin build, with green eyes and messy white hair. Their face is missing teeth 
>
> ***Characteristics*** :  Unable to let a joke die
>
> ***Personality*** :  Honest
>
> ***Trait*** : I would rather make a new friend than a new enemy.
>
> ***Ideal*** : Power. If I can attain more power, no one will tell me what to do. (Evil)
{ .ownerDescription }



