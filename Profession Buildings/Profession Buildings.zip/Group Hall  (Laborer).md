---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Laborer Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Group Hall 
services: services
owner: Preece (Half-Orc)
---
> [!oRPG-Layout] 
> #  Group Hall  (Laborer/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Preece (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Average |

##  Group Hall  owned by [[Preece]] (Half-Orc)
*Laborer / Professional*


**Building Description:**  An building, stairs leading up to a Elm wood door with a Ceder frame with shingled siding. The roof is timber. A shed structure is to the side. A warn Beech chest sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Short anorexic build, with blue eyes and greasy grey hair. Their face has a broken nose 
>
> ***Characteristics*** :  Haphephobic (afraid of being touched)
>
> ***Personality*** :  Vulgar
>
> ***Trait*** : I always want to know how things work and what makes people tick.
>
> ***Ideal*** : Self-Knowledge. If you know yourself, there're nothing left to know. (Any)
{ .ownerDescription }



