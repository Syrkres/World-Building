---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armor Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Copper Ringmail Dealer 
services: services
owner: Yubi (Halfling)
---
> [!oRPG-Layout] 
> #  The Copper Ringmail Dealer  (Armor Dealer/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Yubi (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Above Average |

##  The Copper Ringmail Dealer  owned by [[Yubi]] (Halfling)
*Armor Dealer / *


**Building Description:**  A new building with a smithy structure to the side. An anvil sits in the corner of the yard with various Spear lying about. A warn Hickory barrel filled with Copper bars, with a Glass Cutter leaning against the base.  



> ### Owner Description/Background
> ***Appearance*** : Normal anorexic build, with hazel eyes and wavy red hair. Their face is missing teeth 
>
> ***Characteristics*** :  Hums
>
> ***Personality*** :  Friendly
>
> ***Trait*** : I am horribly, horribly awkward in social situations.
>
> ***Ideal*** : Destiny. Nothing and no one can steer me away from my higher calling. (Any)
{ .ownerDescription }



