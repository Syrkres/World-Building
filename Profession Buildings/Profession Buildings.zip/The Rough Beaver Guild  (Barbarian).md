---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Tavern
title:  The Rough Beaver Guild 
services: services
owner: Hannier (Halfling)
---
> [!oRPG-Layout] 
> #  The Rough Beaver Guild  (Barbarian/Guard)
> **Structure:** Tavern
> **Resides In:** 
>  **Owner:** Hannier (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Low |

##  The Rough Beaver Guild  owned by [[Hannier]] (Halfling)
*Barbarian / Guard*


**Building Description:**  An new long one story building with stoned siding with a front short broken window that has a Beech wood with Steal bands door with the merchants name. The roof is thatching made of grass. A shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short frail build, with red eyes and streaked brown hair. Their face is missing teeth 
>
> ***Characteristics*** :  Plays practical jokes
>
> ***Personality*** :  Nervous
>
> ***Trait*** : My eloquent flattery makes everyone I talk to feel like the most wonderful and important person in the world.
>
> ***Ideal*** : Creativity. I never run the same con twice. (Chaotic)
{ .ownerDescription }



