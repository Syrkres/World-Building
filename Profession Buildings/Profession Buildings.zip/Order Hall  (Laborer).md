---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Laborer Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Order Hall 
services: services
owner: Roche (Gnome)
---
> [!oRPG-Layout] 
> #  Order Hall  (Laborer/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Roche (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Average |

##  Order Hall  owned by [[Roche]] (Gnome)
*Laborer / Professional*


**Building Description:**  An building, with brick siding. The roof is thatched. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short weak build, with white eyes and messy white hair. Their face has a missing right eye 
>
> ***Characteristics*** :  Sucks teeth
>
> ***Personality*** :  Rascal
>
> ***Trait*** : I am working on a grand philosophical theory and love sharing my ideas.
>
> ***Ideal*** : Respect. People deserve to be treated with dignity and respect. (Good)
{ .ownerDescription }



