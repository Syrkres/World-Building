---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cow Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Old Bull Fields 
services: services
owner: Cainen (Gnome)
---
> [!oRPG-Layout] 
> #  The Old Bull Fields  (Farmer - Cow Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Cainen (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  The Old Bull Fields  owned by [[Cainen]] (Gnome)
*Farmer - Cow Herder / Farmer*


**Building Description:**  An narrow tall building, with faded paint stairs leading up to a Oak wood door with a Yellow Birch frame with stoned siding. The roof is thatching made of grass. A Beech pergola is attached to the side. A pile of Maple wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Short strong build, with hazel eyes and greasy blond hair. Their face is missing teeth 
>
> ***Characteristics*** :  Bruises easily
>
> ***Personality*** :  Shy
>
> ***Trait*** : I feel far more comfortable around animals than people.
>
> ***Ideal*** : Respect. People deserve to be treated with dignity and respect. (Good)
{ .ownerDescription }



