---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Oil Trader Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Oil Maker 
services: services
owner: Tamils (Human)
---
> [!oRPG-Layout] 
> #  The Oil Maker  (Oil Trader/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Tamils (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Low |

##  The Oil Maker  owned by [[Tamils]] (Human)
*Oil Trader / Offical*


**Building Description:**  An new one story building, a Ceder wood with Copper bands door with a Cherry frame with brick siding with a front round shuttered window that has a painted sign hanging above with the merchants name. The roof is shingled with Red Oak shingles. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Average strong build, with red eyes and wavy brown hair. Their face has small scar 
>
> ***Characteristics*** :  Dandruff
>
> ***Personality*** :  Merry
>
> ***Trait*** : I'm oblivious to etiquette and social expectations.
>
> ***Ideal*** : Independence. I am a free spirit--no one tells me what to do. (Chaotic)
{ .ownerDescription }



