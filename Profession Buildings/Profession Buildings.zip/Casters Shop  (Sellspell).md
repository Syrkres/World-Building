---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sellspell Holyman
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Casters Shop 
services: services
owner: Aten (Half-Orc)
---
> [!oRPG-Layout] 
> #  Casters Shop  (Sellspell/Holyman)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Aten (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  Casters Shop  owned by [[Aten]] (Half-Orc)
*Sellspell / Holyman*


**Building Description:**  An building, with new paint with shingled siding. The roof is shingled with Beech shingles. A Pine shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand strong build, with white eyes and wiry black hair. Their face is missing teeth 
>
> ***Characteristics*** :  Talks with food in mouth
>
> ***Personality*** :  Accusative
>
> ***Trait*** : When I set my mind to something, I follow through no matter what gets in my way.
>
> ***Ideal*** : Sincerity. There's no good pretending to be something I'm not. (Neutral)
{ .ownerDescription }



