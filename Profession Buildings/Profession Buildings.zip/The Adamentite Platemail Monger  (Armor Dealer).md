---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Armor Dealer 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Adamentite Platemail Monger 
services: services
owner: Remer (Halfling)
---
> [!oRPG-Layout] 
> #  The Adamentite Platemail Monger  (Armor Dealer/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Remer (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Adamentite Platemail Monger  owned by [[Remer]] (Halfling)
*Armor Dealer / *


**Building Description:**  A old one story building with a smithy attached to the side. An anvil sits in outside smithy with various Sword lying about.  



> ### Owner Description/Background
> ***Appearance*** : Average strong build, with brown eyes and strange hairstyle auburn hair. Their face has no eyebrows 
>
> ***Characteristics*** :  Refuses to sit in chairs
>
> ***Personality*** :  Conservative
>
> ***Trait*** : I'm always picking things up, absently fiddling with them, and sometimes accidentally breaking them.
>
> ***Ideal*** : Logic. Emotions must not cloud our sense of what is right and true, or our logical thinking. (Lawful)
{ .ownerDescription }



