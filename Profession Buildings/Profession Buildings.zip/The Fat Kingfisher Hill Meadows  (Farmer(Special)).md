---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer(Special) Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Fat Kingfisher Hill Meadows 
services: services
owner: Milne (Dwarf)
---
> [!oRPG-Layout] 
> #  The Fat Kingfisher Hill Meadows  (Farmer(Special)/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Milne (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Average |

##  The Fat Kingfisher Hill Meadows  owned by [[Milne]] (Dwarf)
*Farmer(Special) / Farmer*


**Building Description:**  An new tall building, a Hickory wood door with a Oak frame with stoned siding. The roof is thatching made of grass. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal fat build, with red eyes and braided brown hair. Their face has small scar on left cheek 
>
> ***Characteristics*** :  Hook for a hand
>
> ***Personality*** :  Tawdry
>
> ***Trait*** : I'm always picking things up, absently fiddling with them, and sometimes accidentally breaking them.
>
> ***Ideal*** : Responsibility. I do what I must and obey just authority. (Lawful)
{ .ownerDescription }



