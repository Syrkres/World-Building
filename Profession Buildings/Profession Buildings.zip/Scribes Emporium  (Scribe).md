---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Scribe 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Scribes Emporium 
services: services
owner: Bayona (Half-Elf)
---
> [!oRPG-Layout] 
> #  Scribes Emporium  (Scribe/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bayona (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Low |

##  Scribes Emporium  owned by [[Bayona]] (Half-Elf)
*Scribe / *


**Building Description:**  An old one story building, with new paint stairs leading up to a set of double Oak wood with Bronze bands doors, with stoned siding. The roof is thatched. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Grand wide build, with hazel eyes and short brown hair. Their face has large scar 
>
> ***Characteristics*** :  Sucks teeth
>
> ***Personality*** :  Rigid
>
> ***Trait*** : I'm used to helping out those who aren't as smart as I am, and I patiently explain anything and everything to others.
>
> ***Ideal*** : Honor. If I dishonor myself, I dishonor my whole clan. (Lawful)
{ .ownerDescription }



