---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Purse Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Light Blue Handbag 
services: services
owner: Ott (Human)
---
> [!oRPG-Layout] 
> #  The Light Blue Handbag  (Purse Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Ott (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Below Average |

##  The Light Blue Handbag  owned by [[Ott]] (Human)
*Purse Maker / Tailor*


**Building Description:**  An old two story building, stairs leading up to a Beech wood with Iron bands door with shingled siding with a few windows. The roof is thatching made of grass. A pile of Cherry wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Squat frail build, with red eyes and straight black hair. Their face has small scar 
>
> ***Characteristics*** :  Always gives vaguest possible answer
>
> ***Personality*** :  Responsible
>
> ***Trait*** : There's nothing I like more than a good mystery.
>
> ***Ideal*** : Might. The strongest are meant to rule. (Evil)
{ .ownerDescription }



