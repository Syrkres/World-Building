---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Taverner Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Beaver Mug 
services: services
owner: Diza (Human)
---
> [!oRPG-Layout] 
> #  The Beaver Mug  (Taverner/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Diza (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Above Average |

##  The Beaver Mug  owned by [[Diza]] (Human)
*Taverner / Cooks*


**Building Description:**  An building, with stoned siding. The roof is shingled with Pine shingles. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Grand wide build, with brown eyes and streaked brown hair. Their face is weather-beaten 
>
> ***Characteristics*** :  Gesticulates wildly
>
> ***Personality*** :  Fearful
>
> ***Trait*** : I watch over my friends as if they were a litter of newborn pups.
>
> ***Ideal*** : Logic. Emotions must not cloud our sense of what is right and true, or our logical thinking. (Lawful)
{ .ownerDescription }



