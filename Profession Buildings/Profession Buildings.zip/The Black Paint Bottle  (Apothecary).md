---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Apothecary 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Black Paint Bottle 
services: services
owner: Gell-mann (Halfling)
---
> [!oRPG-Layout] 
> #  The Black Paint Bottle  (Apothecary/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Gell-mann (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | High |

##  The Black Paint Bottle  owned by [[Gell-mann]] (Halfling)
*Apothecary / *


**Building Description:**  An one story building, a Steal door with a Red Oak frame with brick siding. The roof is timber made of Cherry. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Tall fat build, with green eyes and greasy blond hair. Their face has a missing left eye 
>
> ***Characteristics*** :  Drones on and on while talking
>
> ***Personality*** :  Treacherous
>
> ***Trait*** : I judge people by their actions, not their words.
>
> ***Ideal*** : Aspiration. I seek to prove my self worthy of my god's favor by matching my actions against his or her teachings. (Any)
{ .ownerDescription }



