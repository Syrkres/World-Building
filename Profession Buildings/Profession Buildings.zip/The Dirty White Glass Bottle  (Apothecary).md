---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Apothecary 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Dirty White Glass Bottle 
services: services
owner: Hannier (Elven)
---
> [!oRPG-Layout] 
> #  The Dirty White Glass Bottle  (Apothecary/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hannier (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  The Dirty White Glass Bottle  owned by [[Hannier]] (Elven)
*Apothecary / *


**Building Description:**  An new narrow building, stairs leading up to a Cherry wood door with shingled siding with a front window that has a sign hanging above with the merchants name. The roof is thatched. A Elm shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short average build, with hazel eyes and limp black hair. Their face has small scar on left cheek 
>
> ***Characteristics*** :  Loves children
>
> ***Personality*** :  Feral
>
> ***Trait*** : I like to squeeze into small places where no one else can get to me.
>
> ***Ideal*** : Free Thinking. Inquiry and curiosity are the pillars of progress. (Chaotic)
{ .ownerDescription }



