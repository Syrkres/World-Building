---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Bannana Pie 
services: services
owner: Erwann (Elven)
---
> [!oRPG-Layout] 
> #  The Bannana Pie  (Baker/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Erwann (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Bannana Pie  owned by [[Erwann]] (Elven)
*Baker / Cooks*


**Building Description:**  An two story building, with shingled siding with a missing window. The roof is planked with Pine planks.  



> ### Owner Description/Background
> ***Appearance*** : Extra short fat build, with green eyes and pony-tail blond hair. Their face has a patch over right eye 
>
> ***Characteristics*** :  Rolls eyes when bored/annoyed
>
> ***Personality*** :  Phony
>
> ***Trait*** : I use polysyllabic words to convey the impression of great erudition.
>
> ***Ideal*** : Fairness. We all do the work, so we all share in the rewards. (Lawful)
{ .ownerDescription }



