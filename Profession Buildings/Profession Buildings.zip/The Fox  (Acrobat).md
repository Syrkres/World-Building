---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Acrobat Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: House
title:  The Fox 
services: services
owner: Covell (Gnome)
---
> [!oRPG-Layout] 
> #  The Fox  (Acrobat/Entertainer)
> **Structure:** House
> **Resides In:** 
>  **Owner:** Covell (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Low |

##  The Fox  owned by [[Covell]] (Gnome)
*Acrobat / Entertainer*


**Building Description:**  An tall building with new paint and with shingled siding with a missing tall window. The roof is planked.  



> ### Owner Description/Background
> ***Appearance*** : Tall thin build, with brown eyes and wiry red hair. Their face is weather-beaten 
>
> ***Characteristics*** :  Refuses to sit in chairs
>
> ***Personality*** :  Snobbish
>
> ***Trait*** : I have a crude sense of humor.
>
> ***Ideal*** : Respect. The thing that keeps a ship together is mutual respect between captain and crew. (Good)
{ .ownerDescription }



