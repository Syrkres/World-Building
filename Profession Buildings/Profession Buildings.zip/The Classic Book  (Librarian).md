---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Librarian Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Classic Book 
services: services
owner: Bodger (Human)
---
> [!oRPG-Layout] 
> #  The Classic Book  (Librarian/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bodger (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Low |

##  The Classic Book  owned by [[Bodger]] (Human)
*Librarian / Librarian*


**Building Description:**  An old narrow two story building, stairs leading up to a Oak wood with Copper bands door with brick siding. The roof is thatching made of straw. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short lean build, with white eyes and streaked auburn hair. Their face is an missing ear 
>
> ***Characteristics*** :  Flips a coin
>
> ***Personality*** :  Rash
>
> ***Trait*** : I'm a hopeless romantic, always searching for that 'special someone'.
>
> ***Ideal*** : Nature. The natural world is more important than all the constructs of civilization. (Neutral)
{ .ownerDescription }



