---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wood Carver 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Ceder Furniture 
services: services
owner: Linka (Halfling)
---
> [!oRPG-Layout] 
> #  Ceder Furniture  (Wood Carver/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Linka (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Low |

##  Ceder Furniture  owned by [[Linka]] (Halfling)
*Wood Carver / *


**Building Description:**  An new long building, with planked siding. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Grand anorexic build, with green eyes and messy auburn hair. Their face is an missing ear 
>
> ***Characteristics*** :  Claustrophobic (afraid of small spaces)
>
> ***Personality*** :  Groveling
>
> ***Trait*** : I watch over my friends as if they were a litter of newborn pups.
>
> ***Ideal*** : Responsibility. It is my duty to respect the authority of those above me, just as those below me must respect mine. (Lawful)
{ .ownerDescription }



