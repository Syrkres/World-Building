---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Apothecary 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Crystal Vial 
services: services
owner: Kypri (Gnome)
---
> [!oRPG-Layout] 
> #  The Crystal Vial  (Apothecary/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kypri (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Crystal Vial  owned by [[Kypri]] (Gnome)
*Apothecary / *


**Building Description:**  An old one story building, with faded paint stairs leading up to a set of double Maple wood doors with a Red Oak frame, with planked siding. The roof is timber made of Beech. A Beech shed structure is to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall average build, with hazel eyes and very long white hair. Their face has no eyebrows 
>
> ***Characteristics*** :  Achluophobic (afraid of darkness)
>
> ***Personality*** :  Morose
>
> ***Trait*** : I'm well known for my work, and I want to make sure everyone appreciates it. I'm always taken aback when people haven't heard of me.
>
> ***Ideal*** : Friendship. Material goods come and go. Bonds of friendship last forever. (Good)
{ .ownerDescription }



