---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sellspell Holyman
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Casters Emporium 
services: services
owner: Erwann (Dwarf)
---
> [!oRPG-Layout] 
> #  Casters Emporium  (Sellspell/Holyman)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Erwann (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Below Average |

##  Casters Emporium  owned by [[Erwann]] (Dwarf)
*Sellspell / Holyman*


**Building Description:**  An old building, with new paint with shingled siding. The roof is planked with Hickory planks. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Tall weak build, with white eyes and pony-tail black hair. Their face is weather-beaten 
>
> ***Characteristics*** :  Smiles when angry/annoyed
>
> ***Personality*** :  Sensual
>
> ***Trait*** : I think anyone who's nice to me is hiding evil intent.
>
> ***Ideal*** : Retribution. The rich need to be shown what life and death are like in the gutters. (Evil)
{ .ownerDescription }



