---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Merc Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Guild Hall 
services: services
owner: Najor (Dwarf)
---
> [!oRPG-Layout] 
> #  Guild Hall  (Merc/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Najor (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Below Average |

##  Guild Hall  owned by [[Najor]] (Dwarf)
*Merc / Guard*


**Building Description:**  An two story building, with new paint with brick siding with a few shuttered windows. The roof is planked. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal weak build, with brown eyes and wavy red hair. Their face has sideburns 
>
> ***Characteristics*** :  Altophobic (afraid of heights)
>
> ***Personality*** :  Aloof
>
> ***Trait*** : My language is as foul as an otyugh nest.
>
> ***Ideal*** : People. I help people who help me--that's what keeps us alive. (Neutral)
{ .ownerDescription }



