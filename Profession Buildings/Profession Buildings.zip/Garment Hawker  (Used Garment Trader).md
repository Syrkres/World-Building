---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Used Garment Trader Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Garment Hawker 
services: services
owner: Lottings (Human)
---
> [!oRPG-Layout] 
> #  Garment Hawker  (Used Garment Trader/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Lottings (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Average |

##  Garment Hawker  owned by [[Lottings]] (Human)
*Used Garment Trader / Tailor*


**Building Description:**  An old one story building, with faded paint with brick siding. The roof is planked.  



> ### Owner Description/Background
> ***Appearance*** : Short thin build, with brown eyes and streaked black hair. Their face has a broken nose 
>
> ***Characteristics*** :  Plays with hair
>
> ***Personality*** :  Gloomy
>
> ***Trait*** : I've read every book in the world's greatest libraries--or like to boast that I have.
>
> ***Ideal*** : People. I'm committed to the people I care about, not to ideals. (Neutral)
{ .ownerDescription }



