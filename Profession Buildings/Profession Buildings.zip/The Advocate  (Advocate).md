---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Advocate Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Advocate 
services: services
owner: Kran (Elven)
---
> [!oRPG-Layout] 
> #  The Advocate  (Advocate/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kran (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Below Average |

##  The Advocate  owned by [[Kran]] (Elven)
*Advocate / Professional*


**Building Description:**  An old building, with new paint with brick siding. The roof is timber.  



> ### Owner Description/Background
> ***Appearance*** : Squat athletic build, with white eyes and pony-tail brown hair. Their face has stained teeth 
>
> ***Characteristics*** :  Grins evilly
>
> ***Personality*** :  Energetic
>
> ***Trait*** : To me, a tavern brawl is a nice way to get to know a new city.
>
> ***Ideal*** : Tradition. The stories, legends, and songs of the past must never be forgotten. (Lawful)
{ .ownerDescription }



