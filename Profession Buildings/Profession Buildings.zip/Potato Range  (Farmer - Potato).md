---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Potato Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Potato Range 
services: services
owner: Manley (Halfling)
---
> [!oRPG-Layout] 
> #  Potato Range  (Farmer - Potato/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Manley (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  Potato Range  owned by [[Manley]] (Halfling)
*Farmer - Potato / Farmer*


**Building Description:**  An new building, with faded paint with planked siding. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Squat frail build, with brown eyes and bald auburn hair. Their face is missing teeth 
>
> ***Characteristics*** :  Unable to remember names
>
> ***Personality*** :  Annoying
>
> ***Trait*** : I'm oblivious to etiquette and social expectations.
>
> ***Ideal*** : Creativity. The world is in need of new ideas and bold action. (Chaotic)
{ .ownerDescription }



