---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Soap Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Soap Hawker 
services: services
owner: Logspitter (Half-Orc)
---
> [!oRPG-Layout] 
> #  Soap Hawker  (Soap Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Logspitter (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  Soap Hawker  owned by [[Logspitter]] (Half-Orc)
*Soap Maker / Crafter*


**Building Description:**  An long building, with brick siding. The roof is thatching made of grass. A shed structure is to the side. A warn Hickory crate sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short wide build, with white eyes and braided red hair. Their face has no eyebrows 
>
> ***Characteristics*** :  Entomophobic (afraid of insects)
>
> ***Personality*** :  Shallow
>
> ***Trait*** : I am utterly serene, even in the face of disaster.
>
> ***Ideal*** : Noble Obligation. It is my duty to protect and care for the people beneath me. (Good)
{ .ownerDescription }



