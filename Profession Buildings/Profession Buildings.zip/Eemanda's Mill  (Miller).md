---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Miller Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Eemanda's Mill 
services: services
owner: Eemanda (Elven)
---
> [!oRPG-Layout] 
> #  Eemanda's Mill  (Miller/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Eemanda (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  Eemanda's Mill  owned by [[Eemanda]] (Elven)
*Miller / Cooks*


**Building Description:**  An one story building, with faded paint with brick siding with a few short boarded windows. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Tall frail build, with red eyes and frazzled grey hair. Their face is doe-eyed 
>
> ***Characteristics*** :  Chews tobacco
>
> ***Personality*** :  Pessimistic
>
> ***Trait*** : My language is as foul as an otyugh nest.
>
> ***Ideal*** : Faith. I trust that my deity will guide my actions. I have faith that if I work hard, things will go well. (Lawful)
{ .ownerDescription }



