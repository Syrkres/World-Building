---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tutor Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Teachers Group 
services: services
owner: Ligget (Gnome)
---
> [!oRPG-Layout] 
> #  Teachers Group  (Tutor/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Ligget (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  Teachers Group  owned by [[Ligget]] (Gnome)
*Tutor / Librarian*


**Building Description:**  An building, stairs leading up to a Bronze door with stoned siding. The roof is thatching made of grass. A Yellow Birch pergola is attached to the side. A few new Maple chests sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short frail build, with red eyes and wavy grey hair. Their face has large scar across full face 
>
> ***Characteristics*** :  Double-checks everything
>
> ***Personality*** :  Philanderer
>
> ***Trait*** : I don't like to bathe.
>
> ***Ideal*** : Might. The strongest are meant to rule. (Evil)
{ .ownerDescription }



