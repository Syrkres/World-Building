---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Duke Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Omar's Villa 
services: services
owner: Omar (Halfling)
---
> [!oRPG-Layout] 
> #  Omar's Villa  (Duke/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Omar (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Average |

##  Omar's Villa  owned by [[Omar]] (Halfling)
*Duke / Offical*


**Building Description:**  An building, stairs leading up to a set of double Elm wood with Bronze bands doors with a Hickory frame, with shingled siding. The roof is planked. A shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short frail build, with green eyes and long black hair. Their face has lip pierced 
>
> ***Characteristics*** :  Unable to figure out which color clothes match
>
> ***Personality*** :  Distraught
>
> ***Trait*** : I connect everything that happens to me to a grand cosmic plan.
>
> ***Ideal*** : Respect. Respect is due to me because of my position, but all people regardless of station deserve to be treated with dignity. (Good)
{ .ownerDescription }



