---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Earl Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Hurlie's Villa 
services: services
owner: Hurlie (Halfling)
---
> [!oRPG-Layout] 
> #  Hurlie's Villa  (Earl/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hurlie (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  Hurlie's Villa  owned by [[Hurlie]] (Halfling)
*Earl / Offical*


**Building Description:**  An new building, with faded paint a Beech wood with Steal bands door with brick siding. The roof is planked with Yellow Birch planks. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Tall strong build, with brown eyes and greasy red hair. Their face has large scar 
>
> ***Characteristics*** :  Plays with hair
>
> ***Personality*** :  Needy
>
> ***Trait*** : I'm a born gambler who can't resist taking a risk for a potential payoff.
>
> ***Ideal*** : Self-Knowledge. If you know yourself, there're nothing left to know. (Any)
{ .ownerDescription }



