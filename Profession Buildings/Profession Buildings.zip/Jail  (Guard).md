---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Guard Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Jail 
services: services
owner: Hidalgo (Human)
---
> [!oRPG-Layout] 
> #  Jail  (Guard/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hidalgo (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | High |

##  Jail  owned by [[Hidalgo]] (Human)
*Guard / Guard*


**Building Description:**  An narrow tall building, with shingled siding with a few short windows. The roof is timber made of Hickory.  



> ### Owner Description/Background
> ***Appearance*** : Extra short lean build, with white eyes and pony-tail white hair. Their face has a bushy eyebrows 
>
> ***Characteristics*** :  Ophidiophobic (afraid of snakes)
>
> ***Personality*** :  Irreligious
>
> ***Trait*** : I face problems head-on. A simple direct solution is the best path to success.
>
> ***Ideal*** : Respect. All people, rich or poor, deserve respect. (Good)
{ .ownerDescription }



