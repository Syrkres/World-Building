---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crook Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Pawn Reseller 
services: services
owner: Nabil (Half-Elf)
---
> [!oRPG-Layout] 
> #  Pawn Reseller  (Crook/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Nabil (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Below Average |

##  Pawn Reseller  owned by [[Nabil]] (Half-Elf)
*Crook / Guard*


**Building Description:**  An building, with faded paint stairs leading up to a set of double Copper doors with a Oak frame, with shingled siding with a missing window. The roof is thatching made of grass. A Red Oak shed is attached to the side. A few new Maple chests sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Squat weak build, with green eyes and pony-tail black hair. Their face has lip pierced 
>
> ***Characteristics*** :  Talks to self
>
> ***Personality*** :  Enigmatic
>
> ***Trait*** : I quote the sacred texts and proverbs in almost every situation.
>
> ***Ideal*** : Glory. I must earn glory in battle, for myself and my clan. (Any)
{ .ownerDescription }



