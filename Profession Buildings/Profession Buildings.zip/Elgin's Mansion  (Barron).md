---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barron Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Townhall
title:  Elgin's Mansion 
services: services
owner: Elgin (Elven)
---
> [!oRPG-Layout] 
> #  Elgin's Mansion  (Barron/Offical)
> **Structure:** Townhall
> **Resides In:** 
>  **Owner:** Elgin (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Average |

##  Elgin's Mansion  owned by [[Elgin]] (Elven)
*Barron / Offical*


**Building Description:**  An old tall building with new paint and with shingled siding with a few windows. The roof is shingled with Beech shingles. A shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall lean build, with white eyes and dreadlocks grey hair. Their face is gap-toothed 
>
> ***Characteristics*** :  Taps fingers
>
> ***Personality*** :  Childish
>
> ***Trait*** : I enjoy being strong and like breaking things.
>
> ***Ideal*** : Free Thinking. Inquiry and curiosity are the pillars of progress. (Chaotic)
{ .ownerDescription }



