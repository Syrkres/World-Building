---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sellspell Holyman
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Casters Store 
services: services
owner: Pauling (Half-Elf)
---
> [!oRPG-Layout] 
> #  Casters Store  (Sellspell/Holyman)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Pauling (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Low |

##  Casters Store  owned by [[Pauling]] (Half-Elf)
*Sellspell / Holyman*


**Building Description:**  An building, with new paint with planked siding with a front short boarded window that has a sign hanging above with the merchants name. The roof is thatching made of grass. A warn Beech chest sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Tall athletic build, with green eyes and curly grey hair. Their face has a bushy eyebrows 
>
> ***Characteristics*** :  Leers
>
> ***Personality*** :  Discreet
>
> ***Trait*** : My favor, once lost, is lost forever.
>
> ***Ideal*** : Fairness. No one should get preferential treatment before the law, and no one is above the law. (Lawful)
{ .ownerDescription }



