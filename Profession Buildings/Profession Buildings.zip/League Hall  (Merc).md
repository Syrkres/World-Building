---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Merc Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  League Hall 
services: services
owner: Charden (Human)
---
> [!oRPG-Layout] 
> #  League Hall  (Merc/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Charden (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  League Hall  owned by [[Charden]] (Human)
*Merc / Guard*


**Building Description:**  An one story building, with stoned siding. The roof is timber. A Red Oak chest sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short strong build, with white eyes and straight brown hair. Their face has large scar across full face 
>
> ***Characteristics*** :  Stares
>
> ***Personality*** :  Restless
>
> ***Trait*** : I lie about almost everything, even when there's no good reason to.
>
> ***Ideal*** : People. I'm committed to my crewmates, not to ideals. (Neutral)
{ .ownerDescription }



