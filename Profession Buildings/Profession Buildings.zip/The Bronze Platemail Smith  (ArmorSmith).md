---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: ArmorSmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Bronze Platemail Smith 
services: services
owner: Cynewulf (Gnome)
---
> [!oRPG-Layout] 
> #  The Bronze Platemail Smith  (ArmorSmith/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Cynewulf (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Bronze Platemail Smith  owned by [[Cynewulf]] (Gnome)
*ArmorSmith / *


**Building Description:**  A building with a smithy structure to the side. An rusted anvil sits in outside yard with various Sword lying about. A saw horse with hay strewn about, a sledge hammer leaning on the edge.  



> ### Owner Description/Background
> ***Appearance*** : Normal weak build, with red eyes and limp grey hair. Their face has lip pierced 
>
> ***Characteristics*** :  Bad with money
>
> ***Personality*** :  Puerile
>
> ***Trait*** : I hide scraps of food and trinkets away in my pockets.
>
> ***Ideal*** : Might. In life as in war, the stronger force wins. (Evil)
{ .ownerDescription }



