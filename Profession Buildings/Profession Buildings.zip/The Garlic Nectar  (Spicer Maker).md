---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Spicer Maker Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Garlic Nectar 
services: services
owner: Carnevale (Elven)
---
> [!oRPG-Layout] 
> #  The Garlic Nectar  (Spicer Maker/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Carnevale (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Garlic Nectar  owned by [[Carnevale]] (Elven)
*Spicer Maker / Cooks*


**Building Description:**  An old building, with new paint stairs leading up to a set of double Oak wood with Bronze bands doors, with stoned siding. The roof is timber. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short strong build, with white eyes and wavy blond hair. Their face has a goatee 
>
> ***Characteristics*** :  Finishes others' sentences
>
> ***Personality*** :  Merciless
>
> ***Trait*** : I'm confident in my own abilities and do what I can to instill confidence in others.
>
> ***Ideal*** : Tradition. The stories, legends, and songs of the past must never be forgotten. (Lawful)
{ .ownerDescription }



