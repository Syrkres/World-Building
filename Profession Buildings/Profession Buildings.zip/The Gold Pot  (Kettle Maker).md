---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Kettle Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Gold Pot 
services: services
owner: Zonn (Elven)
---
> [!oRPG-Layout] 
> #  The Gold Pot  (Kettle Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Zonn (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  The Gold Pot  owned by [[Zonn]] (Elven)
*Kettle Maker / Crafter*


**Building Description:**  An new narrow tall building, a Cherry wood with Iron bands door with planked siding. The roof is thatching made of grass. A Beech shed is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Normal strong build, with green eyes and thick brown hair. Their face is pierced 
>
> ***Characteristics*** :  Sucks teeth
>
> ***Personality*** :  Promiscuous
>
> ***Trait*** : I'm always polite and respectful.
>
> ***Ideal*** : Generosity. My talents were given to me so that I could use them to benefit the world. (Good)
{ .ownerDescription }



