---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tracker 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  old Cottage 
services: services
owner: Bayona (Gnome)
---
> [!oRPG-Layout] 
> #  old Cottage  (Tracker/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Bayona (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Low |

##  old Cottage  owned by [[Bayona]] (Gnome)
*Tracker / *


**Building Description:**  An two story building, with new paint a set of double Red Oak wood with Copper bands doors, with brick siding with a few short boarded windows. The roof is thatching made of straw. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal fat build, with brown eyes and thick grey hair. Their face is weather-beaten 
>
> ***Characteristics*** :  Hallucinates
>
> ***Personality*** :  Contentious
>
> ***Trait*** : There's nothing I like more than a good mystery.
>
> ***Ideal*** : Freedom. Tyrants must not be allowed to oppress the people. (Chaotic)
{ .ownerDescription }



