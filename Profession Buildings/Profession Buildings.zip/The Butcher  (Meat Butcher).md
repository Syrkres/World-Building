---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Meat Butcher Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Butcher 
services: services
owner: Albaara (Elven)
---
> [!oRPG-Layout] 
> #  The Butcher  (Meat Butcher/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Albaara (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Above Average |

##  The Butcher  owned by [[Albaara]] (Elven)
*Meat Butcher / Cooks*


**Building Description:**  An new two story building, with planked siding. The roof is thatching made of grass. A few Ceder barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short average build, with brown eyes and bald blond hair. Their face is gap-toothed 
>
> ***Characteristics*** :  Stares
>
> ***Personality*** :  Optimistic
>
> ***Trait*** : I ask a lot of questions.
>
> ***Ideal*** : Community. We have to take care of each other, because no one else is going to do it. (Lawful)
{ .ownerDescription }



