---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: WeaponSmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Smith
title:  The Light Green Mace 
services: services
owner: Wilkney (Dwarf)
---
> [!oRPG-Layout] 
> #  The Light Green Mace  (WeaponSmith/)
> **Structure:** Smith
> **Resides In:** 
>  **Owner:** Wilkney (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Average |

##  The Light Green Mace  owned by [[Wilkney]] (Dwarf)
*WeaponSmith / *


**Building Description:**  A new long one story building with a smithy attached to the side. An rusted anvil sits in outside yard a large smith hammer lying across the top with various Flail scattered about. A Falchion : with a pommel that has a with 2 Chalcedony in a Heart Shape cut for eyes tip made of Steal, and the grip is made of cotton with a hilt made of Copper, a wiggly blade is made of Beech wood and embossed with glyphs is displayed on a table. A warn Yellow Birch chest filled with Bronze shavings.  



> ### Owner Description/Background
> ***Appearance*** : Normal lean build, with green eyes and limp grey hair. Their face has a missing left eye 
>
> ***Characteristics*** :  Talks to self
>
> ***Personality*** :  Narrow-minded
>
> ***Trait*** : My language is as foul as an otyugh nest.
>
> ***Ideal*** : Respect. The thing that keeps a ship together is mutual respect between captain and crew. (Good)
{ .ownerDescription }



