---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Rug Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Carpet Monger 
services: services
owner: Braggs (Half-Orc)
---
> [!oRPG-Layout] 
> #  Carpet Monger  (Rug Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Braggs (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | Below Average |

##  Carpet Monger  owned by [[Braggs]] (Half-Orc)
*Rug Maker / Crafter*


**Building Description:**  An old long one story building, with new paint with brick siding with a front tall window that has a Maple wood door with the merchants name. The roof is timber. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Short athletic build, with green eyes and streaked grey hair. Their face has small scar 
>
> ***Characteristics*** :  Enjoys own body odor
>
> ***Personality*** :  Dominating
>
> ***Trait*** : I enjoy being strong and like breaking things.
>
> ***Ideal*** : Creativity. The world is in need of new ideas and bold action. (Chaotic)
{ .ownerDescription }



