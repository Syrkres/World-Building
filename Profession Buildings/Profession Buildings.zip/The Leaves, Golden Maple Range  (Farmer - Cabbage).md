---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cabbage Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Leaves, Golden Maple Range 
services: services
owner: Mombril (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Leaves, Golden Maple Range  (Farmer - Cabbage/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Mombril (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  The Leaves, Golden Maple Range  owned by [[Mombril]] (Half-Elf)
*Farmer - Cabbage / Farmer*


**Building Description:**  An narrow building, with new paint with brick siding. The roof is thatching made of straw. A pile of Yellow Birch wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal athletic build, with green eyes and very long brown hair. Their face has a bushy eyebrows 
>
> ***Characteristics*** :  Hiccoughs
>
> ***Personality*** :  Chivalrous
>
> ***Trait*** : I'll settle for nothing less than perfection.
>
> ***Ideal*** : No Limits. Nothing should fetter the infinite possibility inherent in all existence. (Chaotic)
{ .ownerDescription }



