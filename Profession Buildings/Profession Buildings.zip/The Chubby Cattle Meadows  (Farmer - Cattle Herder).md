---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Chubby Cattle Meadows 
services: services
owner: Maestre (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Chubby Cattle Meadows  (Farmer - Cattle Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Maestre (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Low |

##  The Chubby Cattle Meadows  owned by [[Maestre]] (Half-Orc)
*Farmer - Cattle Herder / Farmer*


**Building Description:**  An old one story building, a set of double Steal doors, with stoned siding. The roof is planked.  



> ### Owner Description/Background
> ***Appearance*** : Extra short frail build, with white eyes and streaked grey hair. Their face has a patch over eye 
>
> ***Characteristics*** :  Insomniac
>
> ***Personality*** :  Obstinate
>
> ***Trait*** : I work hard so that I can play hard when the work is done.
>
> ***Ideal*** : Family. Blood runs thicker than water. (Any)
{ .ownerDescription }



