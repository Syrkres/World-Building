---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Horse Trader 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Horse Maker 
services: services
owner: Kutner (Half-Orc)
---
> [!oRPG-Layout] 
> #  Horse Maker  (Horse Trader/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kutner (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  Horse Maker  owned by [[Kutner]] (Half-Orc)
*Horse Trader / *


**Building Description:**  An new narrow building, with shingled siding with a front window that has a sign hanging above with the merchants name. The roof is thatched. A Beech shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short thin build, with green eyes and greasy white hair. Their face is grizzled 
>
> ***Characteristics*** :  Laughs at own jokes
>
> ***Personality*** :  Peaceful
>
> ***Trait*** : I hide scraps of food and trinkets away in my pockets.
>
> ***Ideal*** : Freedom. Chains are meant to be broken, as are those who would forge them. (Chaotic)
{ .ownerDescription }



