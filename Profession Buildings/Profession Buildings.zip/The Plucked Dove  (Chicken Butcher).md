---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chicken Butcher Cooks
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Plucked Dove 
services: services
owner: Ham (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Plucked Dove  (Chicken Butcher/Cooks)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Ham (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  The Plucked Dove  owned by [[Ham]] (Half-Elf)
*Chicken Butcher / Cooks*


**Building Description:**  An long two story building, stairs leading up to a Pine wood with Bronze bands door with a Yellow Birch frame with stoned siding with a missing window. The roof is thatching made of straw. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Tall average build, with blue eyes and very long black hair. Their face has small scar 
>
> ***Characteristics*** :  Bad/loud/annoying/shrill laugh
>
> ***Personality*** :  Daring
>
> ***Trait*** : I like a job well done, especially if I can convince someone else to do it.
>
> ***Ideal*** : Change. Life is like the seasons, in constant change, and we must change with it. (Chaotic)
{ .ownerDescription }



