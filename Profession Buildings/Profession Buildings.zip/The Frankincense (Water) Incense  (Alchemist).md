---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Alchemist Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Frankincense (Water) Incense 
services: services
owner: Virzi (Human)
---
> [!oRPG-Layout] 
> #  The Frankincense (Water) Incense  (Alchemist/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Virzi (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Low |

##  The Frankincense (Water) Incense  owned by [[Virzi]] (Human)
*Alchemist / Librarian*


**Building Description:**  An old two story building, with planked siding. The roof is planked. A Hickory shed structure is to the side. A pile of Ceder wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Normal fat build, with blue eyes and short brown hair. Their face has stained teeth 
>
> ***Characteristics*** :  Stares
>
> ***Personality*** :  Repellent
>
> ***Trait*** : I've read every book in the world's greatest libraries--or like to boast that I have.
>
> ***Ideal*** : Independence. I must prove that I can handle myself without the coddling of my family. (Chaotic)
{ .ownerDescription }



