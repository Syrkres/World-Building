---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Fine old Amulet 
services: services
owner: Gullstrand (Gnome)
---
> [!oRPG-Layout] 
> #  The Fine old Amulet  (Antiquities/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Gullstrand (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Low |

##  The Fine old Amulet  owned by [[Gullstrand]] (Gnome)
*Antiquities / Offical*


**Building Description:**  An tall building, a Pine wood door with a Yellow Birch frame with planked siding. The roof is timber made of Oak. A Maple shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short thin build, with brown eyes and strange hairstyle white hair. Their face is pierced 
>
> ***Characteristics*** :  Picks scabs
>
> ***Personality*** :  Apprehensive
>
> ***Trait*** : I was, in fact, raised by wolves.
>
> ***Ideal*** : Freedom. Everyone should be free to pursue his or her livelihood. (Chaotic)
{ .ownerDescription }



