---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Corn Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Old Elm Range 
services: services
owner: Yubi (Dwarf)
---
> [!oRPG-Layout] 
> #  The Old Elm Range  (Farmer - Corn/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Yubi (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Average |

##  The Old Elm Range  owned by [[Yubi]] (Dwarf)
*Farmer - Corn / Farmer*


**Building Description:**  An old building, stairs leading up to a Ceder wood with Copper bands door with a Oak frame with stoned siding with a front short window that has stairs leading up to a Bronze door with the merchants name. The roof is thatched.  



> ### Owner Description/Background
> ***Appearance*** : Squat weak build, with blue eyes and greasy auburn hair. Their face has a distinctive nose 
>
> ***Characteristics*** :  Hydrophobic (afraid of water)
>
> ***Personality*** :  Industrious
>
> ***Trait*** : I keep multiple holy symbols on me and invoke whatever deity might come in useful at any given moment.
>
> ***Ideal*** : Respect. Respect is due to me because of my position, but all people regardless of station deserve to be treated with dignity. (Good)
{ .ownerDescription }



