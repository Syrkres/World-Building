---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Pig Herder Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Portly Swine Range 
services: services
owner: Estrum (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Portly Swine Range  (Farmer - Pig Herder/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Estrum (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Portly Swine Range  owned by [[Estrum]] (Half-Orc)
*Farmer - Pig Herder / Farmer*


**Building Description:**  An building, stairs leading up to a set of double Steal doors, with brick siding with a front broken window that has a Red Oak wood door with the merchants name. The roof is thatching made of grass. A Oak shed is attached to the side. A few Elm barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Grand weak build, with brown eyes and curly auburn hair. Their face is chiseled 
>
> ***Characteristics*** :  Ophidiophobic (afraid of snakes)
>
> ***Personality*** :  Hostile
>
> ***Trait*** : I'm willing to listen to every side of an argument before I make my own judgment.
>
> ***Ideal*** : Greater Good. My gifts are meant to be shared with all, not used for my own benefit. (Good)
{ .ownerDescription }



