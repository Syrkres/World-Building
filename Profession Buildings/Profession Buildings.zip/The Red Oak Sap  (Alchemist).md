---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Alchemist Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Red Oak Sap 
services: services
owner: Arbuckle (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Red Oak Sap  (Alchemist/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Arbuckle (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Below Average |

##  The Red Oak Sap  owned by [[Arbuckle]] (Half-Orc)
*Alchemist / Librarian*


**Building Description:**  An building, with new paint with shingled siding with a missing short window. The roof is shingled with Hickory shingles. A warn Yellow Birch chest sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall frail build, with brown eyes and very long red hair. Their face is missing teeth 
>
> ***Characteristics*** :  Scarred on Right leg
>
> ***Personality*** :  Proselytizing
>
> ***Trait*** : I'm a born gambler who can't resist taking a risk for a potential payoff.
>
> ***Ideal*** : Self-improvement. The goal of a life of study is the betterment of oneself.
{ .ownerDescription }



