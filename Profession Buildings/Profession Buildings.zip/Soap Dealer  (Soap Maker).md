---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Soap Maker Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Soap Dealer 
services: services
owner: Jeruss (Elven)
---
> [!oRPG-Layout] 
> #  Soap Dealer  (Soap Maker/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Jeruss (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Low |

##  Soap Dealer  owned by [[Jeruss]] (Elven)
*Soap Maker / Crafter*


**Building Description:**  An narrow building, with shingled siding with a front short window that has a Copper door with the merchants name. The roof is thatching made of grass. A Yellow Birch shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Squat athletic build, with hazel eyes and greasy blond hair. Their face is gap-toothed 
>
> ***Characteristics*** :  Hydrophobic (afraid of water)
>
> ***Personality*** :  Defensive
>
> ***Trait*** : I'm a born gambler who can't resist taking a risk for a potential payoff.
>
> ***Ideal*** : Might. The strongest are meant to rule. (Evil)
{ .ownerDescription }



