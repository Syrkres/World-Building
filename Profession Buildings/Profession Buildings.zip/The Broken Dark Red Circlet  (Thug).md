---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thug Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Broken Dark Red Circlet 
services: services
owner: Pereira (Human)
---
> [!oRPG-Layout] 
> #  The Broken Dark Red Circlet  (Thug/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Pereira (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  The Broken Dark Red Circlet  owned by [[Pereira]] (Human)
*Thug / Guard*


**Building Description:**  An tall building, with faded paint with stoned siding. The roof is planked. A Red Oak shed structure is to the side. A warn Oak chest sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Tall lean build, with green eyes and streaked white hair. Their face has lip pierced 
>
> ***Characteristics*** :  Prefers to be called by last name
>
> ***Personality*** :  Spendthrift
>
> ***Trait*** : I never pass up a friendly wager.
>
> ***Ideal*** : Aspiration. Someday I'll own my own ship and chart my own destiny. (Any)
{ .ownerDescription }



