---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Prince Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Lone Tower 
services: services
owner: Saeta (Dwarf)
---
> [!oRPG-Layout] 
> #  The Lone Tower  (Prince/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Saeta (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Lone Tower  owned by [[Saeta]] (Dwarf)
*Prince / Offical*


**Building Description:**  An new one story building, a set of double Red Oak wood with Steal bands doors with a Yellow Birch frame, with shingled siding. The roof is thatching made of grass. A Cherry shed structure is to the side.  



> ### Owner Description/Background
> ***Appearance*** : Average thin build, with white eyes and frazzled auburn hair. Their face has small scar on right cheek 
>
> ***Characteristics*** :  Dandruff
>
> ***Personality*** :  Pertinacious
>
> ***Trait*** : I'm a hopeless romantic, always searching for that 'special someone'.
>
> ***Ideal*** : Free Thinking. Inquiry and curiosity are the pillars of progress. (Chaotic)
{ .ownerDescription }



