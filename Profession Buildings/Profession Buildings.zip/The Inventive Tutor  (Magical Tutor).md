---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Magical Tutor Librarian
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Inventive Tutor 
services: services
owner: Sharan (Halfling)
---
> [!oRPG-Layout] 
> #  The Inventive Tutor  (Magical Tutor/Librarian)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Sharan (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | High |

##  The Inventive Tutor  owned by [[Sharan]] (Halfling)
*Magical Tutor / Librarian*


**Building Description:**  An one story building, a Copper door with planked siding. The roof is timber. A few Maple chests sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short lean build, with white eyes and frazzled red hair. Their face is gap-toothed 
>
> ***Characteristics*** :  Wears flamboyant or outlandish clothes
>
> ***Personality*** :  Animated
>
> ***Trait*** : I don't part with my money easily and will haggle tirelessly to get the best deal possible.
>
> ***Ideal*** : Knowledge. The path to power and self-improvement is through knowledge. (Neutral)
{ .ownerDescription }



