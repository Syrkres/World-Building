---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sculptor Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title: 
services: services
owner: Kutner (Half-Elf)
---
> [!oRPG-Layout] 
> #  (Sculptor/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kutner (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  owned by [[Kutner]] (Half-Elf)
*Sculptor / Crafter*


**Building Description:**  An building, with shingled siding with a missing window. The roof is timber made of Oak. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall wide build, with blue eyes and braided red hair. Their face is weather-beaten 
>
> ***Characteristics*** :  Scarred on Right leg on Left leg on Left arm on Head/Face on Right leg on Left arm on Stomach on Waist on Back on Head/Face on Back
>
> ***Personality*** :  Sardonic
>
> ***Trait*** : When I set my mind to something, I follow through no matter what gets in my way.
>
> ***Ideal*** : Might. The strongest are meant to rule. (Evil)
{ .ownerDescription }



