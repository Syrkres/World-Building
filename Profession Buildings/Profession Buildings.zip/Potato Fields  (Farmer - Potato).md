---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Potato Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Potato Fields 
services: services
owner: Buell (Gnome)
---
> [!oRPG-Layout] 
> #  Potato Fields  (Farmer - Potato/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Buell (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  Potato Fields  owned by [[Buell]] (Gnome)
*Farmer - Potato / Farmer*


**Building Description:**  An tall building, with faded paint with brick siding with a few windows. The roof is timber. A few old Maple crates sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall weak build, with red eyes and short white hair. Their face has lip pierced 
>
> ***Characteristics*** :  Picks at teeth
>
> ***Personality*** :  Angry
>
> ***Trait*** : Thinking is for other people. I prefer action.
>
> ***Ideal*** : Aspiration. Someday I'll own my own ship and chart my own destiny. (Any)
{ .ownerDescription }



