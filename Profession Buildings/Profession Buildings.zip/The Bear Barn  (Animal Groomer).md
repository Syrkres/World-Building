---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Stables
title:  The Bear Barn 
services: services
owner: Cetrone (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Bear Barn  (Animal Groomer/Entertainer)
> **Structure:** Stables
> **Resides In:** 
>  **Owner:** Cetrone (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Low |

##  The Bear Barn  owned by [[Cetrone]] (Half-Elf)
*Animal Groomer / Entertainer*


**Building Description:**  An two story building with new paint and with shingled siding with a front shuttered window that has a sign hanging above with the merchants name. The roof is planked with Beech planks.  



> ### Owner Description/Background
> ***Appearance*** : Extra short athletic build, with blue eyes and braided grey hair. Their face is pock-marked 
>
> ***Characteristics*** :  Always arrives late
>
> ***Personality*** :  Idealistic
>
> ***Trait*** : I'm convinced that people are always trying to steal my secrets.
>
> ***Ideal*** : Tradition. The stories, legends, and songs of the past must never be forgotten. (Lawful)
{ .ownerDescription }



