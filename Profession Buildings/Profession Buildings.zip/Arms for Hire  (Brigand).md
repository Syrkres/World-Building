---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand Guard
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Arms for Hire 
services: services
owner: Rhyklin (Halfling)
---
> [!oRPG-Layout] 
> #  Arms for Hire  (Brigand/Guard)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Rhyklin (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Below Average |

##  Arms for Hire  owned by [[Rhyklin]] (Halfling)
*Brigand / Guard*


**Building Description:**  An long tall building, with new paint with planked siding. The roof is timber made of Oak. A Beech shed is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall average build, with hazel eyes and thick red hair. Their face has a patch over right eye 
>
> ***Characteristics*** :  Sun-burned
>
> ***Personality*** :  Joking
>
> ***Trait*** : I love a good insult, even one directed at me.
>
> ***Ideal*** : Change. Life is like the seasons, in constant change, and we must change with it. (Chaotic)
{ .ownerDescription }



