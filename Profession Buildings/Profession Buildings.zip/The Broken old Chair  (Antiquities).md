---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Broken old Chair 
services: services
owner: Dihn (Elven)
---
> [!oRPG-Layout] 
> #  The Broken old Chair  (Antiquities/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Dihn (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Low |

##  The Broken old Chair  owned by [[Dihn]] (Elven)
*Antiquities / Offical*


**Building Description:**  An new long one story building, with new paint with planked siding with a missing window. The roof is shingled. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra short strong build, with hazel eyes and braided red hair. Their face has eyebrow pierced 
>
> ***Characteristics*** :  Bleeding nose
>
> ***Personality*** :  Deluded
>
> ***Trait*** : I pocket anything I see that might have some value.
>
> ***Ideal*** : Honor. I don't steal from others in the trade. (Lawful)
{ .ownerDescription }



