---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Apothecary 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Light Green Glass Vial 
services: services
owner: Modo (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Light Green Glass Vial  (Apothecary/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Modo (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Low |

##  The Light Green Glass Vial  owned by [[Modo]] (Half-Orc)
*Apothecary / *


**Building Description:**  An old two story building, stairs leading up to a Elm wood door with planked siding with a front window that has a painted sign hanging above with the merchants name. The roof is thatched. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand frail build, with hazel eyes and straight blond hair. Their face has large scar across full face 
>
> ***Characteristics*** :  Grins evilly
>
> ***Personality*** :  Apathetic
>
> ***Trait*** : I have a lesson for every situation, drawn from observing nature.
>
> ***Ideal*** : Independence. When people follow orders blindly they embrace a kind of tyranny. (Chaotic)
{ .ownerDescription }



