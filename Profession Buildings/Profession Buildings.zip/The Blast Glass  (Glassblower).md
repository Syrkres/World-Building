---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Glassblower Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Blast Glass 
services: services
owner: Logspitter (Dwarf)
---
> [!oRPG-Layout] 
> #  The Blast Glass  (Glassblower/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Logspitter (Dwarf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Low |

##  The Blast Glass  owned by [[Logspitter]] (Dwarf)
*Glassblower / Crafter*


**Building Description:**  An old tall building, with faded paint stairs leading up to a set of double Cherry wood with Iron bands doors with a Beech frame, with planked siding. The roof is shingled. A pile of Beech wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Short strong build, with white eyes and frazzled grey hair. Their face has small scar on left cheek 
>
> ***Characteristics*** :  Limps
>
> ***Personality*** :  Flamboyant
>
> ***Trait*** : My favor, once lost, is lost forever.
>
> ***Ideal*** : People. I'm committed to the people I care about, not to ideals. (Neutral)
{ .ownerDescription }



