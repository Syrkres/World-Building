---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Earl Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Eusibic's Villa 
services: services
owner: Eusibic (Half-Orc)
---
> [!oRPG-Layout] 
> #  Eusibic's Villa  (Earl/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Eusibic (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Above Average |

##  Eusibic's Villa  owned by [[Eusibic]] (Half-Orc)
*Earl / Offical*


**Building Description:**  An one story building, with new paint with stoned siding. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Average fat build, with green eyes and braided red hair. Their face is squinty 
>
> ***Characteristics*** :  Taps feet
>
> ***Personality*** :  Energetic
>
> ***Trait*** : The common folk love me for my kindness and generosity.
>
> ***Ideal*** : Might. If I become strong, I can take what I want--what I deserve. (Evil)
{ .ownerDescription }



