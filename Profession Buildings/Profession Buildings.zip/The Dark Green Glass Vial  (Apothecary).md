---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Apothecary 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Dark Green Glass Vial 
services: services
owner: Caelun (Human)
---
> [!oRPG-Layout] 
> #  The Dark Green Glass Vial  (Apothecary/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Caelun (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Average |

##  The Dark Green Glass Vial  owned by [[Caelun]] (Human)
*Apothecary / *


**Building Description:**  An new long two story building, with new paint stairs leading up to a set of double Iron doors, with stoned siding. The roof is planked. A few Red Oak barrels sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Tall fat build, with blue eyes and streaked grey hair. Their face is missing teeth 
>
> ***Characteristics*** :  Needs story before sleeping
>
> ***Personality*** :  Sarcastic
>
> ***Trait*** : I enjoy sailing into new ports and making new friends over a flagon of ale.
>
> ***Ideal*** : Freedom. Everyone should be free to pursue his or her livelihood. (Chaotic)
{ .ownerDescription }



