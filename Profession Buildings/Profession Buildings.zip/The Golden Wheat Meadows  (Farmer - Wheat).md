---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Wheat Farmer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Golden Wheat Meadows 
services: services
owner: Fualla (Elven)
---
> [!oRPG-Layout] 
> #  The Golden Wheat Meadows  (Farmer - Wheat/Farmer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Fualla (Elven)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Average |
> |Costs | High |

##  The Golden Wheat Meadows  owned by [[Fualla]] (Elven)
*Farmer - Wheat / Farmer*


**Building Description:**  An new two story building, with faded paint with planked siding with a missing short window. The roof is planked with Elm planks. A Cherry pergola is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Grand lean build, with white eyes and strange hairstyle grey hair. Their face has small scar on right cheek 
>
> ***Characteristics*** :  Enjoys own body odor
>
> ***Personality*** :  Fastidious
>
> ***Trait*** : Flattery is my preferred trick for getting what I want.
>
> ***Ideal*** : Charity. I steal from the wealthy so that I can help people in need. (Good)
{ .ownerDescription }



