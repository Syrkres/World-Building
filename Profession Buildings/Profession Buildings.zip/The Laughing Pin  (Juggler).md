---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Juggler Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Laughing Pin 
services: services
owner: Ortenbarge (Human)
---
> [!oRPG-Layout] 
> #  The Laughing Pin  (Juggler/Entertainer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Ortenbarge (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Below Average |

##  The Laughing Pin  owned by [[Ortenbarge]] (Human)
*Juggler / Entertainer*


**Building Description:**  An new two story building, with brick siding with a missing window. The roof is timber. A Cherry pergola is attached to the side. A few Cherry crates sit along side.  



> ### Owner Description/Background
> ***Appearance*** : Normal thin build, with blue eyes and thinning white hair. Their face has a moustache 
>
> ***Characteristics*** :  Talks to inanimate objects
>
> ***Personality*** :  Cantankerous
>
> ***Trait*** : I enjoy sailing into new ports and making new friends over a flagon of ale.
>
> ***Ideal*** : Honor. I don't steal from others in the trade. (Lawful)
{ .ownerDescription }



