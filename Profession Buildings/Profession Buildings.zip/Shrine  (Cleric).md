---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric Holyman
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Shrine 
services: services
owner: Saentz (Halfling)
---
> [!oRPG-Layout] 
> #  Shrine  (Cleric/Holyman)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Saentz (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Average |

##  Shrine  owned by [[Saentz]] (Halfling)
*Cleric / Holyman*


**Building Description:**  An old building, with shingled siding with a missing window. The roof is thatching made of straw.  



> ### Owner Description/Background
> ***Appearance*** : Extra short frail build, with red eyes and messy brown hair. Their face has a moustache 
>
> ***Characteristics*** :  Collects teeth/hair/claws of slain opponents
>
> ***Personality*** :  Intolerant
>
> ***Trait*** : I fall in and out of love easily, and am always pursuing someone.
>
> ***Ideal*** : Independence. I am a free spirit--no one tells me what to do. (Chaotic)
{ .ownerDescription }



