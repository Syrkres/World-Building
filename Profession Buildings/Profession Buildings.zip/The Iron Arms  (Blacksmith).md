---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Blacksmith 
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Iron Arms 
services: services
owner: Eusibic (Human)
---
> [!oRPG-Layout] 
> #  The Iron Arms  (Blacksmith/)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Eusibic (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Poor |
> |Costs | Low |

##  The Iron Arms  owned by [[Eusibic]] (Human)
*Blacksmith / *


**Building Description:**  An narrow building, a set of double Pine wood with Steal bands doors, with brick siding. The roof is planked with Oak planks. A Cherry shed is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall frail build, with red eyes and strange hairstyle red hair. Their face is squinty 
>
> ***Characteristics*** :  Sharpens weapon
>
> ***Personality*** :  Feisty
>
> ***Trait*** : I often get lost in my own thoughts and contemplations, becoming oblivious to my surroundings.
>
> ***Ideal*** : Greed. I will do whatever it takes to become wealthy. (Evil)
{ .ownerDescription }



