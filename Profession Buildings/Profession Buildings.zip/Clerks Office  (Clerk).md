---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Clerk Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Clerks Office 
services: services
owner: Vesperini (Gnome)
---
> [!oRPG-Layout] 
> #  Clerks Office  (Clerk/Offical)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Vesperini (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  Clerks Office  owned by [[Vesperini]] (Gnome)
*Clerk / Offical*


**Building Description:**  An one story building, with faded paint with brick siding with a front shuttered window that has a painted sign hanging above with the merchants name. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Average average build, with hazel eyes and messy black hair. Their face is gap-toothed 
>
> ***Characteristics*** :  Picks at teeth
>
> ***Personality*** :  Defensive
>
> ***Trait*** : I can stare down a hellhound without flinching.
>
> ***Ideal*** : Might. If I become strong, I can take what I want--what I deserve. (Evil)
{ .ownerDescription }



