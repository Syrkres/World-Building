---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Potter Crafter
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Pot Market Stall 
services: services
owner: Rorken (Gnome)
---
> [!oRPG-Layout] 
> #  The Pot Market Stall  (Potter/Crafter)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Rorken (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | High |

##  The Pot Market Stall  owned by [[Rorken]] (Gnome)
*Potter / Crafter*


**Building Description:**  An two story building, with shingled siding with a front round window that has a Cherry wood door with the merchants name. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Extra short frail build, with brown eyes and very long white hair. Their face is toothless 
>
> ***Characteristics*** :  Easily confused
>
> ***Personality*** :  Moody
>
> ***Trait*** : I am working on a grand philosophical theory and love sharing my ideas.
>
> ***Ideal*** : Redemption. There's a spark of good in everyone. (Good)
{ .ownerDescription }



