---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Advocate Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Dependant 
services: services
owner: Kran (Gnome)
---
> [!oRPG-Layout] 
> #  The Dependant  (Advocate/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Kran (Gnome)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | Above Average |

##  The Dependant  owned by [[Kran]] (Gnome)
*Advocate / Professional*


**Building Description:**  An narrow tall building, with brick siding. The roof is timber made of Cherry. A shed is attached to the side. A pile of bricks sit at the corner.  



> ### Owner Description/Background
> ***Appearance*** : Squat average build, with blue eyes and bald blond hair. Their face is missing teeth 
>
> ***Characteristics*** :  Gesticulates wildly
>
> ***Personality*** :  Timid
>
> ***Trait*** : I hide scraps of food and trinkets away in my pockets.
>
> ***Ideal*** : Glory. I must earn glory in battle, for myself and my clan. (Any)
{ .ownerDescription }



