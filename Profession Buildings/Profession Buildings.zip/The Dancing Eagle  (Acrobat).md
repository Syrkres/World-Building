---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Acrobat Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: House
title:  The Dancing Eagle 
services: services
owner: Artimas (Halfling)
---
> [!oRPG-Layout] 
> #  The Dancing Eagle  (Acrobat/Entertainer)
> **Structure:** House
> **Resides In:** 
>  **Owner:** Artimas (Halfling)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Low |

##  The Dancing Eagle  owned by [[Artimas]] (Halfling)
*Acrobat / Entertainer*


**Building Description:**  An old building with shingled siding. The roof is planked.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall average build, with blue eyes and long brown hair. Their face is buck-toothed 
>
> ***Characteristics*** :  Whistles
>
> ***Personality*** :  Rebellious
>
> ***Trait*** : I keep multiple holy symbols on me and invoke whatever deity might come in useful at any given moment.
>
> ***Ideal*** : Charity. I always try to help those in need, no matter what the personal cost. (Good)
{ .ownerDescription }



