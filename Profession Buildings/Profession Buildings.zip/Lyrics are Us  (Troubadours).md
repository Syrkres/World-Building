---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Troubadours Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Lyrics are Us 
services: services
owner: Whil (Half-Elf)
---
> [!oRPG-Layout] 
> #  Lyrics are Us  (Troubadours/Entertainer)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Whil (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Excellent |
> |Costs | Below Average |

##  Lyrics are Us  owned by [[Whil]] (Half-Elf)
*Troubadours / Entertainer*


**Building Description:**  An old narrow building, with stoned siding with a few shuttered windows. The roof is thatching made of grass. A Yellow Birch pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Tall strong build, with white eyes and strange hairstyle white hair. Their face is squinty 
>
> ***Characteristics*** :  Giggles
>
> ***Personality*** :  Promiscuous
>
> ***Trait*** : I face problems head-on. A simple direct solution is the best path to success.
>
> ***Ideal*** : Nature. The natural world is more important than all the constructs of civilization. (Neutral)
{ .ownerDescription }



