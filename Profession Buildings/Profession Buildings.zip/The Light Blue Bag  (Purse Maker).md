---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Purse Maker Tailor
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Light Blue Bag 
services: services
owner: Hannier (Half-Orc)
---
> [!oRPG-Layout] 
> #  The Light Blue Bag  (Purse Maker/Tailor)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hannier (Half-Orc)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Below Average |

##  The Light Blue Bag  owned by [[Hannier]] (Half-Orc)
*Purse Maker / Tailor*


**Building Description:**  An building, with shingled siding. The roof is thatched. A pile of Hickory wood planks lean up against the side.  



> ### Owner Description/Background
> ***Appearance*** : Grand fat build, with brown eyes and greasy auburn hair. Their face is weather-beaten 
>
> ***Characteristics*** :  Makes up words
>
> ***Personality*** :  Pompous
>
> ***Trait*** : I idolize a particular hero of my faith and constantly refer to that person's deeds and example.
>
> ***Ideal*** : Responsibility. It is my duty to respect the authority of those above me, just as those below me must respect mine. (Lawful)
{ .ownerDescription }



