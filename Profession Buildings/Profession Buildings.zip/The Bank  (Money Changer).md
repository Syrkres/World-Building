---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Money Changer Professional
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  The Bank 
services: services
owner: Eemanda (Human)
---
> [!oRPG-Layout] 
> #  The Bank  (Money Changer/Professional)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Eemanda (Human)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Low |
> |Costs | High |

##  The Bank  owned by [[Eemanda]] (Human)
*Money Changer / Professional*


**Building Description:**  An new one story building, with faded paint with brick siding with a missing round window. The roof is shingled.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall average build, with hazel eyes and messy white hair. Their face has no eyebrows 
>
> ***Characteristics*** :  Picks at fingernails
>
> ***Personality*** :  Proud
>
> ***Trait*** : I work hard so that I can play hard when the work is done.
>
> ***Ideal*** : People. I like seeing the smiles on people's faces when I perform. That's all that matters. (Neutral)
{ .ownerDescription }



