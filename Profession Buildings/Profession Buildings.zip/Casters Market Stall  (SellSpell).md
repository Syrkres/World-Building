---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sellspell Holyman
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Shop
title:  Casters Market Stall 
services: services
owner: Hunjan (Half-Elf)
---
> [!oRPG-Layout] 
> #  Casters Market Stall  (Sellspell/Holyman)
> **Structure:** Shop
> **Resides In:** 
>  **Owner:** Hunjan (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Average |

##  Casters Market Stall  owned by [[Hunjan]] (Half-Elf)
*Sellspell / Holyman*


**Building Description:**  An old tall building, stairs leading up to a Elm wood with Bronze bands door with shingled siding. The roof is planked. A pergola is attached to the side.  



> ### Owner Description/Background
> ***Appearance*** : Short wide build, with green eyes and limp grey hair. Their face has a goatee 
>
> ***Characteristics*** :  Fidgets
>
> ***Personality*** :  Cruel
>
> ***Trait*** : I fall in and out of love easily, and am always pursuing someone.
>
> ***Ideal*** : Destiny. Nothing and no one can steer me away from my higher calling. (Any)
{ .ownerDescription }



