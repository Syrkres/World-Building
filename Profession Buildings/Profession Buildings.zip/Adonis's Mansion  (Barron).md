---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barron Offical
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Townhall
title:  Adonis's Mansion 
services: services
owner: Adonis (Half-Elf)
---
> [!oRPG-Layout] 
> #  Adonis's Mansion  (Barron/Offical)
> **Structure:** Townhall
> **Resides In:** 
>  **Owner:** Adonis (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Good |
> |Costs | Average |

##  Adonis's Mansion  owned by [[Adonis]] (Half-Elf)
*Barron / Offical*


**Building Description:**  An one story building with new paint and with planked siding with a few round windows. The roof is thatching made of grass.  



> ### Owner Description/Background
> ***Appearance*** : Extra tall weak build, with hazel eyes and well groomed red hair. Their face has a moustache 
>
> ***Characteristics*** :  Claustrophobic (afraid of small spaces)
>
> ***Personality*** :  Critical
>
> ***Trait*** : I would rather make a new friend than a new enemy.
>
> ***Ideal*** : Greater Good. It is each person's responsibility to make the most happiness for the whole tribe. (Good)
{ .ownerDescription }



