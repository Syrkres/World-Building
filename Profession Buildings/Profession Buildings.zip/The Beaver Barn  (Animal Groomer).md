---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer Entertainer
kingdom: 
region:  
settlement: 
urbanArea: 
structure: Stables
title:  The Beaver Barn 
services: services
owner: Sinias (Half-Elf)
---
> [!oRPG-Layout] 
> #  The Beaver Barn  (Animal Groomer/Entertainer)
> **Structure:** Stables
> **Resides In:** 
>  **Owner:** Sinias (Half-Elf)
> ###### Services
> |Name | Quality/Adj | 
> |:---|:---:| 
> |Service | Horrible |
> |Costs | Above Average |

##  The Beaver Barn  owned by [[Sinias]] (Half-Elf)
*Animal Groomer / Entertainer*


**Building Description:**  An narrow building with planked siding with a missing tall window. The roof is planked with Yellow Birch planks.  



> ### Owner Description/Background
> ***Appearance*** : Normal fat build, with red eyes and greasy grey hair. Their face has a bushy eyebrows 
>
> ***Characteristics*** :  Haphephobic (afraid of being touched)
>
> ***Personality*** :  Frustrated
>
> ***Trait*** : I'll settle for nothing less than perfection.
>
> ***Ideal*** : Self-improvement. The goal of a life of study is the betterment of oneself.
{ .ownerDescription }



