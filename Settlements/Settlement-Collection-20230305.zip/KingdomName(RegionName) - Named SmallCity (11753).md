---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallCity
kingdom: KingdomName
region: RegionName
settlementName: Named SmallCity (11753)
terrain: Desert Sands 
settlementDescription: 
population: 11753
culture: Oriental 
technology: Dark Ages 
leader: 
govermentType: Anarchy 
demographics: 
- Acrobat(20) 
- Minstrel(20) 
- Storyteller(20) 
- Troubadours(20) 
- Writer(20) 
- Advocate(15) 
- Clerk(34) 
- Council Member(30) 
- Diplomat(5) 
- Judge(17) 
- Mayor(1) 
- Alchemist(10) 
- Chandler(30) 
- Dye Makers(30) 
- Florist(10) 
- Herbalist(10) 
- Potionmakers(10) 
- Sage(6) 
- Spice Merchant(20) 
- Taxidermist(20) 
- Tobacco Merchant(20) 
- Animal Groomer(8) 
- Animal Handler(20) 
- Caravanner(15) 
- Horse Trader(24) 
- Livestock Merchant(16) 
- Stabler(21) 
- Antiquities(20) 
- Armor Dealer(20) 
- Launderer(20) 
- Oil Trader(30) 
- Trading Post(30) 
- Slaver(20) 
- Spice Merchant(20) 
- Taxidermist(20) 
- Tobacco Merchant(20) 
- Warehouser(20) 
- Weapon Dealer(20) 
- Architect(24) 
- Bricklayer(24) 
- Engineer(24) 
- Laborer(24) 
- Mason(24) 
- Painter(Building)(24) 
- Plasterer(24) 
- Roofer(24) 
- Teamster(24) 
- Tiler(24) 
- Armorer(7) 
- Blacksmith(28) 
- Bowyer-Fletcher(10) 
- Jeweler(8) 
- Silversmith(7) 
- Weapon Dealer(20) 
- Weaponsmith(6) 
- Artist(27) 
- Glassblower(20) 
- Goldsmith(14) 
- Inventor(17) 
- Jeweler(12) 
- Magical Artisan(6) 
- Painter(Art)(22) 
- Silversmith(17) 
- Tinker(30) 
- Toymaker(10) 
- Astrologist(6) 
- Conjourer(6) 
- High Mage(6) 
- Historian(6) 
- Librarian(6) 
- Magical Artisan(6) 
- Magical Tutor(6) 
- Professor(6) 
- Scribe(6) 
- SellSpell(6) 
- Teacher(6) 
- Tutor(6) 
- Baker(19) 
- Beer Merchant(11) 
- Brewer(3) 
- Butcher(12) 
- Chicken Butcher(12) 
- Cook(13) 
- Dairy Seller(59) 
- Distiller(11) 
- Hay Merchant(59) 
- Fisherman(15) 
- Fishmonger(15) 
- Grain Merchant(3) 
- Grocer(9) 
- Meat Butcher(10) 
- Miller(30) 
- Pastry Maker(15) 
- Vintner(13) 
- Banker(7) 
- Pawnbroker(7) 
- Barbarian(59) 
- Brigand(59) 
- Captain(59) 
- Mountainman(59) 
- Barbarian(11) 
- Cartographer(10) 
- Guide(20) 
- Huntsman(30) 
- Mountainman(10) 
- Pathfinder(10) 
- Scout(10) 
- Slaver(20) 
- Barrel Maker(13) 
- Basket Maker(17) 
- Book Binder(6) 
- Bookseller(6) 
- Buckle Maker(10) 
- Candle Maker(8) 
- Clock Maker(6) 
- Cobbler(19) 
- Cooper(14) 
- Cutler(6) 
- Engraver(6) 
- Furniture Maker(19) 
- Glassblower(9) 
- Glazier(6) 
- Glove Merchant(16) 
- Goldsmith(9) 
- Harness Maker(20) 
- Hat Maker(8) 
- Instrument Maker(6) 
- Kettle Maker(6) 
- Locksmith(7) 
- Perfumer(9) 
- Potter(20) 
- Rope Maker(14) 
- Rug Maker(8) 
- Saddler(15) 
- Sculptor(6) 
- Shoe Maker(14) 
- Soap Maker(10) 
- Tanner(15) 
- Tinker(7) 
- Toymaker(6) 
- Weaponsmith(6) 
- Weaver(17) 
- Wheelwright(27) 
- Wine Merchant(10) 
- Wool Merchant(15) 
- Lord(4) 
- Knight(4) 
- Baron(3) 
- Viscount(2) 
- Earl(1) 
- Count(1) 
- Duke(1) 
- Barrel Maker(22) 
- Bowyer-Fletcher(10) 
- Carpenter(34) 
- Roofer(24) 
- Wagon Maker(17) 
- Wheelwright(19) 
- Wood Carver(10) 
- Wood Seller(9) 
- Barber(10) 
- Bleacher(10) 
- Physic/Chirurgeon(10) 
- Bather(8) 
- Brigand(20) 
- Crime Lord(5) 
- Crook(24) 
- Goon(27) 
- Brothel Keeper(9) 
- Innkeeper(16) 
- Tavern Keeper(22) 
- Buckle Maker(16) 
- Cobbler(14) 
- Draper(10) 
- Furrier(27) 
- Girdler(9) 
- Haberdasher(8) 
- Launderer(16) 
- Leatherworker(11) 
- Purse Maker(10) 
- Shoe Maker(14) 
- Tailor(16) 
- Tanner(15) 
- Used Garment Trader(25) 
- Vestment Maker(14) 
- Chandler(30) 
- Dye Makers(30) 
- Oil Trader(30) 
- Cleric(22) 
- High Priest(9) 
- Missionary(79) 
- Preacher(48) 
- Priest(27) 
- Farmer(588) 
- Homestead(784) 
- Farmer - Cabbage(59) 
- Farmer - Cattle Herder(59) 
- Farmer - Corn(59) 
- Farmer - Cow Herder(59) 
- Farmer - Dairy(59) 
- Farmer - Goat Herder(59) 
- Farmer - Pig Herder(59) 
- Farmer - Potato(59) 
- Farmer - Sheep Herder(59) 
- Farmer - Wheat(59) 
- Farmer(Special)(59) 
- Dungsweeper(17) 
- Illuminator(12) 
- Messenger(19) 
- Tax Collector(3) 
- Town Crier(34) 
- Town Justice(8) 
- Undertaker(7) 
- Water Carrier(24) 
- Leatherworker(12) 
- Skinner(12) 
- Naval Outfitter(7) 
- Pirate(30) 
- Sail Maker(17) 
- Sailor(40) 
- Ship Builder(7) 
imports: 
- Skins  
exports: 
- Tortoise Shells  
defenses: Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(20)  
> - Advocate(15)  
> - Alchemist(10)  
> - Animal Groomer(8)  
> - Animal Handler(20)  
> - Antiquities(20)  
> - Architect(24)  
> - Armor Dealer(20)  
> - Armorer(7)  
> - Artist(27)  
> - Astrologist(6)  
> - Baker(19)  
> - Banker(7)  
> - Barbarian(11)  
> - Barbarian(59)  
> - Barber(10)  
> - Baron(3)  
> - Barrel Maker(13)  
> - Barrel Maker(22)  
> - Basket Maker(17)  
> - Bather(8)  
> - Beer Merchant(11)  
> - Blacksmith(28)  
> - Bleacher(10)  
> - Book Binder(6)  
> - Bookseller(6)  
> - Bowyer-Fletcher(10)  
> - Bowyer-Fletcher(10)  
> - Brewer(3)  
> - Bricklayer(24)  
> - Brigand(20)  
> - Brigand(59)  
> - Brothel Keeper(9)  
> - Buckle Maker(10)  
> - Buckle Maker(16)  
> - Butcher(12)  
> - Candle Maker(8)  
> - Captain(59)  
> - Caravanner(15)  
> - Carpenter(34)  
> - Cartographer(10)  
> - Chandler(30)  
> - Chandler(30)  
> - Chicken Butcher(12)  
> - Cleric(22)  
> - Clerk(34)  
> - Clock Maker(6)  
> - Cobbler(14)  
> - Cobbler(19)  
> - Conjourer(6)  
> - Cook(13)  
> - Cooper(14)  
> - Council Member(30)  
> - Count(1)  
> - Crime Lord(5)  
> - Crook(24)  
> - Cutler(6)  
> - Dairy Seller(59)  
> - Diplomat(5)  
> - Distiller(11)  
> - Draper(10)  
> - Duke(1)  
> - Dungsweeper(17)  
> - Dye Makers(30)  
> - Dye Makers(30)  
> - Earl(1)  
> - Engineer(24)  
> - Engraver(6)  
> - Farmer - Cabbage(59)  
> - Farmer - Cattle Herder(59)  
> - Farmer - Corn(59)  
> - Farmer - Cow Herder(59)  
> - Farmer - Dairy(59)  
> - Farmer - Goat Herder(59)  
> - Farmer - Pig Herder(59)  
> - Farmer - Potato(59)  
> - Farmer - Sheep Herder(59)  
> - Farmer - Wheat(59)  
> - Farmer(588)  
> - Farmer(Special)(59)  
> - Fisherman(15)  
> - Fishmonger(15)  
> - Florist(10)  
> - Furniture Maker(19)  
> - Furrier(27)  
> - Girdler(9)  
> - Glassblower(20)  
> - Glassblower(9)  
> - Glazier(6)  
> - Glove Merchant(16)  
> - Goldsmith(14)  
> - Goldsmith(9)  
> - Goon(27)  
> - Grain Merchant(3)  
> - Grocer(9)  
> - Guide(20)  
> - Haberdasher(8)  
> - Harness Maker(20)  
> - Hat Maker(8)  
> - Hay Merchant(59)  
> - Herbalist(10)  
> - High Mage(6)  
> - High Priest(9)  
> - Historian(6)  
> - Homestead(784)  
> - Horse Trader(24)  
> - Huntsman(30)  
> - Illuminator(12)  
> - Innkeeper(16)  
> - Instrument Maker(6)  
> - Inventor(17)  
> - Jeweler(12)  
> - Jeweler(8)  
> - Judge(17)  
> - Kettle Maker(6)  
> - Knight(4)  
> - Laborer(24)  
> - Launderer(16)  
> - Launderer(20)  
> - Leatherworker(11)  
> - Leatherworker(12)  
> - Librarian(6)  
> - Livestock Merchant(16)  
> - Locksmith(7)  
> - Lord(4)  
> - Magical Artisan(6)  
> - Magical Artisan(6)  
> - Magical Tutor(6)  
> - Mason(24)  
> - Mayor(1)  
> - Meat Butcher(10)  
> - Messenger(19)  
> - Miller(30)  
> - Minstrel(20)  
> - Missionary(79)  
> - Mountainman(10)  
> - Mountainman(59)  
> - Naval Outfitter(7)  
> - Oil Trader(30)  
> - Oil Trader(30)  
> - Painter(Art)(22)  
> - Painter(Building)(24)  
> - Pastry Maker(15)  
> - Pathfinder(10)  
> - Pawnbroker(7)  
> - Perfumer(9)  
> - Physic/Chirurgeon(10)  
> - Pirate(30)  
> - Plasterer(24)  
> - Potionmakers(10)  
> - Potter(20)  
> - Preacher(48)  
> - Priest(27)  
> - Professor(6)  
> - Purse Maker(10)  
> - Roofer(24)  
> - Roofer(24)  
> - Rope Maker(14)  
> - Rug Maker(8)  
> - Saddler(15)  
> - Sage(6)  
> - Sail Maker(17)  
> - Sailor(40)  
> - Scout(10)  
> - Scribe(6)  
> - Sculptor(6)  
> - SellSpell(6)  
> - Ship Builder(7)  
> - Shoe Maker(14)  
> - Shoe Maker(14)  
> - Silversmith(17)  
> - Silversmith(7)  
> - Skinner(12)  
> - Slaver(20)  
> - Slaver(20)  
> - Soap Maker(10)  
> - Spice Merchant(20)  
> - Spice Merchant(20)  
> - Stabler(21)  
> - Storyteller(20)  
> - Tailor(16)  
> - Tanner(15)  
> - Tanner(15)  
> - Tavern Keeper(22)  
> - Tax Collector(3)  
> - Taxidermist(20)  
> - Taxidermist(20)  
> - Teacher(6)  
> - Teamster(24)  
> - Tiler(24)  
> - Tinker(30)  
> - Tinker(7)  
> - Tobacco Merchant(20)  
> - Tobacco Merchant(20)  
> - Town Crier(34)  
> - Town Justice(8)  
> - Toymaker(10)  
> - Toymaker(6)  
> - Trading Post(30)  
> - Troubadours(20)  
> - Tutor(6)  
> - Undertaker(7)  
> - Used Garment Trader(25)  
> - Vestment Maker(14)  
> - Vintner(13)  
> - Viscount(2)  
> - Wagon Maker(17)  
> - Warehouser(20)  
> - Water Carrier(24)  
> - Weapon Dealer(20)  
> - Weapon Dealer(20)  
> - Weaponsmith(6)  
> - Weaponsmith(6)  
> - Weaver(17)  
> - Wheelwright(19)  
> - Wheelwright(27)  
> - Wine Merchant(10)  
> - Wood Carver(10)  
> - Wood Seller(9)  
> - Wool Merchant(15)  
> - Writer(20)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(20)  
> - Advocate(15)  
> - Alchemist(10)  
> - Animal Groomer(8)  
> - Animal Handler(20)  
> - Antiquities(20)  
> - Architect(24)  
> - Armor Dealer(20)  
> - Armorer(7)  
> - Artist(27)  
> - Astrologist(6)  
> - Baker(19)  
> - Banker(7)  
> - Barbarian(11)  
> - Barbarian(59)  
> - Barber(10)  
> - Baron(3)  
> - Barrel Maker(13)  
> - Barrel Maker(22)  
> - Basket Maker(17)  
> - Bather(8)  
> - Beer Merchant(11)  
> - Blacksmith(28)  
> - Bleacher(10)  
> - Book Binder(6)  
> - Bookseller(6)  
> - Bowyer-Fletcher(10)  
> - Bowyer-Fletcher(10)  
> - Brewer(3)  
> - Bricklayer(24)  
> - Brigand(20)  
> - Brigand(59)  
> - Brothel Keeper(9)  
> - Buckle Maker(10)  
> - Buckle Maker(16)  
> - Butcher(12)  
> - Candle Maker(8)  
> - Captain(59)  
> - Caravanner(15)  
> - Carpenter(34)  
> - Cartographer(10)  
> - Chandler(30)  
> - Chandler(30)  
> - Chicken Butcher(12)  
> - Cleric(22)  
> - Clerk(34)  
> - Clock Maker(6)  
> - Cobbler(14)  
> - Cobbler(19)  
> - Conjourer(6)  
> - Cook(13)  
> - Cooper(14)  
> - Council Member(30)  
> - Count(1)  
> - Crime Lord(5)  
> - Crook(24)  
> - Cutler(6)  
> - Dairy Seller(59)  
> - Diplomat(5)  
> - Distiller(11)  
> - Draper(10)  
> - Duke(1)  
> - Dungsweeper(17)  
> - Dye Makers(30)  
> - Dye Makers(30)  
> - Earl(1)  
> - Engineer(24)  
> - Engraver(6)  
> - Farmer - Cabbage(59)  
> - Farmer - Cattle Herder(59)  
> - Farmer - Corn(59)  
> - Farmer - Cow Herder(59)  
> - Farmer - Dairy(59)  
> - Farmer - Goat Herder(59)  
> - Farmer - Pig Herder(59)  
> - Farmer - Potato(59)  
> - Farmer - Sheep Herder(59)  
> - Farmer - Wheat(59)  
> - Farmer(588)  
> - Farmer(Special)(59)  
> - Fisherman(15)  
> - Fishmonger(15)  
> - Florist(10)  
> - Furniture Maker(19)  
> - Furrier(27)  
> - Girdler(9)  
> - Glassblower(20)  
> - Glassblower(9)  
> - Glazier(6)  
> - Glove Merchant(16)  
> - Goldsmith(14)  
> - Goldsmith(9)  
> - Goon(27)  
> - Grain Merchant(3)  
> - Grocer(9)  
> - Guide(20)  
> - Haberdasher(8)  
> - Harness Maker(20)  
> - Hat Maker(8)  
> - Hay Merchant(59)  
> - Herbalist(10)  
> - High Mage(6)  
> - High Priest(9)  
> - Historian(6)  
> - Homestead(784)  
> - Horse Trader(24)  
> - Huntsman(30)  
> - Illuminator(12)  
> - Innkeeper(16)  
> - Instrument Maker(6)  
> - Inventor(17)  
> - Jeweler(12)  
> - Jeweler(8)  
> - Judge(17)  
> - Kettle Maker(6)  
> - Knight(4)  
> - Laborer(24)  
> - Launderer(16)  
> - Launderer(20)  
> - Leatherworker(11)  
> - Leatherworker(12)  
> - Librarian(6)  
> - Livestock Merchant(16)  
> - Locksmith(7)  
> - Lord(4)  
> - Magical Artisan(6)  
> - Magical Artisan(6)  
> - Magical Tutor(6)  
> - Mason(24)  
> - Mayor(1)  
> - Meat Butcher(10)  
> - Messenger(19)  
> - Miller(30)  
> - Minstrel(20)  
> - Missionary(79)  
> - Mountainman(10)  
> - Mountainman(59)  
> - Naval Outfitter(7)  
> - Oil Trader(30)  
> - Oil Trader(30)  
> - Painter(Art)(22)  
> - Painter(Building)(24)  
> - Pastry Maker(15)  
> - Pathfinder(10)  
> - Pawnbroker(7)  
> - Perfumer(9)  
> - Physic/Chirurgeon(10)  
> - Pirate(30)  
> - Plasterer(24)  
> - Potionmakers(10)  
> - Potter(20)  
> - Preacher(48)  
> - Priest(27)  
> - Professor(6)  
> - Purse Maker(10)  
> - Roofer(24)  
> - Roofer(24)  
> - Rope Maker(14)  
> - Rug Maker(8)  
> - Saddler(15)  
> - Sage(6)  
> - Sail Maker(17)  
> - Sailor(40)  
> - Scout(10)  
> - Scribe(6)  
> - Sculptor(6)  
> - SellSpell(6)  
> - Ship Builder(7)  
> - Shoe Maker(14)  
> - Shoe Maker(14)  
> - Silversmith(17)  
> - Silversmith(7)  
> - Skinner(12)  
> - Slaver(20)  
> - Slaver(20)  
> - Soap Maker(10)  
> - Spice Merchant(20)  
> - Spice Merchant(20)  
> - Stabler(21)  
> - Storyteller(20)  
> - Tailor(16)  
> - Tanner(15)  
> - Tanner(15)  
> - Tavern Keeper(22)  
> - Tax Collector(3)  
> - Taxidermist(20)  
> - Taxidermist(20)  
> - Teacher(6)  
> - Teamster(24)  
> - Tiler(24)  
> - Tinker(30)  
> - Tinker(7)  
> - Tobacco Merchant(20)  
> - Tobacco Merchant(20)  
> - Town Crier(34)  
> - Town Justice(8)  
> - Toymaker(10)  
> - Toymaker(6)  
> - Trading Post(30)  
> - Troubadours(20)  
> - Tutor(6)  
> - Undertaker(7)  
> - Used Garment Trader(25)  
> - Vestment Maker(14)  
> - Vintner(13)  
> - Viscount(2)  
> - Wagon Maker(17)  
> - Warehouser(20)  
> - Water Carrier(24)  
> - Weapon Dealer(20)  
> - Weapon Dealer(20)  
> - Weaponsmith(6)  
> - Weaponsmith(6)  
> - Weaver(17)  
> - Wheelwright(19)  
> - Wheelwright(27)  
> - Wine Merchant(10)  
> - Wood Carver(10)  
> - Wood Seller(9)  
> - Wool Merchant(15)  
> - Writer(20)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



