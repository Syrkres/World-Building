---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallCity
kingdom: KingdomName
region: RegionName
settlementName: Named SmallCity (10297)
terrain: Hills Forest Jungle 
settlementDescription: 
population: 10297
culture: Renaissance 
technology: Savage 
leader: 
govermentType: Democracy 
demographics: 
- Acrobat(18) 
- Minstrel(18) 
- Storyteller(18) 
- Troubadours(18) 
- Writer(18) 
- Advocate(13) 
- Clerk(30) 
- Council Member(26) 
- Diplomat(5) 
- Judge(15) 
- Mayor(1) 
- Alchemist(9) 
- Chandler(26) 
- Dye Makers(26) 
- Florist(9) 
- Herbalist(9) 
- Potionmakers(9) 
- Sage(5) 
- Spice Merchant(18) 
- Taxidermist(18) 
- Tobacco Merchant(18) 
- Animal Groomer(7) 
- Animal Handler(18) 
- Caravanner(13) 
- Horse Trader(21) 
- Livestock Merchant(14) 
- Stabler(19) 
- Antiquities(18) 
- Armor Dealer(18) 
- Launderer(18) 
- Oil Trader(26) 
- Trading Post(26) 
- Slaver(18) 
- Spice Merchant(18) 
- Taxidermist(18) 
- Tobacco Merchant(18) 
- Warehouser(18) 
- Weapon Dealer(18) 
- Architect(21) 
- Bricklayer(21) 
- Engineer(21) 
- Laborer(21) 
- Mason(21) 
- Painter(Building)(21) 
- Plasterer(21) 
- Roofer(21) 
- Teamster(21) 
- Tiler(21) 
- Armorer(6) 
- Blacksmith(25) 
- Bowyer-Fletcher(9) 
- Jeweler(7) 
- Silversmith(7) 
- Weapon Dealer(18) 
- Weaponsmith(5) 
- Artist(23) 
- Glassblower(18) 
- Goldsmith(12) 
- Inventor(15) 
- Jeweler(11) 
- Magical Artisan(5) 
- Painter(Art)(19) 
- Silversmith(15) 
- Tinker(26) 
- Toymaker(8) 
- Astrologist(5) 
- Conjourer(5) 
- High Mage(5) 
- Historian(5) 
- Librarian(5) 
- Magical Artisan(5) 
- Magical Tutor(5) 
- Professor(5) 
- Scribe(5) 
- SellSpell(5) 
- Teacher(5) 
- Tutor(5) 
- Baker(16) 
- Beer Merchant(10) 
- Brewer(3) 
- Butcher(11) 
- Chicken Butcher(11) 
- Cook(11) 
- Dairy Seller(52) 
- Distiller(10) 
- Hay Merchant(52) 
- Fisherman(13) 
- Fishmonger(13) 
- Grain Merchant(3) 
- Grocer(8) 
- Meat Butcher(9) 
- Miller(26) 
- Pastry Maker(13) 
- Vintner(11) 
- Banker(6) 
- Pawnbroker(6) 
- Barbarian(52) 
- Brigand(52) 
- Captain(52) 
- Mountainman(52) 
- Barbarian(10) 
- Cartographer(9) 
- Guide(18) 
- Huntsman(26) 
- Mountainman(8) 
- Pathfinder(9) 
- Scout(9) 
- Slaver(18) 
- Barrel Maker(11) 
- Basket Maker(15) 
- Book Binder(6) 
- Bookseller(5) 
- Buckle Maker(8) 
- Candle Maker(7) 
- Clock Maker(5) 
- Cobbler(16) 
- Cooper(13) 
- Cutler(6) 
- Engraver(5) 
- Furniture Maker(16) 
- Glassblower(8) 
- Glazier(5) 
- Glove Merchant(14) 
- Goldsmith(8) 
- Harness Maker(18) 
- Hat Maker(7) 
- Instrument Maker(5) 
- Kettle Maker(5) 
- Locksmith(7) 
- Perfumer(8) 
- Potter(18) 
- Rope Maker(13) 
- Rug Maker(7) 
- Saddler(13) 
- Sculptor(5) 
- Shoe Maker(13) 
- Soap Maker(9) 
- Tanner(13) 
- Tinker(6) 
- Toymaker(5) 
- Weaponsmith(5) 
- Weaver(15) 
- Wheelwright(23) 
- Wine Merchant(9) 
- Wool Merchant(13) 
- Lord(4) 
- Knight(4) 
- Baron(3) 
- Viscount(2) 
- Earl(1) 
- Count(1) 
- Duke(1) 
- Barrel Maker(19) 
- Bowyer-Fletcher(9) 
- Carpenter(30) 
- Roofer(21) 
- Wagon Maker(15) 
- Wheelwright(16) 
- Wood Carver(9) 
- Wood Seller(8) 
- Barber(9) 
- Bleacher(9) 
- Physic/Chirurgeon(9) 
- Bather(7) 
- Brigand(18) 
- Crime Lord(5) 
- Crook(21) 
- Goon(23) 
- Brothel Keeper(8) 
- Innkeeper(14) 
- Tavern Keeper(19) 
- Buckle Maker(14) 
- Cobbler(13) 
- Draper(9) 
- Furrier(23) 
- Girdler(8) 
- Haberdasher(7) 
- Launderer(14) 
- Leatherworker(10) 
- Purse Maker(9) 
- Shoe Maker(13) 
- Tailor(14) 
- Tanner(13) 
- Used Garment Trader(22) 
- Vestment Maker(13) 
- Chandler(26) 
- Dye Makers(26) 
- Oil Trader(26) 
- Cleric(19) 
- High Priest(8) 
- Missionary(69) 
- Preacher(42) 
- Priest(23) 
- Farmer(515) 
- Homestead(687) 
- Farmer - Cabbage(52) 
- Farmer - Cattle Herder(52) 
- Farmer - Corn(52) 
- Farmer - Cow Herder(52) 
- Farmer - Dairy(52) 
- Farmer - Goat Herder(52) 
- Farmer - Pig Herder(52) 
- Farmer - Potato(52) 
- Farmer - Sheep Herder(52) 
- Farmer - Wheat(52) 
- Farmer(Special)(52) 
- Dungsweeper(15) 
- Illuminator(11) 
- Messenger(16) 
- Tax Collector(3) 
- Town Crier(30) 
- Town Justice(7) 
- Undertaker(6) 
- Water Carrier(21) 
- Leatherworker(11) 
- Skinner(11) 
- Naval Outfitter(6) 
- Pirate(26) 
- Sail Maker(15) 
- Sailor(35) 
- Ship Builder(7) 
imports: 
- Soapstone  
exports: 
- Ceder Lumber  
defenses: Stone Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(18)  
> - Advocate(13)  
> - Alchemist(9)  
> - Animal Groomer(7)  
> - Animal Handler(18)  
> - Antiquities(18)  
> - Architect(21)  
> - Armor Dealer(18)  
> - Armorer(6)  
> - Artist(23)  
> - Astrologist(5)  
> - Baker(16)  
> - Banker(6)  
> - Barbarian(10)  
> - Barbarian(52)  
> - Barber(9)  
> - Baron(3)  
> - Barrel Maker(11)  
> - Barrel Maker(19)  
> - Basket Maker(15)  
> - Bather(7)  
> - Beer Merchant(10)  
> - Blacksmith(25)  
> - Bleacher(9)  
> - Book Binder(6)  
> - Bookseller(5)  
> - Bowyer-Fletcher(9)  
> - Bowyer-Fletcher(9)  
> - Brewer(3)  
> - Bricklayer(21)  
> - Brigand(18)  
> - Brigand(52)  
> - Brothel Keeper(8)  
> - Buckle Maker(14)  
> - Buckle Maker(8)  
> - Butcher(11)  
> - Candle Maker(7)  
> - Captain(52)  
> - Caravanner(13)  
> - Carpenter(30)  
> - Cartographer(9)  
> - Chandler(26)  
> - Chandler(26)  
> - Chicken Butcher(11)  
> - Cleric(19)  
> - Clerk(30)  
> - Clock Maker(5)  
> - Cobbler(13)  
> - Cobbler(16)  
> - Conjourer(5)  
> - Cook(11)  
> - Cooper(13)  
> - Council Member(26)  
> - Count(1)  
> - Crime Lord(5)  
> - Crook(21)  
> - Cutler(6)  
> - Dairy Seller(52)  
> - Diplomat(5)  
> - Distiller(10)  
> - Draper(9)  
> - Duke(1)  
> - Dungsweeper(15)  
> - Dye Makers(26)  
> - Dye Makers(26)  
> - Earl(1)  
> - Engineer(21)  
> - Engraver(5)  
> - Farmer - Cabbage(52)  
> - Farmer - Cattle Herder(52)  
> - Farmer - Corn(52)  
> - Farmer - Cow Herder(52)  
> - Farmer - Dairy(52)  
> - Farmer - Goat Herder(52)  
> - Farmer - Pig Herder(52)  
> - Farmer - Potato(52)  
> - Farmer - Sheep Herder(52)  
> - Farmer - Wheat(52)  
> - Farmer(515)  
> - Farmer(Special)(52)  
> - Fisherman(13)  
> - Fishmonger(13)  
> - Florist(9)  
> - Furniture Maker(16)  
> - Furrier(23)  
> - Girdler(8)  
> - Glassblower(18)  
> - Glassblower(8)  
> - Glazier(5)  
> - Glove Merchant(14)  
> - Goldsmith(12)  
> - Goldsmith(8)  
> - Goon(23)  
> - Grain Merchant(3)  
> - Grocer(8)  
> - Guide(18)  
> - Haberdasher(7)  
> - Harness Maker(18)  
> - Hat Maker(7)  
> - Hay Merchant(52)  
> - Herbalist(9)  
> - High Mage(5)  
> - High Priest(8)  
> - Historian(5)  
> - Homestead(687)  
> - Horse Trader(21)  
> - Huntsman(26)  
> - Illuminator(11)  
> - Innkeeper(14)  
> - Instrument Maker(5)  
> - Inventor(15)  
> - Jeweler(11)  
> - Jeweler(7)  
> - Judge(15)  
> - Kettle Maker(5)  
> - Knight(4)  
> - Laborer(21)  
> - Launderer(14)  
> - Launderer(18)  
> - Leatherworker(10)  
> - Leatherworker(11)  
> - Librarian(5)  
> - Livestock Merchant(14)  
> - Locksmith(7)  
> - Lord(4)  
> - Magical Artisan(5)  
> - Magical Artisan(5)  
> - Magical Tutor(5)  
> - Mason(21)  
> - Mayor(1)  
> - Meat Butcher(9)  
> - Messenger(16)  
> - Miller(26)  
> - Minstrel(18)  
> - Missionary(69)  
> - Mountainman(52)  
> - Mountainman(8)  
> - Naval Outfitter(6)  
> - Oil Trader(26)  
> - Oil Trader(26)  
> - Painter(Art)(19)  
> - Painter(Building)(21)  
> - Pastry Maker(13)  
> - Pathfinder(9)  
> - Pawnbroker(6)  
> - Perfumer(8)  
> - Physic/Chirurgeon(9)  
> - Pirate(26)  
> - Plasterer(21)  
> - Potionmakers(9)  
> - Potter(18)  
> - Preacher(42)  
> - Priest(23)  
> - Professor(5)  
> - Purse Maker(9)  
> - Roofer(21)  
> - Roofer(21)  
> - Rope Maker(13)  
> - Rug Maker(7)  
> - Saddler(13)  
> - Sage(5)  
> - Sail Maker(15)  
> - Sailor(35)  
> - Scout(9)  
> - Scribe(5)  
> - Sculptor(5)  
> - SellSpell(5)  
> - Ship Builder(7)  
> - Shoe Maker(13)  
> - Shoe Maker(13)  
> - Silversmith(15)  
> - Silversmith(7)  
> - Skinner(11)  
> - Slaver(18)  
> - Slaver(18)  
> - Soap Maker(9)  
> - Spice Merchant(18)  
> - Spice Merchant(18)  
> - Stabler(19)  
> - Storyteller(18)  
> - Tailor(14)  
> - Tanner(13)  
> - Tanner(13)  
> - Tavern Keeper(19)  
> - Tax Collector(3)  
> - Taxidermist(18)  
> - Taxidermist(18)  
> - Teacher(5)  
> - Teamster(21)  
> - Tiler(21)  
> - Tinker(26)  
> - Tinker(6)  
> - Tobacco Merchant(18)  
> - Tobacco Merchant(18)  
> - Town Crier(30)  
> - Town Justice(7)  
> - Toymaker(5)  
> - Toymaker(8)  
> - Trading Post(26)  
> - Troubadours(18)  
> - Tutor(5)  
> - Undertaker(6)  
> - Used Garment Trader(22)  
> - Vestment Maker(13)  
> - Vintner(11)  
> - Viscount(2)  
> - Wagon Maker(15)  
> - Warehouser(18)  
> - Water Carrier(21)  
> - Weapon Dealer(18)  
> - Weapon Dealer(18)  
> - Weaponsmith(5)  
> - Weaponsmith(5)  
> - Weaver(15)  
> - Wheelwright(16)  
> - Wheelwright(23)  
> - Wine Merchant(9)  
> - Wood Carver(9)  
> - Wood Seller(8)  
> - Wool Merchant(13)  
> - Writer(18)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(18)  
> - Advocate(13)  
> - Alchemist(9)  
> - Animal Groomer(7)  
> - Animal Handler(18)  
> - Antiquities(18)  
> - Architect(21)  
> - Armor Dealer(18)  
> - Armorer(6)  
> - Artist(23)  
> - Astrologist(5)  
> - Baker(16)  
> - Banker(6)  
> - Barbarian(10)  
> - Barbarian(52)  
> - Barber(9)  
> - Baron(3)  
> - Barrel Maker(11)  
> - Barrel Maker(19)  
> - Basket Maker(15)  
> - Bather(7)  
> - Beer Merchant(10)  
> - Blacksmith(25)  
> - Bleacher(9)  
> - Book Binder(6)  
> - Bookseller(5)  
> - Bowyer-Fletcher(9)  
> - Bowyer-Fletcher(9)  
> - Brewer(3)  
> - Bricklayer(21)  
> - Brigand(18)  
> - Brigand(52)  
> - Brothel Keeper(8)  
> - Buckle Maker(14)  
> - Buckle Maker(8)  
> - Butcher(11)  
> - Candle Maker(7)  
> - Captain(52)  
> - Caravanner(13)  
> - Carpenter(30)  
> - Cartographer(9)  
> - Chandler(26)  
> - Chandler(26)  
> - Chicken Butcher(11)  
> - Cleric(19)  
> - Clerk(30)  
> - Clock Maker(5)  
> - Cobbler(13)  
> - Cobbler(16)  
> - Conjourer(5)  
> - Cook(11)  
> - Cooper(13)  
> - Council Member(26)  
> - Count(1)  
> - Crime Lord(5)  
> - Crook(21)  
> - Cutler(6)  
> - Dairy Seller(52)  
> - Diplomat(5)  
> - Distiller(10)  
> - Draper(9)  
> - Duke(1)  
> - Dungsweeper(15)  
> - Dye Makers(26)  
> - Dye Makers(26)  
> - Earl(1)  
> - Engineer(21)  
> - Engraver(5)  
> - Farmer - Cabbage(52)  
> - Farmer - Cattle Herder(52)  
> - Farmer - Corn(52)  
> - Farmer - Cow Herder(52)  
> - Farmer - Dairy(52)  
> - Farmer - Goat Herder(52)  
> - Farmer - Pig Herder(52)  
> - Farmer - Potato(52)  
> - Farmer - Sheep Herder(52)  
> - Farmer - Wheat(52)  
> - Farmer(515)  
> - Farmer(Special)(52)  
> - Fisherman(13)  
> - Fishmonger(13)  
> - Florist(9)  
> - Furniture Maker(16)  
> - Furrier(23)  
> - Girdler(8)  
> - Glassblower(18)  
> - Glassblower(8)  
> - Glazier(5)  
> - Glove Merchant(14)  
> - Goldsmith(12)  
> - Goldsmith(8)  
> - Goon(23)  
> - Grain Merchant(3)  
> - Grocer(8)  
> - Guide(18)  
> - Haberdasher(7)  
> - Harness Maker(18)  
> - Hat Maker(7)  
> - Hay Merchant(52)  
> - Herbalist(9)  
> - High Mage(5)  
> - High Priest(8)  
> - Historian(5)  
> - Homestead(687)  
> - Horse Trader(21)  
> - Huntsman(26)  
> - Illuminator(11)  
> - Innkeeper(14)  
> - Instrument Maker(5)  
> - Inventor(15)  
> - Jeweler(11)  
> - Jeweler(7)  
> - Judge(15)  
> - Kettle Maker(5)  
> - Knight(4)  
> - Laborer(21)  
> - Launderer(14)  
> - Launderer(18)  
> - Leatherworker(10)  
> - Leatherworker(11)  
> - Librarian(5)  
> - Livestock Merchant(14)  
> - Locksmith(7)  
> - Lord(4)  
> - Magical Artisan(5)  
> - Magical Artisan(5)  
> - Magical Tutor(5)  
> - Mason(21)  
> - Mayor(1)  
> - Meat Butcher(9)  
> - Messenger(16)  
> - Miller(26)  
> - Minstrel(18)  
> - Missionary(69)  
> - Mountainman(52)  
> - Mountainman(8)  
> - Naval Outfitter(6)  
> - Oil Trader(26)  
> - Oil Trader(26)  
> - Painter(Art)(19)  
> - Painter(Building)(21)  
> - Pastry Maker(13)  
> - Pathfinder(9)  
> - Pawnbroker(6)  
> - Perfumer(8)  
> - Physic/Chirurgeon(9)  
> - Pirate(26)  
> - Plasterer(21)  
> - Potionmakers(9)  
> - Potter(18)  
> - Preacher(42)  
> - Priest(23)  
> - Professor(5)  
> - Purse Maker(9)  
> - Roofer(21)  
> - Roofer(21)  
> - Rope Maker(13)  
> - Rug Maker(7)  
> - Saddler(13)  
> - Sage(5)  
> - Sail Maker(15)  
> - Sailor(35)  
> - Scout(9)  
> - Scribe(5)  
> - Sculptor(5)  
> - SellSpell(5)  
> - Ship Builder(7)  
> - Shoe Maker(13)  
> - Shoe Maker(13)  
> - Silversmith(15)  
> - Silversmith(7)  
> - Skinner(11)  
> - Slaver(18)  
> - Slaver(18)  
> - Soap Maker(9)  
> - Spice Merchant(18)  
> - Spice Merchant(18)  
> - Stabler(19)  
> - Storyteller(18)  
> - Tailor(14)  
> - Tanner(13)  
> - Tanner(13)  
> - Tavern Keeper(19)  
> - Tax Collector(3)  
> - Taxidermist(18)  
> - Taxidermist(18)  
> - Teacher(5)  
> - Teamster(21)  
> - Tiler(21)  
> - Tinker(26)  
> - Tinker(6)  
> - Tobacco Merchant(18)  
> - Tobacco Merchant(18)  
> - Town Crier(30)  
> - Town Justice(7)  
> - Toymaker(5)  
> - Toymaker(8)  
> - Trading Post(26)  
> - Troubadours(18)  
> - Tutor(5)  
> - Undertaker(6)  
> - Used Garment Trader(22)  
> - Vestment Maker(13)  
> - Vintner(11)  
> - Viscount(2)  
> - Wagon Maker(15)  
> - Warehouser(18)  
> - Water Carrier(21)  
> - Weapon Dealer(18)  
> - Weapon Dealer(18)  
> - Weaponsmith(5)  
> - Weaponsmith(5)  
> - Weaver(15)  
> - Wheelwright(16)  
> - Wheelwright(23)  
> - Wine Merchant(9)  
> - Wood Carver(9)  
> - Wood Seller(8)  
> - Wool Merchant(13)  
> - Writer(18)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



