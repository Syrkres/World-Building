---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (25077)
terrain: Mountain Forest 
settlementDescription: 
population: 25077
culture: Barbarian 
technology: Crusades 
leader: 
govermentType: Oligarchy 
demographics: 
- Acrobat(42) 
- Minstrel(42) 
- Storyteller(42) 
- Troubadours(42) 
- Writer(42) 
- Advocate(32) 
- Clerk(72) 
- Council Member(63) 
- Diplomat(11) 
- Judge(36) 
- Mayor(1) 
- Alchemist(21) 
- Chandler(63) 
- Dye Makers(63) 
- Florist(21) 
- Herbalist(21) 
- Potionmakers(21) 
- Sage(12) 
- Spice Merchant(42) 
- Taxidermist(42) 
- Tobacco Merchant(42) 
- Animal Groomer(17) 
- Animal Handler(42) 
- Caravanner(32) 
- Horse Trader(51) 
- Livestock Merchant(34) 
- Stabler(45) 
- Antiquities(42) 
- Armor Dealer(42) 
- Launderer(42) 
- Oil Trader(63) 
- Trading Post(63) 
- Slaver(42) 
- Spice Merchant(42) 
- Taxidermist(42) 
- Tobacco Merchant(42) 
- Warehouser(42) 
- Weapon Dealer(42) 
- Architect(51) 
- Bricklayer(51) 
- Engineer(51) 
- Laborer(51) 
- Mason(51) 
- Painter(Building)(51) 
- Plasterer(51) 
- Roofer(51) 
- Teamster(51) 
- Tiler(51) 
- Armorer(14) 
- Blacksmith(60) 
- Bowyer-Fletcher(21) 
- Jeweler(16) 
- Silversmith(15) 
- Weapon Dealer(42) 
- Weaponsmith(12) 
- Artist(56) 
- Glassblower(42) 
- Goldsmith(28) 
- Inventor(36) 
- Jeweler(26) 
- Magical Artisan(12) 
- Painter(Art)(46) 
- Silversmith(36) 
- Tinker(63) 
- Toymaker(20) 
- Astrologist(12) 
- Conjourer(12) 
- High Mage(12) 
- Historian(12) 
- Librarian(12) 
- Magical Artisan(12) 
- Magical Tutor(12) 
- Professor(12) 
- Scribe(12) 
- SellSpell(12) 
- Teacher(12) 
- Tutor(12) 
- Baker(39) 
- Beer Merchant(23) 
- Brewer(6) 
- Butcher(26) 
- Chicken Butcher(26) 
- Cook(27) 
- Dairy Seller(126) 
- Distiller(23) 
- Hay Merchant(126) 
- Fisherman(32) 
- Fishmonger(32) 
- Grain Merchant(7) 
- Grocer(19) 
- Meat Butcher(21) 
- Miller(63) 
- Pastry Maker(32) 
- Vintner(27) 
- Banker(14) 
- Pawnbroker(14) 
- Barbarian(126) 
- Brigand(126) 
- Captain(126) 
- Mountainman(126) 
- Barbarian(23) 
- Cartographer(21) 
- Guide(42) 
- Huntsman(63) 
- Mountainman(20) 
- Pathfinder(21) 
- Scout(21) 
- Slaver(42) 
- Barrel Maker(27) 
- Basket Maker(36) 
- Book Binder(13) 
- Bookseller(12) 
- Buckle Maker(20) 
- Candle Maker(16) 
- Clock Maker(12) 
- Cobbler(39) 
- Cooper(30) 
- Cutler(13) 
- Engraver(12) 
- Furniture Maker(39) 
- Glassblower(18) 
- Glazier(12) 
- Glove Merchant(34) 
- Goldsmith(18) 
- Harness Maker(42) 
- Hat Maker(17) 
- Instrument Maker(12) 
- Kettle Maker(11) 
- Locksmith(15) 
- Perfumer(18) 
- Potter(42) 
- Rope Maker(30) 
- Rug Maker(16) 
- Saddler(32) 
- Sculptor(11) 
- Shoe Maker(30) 
- Soap Maker(21) 
- Tanner(32) 
- Tinker(14) 
- Toymaker(12) 
- Weaponsmith(12) 
- Weaver(36) 
- Wheelwright(56) 
- Wine Merchant(21) 
- Wool Merchant(32) 
- Lord(9) 
- Knight(9) 
- Baron(6) 
- Viscount(4) 
- Earl(3) 
- Count(3) 
- Duke(2) 
- ArchDuke(1) 
- Barrel Maker(46) 
- Bowyer-Fletcher(21) 
- Carpenter(72) 
- Roofer(51) 
- Wagon Maker(36) 
- Wheelwright(39) 
- Wood Carver(21) 
- Wood Seller(19) 
- Barber(21) 
- Bleacher(21) 
- Physic/Chirurgeon(21) 
- Bather(17) 
- Brigand(42) 
- Crime Lord(11) 
- Crook(51) 
- Goon(56) 
- Brothel Keeper(18) 
- Innkeeper(34) 
- Tavern Keeper(46) 
- Buckle Maker(34) 
- Cobbler(30) 
- Draper(21) 
- Furrier(56) 
- Girdler(19) 
- Haberdasher(17) 
- Launderer(34) 
- Leatherworker(23) 
- Purse Maker(21) 
- Shoe Maker(30) 
- Tailor(34) 
- Tanner(32) 
- Used Garment Trader(53) 
- Vestment Maker(30) 
- Chandler(63) 
- Dye Makers(63) 
- Oil Trader(63) 
- Cleric(46) 
- High Priest(18) 
- Missionary(168) 
- Preacher(101) 
- Priest(56) 
- Farmer(1254) 
- Homestead(1672) 
- Farmer - Cabbage(126) 
- Farmer - Cattle Herder(126) 
- Farmer - Corn(126) 
- Farmer - Cow Herder(126) 
- Farmer - Dairy(126) 
- Farmer - Goat Herder(126) 
- Farmer - Pig Herder(126) 
- Farmer - Potato(126) 
- Farmer - Sheep Herder(126) 
- Farmer - Wheat(126) 
- Farmer(Special)(126) 
- Dungsweeper(36) 
- Illuminator(26) 
- Messenger(39) 
- Tax Collector(7) 
- Town Crier(72) 
- Town Justice(17) 
- Undertaker(14) 
- Water Carrier(51) 
- Leatherworker(26) 
- Skinner(26) 
- Naval Outfitter(13) 
- Pirate(63) 
- Sail Maker(36) 
- Sailor(84) 
- Ship Builder(15) 
imports: 
- Lard  
exports: 
- Copper  
defenses: Wood Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(42)  
> - Advocate(32)  
> - Alchemist(21)  
> - Animal Groomer(17)  
> - Animal Handler(42)  
> - Antiquities(42)  
> - ArchDuke(1)  
> - Architect(51)  
> - Armor Dealer(42)  
> - Armorer(14)  
> - Artist(56)  
> - Astrologist(12)  
> - Baker(39)  
> - Banker(14)  
> - Barbarian(126)  
> - Barbarian(23)  
> - Barber(21)  
> - Baron(6)  
> - Barrel Maker(27)  
> - Barrel Maker(46)  
> - Basket Maker(36)  
> - Bather(17)  
> - Beer Merchant(23)  
> - Blacksmith(60)  
> - Bleacher(21)  
> - Book Binder(13)  
> - Bookseller(12)  
> - Bowyer-Fletcher(21)  
> - Bowyer-Fletcher(21)  
> - Brewer(6)  
> - Bricklayer(51)  
> - Brigand(126)  
> - Brigand(42)  
> - Brothel Keeper(18)  
> - Buckle Maker(20)  
> - Buckle Maker(34)  
> - Butcher(26)  
> - Candle Maker(16)  
> - Captain(126)  
> - Caravanner(32)  
> - Carpenter(72)  
> - Cartographer(21)  
> - Chandler(63)  
> - Chandler(63)  
> - Chicken Butcher(26)  
> - Cleric(46)  
> - Clerk(72)  
> - Clock Maker(12)  
> - Cobbler(30)  
> - Cobbler(39)  
> - Conjourer(12)  
> - Cook(27)  
> - Cooper(30)  
> - Council Member(63)  
> - Count(3)  
> - Crime Lord(11)  
> - Crook(51)  
> - Cutler(13)  
> - Dairy Seller(126)  
> - Diplomat(11)  
> - Distiller(23)  
> - Draper(21)  
> - Duke(2)  
> - Dungsweeper(36)  
> - Dye Makers(63)  
> - Dye Makers(63)  
> - Earl(3)  
> - Engineer(51)  
> - Engraver(12)  
> - Farmer - Cabbage(126)  
> - Farmer - Cattle Herder(126)  
> - Farmer - Corn(126)  
> - Farmer - Cow Herder(126)  
> - Farmer - Dairy(126)  
> - Farmer - Goat Herder(126)  
> - Farmer - Pig Herder(126)  
> - Farmer - Potato(126)  
> - Farmer - Sheep Herder(126)  
> - Farmer - Wheat(126)  
> - Farmer(1254)  
> - Farmer(Special)(126)  
> - Fisherman(32)  
> - Fishmonger(32)  
> - Florist(21)  
> - Furniture Maker(39)  
> - Furrier(56)  
> - Girdler(19)  
> - Glassblower(18)  
> - Glassblower(42)  
> - Glazier(12)  
> - Glove Merchant(34)  
> - Goldsmith(18)  
> - Goldsmith(28)  
> - Goon(56)  
> - Grain Merchant(7)  
> - Grocer(19)  
> - Guide(42)  
> - Haberdasher(17)  
> - Harness Maker(42)  
> - Hat Maker(17)  
> - Hay Merchant(126)  
> - Herbalist(21)  
> - High Mage(12)  
> - High Priest(18)  
> - Historian(12)  
> - Homestead(1672)  
> - Horse Trader(51)  
> - Huntsman(63)  
> - Illuminator(26)  
> - Innkeeper(34)  
> - Instrument Maker(12)  
> - Inventor(36)  
> - Jeweler(16)  
> - Jeweler(26)  
> - Judge(36)  
> - Kettle Maker(11)  
> - Knight(9)  
> - Laborer(51)  
> - Launderer(34)  
> - Launderer(42)  
> - Leatherworker(23)  
> - Leatherworker(26)  
> - Librarian(12)  
> - Livestock Merchant(34)  
> - Locksmith(15)  
> - Lord(9)  
> - Magical Artisan(12)  
> - Magical Artisan(12)  
> - Magical Tutor(12)  
> - Mason(51)  
> - Mayor(1)  
> - Meat Butcher(21)  
> - Messenger(39)  
> - Miller(63)  
> - Minstrel(42)  
> - Missionary(168)  
> - Mountainman(126)  
> - Mountainman(20)  
> - Naval Outfitter(13)  
> - Oil Trader(63)  
> - Oil Trader(63)  
> - Painter(Art)(46)  
> - Painter(Building)(51)  
> - Pastry Maker(32)  
> - Pathfinder(21)  
> - Pawnbroker(14)  
> - Perfumer(18)  
> - Physic/Chirurgeon(21)  
> - Pirate(63)  
> - Plasterer(51)  
> - Potionmakers(21)  
> - Potter(42)  
> - Preacher(101)  
> - Priest(56)  
> - Professor(12)  
> - Purse Maker(21)  
> - Roofer(51)  
> - Roofer(51)  
> - Rope Maker(30)  
> - Rug Maker(16)  
> - Saddler(32)  
> - Sage(12)  
> - Sail Maker(36)  
> - Sailor(84)  
> - Scout(21)  
> - Scribe(12)  
> - Sculptor(11)  
> - SellSpell(12)  
> - Ship Builder(15)  
> - Shoe Maker(30)  
> - Shoe Maker(30)  
> - Silversmith(15)  
> - Silversmith(36)  
> - Skinner(26)  
> - Slaver(42)  
> - Slaver(42)  
> - Soap Maker(21)  
> - Spice Merchant(42)  
> - Spice Merchant(42)  
> - Stabler(45)  
> - Storyteller(42)  
> - Tailor(34)  
> - Tanner(32)  
> - Tanner(32)  
> - Tavern Keeper(46)  
> - Tax Collector(7)  
> - Taxidermist(42)  
> - Taxidermist(42)  
> - Teacher(12)  
> - Teamster(51)  
> - Tiler(51)  
> - Tinker(14)  
> - Tinker(63)  
> - Tobacco Merchant(42)  
> - Tobacco Merchant(42)  
> - Town Crier(72)  
> - Town Justice(17)  
> - Toymaker(12)  
> - Toymaker(20)  
> - Trading Post(63)  
> - Troubadours(42)  
> - Tutor(12)  
> - Undertaker(14)  
> - Used Garment Trader(53)  
> - Vestment Maker(30)  
> - Vintner(27)  
> - Viscount(4)  
> - Wagon Maker(36)  
> - Warehouser(42)  
> - Water Carrier(51)  
> - Weapon Dealer(42)  
> - Weapon Dealer(42)  
> - Weaponsmith(12)  
> - Weaponsmith(12)  
> - Weaver(36)  
> - Wheelwright(39)  
> - Wheelwright(56)  
> - Wine Merchant(21)  
> - Wood Carver(21)  
> - Wood Seller(19)  
> - Wool Merchant(32)  
> - Writer(42)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(42)  
> - Advocate(32)  
> - Alchemist(21)  
> - Animal Groomer(17)  
> - Animal Handler(42)  
> - Antiquities(42)  
> - ArchDuke(1)  
> - Architect(51)  
> - Armor Dealer(42)  
> - Armorer(14)  
> - Artist(56)  
> - Astrologist(12)  
> - Baker(39)  
> - Banker(14)  
> - Barbarian(126)  
> - Barbarian(23)  
> - Barber(21)  
> - Baron(6)  
> - Barrel Maker(27)  
> - Barrel Maker(46)  
> - Basket Maker(36)  
> - Bather(17)  
> - Beer Merchant(23)  
> - Blacksmith(60)  
> - Bleacher(21)  
> - Book Binder(13)  
> - Bookseller(12)  
> - Bowyer-Fletcher(21)  
> - Bowyer-Fletcher(21)  
> - Brewer(6)  
> - Bricklayer(51)  
> - Brigand(126)  
> - Brigand(42)  
> - Brothel Keeper(18)  
> - Buckle Maker(20)  
> - Buckle Maker(34)  
> - Butcher(26)  
> - Candle Maker(16)  
> - Captain(126)  
> - Caravanner(32)  
> - Carpenter(72)  
> - Cartographer(21)  
> - Chandler(63)  
> - Chandler(63)  
> - Chicken Butcher(26)  
> - Cleric(46)  
> - Clerk(72)  
> - Clock Maker(12)  
> - Cobbler(30)  
> - Cobbler(39)  
> - Conjourer(12)  
> - Cook(27)  
> - Cooper(30)  
> - Council Member(63)  
> - Count(3)  
> - Crime Lord(11)  
> - Crook(51)  
> - Cutler(13)  
> - Dairy Seller(126)  
> - Diplomat(11)  
> - Distiller(23)  
> - Draper(21)  
> - Duke(2)  
> - Dungsweeper(36)  
> - Dye Makers(63)  
> - Dye Makers(63)  
> - Earl(3)  
> - Engineer(51)  
> - Engraver(12)  
> - Farmer - Cabbage(126)  
> - Farmer - Cattle Herder(126)  
> - Farmer - Corn(126)  
> - Farmer - Cow Herder(126)  
> - Farmer - Dairy(126)  
> - Farmer - Goat Herder(126)  
> - Farmer - Pig Herder(126)  
> - Farmer - Potato(126)  
> - Farmer - Sheep Herder(126)  
> - Farmer - Wheat(126)  
> - Farmer(1254)  
> - Farmer(Special)(126)  
> - Fisherman(32)  
> - Fishmonger(32)  
> - Florist(21)  
> - Furniture Maker(39)  
> - Furrier(56)  
> - Girdler(19)  
> - Glassblower(18)  
> - Glassblower(42)  
> - Glazier(12)  
> - Glove Merchant(34)  
> - Goldsmith(18)  
> - Goldsmith(28)  
> - Goon(56)  
> - Grain Merchant(7)  
> - Grocer(19)  
> - Guide(42)  
> - Haberdasher(17)  
> - Harness Maker(42)  
> - Hat Maker(17)  
> - Hay Merchant(126)  
> - Herbalist(21)  
> - High Mage(12)  
> - High Priest(18)  
> - Historian(12)  
> - Homestead(1672)  
> - Horse Trader(51)  
> - Huntsman(63)  
> - Illuminator(26)  
> - Innkeeper(34)  
> - Instrument Maker(12)  
> - Inventor(36)  
> - Jeweler(16)  
> - Jeweler(26)  
> - Judge(36)  
> - Kettle Maker(11)  
> - Knight(9)  
> - Laborer(51)  
> - Launderer(34)  
> - Launderer(42)  
> - Leatherworker(23)  
> - Leatherworker(26)  
> - Librarian(12)  
> - Livestock Merchant(34)  
> - Locksmith(15)  
> - Lord(9)  
> - Magical Artisan(12)  
> - Magical Artisan(12)  
> - Magical Tutor(12)  
> - Mason(51)  
> - Mayor(1)  
> - Meat Butcher(21)  
> - Messenger(39)  
> - Miller(63)  
> - Minstrel(42)  
> - Missionary(168)  
> - Mountainman(126)  
> - Mountainman(20)  
> - Naval Outfitter(13)  
> - Oil Trader(63)  
> - Oil Trader(63)  
> - Painter(Art)(46)  
> - Painter(Building)(51)  
> - Pastry Maker(32)  
> - Pathfinder(21)  
> - Pawnbroker(14)  
> - Perfumer(18)  
> - Physic/Chirurgeon(21)  
> - Pirate(63)  
> - Plasterer(51)  
> - Potionmakers(21)  
> - Potter(42)  
> - Preacher(101)  
> - Priest(56)  
> - Professor(12)  
> - Purse Maker(21)  
> - Roofer(51)  
> - Roofer(51)  
> - Rope Maker(30)  
> - Rug Maker(16)  
> - Saddler(32)  
> - Sage(12)  
> - Sail Maker(36)  
> - Sailor(84)  
> - Scout(21)  
> - Scribe(12)  
> - Sculptor(11)  
> - SellSpell(12)  
> - Ship Builder(15)  
> - Shoe Maker(30)  
> - Shoe Maker(30)  
> - Silversmith(15)  
> - Silversmith(36)  
> - Skinner(26)  
> - Slaver(42)  
> - Slaver(42)  
> - Soap Maker(21)  
> - Spice Merchant(42)  
> - Spice Merchant(42)  
> - Stabler(45)  
> - Storyteller(42)  
> - Tailor(34)  
> - Tanner(32)  
> - Tanner(32)  
> - Tavern Keeper(46)  
> - Tax Collector(7)  
> - Taxidermist(42)  
> - Taxidermist(42)  
> - Teacher(12)  
> - Teamster(51)  
> - Tiler(51)  
> - Tinker(14)  
> - Tinker(63)  
> - Tobacco Merchant(42)  
> - Tobacco Merchant(42)  
> - Town Crier(72)  
> - Town Justice(17)  
> - Toymaker(12)  
> - Toymaker(20)  
> - Trading Post(63)  
> - Troubadours(42)  
> - Tutor(12)  
> - Undertaker(14)  
> - Used Garment Trader(53)  
> - Vestment Maker(30)  
> - Vintner(27)  
> - Viscount(4)  
> - Wagon Maker(36)  
> - Warehouser(42)  
> - Water Carrier(51)  
> - Weapon Dealer(42)  
> - Weapon Dealer(42)  
> - Weaponsmith(12)  
> - Weaponsmith(12)  
> - Weaver(36)  
> - Wheelwright(39)  
> - Wheelwright(56)  
> - Wine Merchant(21)  
> - Wood Carver(21)  
> - Wood Seller(19)  
> - Wool Merchant(32)  
> - Writer(42)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



