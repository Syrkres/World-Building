---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallCity
kingdom: KingdomName
region: RegionName
settlementName: Named SmallCity (11042)
terrain: Mountain Forest Boreal 
settlementDescription: 
population: 11042
culture: Arabic 
technology: Crusades 
leader: 
govermentType: Confederation 
demographics: 
- Acrobat(19) 
- Minstrel(19) 
- Storyteller(19) 
- Troubadours(19) 
- Writer(19) 
- Advocate(14) 
- Clerk(32) 
- Council Member(28) 
- Diplomat(5) 
- Judge(16) 
- Mayor(1) 
- Alchemist(10) 
- Chandler(28) 
- Dye Makers(28) 
- Florist(10) 
- Herbalist(10) 
- Potionmakers(10) 
- Sage(6) 
- Spice Merchant(19) 
- Taxidermist(19) 
- Tobacco Merchant(19) 
- Animal Groomer(8) 
- Animal Handler(19) 
- Caravanner(14) 
- Horse Trader(23) 
- Livestock Merchant(15) 
- Stabler(20) 
- Antiquities(19) 
- Armor Dealer(19) 
- Launderer(19) 
- Oil Trader(28) 
- Trading Post(28) 
- Slaver(19) 
- Spice Merchant(19) 
- Taxidermist(19) 
- Tobacco Merchant(19) 
- Warehouser(19) 
- Weapon Dealer(19) 
- Architect(23) 
- Bricklayer(23) 
- Engineer(23) 
- Laborer(23) 
- Mason(23) 
- Painter(Building)(23) 
- Plasterer(23) 
- Roofer(23) 
- Teamster(23) 
- Tiler(23) 
- Armorer(6) 
- Blacksmith(26) 
- Bowyer-Fletcher(9) 
- Jeweler(7) 
- Silversmith(7) 
- Weapon Dealer(19) 
- Weaponsmith(6) 
- Artist(25) 
- Glassblower(19) 
- Goldsmith(13) 
- Inventor(16) 
- Jeweler(12) 
- Magical Artisan(6) 
- Painter(Art)(21) 
- Silversmith(16) 
- Tinker(28) 
- Toymaker(9) 
- Astrologist(6) 
- Conjourer(6) 
- High Mage(6) 
- Historian(6) 
- Librarian(6) 
- Magical Artisan(6) 
- Magical Tutor(6) 
- Professor(6) 
- Scribe(6) 
- SellSpell(6) 
- Teacher(6) 
- Tutor(6) 
- Baker(17) 
- Beer Merchant(11) 
- Brewer(3) 
- Butcher(12) 
- Chicken Butcher(12) 
- Cook(12) 
- Dairy Seller(56) 
- Distiller(11) 
- Hay Merchant(56) 
- Fisherman(14) 
- Fishmonger(14) 
- Grain Merchant(3) 
- Grocer(9) 
- Meat Butcher(10) 
- Miller(28) 
- Pastry Maker(14) 
- Vintner(12) 
- Banker(7) 
- Pawnbroker(7) 
- Barbarian(56) 
- Brigand(56) 
- Captain(56) 
- Mountainman(56) 
- Barbarian(11) 
- Cartographer(10) 
- Guide(19) 
- Huntsman(28) 
- Mountainman(9) 
- Pathfinder(10) 
- Scout(10) 
- Slaver(19) 
- Barrel Maker(12) 
- Basket Maker(16) 
- Book Binder(6) 
- Bookseller(6) 
- Buckle Maker(9) 
- Candle Maker(7) 
- Clock Maker(6) 
- Cobbler(17) 
- Cooper(13) 
- Cutler(6) 
- Engraver(6) 
- Furniture Maker(17) 
- Glassblower(8) 
- Glazier(6) 
- Glove Merchant(15) 
- Goldsmith(8) 
- Harness Maker(19) 
- Hat Maker(8) 
- Instrument Maker(6) 
- Kettle Maker(5) 
- Locksmith(7) 
- Perfumer(8) 
- Potter(19) 
- Rope Maker(13) 
- Rug Maker(7) 
- Saddler(14) 
- Sculptor(5) 
- Shoe Maker(13) 
- Soap Maker(10) 
- Tanner(14) 
- Tinker(7) 
- Toymaker(6) 
- Weaponsmith(6) 
- Weaver(16) 
- Wheelwright(25) 
- Wine Merchant(10) 
- Wool Merchant(14) 
- Lord(4) 
- Knight(4) 
- Baron(3) 
- Viscount(2) 
- Earl(1) 
- Count(1) 
- Duke(1) 
- Barrel Maker(21) 
- Bowyer-Fletcher(9) 
- Carpenter(32) 
- Roofer(23) 
- Wagon Maker(16) 
- Wheelwright(17) 
- Wood Carver(9) 
- Wood Seller(9) 
- Barber(10) 
- Bleacher(10) 
- Physic/Chirurgeon(10) 
- Bather(8) 
- Brigand(19) 
- Crime Lord(5) 
- Crook(23) 
- Goon(25) 
- Brothel Keeper(8) 
- Innkeeper(15) 
- Tavern Keeper(21) 
- Buckle Maker(15) 
- Cobbler(13) 
- Draper(10) 
- Furrier(25) 
- Girdler(9) 
- Haberdasher(8) 
- Launderer(15) 
- Leatherworker(11) 
- Purse Maker(10) 
- Shoe Maker(13) 
- Tailor(15) 
- Tanner(14) 
- Used Garment Trader(24) 
- Vestment Maker(13) 
- Chandler(28) 
- Dye Makers(28) 
- Oil Trader(28) 
- Cleric(21) 
- High Priest(8) 
- Missionary(74) 
- Preacher(45) 
- Priest(25) 
- Farmer(553) 
- Homestead(737) 
- Farmer - Cabbage(56) 
- Farmer - Cattle Herder(56) 
- Farmer - Corn(56) 
- Farmer - Cow Herder(56) 
- Farmer - Dairy(56) 
- Farmer - Goat Herder(56) 
- Farmer - Pig Herder(56) 
- Farmer - Potato(56) 
- Farmer - Sheep Herder(56) 
- Farmer - Wheat(56) 
- Farmer(Special)(56) 
- Dungsweeper(16) 
- Illuminator(12) 
- Messenger(17) 
- Tax Collector(3) 
- Town Crier(32) 
- Town Justice(8) 
- Undertaker(7) 
- Water Carrier(23) 
- Leatherworker(12) 
- Skinner(12) 
- Naval Outfitter(6) 
- Pirate(28) 
- Sail Maker(16) 
- Sailor(37) 
- Ship Builder(7) 
imports: 
- Oak Lumber  
exports: 
- Metals  
defenses: Killing Fields 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(19)  
> - Advocate(14)  
> - Alchemist(10)  
> - Animal Groomer(8)  
> - Animal Handler(19)  
> - Antiquities(19)  
> - Architect(23)  
> - Armor Dealer(19)  
> - Armorer(6)  
> - Artist(25)  
> - Astrologist(6)  
> - Baker(17)  
> - Banker(7)  
> - Barbarian(11)  
> - Barbarian(56)  
> - Barber(10)  
> - Baron(3)  
> - Barrel Maker(12)  
> - Barrel Maker(21)  
> - Basket Maker(16)  
> - Bather(8)  
> - Beer Merchant(11)  
> - Blacksmith(26)  
> - Bleacher(10)  
> - Book Binder(6)  
> - Bookseller(6)  
> - Bowyer-Fletcher(9)  
> - Bowyer-Fletcher(9)  
> - Brewer(3)  
> - Bricklayer(23)  
> - Brigand(19)  
> - Brigand(56)  
> - Brothel Keeper(8)  
> - Buckle Maker(15)  
> - Buckle Maker(9)  
> - Butcher(12)  
> - Candle Maker(7)  
> - Captain(56)  
> - Caravanner(14)  
> - Carpenter(32)  
> - Cartographer(10)  
> - Chandler(28)  
> - Chandler(28)  
> - Chicken Butcher(12)  
> - Cleric(21)  
> - Clerk(32)  
> - Clock Maker(6)  
> - Cobbler(13)  
> - Cobbler(17)  
> - Conjourer(6)  
> - Cook(12)  
> - Cooper(13)  
> - Council Member(28)  
> - Count(1)  
> - Crime Lord(5)  
> - Crook(23)  
> - Cutler(6)  
> - Dairy Seller(56)  
> - Diplomat(5)  
> - Distiller(11)  
> - Draper(10)  
> - Duke(1)  
> - Dungsweeper(16)  
> - Dye Makers(28)  
> - Dye Makers(28)  
> - Earl(1)  
> - Engineer(23)  
> - Engraver(6)  
> - Farmer - Cabbage(56)  
> - Farmer - Cattle Herder(56)  
> - Farmer - Corn(56)  
> - Farmer - Cow Herder(56)  
> - Farmer - Dairy(56)  
> - Farmer - Goat Herder(56)  
> - Farmer - Pig Herder(56)  
> - Farmer - Potato(56)  
> - Farmer - Sheep Herder(56)  
> - Farmer - Wheat(56)  
> - Farmer(553)  
> - Farmer(Special)(56)  
> - Fisherman(14)  
> - Fishmonger(14)  
> - Florist(10)  
> - Furniture Maker(17)  
> - Furrier(25)  
> - Girdler(9)  
> - Glassblower(19)  
> - Glassblower(8)  
> - Glazier(6)  
> - Glove Merchant(15)  
> - Goldsmith(13)  
> - Goldsmith(8)  
> - Goon(25)  
> - Grain Merchant(3)  
> - Grocer(9)  
> - Guide(19)  
> - Haberdasher(8)  
> - Harness Maker(19)  
> - Hat Maker(8)  
> - Hay Merchant(56)  
> - Herbalist(10)  
> - High Mage(6)  
> - High Priest(8)  
> - Historian(6)  
> - Homestead(737)  
> - Horse Trader(23)  
> - Huntsman(28)  
> - Illuminator(12)  
> - Innkeeper(15)  
> - Instrument Maker(6)  
> - Inventor(16)  
> - Jeweler(12)  
> - Jeweler(7)  
> - Judge(16)  
> - Kettle Maker(5)  
> - Knight(4)  
> - Laborer(23)  
> - Launderer(15)  
> - Launderer(19)  
> - Leatherworker(11)  
> - Leatherworker(12)  
> - Librarian(6)  
> - Livestock Merchant(15)  
> - Locksmith(7)  
> - Lord(4)  
> - Magical Artisan(6)  
> - Magical Artisan(6)  
> - Magical Tutor(6)  
> - Mason(23)  
> - Mayor(1)  
> - Meat Butcher(10)  
> - Messenger(17)  
> - Miller(28)  
> - Minstrel(19)  
> - Missionary(74)  
> - Mountainman(56)  
> - Mountainman(9)  
> - Naval Outfitter(6)  
> - Oil Trader(28)  
> - Oil Trader(28)  
> - Painter(Art)(21)  
> - Painter(Building)(23)  
> - Pastry Maker(14)  
> - Pathfinder(10)  
> - Pawnbroker(7)  
> - Perfumer(8)  
> - Physic/Chirurgeon(10)  
> - Pirate(28)  
> - Plasterer(23)  
> - Potionmakers(10)  
> - Potter(19)  
> - Preacher(45)  
> - Priest(25)  
> - Professor(6)  
> - Purse Maker(10)  
> - Roofer(23)  
> - Roofer(23)  
> - Rope Maker(13)  
> - Rug Maker(7)  
> - Saddler(14)  
> - Sage(6)  
> - Sail Maker(16)  
> - Sailor(37)  
> - Scout(10)  
> - Scribe(6)  
> - Sculptor(5)  
> - SellSpell(6)  
> - Ship Builder(7)  
> - Shoe Maker(13)  
> - Shoe Maker(13)  
> - Silversmith(16)  
> - Silversmith(7)  
> - Skinner(12)  
> - Slaver(19)  
> - Slaver(19)  
> - Soap Maker(10)  
> - Spice Merchant(19)  
> - Spice Merchant(19)  
> - Stabler(20)  
> - Storyteller(19)  
> - Tailor(15)  
> - Tanner(14)  
> - Tanner(14)  
> - Tavern Keeper(21)  
> - Tax Collector(3)  
> - Taxidermist(19)  
> - Taxidermist(19)  
> - Teacher(6)  
> - Teamster(23)  
> - Tiler(23)  
> - Tinker(28)  
> - Tinker(7)  
> - Tobacco Merchant(19)  
> - Tobacco Merchant(19)  
> - Town Crier(32)  
> - Town Justice(8)  
> - Toymaker(6)  
> - Toymaker(9)  
> - Trading Post(28)  
> - Troubadours(19)  
> - Tutor(6)  
> - Undertaker(7)  
> - Used Garment Trader(24)  
> - Vestment Maker(13)  
> - Vintner(12)  
> - Viscount(2)  
> - Wagon Maker(16)  
> - Warehouser(19)  
> - Water Carrier(23)  
> - Weapon Dealer(19)  
> - Weapon Dealer(19)  
> - Weaponsmith(6)  
> - Weaponsmith(6)  
> - Weaver(16)  
> - Wheelwright(17)  
> - Wheelwright(25)  
> - Wine Merchant(10)  
> - Wood Carver(9)  
> - Wood Seller(9)  
> - Wool Merchant(14)  
> - Writer(19)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(19)  
> - Advocate(14)  
> - Alchemist(10)  
> - Animal Groomer(8)  
> - Animal Handler(19)  
> - Antiquities(19)  
> - Architect(23)  
> - Armor Dealer(19)  
> - Armorer(6)  
> - Artist(25)  
> - Astrologist(6)  
> - Baker(17)  
> - Banker(7)  
> - Barbarian(11)  
> - Barbarian(56)  
> - Barber(10)  
> - Baron(3)  
> - Barrel Maker(12)  
> - Barrel Maker(21)  
> - Basket Maker(16)  
> - Bather(8)  
> - Beer Merchant(11)  
> - Blacksmith(26)  
> - Bleacher(10)  
> - Book Binder(6)  
> - Bookseller(6)  
> - Bowyer-Fletcher(9)  
> - Bowyer-Fletcher(9)  
> - Brewer(3)  
> - Bricklayer(23)  
> - Brigand(19)  
> - Brigand(56)  
> - Brothel Keeper(8)  
> - Buckle Maker(15)  
> - Buckle Maker(9)  
> - Butcher(12)  
> - Candle Maker(7)  
> - Captain(56)  
> - Caravanner(14)  
> - Carpenter(32)  
> - Cartographer(10)  
> - Chandler(28)  
> - Chandler(28)  
> - Chicken Butcher(12)  
> - Cleric(21)  
> - Clerk(32)  
> - Clock Maker(6)  
> - Cobbler(13)  
> - Cobbler(17)  
> - Conjourer(6)  
> - Cook(12)  
> - Cooper(13)  
> - Council Member(28)  
> - Count(1)  
> - Crime Lord(5)  
> - Crook(23)  
> - Cutler(6)  
> - Dairy Seller(56)  
> - Diplomat(5)  
> - Distiller(11)  
> - Draper(10)  
> - Duke(1)  
> - Dungsweeper(16)  
> - Dye Makers(28)  
> - Dye Makers(28)  
> - Earl(1)  
> - Engineer(23)  
> - Engraver(6)  
> - Farmer - Cabbage(56)  
> - Farmer - Cattle Herder(56)  
> - Farmer - Corn(56)  
> - Farmer - Cow Herder(56)  
> - Farmer - Dairy(56)  
> - Farmer - Goat Herder(56)  
> - Farmer - Pig Herder(56)  
> - Farmer - Potato(56)  
> - Farmer - Sheep Herder(56)  
> - Farmer - Wheat(56)  
> - Farmer(553)  
> - Farmer(Special)(56)  
> - Fisherman(14)  
> - Fishmonger(14)  
> - Florist(10)  
> - Furniture Maker(17)  
> - Furrier(25)  
> - Girdler(9)  
> - Glassblower(19)  
> - Glassblower(8)  
> - Glazier(6)  
> - Glove Merchant(15)  
> - Goldsmith(13)  
> - Goldsmith(8)  
> - Goon(25)  
> - Grain Merchant(3)  
> - Grocer(9)  
> - Guide(19)  
> - Haberdasher(8)  
> - Harness Maker(19)  
> - Hat Maker(8)  
> - Hay Merchant(56)  
> - Herbalist(10)  
> - High Mage(6)  
> - High Priest(8)  
> - Historian(6)  
> - Homestead(737)  
> - Horse Trader(23)  
> - Huntsman(28)  
> - Illuminator(12)  
> - Innkeeper(15)  
> - Instrument Maker(6)  
> - Inventor(16)  
> - Jeweler(12)  
> - Jeweler(7)  
> - Judge(16)  
> - Kettle Maker(5)  
> - Knight(4)  
> - Laborer(23)  
> - Launderer(15)  
> - Launderer(19)  
> - Leatherworker(11)  
> - Leatherworker(12)  
> - Librarian(6)  
> - Livestock Merchant(15)  
> - Locksmith(7)  
> - Lord(4)  
> - Magical Artisan(6)  
> - Magical Artisan(6)  
> - Magical Tutor(6)  
> - Mason(23)  
> - Mayor(1)  
> - Meat Butcher(10)  
> - Messenger(17)  
> - Miller(28)  
> - Minstrel(19)  
> - Missionary(74)  
> - Mountainman(56)  
> - Mountainman(9)  
> - Naval Outfitter(6)  
> - Oil Trader(28)  
> - Oil Trader(28)  
> - Painter(Art)(21)  
> - Painter(Building)(23)  
> - Pastry Maker(14)  
> - Pathfinder(10)  
> - Pawnbroker(7)  
> - Perfumer(8)  
> - Physic/Chirurgeon(10)  
> - Pirate(28)  
> - Plasterer(23)  
> - Potionmakers(10)  
> - Potter(19)  
> - Preacher(45)  
> - Priest(25)  
> - Professor(6)  
> - Purse Maker(10)  
> - Roofer(23)  
> - Roofer(23)  
> - Rope Maker(13)  
> - Rug Maker(7)  
> - Saddler(14)  
> - Sage(6)  
> - Sail Maker(16)  
> - Sailor(37)  
> - Scout(10)  
> - Scribe(6)  
> - Sculptor(5)  
> - SellSpell(6)  
> - Ship Builder(7)  
> - Shoe Maker(13)  
> - Shoe Maker(13)  
> - Silversmith(16)  
> - Silversmith(7)  
> - Skinner(12)  
> - Slaver(19)  
> - Slaver(19)  
> - Soap Maker(10)  
> - Spice Merchant(19)  
> - Spice Merchant(19)  
> - Stabler(20)  
> - Storyteller(19)  
> - Tailor(15)  
> - Tanner(14)  
> - Tanner(14)  
> - Tavern Keeper(21)  
> - Tax Collector(3)  
> - Taxidermist(19)  
> - Taxidermist(19)  
> - Teacher(6)  
> - Teamster(23)  
> - Tiler(23)  
> - Tinker(28)  
> - Tinker(7)  
> - Tobacco Merchant(19)  
> - Tobacco Merchant(19)  
> - Town Crier(32)  
> - Town Justice(8)  
> - Toymaker(6)  
> - Toymaker(9)  
> - Trading Post(28)  
> - Troubadours(19)  
> - Tutor(6)  
> - Undertaker(7)  
> - Used Garment Trader(24)  
> - Vestment Maker(13)  
> - Vintner(12)  
> - Viscount(2)  
> - Wagon Maker(16)  
> - Warehouser(19)  
> - Water Carrier(23)  
> - Weapon Dealer(19)  
> - Weapon Dealer(19)  
> - Weaponsmith(6)  
> - Weaponsmith(6)  
> - Weaver(16)  
> - Wheelwright(17)  
> - Wheelwright(25)  
> - Wine Merchant(10)  
> - Wood Carver(9)  
> - Wood Seller(9)  
> - Wool Merchant(14)  
> - Writer(19)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



