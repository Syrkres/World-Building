---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallTown
kingdom: KingdomName
region: RegionName
settlementName: Named SmallTown (1165)
terrain: Desert 
settlementDescription: 
population: 1165
culture: Egyptian 
technology: Bronze Age 
leader: 
govermentType: Oligarchy 
demographics: 
- Acrobat(1) 
- Minstrel(1) 
- Storyteller(1) 
- Troubadours(1) 
- Writer(1) 
- Advocate(2) 
- Clerk(4) 
- Council Member(3) 
- Judge(2) 
- Mayor(1) 
- Chandler(3) 
- Dye Makers(3) 
- Spice Merchant(1) 
- Taxidermist(1) 
- Tobacco Merchant(1) 
- Animal Handler(2) 
- Caravanner(2) 
- Horse Trader(3) 
- Livestock Merchant(1) 
- Stabler(3) 
- Antiquities(1) 
- Armor Dealer(1) 
- Launderer(1) 
- Oil Trader(3) 
- Trading Post(3) 
- Slaver(1) 
- Spice Merchant(1) 
- Taxidermist(1) 
- Tobacco Merchant(1) 
- Warehouser(1) 
- Weapon Dealer(1) 
- Architect(3) 
- Bricklayer(3) 
- Engineer(3) 
- Laborer(3) 
- Mason(3) 
- Painter(Building)(3) 
- Plasterer(3) 
- Roofer(3) 
- Teamster(3) 
- Tiler(3) 
- Blacksmith(3) 
- Bowyer-Fletcher(1) 
- Jeweler(1) 
- Silversmith(1) 
- Weapon Dealer(1) 
- Artist(3) 
- Glassblower(2) 
- Goldsmith(1) 
- Inventor(2) 
- Jeweler(1) 
- Painter(Art)(3) 
- Silversmith(1) 
- Tinker(3) 
- Baker(1) 
- Beer Merchant(1) 
- Butcher(1) 
- Chicken Butcher(1) 
- Cook(1) 
- Dairy Seller(1) 
- Distiller(1) 
- Hay Merchant(1) 
- Fisherman(1) 
- Fishmonger(1) 
- Miller(3) 
- Pastry Maker(1) 
- Vintner(1) 
- Barbarian(6) 
- Brigand(6) 
- Captain(6) 
- Mountainman(6) 
- Barbarian(2) 
- Cartographer(1) 
- Guide(2) 
- Huntsman(3) 
- Pathfinder(1) 
- Scout(1) 
- Slaver(1) 
- Barrel Maker(2) 
- Basket Maker(1) 
- Cobbler(2) 
- Cooper(2) 
- Furniture Maker(1) 
- Glassblower(1) 
- Glove Merchant(1) 
- Harness Maker(2) 
- Potter(2) 
- Rope Maker(1) 
- Saddler(1) 
- Shoe Maker(1) 
- Soap Maker(1) 
- Tanner(1) 
- Weaver(1) 
- Wheelwright(3) 
- Wine Merchant(1) 
- Wool Merchant(2) 
- Lord(1) 
- Barrel Maker(3) 
- Carpenter(4) 
- Roofer(3) 
- Wagon Maker(1) 
- Wheelwright(2) 
- Barber(1) 
- Bleacher(1) 
- Physic/Chirurgeon(1) 
- Bather(1) 
- Brigand(2) 
- Crook(3) 
- Goon(3) 
- Innkeeper(2) 
- Tavern Keeper(3) 
- Buckle Maker(2) 
- Cobbler(2) 
- Draper(1) 
- Furrier(3) 
- Girdler(1) 
- Haberdasher(1) 
- Launderer(2) 
- Leatherworker(2) 
- Purse Maker(1) 
- Shoe Maker(2) 
- Tailor(2) 
- Tanner(2) 
- Used Garment Trader(3) 
- Vestment Maker(1) 
- Chandler(3) 
- Dye Makers(3) 
- Oil Trader(3) 
- Cleric(3) 
- Missionary(8) 
- Preacher(5) 
- Priest(3) 
- Farmer(59) 
- Homestead(78) 
- Farmer - Cabbage(6) 
- Farmer - Cattle Herder(6) 
- Farmer - Corn(6) 
- Farmer - Cow Herder(6) 
- Farmer - Dairy(6) 
- Farmer - Goat Herder(6) 
- Farmer - Pig Herder(6) 
- Farmer - Potato(6) 
- Farmer - Sheep Herder(6) 
- Farmer - Wheat(6) 
- Farmer(Special)(6) 
- Dungsweeper(2) 
- Illuminator(1) 
- Messenger(2) 
- Town Crier(4) 
- Town Justice(1) 
- Undertaker(1) 
- Water Carrier(3) 
- Leatherworker(1) 
- Skinner(1) 
- Pirate(3) 
- Sail Maker(2) 
- Sailor(4) 
imports: 
- Herbs  
exports: 
- Onyx  
defenses: Baileys 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(1)  
> - Advocate(2)  
> - Animal Handler(2)  
> - Antiquities(1)  
> - Architect(3)  
> - Armor Dealer(1)  
> - Artist(3)  
> - Baker(1)  
> - Barbarian(2)  
> - Barbarian(6)  
> - Barber(1)  
> - Barrel Maker(2)  
> - Barrel Maker(3)  
> - Basket Maker(1)  
> - Bather(1)  
> - Beer Merchant(1)  
> - Blacksmith(3)  
> - Bleacher(1)  
> - Bowyer-Fletcher(1)  
> - Bricklayer(3)  
> - Brigand(2)  
> - Brigand(6)  
> - Buckle Maker(2)  
> - Butcher(1)  
> - Captain(6)  
> - Caravanner(2)  
> - Carpenter(4)  
> - Cartographer(1)  
> - Chandler(3)  
> - Chandler(3)  
> - Chicken Butcher(1)  
> - Cleric(3)  
> - Clerk(4)  
> - Cobbler(2)  
> - Cobbler(2)  
> - Cook(1)  
> - Cooper(2)  
> - Council Member(3)  
> - Crook(3)  
> - Dairy Seller(1)  
> - Distiller(1)  
> - Draper(1)  
> - Dungsweeper(2)  
> - Dye Makers(3)  
> - Dye Makers(3)  
> - Engineer(3)  
> - Farmer - Cabbage(6)  
> - Farmer - Cattle Herder(6)  
> - Farmer - Corn(6)  
> - Farmer - Cow Herder(6)  
> - Farmer - Dairy(6)  
> - Farmer - Goat Herder(6)  
> - Farmer - Pig Herder(6)  
> - Farmer - Potato(6)  
> - Farmer - Sheep Herder(6)  
> - Farmer - Wheat(6)  
> - Farmer(59)  
> - Farmer(Special)(6)  
> - Fisherman(1)  
> - Fishmonger(1)  
> - Furniture Maker(1)  
> - Furrier(3)  
> - Girdler(1)  
> - Glassblower(1)  
> - Glassblower(2)  
> - Glove Merchant(1)  
> - Goldsmith(1)  
> - Goon(3)  
> - Guide(2)  
> - Haberdasher(1)  
> - Harness Maker(2)  
> - Hay Merchant(1)  
> - Homestead(78)  
> - Horse Trader(3)  
> - Huntsman(3)  
> - Illuminator(1)  
> - Innkeeper(2)  
> - Inventor(2)  
> - Jeweler(1)  
> - Jeweler(1)  
> - Judge(2)  
> - Laborer(3)  
> - Launderer(1)  
> - Launderer(2)  
> - Leatherworker(1)  
> - Leatherworker(2)  
> - Livestock Merchant(1)  
> - Lord(1)  
> - Mason(3)  
> - Mayor(1)  
> - Messenger(2)  
> - Miller(3)  
> - Minstrel(1)  
> - Missionary(8)  
> - Mountainman(6)  
> - Oil Trader(3)  
> - Oil Trader(3)  
> - Painter(Art)(3)  
> - Painter(Building)(3)  
> - Pastry Maker(1)  
> - Pathfinder(1)  
> - Physic/Chirurgeon(1)  
> - Pirate(3)  
> - Plasterer(3)  
> - Potter(2)  
> - Preacher(5)  
> - Priest(3)  
> - Purse Maker(1)  
> - Roofer(3)  
> - Roofer(3)  
> - Rope Maker(1)  
> - Saddler(1)  
> - Sail Maker(2)  
> - Sailor(4)  
> - Scout(1)  
> - Shoe Maker(1)  
> - Shoe Maker(2)  
> - Silversmith(1)  
> - Silversmith(1)  
> - Skinner(1)  
> - Slaver(1)  
> - Slaver(1)  
> - Soap Maker(1)  
> - Spice Merchant(1)  
> - Spice Merchant(1)  
> - Stabler(3)  
> - Storyteller(1)  
> - Tailor(2)  
> - Tanner(1)  
> - Tanner(2)  
> - Tavern Keeper(3)  
> - Taxidermist(1)  
> - Taxidermist(1)  
> - Teamster(3)  
> - Tiler(3)  
> - Tinker(3)  
> - Tobacco Merchant(1)  
> - Tobacco Merchant(1)  
> - Town Crier(4)  
> - Town Justice(1)  
> - Trading Post(3)  
> - Troubadours(1)  
> - Undertaker(1)  
> - Used Garment Trader(3)  
> - Vestment Maker(1)  
> - Vintner(1)  
> - Wagon Maker(1)  
> - Warehouser(1)  
> - Water Carrier(3)  
> - Weapon Dealer(1)  
> - Weapon Dealer(1)  
> - Weaver(1)  
> - Wheelwright(2)  
> - Wheelwright(3)  
> - Wine Merchant(1)  
> - Wool Merchant(2)  
> - Writer(1)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(1)  
> - Advocate(2)  
> - Animal Handler(2)  
> - Antiquities(1)  
> - Architect(3)  
> - Armor Dealer(1)  
> - Artist(3)  
> - Baker(1)  
> - Barbarian(2)  
> - Barbarian(6)  
> - Barber(1)  
> - Barrel Maker(2)  
> - Barrel Maker(3)  
> - Basket Maker(1)  
> - Bather(1)  
> - Beer Merchant(1)  
> - Blacksmith(3)  
> - Bleacher(1)  
> - Bowyer-Fletcher(1)  
> - Bricklayer(3)  
> - Brigand(2)  
> - Brigand(6)  
> - Buckle Maker(2)  
> - Butcher(1)  
> - Captain(6)  
> - Caravanner(2)  
> - Carpenter(4)  
> - Cartographer(1)  
> - Chandler(3)  
> - Chandler(3)  
> - Chicken Butcher(1)  
> - Cleric(3)  
> - Clerk(4)  
> - Cobbler(2)  
> - Cobbler(2)  
> - Cook(1)  
> - Cooper(2)  
> - Council Member(3)  
> - Crook(3)  
> - Dairy Seller(1)  
> - Distiller(1)  
> - Draper(1)  
> - Dungsweeper(2)  
> - Dye Makers(3)  
> - Dye Makers(3)  
> - Engineer(3)  
> - Farmer - Cabbage(6)  
> - Farmer - Cattle Herder(6)  
> - Farmer - Corn(6)  
> - Farmer - Cow Herder(6)  
> - Farmer - Dairy(6)  
> - Farmer - Goat Herder(6)  
> - Farmer - Pig Herder(6)  
> - Farmer - Potato(6)  
> - Farmer - Sheep Herder(6)  
> - Farmer - Wheat(6)  
> - Farmer(59)  
> - Farmer(Special)(6)  
> - Fisherman(1)  
> - Fishmonger(1)  
> - Furniture Maker(1)  
> - Furrier(3)  
> - Girdler(1)  
> - Glassblower(1)  
> - Glassblower(2)  
> - Glove Merchant(1)  
> - Goldsmith(1)  
> - Goon(3)  
> - Guide(2)  
> - Haberdasher(1)  
> - Harness Maker(2)  
> - Hay Merchant(1)  
> - Homestead(78)  
> - Horse Trader(3)  
> - Huntsman(3)  
> - Illuminator(1)  
> - Innkeeper(2)  
> - Inventor(2)  
> - Jeweler(1)  
> - Jeweler(1)  
> - Judge(2)  
> - Laborer(3)  
> - Launderer(1)  
> - Launderer(2)  
> - Leatherworker(1)  
> - Leatherworker(2)  
> - Livestock Merchant(1)  
> - Lord(1)  
> - Mason(3)  
> - Mayor(1)  
> - Messenger(2)  
> - Miller(3)  
> - Minstrel(1)  
> - Missionary(8)  
> - Mountainman(6)  
> - Oil Trader(3)  
> - Oil Trader(3)  
> - Painter(Art)(3)  
> - Painter(Building)(3)  
> - Pastry Maker(1)  
> - Pathfinder(1)  
> - Physic/Chirurgeon(1)  
> - Pirate(3)  
> - Plasterer(3)  
> - Potter(2)  
> - Preacher(5)  
> - Priest(3)  
> - Purse Maker(1)  
> - Roofer(3)  
> - Roofer(3)  
> - Rope Maker(1)  
> - Saddler(1)  
> - Sail Maker(2)  
> - Sailor(4)  
> - Scout(1)  
> - Shoe Maker(1)  
> - Shoe Maker(2)  
> - Silversmith(1)  
> - Silversmith(1)  
> - Skinner(1)  
> - Slaver(1)  
> - Slaver(1)  
> - Soap Maker(1)  
> - Spice Merchant(1)  
> - Spice Merchant(1)  
> - Stabler(3)  
> - Storyteller(1)  
> - Tailor(2)  
> - Tanner(1)  
> - Tanner(2)  
> - Tavern Keeper(3)  
> - Taxidermist(1)  
> - Taxidermist(1)  
> - Teamster(3)  
> - Tiler(3)  
> - Tinker(3)  
> - Tobacco Merchant(1)  
> - Tobacco Merchant(1)  
> - Town Crier(4)  
> - Town Justice(1)  
> - Trading Post(3)  
> - Troubadours(1)  
> - Undertaker(1)  
> - Used Garment Trader(3)  
> - Vestment Maker(1)  
> - Vintner(1)  
> - Wagon Maker(1)  
> - Warehouser(1)  
> - Water Carrier(3)  
> - Weapon Dealer(1)  
> - Weapon Dealer(1)  
> - Weaver(1)  
> - Wheelwright(2)  
> - Wheelwright(3)  
> - Wine Merchant(1)  
> - Wool Merchant(2)  
> - Writer(1)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



