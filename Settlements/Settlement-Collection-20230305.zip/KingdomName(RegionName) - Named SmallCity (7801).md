---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallCity
kingdom: KingdomName
region: RegionName
settlementName: Named SmallCity (7801)
terrain: Mountain Forest 
settlementDescription: 
population: 7801
culture: Egyptian 
technology: Crusades 
leader: 
govermentType: Dictatorship 
demographics: 
- Acrobat(14) 
- Minstrel(14) 
- Storyteller(14) 
- Troubadours(14) 
- Writer(14) 
- Advocate(10) 
- Clerk(23) 
- Council Member(20) 
- Diplomat(4) 
- Judge(12) 
- Mayor(1) 
- Alchemist(7) 
- Chandler(20) 
- Dye Makers(20) 
- Florist(7) 
- Herbalist(7) 
- Potionmakers(7) 
- Sage(4) 
- Spice Merchant(14) 
- Taxidermist(14) 
- Tobacco Merchant(14) 
- Animal Groomer(6) 
- Animal Handler(14) 
- Caravanner(10) 
- Horse Trader(16) 
- Livestock Merchant(11) 
- Stabler(14) 
- Antiquities(14) 
- Armor Dealer(14) 
- Launderer(14) 
- Oil Trader(20) 
- Trading Post(20) 
- Slaver(14) 
- Spice Merchant(14) 
- Taxidermist(14) 
- Tobacco Merchant(14) 
- Warehouser(14) 
- Weapon Dealer(14) 
- Architect(16) 
- Bricklayer(16) 
- Engineer(16) 
- Laborer(16) 
- Mason(16) 
- Painter(Building)(16) 
- Plasterer(16) 
- Roofer(16) 
- Teamster(16) 
- Tiler(16) 
- Armorer(5) 
- Blacksmith(19) 
- Bowyer-Fletcher(7) 
- Jeweler(5) 
- Silversmith(5) 
- Weapon Dealer(14) 
- Weaponsmith(4) 
- Artist(18) 
- Glassblower(14) 
- Goldsmith(9) 
- Inventor(12) 
- Jeweler(8) 
- Magical Artisan(4) 
- Painter(Art)(15) 
- Silversmith(12) 
- Tinker(20) 
- Toymaker(7) 
- Astrologist(4) 
- Conjourer(4) 
- High Mage(4) 
- Historian(4) 
- Librarian(4) 
- Magical Artisan(4) 
- Magical Tutor(4) 
- Professor(4) 
- Scribe(4) 
- SellSpell(4) 
- Teacher(4) 
- Tutor(4) 
- Baker(13) 
- Beer Merchant(8) 
- Brewer(1) 
- Butcher(8) 
- Chicken Butcher(8) 
- Cook(9) 
- Dairy Seller(40) 
- Distiller(8) 
- Hay Merchant(40) 
- Fisherman(10) 
- Fishmonger(10) 
- Grain Merchant(1) 
- Grocer(6) 
- Meat Butcher(7) 
- Miller(20) 
- Pastry Maker(10) 
- Vintner(9) 
- Banker(5) 
- Pawnbroker(5) 
- Barbarian(40) 
- Brigand(40) 
- Captain(40) 
- Mountainman(40) 
- Barbarian(8) 
- Cartographer(7) 
- Guide(14) 
- Huntsman(20) 
- Mountainman(7) 
- Pathfinder(7) 
- Scout(7) 
- Slaver(14) 
- Barrel Maker(9) 
- Basket Maker(12) 
- Book Binder(4) 
- Bookseller(4) 
- Buckle Maker(7) 
- Candle Maker(5) 
- Clock Maker(4) 
- Cobbler(13) 
- Cooper(10) 
- Cutler(4) 
- Engraver(4) 
- Furniture Maker(13) 
- Glassblower(6) 
- Glazier(4) 
- Glove Merchant(11) 
- Goldsmith(6) 
- Harness Maker(14) 
- Hat Maker(6) 
- Instrument Maker(4) 
- Kettle Maker(4) 
- Locksmith(5) 
- Perfumer(6) 
- Potter(14) 
- Rope Maker(10) 
- Rug Maker(5) 
- Saddler(10) 
- Sculptor(4) 
- Shoe Maker(10) 
- Soap Maker(7) 
- Tanner(10) 
- Tinker(5) 
- Toymaker(4) 
- Weaponsmith(4) 
- Weaver(12) 
- Wheelwright(18) 
- Wine Merchant(7) 
- Wool Merchant(10) 
- Lord(3) 
- Knight(3) 
- Baron(2) 
- Viscount(1) 
- Earl(1) 
- Count(1) 
- Barrel Maker(15) 
- Bowyer-Fletcher(7) 
- Carpenter(23) 
- Roofer(16) 
- Wagon Maker(12) 
- Wheelwright(13) 
- Wood Carver(7) 
- Wood Seller(6) 
- Barber(7) 
- Bleacher(7) 
- Physic/Chirurgeon(7) 
- Bather(6) 
- Brigand(14) 
- Crime Lord(4) 
- Crook(16) 
- Goon(18) 
- Brothel Keeper(6) 
- Innkeeper(11) 
- Tavern Keeper(15) 
- Buckle Maker(11) 
- Cobbler(10) 
- Draper(7) 
- Furrier(18) 
- Girdler(6) 
- Haberdasher(6) 
- Launderer(11) 
- Leatherworker(8) 
- Purse Maker(7) 
- Shoe Maker(10) 
- Tailor(11) 
- Tanner(10) 
- Used Garment Trader(17) 
- Vestment Maker(10) 
- Chandler(20) 
- Dye Makers(20) 
- Oil Trader(20) 
- Cleric(15) 
- High Priest(6) 
- Missionary(53) 
- Preacher(32) 
- Priest(18) 
- Farmer(391) 
- Homestead(521) 
- Farmer - Cabbage(40) 
- Farmer - Cattle Herder(40) 
- Farmer - Corn(40) 
- Farmer - Cow Herder(40) 
- Farmer - Dairy(40) 
- Farmer - Goat Herder(40) 
- Farmer - Pig Herder(40) 
- Farmer - Potato(40) 
- Farmer - Sheep Herder(40) 
- Farmer - Wheat(40) 
- Farmer(Special)(40) 
- Dungsweeper(11) 
- Illuminator(8) 
- Messenger(13) 
- Tax Collector(2) 
- Town Crier(23) 
- Town Justice(6) 
- Undertaker(5) 
- Water Carrier(16) 
- Leatherworker(8) 
- Skinner(8) 
- Naval Outfitter(5) 
- Pirate(20) 
- Sail Maker(12) 
- Sailor(27) 
- Ship Builder(5) 
imports: 
- Ore  
exports: 
- Gemstones  
defenses: Killing Fields 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(14)  
> - Advocate(10)  
> - Alchemist(7)  
> - Animal Groomer(6)  
> - Animal Handler(14)  
> - Antiquities(14)  
> - Architect(16)  
> - Armor Dealer(14)  
> - Armorer(5)  
> - Artist(18)  
> - Astrologist(4)  
> - Baker(13)  
> - Banker(5)  
> - Barbarian(40)  
> - Barbarian(8)  
> - Barber(7)  
> - Baron(2)  
> - Barrel Maker(15)  
> - Barrel Maker(9)  
> - Basket Maker(12)  
> - Bather(6)  
> - Beer Merchant(8)  
> - Blacksmith(19)  
> - Bleacher(7)  
> - Book Binder(4)  
> - Bookseller(4)  
> - Bowyer-Fletcher(7)  
> - Bowyer-Fletcher(7)  
> - Brewer(1)  
> - Bricklayer(16)  
> - Brigand(14)  
> - Brigand(40)  
> - Brothel Keeper(6)  
> - Buckle Maker(11)  
> - Buckle Maker(7)  
> - Butcher(8)  
> - Candle Maker(5)  
> - Captain(40)  
> - Caravanner(10)  
> - Carpenter(23)  
> - Cartographer(7)  
> - Chandler(20)  
> - Chandler(20)  
> - Chicken Butcher(8)  
> - Cleric(15)  
> - Clerk(23)  
> - Clock Maker(4)  
> - Cobbler(10)  
> - Cobbler(13)  
> - Conjourer(4)  
> - Cook(9)  
> - Cooper(10)  
> - Council Member(20)  
> - Count(1)  
> - Crime Lord(4)  
> - Crook(16)  
> - Cutler(4)  
> - Dairy Seller(40)  
> - Diplomat(4)  
> - Distiller(8)  
> - Draper(7)  
> - Dungsweeper(11)  
> - Dye Makers(20)  
> - Dye Makers(20)  
> - Earl(1)  
> - Engineer(16)  
> - Engraver(4)  
> - Farmer - Cabbage(40)  
> - Farmer - Cattle Herder(40)  
> - Farmer - Corn(40)  
> - Farmer - Cow Herder(40)  
> - Farmer - Dairy(40)  
> - Farmer - Goat Herder(40)  
> - Farmer - Pig Herder(40)  
> - Farmer - Potato(40)  
> - Farmer - Sheep Herder(40)  
> - Farmer - Wheat(40)  
> - Farmer(391)  
> - Farmer(Special)(40)  
> - Fisherman(10)  
> - Fishmonger(10)  
> - Florist(7)  
> - Furniture Maker(13)  
> - Furrier(18)  
> - Girdler(6)  
> - Glassblower(14)  
> - Glassblower(6)  
> - Glazier(4)  
> - Glove Merchant(11)  
> - Goldsmith(6)  
> - Goldsmith(9)  
> - Goon(18)  
> - Grain Merchant(1)  
> - Grocer(6)  
> - Guide(14)  
> - Haberdasher(6)  
> - Harness Maker(14)  
> - Hat Maker(6)  
> - Hay Merchant(40)  
> - Herbalist(7)  
> - High Mage(4)  
> - High Priest(6)  
> - Historian(4)  
> - Homestead(521)  
> - Horse Trader(16)  
> - Huntsman(20)  
> - Illuminator(8)  
> - Innkeeper(11)  
> - Instrument Maker(4)  
> - Inventor(12)  
> - Jeweler(5)  
> - Jeweler(8)  
> - Judge(12)  
> - Kettle Maker(4)  
> - Knight(3)  
> - Laborer(16)  
> - Launderer(11)  
> - Launderer(14)  
> - Leatherworker(8)  
> - Leatherworker(8)  
> - Librarian(4)  
> - Livestock Merchant(11)  
> - Locksmith(5)  
> - Lord(3)  
> - Magical Artisan(4)  
> - Magical Artisan(4)  
> - Magical Tutor(4)  
> - Mason(16)  
> - Mayor(1)  
> - Meat Butcher(7)  
> - Messenger(13)  
> - Miller(20)  
> - Minstrel(14)  
> - Missionary(53)  
> - Mountainman(40)  
> - Mountainman(7)  
> - Naval Outfitter(5)  
> - Oil Trader(20)  
> - Oil Trader(20)  
> - Painter(Art)(15)  
> - Painter(Building)(16)  
> - Pastry Maker(10)  
> - Pathfinder(7)  
> - Pawnbroker(5)  
> - Perfumer(6)  
> - Physic/Chirurgeon(7)  
> - Pirate(20)  
> - Plasterer(16)  
> - Potionmakers(7)  
> - Potter(14)  
> - Preacher(32)  
> - Priest(18)  
> - Professor(4)  
> - Purse Maker(7)  
> - Roofer(16)  
> - Roofer(16)  
> - Rope Maker(10)  
> - Rug Maker(5)  
> - Saddler(10)  
> - Sage(4)  
> - Sail Maker(12)  
> - Sailor(27)  
> - Scout(7)  
> - Scribe(4)  
> - Sculptor(4)  
> - SellSpell(4)  
> - Ship Builder(5)  
> - Shoe Maker(10)  
> - Shoe Maker(10)  
> - Silversmith(12)  
> - Silversmith(5)  
> - Skinner(8)  
> - Slaver(14)  
> - Slaver(14)  
> - Soap Maker(7)  
> - Spice Merchant(14)  
> - Spice Merchant(14)  
> - Stabler(14)  
> - Storyteller(14)  
> - Tailor(11)  
> - Tanner(10)  
> - Tanner(10)  
> - Tavern Keeper(15)  
> - Tax Collector(2)  
> - Taxidermist(14)  
> - Taxidermist(14)  
> - Teacher(4)  
> - Teamster(16)  
> - Tiler(16)  
> - Tinker(20)  
> - Tinker(5)  
> - Tobacco Merchant(14)  
> - Tobacco Merchant(14)  
> - Town Crier(23)  
> - Town Justice(6)  
> - Toymaker(4)  
> - Toymaker(7)  
> - Trading Post(20)  
> - Troubadours(14)  
> - Tutor(4)  
> - Undertaker(5)  
> - Used Garment Trader(17)  
> - Vestment Maker(10)  
> - Vintner(9)  
> - Viscount(1)  
> - Wagon Maker(12)  
> - Warehouser(14)  
> - Water Carrier(16)  
> - Weapon Dealer(14)  
> - Weapon Dealer(14)  
> - Weaponsmith(4)  
> - Weaponsmith(4)  
> - Weaver(12)  
> - Wheelwright(13)  
> - Wheelwright(18)  
> - Wine Merchant(7)  
> - Wood Carver(7)  
> - Wood Seller(6)  
> - Wool Merchant(10)  
> - Writer(14)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(14)  
> - Advocate(10)  
> - Alchemist(7)  
> - Animal Groomer(6)  
> - Animal Handler(14)  
> - Antiquities(14)  
> - Architect(16)  
> - Armor Dealer(14)  
> - Armorer(5)  
> - Artist(18)  
> - Astrologist(4)  
> - Baker(13)  
> - Banker(5)  
> - Barbarian(40)  
> - Barbarian(8)  
> - Barber(7)  
> - Baron(2)  
> - Barrel Maker(15)  
> - Barrel Maker(9)  
> - Basket Maker(12)  
> - Bather(6)  
> - Beer Merchant(8)  
> - Blacksmith(19)  
> - Bleacher(7)  
> - Book Binder(4)  
> - Bookseller(4)  
> - Bowyer-Fletcher(7)  
> - Bowyer-Fletcher(7)  
> - Brewer(1)  
> - Bricklayer(16)  
> - Brigand(14)  
> - Brigand(40)  
> - Brothel Keeper(6)  
> - Buckle Maker(11)  
> - Buckle Maker(7)  
> - Butcher(8)  
> - Candle Maker(5)  
> - Captain(40)  
> - Caravanner(10)  
> - Carpenter(23)  
> - Cartographer(7)  
> - Chandler(20)  
> - Chandler(20)  
> - Chicken Butcher(8)  
> - Cleric(15)  
> - Clerk(23)  
> - Clock Maker(4)  
> - Cobbler(10)  
> - Cobbler(13)  
> - Conjourer(4)  
> - Cook(9)  
> - Cooper(10)  
> - Council Member(20)  
> - Count(1)  
> - Crime Lord(4)  
> - Crook(16)  
> - Cutler(4)  
> - Dairy Seller(40)  
> - Diplomat(4)  
> - Distiller(8)  
> - Draper(7)  
> - Dungsweeper(11)  
> - Dye Makers(20)  
> - Dye Makers(20)  
> - Earl(1)  
> - Engineer(16)  
> - Engraver(4)  
> - Farmer - Cabbage(40)  
> - Farmer - Cattle Herder(40)  
> - Farmer - Corn(40)  
> - Farmer - Cow Herder(40)  
> - Farmer - Dairy(40)  
> - Farmer - Goat Herder(40)  
> - Farmer - Pig Herder(40)  
> - Farmer - Potato(40)  
> - Farmer - Sheep Herder(40)  
> - Farmer - Wheat(40)  
> - Farmer(391)  
> - Farmer(Special)(40)  
> - Fisherman(10)  
> - Fishmonger(10)  
> - Florist(7)  
> - Furniture Maker(13)  
> - Furrier(18)  
> - Girdler(6)  
> - Glassblower(14)  
> - Glassblower(6)  
> - Glazier(4)  
> - Glove Merchant(11)  
> - Goldsmith(6)  
> - Goldsmith(9)  
> - Goon(18)  
> - Grain Merchant(1)  
> - Grocer(6)  
> - Guide(14)  
> - Haberdasher(6)  
> - Harness Maker(14)  
> - Hat Maker(6)  
> - Hay Merchant(40)  
> - Herbalist(7)  
> - High Mage(4)  
> - High Priest(6)  
> - Historian(4)  
> - Homestead(521)  
> - Horse Trader(16)  
> - Huntsman(20)  
> - Illuminator(8)  
> - Innkeeper(11)  
> - Instrument Maker(4)  
> - Inventor(12)  
> - Jeweler(5)  
> - Jeweler(8)  
> - Judge(12)  
> - Kettle Maker(4)  
> - Knight(3)  
> - Laborer(16)  
> - Launderer(11)  
> - Launderer(14)  
> - Leatherworker(8)  
> - Leatherworker(8)  
> - Librarian(4)  
> - Livestock Merchant(11)  
> - Locksmith(5)  
> - Lord(3)  
> - Magical Artisan(4)  
> - Magical Artisan(4)  
> - Magical Tutor(4)  
> - Mason(16)  
> - Mayor(1)  
> - Meat Butcher(7)  
> - Messenger(13)  
> - Miller(20)  
> - Minstrel(14)  
> - Missionary(53)  
> - Mountainman(40)  
> - Mountainman(7)  
> - Naval Outfitter(5)  
> - Oil Trader(20)  
> - Oil Trader(20)  
> - Painter(Art)(15)  
> - Painter(Building)(16)  
> - Pastry Maker(10)  
> - Pathfinder(7)  
> - Pawnbroker(5)  
> - Perfumer(6)  
> - Physic/Chirurgeon(7)  
> - Pirate(20)  
> - Plasterer(16)  
> - Potionmakers(7)  
> - Potter(14)  
> - Preacher(32)  
> - Priest(18)  
> - Professor(4)  
> - Purse Maker(7)  
> - Roofer(16)  
> - Roofer(16)  
> - Rope Maker(10)  
> - Rug Maker(5)  
> - Saddler(10)  
> - Sage(4)  
> - Sail Maker(12)  
> - Sailor(27)  
> - Scout(7)  
> - Scribe(4)  
> - Sculptor(4)  
> - SellSpell(4)  
> - Ship Builder(5)  
> - Shoe Maker(10)  
> - Shoe Maker(10)  
> - Silversmith(12)  
> - Silversmith(5)  
> - Skinner(8)  
> - Slaver(14)  
> - Slaver(14)  
> - Soap Maker(7)  
> - Spice Merchant(14)  
> - Spice Merchant(14)  
> - Stabler(14)  
> - Storyteller(14)  
> - Tailor(11)  
> - Tanner(10)  
> - Tanner(10)  
> - Tavern Keeper(15)  
> - Tax Collector(2)  
> - Taxidermist(14)  
> - Taxidermist(14)  
> - Teacher(4)  
> - Teamster(16)  
> - Tiler(16)  
> - Tinker(20)  
> - Tinker(5)  
> - Tobacco Merchant(14)  
> - Tobacco Merchant(14)  
> - Town Crier(23)  
> - Town Justice(6)  
> - Toymaker(4)  
> - Toymaker(7)  
> - Trading Post(20)  
> - Troubadours(14)  
> - Tutor(4)  
> - Undertaker(5)  
> - Used Garment Trader(17)  
> - Vestment Maker(10)  
> - Vintner(9)  
> - Viscount(1)  
> - Wagon Maker(12)  
> - Warehouser(14)  
> - Water Carrier(16)  
> - Weapon Dealer(14)  
> - Weapon Dealer(14)  
> - Weaponsmith(4)  
> - Weaponsmith(4)  
> - Weaver(12)  
> - Wheelwright(13)  
> - Wheelwright(18)  
> - Wine Merchant(7)  
> - Wood Carver(7)  
> - Wood Seller(6)  
> - Wool Merchant(10)  
> - Writer(14)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



