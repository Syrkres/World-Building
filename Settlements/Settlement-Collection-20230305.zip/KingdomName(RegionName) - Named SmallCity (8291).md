---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallCity
kingdom: KingdomName
region: RegionName
settlementName: Named SmallCity (8291)
terrain: Mountain Forest Boreal 
settlementDescription: 
population: 8291
culture: Barbarian 
technology: Savage 
leader: 
govermentType: Feudalism 
demographics: 
- Acrobat(14) 
- Minstrel(14) 
- Storyteller(14) 
- Troubadours(14) 
- Writer(14) 
- Advocate(11) 
- Clerk(24) 
- Council Member(21) 
- Diplomat(4) 
- Judge(12) 
- Mayor(1) 
- Alchemist(7) 
- Chandler(21) 
- Dye Makers(21) 
- Florist(7) 
- Herbalist(7) 
- Potionmakers(7) 
- Sage(4) 
- Spice Merchant(14) 
- Taxidermist(14) 
- Tobacco Merchant(14) 
- Animal Groomer(6) 
- Animal Handler(14) 
- Caravanner(11) 
- Horse Trader(17) 
- Livestock Merchant(12) 
- Stabler(15) 
- Antiquities(14) 
- Armor Dealer(14) 
- Launderer(14) 
- Oil Trader(21) 
- Trading Post(21) 
- Slaver(14) 
- Spice Merchant(14) 
- Taxidermist(14) 
- Tobacco Merchant(14) 
- Warehouser(14) 
- Weapon Dealer(14) 
- Architect(17) 
- Bricklayer(17) 
- Engineer(17) 
- Laborer(17) 
- Mason(17) 
- Painter(Building)(17) 
- Plasterer(17) 
- Roofer(17) 
- Teamster(17) 
- Tiler(17) 
- Armorer(5) 
- Blacksmith(20) 
- Bowyer-Fletcher(7) 
- Jeweler(6) 
- Silversmith(5) 
- Weapon Dealer(14) 
- Weaponsmith(4) 
- Artist(19) 
- Glassblower(14) 
- Goldsmith(10) 
- Inventor(12) 
- Jeweler(9) 
- Magical Artisan(4) 
- Painter(Art)(16) 
- Silversmith(12) 
- Tinker(21) 
- Toymaker(7) 
- Astrologist(4) 
- Conjourer(4) 
- High Mage(4) 
- Historian(4) 
- Librarian(4) 
- Magical Artisan(4) 
- Magical Tutor(4) 
- Professor(4) 
- Scribe(4) 
- SellSpell(4) 
- Teacher(4) 
- Tutor(4) 
- Baker(13) 
- Beer Merchant(8) 
- Brewer(1) 
- Butcher(9) 
- Chicken Butcher(9) 
- Cook(9) 
- Dairy Seller(42) 
- Distiller(8) 
- Hay Merchant(42) 
- Fisherman(11) 
- Fishmonger(11) 
- Grain Merchant(3) 
- Grocer(7) 
- Meat Butcher(7) 
- Miller(21) 
- Pastry Maker(11) 
- Vintner(9) 
- Banker(5) 
- Pawnbroker(5) 
- Barbarian(42) 
- Brigand(42) 
- Captain(42) 
- Mountainman(42) 
- Barbarian(8) 
- Cartographer(7) 
- Guide(14) 
- Huntsman(21) 
- Mountainman(7) 
- Pathfinder(7) 
- Scout(7) 
- Slaver(14) 
- Barrel Maker(9) 
- Basket Maker(12) 
- Book Binder(5) 
- Bookseller(4) 
- Buckle Maker(7) 
- Candle Maker(6) 
- Clock Maker(4) 
- Cobbler(13) 
- Cooper(10) 
- Cutler(5) 
- Engraver(4) 
- Furniture Maker(13) 
- Glassblower(6) 
- Glazier(4) 
- Glove Merchant(12) 
- Goldsmith(6) 
- Harness Maker(14) 
- Hat Maker(6) 
- Instrument Maker(4) 
- Kettle Maker(4) 
- Locksmith(5) 
- Perfumer(6) 
- Potter(14) 
- Rope Maker(10) 
- Rug Maker(6) 
- Saddler(11) 
- Sculptor(4) 
- Shoe Maker(10) 
- Soap Maker(7) 
- Tanner(11) 
- Tinker(5) 
- Toymaker(4) 
- Weaponsmith(4) 
- Weaver(12) 
- Wheelwright(19) 
- Wine Merchant(7) 
- Wool Merchant(11) 
- Lord(3) 
- Knight(3) 
- Baron(2) 
- Viscount(1) 
- Earl(1) 
- Count(1) 
- Barrel Maker(16) 
- Bowyer-Fletcher(7) 
- Carpenter(24) 
- Roofer(17) 
- Wagon Maker(12) 
- Wheelwright(13) 
- Wood Carver(7) 
- Wood Seller(7) 
- Barber(7) 
- Bleacher(7) 
- Physic/Chirurgeon(7) 
- Bather(6) 
- Brigand(14) 
- Crime Lord(4) 
- Crook(17) 
- Goon(19) 
- Brothel Keeper(6) 
- Innkeeper(12) 
- Tavern Keeper(16) 
- Buckle Maker(12) 
- Cobbler(10) 
- Draper(7) 
- Furrier(19) 
- Girdler(7) 
- Haberdasher(6) 
- Launderer(12) 
- Leatherworker(8) 
- Purse Maker(7) 
- Shoe Maker(10) 
- Tailor(12) 
- Tanner(11) 
- Used Garment Trader(18) 
- Vestment Maker(10) 
- Chandler(21) 
- Dye Makers(21) 
- Oil Trader(21) 
- Cleric(16) 
- High Priest(6) 
- Missionary(56) 
- Preacher(34) 
- Priest(19) 
- Farmer(415) 
- Homestead(553) 
- Farmer - Cabbage(42) 
- Farmer - Cattle Herder(42) 
- Farmer - Corn(42) 
- Farmer - Cow Herder(42) 
- Farmer - Dairy(42) 
- Farmer - Goat Herder(42) 
- Farmer - Pig Herder(42) 
- Farmer - Potato(42) 
- Farmer - Sheep Herder(42) 
- Farmer - Wheat(42) 
- Farmer(Special)(42) 
- Dungsweeper(12) 
- Illuminator(9) 
- Messenger(13) 
- Tax Collector(3) 
- Town Crier(24) 
- Town Justice(6) 
- Undertaker(5) 
- Water Carrier(17) 
- Leatherworker(9) 
- Skinner(9) 
- Naval Outfitter(5) 
- Pirate(21) 
- Sail Maker(12) 
- Sailor(28) 
- Ship Builder(5) 
imports: 
- Bamboo  
exports: 
- Soapstone  
defenses: Archer towers 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(14)  
> - Advocate(11)  
> - Alchemist(7)  
> - Animal Groomer(6)  
> - Animal Handler(14)  
> - Antiquities(14)  
> - Architect(17)  
> - Armor Dealer(14)  
> - Armorer(5)  
> - Artist(19)  
> - Astrologist(4)  
> - Baker(13)  
> - Banker(5)  
> - Barbarian(42)  
> - Barbarian(8)  
> - Barber(7)  
> - Baron(2)  
> - Barrel Maker(16)  
> - Barrel Maker(9)  
> - Basket Maker(12)  
> - Bather(6)  
> - Beer Merchant(8)  
> - Blacksmith(20)  
> - Bleacher(7)  
> - Book Binder(5)  
> - Bookseller(4)  
> - Bowyer-Fletcher(7)  
> - Bowyer-Fletcher(7)  
> - Brewer(1)  
> - Bricklayer(17)  
> - Brigand(14)  
> - Brigand(42)  
> - Brothel Keeper(6)  
> - Buckle Maker(12)  
> - Buckle Maker(7)  
> - Butcher(9)  
> - Candle Maker(6)  
> - Captain(42)  
> - Caravanner(11)  
> - Carpenter(24)  
> - Cartographer(7)  
> - Chandler(21)  
> - Chandler(21)  
> - Chicken Butcher(9)  
> - Cleric(16)  
> - Clerk(24)  
> - Clock Maker(4)  
> - Cobbler(10)  
> - Cobbler(13)  
> - Conjourer(4)  
> - Cook(9)  
> - Cooper(10)  
> - Council Member(21)  
> - Count(1)  
> - Crime Lord(4)  
> - Crook(17)  
> - Cutler(5)  
> - Dairy Seller(42)  
> - Diplomat(4)  
> - Distiller(8)  
> - Draper(7)  
> - Dungsweeper(12)  
> - Dye Makers(21)  
> - Dye Makers(21)  
> - Earl(1)  
> - Engineer(17)  
> - Engraver(4)  
> - Farmer - Cabbage(42)  
> - Farmer - Cattle Herder(42)  
> - Farmer - Corn(42)  
> - Farmer - Cow Herder(42)  
> - Farmer - Dairy(42)  
> - Farmer - Goat Herder(42)  
> - Farmer - Pig Herder(42)  
> - Farmer - Potato(42)  
> - Farmer - Sheep Herder(42)  
> - Farmer - Wheat(42)  
> - Farmer(415)  
> - Farmer(Special)(42)  
> - Fisherman(11)  
> - Fishmonger(11)  
> - Florist(7)  
> - Furniture Maker(13)  
> - Furrier(19)  
> - Girdler(7)  
> - Glassblower(14)  
> - Glassblower(6)  
> - Glazier(4)  
> - Glove Merchant(12)  
> - Goldsmith(10)  
> - Goldsmith(6)  
> - Goon(19)  
> - Grain Merchant(3)  
> - Grocer(7)  
> - Guide(14)  
> - Haberdasher(6)  
> - Harness Maker(14)  
> - Hat Maker(6)  
> - Hay Merchant(42)  
> - Herbalist(7)  
> - High Mage(4)  
> - High Priest(6)  
> - Historian(4)  
> - Homestead(553)  
> - Horse Trader(17)  
> - Huntsman(21)  
> - Illuminator(9)  
> - Innkeeper(12)  
> - Instrument Maker(4)  
> - Inventor(12)  
> - Jeweler(6)  
> - Jeweler(9)  
> - Judge(12)  
> - Kettle Maker(4)  
> - Knight(3)  
> - Laborer(17)  
> - Launderer(12)  
> - Launderer(14)  
> - Leatherworker(8)  
> - Leatherworker(9)  
> - Librarian(4)  
> - Livestock Merchant(12)  
> - Locksmith(5)  
> - Lord(3)  
> - Magical Artisan(4)  
> - Magical Artisan(4)  
> - Magical Tutor(4)  
> - Mason(17)  
> - Mayor(1)  
> - Meat Butcher(7)  
> - Messenger(13)  
> - Miller(21)  
> - Minstrel(14)  
> - Missionary(56)  
> - Mountainman(42)  
> - Mountainman(7)  
> - Naval Outfitter(5)  
> - Oil Trader(21)  
> - Oil Trader(21)  
> - Painter(Art)(16)  
> - Painter(Building)(17)  
> - Pastry Maker(11)  
> - Pathfinder(7)  
> - Pawnbroker(5)  
> - Perfumer(6)  
> - Physic/Chirurgeon(7)  
> - Pirate(21)  
> - Plasterer(17)  
> - Potionmakers(7)  
> - Potter(14)  
> - Preacher(34)  
> - Priest(19)  
> - Professor(4)  
> - Purse Maker(7)  
> - Roofer(17)  
> - Roofer(17)  
> - Rope Maker(10)  
> - Rug Maker(6)  
> - Saddler(11)  
> - Sage(4)  
> - Sail Maker(12)  
> - Sailor(28)  
> - Scout(7)  
> - Scribe(4)  
> - Sculptor(4)  
> - SellSpell(4)  
> - Ship Builder(5)  
> - Shoe Maker(10)  
> - Shoe Maker(10)  
> - Silversmith(12)  
> - Silversmith(5)  
> - Skinner(9)  
> - Slaver(14)  
> - Slaver(14)  
> - Soap Maker(7)  
> - Spice Merchant(14)  
> - Spice Merchant(14)  
> - Stabler(15)  
> - Storyteller(14)  
> - Tailor(12)  
> - Tanner(11)  
> - Tanner(11)  
> - Tavern Keeper(16)  
> - Tax Collector(3)  
> - Taxidermist(14)  
> - Taxidermist(14)  
> - Teacher(4)  
> - Teamster(17)  
> - Tiler(17)  
> - Tinker(21)  
> - Tinker(5)  
> - Tobacco Merchant(14)  
> - Tobacco Merchant(14)  
> - Town Crier(24)  
> - Town Justice(6)  
> - Toymaker(4)  
> - Toymaker(7)  
> - Trading Post(21)  
> - Troubadours(14)  
> - Tutor(4)  
> - Undertaker(5)  
> - Used Garment Trader(18)  
> - Vestment Maker(10)  
> - Vintner(9)  
> - Viscount(1)  
> - Wagon Maker(12)  
> - Warehouser(14)  
> - Water Carrier(17)  
> - Weapon Dealer(14)  
> - Weapon Dealer(14)  
> - Weaponsmith(4)  
> - Weaponsmith(4)  
> - Weaver(12)  
> - Wheelwright(13)  
> - Wheelwright(19)  
> - Wine Merchant(7)  
> - Wood Carver(7)  
> - Wood Seller(7)  
> - Wool Merchant(11)  
> - Writer(14)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(14)  
> - Advocate(11)  
> - Alchemist(7)  
> - Animal Groomer(6)  
> - Animal Handler(14)  
> - Antiquities(14)  
> - Architect(17)  
> - Armor Dealer(14)  
> - Armorer(5)  
> - Artist(19)  
> - Astrologist(4)  
> - Baker(13)  
> - Banker(5)  
> - Barbarian(42)  
> - Barbarian(8)  
> - Barber(7)  
> - Baron(2)  
> - Barrel Maker(16)  
> - Barrel Maker(9)  
> - Basket Maker(12)  
> - Bather(6)  
> - Beer Merchant(8)  
> - Blacksmith(20)  
> - Bleacher(7)  
> - Book Binder(5)  
> - Bookseller(4)  
> - Bowyer-Fletcher(7)  
> - Bowyer-Fletcher(7)  
> - Brewer(1)  
> - Bricklayer(17)  
> - Brigand(14)  
> - Brigand(42)  
> - Brothel Keeper(6)  
> - Buckle Maker(12)  
> - Buckle Maker(7)  
> - Butcher(9)  
> - Candle Maker(6)  
> - Captain(42)  
> - Caravanner(11)  
> - Carpenter(24)  
> - Cartographer(7)  
> - Chandler(21)  
> - Chandler(21)  
> - Chicken Butcher(9)  
> - Cleric(16)  
> - Clerk(24)  
> - Clock Maker(4)  
> - Cobbler(10)  
> - Cobbler(13)  
> - Conjourer(4)  
> - Cook(9)  
> - Cooper(10)  
> - Council Member(21)  
> - Count(1)  
> - Crime Lord(4)  
> - Crook(17)  
> - Cutler(5)  
> - Dairy Seller(42)  
> - Diplomat(4)  
> - Distiller(8)  
> - Draper(7)  
> - Dungsweeper(12)  
> - Dye Makers(21)  
> - Dye Makers(21)  
> - Earl(1)  
> - Engineer(17)  
> - Engraver(4)  
> - Farmer - Cabbage(42)  
> - Farmer - Cattle Herder(42)  
> - Farmer - Corn(42)  
> - Farmer - Cow Herder(42)  
> - Farmer - Dairy(42)  
> - Farmer - Goat Herder(42)  
> - Farmer - Pig Herder(42)  
> - Farmer - Potato(42)  
> - Farmer - Sheep Herder(42)  
> - Farmer - Wheat(42)  
> - Farmer(415)  
> - Farmer(Special)(42)  
> - Fisherman(11)  
> - Fishmonger(11)  
> - Florist(7)  
> - Furniture Maker(13)  
> - Furrier(19)  
> - Girdler(7)  
> - Glassblower(14)  
> - Glassblower(6)  
> - Glazier(4)  
> - Glove Merchant(12)  
> - Goldsmith(10)  
> - Goldsmith(6)  
> - Goon(19)  
> - Grain Merchant(3)  
> - Grocer(7)  
> - Guide(14)  
> - Haberdasher(6)  
> - Harness Maker(14)  
> - Hat Maker(6)  
> - Hay Merchant(42)  
> - Herbalist(7)  
> - High Mage(4)  
> - High Priest(6)  
> - Historian(4)  
> - Homestead(553)  
> - Horse Trader(17)  
> - Huntsman(21)  
> - Illuminator(9)  
> - Innkeeper(12)  
> - Instrument Maker(4)  
> - Inventor(12)  
> - Jeweler(6)  
> - Jeweler(9)  
> - Judge(12)  
> - Kettle Maker(4)  
> - Knight(3)  
> - Laborer(17)  
> - Launderer(12)  
> - Launderer(14)  
> - Leatherworker(8)  
> - Leatherworker(9)  
> - Librarian(4)  
> - Livestock Merchant(12)  
> - Locksmith(5)  
> - Lord(3)  
> - Magical Artisan(4)  
> - Magical Artisan(4)  
> - Magical Tutor(4)  
> - Mason(17)  
> - Mayor(1)  
> - Meat Butcher(7)  
> - Messenger(13)  
> - Miller(21)  
> - Minstrel(14)  
> - Missionary(56)  
> - Mountainman(42)  
> - Mountainman(7)  
> - Naval Outfitter(5)  
> - Oil Trader(21)  
> - Oil Trader(21)  
> - Painter(Art)(16)  
> - Painter(Building)(17)  
> - Pastry Maker(11)  
> - Pathfinder(7)  
> - Pawnbroker(5)  
> - Perfumer(6)  
> - Physic/Chirurgeon(7)  
> - Pirate(21)  
> - Plasterer(17)  
> - Potionmakers(7)  
> - Potter(14)  
> - Preacher(34)  
> - Priest(19)  
> - Professor(4)  
> - Purse Maker(7)  
> - Roofer(17)  
> - Roofer(17)  
> - Rope Maker(10)  
> - Rug Maker(6)  
> - Saddler(11)  
> - Sage(4)  
> - Sail Maker(12)  
> - Sailor(28)  
> - Scout(7)  
> - Scribe(4)  
> - Sculptor(4)  
> - SellSpell(4)  
> - Ship Builder(5)  
> - Shoe Maker(10)  
> - Shoe Maker(10)  
> - Silversmith(12)  
> - Silversmith(5)  
> - Skinner(9)  
> - Slaver(14)  
> - Slaver(14)  
> - Soap Maker(7)  
> - Spice Merchant(14)  
> - Spice Merchant(14)  
> - Stabler(15)  
> - Storyteller(14)  
> - Tailor(12)  
> - Tanner(11)  
> - Tanner(11)  
> - Tavern Keeper(16)  
> - Tax Collector(3)  
> - Taxidermist(14)  
> - Taxidermist(14)  
> - Teacher(4)  
> - Teamster(17)  
> - Tiler(17)  
> - Tinker(21)  
> - Tinker(5)  
> - Tobacco Merchant(14)  
> - Tobacco Merchant(14)  
> - Town Crier(24)  
> - Town Justice(6)  
> - Toymaker(4)  
> - Toymaker(7)  
> - Trading Post(21)  
> - Troubadours(14)  
> - Tutor(4)  
> - Undertaker(5)  
> - Used Garment Trader(18)  
> - Vestment Maker(10)  
> - Vintner(9)  
> - Viscount(1)  
> - Wagon Maker(12)  
> - Warehouser(14)  
> - Water Carrier(17)  
> - Weapon Dealer(14)  
> - Weapon Dealer(14)  
> - Weaponsmith(4)  
> - Weaponsmith(4)  
> - Weaver(12)  
> - Wheelwright(13)  
> - Wheelwright(19)  
> - Wine Merchant(7)  
> - Wood Carver(7)  
> - Wood Seller(7)  
> - Wool Merchant(11)  
> - Writer(14)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



