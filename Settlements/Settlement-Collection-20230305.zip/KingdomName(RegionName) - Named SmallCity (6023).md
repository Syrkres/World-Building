---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallCity
kingdom: KingdomName
region: RegionName
settlementName: Named SmallCity (6023)
terrain: Grasslands 
settlementDescription: 
population: 6023
culture: Incan 
technology: Savage 
leader: 
govermentType: Dictatorship 
demographics: 
- Acrobat(11) 
- Minstrel(11) 
- Storyteller(11) 
- Troubadours(11) 
- Writer(11) 
- Advocate(8) 
- Clerk(18) 
- Council Member(16) 
- Diplomat(3) 
- Judge(9) 
- Mayor(1) 
- Alchemist(6) 
- Chandler(16) 
- Dye Makers(16) 
- Florist(6) 
- Herbalist(6) 
- Potionmakers(6) 
- Sage(3) 
- Spice Merchant(11) 
- Taxidermist(11) 
- Tobacco Merchant(11) 
- Animal Groomer(5) 
- Animal Handler(11) 
- Caravanner(8) 
- Horse Trader(13) 
- Livestock Merchant(9) 
- Stabler(11) 
- Antiquities(11) 
- Armor Dealer(11) 
- Launderer(11) 
- Oil Trader(16) 
- Trading Post(16) 
- Slaver(11) 
- Spice Merchant(11) 
- Taxidermist(11) 
- Tobacco Merchant(11) 
- Warehouser(11) 
- Weapon Dealer(11) 
- Architect(13) 
- Bricklayer(13) 
- Engineer(13) 
- Laborer(13) 
- Mason(13) 
- Painter(Building)(13) 
- Plasterer(13) 
- Roofer(13) 
- Teamster(13) 
- Tiler(13) 
- Armorer(4) 
- Blacksmith(15) 
- Bowyer-Fletcher(5) 
- Jeweler(4) 
- Silversmith(4) 
- Weapon Dealer(11) 
- Weaponsmith(3) 
- Artist(14) 
- Glassblower(11) 
- Goldsmith(7) 
- Inventor(9) 
- Jeweler(7) 
- Magical Artisan(3) 
- Painter(Art)(11) 
- Silversmith(9) 
- Tinker(16) 
- Toymaker(5) 
- Astrologist(3) 
- Conjourer(3) 
- High Mage(3) 
- Historian(3) 
- Librarian(3) 
- Magical Artisan(3) 
- Magical Tutor(3) 
- Professor(3) 
- Scribe(3) 
- SellSpell(3) 
- Teacher(3) 
- Tutor(3) 
- Baker(10) 
- Beer Merchant(6) 
- Brewer(1) 
- Butcher(7) 
- Chicken Butcher(7) 
- Cook(7) 
- Dairy Seller(31) 
- Distiller(6) 
- Hay Merchant(31) 
- Fisherman(8) 
- Fishmonger(8) 
- Grain Merchant(1) 
- Grocer(5) 
- Meat Butcher(6) 
- Miller(16) 
- Pastry Maker(8) 
- Vintner(7) 
- Banker(4) 
- Pawnbroker(4) 
- Barbarian(31) 
- Brigand(31) 
- Captain(31) 
- Mountainman(31) 
- Barbarian(6) 
- Cartographer(6) 
- Guide(11) 
- Huntsman(16) 
- Mountainman(5) 
- Pathfinder(6) 
- Scout(6) 
- Slaver(11) 
- Barrel Maker(7) 
- Basket Maker(9) 
- Book Binder(4) 
- Bookseller(3) 
- Buckle Maker(5) 
- Candle Maker(4) 
- Clock Maker(3) 
- Cobbler(10) 
- Cooper(8) 
- Cutler(4) 
- Engraver(3) 
- Furniture Maker(10) 
- Glassblower(5) 
- Glazier(3) 
- Glove Merchant(9) 
- Goldsmith(5) 
- Harness Maker(11) 
- Hat Maker(5) 
- Instrument Maker(3) 
- Kettle Maker(3) 
- Locksmith(4) 
- Perfumer(5) 
- Potter(11) 
- Rope Maker(8) 
- Rug Maker(4) 
- Saddler(8) 
- Sculptor(3) 
- Shoe Maker(8) 
- Soap Maker(6) 
- Tanner(8) 
- Tinker(4) 
- Toymaker(3) 
- Weaponsmith(3) 
- Weaver(9) 
- Wheelwright(14) 
- Wine Merchant(6) 
- Wool Merchant(8) 
- Lord(3) 
- Knight(3) 
- Baron(2) 
- Viscount(1) 
- Earl(1) 
- Barrel Maker(11) 
- Bowyer-Fletcher(5) 
- Carpenter(18) 
- Roofer(13) 
- Wagon Maker(9) 
- Wheelwright(10) 
- Wood Carver(5) 
- Wood Seller(5) 
- Barber(6) 
- Bleacher(6) 
- Physic/Chirurgeon(6) 
- Bather(5) 
- Brigand(11) 
- Crime Lord(3) 
- Crook(13) 
- Goon(14) 
- Brothel Keeper(5) 
- Innkeeper(9) 
- Tavern Keeper(11) 
- Buckle Maker(9) 
- Cobbler(8) 
- Draper(5) 
- Furrier(14) 
- Girdler(5) 
- Haberdasher(4) 
- Launderer(9) 
- Leatherworker(6) 
- Purse Maker(6) 
- Shoe Maker(8) 
- Tailor(9) 
- Tanner(8) 
- Used Garment Trader(13) 
- Vestment Maker(8) 
- Chandler(16) 
- Dye Makers(16) 
- Oil Trader(16) 
- Cleric(11) 
- High Priest(5) 
- Missionary(41) 
- Preacher(25) 
- Priest(14) 
- Farmer(302) 
- Homestead(402) 
- Farmer - Cabbage(31) 
- Farmer - Cattle Herder(31) 
- Farmer - Corn(31) 
- Farmer - Cow Herder(31) 
- Farmer - Dairy(31) 
- Farmer - Goat Herder(31) 
- Farmer - Pig Herder(31) 
- Farmer - Potato(31) 
- Farmer - Sheep Herder(31) 
- Farmer - Wheat(31) 
- Farmer(Special)(31) 
- Dungsweeper(9) 
- Illuminator(7) 
- Messenger(10) 
- Tax Collector(2) 
- Town Crier(18) 
- Town Justice(5) 
- Undertaker(4) 
- Water Carrier(13) 
- Leatherworker(7) 
- Skinner(7) 
- Naval Outfitter(4) 
- Pirate(16) 
- Sail Maker(9) 
- Sailor(21) 
- Ship Builder(4) 
imports: 
- Iron  
exports: 
- Ceramics  
defenses: Killing Fields 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(11)  
> - Advocate(8)  
> - Alchemist(6)  
> - Animal Groomer(5)  
> - Animal Handler(11)  
> - Antiquities(11)  
> - Architect(13)  
> - Armor Dealer(11)  
> - Armorer(4)  
> - Artist(14)  
> - Astrologist(3)  
> - Baker(10)  
> - Banker(4)  
> - Barbarian(31)  
> - Barbarian(6)  
> - Barber(6)  
> - Baron(2)  
> - Barrel Maker(11)  
> - Barrel Maker(7)  
> - Basket Maker(9)  
> - Bather(5)  
> - Beer Merchant(6)  
> - Blacksmith(15)  
> - Bleacher(6)  
> - Book Binder(4)  
> - Bookseller(3)  
> - Bowyer-Fletcher(5)  
> - Bowyer-Fletcher(5)  
> - Brewer(1)  
> - Bricklayer(13)  
> - Brigand(11)  
> - Brigand(31)  
> - Brothel Keeper(5)  
> - Buckle Maker(5)  
> - Buckle Maker(9)  
> - Butcher(7)  
> - Candle Maker(4)  
> - Captain(31)  
> - Caravanner(8)  
> - Carpenter(18)  
> - Cartographer(6)  
> - Chandler(16)  
> - Chandler(16)  
> - Chicken Butcher(7)  
> - Cleric(11)  
> - Clerk(18)  
> - Clock Maker(3)  
> - Cobbler(10)  
> - Cobbler(8)  
> - Conjourer(3)  
> - Cook(7)  
> - Cooper(8)  
> - Council Member(16)  
> - Crime Lord(3)  
> - Crook(13)  
> - Cutler(4)  
> - Dairy Seller(31)  
> - Diplomat(3)  
> - Distiller(6)  
> - Draper(5)  
> - Dungsweeper(9)  
> - Dye Makers(16)  
> - Dye Makers(16)  
> - Earl(1)  
> - Engineer(13)  
> - Engraver(3)  
> - Farmer - Cabbage(31)  
> - Farmer - Cattle Herder(31)  
> - Farmer - Corn(31)  
> - Farmer - Cow Herder(31)  
> - Farmer - Dairy(31)  
> - Farmer - Goat Herder(31)  
> - Farmer - Pig Herder(31)  
> - Farmer - Potato(31)  
> - Farmer - Sheep Herder(31)  
> - Farmer - Wheat(31)  
> - Farmer(302)  
> - Farmer(Special)(31)  
> - Fisherman(8)  
> - Fishmonger(8)  
> - Florist(6)  
> - Furniture Maker(10)  
> - Furrier(14)  
> - Girdler(5)  
> - Glassblower(11)  
> - Glassblower(5)  
> - Glazier(3)  
> - Glove Merchant(9)  
> - Goldsmith(5)  
> - Goldsmith(7)  
> - Goon(14)  
> - Grain Merchant(1)  
> - Grocer(5)  
> - Guide(11)  
> - Haberdasher(4)  
> - Harness Maker(11)  
> - Hat Maker(5)  
> - Hay Merchant(31)  
> - Herbalist(6)  
> - High Mage(3)  
> - High Priest(5)  
> - Historian(3)  
> - Homestead(402)  
> - Horse Trader(13)  
> - Huntsman(16)  
> - Illuminator(7)  
> - Innkeeper(9)  
> - Instrument Maker(3)  
> - Inventor(9)  
> - Jeweler(4)  
> - Jeweler(7)  
> - Judge(9)  
> - Kettle Maker(3)  
> - Knight(3)  
> - Laborer(13)  
> - Launderer(11)  
> - Launderer(9)  
> - Leatherworker(6)  
> - Leatherworker(7)  
> - Librarian(3)  
> - Livestock Merchant(9)  
> - Locksmith(4)  
> - Lord(3)  
> - Magical Artisan(3)  
> - Magical Artisan(3)  
> - Magical Tutor(3)  
> - Mason(13)  
> - Mayor(1)  
> - Meat Butcher(6)  
> - Messenger(10)  
> - Miller(16)  
> - Minstrel(11)  
> - Missionary(41)  
> - Mountainman(31)  
> - Mountainman(5)  
> - Naval Outfitter(4)  
> - Oil Trader(16)  
> - Oil Trader(16)  
> - Painter(Art)(11)  
> - Painter(Building)(13)  
> - Pastry Maker(8)  
> - Pathfinder(6)  
> - Pawnbroker(4)  
> - Perfumer(5)  
> - Physic/Chirurgeon(6)  
> - Pirate(16)  
> - Plasterer(13)  
> - Potionmakers(6)  
> - Potter(11)  
> - Preacher(25)  
> - Priest(14)  
> - Professor(3)  
> - Purse Maker(6)  
> - Roofer(13)  
> - Roofer(13)  
> - Rope Maker(8)  
> - Rug Maker(4)  
> - Saddler(8)  
> - Sage(3)  
> - Sail Maker(9)  
> - Sailor(21)  
> - Scout(6)  
> - Scribe(3)  
> - Sculptor(3)  
> - SellSpell(3)  
> - Ship Builder(4)  
> - Shoe Maker(8)  
> - Shoe Maker(8)  
> - Silversmith(4)  
> - Silversmith(9)  
> - Skinner(7)  
> - Slaver(11)  
> - Slaver(11)  
> - Soap Maker(6)  
> - Spice Merchant(11)  
> - Spice Merchant(11)  
> - Stabler(11)  
> - Storyteller(11)  
> - Tailor(9)  
> - Tanner(8)  
> - Tanner(8)  
> - Tavern Keeper(11)  
> - Tax Collector(2)  
> - Taxidermist(11)  
> - Taxidermist(11)  
> - Teacher(3)  
> - Teamster(13)  
> - Tiler(13)  
> - Tinker(16)  
> - Tinker(4)  
> - Tobacco Merchant(11)  
> - Tobacco Merchant(11)  
> - Town Crier(18)  
> - Town Justice(5)  
> - Toymaker(3)  
> - Toymaker(5)  
> - Trading Post(16)  
> - Troubadours(11)  
> - Tutor(3)  
> - Undertaker(4)  
> - Used Garment Trader(13)  
> - Vestment Maker(8)  
> - Vintner(7)  
> - Viscount(1)  
> - Wagon Maker(9)  
> - Warehouser(11)  
> - Water Carrier(13)  
> - Weapon Dealer(11)  
> - Weapon Dealer(11)  
> - Weaponsmith(3)  
> - Weaponsmith(3)  
> - Weaver(9)  
> - Wheelwright(10)  
> - Wheelwright(14)  
> - Wine Merchant(6)  
> - Wood Carver(5)  
> - Wood Seller(5)  
> - Wool Merchant(8)  
> - Writer(11)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(11)  
> - Advocate(8)  
> - Alchemist(6)  
> - Animal Groomer(5)  
> - Animal Handler(11)  
> - Antiquities(11)  
> - Architect(13)  
> - Armor Dealer(11)  
> - Armorer(4)  
> - Artist(14)  
> - Astrologist(3)  
> - Baker(10)  
> - Banker(4)  
> - Barbarian(31)  
> - Barbarian(6)  
> - Barber(6)  
> - Baron(2)  
> - Barrel Maker(11)  
> - Barrel Maker(7)  
> - Basket Maker(9)  
> - Bather(5)  
> - Beer Merchant(6)  
> - Blacksmith(15)  
> - Bleacher(6)  
> - Book Binder(4)  
> - Bookseller(3)  
> - Bowyer-Fletcher(5)  
> - Bowyer-Fletcher(5)  
> - Brewer(1)  
> - Bricklayer(13)  
> - Brigand(11)  
> - Brigand(31)  
> - Brothel Keeper(5)  
> - Buckle Maker(5)  
> - Buckle Maker(9)  
> - Butcher(7)  
> - Candle Maker(4)  
> - Captain(31)  
> - Caravanner(8)  
> - Carpenter(18)  
> - Cartographer(6)  
> - Chandler(16)  
> - Chandler(16)  
> - Chicken Butcher(7)  
> - Cleric(11)  
> - Clerk(18)  
> - Clock Maker(3)  
> - Cobbler(10)  
> - Cobbler(8)  
> - Conjourer(3)  
> - Cook(7)  
> - Cooper(8)  
> - Council Member(16)  
> - Crime Lord(3)  
> - Crook(13)  
> - Cutler(4)  
> - Dairy Seller(31)  
> - Diplomat(3)  
> - Distiller(6)  
> - Draper(5)  
> - Dungsweeper(9)  
> - Dye Makers(16)  
> - Dye Makers(16)  
> - Earl(1)  
> - Engineer(13)  
> - Engraver(3)  
> - Farmer - Cabbage(31)  
> - Farmer - Cattle Herder(31)  
> - Farmer - Corn(31)  
> - Farmer - Cow Herder(31)  
> - Farmer - Dairy(31)  
> - Farmer - Goat Herder(31)  
> - Farmer - Pig Herder(31)  
> - Farmer - Potato(31)  
> - Farmer - Sheep Herder(31)  
> - Farmer - Wheat(31)  
> - Farmer(302)  
> - Farmer(Special)(31)  
> - Fisherman(8)  
> - Fishmonger(8)  
> - Florist(6)  
> - Furniture Maker(10)  
> - Furrier(14)  
> - Girdler(5)  
> - Glassblower(11)  
> - Glassblower(5)  
> - Glazier(3)  
> - Glove Merchant(9)  
> - Goldsmith(5)  
> - Goldsmith(7)  
> - Goon(14)  
> - Grain Merchant(1)  
> - Grocer(5)  
> - Guide(11)  
> - Haberdasher(4)  
> - Harness Maker(11)  
> - Hat Maker(5)  
> - Hay Merchant(31)  
> - Herbalist(6)  
> - High Mage(3)  
> - High Priest(5)  
> - Historian(3)  
> - Homestead(402)  
> - Horse Trader(13)  
> - Huntsman(16)  
> - Illuminator(7)  
> - Innkeeper(9)  
> - Instrument Maker(3)  
> - Inventor(9)  
> - Jeweler(4)  
> - Jeweler(7)  
> - Judge(9)  
> - Kettle Maker(3)  
> - Knight(3)  
> - Laborer(13)  
> - Launderer(11)  
> - Launderer(9)  
> - Leatherworker(6)  
> - Leatherworker(7)  
> - Librarian(3)  
> - Livestock Merchant(9)  
> - Locksmith(4)  
> - Lord(3)  
> - Magical Artisan(3)  
> - Magical Artisan(3)  
> - Magical Tutor(3)  
> - Mason(13)  
> - Mayor(1)  
> - Meat Butcher(6)  
> - Messenger(10)  
> - Miller(16)  
> - Minstrel(11)  
> - Missionary(41)  
> - Mountainman(31)  
> - Mountainman(5)  
> - Naval Outfitter(4)  
> - Oil Trader(16)  
> - Oil Trader(16)  
> - Painter(Art)(11)  
> - Painter(Building)(13)  
> - Pastry Maker(8)  
> - Pathfinder(6)  
> - Pawnbroker(4)  
> - Perfumer(5)  
> - Physic/Chirurgeon(6)  
> - Pirate(16)  
> - Plasterer(13)  
> - Potionmakers(6)  
> - Potter(11)  
> - Preacher(25)  
> - Priest(14)  
> - Professor(3)  
> - Purse Maker(6)  
> - Roofer(13)  
> - Roofer(13)  
> - Rope Maker(8)  
> - Rug Maker(4)  
> - Saddler(8)  
> - Sage(3)  
> - Sail Maker(9)  
> - Sailor(21)  
> - Scout(6)  
> - Scribe(3)  
> - Sculptor(3)  
> - SellSpell(3)  
> - Ship Builder(4)  
> - Shoe Maker(8)  
> - Shoe Maker(8)  
> - Silversmith(4)  
> - Silversmith(9)  
> - Skinner(7)  
> - Slaver(11)  
> - Slaver(11)  
> - Soap Maker(6)  
> - Spice Merchant(11)  
> - Spice Merchant(11)  
> - Stabler(11)  
> - Storyteller(11)  
> - Tailor(9)  
> - Tanner(8)  
> - Tanner(8)  
> - Tavern Keeper(11)  
> - Tax Collector(2)  
> - Taxidermist(11)  
> - Taxidermist(11)  
> - Teacher(3)  
> - Teamster(13)  
> - Tiler(13)  
> - Tinker(16)  
> - Tinker(4)  
> - Tobacco Merchant(11)  
> - Tobacco Merchant(11)  
> - Town Crier(18)  
> - Town Justice(5)  
> - Toymaker(3)  
> - Toymaker(5)  
> - Trading Post(16)  
> - Troubadours(11)  
> - Tutor(3)  
> - Undertaker(4)  
> - Used Garment Trader(13)  
> - Vestment Maker(8)  
> - Vintner(7)  
> - Viscount(1)  
> - Wagon Maker(9)  
> - Warehouser(11)  
> - Water Carrier(13)  
> - Weapon Dealer(11)  
> - Weapon Dealer(11)  
> - Weaponsmith(3)  
> - Weaponsmith(3)  
> - Weaver(9)  
> - Wheelwright(10)  
> - Wheelwright(14)  
> - Wine Merchant(6)  
> - Wood Carver(5)  
> - Wood Seller(5)  
> - Wool Merchant(8)  
> - Writer(11)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



