---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (30433)
terrain: Forest Heavy 
settlementDescription: 
population: 30433
culture: Persian 
technology: Savage 
leader: 
govermentType: Dictatorship 
demographics: 
- Acrobat(51) 
- Minstrel(51) 
- Storyteller(51) 
- Troubadours(51) 
- Writer(51) 
- Advocate(39) 
- Clerk(87) 
- Council Member(77) 
- Diplomat(13) 
- Judge(44) 
- Mayor(1) 
- Alchemist(26) 
- Chandler(77) 
- Dye Makers(77) 
- Florist(26) 
- Herbalist(26) 
- Potionmakers(26) 
- Sage(14) 
- Spice Merchant(51) 
- Taxidermist(51) 
- Tobacco Merchant(51) 
- Animal Groomer(21) 
- Animal Handler(51) 
- Caravanner(39) 
- Horse Trader(61) 
- Livestock Merchant(41) 
- Stabler(55) 
- Antiquities(51) 
- Armor Dealer(51) 
- Launderer(51) 
- Oil Trader(77) 
- Trading Post(77) 
- Slaver(51) 
- Spice Merchant(51) 
- Taxidermist(51) 
- Tobacco Merchant(51) 
- Warehouser(51) 
- Weapon Dealer(51) 
- Architect(61) 
- Bricklayer(61) 
- Engineer(61) 
- Laborer(61) 
- Mason(61) 
- Painter(Building)(61) 
- Plasterer(61) 
- Roofer(61) 
- Teamster(61) 
- Tiler(61) 
- Armorer(17) 
- Blacksmith(72) 
- Bowyer-Fletcher(25) 
- Jeweler(20) 
- Silversmith(18) 
- Weapon Dealer(51) 
- Weaponsmith(15) 
- Artist(68) 
- Glassblower(51) 
- Goldsmith(34) 
- Inventor(44) 
- Jeweler(31) 
- Magical Artisan(14) 
- Painter(Art)(56) 
- Silversmith(44) 
- Tinker(77) 
- Toymaker(24) 
- Astrologist(14) 
- Conjourer(14) 
- High Mage(14) 
- Historian(14) 
- Librarian(14) 
- Magical Artisan(14) 
- Magical Tutor(14) 
- Professor(14) 
- Scribe(14) 
- SellSpell(14) 
- Teacher(14) 
- Tutor(14) 
- Baker(47) 
- Beer Merchant(28) 
- Brewer(8) 
- Butcher(31) 
- Chicken Butcher(31) 
- Cook(33) 
- Dairy Seller(153) 
- Distiller(28) 
- Hay Merchant(153) 
- Fisherman(39) 
- Fishmonger(39) 
- Grain Merchant(8) 
- Grocer(23) 
- Meat Butcher(26) 
- Miller(77) 
- Pastry Maker(39) 
- Vintner(33) 
- Banker(17) 
- Pawnbroker(17) 
- Barbarian(153) 
- Brigand(153) 
- Captain(153) 
- Mountainman(153) 
- Barbarian(28) 
- Cartographer(26) 
- Guide(51) 
- Huntsman(77) 
- Mountainman(24) 
- Pathfinder(26) 
- Scout(26) 
- Slaver(51) 
- Barrel Maker(33) 
- Basket Maker(44) 
- Book Binder(16) 
- Bookseller(15) 
- Buckle Maker(24) 
- Candle Maker(20) 
- Clock Maker(14) 
- Cobbler(47) 
- Cooper(36) 
- Cutler(16) 
- Engraver(14) 
- Furniture Maker(47) 
- Glassblower(22) 
- Glazier(15) 
- Glove Merchant(41) 
- Goldsmith(22) 
- Harness Maker(51) 
- Hat Maker(21) 
- Instrument Maker(14) 
- Kettle Maker(14) 
- Locksmith(18) 
- Perfumer(21) 
- Potter(51) 
- Rope Maker(36) 
- Rug Maker(19) 
- Saddler(39) 
- Sculptor(13) 
- Shoe Maker(36) 
- Soap Maker(26) 
- Tanner(39) 
- Tinker(17) 
- Toymaker(14) 
- Weaponsmith(15) 
- Weaver(44) 
- Wheelwright(68) 
- Wine Merchant(26) 
- Wool Merchant(39) 
- Lord(11) 
- Knight(11) 
- Baron(7) 
- Viscount(4) 
- Earl(4) 
- Count(3) 
- Duke(2) 
- ArchDuke(1) 
- Prince(1) 
- Barrel Maker(56) 
- Bowyer-Fletcher(25) 
- Carpenter(87) 
- Roofer(61) 
- Wagon Maker(44) 
- Wheelwright(47) 
- Wood Carver(25) 
- Wood Seller(23) 
- Barber(26) 
- Bleacher(26) 
- Physic/Chirurgeon(26) 
- Bather(21) 
- Brigand(51) 
- Crime Lord(13) 
- Crook(61) 
- Goon(68) 
- Brothel Keeper(21) 
- Innkeeper(41) 
- Tavern Keeper(56) 
- Buckle Maker(41) 
- Cobbler(36) 
- Draper(25) 
- Furrier(68) 
- Girdler(23) 
- Haberdasher(20) 
- Launderer(41) 
- Leatherworker(28) 
- Purse Maker(26) 
- Shoe Maker(36) 
- Tailor(41) 
- Tanner(39) 
- Used Garment Trader(65) 
- Vestment Maker(36) 
- Chandler(77) 
- Dye Makers(77) 
- Oil Trader(77) 
- Cleric(56) 
- High Priest(21) 
- Missionary(203) 
- Preacher(122) 
- Priest(68) 
- Farmer(1522) 
- Homestead(2029) 
- Farmer - Cabbage(153) 
- Farmer - Cattle Herder(153) 
- Farmer - Corn(153) 
- Farmer - Cow Herder(153) 
- Farmer - Dairy(153) 
- Farmer - Goat Herder(153) 
- Farmer - Pig Herder(153) 
- Farmer - Potato(153) 
- Farmer - Sheep Herder(153) 
- Farmer - Wheat(153) 
- Farmer(Special)(153) 
- Dungsweeper(43) 
- Illuminator(31) 
- Messenger(47) 
- Tax Collector(8) 
- Town Crier(87) 
- Town Justice(21) 
- Undertaker(17) 
- Water Carrier(61) 
- Leatherworker(31) 
- Skinner(31) 
- Naval Outfitter(16) 
- Pirate(77) 
- Sail Maker(44) 
- Sailor(102) 
- Ship Builder(18) 
imports: 
- Carving Stone  
exports: 
- Skins  
defenses: Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(51)  
> - Advocate(39)  
> - Alchemist(26)  
> - Animal Groomer(21)  
> - Animal Handler(51)  
> - Antiquities(51)  
> - ArchDuke(1)  
> - Architect(61)  
> - Armor Dealer(51)  
> - Armorer(17)  
> - Artist(68)  
> - Astrologist(14)  
> - Baker(47)  
> - Banker(17)  
> - Barbarian(153)  
> - Barbarian(28)  
> - Barber(26)  
> - Baron(7)  
> - Barrel Maker(33)  
> - Barrel Maker(56)  
> - Basket Maker(44)  
> - Bather(21)  
> - Beer Merchant(28)  
> - Blacksmith(72)  
> - Bleacher(26)  
> - Book Binder(16)  
> - Bookseller(15)  
> - Bowyer-Fletcher(25)  
> - Bowyer-Fletcher(25)  
> - Brewer(8)  
> - Bricklayer(61)  
> - Brigand(153)  
> - Brigand(51)  
> - Brothel Keeper(21)  
> - Buckle Maker(24)  
> - Buckle Maker(41)  
> - Butcher(31)  
> - Candle Maker(20)  
> - Captain(153)  
> - Caravanner(39)  
> - Carpenter(87)  
> - Cartographer(26)  
> - Chandler(77)  
> - Chandler(77)  
> - Chicken Butcher(31)  
> - Cleric(56)  
> - Clerk(87)  
> - Clock Maker(14)  
> - Cobbler(36)  
> - Cobbler(47)  
> - Conjourer(14)  
> - Cook(33)  
> - Cooper(36)  
> - Council Member(77)  
> - Count(3)  
> - Crime Lord(13)  
> - Crook(61)  
> - Cutler(16)  
> - Dairy Seller(153)  
> - Diplomat(13)  
> - Distiller(28)  
> - Draper(25)  
> - Duke(2)  
> - Dungsweeper(43)  
> - Dye Makers(77)  
> - Dye Makers(77)  
> - Earl(4)  
> - Engineer(61)  
> - Engraver(14)  
> - Farmer - Cabbage(153)  
> - Farmer - Cattle Herder(153)  
> - Farmer - Corn(153)  
> - Farmer - Cow Herder(153)  
> - Farmer - Dairy(153)  
> - Farmer - Goat Herder(153)  
> - Farmer - Pig Herder(153)  
> - Farmer - Potato(153)  
> - Farmer - Sheep Herder(153)  
> - Farmer - Wheat(153)  
> - Farmer(1522)  
> - Farmer(Special)(153)  
> - Fisherman(39)  
> - Fishmonger(39)  
> - Florist(26)  
> - Furniture Maker(47)  
> - Furrier(68)  
> - Girdler(23)  
> - Glassblower(22)  
> - Glassblower(51)  
> - Glazier(15)  
> - Glove Merchant(41)  
> - Goldsmith(22)  
> - Goldsmith(34)  
> - Goon(68)  
> - Grain Merchant(8)  
> - Grocer(23)  
> - Guide(51)  
> - Haberdasher(20)  
> - Harness Maker(51)  
> - Hat Maker(21)  
> - Hay Merchant(153)  
> - Herbalist(26)  
> - High Mage(14)  
> - High Priest(21)  
> - Historian(14)  
> - Homestead(2029)  
> - Horse Trader(61)  
> - Huntsman(77)  
> - Illuminator(31)  
> - Innkeeper(41)  
> - Instrument Maker(14)  
> - Inventor(44)  
> - Jeweler(20)  
> - Jeweler(31)  
> - Judge(44)  
> - Kettle Maker(14)  
> - Knight(11)  
> - Laborer(61)  
> - Launderer(41)  
> - Launderer(51)  
> - Leatherworker(28)  
> - Leatherworker(31)  
> - Librarian(14)  
> - Livestock Merchant(41)  
> - Locksmith(18)  
> - Lord(11)  
> - Magical Artisan(14)  
> - Magical Artisan(14)  
> - Magical Tutor(14)  
> - Mason(61)  
> - Mayor(1)  
> - Meat Butcher(26)  
> - Messenger(47)  
> - Miller(77)  
> - Minstrel(51)  
> - Missionary(203)  
> - Mountainman(153)  
> - Mountainman(24)  
> - Naval Outfitter(16)  
> - Oil Trader(77)  
> - Oil Trader(77)  
> - Painter(Art)(56)  
> - Painter(Building)(61)  
> - Pastry Maker(39)  
> - Pathfinder(26)  
> - Pawnbroker(17)  
> - Perfumer(21)  
> - Physic/Chirurgeon(26)  
> - Pirate(77)  
> - Plasterer(61)  
> - Potionmakers(26)  
> - Potter(51)  
> - Preacher(122)  
> - Priest(68)  
> - Prince(1)  
> - Professor(14)  
> - Purse Maker(26)  
> - Roofer(61)  
> - Roofer(61)  
> - Rope Maker(36)  
> - Rug Maker(19)  
> - Saddler(39)  
> - Sage(14)  
> - Sail Maker(44)  
> - Sailor(102)  
> - Scout(26)  
> - Scribe(14)  
> - Sculptor(13)  
> - SellSpell(14)  
> - Ship Builder(18)  
> - Shoe Maker(36)  
> - Shoe Maker(36)  
> - Silversmith(18)  
> - Silversmith(44)  
> - Skinner(31)  
> - Slaver(51)  
> - Slaver(51)  
> - Soap Maker(26)  
> - Spice Merchant(51)  
> - Spice Merchant(51)  
> - Stabler(55)  
> - Storyteller(51)  
> - Tailor(41)  
> - Tanner(39)  
> - Tanner(39)  
> - Tavern Keeper(56)  
> - Tax Collector(8)  
> - Taxidermist(51)  
> - Taxidermist(51)  
> - Teacher(14)  
> - Teamster(61)  
> - Tiler(61)  
> - Tinker(17)  
> - Tinker(77)  
> - Tobacco Merchant(51)  
> - Tobacco Merchant(51)  
> - Town Crier(87)  
> - Town Justice(21)  
> - Toymaker(14)  
> - Toymaker(24)  
> - Trading Post(77)  
> - Troubadours(51)  
> - Tutor(14)  
> - Undertaker(17)  
> - Used Garment Trader(65)  
> - Vestment Maker(36)  
> - Vintner(33)  
> - Viscount(4)  
> - Wagon Maker(44)  
> - Warehouser(51)  
> - Water Carrier(61)  
> - Weapon Dealer(51)  
> - Weapon Dealer(51)  
> - Weaponsmith(15)  
> - Weaponsmith(15)  
> - Weaver(44)  
> - Wheelwright(47)  
> - Wheelwright(68)  
> - Wine Merchant(26)  
> - Wood Carver(25)  
> - Wood Seller(23)  
> - Wool Merchant(39)  
> - Writer(51)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(51)  
> - Advocate(39)  
> - Alchemist(26)  
> - Animal Groomer(21)  
> - Animal Handler(51)  
> - Antiquities(51)  
> - ArchDuke(1)  
> - Architect(61)  
> - Armor Dealer(51)  
> - Armorer(17)  
> - Artist(68)  
> - Astrologist(14)  
> - Baker(47)  
> - Banker(17)  
> - Barbarian(153)  
> - Barbarian(28)  
> - Barber(26)  
> - Baron(7)  
> - Barrel Maker(33)  
> - Barrel Maker(56)  
> - Basket Maker(44)  
> - Bather(21)  
> - Beer Merchant(28)  
> - Blacksmith(72)  
> - Bleacher(26)  
> - Book Binder(16)  
> - Bookseller(15)  
> - Bowyer-Fletcher(25)  
> - Bowyer-Fletcher(25)  
> - Brewer(8)  
> - Bricklayer(61)  
> - Brigand(153)  
> - Brigand(51)  
> - Brothel Keeper(21)  
> - Buckle Maker(24)  
> - Buckle Maker(41)  
> - Butcher(31)  
> - Candle Maker(20)  
> - Captain(153)  
> - Caravanner(39)  
> - Carpenter(87)  
> - Cartographer(26)  
> - Chandler(77)  
> - Chandler(77)  
> - Chicken Butcher(31)  
> - Cleric(56)  
> - Clerk(87)  
> - Clock Maker(14)  
> - Cobbler(36)  
> - Cobbler(47)  
> - Conjourer(14)  
> - Cook(33)  
> - Cooper(36)  
> - Council Member(77)  
> - Count(3)  
> - Crime Lord(13)  
> - Crook(61)  
> - Cutler(16)  
> - Dairy Seller(153)  
> - Diplomat(13)  
> - Distiller(28)  
> - Draper(25)  
> - Duke(2)  
> - Dungsweeper(43)  
> - Dye Makers(77)  
> - Dye Makers(77)  
> - Earl(4)  
> - Engineer(61)  
> - Engraver(14)  
> - Farmer - Cabbage(153)  
> - Farmer - Cattle Herder(153)  
> - Farmer - Corn(153)  
> - Farmer - Cow Herder(153)  
> - Farmer - Dairy(153)  
> - Farmer - Goat Herder(153)  
> - Farmer - Pig Herder(153)  
> - Farmer - Potato(153)  
> - Farmer - Sheep Herder(153)  
> - Farmer - Wheat(153)  
> - Farmer(1522)  
> - Farmer(Special)(153)  
> - Fisherman(39)  
> - Fishmonger(39)  
> - Florist(26)  
> - Furniture Maker(47)  
> - Furrier(68)  
> - Girdler(23)  
> - Glassblower(22)  
> - Glassblower(51)  
> - Glazier(15)  
> - Glove Merchant(41)  
> - Goldsmith(22)  
> - Goldsmith(34)  
> - Goon(68)  
> - Grain Merchant(8)  
> - Grocer(23)  
> - Guide(51)  
> - Haberdasher(20)  
> - Harness Maker(51)  
> - Hat Maker(21)  
> - Hay Merchant(153)  
> - Herbalist(26)  
> - High Mage(14)  
> - High Priest(21)  
> - Historian(14)  
> - Homestead(2029)  
> - Horse Trader(61)  
> - Huntsman(77)  
> - Illuminator(31)  
> - Innkeeper(41)  
> - Instrument Maker(14)  
> - Inventor(44)  
> - Jeweler(20)  
> - Jeweler(31)  
> - Judge(44)  
> - Kettle Maker(14)  
> - Knight(11)  
> - Laborer(61)  
> - Launderer(41)  
> - Launderer(51)  
> - Leatherworker(28)  
> - Leatherworker(31)  
> - Librarian(14)  
> - Livestock Merchant(41)  
> - Locksmith(18)  
> - Lord(11)  
> - Magical Artisan(14)  
> - Magical Artisan(14)  
> - Magical Tutor(14)  
> - Mason(61)  
> - Mayor(1)  
> - Meat Butcher(26)  
> - Messenger(47)  
> - Miller(77)  
> - Minstrel(51)  
> - Missionary(203)  
> - Mountainman(153)  
> - Mountainman(24)  
> - Naval Outfitter(16)  
> - Oil Trader(77)  
> - Oil Trader(77)  
> - Painter(Art)(56)  
> - Painter(Building)(61)  
> - Pastry Maker(39)  
> - Pathfinder(26)  
> - Pawnbroker(17)  
> - Perfumer(21)  
> - Physic/Chirurgeon(26)  
> - Pirate(77)  
> - Plasterer(61)  
> - Potionmakers(26)  
> - Potter(51)  
> - Preacher(122)  
> - Priest(68)  
> - Prince(1)  
> - Professor(14)  
> - Purse Maker(26)  
> - Roofer(61)  
> - Roofer(61)  
> - Rope Maker(36)  
> - Rug Maker(19)  
> - Saddler(39)  
> - Sage(14)  
> - Sail Maker(44)  
> - Sailor(102)  
> - Scout(26)  
> - Scribe(14)  
> - Sculptor(13)  
> - SellSpell(14)  
> - Ship Builder(18)  
> - Shoe Maker(36)  
> - Shoe Maker(36)  
> - Silversmith(18)  
> - Silversmith(44)  
> - Skinner(31)  
> - Slaver(51)  
> - Slaver(51)  
> - Soap Maker(26)  
> - Spice Merchant(51)  
> - Spice Merchant(51)  
> - Stabler(55)  
> - Storyteller(51)  
> - Tailor(41)  
> - Tanner(39)  
> - Tanner(39)  
> - Tavern Keeper(56)  
> - Tax Collector(8)  
> - Taxidermist(51)  
> - Taxidermist(51)  
> - Teacher(14)  
> - Teamster(61)  
> - Tiler(61)  
> - Tinker(17)  
> - Tinker(77)  
> - Tobacco Merchant(51)  
> - Tobacco Merchant(51)  
> - Town Crier(87)  
> - Town Justice(21)  
> - Toymaker(14)  
> - Toymaker(24)  
> - Trading Post(77)  
> - Troubadours(51)  
> - Tutor(14)  
> - Undertaker(17)  
> - Used Garment Trader(65)  
> - Vestment Maker(36)  
> - Vintner(33)  
> - Viscount(4)  
> - Wagon Maker(44)  
> - Warehouser(51)  
> - Water Carrier(61)  
> - Weapon Dealer(51)  
> - Weapon Dealer(51)  
> - Weaponsmith(15)  
> - Weaponsmith(15)  
> - Weaver(44)  
> - Wheelwright(47)  
> - Wheelwright(68)  
> - Wine Merchant(26)  
> - Wood Carver(25)  
> - Wood Seller(23)  
> - Wool Merchant(39)  
> - Writer(51)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



