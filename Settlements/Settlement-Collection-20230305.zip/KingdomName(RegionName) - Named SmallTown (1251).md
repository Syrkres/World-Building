---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallTown
kingdom: KingdomName
region: RegionName
settlementName: Named SmallTown (1251)
terrain: Forest Heavy Boreal 
settlementDescription: 
population: 1251
culture: Renaissance 
technology: Roman 
leader: 
govermentType: Monarchy 
demographics: 
- Acrobat(3) 
- Minstrel(3) 
- Storyteller(3) 
- Troubadours(3) 
- Writer(3) 
- Advocate(2) 
- Clerk(4) 
- Council Member(4) 
- Judge(2) 
- Mayor(1) 
- Alchemist(1) 
- Chandler(4) 
- Dye Makers(4) 
- Florist(1) 
- Herbalist(1) 
- Potionmakers(1) 
- Spice Merchant(3) 
- Taxidermist(3) 
- Tobacco Merchant(3) 
- Animal Handler(3) 
- Caravanner(2) 
- Horse Trader(3) 
- Livestock Merchant(2) 
- Stabler(3) 
- Antiquities(3) 
- Armor Dealer(3) 
- Launderer(3) 
- Oil Trader(4) 
- Trading Post(4) 
- Slaver(3) 
- Spice Merchant(3) 
- Taxidermist(3) 
- Tobacco Merchant(3) 
- Warehouser(3) 
- Weapon Dealer(3) 
- Architect(3) 
- Bricklayer(3) 
- Engineer(3) 
- Laborer(3) 
- Mason(3) 
- Painter(Building)(3) 
- Plasterer(3) 
- Roofer(3) 
- Teamster(3) 
- Tiler(3) 
- Armorer(1) 
- Blacksmith(3) 
- Bowyer-Fletcher(1) 
- Jeweler(1) 
- Silversmith(1) 
- Weapon Dealer(3) 
- Artist(3) 
- Glassblower(3) 
- Goldsmith(1) 
- Inventor(2) 
- Jeweler(1) 
- Painter(Art)(3) 
- Silversmith(1) 
- Tinker(4) 
- Toymaker(1) 
- Baker(1) 
- Beer Merchant(1) 
- Butcher(1) 
- Chicken Butcher(1) 
- Cook(1) 
- Dairy Seller(7) 
- Distiller(1) 
- Hay Merchant(1) 
- Fisherman(1) 
- Fishmonger(1) 
- Meat Butcher(1) 
- Miller(4) 
- Pastry Maker(1) 
- Vintner(1) 
- Barbarian(7) 
- Brigand(7) 
- Captain(7) 
- Mountainman(7) 
- Barbarian(2) 
- Cartographer(1) 
- Guide(3) 
- Huntsman(4) 
- Mountainman(1) 
- Pathfinder(1) 
- Scout(1) 
- Slaver(3) 
- Barrel Maker(2) 
- Basket Maker(1) 
- Buckle Maker(1) 
- Candle Maker(1) 
- Cobbler(2) 
- Cooper(2) 
- Cutler(1) 
- Furniture Maker(2) 
- Glassblower(1) 
- Glazier(1) 
- Glove Merchant(1) 
- Goldsmith(1) 
- Harness Maker(3) 
- Potter(3) 
- Rope Maker(1) 
- Saddler(2) 
- Shoe Maker(1) 
- Soap Maker(1) 
- Tanner(1) 
- Weaver(2) 
- Wheelwright(3) 
- Wine Merchant(1) 
- Wool Merchant(2) 
- Lord(1) 
- Barrel Maker(3) 
- Bowyer-Fletcher(1) 
- Carpenter(4) 
- Roofer(3) 
- Wagon Maker(1) 
- Wheelwright(2) 
- Wood Carver(1) 
- Barber(1) 
- Bleacher(1) 
- Physic/Chirurgeon(2) 
- Bather(1) 
- Brigand(3) 
- Crook(3) 
- Goon(3) 
- Brothel Keeper(1) 
- Innkeeper(2) 
- Tavern Keeper(3) 
- Buckle Maker(2) 
- Cobbler(2) 
- Draper(2) 
- Furrier(3) 
- Girdler(1) 
- Haberdasher(1) 
- Launderer(2) 
- Leatherworker(2) 
- Purse Maker(1) 
- Shoe Maker(2) 
- Tailor(2) 
- Tanner(2) 
- Used Garment Trader(3) 
- Vestment Maker(1) 
- Chandler(4) 
- Dye Makers(4) 
- Oil Trader(4) 
- Cleric(3) 
- High Priest(1) 
- Missionary(9) 
- Preacher(6) 
- Priest(3) 
- Farmer(63) 
- Homestead(84) 
- Farmer - Cabbage(7) 
- Farmer - Cattle Herder(7) 
- Farmer - Corn(7) 
- Farmer - Cow Herder(7) 
- Farmer - Dairy(7) 
- Farmer - Goat Herder(7) 
- Farmer - Pig Herder(7) 
- Farmer - Potato(7) 
- Farmer - Sheep Herder(7) 
- Farmer - Wheat(7) 
- Farmer(Special)(7) 
- Dungsweeper(2) 
- Illuminator(1) 
- Messenger(2) 
- Town Crier(4) 
- Town Justice(1) 
- Undertaker(1) 
- Water Carrier(3) 
- Leatherworker(1) 
- Skinner(1) 
- Pirate(4) 
- Sail Maker(2) 
- Sailor(5) 
imports: 
- Sandstone  
exports: 
- Incense  
defenses: Baileys 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(3)  
> - Advocate(2)  
> - Alchemist(1)  
> - Animal Handler(3)  
> - Antiquities(3)  
> - Architect(3)  
> - Armor Dealer(3)  
> - Armorer(1)  
> - Artist(3)  
> - Baker(1)  
> - Barbarian(2)  
> - Barbarian(7)  
> - Barber(1)  
> - Barrel Maker(2)  
> - Barrel Maker(3)  
> - Basket Maker(1)  
> - Bather(1)  
> - Beer Merchant(1)  
> - Blacksmith(3)  
> - Bleacher(1)  
> - Bowyer-Fletcher(1)  
> - Bowyer-Fletcher(1)  
> - Bricklayer(3)  
> - Brigand(3)  
> - Brigand(7)  
> - Brothel Keeper(1)  
> - Buckle Maker(1)  
> - Buckle Maker(2)  
> - Butcher(1)  
> - Candle Maker(1)  
> - Captain(7)  
> - Caravanner(2)  
> - Carpenter(4)  
> - Cartographer(1)  
> - Chandler(4)  
> - Chandler(4)  
> - Chicken Butcher(1)  
> - Cleric(3)  
> - Clerk(4)  
> - Cobbler(2)  
> - Cobbler(2)  
> - Cook(1)  
> - Cooper(2)  
> - Council Member(4)  
> - Crook(3)  
> - Cutler(1)  
> - Dairy Seller(7)  
> - Distiller(1)  
> - Draper(2)  
> - Dungsweeper(2)  
> - Dye Makers(4)  
> - Dye Makers(4)  
> - Engineer(3)  
> - Farmer - Cabbage(7)  
> - Farmer - Cattle Herder(7)  
> - Farmer - Corn(7)  
> - Farmer - Cow Herder(7)  
> - Farmer - Dairy(7)  
> - Farmer - Goat Herder(7)  
> - Farmer - Pig Herder(7)  
> - Farmer - Potato(7)  
> - Farmer - Sheep Herder(7)  
> - Farmer - Wheat(7)  
> - Farmer(63)  
> - Farmer(Special)(7)  
> - Fisherman(1)  
> - Fishmonger(1)  
> - Florist(1)  
> - Furniture Maker(2)  
> - Furrier(3)  
> - Girdler(1)  
> - Glassblower(1)  
> - Glassblower(3)  
> - Glazier(1)  
> - Glove Merchant(1)  
> - Goldsmith(1)  
> - Goldsmith(1)  
> - Goon(3)  
> - Guide(3)  
> - Haberdasher(1)  
> - Harness Maker(3)  
> - Hay Merchant(1)  
> - Herbalist(1)  
> - High Priest(1)  
> - Homestead(84)  
> - Horse Trader(3)  
> - Huntsman(4)  
> - Illuminator(1)  
> - Innkeeper(2)  
> - Inventor(2)  
> - Jeweler(1)  
> - Jeweler(1)  
> - Judge(2)  
> - Laborer(3)  
> - Launderer(2)  
> - Launderer(3)  
> - Leatherworker(1)  
> - Leatherworker(2)  
> - Livestock Merchant(2)  
> - Lord(1)  
> - Mason(3)  
> - Mayor(1)  
> - Meat Butcher(1)  
> - Messenger(2)  
> - Miller(4)  
> - Minstrel(3)  
> - Missionary(9)  
> - Mountainman(1)  
> - Mountainman(7)  
> - Oil Trader(4)  
> - Oil Trader(4)  
> - Painter(Art)(3)  
> - Painter(Building)(3)  
> - Pastry Maker(1)  
> - Pathfinder(1)  
> - Physic/Chirurgeon(2)  
> - Pirate(4)  
> - Plasterer(3)  
> - Potionmakers(1)  
> - Potter(3)  
> - Preacher(6)  
> - Priest(3)  
> - Purse Maker(1)  
> - Roofer(3)  
> - Roofer(3)  
> - Rope Maker(1)  
> - Saddler(2)  
> - Sail Maker(2)  
> - Sailor(5)  
> - Scout(1)  
> - Shoe Maker(1)  
> - Shoe Maker(2)  
> - Silversmith(1)  
> - Silversmith(1)  
> - Skinner(1)  
> - Slaver(3)  
> - Slaver(3)  
> - Soap Maker(1)  
> - Spice Merchant(3)  
> - Spice Merchant(3)  
> - Stabler(3)  
> - Storyteller(3)  
> - Tailor(2)  
> - Tanner(1)  
> - Tanner(2)  
> - Tavern Keeper(3)  
> - Taxidermist(3)  
> - Taxidermist(3)  
> - Teamster(3)  
> - Tiler(3)  
> - Tinker(4)  
> - Tobacco Merchant(3)  
> - Tobacco Merchant(3)  
> - Town Crier(4)  
> - Town Justice(1)  
> - Toymaker(1)  
> - Trading Post(4)  
> - Troubadours(3)  
> - Undertaker(1)  
> - Used Garment Trader(3)  
> - Vestment Maker(1)  
> - Vintner(1)  
> - Wagon Maker(1)  
> - Warehouser(3)  
> - Water Carrier(3)  
> - Weapon Dealer(3)  
> - Weapon Dealer(3)  
> - Weaver(2)  
> - Wheelwright(2)  
> - Wheelwright(3)  
> - Wine Merchant(1)  
> - Wood Carver(1)  
> - Wool Merchant(2)  
> - Writer(3)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(3)  
> - Advocate(2)  
> - Alchemist(1)  
> - Animal Handler(3)  
> - Antiquities(3)  
> - Architect(3)  
> - Armor Dealer(3)  
> - Armorer(1)  
> - Artist(3)  
> - Baker(1)  
> - Barbarian(2)  
> - Barbarian(7)  
> - Barber(1)  
> - Barrel Maker(2)  
> - Barrel Maker(3)  
> - Basket Maker(1)  
> - Bather(1)  
> - Beer Merchant(1)  
> - Blacksmith(3)  
> - Bleacher(1)  
> - Bowyer-Fletcher(1)  
> - Bowyer-Fletcher(1)  
> - Bricklayer(3)  
> - Brigand(3)  
> - Brigand(7)  
> - Brothel Keeper(1)  
> - Buckle Maker(1)  
> - Buckle Maker(2)  
> - Butcher(1)  
> - Candle Maker(1)  
> - Captain(7)  
> - Caravanner(2)  
> - Carpenter(4)  
> - Cartographer(1)  
> - Chandler(4)  
> - Chandler(4)  
> - Chicken Butcher(1)  
> - Cleric(3)  
> - Clerk(4)  
> - Cobbler(2)  
> - Cobbler(2)  
> - Cook(1)  
> - Cooper(2)  
> - Council Member(4)  
> - Crook(3)  
> - Cutler(1)  
> - Dairy Seller(7)  
> - Distiller(1)  
> - Draper(2)  
> - Dungsweeper(2)  
> - Dye Makers(4)  
> - Dye Makers(4)  
> - Engineer(3)  
> - Farmer - Cabbage(7)  
> - Farmer - Cattle Herder(7)  
> - Farmer - Corn(7)  
> - Farmer - Cow Herder(7)  
> - Farmer - Dairy(7)  
> - Farmer - Goat Herder(7)  
> - Farmer - Pig Herder(7)  
> - Farmer - Potato(7)  
> - Farmer - Sheep Herder(7)  
> - Farmer - Wheat(7)  
> - Farmer(63)  
> - Farmer(Special)(7)  
> - Fisherman(1)  
> - Fishmonger(1)  
> - Florist(1)  
> - Furniture Maker(2)  
> - Furrier(3)  
> - Girdler(1)  
> - Glassblower(1)  
> - Glassblower(3)  
> - Glazier(1)  
> - Glove Merchant(1)  
> - Goldsmith(1)  
> - Goldsmith(1)  
> - Goon(3)  
> - Guide(3)  
> - Haberdasher(1)  
> - Harness Maker(3)  
> - Hay Merchant(1)  
> - Herbalist(1)  
> - High Priest(1)  
> - Homestead(84)  
> - Horse Trader(3)  
> - Huntsman(4)  
> - Illuminator(1)  
> - Innkeeper(2)  
> - Inventor(2)  
> - Jeweler(1)  
> - Jeweler(1)  
> - Judge(2)  
> - Laborer(3)  
> - Launderer(2)  
> - Launderer(3)  
> - Leatherworker(1)  
> - Leatherworker(2)  
> - Livestock Merchant(2)  
> - Lord(1)  
> - Mason(3)  
> - Mayor(1)  
> - Meat Butcher(1)  
> - Messenger(2)  
> - Miller(4)  
> - Minstrel(3)  
> - Missionary(9)  
> - Mountainman(1)  
> - Mountainman(7)  
> - Oil Trader(4)  
> - Oil Trader(4)  
> - Painter(Art)(3)  
> - Painter(Building)(3)  
> - Pastry Maker(1)  
> - Pathfinder(1)  
> - Physic/Chirurgeon(2)  
> - Pirate(4)  
> - Plasterer(3)  
> - Potionmakers(1)  
> - Potter(3)  
> - Preacher(6)  
> - Priest(3)  
> - Purse Maker(1)  
> - Roofer(3)  
> - Roofer(3)  
> - Rope Maker(1)  
> - Saddler(2)  
> - Sail Maker(2)  
> - Sailor(5)  
> - Scout(1)  
> - Shoe Maker(1)  
> - Shoe Maker(2)  
> - Silversmith(1)  
> - Silversmith(1)  
> - Skinner(1)  
> - Slaver(3)  
> - Slaver(3)  
> - Soap Maker(1)  
> - Spice Merchant(3)  
> - Spice Merchant(3)  
> - Stabler(3)  
> - Storyteller(3)  
> - Tailor(2)  
> - Tanner(1)  
> - Tanner(2)  
> - Tavern Keeper(3)  
> - Taxidermist(3)  
> - Taxidermist(3)  
> - Teamster(3)  
> - Tiler(3)  
> - Tinker(4)  
> - Tobacco Merchant(3)  
> - Tobacco Merchant(3)  
> - Town Crier(4)  
> - Town Justice(1)  
> - Toymaker(1)  
> - Trading Post(4)  
> - Troubadours(3)  
> - Undertaker(1)  
> - Used Garment Trader(3)  
> - Vestment Maker(1)  
> - Vintner(1)  
> - Wagon Maker(1)  
> - Warehouser(3)  
> - Water Carrier(3)  
> - Weapon Dealer(3)  
> - Weapon Dealer(3)  
> - Weaver(2)  
> - Wheelwright(2)  
> - Wheelwright(3)  
> - Wine Merchant(1)  
> - Wood Carver(1)  
> - Wool Merchant(2)  
> - Writer(3)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



