---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallCity
kingdom: KingdomName
region: RegionName
settlementName: Named SmallCity (10083)
terrain: Savannah Hills 
settlementDescription: 
population: 10083
culture: European 
technology: Bronze Age 
leader: 
govermentType: Democracy 
demographics: 
- Acrobat(17) 
- Minstrel(17) 
- Storyteller(17) 
- Troubadours(17) 
- Writer(17) 
- Advocate(13) 
- Clerk(29) 
- Council Member(26) 
- Diplomat(5) 
- Judge(15) 
- Mayor(1) 
- Alchemist(9) 
- Chandler(26) 
- Dye Makers(26) 
- Florist(9) 
- Herbalist(9) 
- Potionmakers(9) 
- Sage(5) 
- Spice Merchant(17) 
- Taxidermist(17) 
- Tobacco Merchant(17) 
- Animal Groomer(7) 
- Animal Handler(17) 
- Caravanner(13) 
- Horse Trader(21) 
- Livestock Merchant(14) 
- Stabler(19) 
- Antiquities(17) 
- Armor Dealer(17) 
- Launderer(17) 
- Oil Trader(26) 
- Trading Post(26) 
- Slaver(17) 
- Spice Merchant(17) 
- Taxidermist(17) 
- Tobacco Merchant(17) 
- Warehouser(17) 
- Weapon Dealer(17) 
- Architect(21) 
- Bricklayer(21) 
- Engineer(21) 
- Laborer(21) 
- Mason(21) 
- Painter(Building)(21) 
- Plasterer(21) 
- Roofer(21) 
- Teamster(21) 
- Tiler(21) 
- Armorer(6) 
- Blacksmith(24) 
- Bowyer-Fletcher(9) 
- Jeweler(7) 
- Silversmith(6) 
- Weapon Dealer(17) 
- Weaponsmith(5) 
- Artist(23) 
- Glassblower(17) 
- Goldsmith(12) 
- Inventor(15) 
- Jeweler(11) 
- Magical Artisan(5) 
- Painter(Art)(19) 
- Silversmith(15) 
- Tinker(26) 
- Toymaker(8) 
- Astrologist(5) 
- Conjourer(5) 
- High Mage(5) 
- Historian(5) 
- Librarian(5) 
- Magical Artisan(5) 
- Magical Tutor(5) 
- Professor(5) 
- Scribe(5) 
- SellSpell(5) 
- Teacher(5) 
- Tutor(5) 
- Baker(16) 
- Beer Merchant(10) 
- Brewer(3) 
- Butcher(11) 
- Chicken Butcher(11) 
- Cook(11) 
- Dairy Seller(51) 
- Distiller(10) 
- Hay Merchant(51) 
- Fisherman(13) 
- Fishmonger(13) 
- Grain Merchant(3) 
- Grocer(8) 
- Meat Butcher(9) 
- Miller(26) 
- Pastry Maker(13) 
- Vintner(11) 
- Banker(6) 
- Pawnbroker(6) 
- Barbarian(51) 
- Brigand(51) 
- Captain(51) 
- Mountainman(51) 
- Barbarian(10) 
- Cartographer(9) 
- Guide(17) 
- Huntsman(26) 
- Mountainman(8) 
- Pathfinder(9) 
- Scout(9) 
- Slaver(17) 
- Barrel Maker(11) 
- Basket Maker(15) 
- Book Binder(6) 
- Bookseller(5) 
- Buckle Maker(8) 
- Candle Maker(7) 
- Clock Maker(5) 
- Cobbler(16) 
- Cooper(12) 
- Cutler(6) 
- Engraver(5) 
- Furniture Maker(16) 
- Glassblower(8) 
- Glazier(5) 
- Glove Merchant(14) 
- Goldsmith(8) 
- Harness Maker(17) 
- Hat Maker(7) 
- Instrument Maker(5) 
- Kettle Maker(5) 
- Locksmith(6) 
- Perfumer(7) 
- Potter(17) 
- Rope Maker(12) 
- Rug Maker(7) 
- Saddler(13) 
- Sculptor(5) 
- Shoe Maker(12) 
- Soap Maker(9) 
- Tanner(13) 
- Tinker(6) 
- Toymaker(5) 
- Weaponsmith(5) 
- Weaver(15) 
- Wheelwright(23) 
- Wine Merchant(9) 
- Wool Merchant(13) 
- Lord(4) 
- Knight(4) 
- Baron(3) 
- Viscount(2) 
- Earl(1) 
- Count(1) 
- Duke(1) 
- Barrel Maker(19) 
- Bowyer-Fletcher(9) 
- Carpenter(29) 
- Roofer(21) 
- Wagon Maker(15) 
- Wheelwright(16) 
- Wood Carver(9) 
- Wood Seller(8) 
- Barber(9) 
- Bleacher(9) 
- Physic/Chirurgeon(9) 
- Bather(7) 
- Brigand(17) 
- Crime Lord(5) 
- Crook(21) 
- Goon(23) 
- Brothel Keeper(7) 
- Innkeeper(14) 
- Tavern Keeper(19) 
- Buckle Maker(14) 
- Cobbler(12) 
- Draper(9) 
- Furrier(23) 
- Girdler(8) 
- Haberdasher(7) 
- Launderer(14) 
- Leatherworker(10) 
- Purse Maker(9) 
- Shoe Maker(12) 
- Tailor(14) 
- Tanner(13) 
- Used Garment Trader(22) 
- Vestment Maker(12) 
- Chandler(26) 
- Dye Makers(26) 
- Oil Trader(26) 
- Cleric(19) 
- High Priest(7) 
- Missionary(68) 
- Preacher(41) 
- Priest(23) 
- Farmer(505) 
- Homestead(673) 
- Farmer - Cabbage(51) 
- Farmer - Cattle Herder(51) 
- Farmer - Corn(51) 
- Farmer - Cow Herder(51) 
- Farmer - Dairy(51) 
- Farmer - Goat Herder(51) 
- Farmer - Pig Herder(51) 
- Farmer - Potato(51) 
- Farmer - Sheep Herder(51) 
- Farmer - Wheat(51) 
- Farmer(Special)(51) 
- Dungsweeper(15) 
- Illuminator(11) 
- Messenger(16) 
- Tax Collector(3) 
- Town Crier(29) 
- Town Justice(7) 
- Undertaker(6) 
- Water Carrier(21) 
- Leatherworker(11) 
- Skinner(11) 
- Naval Outfitter(6) 
- Pirate(26) 
- Sail Maker(15) 
- Sailor(34) 
- Ship Builder(6) 
imports: 
- Whale Bones  
exports: 
- Silicates  
defenses: Wood Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(17)  
> - Advocate(13)  
> - Alchemist(9)  
> - Animal Groomer(7)  
> - Animal Handler(17)  
> - Antiquities(17)  
> - Architect(21)  
> - Armor Dealer(17)  
> - Armorer(6)  
> - Artist(23)  
> - Astrologist(5)  
> - Baker(16)  
> - Banker(6)  
> - Barbarian(10)  
> - Barbarian(51)  
> - Barber(9)  
> - Baron(3)  
> - Barrel Maker(11)  
> - Barrel Maker(19)  
> - Basket Maker(15)  
> - Bather(7)  
> - Beer Merchant(10)  
> - Blacksmith(24)  
> - Bleacher(9)  
> - Book Binder(6)  
> - Bookseller(5)  
> - Bowyer-Fletcher(9)  
> - Bowyer-Fletcher(9)  
> - Brewer(3)  
> - Bricklayer(21)  
> - Brigand(17)  
> - Brigand(51)  
> - Brothel Keeper(7)  
> - Buckle Maker(14)  
> - Buckle Maker(8)  
> - Butcher(11)  
> - Candle Maker(7)  
> - Captain(51)  
> - Caravanner(13)  
> - Carpenter(29)  
> - Cartographer(9)  
> - Chandler(26)  
> - Chandler(26)  
> - Chicken Butcher(11)  
> - Cleric(19)  
> - Clerk(29)  
> - Clock Maker(5)  
> - Cobbler(12)  
> - Cobbler(16)  
> - Conjourer(5)  
> - Cook(11)  
> - Cooper(12)  
> - Council Member(26)  
> - Count(1)  
> - Crime Lord(5)  
> - Crook(21)  
> - Cutler(6)  
> - Dairy Seller(51)  
> - Diplomat(5)  
> - Distiller(10)  
> - Draper(9)  
> - Duke(1)  
> - Dungsweeper(15)  
> - Dye Makers(26)  
> - Dye Makers(26)  
> - Earl(1)  
> - Engineer(21)  
> - Engraver(5)  
> - Farmer - Cabbage(51)  
> - Farmer - Cattle Herder(51)  
> - Farmer - Corn(51)  
> - Farmer - Cow Herder(51)  
> - Farmer - Dairy(51)  
> - Farmer - Goat Herder(51)  
> - Farmer - Pig Herder(51)  
> - Farmer - Potato(51)  
> - Farmer - Sheep Herder(51)  
> - Farmer - Wheat(51)  
> - Farmer(505)  
> - Farmer(Special)(51)  
> - Fisherman(13)  
> - Fishmonger(13)  
> - Florist(9)  
> - Furniture Maker(16)  
> - Furrier(23)  
> - Girdler(8)  
> - Glassblower(17)  
> - Glassblower(8)  
> - Glazier(5)  
> - Glove Merchant(14)  
> - Goldsmith(12)  
> - Goldsmith(8)  
> - Goon(23)  
> - Grain Merchant(3)  
> - Grocer(8)  
> - Guide(17)  
> - Haberdasher(7)  
> - Harness Maker(17)  
> - Hat Maker(7)  
> - Hay Merchant(51)  
> - Herbalist(9)  
> - High Mage(5)  
> - High Priest(7)  
> - Historian(5)  
> - Homestead(673)  
> - Horse Trader(21)  
> - Huntsman(26)  
> - Illuminator(11)  
> - Innkeeper(14)  
> - Instrument Maker(5)  
> - Inventor(15)  
> - Jeweler(11)  
> - Jeweler(7)  
> - Judge(15)  
> - Kettle Maker(5)  
> - Knight(4)  
> - Laborer(21)  
> - Launderer(14)  
> - Launderer(17)  
> - Leatherworker(10)  
> - Leatherworker(11)  
> - Librarian(5)  
> - Livestock Merchant(14)  
> - Locksmith(6)  
> - Lord(4)  
> - Magical Artisan(5)  
> - Magical Artisan(5)  
> - Magical Tutor(5)  
> - Mason(21)  
> - Mayor(1)  
> - Meat Butcher(9)  
> - Messenger(16)  
> - Miller(26)  
> - Minstrel(17)  
> - Missionary(68)  
> - Mountainman(51)  
> - Mountainman(8)  
> - Naval Outfitter(6)  
> - Oil Trader(26)  
> - Oil Trader(26)  
> - Painter(Art)(19)  
> - Painter(Building)(21)  
> - Pastry Maker(13)  
> - Pathfinder(9)  
> - Pawnbroker(6)  
> - Perfumer(7)  
> - Physic/Chirurgeon(9)  
> - Pirate(26)  
> - Plasterer(21)  
> - Potionmakers(9)  
> - Potter(17)  
> - Preacher(41)  
> - Priest(23)  
> - Professor(5)  
> - Purse Maker(9)  
> - Roofer(21)  
> - Roofer(21)  
> - Rope Maker(12)  
> - Rug Maker(7)  
> - Saddler(13)  
> - Sage(5)  
> - Sail Maker(15)  
> - Sailor(34)  
> - Scout(9)  
> - Scribe(5)  
> - Sculptor(5)  
> - SellSpell(5)  
> - Ship Builder(6)  
> - Shoe Maker(12)  
> - Shoe Maker(12)  
> - Silversmith(15)  
> - Silversmith(6)  
> - Skinner(11)  
> - Slaver(17)  
> - Slaver(17)  
> - Soap Maker(9)  
> - Spice Merchant(17)  
> - Spice Merchant(17)  
> - Stabler(19)  
> - Storyteller(17)  
> - Tailor(14)  
> - Tanner(13)  
> - Tanner(13)  
> - Tavern Keeper(19)  
> - Tax Collector(3)  
> - Taxidermist(17)  
> - Taxidermist(17)  
> - Teacher(5)  
> - Teamster(21)  
> - Tiler(21)  
> - Tinker(26)  
> - Tinker(6)  
> - Tobacco Merchant(17)  
> - Tobacco Merchant(17)  
> - Town Crier(29)  
> - Town Justice(7)  
> - Toymaker(5)  
> - Toymaker(8)  
> - Trading Post(26)  
> - Troubadours(17)  
> - Tutor(5)  
> - Undertaker(6)  
> - Used Garment Trader(22)  
> - Vestment Maker(12)  
> - Vintner(11)  
> - Viscount(2)  
> - Wagon Maker(15)  
> - Warehouser(17)  
> - Water Carrier(21)  
> - Weapon Dealer(17)  
> - Weapon Dealer(17)  
> - Weaponsmith(5)  
> - Weaponsmith(5)  
> - Weaver(15)  
> - Wheelwright(16)  
> - Wheelwright(23)  
> - Wine Merchant(9)  
> - Wood Carver(9)  
> - Wood Seller(8)  
> - Wool Merchant(13)  
> - Writer(17)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(17)  
> - Advocate(13)  
> - Alchemist(9)  
> - Animal Groomer(7)  
> - Animal Handler(17)  
> - Antiquities(17)  
> - Architect(21)  
> - Armor Dealer(17)  
> - Armorer(6)  
> - Artist(23)  
> - Astrologist(5)  
> - Baker(16)  
> - Banker(6)  
> - Barbarian(10)  
> - Barbarian(51)  
> - Barber(9)  
> - Baron(3)  
> - Barrel Maker(11)  
> - Barrel Maker(19)  
> - Basket Maker(15)  
> - Bather(7)  
> - Beer Merchant(10)  
> - Blacksmith(24)  
> - Bleacher(9)  
> - Book Binder(6)  
> - Bookseller(5)  
> - Bowyer-Fletcher(9)  
> - Bowyer-Fletcher(9)  
> - Brewer(3)  
> - Bricklayer(21)  
> - Brigand(17)  
> - Brigand(51)  
> - Brothel Keeper(7)  
> - Buckle Maker(14)  
> - Buckle Maker(8)  
> - Butcher(11)  
> - Candle Maker(7)  
> - Captain(51)  
> - Caravanner(13)  
> - Carpenter(29)  
> - Cartographer(9)  
> - Chandler(26)  
> - Chandler(26)  
> - Chicken Butcher(11)  
> - Cleric(19)  
> - Clerk(29)  
> - Clock Maker(5)  
> - Cobbler(12)  
> - Cobbler(16)  
> - Conjourer(5)  
> - Cook(11)  
> - Cooper(12)  
> - Council Member(26)  
> - Count(1)  
> - Crime Lord(5)  
> - Crook(21)  
> - Cutler(6)  
> - Dairy Seller(51)  
> - Diplomat(5)  
> - Distiller(10)  
> - Draper(9)  
> - Duke(1)  
> - Dungsweeper(15)  
> - Dye Makers(26)  
> - Dye Makers(26)  
> - Earl(1)  
> - Engineer(21)  
> - Engraver(5)  
> - Farmer - Cabbage(51)  
> - Farmer - Cattle Herder(51)  
> - Farmer - Corn(51)  
> - Farmer - Cow Herder(51)  
> - Farmer - Dairy(51)  
> - Farmer - Goat Herder(51)  
> - Farmer - Pig Herder(51)  
> - Farmer - Potato(51)  
> - Farmer - Sheep Herder(51)  
> - Farmer - Wheat(51)  
> - Farmer(505)  
> - Farmer(Special)(51)  
> - Fisherman(13)  
> - Fishmonger(13)  
> - Florist(9)  
> - Furniture Maker(16)  
> - Furrier(23)  
> - Girdler(8)  
> - Glassblower(17)  
> - Glassblower(8)  
> - Glazier(5)  
> - Glove Merchant(14)  
> - Goldsmith(12)  
> - Goldsmith(8)  
> - Goon(23)  
> - Grain Merchant(3)  
> - Grocer(8)  
> - Guide(17)  
> - Haberdasher(7)  
> - Harness Maker(17)  
> - Hat Maker(7)  
> - Hay Merchant(51)  
> - Herbalist(9)  
> - High Mage(5)  
> - High Priest(7)  
> - Historian(5)  
> - Homestead(673)  
> - Horse Trader(21)  
> - Huntsman(26)  
> - Illuminator(11)  
> - Innkeeper(14)  
> - Instrument Maker(5)  
> - Inventor(15)  
> - Jeweler(11)  
> - Jeweler(7)  
> - Judge(15)  
> - Kettle Maker(5)  
> - Knight(4)  
> - Laborer(21)  
> - Launderer(14)  
> - Launderer(17)  
> - Leatherworker(10)  
> - Leatherworker(11)  
> - Librarian(5)  
> - Livestock Merchant(14)  
> - Locksmith(6)  
> - Lord(4)  
> - Magical Artisan(5)  
> - Magical Artisan(5)  
> - Magical Tutor(5)  
> - Mason(21)  
> - Mayor(1)  
> - Meat Butcher(9)  
> - Messenger(16)  
> - Miller(26)  
> - Minstrel(17)  
> - Missionary(68)  
> - Mountainman(51)  
> - Mountainman(8)  
> - Naval Outfitter(6)  
> - Oil Trader(26)  
> - Oil Trader(26)  
> - Painter(Art)(19)  
> - Painter(Building)(21)  
> - Pastry Maker(13)  
> - Pathfinder(9)  
> - Pawnbroker(6)  
> - Perfumer(7)  
> - Physic/Chirurgeon(9)  
> - Pirate(26)  
> - Plasterer(21)  
> - Potionmakers(9)  
> - Potter(17)  
> - Preacher(41)  
> - Priest(23)  
> - Professor(5)  
> - Purse Maker(9)  
> - Roofer(21)  
> - Roofer(21)  
> - Rope Maker(12)  
> - Rug Maker(7)  
> - Saddler(13)  
> - Sage(5)  
> - Sail Maker(15)  
> - Sailor(34)  
> - Scout(9)  
> - Scribe(5)  
> - Sculptor(5)  
> - SellSpell(5)  
> - Ship Builder(6)  
> - Shoe Maker(12)  
> - Shoe Maker(12)  
> - Silversmith(15)  
> - Silversmith(6)  
> - Skinner(11)  
> - Slaver(17)  
> - Slaver(17)  
> - Soap Maker(9)  
> - Spice Merchant(17)  
> - Spice Merchant(17)  
> - Stabler(19)  
> - Storyteller(17)  
> - Tailor(14)  
> - Tanner(13)  
> - Tanner(13)  
> - Tavern Keeper(19)  
> - Tax Collector(3)  
> - Taxidermist(17)  
> - Taxidermist(17)  
> - Teacher(5)  
> - Teamster(21)  
> - Tiler(21)  
> - Tinker(26)  
> - Tinker(6)  
> - Tobacco Merchant(17)  
> - Tobacco Merchant(17)  
> - Town Crier(29)  
> - Town Justice(7)  
> - Toymaker(5)  
> - Toymaker(8)  
> - Trading Post(26)  
> - Troubadours(17)  
> - Tutor(5)  
> - Undertaker(6)  
> - Used Garment Trader(22)  
> - Vestment Maker(12)  
> - Vintner(11)  
> - Viscount(2)  
> - Wagon Maker(15)  
> - Warehouser(17)  
> - Water Carrier(21)  
> - Weapon Dealer(17)  
> - Weapon Dealer(17)  
> - Weaponsmith(5)  
> - Weaponsmith(5)  
> - Weaver(15)  
> - Wheelwright(16)  
> - Wheelwright(23)  
> - Wine Merchant(9)  
> - Wood Carver(9)  
> - Wood Seller(8)  
> - Wool Merchant(13)  
> - Writer(17)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



