---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (22401)
terrain: Mountain Forest Boreal 
settlementDescription: 
population: 22401
culture: Aboriginal 
technology: Renaissance 
leader: 
govermentType: Democracy 
demographics: 
- Acrobat(38) 
- Minstrel(38) 
- Storyteller(38) 
- Troubadours(38) 
- Writer(38) 
- Advocate(29) 
- Clerk(65) 
- Council Member(57) 
- Diplomat(9) 
- Judge(33) 
- Mayor(1) 
- Alchemist(19) 
- Chandler(57) 
- Dye Makers(57) 
- Florist(19) 
- Herbalist(19) 
- Potionmakers(19) 
- Sage(11) 
- Spice Merchant(38) 
- Taxidermist(38) 
- Tobacco Merchant(38) 
- Animal Groomer(15) 
- Animal Handler(38) 
- Caravanner(29) 
- Horse Trader(45) 
- Livestock Merchant(30) 
- Stabler(41) 
- Antiquities(38) 
- Armor Dealer(38) 
- Launderer(38) 
- Oil Trader(57) 
- Trading Post(57) 
- Slaver(38) 
- Spice Merchant(38) 
- Taxidermist(38) 
- Tobacco Merchant(38) 
- Warehouser(38) 
- Weapon Dealer(38) 
- Architect(45) 
- Bricklayer(45) 
- Engineer(45) 
- Laborer(45) 
- Mason(45) 
- Painter(Building)(45) 
- Plasterer(45) 
- Roofer(45) 
- Teamster(45) 
- Tiler(45) 
- Armorer(12) 
- Blacksmith(53) 
- Bowyer-Fletcher(18) 
- Jeweler(15) 
- Silversmith(14) 
- Weapon Dealer(38) 
- Weaponsmith(11) 
- Artist(50) 
- Glassblower(38) 
- Goldsmith(25) 
- Inventor(33) 
- Jeweler(23) 
- Magical Artisan(11) 
- Painter(Art)(41) 
- Silversmith(33) 
- Tinker(57) 
- Toymaker(18) 
- Astrologist(11) 
- Conjourer(11) 
- High Mage(11) 
- Historian(11) 
- Librarian(11) 
- Magical Artisan(11) 
- Magical Tutor(11) 
- Professor(11) 
- Scribe(11) 
- SellSpell(11) 
- Teacher(11) 
- Tutor(11) 
- Baker(35) 
- Beer Merchant(21) 
- Brewer(6) 
- Butcher(23) 
- Chicken Butcher(23) 
- Cook(24) 
- Dairy Seller(113) 
- Distiller(21) 
- Hay Merchant(113) 
- Fisherman(29) 
- Fishmonger(29) 
- Grain Merchant(6) 
- Grocer(17) 
- Meat Butcher(19) 
- Miller(57) 
- Pastry Maker(29) 
- Vintner(24) 
- Banker(13) 
- Pawnbroker(13) 
- Barbarian(113) 
- Brigand(113) 
- Captain(113) 
- Mountainman(113) 
- Barbarian(21) 
- Cartographer(19) 
- Guide(38) 
- Huntsman(57) 
- Mountainman(18) 
- Pathfinder(19) 
- Scout(19) 
- Slaver(38) 
- Barrel Maker(24) 
- Basket Maker(33) 
- Book Binder(12) 
- Bookseller(11) 
- Buckle Maker(18) 
- Candle Maker(15) 
- Clock Maker(11) 
- Cobbler(35) 
- Cooper(27) 
- Cutler(12) 
- Engraver(11) 
- Furniture Maker(35) 
- Glassblower(17) 
- Glazier(11) 
- Glove Merchant(30) 
- Goldsmith(17) 
- Harness Maker(38) 
- Hat Maker(15) 
- Instrument Maker(11) 
- Kettle Maker(10) 
- Locksmith(14) 
- Perfumer(16) 
- Potter(38) 
- Rope Maker(27) 
- Rug Maker(14) 
- Saddler(29) 
- Sculptor(10) 
- Shoe Maker(27) 
- Soap Maker(19) 
- Tanner(29) 
- Tinker(13) 
- Toymaker(11) 
- Weaponsmith(11) 
- Weaver(33) 
- Wheelwright(50) 
- Wine Merchant(19) 
- Wool Merchant(29) 
- Lord(8) 
- Knight(8) 
- Baron(5) 
- Viscount(3) 
- Earl(3) 
- Count(3) 
- Duke(2) 
- ArchDuke(1) 
- Barrel Maker(41) 
- Bowyer-Fletcher(18) 
- Carpenter(65) 
- Roofer(45) 
- Wagon Maker(33) 
- Wheelwright(35) 
- Wood Carver(18) 
- Wood Seller(17) 
- Barber(19) 
- Bleacher(19) 
- Physic/Chirurgeon(19) 
- Bather(15) 
- Brigand(38) 
- Crime Lord(9) 
- Crook(45) 
- Goon(50) 
- Brothel Keeper(16) 
- Innkeeper(30) 
- Tavern Keeper(41) 
- Buckle Maker(30) 
- Cobbler(27) 
- Draper(19) 
- Furrier(50) 
- Girdler(17) 
- Haberdasher(15) 
- Launderer(30) 
- Leatherworker(21) 
- Purse Maker(19) 
- Shoe Maker(27) 
- Tailor(30) 
- Tanner(29) 
- Used Garment Trader(48) 
- Vestment Maker(27) 
- Chandler(57) 
- Dye Makers(57) 
- Oil Trader(57) 
- Cleric(41) 
- High Priest(16) 
- Missionary(150) 
- Preacher(90) 
- Priest(50) 
- Farmer(1121) 
- Homestead(1494) 
- Farmer - Cabbage(113) 
- Farmer - Cattle Herder(113) 
- Farmer - Corn(113) 
- Farmer - Cow Herder(113) 
- Farmer - Dairy(113) 
- Farmer - Goat Herder(113) 
- Farmer - Pig Herder(113) 
- Farmer - Potato(113) 
- Farmer - Sheep Herder(113) 
- Farmer - Wheat(113) 
- Farmer(Special)(113) 
- Dungsweeper(32) 
- Illuminator(23) 
- Messenger(35) 
- Tax Collector(6) 
- Town Crier(65) 
- Town Justice(15) 
- Undertaker(13) 
- Water Carrier(45) 
- Leatherworker(23) 
- Skinner(23) 
- Naval Outfitter(12) 
- Pirate(57) 
- Sail Maker(33) 
- Sailor(75) 
- Ship Builder(14) 
imports: 
- Marble  
exports: 
- Dyes  
defenses: Killing Fields 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(38)  
> - Advocate(29)  
> - Alchemist(19)  
> - Animal Groomer(15)  
> - Animal Handler(38)  
> - Antiquities(38)  
> - ArchDuke(1)  
> - Architect(45)  
> - Armor Dealer(38)  
> - Armorer(12)  
> - Artist(50)  
> - Astrologist(11)  
> - Baker(35)  
> - Banker(13)  
> - Barbarian(113)  
> - Barbarian(21)  
> - Barber(19)  
> - Baron(5)  
> - Barrel Maker(24)  
> - Barrel Maker(41)  
> - Basket Maker(33)  
> - Bather(15)  
> - Beer Merchant(21)  
> - Blacksmith(53)  
> - Bleacher(19)  
> - Book Binder(12)  
> - Bookseller(11)  
> - Bowyer-Fletcher(18)  
> - Bowyer-Fletcher(18)  
> - Brewer(6)  
> - Bricklayer(45)  
> - Brigand(113)  
> - Brigand(38)  
> - Brothel Keeper(16)  
> - Buckle Maker(18)  
> - Buckle Maker(30)  
> - Butcher(23)  
> - Candle Maker(15)  
> - Captain(113)  
> - Caravanner(29)  
> - Carpenter(65)  
> - Cartographer(19)  
> - Chandler(57)  
> - Chandler(57)  
> - Chicken Butcher(23)  
> - Cleric(41)  
> - Clerk(65)  
> - Clock Maker(11)  
> - Cobbler(27)  
> - Cobbler(35)  
> - Conjourer(11)  
> - Cook(24)  
> - Cooper(27)  
> - Council Member(57)  
> - Count(3)  
> - Crime Lord(9)  
> - Crook(45)  
> - Cutler(12)  
> - Dairy Seller(113)  
> - Diplomat(9)  
> - Distiller(21)  
> - Draper(19)  
> - Duke(2)  
> - Dungsweeper(32)  
> - Dye Makers(57)  
> - Dye Makers(57)  
> - Earl(3)  
> - Engineer(45)  
> - Engraver(11)  
> - Farmer - Cabbage(113)  
> - Farmer - Cattle Herder(113)  
> - Farmer - Corn(113)  
> - Farmer - Cow Herder(113)  
> - Farmer - Dairy(113)  
> - Farmer - Goat Herder(113)  
> - Farmer - Pig Herder(113)  
> - Farmer - Potato(113)  
> - Farmer - Sheep Herder(113)  
> - Farmer - Wheat(113)  
> - Farmer(1121)  
> - Farmer(Special)(113)  
> - Fisherman(29)  
> - Fishmonger(29)  
> - Florist(19)  
> - Furniture Maker(35)  
> - Furrier(50)  
> - Girdler(17)  
> - Glassblower(17)  
> - Glassblower(38)  
> - Glazier(11)  
> - Glove Merchant(30)  
> - Goldsmith(17)  
> - Goldsmith(25)  
> - Goon(50)  
> - Grain Merchant(6)  
> - Grocer(17)  
> - Guide(38)  
> - Haberdasher(15)  
> - Harness Maker(38)  
> - Hat Maker(15)  
> - Hay Merchant(113)  
> - Herbalist(19)  
> - High Mage(11)  
> - High Priest(16)  
> - Historian(11)  
> - Homestead(1494)  
> - Horse Trader(45)  
> - Huntsman(57)  
> - Illuminator(23)  
> - Innkeeper(30)  
> - Instrument Maker(11)  
> - Inventor(33)  
> - Jeweler(15)  
> - Jeweler(23)  
> - Judge(33)  
> - Kettle Maker(10)  
> - Knight(8)  
> - Laborer(45)  
> - Launderer(30)  
> - Launderer(38)  
> - Leatherworker(21)  
> - Leatherworker(23)  
> - Librarian(11)  
> - Livestock Merchant(30)  
> - Locksmith(14)  
> - Lord(8)  
> - Magical Artisan(11)  
> - Magical Artisan(11)  
> - Magical Tutor(11)  
> - Mason(45)  
> - Mayor(1)  
> - Meat Butcher(19)  
> - Messenger(35)  
> - Miller(57)  
> - Minstrel(38)  
> - Missionary(150)  
> - Mountainman(113)  
> - Mountainman(18)  
> - Naval Outfitter(12)  
> - Oil Trader(57)  
> - Oil Trader(57)  
> - Painter(Art)(41)  
> - Painter(Building)(45)  
> - Pastry Maker(29)  
> - Pathfinder(19)  
> - Pawnbroker(13)  
> - Perfumer(16)  
> - Physic/Chirurgeon(19)  
> - Pirate(57)  
> - Plasterer(45)  
> - Potionmakers(19)  
> - Potter(38)  
> - Preacher(90)  
> - Priest(50)  
> - Professor(11)  
> - Purse Maker(19)  
> - Roofer(45)  
> - Roofer(45)  
> - Rope Maker(27)  
> - Rug Maker(14)  
> - Saddler(29)  
> - Sage(11)  
> - Sail Maker(33)  
> - Sailor(75)  
> - Scout(19)  
> - Scribe(11)  
> - Sculptor(10)  
> - SellSpell(11)  
> - Ship Builder(14)  
> - Shoe Maker(27)  
> - Shoe Maker(27)  
> - Silversmith(14)  
> - Silversmith(33)  
> - Skinner(23)  
> - Slaver(38)  
> - Slaver(38)  
> - Soap Maker(19)  
> - Spice Merchant(38)  
> - Spice Merchant(38)  
> - Stabler(41)  
> - Storyteller(38)  
> - Tailor(30)  
> - Tanner(29)  
> - Tanner(29)  
> - Tavern Keeper(41)  
> - Tax Collector(6)  
> - Taxidermist(38)  
> - Taxidermist(38)  
> - Teacher(11)  
> - Teamster(45)  
> - Tiler(45)  
> - Tinker(13)  
> - Tinker(57)  
> - Tobacco Merchant(38)  
> - Tobacco Merchant(38)  
> - Town Crier(65)  
> - Town Justice(15)  
> - Toymaker(11)  
> - Toymaker(18)  
> - Trading Post(57)  
> - Troubadours(38)  
> - Tutor(11)  
> - Undertaker(13)  
> - Used Garment Trader(48)  
> - Vestment Maker(27)  
> - Vintner(24)  
> - Viscount(3)  
> - Wagon Maker(33)  
> - Warehouser(38)  
> - Water Carrier(45)  
> - Weapon Dealer(38)  
> - Weapon Dealer(38)  
> - Weaponsmith(11)  
> - Weaponsmith(11)  
> - Weaver(33)  
> - Wheelwright(35)  
> - Wheelwright(50)  
> - Wine Merchant(19)  
> - Wood Carver(18)  
> - Wood Seller(17)  
> - Wool Merchant(29)  
> - Writer(38)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(38)  
> - Advocate(29)  
> - Alchemist(19)  
> - Animal Groomer(15)  
> - Animal Handler(38)  
> - Antiquities(38)  
> - ArchDuke(1)  
> - Architect(45)  
> - Armor Dealer(38)  
> - Armorer(12)  
> - Artist(50)  
> - Astrologist(11)  
> - Baker(35)  
> - Banker(13)  
> - Barbarian(113)  
> - Barbarian(21)  
> - Barber(19)  
> - Baron(5)  
> - Barrel Maker(24)  
> - Barrel Maker(41)  
> - Basket Maker(33)  
> - Bather(15)  
> - Beer Merchant(21)  
> - Blacksmith(53)  
> - Bleacher(19)  
> - Book Binder(12)  
> - Bookseller(11)  
> - Bowyer-Fletcher(18)  
> - Bowyer-Fletcher(18)  
> - Brewer(6)  
> - Bricklayer(45)  
> - Brigand(113)  
> - Brigand(38)  
> - Brothel Keeper(16)  
> - Buckle Maker(18)  
> - Buckle Maker(30)  
> - Butcher(23)  
> - Candle Maker(15)  
> - Captain(113)  
> - Caravanner(29)  
> - Carpenter(65)  
> - Cartographer(19)  
> - Chandler(57)  
> - Chandler(57)  
> - Chicken Butcher(23)  
> - Cleric(41)  
> - Clerk(65)  
> - Clock Maker(11)  
> - Cobbler(27)  
> - Cobbler(35)  
> - Conjourer(11)  
> - Cook(24)  
> - Cooper(27)  
> - Council Member(57)  
> - Count(3)  
> - Crime Lord(9)  
> - Crook(45)  
> - Cutler(12)  
> - Dairy Seller(113)  
> - Diplomat(9)  
> - Distiller(21)  
> - Draper(19)  
> - Duke(2)  
> - Dungsweeper(32)  
> - Dye Makers(57)  
> - Dye Makers(57)  
> - Earl(3)  
> - Engineer(45)  
> - Engraver(11)  
> - Farmer - Cabbage(113)  
> - Farmer - Cattle Herder(113)  
> - Farmer - Corn(113)  
> - Farmer - Cow Herder(113)  
> - Farmer - Dairy(113)  
> - Farmer - Goat Herder(113)  
> - Farmer - Pig Herder(113)  
> - Farmer - Potato(113)  
> - Farmer - Sheep Herder(113)  
> - Farmer - Wheat(113)  
> - Farmer(1121)  
> - Farmer(Special)(113)  
> - Fisherman(29)  
> - Fishmonger(29)  
> - Florist(19)  
> - Furniture Maker(35)  
> - Furrier(50)  
> - Girdler(17)  
> - Glassblower(17)  
> - Glassblower(38)  
> - Glazier(11)  
> - Glove Merchant(30)  
> - Goldsmith(17)  
> - Goldsmith(25)  
> - Goon(50)  
> - Grain Merchant(6)  
> - Grocer(17)  
> - Guide(38)  
> - Haberdasher(15)  
> - Harness Maker(38)  
> - Hat Maker(15)  
> - Hay Merchant(113)  
> - Herbalist(19)  
> - High Mage(11)  
> - High Priest(16)  
> - Historian(11)  
> - Homestead(1494)  
> - Horse Trader(45)  
> - Huntsman(57)  
> - Illuminator(23)  
> - Innkeeper(30)  
> - Instrument Maker(11)  
> - Inventor(33)  
> - Jeweler(15)  
> - Jeweler(23)  
> - Judge(33)  
> - Kettle Maker(10)  
> - Knight(8)  
> - Laborer(45)  
> - Launderer(30)  
> - Launderer(38)  
> - Leatherworker(21)  
> - Leatherworker(23)  
> - Librarian(11)  
> - Livestock Merchant(30)  
> - Locksmith(14)  
> - Lord(8)  
> - Magical Artisan(11)  
> - Magical Artisan(11)  
> - Magical Tutor(11)  
> - Mason(45)  
> - Mayor(1)  
> - Meat Butcher(19)  
> - Messenger(35)  
> - Miller(57)  
> - Minstrel(38)  
> - Missionary(150)  
> - Mountainman(113)  
> - Mountainman(18)  
> - Naval Outfitter(12)  
> - Oil Trader(57)  
> - Oil Trader(57)  
> - Painter(Art)(41)  
> - Painter(Building)(45)  
> - Pastry Maker(29)  
> - Pathfinder(19)  
> - Pawnbroker(13)  
> - Perfumer(16)  
> - Physic/Chirurgeon(19)  
> - Pirate(57)  
> - Plasterer(45)  
> - Potionmakers(19)  
> - Potter(38)  
> - Preacher(90)  
> - Priest(50)  
> - Professor(11)  
> - Purse Maker(19)  
> - Roofer(45)  
> - Roofer(45)  
> - Rope Maker(27)  
> - Rug Maker(14)  
> - Saddler(29)  
> - Sage(11)  
> - Sail Maker(33)  
> - Sailor(75)  
> - Scout(19)  
> - Scribe(11)  
> - Sculptor(10)  
> - SellSpell(11)  
> - Ship Builder(14)  
> - Shoe Maker(27)  
> - Shoe Maker(27)  
> - Silversmith(14)  
> - Silversmith(33)  
> - Skinner(23)  
> - Slaver(38)  
> - Slaver(38)  
> - Soap Maker(19)  
> - Spice Merchant(38)  
> - Spice Merchant(38)  
> - Stabler(41)  
> - Storyteller(38)  
> - Tailor(30)  
> - Tanner(29)  
> - Tanner(29)  
> - Tavern Keeper(41)  
> - Tax Collector(6)  
> - Taxidermist(38)  
> - Taxidermist(38)  
> - Teacher(11)  
> - Teamster(45)  
> - Tiler(45)  
> - Tinker(13)  
> - Tinker(57)  
> - Tobacco Merchant(38)  
> - Tobacco Merchant(38)  
> - Town Crier(65)  
> - Town Justice(15)  
> - Toymaker(11)  
> - Toymaker(18)  
> - Trading Post(57)  
> - Troubadours(38)  
> - Tutor(11)  
> - Undertaker(13)  
> - Used Garment Trader(48)  
> - Vestment Maker(27)  
> - Vintner(24)  
> - Viscount(3)  
> - Wagon Maker(33)  
> - Warehouser(38)  
> - Water Carrier(45)  
> - Weapon Dealer(38)  
> - Weapon Dealer(38)  
> - Weaponsmith(11)  
> - Weaponsmith(11)  
> - Weaver(33)  
> - Wheelwright(35)  
> - Wheelwright(50)  
> - Wine Merchant(19)  
> - Wood Carver(18)  
> - Wood Seller(17)  
> - Wool Merchant(29)  
> - Writer(38)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



