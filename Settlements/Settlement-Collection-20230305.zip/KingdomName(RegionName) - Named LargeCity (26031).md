---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (26031)
terrain: Forest 
settlementDescription: 
population: 26031
culture: Renaissance 
technology: Stone Age 
leader: 
govermentType: Confederation 
demographics: 
- Acrobat(44) 
- Minstrel(44) 
- Storyteller(44) 
- Troubadours(44) 
- Writer(44) 
- Advocate(33) 
- Clerk(75) 
- Council Member(66) 
- Diplomat(11) 
- Judge(38) 
- Mayor(1) 
- Alchemist(22) 
- Chandler(66) 
- Dye Makers(66) 
- Florist(22) 
- Herbalist(22) 
- Potionmakers(22) 
- Sage(12) 
- Spice Merchant(44) 
- Taxidermist(44) 
- Tobacco Merchant(44) 
- Animal Groomer(18) 
- Animal Handler(44) 
- Caravanner(33) 
- Horse Trader(53) 
- Livestock Merchant(35) 
- Stabler(47) 
- Antiquities(44) 
- Armor Dealer(44) 
- Launderer(44) 
- Oil Trader(66) 
- Trading Post(66) 
- Slaver(44) 
- Spice Merchant(44) 
- Taxidermist(44) 
- Tobacco Merchant(44) 
- Warehouser(44) 
- Weapon Dealer(44) 
- Architect(53) 
- Bricklayer(53) 
- Engineer(53) 
- Laborer(53) 
- Mason(53) 
- Painter(Building)(53) 
- Plasterer(53) 
- Roofer(53) 
- Teamster(53) 
- Tiler(53) 
- Armorer(14) 
- Blacksmith(62) 
- Bowyer-Fletcher(21) 
- Jeweler(17) 
- Silversmith(16) 
- Weapon Dealer(44) 
- Weaponsmith(13) 
- Artist(58) 
- Glassblower(44) 
- Goldsmith(29) 
- Inventor(38) 
- Jeweler(27) 
- Magical Artisan(12) 
- Painter(Art)(48) 
- Silversmith(38) 
- Tinker(66) 
- Toymaker(21) 
- Astrologist(12) 
- Conjourer(12) 
- High Mage(12) 
- Historian(12) 
- Librarian(12) 
- Magical Artisan(12) 
- Magical Tutor(12) 
- Professor(12) 
- Scribe(12) 
- SellSpell(12) 
- Teacher(12) 
- Tutor(12) 
- Baker(41) 
- Beer Merchant(24) 
- Brewer(7) 
- Butcher(27) 
- Chicken Butcher(27) 
- Cook(28) 
- Dairy Seller(131) 
- Distiller(24) 
- Hay Merchant(131) 
- Fisherman(33) 
- Fishmonger(33) 
- Grain Merchant(7) 
- Grocer(20) 
- Meat Butcher(22) 
- Miller(66) 
- Pastry Maker(33) 
- Vintner(28) 
- Banker(15) 
- Pawnbroker(15) 
- Barbarian(131) 
- Brigand(131) 
- Captain(131) 
- Mountainman(131) 
- Barbarian(24) 
- Cartographer(22) 
- Guide(44) 
- Huntsman(66) 
- Mountainman(21) 
- Pathfinder(22) 
- Scout(22) 
- Slaver(44) 
- Barrel Maker(28) 
- Basket Maker(38) 
- Book Binder(14) 
- Bookseller(13) 
- Buckle Maker(21) 
- Candle Maker(17) 
- Clock Maker(12) 
- Cobbler(41) 
- Cooper(31) 
- Cutler(14) 
- Engraver(12) 
- Furniture Maker(41) 
- Glassblower(19) 
- Glazier(13) 
- Glove Merchant(35) 
- Goldsmith(19) 
- Harness Maker(44) 
- Hat Maker(18) 
- Instrument Maker(12) 
- Kettle Maker(12) 
- Locksmith(16) 
- Perfumer(18) 
- Potter(44) 
- Rope Maker(31) 
- Rug Maker(16) 
- Saddler(33) 
- Sculptor(12) 
- Shoe Maker(31) 
- Soap Maker(22) 
- Tanner(33) 
- Tinker(15) 
- Toymaker(12) 
- Weaponsmith(13) 
- Weaver(38) 
- Wheelwright(58) 
- Wine Merchant(22) 
- Wool Merchant(33) 
- Lord(9) 
- Knight(9) 
- Baron(6) 
- Viscount(4) 
- Earl(3) 
- Count(3) 
- Duke(2) 
- ArchDuke(1) 
- Barrel Maker(48) 
- Bowyer-Fletcher(21) 
- Carpenter(75) 
- Roofer(53) 
- Wagon Maker(38) 
- Wheelwright(41) 
- Wood Carver(21) 
- Wood Seller(20) 
- Barber(22) 
- Bleacher(22) 
- Physic/Chirurgeon(22) 
- Bather(18) 
- Brigand(44) 
- Crime Lord(11) 
- Crook(53) 
- Goon(58) 
- Brothel Keeper(18) 
- Innkeeper(35) 
- Tavern Keeper(48) 
- Buckle Maker(35) 
- Cobbler(31) 
- Draper(22) 
- Furrier(58) 
- Girdler(20) 
- Haberdasher(17) 
- Launderer(35) 
- Leatherworker(24) 
- Purse Maker(22) 
- Shoe Maker(31) 
- Tailor(35) 
- Tanner(33) 
- Used Garment Trader(55) 
- Vestment Maker(31) 
- Chandler(66) 
- Dye Makers(66) 
- Oil Trader(66) 
- Cleric(48) 
- High Priest(18) 
- Missionary(174) 
- Preacher(105) 
- Priest(58) 
- Farmer(1302) 
- Homestead(1736) 
- Farmer - Cabbage(131) 
- Farmer - Cattle Herder(131) 
- Farmer - Corn(131) 
- Farmer - Cow Herder(131) 
- Farmer - Dairy(131) 
- Farmer - Goat Herder(131) 
- Farmer - Pig Herder(131) 
- Farmer - Potato(131) 
- Farmer - Sheep Herder(131) 
- Farmer - Wheat(131) 
- Farmer(Special)(131) 
- Dungsweeper(37) 
- Illuminator(27) 
- Messenger(41) 
- Tax Collector(7) 
- Town Crier(75) 
- Town Justice(18) 
- Undertaker(15) 
- Water Carrier(53) 
- Leatherworker(27) 
- Skinner(27) 
- Naval Outfitter(14) 
- Pirate(66) 
- Sail Maker(38) 
- Sailor(87) 
- Ship Builder(16) 
imports: 
- Grease  
exports: 
- Wool  
defenses: Stone Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(44)  
> - Advocate(33)  
> - Alchemist(22)  
> - Animal Groomer(18)  
> - Animal Handler(44)  
> - Antiquities(44)  
> - ArchDuke(1)  
> - Architect(53)  
> - Armor Dealer(44)  
> - Armorer(14)  
> - Artist(58)  
> - Astrologist(12)  
> - Baker(41)  
> - Banker(15)  
> - Barbarian(131)  
> - Barbarian(24)  
> - Barber(22)  
> - Baron(6)  
> - Barrel Maker(28)  
> - Barrel Maker(48)  
> - Basket Maker(38)  
> - Bather(18)  
> - Beer Merchant(24)  
> - Blacksmith(62)  
> - Bleacher(22)  
> - Book Binder(14)  
> - Bookseller(13)  
> - Bowyer-Fletcher(21)  
> - Bowyer-Fletcher(21)  
> - Brewer(7)  
> - Bricklayer(53)  
> - Brigand(131)  
> - Brigand(44)  
> - Brothel Keeper(18)  
> - Buckle Maker(21)  
> - Buckle Maker(35)  
> - Butcher(27)  
> - Candle Maker(17)  
> - Captain(131)  
> - Caravanner(33)  
> - Carpenter(75)  
> - Cartographer(22)  
> - Chandler(66)  
> - Chandler(66)  
> - Chicken Butcher(27)  
> - Cleric(48)  
> - Clerk(75)  
> - Clock Maker(12)  
> - Cobbler(31)  
> - Cobbler(41)  
> - Conjourer(12)  
> - Cook(28)  
> - Cooper(31)  
> - Council Member(66)  
> - Count(3)  
> - Crime Lord(11)  
> - Crook(53)  
> - Cutler(14)  
> - Dairy Seller(131)  
> - Diplomat(11)  
> - Distiller(24)  
> - Draper(22)  
> - Duke(2)  
> - Dungsweeper(37)  
> - Dye Makers(66)  
> - Dye Makers(66)  
> - Earl(3)  
> - Engineer(53)  
> - Engraver(12)  
> - Farmer - Cabbage(131)  
> - Farmer - Cattle Herder(131)  
> - Farmer - Corn(131)  
> - Farmer - Cow Herder(131)  
> - Farmer - Dairy(131)  
> - Farmer - Goat Herder(131)  
> - Farmer - Pig Herder(131)  
> - Farmer - Potato(131)  
> - Farmer - Sheep Herder(131)  
> - Farmer - Wheat(131)  
> - Farmer(1302)  
> - Farmer(Special)(131)  
> - Fisherman(33)  
> - Fishmonger(33)  
> - Florist(22)  
> - Furniture Maker(41)  
> - Furrier(58)  
> - Girdler(20)  
> - Glassblower(19)  
> - Glassblower(44)  
> - Glazier(13)  
> - Glove Merchant(35)  
> - Goldsmith(19)  
> - Goldsmith(29)  
> - Goon(58)  
> - Grain Merchant(7)  
> - Grocer(20)  
> - Guide(44)  
> - Haberdasher(17)  
> - Harness Maker(44)  
> - Hat Maker(18)  
> - Hay Merchant(131)  
> - Herbalist(22)  
> - High Mage(12)  
> - High Priest(18)  
> - Historian(12)  
> - Homestead(1736)  
> - Horse Trader(53)  
> - Huntsman(66)  
> - Illuminator(27)  
> - Innkeeper(35)  
> - Instrument Maker(12)  
> - Inventor(38)  
> - Jeweler(17)  
> - Jeweler(27)  
> - Judge(38)  
> - Kettle Maker(12)  
> - Knight(9)  
> - Laborer(53)  
> - Launderer(35)  
> - Launderer(44)  
> - Leatherworker(24)  
> - Leatherworker(27)  
> - Librarian(12)  
> - Livestock Merchant(35)  
> - Locksmith(16)  
> - Lord(9)  
> - Magical Artisan(12)  
> - Magical Artisan(12)  
> - Magical Tutor(12)  
> - Mason(53)  
> - Mayor(1)  
> - Meat Butcher(22)  
> - Messenger(41)  
> - Miller(66)  
> - Minstrel(44)  
> - Missionary(174)  
> - Mountainman(131)  
> - Mountainman(21)  
> - Naval Outfitter(14)  
> - Oil Trader(66)  
> - Oil Trader(66)  
> - Painter(Art)(48)  
> - Painter(Building)(53)  
> - Pastry Maker(33)  
> - Pathfinder(22)  
> - Pawnbroker(15)  
> - Perfumer(18)  
> - Physic/Chirurgeon(22)  
> - Pirate(66)  
> - Plasterer(53)  
> - Potionmakers(22)  
> - Potter(44)  
> - Preacher(105)  
> - Priest(58)  
> - Professor(12)  
> - Purse Maker(22)  
> - Roofer(53)  
> - Roofer(53)  
> - Rope Maker(31)  
> - Rug Maker(16)  
> - Saddler(33)  
> - Sage(12)  
> - Sail Maker(38)  
> - Sailor(87)  
> - Scout(22)  
> - Scribe(12)  
> - Sculptor(12)  
> - SellSpell(12)  
> - Ship Builder(16)  
> - Shoe Maker(31)  
> - Shoe Maker(31)  
> - Silversmith(16)  
> - Silversmith(38)  
> - Skinner(27)  
> - Slaver(44)  
> - Slaver(44)  
> - Soap Maker(22)  
> - Spice Merchant(44)  
> - Spice Merchant(44)  
> - Stabler(47)  
> - Storyteller(44)  
> - Tailor(35)  
> - Tanner(33)  
> - Tanner(33)  
> - Tavern Keeper(48)  
> - Tax Collector(7)  
> - Taxidermist(44)  
> - Taxidermist(44)  
> - Teacher(12)  
> - Teamster(53)  
> - Tiler(53)  
> - Tinker(15)  
> - Tinker(66)  
> - Tobacco Merchant(44)  
> - Tobacco Merchant(44)  
> - Town Crier(75)  
> - Town Justice(18)  
> - Toymaker(12)  
> - Toymaker(21)  
> - Trading Post(66)  
> - Troubadours(44)  
> - Tutor(12)  
> - Undertaker(15)  
> - Used Garment Trader(55)  
> - Vestment Maker(31)  
> - Vintner(28)  
> - Viscount(4)  
> - Wagon Maker(38)  
> - Warehouser(44)  
> - Water Carrier(53)  
> - Weapon Dealer(44)  
> - Weapon Dealer(44)  
> - Weaponsmith(13)  
> - Weaponsmith(13)  
> - Weaver(38)  
> - Wheelwright(41)  
> - Wheelwright(58)  
> - Wine Merchant(22)  
> - Wood Carver(21)  
> - Wood Seller(20)  
> - Wool Merchant(33)  
> - Writer(44)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(44)  
> - Advocate(33)  
> - Alchemist(22)  
> - Animal Groomer(18)  
> - Animal Handler(44)  
> - Antiquities(44)  
> - ArchDuke(1)  
> - Architect(53)  
> - Armor Dealer(44)  
> - Armorer(14)  
> - Artist(58)  
> - Astrologist(12)  
> - Baker(41)  
> - Banker(15)  
> - Barbarian(131)  
> - Barbarian(24)  
> - Barber(22)  
> - Baron(6)  
> - Barrel Maker(28)  
> - Barrel Maker(48)  
> - Basket Maker(38)  
> - Bather(18)  
> - Beer Merchant(24)  
> - Blacksmith(62)  
> - Bleacher(22)  
> - Book Binder(14)  
> - Bookseller(13)  
> - Bowyer-Fletcher(21)  
> - Bowyer-Fletcher(21)  
> - Brewer(7)  
> - Bricklayer(53)  
> - Brigand(131)  
> - Brigand(44)  
> - Brothel Keeper(18)  
> - Buckle Maker(21)  
> - Buckle Maker(35)  
> - Butcher(27)  
> - Candle Maker(17)  
> - Captain(131)  
> - Caravanner(33)  
> - Carpenter(75)  
> - Cartographer(22)  
> - Chandler(66)  
> - Chandler(66)  
> - Chicken Butcher(27)  
> - Cleric(48)  
> - Clerk(75)  
> - Clock Maker(12)  
> - Cobbler(31)  
> - Cobbler(41)  
> - Conjourer(12)  
> - Cook(28)  
> - Cooper(31)  
> - Council Member(66)  
> - Count(3)  
> - Crime Lord(11)  
> - Crook(53)  
> - Cutler(14)  
> - Dairy Seller(131)  
> - Diplomat(11)  
> - Distiller(24)  
> - Draper(22)  
> - Duke(2)  
> - Dungsweeper(37)  
> - Dye Makers(66)  
> - Dye Makers(66)  
> - Earl(3)  
> - Engineer(53)  
> - Engraver(12)  
> - Farmer - Cabbage(131)  
> - Farmer - Cattle Herder(131)  
> - Farmer - Corn(131)  
> - Farmer - Cow Herder(131)  
> - Farmer - Dairy(131)  
> - Farmer - Goat Herder(131)  
> - Farmer - Pig Herder(131)  
> - Farmer - Potato(131)  
> - Farmer - Sheep Herder(131)  
> - Farmer - Wheat(131)  
> - Farmer(1302)  
> - Farmer(Special)(131)  
> - Fisherman(33)  
> - Fishmonger(33)  
> - Florist(22)  
> - Furniture Maker(41)  
> - Furrier(58)  
> - Girdler(20)  
> - Glassblower(19)  
> - Glassblower(44)  
> - Glazier(13)  
> - Glove Merchant(35)  
> - Goldsmith(19)  
> - Goldsmith(29)  
> - Goon(58)  
> - Grain Merchant(7)  
> - Grocer(20)  
> - Guide(44)  
> - Haberdasher(17)  
> - Harness Maker(44)  
> - Hat Maker(18)  
> - Hay Merchant(131)  
> - Herbalist(22)  
> - High Mage(12)  
> - High Priest(18)  
> - Historian(12)  
> - Homestead(1736)  
> - Horse Trader(53)  
> - Huntsman(66)  
> - Illuminator(27)  
> - Innkeeper(35)  
> - Instrument Maker(12)  
> - Inventor(38)  
> - Jeweler(17)  
> - Jeweler(27)  
> - Judge(38)  
> - Kettle Maker(12)  
> - Knight(9)  
> - Laborer(53)  
> - Launderer(35)  
> - Launderer(44)  
> - Leatherworker(24)  
> - Leatherworker(27)  
> - Librarian(12)  
> - Livestock Merchant(35)  
> - Locksmith(16)  
> - Lord(9)  
> - Magical Artisan(12)  
> - Magical Artisan(12)  
> - Magical Tutor(12)  
> - Mason(53)  
> - Mayor(1)  
> - Meat Butcher(22)  
> - Messenger(41)  
> - Miller(66)  
> - Minstrel(44)  
> - Missionary(174)  
> - Mountainman(131)  
> - Mountainman(21)  
> - Naval Outfitter(14)  
> - Oil Trader(66)  
> - Oil Trader(66)  
> - Painter(Art)(48)  
> - Painter(Building)(53)  
> - Pastry Maker(33)  
> - Pathfinder(22)  
> - Pawnbroker(15)  
> - Perfumer(18)  
> - Physic/Chirurgeon(22)  
> - Pirate(66)  
> - Plasterer(53)  
> - Potionmakers(22)  
> - Potter(44)  
> - Preacher(105)  
> - Priest(58)  
> - Professor(12)  
> - Purse Maker(22)  
> - Roofer(53)  
> - Roofer(53)  
> - Rope Maker(31)  
> - Rug Maker(16)  
> - Saddler(33)  
> - Sage(12)  
> - Sail Maker(38)  
> - Sailor(87)  
> - Scout(22)  
> - Scribe(12)  
> - Sculptor(12)  
> - SellSpell(12)  
> - Ship Builder(16)  
> - Shoe Maker(31)  
> - Shoe Maker(31)  
> - Silversmith(16)  
> - Silversmith(38)  
> - Skinner(27)  
> - Slaver(44)  
> - Slaver(44)  
> - Soap Maker(22)  
> - Spice Merchant(44)  
> - Spice Merchant(44)  
> - Stabler(47)  
> - Storyteller(44)  
> - Tailor(35)  
> - Tanner(33)  
> - Tanner(33)  
> - Tavern Keeper(48)  
> - Tax Collector(7)  
> - Taxidermist(44)  
> - Taxidermist(44)  
> - Teacher(12)  
> - Teamster(53)  
> - Tiler(53)  
> - Tinker(15)  
> - Tinker(66)  
> - Tobacco Merchant(44)  
> - Tobacco Merchant(44)  
> - Town Crier(75)  
> - Town Justice(18)  
> - Toymaker(12)  
> - Toymaker(21)  
> - Trading Post(66)  
> - Troubadours(44)  
> - Tutor(12)  
> - Undertaker(15)  
> - Used Garment Trader(55)  
> - Vestment Maker(31)  
> - Vintner(28)  
> - Viscount(4)  
> - Wagon Maker(38)  
> - Warehouser(44)  
> - Water Carrier(53)  
> - Weapon Dealer(44)  
> - Weapon Dealer(44)  
> - Weaponsmith(13)  
> - Weaponsmith(13)  
> - Weaver(38)  
> - Wheelwright(41)  
> - Wheelwright(58)  
> - Wine Merchant(22)  
> - Wood Carver(21)  
> - Wood Seller(20)  
> - Wool Merchant(33)  
> - Writer(44)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



