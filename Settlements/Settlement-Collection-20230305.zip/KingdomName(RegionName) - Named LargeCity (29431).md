---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (29431)
terrain: Hills Forest Fungal 
settlementDescription: 
population: 29431
culture: European 
technology: Roman 
leader: 
govermentType: Anarchy 
demographics: 
- Acrobat(50) 
- Minstrel(50) 
- Storyteller(50) 
- Troubadours(50) 
- Writer(50) 
- Advocate(37) 
- Clerk(85) 
- Council Member(74) 
- Diplomat(12) 
- Judge(43) 
- Mayor(1) 
- Alchemist(25) 
- Chandler(74) 
- Dye Makers(74) 
- Florist(25) 
- Herbalist(25) 
- Potionmakers(25) 
- Sage(14) 
- Spice Merchant(50) 
- Taxidermist(50) 
- Tobacco Merchant(50) 
- Animal Groomer(20) 
- Animal Handler(50) 
- Caravanner(37) 
- Horse Trader(59) 
- Livestock Merchant(40) 
- Stabler(53) 
- Antiquities(50) 
- Armor Dealer(50) 
- Launderer(50) 
- Oil Trader(74) 
- Trading Post(74) 
- Slaver(50) 
- Spice Merchant(50) 
- Taxidermist(50) 
- Tobacco Merchant(50) 
- Warehouser(50) 
- Weapon Dealer(50) 
- Architect(59) 
- Bricklayer(59) 
- Engineer(59) 
- Laborer(59) 
- Mason(59) 
- Painter(Building)(59) 
- Plasterer(59) 
- Roofer(59) 
- Teamster(59) 
- Tiler(59) 
- Armorer(16) 
- Blacksmith(70) 
- Bowyer-Fletcher(24) 
- Jeweler(19) 
- Silversmith(18) 
- Weapon Dealer(50) 
- Weaponsmith(15) 
- Artist(66) 
- Glassblower(50) 
- Goldsmith(33) 
- Inventor(43) 
- Jeweler(30) 
- Magical Artisan(14) 
- Painter(Art)(54) 
- Silversmith(43) 
- Tinker(74) 
- Toymaker(23) 
- Astrologist(14) 
- Conjourer(14) 
- High Mage(14) 
- Historian(14) 
- Librarian(14) 
- Magical Artisan(14) 
- Magical Tutor(14) 
- Professor(14) 
- Scribe(14) 
- SellSpell(14) 
- Teacher(14) 
- Tutor(14) 
- Baker(46) 
- Beer Merchant(27) 
- Brewer(7) 
- Butcher(30) 
- Chicken Butcher(30) 
- Cook(31) 
- Dairy Seller(148) 
- Distiller(27) 
- Hay Merchant(148) 
- Fisherman(37) 
- Fishmonger(37) 
- Grain Merchant(8) 
- Grocer(22) 
- Meat Butcher(25) 
- Miller(74) 
- Pastry Maker(37) 
- Vintner(31) 
- Banker(17) 
- Pawnbroker(17) 
- Barbarian(148) 
- Brigand(148) 
- Captain(148) 
- Mountainman(148) 
- Barbarian(27) 
- Cartographer(25) 
- Guide(50) 
- Huntsman(74) 
- Mountainman(23) 
- Pathfinder(25) 
- Scout(25) 
- Slaver(50) 
- Barrel Maker(31) 
- Basket Maker(43) 
- Book Binder(15) 
- Bookseller(15) 
- Buckle Maker(23) 
- Candle Maker(19) 
- Clock Maker(14) 
- Cobbler(46) 
- Cooper(35) 
- Cutler(15) 
- Engraver(14) 
- Furniture Maker(46) 
- Glassblower(22) 
- Glazier(15) 
- Glove Merchant(40) 
- Goldsmith(22) 
- Harness Maker(50) 
- Hat Maker(20) 
- Instrument Maker(14) 
- Kettle Maker(13) 
- Locksmith(18) 
- Perfumer(21) 
- Potter(50) 
- Rope Maker(35) 
- Rug Maker(18) 
- Saddler(37) 
- Sculptor(13) 
- Shoe Maker(35) 
- Soap Maker(25) 
- Tanner(37) 
- Tinker(17) 
- Toymaker(14) 
- Weaponsmith(15) 
- Weaver(43) 
- Wheelwright(66) 
- Wine Merchant(25) 
- Wool Merchant(37) 
- Lord(10) 
- Knight(10) 
- Baron(6) 
- Viscount(4) 
- Earl(3) 
- Count(3) 
- Duke(2) 
- ArchDuke(1) 
- Barrel Maker(54) 
- Bowyer-Fletcher(24) 
- Carpenter(85) 
- Roofer(59) 
- Wagon Maker(43) 
- Wheelwright(46) 
- Wood Carver(24) 
- Wood Seller(22) 
- Barber(25) 
- Bleacher(25) 
- Physic/Chirurgeon(25) 
- Bather(20) 
- Brigand(50) 
- Crime Lord(12) 
- Crook(59) 
- Goon(66) 
- Brothel Keeper(21) 
- Innkeeper(40) 
- Tavern Keeper(54) 
- Buckle Maker(40) 
- Cobbler(35) 
- Draper(25) 
- Furrier(66) 
- Girdler(22) 
- Haberdasher(19) 
- Launderer(40) 
- Leatherworker(27) 
- Purse Maker(25) 
- Shoe Maker(35) 
- Tailor(40) 
- Tanner(37) 
- Used Garment Trader(62) 
- Vestment Maker(35) 
- Chandler(74) 
- Dye Makers(74) 
- Oil Trader(74) 
- Cleric(54) 
- High Priest(21) 
- Missionary(197) 
- Preacher(118) 
- Priest(66) 
- Farmer(1472) 
- Homestead(1963) 
- Farmer - Cabbage(148) 
- Farmer - Cattle Herder(148) 
- Farmer - Corn(148) 
- Farmer - Cow Herder(148) 
- Farmer - Dairy(148) 
- Farmer - Goat Herder(148) 
- Farmer - Pig Herder(148) 
- Farmer - Potato(148) 
- Farmer - Sheep Herder(148) 
- Farmer - Wheat(148) 
- Farmer(Special)(148) 
- Dungsweeper(42) 
- Illuminator(30) 
- Messenger(46) 
- Tax Collector(8) 
- Town Crier(85) 
- Town Justice(20) 
- Undertaker(17) 
- Water Carrier(59) 
- Leatherworker(30) 
- Skinner(30) 
- Naval Outfitter(16) 
- Pirate(74) 
- Sail Maker(43) 
- Sailor(99) 
- Ship Builder(18) 
imports: 
- Lumber  
exports: 
- Furs  
defenses: Wood Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(50)  
> - Advocate(37)  
> - Alchemist(25)  
> - Animal Groomer(20)  
> - Animal Handler(50)  
> - Antiquities(50)  
> - ArchDuke(1)  
> - Architect(59)  
> - Armor Dealer(50)  
> - Armorer(16)  
> - Artist(66)  
> - Astrologist(14)  
> - Baker(46)  
> - Banker(17)  
> - Barbarian(148)  
> - Barbarian(27)  
> - Barber(25)  
> - Baron(6)  
> - Barrel Maker(31)  
> - Barrel Maker(54)  
> - Basket Maker(43)  
> - Bather(20)  
> - Beer Merchant(27)  
> - Blacksmith(70)  
> - Bleacher(25)  
> - Book Binder(15)  
> - Bookseller(15)  
> - Bowyer-Fletcher(24)  
> - Bowyer-Fletcher(24)  
> - Brewer(7)  
> - Bricklayer(59)  
> - Brigand(148)  
> - Brigand(50)  
> - Brothel Keeper(21)  
> - Buckle Maker(23)  
> - Buckle Maker(40)  
> - Butcher(30)  
> - Candle Maker(19)  
> - Captain(148)  
> - Caravanner(37)  
> - Carpenter(85)  
> - Cartographer(25)  
> - Chandler(74)  
> - Chandler(74)  
> - Chicken Butcher(30)  
> - Cleric(54)  
> - Clerk(85)  
> - Clock Maker(14)  
> - Cobbler(35)  
> - Cobbler(46)  
> - Conjourer(14)  
> - Cook(31)  
> - Cooper(35)  
> - Council Member(74)  
> - Count(3)  
> - Crime Lord(12)  
> - Crook(59)  
> - Cutler(15)  
> - Dairy Seller(148)  
> - Diplomat(12)  
> - Distiller(27)  
> - Draper(25)  
> - Duke(2)  
> - Dungsweeper(42)  
> - Dye Makers(74)  
> - Dye Makers(74)  
> - Earl(3)  
> - Engineer(59)  
> - Engraver(14)  
> - Farmer - Cabbage(148)  
> - Farmer - Cattle Herder(148)  
> - Farmer - Corn(148)  
> - Farmer - Cow Herder(148)  
> - Farmer - Dairy(148)  
> - Farmer - Goat Herder(148)  
> - Farmer - Pig Herder(148)  
> - Farmer - Potato(148)  
> - Farmer - Sheep Herder(148)  
> - Farmer - Wheat(148)  
> - Farmer(1472)  
> - Farmer(Special)(148)  
> - Fisherman(37)  
> - Fishmonger(37)  
> - Florist(25)  
> - Furniture Maker(46)  
> - Furrier(66)  
> - Girdler(22)  
> - Glassblower(22)  
> - Glassblower(50)  
> - Glazier(15)  
> - Glove Merchant(40)  
> - Goldsmith(22)  
> - Goldsmith(33)  
> - Goon(66)  
> - Grain Merchant(8)  
> - Grocer(22)  
> - Guide(50)  
> - Haberdasher(19)  
> - Harness Maker(50)  
> - Hat Maker(20)  
> - Hay Merchant(148)  
> - Herbalist(25)  
> - High Mage(14)  
> - High Priest(21)  
> - Historian(14)  
> - Homestead(1963)  
> - Horse Trader(59)  
> - Huntsman(74)  
> - Illuminator(30)  
> - Innkeeper(40)  
> - Instrument Maker(14)  
> - Inventor(43)  
> - Jeweler(19)  
> - Jeweler(30)  
> - Judge(43)  
> - Kettle Maker(13)  
> - Knight(10)  
> - Laborer(59)  
> - Launderer(40)  
> - Launderer(50)  
> - Leatherworker(27)  
> - Leatherworker(30)  
> - Librarian(14)  
> - Livestock Merchant(40)  
> - Locksmith(18)  
> - Lord(10)  
> - Magical Artisan(14)  
> - Magical Artisan(14)  
> - Magical Tutor(14)  
> - Mason(59)  
> - Mayor(1)  
> - Meat Butcher(25)  
> - Messenger(46)  
> - Miller(74)  
> - Minstrel(50)  
> - Missionary(197)  
> - Mountainman(148)  
> - Mountainman(23)  
> - Naval Outfitter(16)  
> - Oil Trader(74)  
> - Oil Trader(74)  
> - Painter(Art)(54)  
> - Painter(Building)(59)  
> - Pastry Maker(37)  
> - Pathfinder(25)  
> - Pawnbroker(17)  
> - Perfumer(21)  
> - Physic/Chirurgeon(25)  
> - Pirate(74)  
> - Plasterer(59)  
> - Potionmakers(25)  
> - Potter(50)  
> - Preacher(118)  
> - Priest(66)  
> - Professor(14)  
> - Purse Maker(25)  
> - Roofer(59)  
> - Roofer(59)  
> - Rope Maker(35)  
> - Rug Maker(18)  
> - Saddler(37)  
> - Sage(14)  
> - Sail Maker(43)  
> - Sailor(99)  
> - Scout(25)  
> - Scribe(14)  
> - Sculptor(13)  
> - SellSpell(14)  
> - Ship Builder(18)  
> - Shoe Maker(35)  
> - Shoe Maker(35)  
> - Silversmith(18)  
> - Silversmith(43)  
> - Skinner(30)  
> - Slaver(50)  
> - Slaver(50)  
> - Soap Maker(25)  
> - Spice Merchant(50)  
> - Spice Merchant(50)  
> - Stabler(53)  
> - Storyteller(50)  
> - Tailor(40)  
> - Tanner(37)  
> - Tanner(37)  
> - Tavern Keeper(54)  
> - Tax Collector(8)  
> - Taxidermist(50)  
> - Taxidermist(50)  
> - Teacher(14)  
> - Teamster(59)  
> - Tiler(59)  
> - Tinker(17)  
> - Tinker(74)  
> - Tobacco Merchant(50)  
> - Tobacco Merchant(50)  
> - Town Crier(85)  
> - Town Justice(20)  
> - Toymaker(14)  
> - Toymaker(23)  
> - Trading Post(74)  
> - Troubadours(50)  
> - Tutor(14)  
> - Undertaker(17)  
> - Used Garment Trader(62)  
> - Vestment Maker(35)  
> - Vintner(31)  
> - Viscount(4)  
> - Wagon Maker(43)  
> - Warehouser(50)  
> - Water Carrier(59)  
> - Weapon Dealer(50)  
> - Weapon Dealer(50)  
> - Weaponsmith(15)  
> - Weaponsmith(15)  
> - Weaver(43)  
> - Wheelwright(46)  
> - Wheelwright(66)  
> - Wine Merchant(25)  
> - Wood Carver(24)  
> - Wood Seller(22)  
> - Wool Merchant(37)  
> - Writer(50)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(50)  
> - Advocate(37)  
> - Alchemist(25)  
> - Animal Groomer(20)  
> - Animal Handler(50)  
> - Antiquities(50)  
> - ArchDuke(1)  
> - Architect(59)  
> - Armor Dealer(50)  
> - Armorer(16)  
> - Artist(66)  
> - Astrologist(14)  
> - Baker(46)  
> - Banker(17)  
> - Barbarian(148)  
> - Barbarian(27)  
> - Barber(25)  
> - Baron(6)  
> - Barrel Maker(31)  
> - Barrel Maker(54)  
> - Basket Maker(43)  
> - Bather(20)  
> - Beer Merchant(27)  
> - Blacksmith(70)  
> - Bleacher(25)  
> - Book Binder(15)  
> - Bookseller(15)  
> - Bowyer-Fletcher(24)  
> - Bowyer-Fletcher(24)  
> - Brewer(7)  
> - Bricklayer(59)  
> - Brigand(148)  
> - Brigand(50)  
> - Brothel Keeper(21)  
> - Buckle Maker(23)  
> - Buckle Maker(40)  
> - Butcher(30)  
> - Candle Maker(19)  
> - Captain(148)  
> - Caravanner(37)  
> - Carpenter(85)  
> - Cartographer(25)  
> - Chandler(74)  
> - Chandler(74)  
> - Chicken Butcher(30)  
> - Cleric(54)  
> - Clerk(85)  
> - Clock Maker(14)  
> - Cobbler(35)  
> - Cobbler(46)  
> - Conjourer(14)  
> - Cook(31)  
> - Cooper(35)  
> - Council Member(74)  
> - Count(3)  
> - Crime Lord(12)  
> - Crook(59)  
> - Cutler(15)  
> - Dairy Seller(148)  
> - Diplomat(12)  
> - Distiller(27)  
> - Draper(25)  
> - Duke(2)  
> - Dungsweeper(42)  
> - Dye Makers(74)  
> - Dye Makers(74)  
> - Earl(3)  
> - Engineer(59)  
> - Engraver(14)  
> - Farmer - Cabbage(148)  
> - Farmer - Cattle Herder(148)  
> - Farmer - Corn(148)  
> - Farmer - Cow Herder(148)  
> - Farmer - Dairy(148)  
> - Farmer - Goat Herder(148)  
> - Farmer - Pig Herder(148)  
> - Farmer - Potato(148)  
> - Farmer - Sheep Herder(148)  
> - Farmer - Wheat(148)  
> - Farmer(1472)  
> - Farmer(Special)(148)  
> - Fisherman(37)  
> - Fishmonger(37)  
> - Florist(25)  
> - Furniture Maker(46)  
> - Furrier(66)  
> - Girdler(22)  
> - Glassblower(22)  
> - Glassblower(50)  
> - Glazier(15)  
> - Glove Merchant(40)  
> - Goldsmith(22)  
> - Goldsmith(33)  
> - Goon(66)  
> - Grain Merchant(8)  
> - Grocer(22)  
> - Guide(50)  
> - Haberdasher(19)  
> - Harness Maker(50)  
> - Hat Maker(20)  
> - Hay Merchant(148)  
> - Herbalist(25)  
> - High Mage(14)  
> - High Priest(21)  
> - Historian(14)  
> - Homestead(1963)  
> - Horse Trader(59)  
> - Huntsman(74)  
> - Illuminator(30)  
> - Innkeeper(40)  
> - Instrument Maker(14)  
> - Inventor(43)  
> - Jeweler(19)  
> - Jeweler(30)  
> - Judge(43)  
> - Kettle Maker(13)  
> - Knight(10)  
> - Laborer(59)  
> - Launderer(40)  
> - Launderer(50)  
> - Leatherworker(27)  
> - Leatherworker(30)  
> - Librarian(14)  
> - Livestock Merchant(40)  
> - Locksmith(18)  
> - Lord(10)  
> - Magical Artisan(14)  
> - Magical Artisan(14)  
> - Magical Tutor(14)  
> - Mason(59)  
> - Mayor(1)  
> - Meat Butcher(25)  
> - Messenger(46)  
> - Miller(74)  
> - Minstrel(50)  
> - Missionary(197)  
> - Mountainman(148)  
> - Mountainman(23)  
> - Naval Outfitter(16)  
> - Oil Trader(74)  
> - Oil Trader(74)  
> - Painter(Art)(54)  
> - Painter(Building)(59)  
> - Pastry Maker(37)  
> - Pathfinder(25)  
> - Pawnbroker(17)  
> - Perfumer(21)  
> - Physic/Chirurgeon(25)  
> - Pirate(74)  
> - Plasterer(59)  
> - Potionmakers(25)  
> - Potter(50)  
> - Preacher(118)  
> - Priest(66)  
> - Professor(14)  
> - Purse Maker(25)  
> - Roofer(59)  
> - Roofer(59)  
> - Rope Maker(35)  
> - Rug Maker(18)  
> - Saddler(37)  
> - Sage(14)  
> - Sail Maker(43)  
> - Sailor(99)  
> - Scout(25)  
> - Scribe(14)  
> - Sculptor(13)  
> - SellSpell(14)  
> - Ship Builder(18)  
> - Shoe Maker(35)  
> - Shoe Maker(35)  
> - Silversmith(18)  
> - Silversmith(43)  
> - Skinner(30)  
> - Slaver(50)  
> - Slaver(50)  
> - Soap Maker(25)  
> - Spice Merchant(50)  
> - Spice Merchant(50)  
> - Stabler(53)  
> - Storyteller(50)  
> - Tailor(40)  
> - Tanner(37)  
> - Tanner(37)  
> - Tavern Keeper(54)  
> - Tax Collector(8)  
> - Taxidermist(50)  
> - Taxidermist(50)  
> - Teacher(14)  
> - Teamster(59)  
> - Tiler(59)  
> - Tinker(17)  
> - Tinker(74)  
> - Tobacco Merchant(50)  
> - Tobacco Merchant(50)  
> - Town Crier(85)  
> - Town Justice(20)  
> - Toymaker(14)  
> - Toymaker(23)  
> - Trading Post(74)  
> - Troubadours(50)  
> - Tutor(14)  
> - Undertaker(17)  
> - Used Garment Trader(62)  
> - Vestment Maker(35)  
> - Vintner(31)  
> - Viscount(4)  
> - Wagon Maker(43)  
> - Warehouser(50)  
> - Water Carrier(59)  
> - Weapon Dealer(50)  
> - Weapon Dealer(50)  
> - Weaponsmith(15)  
> - Weaponsmith(15)  
> - Weaver(43)  
> - Wheelwright(46)  
> - Wheelwright(66)  
> - Wine Merchant(25)  
> - Wood Carver(24)  
> - Wood Seller(22)  
> - Wool Merchant(37)  
> - Writer(50)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



