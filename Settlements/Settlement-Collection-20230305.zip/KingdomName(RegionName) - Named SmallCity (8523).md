---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallCity
kingdom: KingdomName
region: RegionName
settlementName: Named SmallCity (8523)
terrain: Savannah Hills 
settlementDescription: 
population: 8523
culture: Oriental 
technology: Savage 
leader: 
govermentType: Federation 
demographics: 
- Acrobat(15) 
- Minstrel(15) 
- Storyteller(15) 
- Troubadours(15) 
- Writer(15) 
- Advocate(11) 
- Clerk(25) 
- Council Member(22) 
- Diplomat(4) 
- Judge(13) 
- Mayor(1) 
- Alchemist(8) 
- Chandler(22) 
- Dye Makers(22) 
- Florist(8) 
- Herbalist(8) 
- Potionmakers(8) 
- Sage(4) 
- Spice Merchant(15) 
- Taxidermist(15) 
- Tobacco Merchant(15) 
- Animal Groomer(6) 
- Animal Handler(15) 
- Caravanner(11) 
- Horse Trader(18) 
- Livestock Merchant(12) 
- Stabler(16) 
- Antiquities(15) 
- Armor Dealer(15) 
- Launderer(15) 
- Oil Trader(22) 
- Trading Post(22) 
- Slaver(15) 
- Spice Merchant(15) 
- Taxidermist(15) 
- Tobacco Merchant(15) 
- Warehouser(15) 
- Weapon Dealer(15) 
- Architect(18) 
- Bricklayer(18) 
- Engineer(18) 
- Laborer(18) 
- Mason(18) 
- Painter(Building)(18) 
- Plasterer(18) 
- Roofer(18) 
- Teamster(18) 
- Tiler(18) 
- Armorer(5) 
- Blacksmith(21) 
- Bowyer-Fletcher(7) 
- Jeweler(6) 
- Silversmith(6) 
- Weapon Dealer(15) 
- Weaponsmith(5) 
- Artist(19) 
- Glassblower(15) 
- Goldsmith(10) 
- Inventor(13) 
- Jeweler(9) 
- Magical Artisan(4) 
- Painter(Art)(16) 
- Silversmith(13) 
- Tinker(22) 
- Toymaker(7) 
- Astrologist(4) 
- Conjourer(4) 
- High Mage(4) 
- Historian(4) 
- Librarian(4) 
- Magical Artisan(4) 
- Magical Tutor(4) 
- Professor(4) 
- Scribe(4) 
- SellSpell(4) 
- Teacher(4) 
- Tutor(4) 
- Baker(14) 
- Beer Merchant(8) 
- Brewer(1) 
- Butcher(9) 
- Chicken Butcher(9) 
- Cook(9) 
- Dairy Seller(43) 
- Distiller(8) 
- Hay Merchant(43) 
- Fisherman(11) 
- Fishmonger(11) 
- Grain Merchant(3) 
- Grocer(7) 
- Meat Butcher(8) 
- Miller(22) 
- Pastry Maker(11) 
- Vintner(9) 
- Banker(5) 
- Pawnbroker(5) 
- Barbarian(43) 
- Brigand(43) 
- Captain(43) 
- Mountainman(43) 
- Barbarian(8) 
- Cartographer(8) 
- Guide(15) 
- Huntsman(22) 
- Mountainman(7) 
- Pathfinder(8) 
- Scout(8) 
- Slaver(15) 
- Barrel Maker(9) 
- Basket Maker(13) 
- Book Binder(5) 
- Bookseller(5) 
- Buckle Maker(7) 
- Candle Maker(6) 
- Clock Maker(4) 
- Cobbler(14) 
- Cooper(11) 
- Cutler(5) 
- Engraver(4) 
- Furniture Maker(14) 
- Glassblower(7) 
- Glazier(5) 
- Glove Merchant(12) 
- Goldsmith(7) 
- Harness Maker(15) 
- Hat Maker(6) 
- Instrument Maker(4) 
- Kettle Maker(4) 
- Locksmith(6) 
- Perfumer(6) 
- Potter(15) 
- Rope Maker(11) 
- Rug Maker(6) 
- Saddler(11) 
- Sculptor(4) 
- Shoe Maker(11) 
- Soap Maker(8) 
- Tanner(11) 
- Tinker(5) 
- Toymaker(4) 
- Weaponsmith(5) 
- Weaver(13) 
- Wheelwright(19) 
- Wine Merchant(8) 
- Wool Merchant(11) 
- Lord(3) 
- Knight(3) 
- Baron(2) 
- Viscount(1) 
- Earl(1) 
- Count(1) 
- Barrel Maker(16) 
- Bowyer-Fletcher(7) 
- Carpenter(25) 
- Roofer(18) 
- Wagon Maker(13) 
- Wheelwright(14) 
- Wood Carver(7) 
- Wood Seller(7) 
- Barber(8) 
- Bleacher(8) 
- Physic/Chirurgeon(8) 
- Bather(6) 
- Brigand(15) 
- Crime Lord(4) 
- Crook(18) 
- Goon(19) 
- Brothel Keeper(6) 
- Innkeeper(12) 
- Tavern Keeper(16) 
- Buckle Maker(12) 
- Cobbler(11) 
- Draper(7) 
- Furrier(19) 
- Girdler(7) 
- Haberdasher(6) 
- Launderer(12) 
- Leatherworker(8) 
- Purse Maker(8) 
- Shoe Maker(11) 
- Tailor(12) 
- Tanner(11) 
- Used Garment Trader(18) 
- Vestment Maker(11) 
- Chandler(22) 
- Dye Makers(22) 
- Oil Trader(22) 
- Cleric(16) 
- High Priest(6) 
- Missionary(57) 
- Preacher(35) 
- Priest(19) 
- Farmer(427) 
- Homestead(569) 
- Farmer - Cabbage(43) 
- Farmer - Cattle Herder(43) 
- Farmer - Corn(43) 
- Farmer - Cow Herder(43) 
- Farmer - Dairy(43) 
- Farmer - Goat Herder(43) 
- Farmer - Pig Herder(43) 
- Farmer - Potato(43) 
- Farmer - Sheep Herder(43) 
- Farmer - Wheat(43) 
- Farmer(Special)(43) 
- Dungsweeper(13) 
- Illuminator(9) 
- Messenger(14) 
- Tax Collector(3) 
- Town Crier(25) 
- Town Justice(6) 
- Undertaker(5) 
- Water Carrier(18) 
- Leatherworker(9) 
- Skinner(9) 
- Naval Outfitter(5) 
- Pirate(22) 
- Sail Maker(13) 
- Sailor(29) 
- Ship Builder(6) 
imports: 
- Shells  
exports: 
- Incense  
defenses: Archer towers 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(15)  
> - Advocate(11)  
> - Alchemist(8)  
> - Animal Groomer(6)  
> - Animal Handler(15)  
> - Antiquities(15)  
> - Architect(18)  
> - Armor Dealer(15)  
> - Armorer(5)  
> - Artist(19)  
> - Astrologist(4)  
> - Baker(14)  
> - Banker(5)  
> - Barbarian(43)  
> - Barbarian(8)  
> - Barber(8)  
> - Baron(2)  
> - Barrel Maker(16)  
> - Barrel Maker(9)  
> - Basket Maker(13)  
> - Bather(6)  
> - Beer Merchant(8)  
> - Blacksmith(21)  
> - Bleacher(8)  
> - Book Binder(5)  
> - Bookseller(5)  
> - Bowyer-Fletcher(7)  
> - Bowyer-Fletcher(7)  
> - Brewer(1)  
> - Bricklayer(18)  
> - Brigand(15)  
> - Brigand(43)  
> - Brothel Keeper(6)  
> - Buckle Maker(12)  
> - Buckle Maker(7)  
> - Butcher(9)  
> - Candle Maker(6)  
> - Captain(43)  
> - Caravanner(11)  
> - Carpenter(25)  
> - Cartographer(8)  
> - Chandler(22)  
> - Chandler(22)  
> - Chicken Butcher(9)  
> - Cleric(16)  
> - Clerk(25)  
> - Clock Maker(4)  
> - Cobbler(11)  
> - Cobbler(14)  
> - Conjourer(4)  
> - Cook(9)  
> - Cooper(11)  
> - Council Member(22)  
> - Count(1)  
> - Crime Lord(4)  
> - Crook(18)  
> - Cutler(5)  
> - Dairy Seller(43)  
> - Diplomat(4)  
> - Distiller(8)  
> - Draper(7)  
> - Dungsweeper(13)  
> - Dye Makers(22)  
> - Dye Makers(22)  
> - Earl(1)  
> - Engineer(18)  
> - Engraver(4)  
> - Farmer - Cabbage(43)  
> - Farmer - Cattle Herder(43)  
> - Farmer - Corn(43)  
> - Farmer - Cow Herder(43)  
> - Farmer - Dairy(43)  
> - Farmer - Goat Herder(43)  
> - Farmer - Pig Herder(43)  
> - Farmer - Potato(43)  
> - Farmer - Sheep Herder(43)  
> - Farmer - Wheat(43)  
> - Farmer(427)  
> - Farmer(Special)(43)  
> - Fisherman(11)  
> - Fishmonger(11)  
> - Florist(8)  
> - Furniture Maker(14)  
> - Furrier(19)  
> - Girdler(7)  
> - Glassblower(15)  
> - Glassblower(7)  
> - Glazier(5)  
> - Glove Merchant(12)  
> - Goldsmith(10)  
> - Goldsmith(7)  
> - Goon(19)  
> - Grain Merchant(3)  
> - Grocer(7)  
> - Guide(15)  
> - Haberdasher(6)  
> - Harness Maker(15)  
> - Hat Maker(6)  
> - Hay Merchant(43)  
> - Herbalist(8)  
> - High Mage(4)  
> - High Priest(6)  
> - Historian(4)  
> - Homestead(569)  
> - Horse Trader(18)  
> - Huntsman(22)  
> - Illuminator(9)  
> - Innkeeper(12)  
> - Instrument Maker(4)  
> - Inventor(13)  
> - Jeweler(6)  
> - Jeweler(9)  
> - Judge(13)  
> - Kettle Maker(4)  
> - Knight(3)  
> - Laborer(18)  
> - Launderer(12)  
> - Launderer(15)  
> - Leatherworker(8)  
> - Leatherworker(9)  
> - Librarian(4)  
> - Livestock Merchant(12)  
> - Locksmith(6)  
> - Lord(3)  
> - Magical Artisan(4)  
> - Magical Artisan(4)  
> - Magical Tutor(4)  
> - Mason(18)  
> - Mayor(1)  
> - Meat Butcher(8)  
> - Messenger(14)  
> - Miller(22)  
> - Minstrel(15)  
> - Missionary(57)  
> - Mountainman(43)  
> - Mountainman(7)  
> - Naval Outfitter(5)  
> - Oil Trader(22)  
> - Oil Trader(22)  
> - Painter(Art)(16)  
> - Painter(Building)(18)  
> - Pastry Maker(11)  
> - Pathfinder(8)  
> - Pawnbroker(5)  
> - Perfumer(6)  
> - Physic/Chirurgeon(8)  
> - Pirate(22)  
> - Plasterer(18)  
> - Potionmakers(8)  
> - Potter(15)  
> - Preacher(35)  
> - Priest(19)  
> - Professor(4)  
> - Purse Maker(8)  
> - Roofer(18)  
> - Roofer(18)  
> - Rope Maker(11)  
> - Rug Maker(6)  
> - Saddler(11)  
> - Sage(4)  
> - Sail Maker(13)  
> - Sailor(29)  
> - Scout(8)  
> - Scribe(4)  
> - Sculptor(4)  
> - SellSpell(4)  
> - Ship Builder(6)  
> - Shoe Maker(11)  
> - Shoe Maker(11)  
> - Silversmith(13)  
> - Silversmith(6)  
> - Skinner(9)  
> - Slaver(15)  
> - Slaver(15)  
> - Soap Maker(8)  
> - Spice Merchant(15)  
> - Spice Merchant(15)  
> - Stabler(16)  
> - Storyteller(15)  
> - Tailor(12)  
> - Tanner(11)  
> - Tanner(11)  
> - Tavern Keeper(16)  
> - Tax Collector(3)  
> - Taxidermist(15)  
> - Taxidermist(15)  
> - Teacher(4)  
> - Teamster(18)  
> - Tiler(18)  
> - Tinker(22)  
> - Tinker(5)  
> - Tobacco Merchant(15)  
> - Tobacco Merchant(15)  
> - Town Crier(25)  
> - Town Justice(6)  
> - Toymaker(4)  
> - Toymaker(7)  
> - Trading Post(22)  
> - Troubadours(15)  
> - Tutor(4)  
> - Undertaker(5)  
> - Used Garment Trader(18)  
> - Vestment Maker(11)  
> - Vintner(9)  
> - Viscount(1)  
> - Wagon Maker(13)  
> - Warehouser(15)  
> - Water Carrier(18)  
> - Weapon Dealer(15)  
> - Weapon Dealer(15)  
> - Weaponsmith(5)  
> - Weaponsmith(5)  
> - Weaver(13)  
> - Wheelwright(14)  
> - Wheelwright(19)  
> - Wine Merchant(8)  
> - Wood Carver(7)  
> - Wood Seller(7)  
> - Wool Merchant(11)  
> - Writer(15)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(15)  
> - Advocate(11)  
> - Alchemist(8)  
> - Animal Groomer(6)  
> - Animal Handler(15)  
> - Antiquities(15)  
> - Architect(18)  
> - Armor Dealer(15)  
> - Armorer(5)  
> - Artist(19)  
> - Astrologist(4)  
> - Baker(14)  
> - Banker(5)  
> - Barbarian(43)  
> - Barbarian(8)  
> - Barber(8)  
> - Baron(2)  
> - Barrel Maker(16)  
> - Barrel Maker(9)  
> - Basket Maker(13)  
> - Bather(6)  
> - Beer Merchant(8)  
> - Blacksmith(21)  
> - Bleacher(8)  
> - Book Binder(5)  
> - Bookseller(5)  
> - Bowyer-Fletcher(7)  
> - Bowyer-Fletcher(7)  
> - Brewer(1)  
> - Bricklayer(18)  
> - Brigand(15)  
> - Brigand(43)  
> - Brothel Keeper(6)  
> - Buckle Maker(12)  
> - Buckle Maker(7)  
> - Butcher(9)  
> - Candle Maker(6)  
> - Captain(43)  
> - Caravanner(11)  
> - Carpenter(25)  
> - Cartographer(8)  
> - Chandler(22)  
> - Chandler(22)  
> - Chicken Butcher(9)  
> - Cleric(16)  
> - Clerk(25)  
> - Clock Maker(4)  
> - Cobbler(11)  
> - Cobbler(14)  
> - Conjourer(4)  
> - Cook(9)  
> - Cooper(11)  
> - Council Member(22)  
> - Count(1)  
> - Crime Lord(4)  
> - Crook(18)  
> - Cutler(5)  
> - Dairy Seller(43)  
> - Diplomat(4)  
> - Distiller(8)  
> - Draper(7)  
> - Dungsweeper(13)  
> - Dye Makers(22)  
> - Dye Makers(22)  
> - Earl(1)  
> - Engineer(18)  
> - Engraver(4)  
> - Farmer - Cabbage(43)  
> - Farmer - Cattle Herder(43)  
> - Farmer - Corn(43)  
> - Farmer - Cow Herder(43)  
> - Farmer - Dairy(43)  
> - Farmer - Goat Herder(43)  
> - Farmer - Pig Herder(43)  
> - Farmer - Potato(43)  
> - Farmer - Sheep Herder(43)  
> - Farmer - Wheat(43)  
> - Farmer(427)  
> - Farmer(Special)(43)  
> - Fisherman(11)  
> - Fishmonger(11)  
> - Florist(8)  
> - Furniture Maker(14)  
> - Furrier(19)  
> - Girdler(7)  
> - Glassblower(15)  
> - Glassblower(7)  
> - Glazier(5)  
> - Glove Merchant(12)  
> - Goldsmith(10)  
> - Goldsmith(7)  
> - Goon(19)  
> - Grain Merchant(3)  
> - Grocer(7)  
> - Guide(15)  
> - Haberdasher(6)  
> - Harness Maker(15)  
> - Hat Maker(6)  
> - Hay Merchant(43)  
> - Herbalist(8)  
> - High Mage(4)  
> - High Priest(6)  
> - Historian(4)  
> - Homestead(569)  
> - Horse Trader(18)  
> - Huntsman(22)  
> - Illuminator(9)  
> - Innkeeper(12)  
> - Instrument Maker(4)  
> - Inventor(13)  
> - Jeweler(6)  
> - Jeweler(9)  
> - Judge(13)  
> - Kettle Maker(4)  
> - Knight(3)  
> - Laborer(18)  
> - Launderer(12)  
> - Launderer(15)  
> - Leatherworker(8)  
> - Leatherworker(9)  
> - Librarian(4)  
> - Livestock Merchant(12)  
> - Locksmith(6)  
> - Lord(3)  
> - Magical Artisan(4)  
> - Magical Artisan(4)  
> - Magical Tutor(4)  
> - Mason(18)  
> - Mayor(1)  
> - Meat Butcher(8)  
> - Messenger(14)  
> - Miller(22)  
> - Minstrel(15)  
> - Missionary(57)  
> - Mountainman(43)  
> - Mountainman(7)  
> - Naval Outfitter(5)  
> - Oil Trader(22)  
> - Oil Trader(22)  
> - Painter(Art)(16)  
> - Painter(Building)(18)  
> - Pastry Maker(11)  
> - Pathfinder(8)  
> - Pawnbroker(5)  
> - Perfumer(6)  
> - Physic/Chirurgeon(8)  
> - Pirate(22)  
> - Plasterer(18)  
> - Potionmakers(8)  
> - Potter(15)  
> - Preacher(35)  
> - Priest(19)  
> - Professor(4)  
> - Purse Maker(8)  
> - Roofer(18)  
> - Roofer(18)  
> - Rope Maker(11)  
> - Rug Maker(6)  
> - Saddler(11)  
> - Sage(4)  
> - Sail Maker(13)  
> - Sailor(29)  
> - Scout(8)  
> - Scribe(4)  
> - Sculptor(4)  
> - SellSpell(4)  
> - Ship Builder(6)  
> - Shoe Maker(11)  
> - Shoe Maker(11)  
> - Silversmith(13)  
> - Silversmith(6)  
> - Skinner(9)  
> - Slaver(15)  
> - Slaver(15)  
> - Soap Maker(8)  
> - Spice Merchant(15)  
> - Spice Merchant(15)  
> - Stabler(16)  
> - Storyteller(15)  
> - Tailor(12)  
> - Tanner(11)  
> - Tanner(11)  
> - Tavern Keeper(16)  
> - Tax Collector(3)  
> - Taxidermist(15)  
> - Taxidermist(15)  
> - Teacher(4)  
> - Teamster(18)  
> - Tiler(18)  
> - Tinker(22)  
> - Tinker(5)  
> - Tobacco Merchant(15)  
> - Tobacco Merchant(15)  
> - Town Crier(25)  
> - Town Justice(6)  
> - Toymaker(4)  
> - Toymaker(7)  
> - Trading Post(22)  
> - Troubadours(15)  
> - Tutor(4)  
> - Undertaker(5)  
> - Used Garment Trader(18)  
> - Vestment Maker(11)  
> - Vintner(9)  
> - Viscount(1)  
> - Wagon Maker(13)  
> - Warehouser(15)  
> - Water Carrier(18)  
> - Weapon Dealer(15)  
> - Weapon Dealer(15)  
> - Weaponsmith(5)  
> - Weaponsmith(5)  
> - Weaver(13)  
> - Wheelwright(14)  
> - Wheelwright(19)  
> - Wine Merchant(8)  
> - Wood Carver(7)  
> - Wood Seller(7)  
> - Wool Merchant(11)  
> - Writer(15)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



