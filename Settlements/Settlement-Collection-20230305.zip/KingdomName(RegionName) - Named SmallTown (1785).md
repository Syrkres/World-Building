---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallTown
kingdom: KingdomName
region: RegionName
settlementName: Named SmallTown (1785)
terrain: Badlands 
settlementDescription: 
population: 1785
culture: Renaissance 
technology: Roman 
leader: 
govermentType: Dictatorship 
demographics: 
- Acrobat(3) 
- Minstrel(3) 
- Storyteller(3) 
- Troubadours(3) 
- Writer(3) 
- Advocate(3) 
- Clerk(6) 
- Council Member(5) 
- Diplomat(1) 
- Judge(3) 
- Mayor(1) 
- Alchemist(1) 
- Chandler(5) 
- Dye Makers(5) 
- Florist(1) 
- Herbalist(1) 
- Potionmakers(1) 
- Spice Merchant(3) 
- Taxidermist(3) 
- Tobacco Merchant(3) 
- Animal Groomer(1) 
- Animal Handler(3) 
- Caravanner(3) 
- Horse Trader(4) 
- Livestock Merchant(3) 
- Stabler(4) 
- Antiquities(3) 
- Armor Dealer(3) 
- Launderer(3) 
- Oil Trader(5) 
- Trading Post(5) 
- Slaver(3) 
- Spice Merchant(3) 
- Taxidermist(3) 
- Tobacco Merchant(3) 
- Warehouser(3) 
- Weapon Dealer(3) 
- Architect(4) 
- Bricklayer(4) 
- Engineer(4) 
- Laborer(4) 
- Mason(4) 
- Painter(Building)(4) 
- Plasterer(4) 
- Roofer(4) 
- Teamster(4) 
- Tiler(4) 
- Armorer(1) 
- Blacksmith(5) 
- Bowyer-Fletcher(2) 
- Jeweler(2) 
- Silversmith(2) 
- Weapon Dealer(3) 
- Weaponsmith(1) 
- Artist(4) 
- Glassblower(3) 
- Goldsmith(2) 
- Inventor(3) 
- Jeweler(1) 
- Painter(Art)(4) 
- Silversmith(3) 
- Tinker(5) 
- Toymaker(1) 
- Baker(3) 
- Beer Merchant(1) 
- Butcher(1) 
- Chicken Butcher(1) 
- Cook(1) 
- Dairy Seller(9) 
- Distiller(1) 
- Hay Merchant(9) 
- Fisherman(3) 
- Fishmonger(3) 
- Grocer(1) 
- Meat Butcher(1) 
- Miller(5) 
- Pastry Maker(3) 
- Vintner(1) 
- Barbarian(9) 
- Brigand(9) 
- Captain(9) 
- Mountainman(9) 
- Barbarian(2) 
- Cartographer(1) 
- Guide(3) 
- Huntsman(5) 
- Mountainman(1) 
- Pathfinder(2) 
- Scout(2) 
- Slaver(3) 
- Barrel Maker(2) 
- Basket Maker(3) 
- Book Binder(1) 
- Buckle Maker(1) 
- Candle Maker(1) 
- Cobbler(3) 
- Cooper(3) 
- Cutler(1) 
- Engraver(1) 
- Furniture Maker(3) 
- Glassblower(1) 
- Glazier(1) 
- Glove Merchant(3) 
- Goldsmith(1) 
- Harness Maker(3) 
- Hat Maker(1) 
- Locksmith(1) 
- Perfumer(1) 
- Potter(3) 
- Rope Maker(3) 
- Rug Maker(1) 
- Saddler(3) 
- Sculptor(1) 
- Shoe Maker(3) 
- Soap Maker(1) 
- Tanner(3) 
- Tinker(1) 
- Weaver(3) 
- Wheelwright(4) 
- Wine Merchant(2) 
- Wool Merchant(3) 
- Lord(1) 
- Knight(1) 
- Barrel Maker(4) 
- Bowyer-Fletcher(1) 
- Carpenter(6) 
- Roofer(4) 
- Wagon Maker(3) 
- Wheelwright(3) 
- Wood Carver(1) 
- Wood Seller(1) 
- Barber(2) 
- Bleacher(1) 
- Physic/Chirurgeon(2) 
- Bather(2) 
- Brigand(3) 
- Crook(4) 
- Goon(4) 
- Brothel Keeper(1) 
- Innkeeper(3) 
- Tavern Keeper(4) 
- Buckle Maker(3) 
- Cobbler(3) 
- Draper(2) 
- Furrier(4) 
- Girdler(1) 
- Haberdasher(1) 
- Launderer(3) 
- Leatherworker(2) 
- Purse Maker(2) 
- Shoe Maker(3) 
- Tailor(3) 
- Tanner(3) 
- Used Garment Trader(4) 
- Vestment Maker(3) 
- Chandler(5) 
- Dye Makers(5) 
- Oil Trader(5) 
- Cleric(4) 
- High Priest(1) 
- Missionary(12) 
- Preacher(8) 
- Priest(4) 
- Farmer(90) 
- Homestead(120) 
- Farmer - Cabbage(9) 
- Farmer - Cattle Herder(9) 
- Farmer - Corn(9) 
- Farmer - Cow Herder(9) 
- Farmer - Dairy(9) 
- Farmer - Goat Herder(9) 
- Farmer - Pig Herder(9) 
- Farmer - Potato(9) 
- Farmer - Sheep Herder(9) 
- Farmer - Wheat(9) 
- Farmer(Special)(9) 
- Dungsweeper(3) 
- Illuminator(2) 
- Messenger(3) 
- Town Crier(6) 
- Town Justice(2) 
- Undertaker(1) 
- Water Carrier(4) 
- Leatherworker(1) 
- Skinner(1) 
- Naval Outfitter(1) 
- Pirate(5) 
- Sail Maker(3) 
- Sailor(6) 
- Ship Builder(1) 
imports: 
- Amber  
exports: 
- Granite  
defenses: Wood Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(3)  
> - Advocate(3)  
> - Alchemist(1)  
> - Animal Groomer(1)  
> - Animal Handler(3)  
> - Antiquities(3)  
> - Architect(4)  
> - Armor Dealer(3)  
> - Armorer(1)  
> - Artist(4)  
> - Baker(3)  
> - Barbarian(2)  
> - Barbarian(9)  
> - Barber(2)  
> - Barrel Maker(2)  
> - Barrel Maker(4)  
> - Basket Maker(3)  
> - Bather(2)  
> - Beer Merchant(1)  
> - Blacksmith(5)  
> - Bleacher(1)  
> - Book Binder(1)  
> - Bowyer-Fletcher(1)  
> - Bowyer-Fletcher(2)  
> - Bricklayer(4)  
> - Brigand(3)  
> - Brigand(9)  
> - Brothel Keeper(1)  
> - Buckle Maker(1)  
> - Buckle Maker(3)  
> - Butcher(1)  
> - Candle Maker(1)  
> - Captain(9)  
> - Caravanner(3)  
> - Carpenter(6)  
> - Cartographer(1)  
> - Chandler(5)  
> - Chandler(5)  
> - Chicken Butcher(1)  
> - Cleric(4)  
> - Clerk(6)  
> - Cobbler(3)  
> - Cobbler(3)  
> - Cook(1)  
> - Cooper(3)  
> - Council Member(5)  
> - Crook(4)  
> - Cutler(1)  
> - Dairy Seller(9)  
> - Diplomat(1)  
> - Distiller(1)  
> - Draper(2)  
> - Dungsweeper(3)  
> - Dye Makers(5)  
> - Dye Makers(5)  
> - Engineer(4)  
> - Engraver(1)  
> - Farmer - Cabbage(9)  
> - Farmer - Cattle Herder(9)  
> - Farmer - Corn(9)  
> - Farmer - Cow Herder(9)  
> - Farmer - Dairy(9)  
> - Farmer - Goat Herder(9)  
> - Farmer - Pig Herder(9)  
> - Farmer - Potato(9)  
> - Farmer - Sheep Herder(9)  
> - Farmer - Wheat(9)  
> - Farmer(90)  
> - Farmer(Special)(9)  
> - Fisherman(3)  
> - Fishmonger(3)  
> - Florist(1)  
> - Furniture Maker(3)  
> - Furrier(4)  
> - Girdler(1)  
> - Glassblower(1)  
> - Glassblower(3)  
> - Glazier(1)  
> - Glove Merchant(3)  
> - Goldsmith(1)  
> - Goldsmith(2)  
> - Goon(4)  
> - Grocer(1)  
> - Guide(3)  
> - Haberdasher(1)  
> - Harness Maker(3)  
> - Hat Maker(1)  
> - Hay Merchant(9)  
> - Herbalist(1)  
> - High Priest(1)  
> - Homestead(120)  
> - Horse Trader(4)  
> - Huntsman(5)  
> - Illuminator(2)  
> - Innkeeper(3)  
> - Inventor(3)  
> - Jeweler(1)  
> - Jeweler(2)  
> - Judge(3)  
> - Knight(1)  
> - Laborer(4)  
> - Launderer(3)  
> - Launderer(3)  
> - Leatherworker(1)  
> - Leatherworker(2)  
> - Livestock Merchant(3)  
> - Locksmith(1)  
> - Lord(1)  
> - Mason(4)  
> - Mayor(1)  
> - Meat Butcher(1)  
> - Messenger(3)  
> - Miller(5)  
> - Minstrel(3)  
> - Missionary(12)  
> - Mountainman(1)  
> - Mountainman(9)  
> - Naval Outfitter(1)  
> - Oil Trader(5)  
> - Oil Trader(5)  
> - Painter(Art)(4)  
> - Painter(Building)(4)  
> - Pastry Maker(3)  
> - Pathfinder(2)  
> - Perfumer(1)  
> - Physic/Chirurgeon(2)  
> - Pirate(5)  
> - Plasterer(4)  
> - Potionmakers(1)  
> - Potter(3)  
> - Preacher(8)  
> - Priest(4)  
> - Purse Maker(2)  
> - Roofer(4)  
> - Roofer(4)  
> - Rope Maker(3)  
> - Rug Maker(1)  
> - Saddler(3)  
> - Sail Maker(3)  
> - Sailor(6)  
> - Scout(2)  
> - Sculptor(1)  
> - Ship Builder(1)  
> - Shoe Maker(3)  
> - Shoe Maker(3)  
> - Silversmith(2)  
> - Silversmith(3)  
> - Skinner(1)  
> - Slaver(3)  
> - Slaver(3)  
> - Soap Maker(1)  
> - Spice Merchant(3)  
> - Spice Merchant(3)  
> - Stabler(4)  
> - Storyteller(3)  
> - Tailor(3)  
> - Tanner(3)  
> - Tanner(3)  
> - Tavern Keeper(4)  
> - Taxidermist(3)  
> - Taxidermist(3)  
> - Teamster(4)  
> - Tiler(4)  
> - Tinker(1)  
> - Tinker(5)  
> - Tobacco Merchant(3)  
> - Tobacco Merchant(3)  
> - Town Crier(6)  
> - Town Justice(2)  
> - Toymaker(1)  
> - Trading Post(5)  
> - Troubadours(3)  
> - Undertaker(1)  
> - Used Garment Trader(4)  
> - Vestment Maker(3)  
> - Vintner(1)  
> - Wagon Maker(3)  
> - Warehouser(3)  
> - Water Carrier(4)  
> - Weapon Dealer(3)  
> - Weapon Dealer(3)  
> - Weaponsmith(1)  
> - Weaver(3)  
> - Wheelwright(3)  
> - Wheelwright(4)  
> - Wine Merchant(2)  
> - Wood Carver(1)  
> - Wood Seller(1)  
> - Wool Merchant(3)  
> - Writer(3)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(3)  
> - Advocate(3)  
> - Alchemist(1)  
> - Animal Groomer(1)  
> - Animal Handler(3)  
> - Antiquities(3)  
> - Architect(4)  
> - Armor Dealer(3)  
> - Armorer(1)  
> - Artist(4)  
> - Baker(3)  
> - Barbarian(2)  
> - Barbarian(9)  
> - Barber(2)  
> - Barrel Maker(2)  
> - Barrel Maker(4)  
> - Basket Maker(3)  
> - Bather(2)  
> - Beer Merchant(1)  
> - Blacksmith(5)  
> - Bleacher(1)  
> - Book Binder(1)  
> - Bowyer-Fletcher(1)  
> - Bowyer-Fletcher(2)  
> - Bricklayer(4)  
> - Brigand(3)  
> - Brigand(9)  
> - Brothel Keeper(1)  
> - Buckle Maker(1)  
> - Buckle Maker(3)  
> - Butcher(1)  
> - Candle Maker(1)  
> - Captain(9)  
> - Caravanner(3)  
> - Carpenter(6)  
> - Cartographer(1)  
> - Chandler(5)  
> - Chandler(5)  
> - Chicken Butcher(1)  
> - Cleric(4)  
> - Clerk(6)  
> - Cobbler(3)  
> - Cobbler(3)  
> - Cook(1)  
> - Cooper(3)  
> - Council Member(5)  
> - Crook(4)  
> - Cutler(1)  
> - Dairy Seller(9)  
> - Diplomat(1)  
> - Distiller(1)  
> - Draper(2)  
> - Dungsweeper(3)  
> - Dye Makers(5)  
> - Dye Makers(5)  
> - Engineer(4)  
> - Engraver(1)  
> - Farmer - Cabbage(9)  
> - Farmer - Cattle Herder(9)  
> - Farmer - Corn(9)  
> - Farmer - Cow Herder(9)  
> - Farmer - Dairy(9)  
> - Farmer - Goat Herder(9)  
> - Farmer - Pig Herder(9)  
> - Farmer - Potato(9)  
> - Farmer - Sheep Herder(9)  
> - Farmer - Wheat(9)  
> - Farmer(90)  
> - Farmer(Special)(9)  
> - Fisherman(3)  
> - Fishmonger(3)  
> - Florist(1)  
> - Furniture Maker(3)  
> - Furrier(4)  
> - Girdler(1)  
> - Glassblower(1)  
> - Glassblower(3)  
> - Glazier(1)  
> - Glove Merchant(3)  
> - Goldsmith(1)  
> - Goldsmith(2)  
> - Goon(4)  
> - Grocer(1)  
> - Guide(3)  
> - Haberdasher(1)  
> - Harness Maker(3)  
> - Hat Maker(1)  
> - Hay Merchant(9)  
> - Herbalist(1)  
> - High Priest(1)  
> - Homestead(120)  
> - Horse Trader(4)  
> - Huntsman(5)  
> - Illuminator(2)  
> - Innkeeper(3)  
> - Inventor(3)  
> - Jeweler(1)  
> - Jeweler(2)  
> - Judge(3)  
> - Knight(1)  
> - Laborer(4)  
> - Launderer(3)  
> - Launderer(3)  
> - Leatherworker(1)  
> - Leatherworker(2)  
> - Livestock Merchant(3)  
> - Locksmith(1)  
> - Lord(1)  
> - Mason(4)  
> - Mayor(1)  
> - Meat Butcher(1)  
> - Messenger(3)  
> - Miller(5)  
> - Minstrel(3)  
> - Missionary(12)  
> - Mountainman(1)  
> - Mountainman(9)  
> - Naval Outfitter(1)  
> - Oil Trader(5)  
> - Oil Trader(5)  
> - Painter(Art)(4)  
> - Painter(Building)(4)  
> - Pastry Maker(3)  
> - Pathfinder(2)  
> - Perfumer(1)  
> - Physic/Chirurgeon(2)  
> - Pirate(5)  
> - Plasterer(4)  
> - Potionmakers(1)  
> - Potter(3)  
> - Preacher(8)  
> - Priest(4)  
> - Purse Maker(2)  
> - Roofer(4)  
> - Roofer(4)  
> - Rope Maker(3)  
> - Rug Maker(1)  
> - Saddler(3)  
> - Sail Maker(3)  
> - Sailor(6)  
> - Scout(2)  
> - Sculptor(1)  
> - Ship Builder(1)  
> - Shoe Maker(3)  
> - Shoe Maker(3)  
> - Silversmith(2)  
> - Silversmith(3)  
> - Skinner(1)  
> - Slaver(3)  
> - Slaver(3)  
> - Soap Maker(1)  
> - Spice Merchant(3)  
> - Spice Merchant(3)  
> - Stabler(4)  
> - Storyteller(3)  
> - Tailor(3)  
> - Tanner(3)  
> - Tanner(3)  
> - Tavern Keeper(4)  
> - Taxidermist(3)  
> - Taxidermist(3)  
> - Teamster(4)  
> - Tiler(4)  
> - Tinker(1)  
> - Tinker(5)  
> - Tobacco Merchant(3)  
> - Tobacco Merchant(3)  
> - Town Crier(6)  
> - Town Justice(2)  
> - Toymaker(1)  
> - Trading Post(5)  
> - Troubadours(3)  
> - Undertaker(1)  
> - Used Garment Trader(4)  
> - Vestment Maker(3)  
> - Vintner(1)  
> - Wagon Maker(3)  
> - Warehouser(3)  
> - Water Carrier(4)  
> - Weapon Dealer(3)  
> - Weapon Dealer(3)  
> - Weaponsmith(1)  
> - Weaver(3)  
> - Wheelwright(3)  
> - Wheelwright(4)  
> - Wine Merchant(2)  
> - Wood Carver(1)  
> - Wood Seller(1)  
> - Wool Merchant(3)  
> - Writer(3)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



