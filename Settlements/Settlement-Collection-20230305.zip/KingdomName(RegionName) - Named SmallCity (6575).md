---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallCity
kingdom: KingdomName
region: RegionName
settlementName: Named SmallCity (6575)
terrain: Brokenlands 
settlementDescription: 
population: 6575
culture: Oriental 
technology: Stone Age 
leader: 
govermentType: Theocracy 
demographics: 
- Acrobat(11) 
- Minstrel(11) 
- Storyteller(11) 
- Troubadours(11) 
- Writer(11) 
- Advocate(9) 
- Clerk(19) 
- Council Member(17) 
- Diplomat(3) 
- Judge(10) 
- Mayor(1) 
- Alchemist(6) 
- Chandler(17) 
- Dye Makers(17) 
- Florist(6) 
- Herbalist(6) 
- Potionmakers(6) 
- Sage(3) 
- Spice Merchant(11) 
- Taxidermist(11) 
- Tobacco Merchant(11) 
- Animal Groomer(5) 
- Animal Handler(11) 
- Caravanner(9) 
- Horse Trader(14) 
- Livestock Merchant(9) 
- Stabler(12) 
- Antiquities(11) 
- Armor Dealer(11) 
- Launderer(11) 
- Oil Trader(17) 
- Trading Post(17) 
- Slaver(11) 
- Spice Merchant(11) 
- Taxidermist(11) 
- Tobacco Merchant(11) 
- Warehouser(11) 
- Weapon Dealer(11) 
- Architect(14) 
- Bricklayer(14) 
- Engineer(14) 
- Laborer(14) 
- Mason(14) 
- Painter(Building)(14) 
- Plasterer(14) 
- Roofer(14) 
- Teamster(14) 
- Tiler(14) 
- Armorer(4) 
- Blacksmith(16) 
- Bowyer-Fletcher(6) 
- Jeweler(5) 
- Silversmith(4) 
- Weapon Dealer(11) 
- Weaponsmith(4) 
- Artist(15) 
- Glassblower(11) 
- Goldsmith(8) 
- Inventor(10) 
- Jeweler(7) 
- Magical Artisan(3) 
- Painter(Art)(12) 
- Silversmith(10) 
- Tinker(17) 
- Toymaker(6) 
- Astrologist(3) 
- Conjourer(3) 
- High Mage(3) 
- Historian(3) 
- Librarian(3) 
- Magical Artisan(3) 
- Magical Tutor(3) 
- Professor(3) 
- Scribe(3) 
- SellSpell(3) 
- Teacher(3) 
- Tutor(3) 
- Baker(11) 
- Beer Merchant(6) 
- Brewer(1) 
- Butcher(7) 
- Chicken Butcher(7) 
- Cook(7) 
- Dairy Seller(33) 
- Distiller(6) 
- Hay Merchant(33) 
- Fisherman(9) 
- Fishmonger(9) 
- Grain Merchant(1) 
- Grocer(5) 
- Meat Butcher(6) 
- Miller(17) 
- Pastry Maker(9) 
- Vintner(7) 
- Banker(4) 
- Pawnbroker(4) 
- Barbarian(33) 
- Brigand(33) 
- Captain(33) 
- Mountainman(33) 
- Barbarian(6) 
- Cartographer(6) 
- Guide(11) 
- Huntsman(17) 
- Mountainman(6) 
- Pathfinder(6) 
- Scout(6) 
- Slaver(11) 
- Barrel Maker(7) 
- Basket Maker(10) 
- Book Binder(4) 
- Bookseller(4) 
- Buckle Maker(6) 
- Candle Maker(5) 
- Clock Maker(3) 
- Cobbler(11) 
- Cooper(8) 
- Cutler(4) 
- Engraver(3) 
- Furniture Maker(11) 
- Glassblower(5) 
- Glazier(4) 
- Glove Merchant(9) 
- Goldsmith(5) 
- Harness Maker(11) 
- Hat Maker(5) 
- Instrument Maker(3) 
- Kettle Maker(3) 
- Locksmith(4) 
- Perfumer(5) 
- Potter(11) 
- Rope Maker(8) 
- Rug Maker(4) 
- Saddler(9) 
- Sculptor(3) 
- Shoe Maker(8) 
- Soap Maker(6) 
- Tanner(9) 
- Tinker(4) 
- Toymaker(3) 
- Weaponsmith(4) 
- Weaver(10) 
- Wheelwright(15) 
- Wine Merchant(6) 
- Wool Merchant(9) 
- Lord(3) 
- Knight(3) 
- Baron(2) 
- Viscount(1) 
- Earl(1) 
- Barrel Maker(12) 
- Bowyer-Fletcher(6) 
- Carpenter(19) 
- Roofer(14) 
- Wagon Maker(10) 
- Wheelwright(11) 
- Wood Carver(6) 
- Wood Seller(5) 
- Barber(6) 
- Bleacher(6) 
- Physic/Chirurgeon(6) 
- Bather(5) 
- Brigand(11) 
- Crime Lord(3) 
- Crook(14) 
- Goon(15) 
- Brothel Keeper(5) 
- Innkeeper(9) 
- Tavern Keeper(12) 
- Buckle Maker(9) 
- Cobbler(8) 
- Draper(6) 
- Furrier(15) 
- Girdler(5) 
- Haberdasher(5) 
- Launderer(9) 
- Leatherworker(6) 
- Purse Maker(6) 
- Shoe Maker(8) 
- Tailor(9) 
- Tanner(9) 
- Used Garment Trader(14) 
- Vestment Maker(8) 
- Chandler(17) 
- Dye Makers(17) 
- Oil Trader(17) 
- Cleric(12) 
- High Priest(5) 
- Missionary(44) 
- Preacher(27) 
- Priest(15) 
- Farmer(329) 
- Homestead(439) 
- Farmer - Cabbage(33) 
- Farmer - Cattle Herder(33) 
- Farmer - Corn(33) 
- Farmer - Cow Herder(33) 
- Farmer - Dairy(33) 
- Farmer - Goat Herder(33) 
- Farmer - Pig Herder(33) 
- Farmer - Potato(33) 
- Farmer - Sheep Herder(33) 
- Farmer - Wheat(33) 
- Farmer(Special)(33) 
- Dungsweeper(10) 
- Illuminator(7) 
- Messenger(11) 
- Tax Collector(2) 
- Town Crier(19) 
- Town Justice(5) 
- Undertaker(4) 
- Water Carrier(14) 
- Leatherworker(7) 
- Skinner(7) 
- Naval Outfitter(4) 
- Pirate(17) 
- Sail Maker(10) 
- Sailor(22) 
- Ship Builder(4) 
imports: 
- Ore  
exports: 
- Bamboo  
defenses: Archer towers 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(11)  
> - Advocate(9)  
> - Alchemist(6)  
> - Animal Groomer(5)  
> - Animal Handler(11)  
> - Antiquities(11)  
> - Architect(14)  
> - Armor Dealer(11)  
> - Armorer(4)  
> - Artist(15)  
> - Astrologist(3)  
> - Baker(11)  
> - Banker(4)  
> - Barbarian(33)  
> - Barbarian(6)  
> - Barber(6)  
> - Baron(2)  
> - Barrel Maker(12)  
> - Barrel Maker(7)  
> - Basket Maker(10)  
> - Bather(5)  
> - Beer Merchant(6)  
> - Blacksmith(16)  
> - Bleacher(6)  
> - Book Binder(4)  
> - Bookseller(4)  
> - Bowyer-Fletcher(6)  
> - Bowyer-Fletcher(6)  
> - Brewer(1)  
> - Bricklayer(14)  
> - Brigand(11)  
> - Brigand(33)  
> - Brothel Keeper(5)  
> - Buckle Maker(6)  
> - Buckle Maker(9)  
> - Butcher(7)  
> - Candle Maker(5)  
> - Captain(33)  
> - Caravanner(9)  
> - Carpenter(19)  
> - Cartographer(6)  
> - Chandler(17)  
> - Chandler(17)  
> - Chicken Butcher(7)  
> - Cleric(12)  
> - Clerk(19)  
> - Clock Maker(3)  
> - Cobbler(11)  
> - Cobbler(8)  
> - Conjourer(3)  
> - Cook(7)  
> - Cooper(8)  
> - Council Member(17)  
> - Crime Lord(3)  
> - Crook(14)  
> - Cutler(4)  
> - Dairy Seller(33)  
> - Diplomat(3)  
> - Distiller(6)  
> - Draper(6)  
> - Dungsweeper(10)  
> - Dye Makers(17)  
> - Dye Makers(17)  
> - Earl(1)  
> - Engineer(14)  
> - Engraver(3)  
> - Farmer - Cabbage(33)  
> - Farmer - Cattle Herder(33)  
> - Farmer - Corn(33)  
> - Farmer - Cow Herder(33)  
> - Farmer - Dairy(33)  
> - Farmer - Goat Herder(33)  
> - Farmer - Pig Herder(33)  
> - Farmer - Potato(33)  
> - Farmer - Sheep Herder(33)  
> - Farmer - Wheat(33)  
> - Farmer(329)  
> - Farmer(Special)(33)  
> - Fisherman(9)  
> - Fishmonger(9)  
> - Florist(6)  
> - Furniture Maker(11)  
> - Furrier(15)  
> - Girdler(5)  
> - Glassblower(11)  
> - Glassblower(5)  
> - Glazier(4)  
> - Glove Merchant(9)  
> - Goldsmith(5)  
> - Goldsmith(8)  
> - Goon(15)  
> - Grain Merchant(1)  
> - Grocer(5)  
> - Guide(11)  
> - Haberdasher(5)  
> - Harness Maker(11)  
> - Hat Maker(5)  
> - Hay Merchant(33)  
> - Herbalist(6)  
> - High Mage(3)  
> - High Priest(5)  
> - Historian(3)  
> - Homestead(439)  
> - Horse Trader(14)  
> - Huntsman(17)  
> - Illuminator(7)  
> - Innkeeper(9)  
> - Instrument Maker(3)  
> - Inventor(10)  
> - Jeweler(5)  
> - Jeweler(7)  
> - Judge(10)  
> - Kettle Maker(3)  
> - Knight(3)  
> - Laborer(14)  
> - Launderer(11)  
> - Launderer(9)  
> - Leatherworker(6)  
> - Leatherworker(7)  
> - Librarian(3)  
> - Livestock Merchant(9)  
> - Locksmith(4)  
> - Lord(3)  
> - Magical Artisan(3)  
> - Magical Artisan(3)  
> - Magical Tutor(3)  
> - Mason(14)  
> - Mayor(1)  
> - Meat Butcher(6)  
> - Messenger(11)  
> - Miller(17)  
> - Minstrel(11)  
> - Missionary(44)  
> - Mountainman(33)  
> - Mountainman(6)  
> - Naval Outfitter(4)  
> - Oil Trader(17)  
> - Oil Trader(17)  
> - Painter(Art)(12)  
> - Painter(Building)(14)  
> - Pastry Maker(9)  
> - Pathfinder(6)  
> - Pawnbroker(4)  
> - Perfumer(5)  
> - Physic/Chirurgeon(6)  
> - Pirate(17)  
> - Plasterer(14)  
> - Potionmakers(6)  
> - Potter(11)  
> - Preacher(27)  
> - Priest(15)  
> - Professor(3)  
> - Purse Maker(6)  
> - Roofer(14)  
> - Roofer(14)  
> - Rope Maker(8)  
> - Rug Maker(4)  
> - Saddler(9)  
> - Sage(3)  
> - Sail Maker(10)  
> - Sailor(22)  
> - Scout(6)  
> - Scribe(3)  
> - Sculptor(3)  
> - SellSpell(3)  
> - Ship Builder(4)  
> - Shoe Maker(8)  
> - Shoe Maker(8)  
> - Silversmith(10)  
> - Silversmith(4)  
> - Skinner(7)  
> - Slaver(11)  
> - Slaver(11)  
> - Soap Maker(6)  
> - Spice Merchant(11)  
> - Spice Merchant(11)  
> - Stabler(12)  
> - Storyteller(11)  
> - Tailor(9)  
> - Tanner(9)  
> - Tanner(9)  
> - Tavern Keeper(12)  
> - Tax Collector(2)  
> - Taxidermist(11)  
> - Taxidermist(11)  
> - Teacher(3)  
> - Teamster(14)  
> - Tiler(14)  
> - Tinker(17)  
> - Tinker(4)  
> - Tobacco Merchant(11)  
> - Tobacco Merchant(11)  
> - Town Crier(19)  
> - Town Justice(5)  
> - Toymaker(3)  
> - Toymaker(6)  
> - Trading Post(17)  
> - Troubadours(11)  
> - Tutor(3)  
> - Undertaker(4)  
> - Used Garment Trader(14)  
> - Vestment Maker(8)  
> - Vintner(7)  
> - Viscount(1)  
> - Wagon Maker(10)  
> - Warehouser(11)  
> - Water Carrier(14)  
> - Weapon Dealer(11)  
> - Weapon Dealer(11)  
> - Weaponsmith(4)  
> - Weaponsmith(4)  
> - Weaver(10)  
> - Wheelwright(11)  
> - Wheelwright(15)  
> - Wine Merchant(6)  
> - Wood Carver(6)  
> - Wood Seller(5)  
> - Wool Merchant(9)  
> - Writer(11)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(11)  
> - Advocate(9)  
> - Alchemist(6)  
> - Animal Groomer(5)  
> - Animal Handler(11)  
> - Antiquities(11)  
> - Architect(14)  
> - Armor Dealer(11)  
> - Armorer(4)  
> - Artist(15)  
> - Astrologist(3)  
> - Baker(11)  
> - Banker(4)  
> - Barbarian(33)  
> - Barbarian(6)  
> - Barber(6)  
> - Baron(2)  
> - Barrel Maker(12)  
> - Barrel Maker(7)  
> - Basket Maker(10)  
> - Bather(5)  
> - Beer Merchant(6)  
> - Blacksmith(16)  
> - Bleacher(6)  
> - Book Binder(4)  
> - Bookseller(4)  
> - Bowyer-Fletcher(6)  
> - Bowyer-Fletcher(6)  
> - Brewer(1)  
> - Bricklayer(14)  
> - Brigand(11)  
> - Brigand(33)  
> - Brothel Keeper(5)  
> - Buckle Maker(6)  
> - Buckle Maker(9)  
> - Butcher(7)  
> - Candle Maker(5)  
> - Captain(33)  
> - Caravanner(9)  
> - Carpenter(19)  
> - Cartographer(6)  
> - Chandler(17)  
> - Chandler(17)  
> - Chicken Butcher(7)  
> - Cleric(12)  
> - Clerk(19)  
> - Clock Maker(3)  
> - Cobbler(11)  
> - Cobbler(8)  
> - Conjourer(3)  
> - Cook(7)  
> - Cooper(8)  
> - Council Member(17)  
> - Crime Lord(3)  
> - Crook(14)  
> - Cutler(4)  
> - Dairy Seller(33)  
> - Diplomat(3)  
> - Distiller(6)  
> - Draper(6)  
> - Dungsweeper(10)  
> - Dye Makers(17)  
> - Dye Makers(17)  
> - Earl(1)  
> - Engineer(14)  
> - Engraver(3)  
> - Farmer - Cabbage(33)  
> - Farmer - Cattle Herder(33)  
> - Farmer - Corn(33)  
> - Farmer - Cow Herder(33)  
> - Farmer - Dairy(33)  
> - Farmer - Goat Herder(33)  
> - Farmer - Pig Herder(33)  
> - Farmer - Potato(33)  
> - Farmer - Sheep Herder(33)  
> - Farmer - Wheat(33)  
> - Farmer(329)  
> - Farmer(Special)(33)  
> - Fisherman(9)  
> - Fishmonger(9)  
> - Florist(6)  
> - Furniture Maker(11)  
> - Furrier(15)  
> - Girdler(5)  
> - Glassblower(11)  
> - Glassblower(5)  
> - Glazier(4)  
> - Glove Merchant(9)  
> - Goldsmith(5)  
> - Goldsmith(8)  
> - Goon(15)  
> - Grain Merchant(1)  
> - Grocer(5)  
> - Guide(11)  
> - Haberdasher(5)  
> - Harness Maker(11)  
> - Hat Maker(5)  
> - Hay Merchant(33)  
> - Herbalist(6)  
> - High Mage(3)  
> - High Priest(5)  
> - Historian(3)  
> - Homestead(439)  
> - Horse Trader(14)  
> - Huntsman(17)  
> - Illuminator(7)  
> - Innkeeper(9)  
> - Instrument Maker(3)  
> - Inventor(10)  
> - Jeweler(5)  
> - Jeweler(7)  
> - Judge(10)  
> - Kettle Maker(3)  
> - Knight(3)  
> - Laborer(14)  
> - Launderer(11)  
> - Launderer(9)  
> - Leatherworker(6)  
> - Leatherworker(7)  
> - Librarian(3)  
> - Livestock Merchant(9)  
> - Locksmith(4)  
> - Lord(3)  
> - Magical Artisan(3)  
> - Magical Artisan(3)  
> - Magical Tutor(3)  
> - Mason(14)  
> - Mayor(1)  
> - Meat Butcher(6)  
> - Messenger(11)  
> - Miller(17)  
> - Minstrel(11)  
> - Missionary(44)  
> - Mountainman(33)  
> - Mountainman(6)  
> - Naval Outfitter(4)  
> - Oil Trader(17)  
> - Oil Trader(17)  
> - Painter(Art)(12)  
> - Painter(Building)(14)  
> - Pastry Maker(9)  
> - Pathfinder(6)  
> - Pawnbroker(4)  
> - Perfumer(5)  
> - Physic/Chirurgeon(6)  
> - Pirate(17)  
> - Plasterer(14)  
> - Potionmakers(6)  
> - Potter(11)  
> - Preacher(27)  
> - Priest(15)  
> - Professor(3)  
> - Purse Maker(6)  
> - Roofer(14)  
> - Roofer(14)  
> - Rope Maker(8)  
> - Rug Maker(4)  
> - Saddler(9)  
> - Sage(3)  
> - Sail Maker(10)  
> - Sailor(22)  
> - Scout(6)  
> - Scribe(3)  
> - Sculptor(3)  
> - SellSpell(3)  
> - Ship Builder(4)  
> - Shoe Maker(8)  
> - Shoe Maker(8)  
> - Silversmith(10)  
> - Silversmith(4)  
> - Skinner(7)  
> - Slaver(11)  
> - Slaver(11)  
> - Soap Maker(6)  
> - Spice Merchant(11)  
> - Spice Merchant(11)  
> - Stabler(12)  
> - Storyteller(11)  
> - Tailor(9)  
> - Tanner(9)  
> - Tanner(9)  
> - Tavern Keeper(12)  
> - Tax Collector(2)  
> - Taxidermist(11)  
> - Taxidermist(11)  
> - Teacher(3)  
> - Teamster(14)  
> - Tiler(14)  
> - Tinker(17)  
> - Tinker(4)  
> - Tobacco Merchant(11)  
> - Tobacco Merchant(11)  
> - Town Crier(19)  
> - Town Justice(5)  
> - Toymaker(3)  
> - Toymaker(6)  
> - Trading Post(17)  
> - Troubadours(11)  
> - Tutor(3)  
> - Undertaker(4)  
> - Used Garment Trader(14)  
> - Vestment Maker(8)  
> - Vintner(7)  
> - Viscount(1)  
> - Wagon Maker(10)  
> - Warehouser(11)  
> - Water Carrier(14)  
> - Weapon Dealer(11)  
> - Weapon Dealer(11)  
> - Weaponsmith(4)  
> - Weaponsmith(4)  
> - Weaver(10)  
> - Wheelwright(11)  
> - Wheelwright(15)  
> - Wine Merchant(6)  
> - Wood Carver(6)  
> - Wood Seller(5)  
> - Wool Merchant(9)  
> - Writer(11)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



