---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (19397)
terrain: Desert Cactus 
settlementDescription: 
population: 19397
culture: Incan 
technology: Roman 
leader: 
govermentType: Plutocracy 
demographics: 
- Acrobat(33) 
- Minstrel(33) 
- Storyteller(33) 
- Troubadours(33) 
- Writer(33) 
- Advocate(25) 
- Clerk(56) 
- Council Member(49) 
- Diplomat(8) 
- Judge(28) 
- Mayor(1) 
- Alchemist(17) 
- Chandler(49) 
- Dye Makers(49) 
- Florist(17) 
- Herbalist(17) 
- Potionmakers(17) 
- Sage(9) 
- Spice Merchant(33) 
- Taxidermist(33) 
- Tobacco Merchant(33) 
- Animal Groomer(13) 
- Animal Handler(33) 
- Caravanner(25) 
- Horse Trader(39) 
- Livestock Merchant(26) 
- Stabler(35) 
- Antiquities(33) 
- Armor Dealer(33) 
- Launderer(33) 
- Oil Trader(49) 
- Trading Post(49) 
- Slaver(33) 
- Spice Merchant(33) 
- Taxidermist(33) 
- Tobacco Merchant(33) 
- Warehouser(33) 
- Weapon Dealer(33) 
- Architect(39) 
- Bricklayer(39) 
- Engineer(39) 
- Laborer(39) 
- Mason(39) 
- Painter(Building)(39) 
- Plasterer(39) 
- Roofer(39) 
- Teamster(39) 
- Tiler(39) 
- Armorer(11) 
- Blacksmith(46) 
- Bowyer-Fletcher(16) 
- Jeweler(13) 
- Silversmith(12) 
- Weapon Dealer(33) 
- Weaponsmith(10) 
- Artist(44) 
- Glassblower(33) 
- Goldsmith(22) 
- Inventor(28) 
- Jeweler(20) 
- Magical Artisan(9) 
- Painter(Art)(36) 
- Silversmith(28) 
- Tinker(49) 
- Toymaker(15) 
- Astrologist(9) 
- Conjourer(9) 
- High Mage(9) 
- Historian(9) 
- Librarian(9) 
- Magical Artisan(9) 
- Magical Tutor(9) 
- Professor(9) 
- Scribe(9) 
- SellSpell(9) 
- Teacher(9) 
- Tutor(9) 
- Baker(30) 
- Beer Merchant(18) 
- Brewer(5) 
- Butcher(20) 
- Chicken Butcher(20) 
- Cook(21) 
- Dairy Seller(97) 
- Distiller(18) 
- Hay Merchant(97) 
- Fisherman(25) 
- Fishmonger(25) 
- Grain Merchant(5) 
- Grocer(15) 
- Meat Butcher(17) 
- Miller(49) 
- Pastry Maker(25) 
- Vintner(21) 
- Banker(11) 
- Pawnbroker(11) 
- Barbarian(97) 
- Brigand(97) 
- Captain(97) 
- Mountainman(97) 
- Barbarian(18) 
- Cartographer(17) 
- Guide(33) 
- Huntsman(49) 
- Mountainman(15) 
- Pathfinder(17) 
- Scout(17) 
- Slaver(33) 
- Barrel Maker(21) 
- Basket Maker(28) 
- Book Binder(10) 
- Bookseller(10) 
- Buckle Maker(15) 
- Candle Maker(13) 
- Clock Maker(9) 
- Cobbler(30) 
- Cooper(23) 
- Cutler(10) 
- Engraver(9) 
- Furniture Maker(30) 
- Glassblower(14) 
- Glazier(10) 
- Glove Merchant(26) 
- Goldsmith(14) 
- Harness Maker(33) 
- Hat Maker(13) 
- Instrument Maker(9) 
- Kettle Maker(9) 
- Locksmith(12) 
- Perfumer(14) 
- Potter(33) 
- Rope Maker(23) 
- Rug Maker(12) 
- Saddler(25) 
- Sculptor(9) 
- Shoe Maker(23) 
- Soap Maker(17) 
- Tanner(25) 
- Tinker(11) 
- Toymaker(9) 
- Weaponsmith(10) 
- Weaver(28) 
- Wheelwright(44) 
- Wine Merchant(17) 
- Wool Merchant(25) 
- Lord(7) 
- Knight(7) 
- Baron(4) 
- Viscount(3) 
- Earl(2) 
- Count(2) 
- Duke(1) 
- Barrel Maker(36) 
- Bowyer-Fletcher(16) 
- Carpenter(56) 
- Roofer(39) 
- Wagon Maker(28) 
- Wheelwright(30) 
- Wood Carver(16) 
- Wood Seller(15) 
- Barber(17) 
- Bleacher(17) 
- Physic/Chirurgeon(17) 
- Bather(13) 
- Brigand(33) 
- Crime Lord(8) 
- Crook(39) 
- Goon(44) 
- Brothel Keeper(14) 
- Innkeeper(26) 
- Tavern Keeper(36) 
- Buckle Maker(26) 
- Cobbler(23) 
- Draper(16) 
- Furrier(44) 
- Girdler(15) 
- Haberdasher(13) 
- Launderer(26) 
- Leatherworker(18) 
- Purse Maker(17) 
- Shoe Maker(23) 
- Tailor(26) 
- Tanner(25) 
- Used Garment Trader(41) 
- Vestment Maker(23) 
- Chandler(49) 
- Dye Makers(49) 
- Oil Trader(49) 
- Cleric(36) 
- High Priest(14) 
- Missionary(130) 
- Preacher(78) 
- Priest(44) 
- Farmer(970) 
- Homestead(1294) 
- Farmer - Cabbage(97) 
- Farmer - Cattle Herder(97) 
- Farmer - Corn(97) 
- Farmer - Cow Herder(97) 
- Farmer - Dairy(97) 
- Farmer - Goat Herder(97) 
- Farmer - Pig Herder(97) 
- Farmer - Potato(97) 
- Farmer - Sheep Herder(97) 
- Farmer - Wheat(97) 
- Farmer(Special)(97) 
- Dungsweeper(28) 
- Illuminator(20) 
- Messenger(30) 
- Tax Collector(5) 
- Town Crier(56) 
- Town Justice(13) 
- Undertaker(11) 
- Water Carrier(39) 
- Leatherworker(20) 
- Skinner(20) 
- Naval Outfitter(10) 
- Pirate(49) 
- Sail Maker(28) 
- Sailor(65) 
- Ship Builder(12) 
imports: 
- Glass  
exports: 
- Lumber  
defenses: Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(33)  
> - Advocate(25)  
> - Alchemist(17)  
> - Animal Groomer(13)  
> - Animal Handler(33)  
> - Antiquities(33)  
> - Architect(39)  
> - Armor Dealer(33)  
> - Armorer(11)  
> - Artist(44)  
> - Astrologist(9)  
> - Baker(30)  
> - Banker(11)  
> - Barbarian(18)  
> - Barbarian(97)  
> - Barber(17)  
> - Baron(4)  
> - Barrel Maker(21)  
> - Barrel Maker(36)  
> - Basket Maker(28)  
> - Bather(13)  
> - Beer Merchant(18)  
> - Blacksmith(46)  
> - Bleacher(17)  
> - Book Binder(10)  
> - Bookseller(10)  
> - Bowyer-Fletcher(16)  
> - Bowyer-Fletcher(16)  
> - Brewer(5)  
> - Bricklayer(39)  
> - Brigand(33)  
> - Brigand(97)  
> - Brothel Keeper(14)  
> - Buckle Maker(15)  
> - Buckle Maker(26)  
> - Butcher(20)  
> - Candle Maker(13)  
> - Captain(97)  
> - Caravanner(25)  
> - Carpenter(56)  
> - Cartographer(17)  
> - Chandler(49)  
> - Chandler(49)  
> - Chicken Butcher(20)  
> - Cleric(36)  
> - Clerk(56)  
> - Clock Maker(9)  
> - Cobbler(23)  
> - Cobbler(30)  
> - Conjourer(9)  
> - Cook(21)  
> - Cooper(23)  
> - Council Member(49)  
> - Count(2)  
> - Crime Lord(8)  
> - Crook(39)  
> - Cutler(10)  
> - Dairy Seller(97)  
> - Diplomat(8)  
> - Distiller(18)  
> - Draper(16)  
> - Duke(1)  
> - Dungsweeper(28)  
> - Dye Makers(49)  
> - Dye Makers(49)  
> - Earl(2)  
> - Engineer(39)  
> - Engraver(9)  
> - Farmer - Cabbage(97)  
> - Farmer - Cattle Herder(97)  
> - Farmer - Corn(97)  
> - Farmer - Cow Herder(97)  
> - Farmer - Dairy(97)  
> - Farmer - Goat Herder(97)  
> - Farmer - Pig Herder(97)  
> - Farmer - Potato(97)  
> - Farmer - Sheep Herder(97)  
> - Farmer - Wheat(97)  
> - Farmer(970)  
> - Farmer(Special)(97)  
> - Fisherman(25)  
> - Fishmonger(25)  
> - Florist(17)  
> - Furniture Maker(30)  
> - Furrier(44)  
> - Girdler(15)  
> - Glassblower(14)  
> - Glassblower(33)  
> - Glazier(10)  
> - Glove Merchant(26)  
> - Goldsmith(14)  
> - Goldsmith(22)  
> - Goon(44)  
> - Grain Merchant(5)  
> - Grocer(15)  
> - Guide(33)  
> - Haberdasher(13)  
> - Harness Maker(33)  
> - Hat Maker(13)  
> - Hay Merchant(97)  
> - Herbalist(17)  
> - High Mage(9)  
> - High Priest(14)  
> - Historian(9)  
> - Homestead(1294)  
> - Horse Trader(39)  
> - Huntsman(49)  
> - Illuminator(20)  
> - Innkeeper(26)  
> - Instrument Maker(9)  
> - Inventor(28)  
> - Jeweler(13)  
> - Jeweler(20)  
> - Judge(28)  
> - Kettle Maker(9)  
> - Knight(7)  
> - Laborer(39)  
> - Launderer(26)  
> - Launderer(33)  
> - Leatherworker(18)  
> - Leatherworker(20)  
> - Librarian(9)  
> - Livestock Merchant(26)  
> - Locksmith(12)  
> - Lord(7)  
> - Magical Artisan(9)  
> - Magical Artisan(9)  
> - Magical Tutor(9)  
> - Mason(39)  
> - Mayor(1)  
> - Meat Butcher(17)  
> - Messenger(30)  
> - Miller(49)  
> - Minstrel(33)  
> - Missionary(130)  
> - Mountainman(15)  
> - Mountainman(97)  
> - Naval Outfitter(10)  
> - Oil Trader(49)  
> - Oil Trader(49)  
> - Painter(Art)(36)  
> - Painter(Building)(39)  
> - Pastry Maker(25)  
> - Pathfinder(17)  
> - Pawnbroker(11)  
> - Perfumer(14)  
> - Physic/Chirurgeon(17)  
> - Pirate(49)  
> - Plasterer(39)  
> - Potionmakers(17)  
> - Potter(33)  
> - Preacher(78)  
> - Priest(44)  
> - Professor(9)  
> - Purse Maker(17)  
> - Roofer(39)  
> - Roofer(39)  
> - Rope Maker(23)  
> - Rug Maker(12)  
> - Saddler(25)  
> - Sage(9)  
> - Sail Maker(28)  
> - Sailor(65)  
> - Scout(17)  
> - Scribe(9)  
> - Sculptor(9)  
> - SellSpell(9)  
> - Ship Builder(12)  
> - Shoe Maker(23)  
> - Shoe Maker(23)  
> - Silversmith(12)  
> - Silversmith(28)  
> - Skinner(20)  
> - Slaver(33)  
> - Slaver(33)  
> - Soap Maker(17)  
> - Spice Merchant(33)  
> - Spice Merchant(33)  
> - Stabler(35)  
> - Storyteller(33)  
> - Tailor(26)  
> - Tanner(25)  
> - Tanner(25)  
> - Tavern Keeper(36)  
> - Tax Collector(5)  
> - Taxidermist(33)  
> - Taxidermist(33)  
> - Teacher(9)  
> - Teamster(39)  
> - Tiler(39)  
> - Tinker(11)  
> - Tinker(49)  
> - Tobacco Merchant(33)  
> - Tobacco Merchant(33)  
> - Town Crier(56)  
> - Town Justice(13)  
> - Toymaker(15)  
> - Toymaker(9)  
> - Trading Post(49)  
> - Troubadours(33)  
> - Tutor(9)  
> - Undertaker(11)  
> - Used Garment Trader(41)  
> - Vestment Maker(23)  
> - Vintner(21)  
> - Viscount(3)  
> - Wagon Maker(28)  
> - Warehouser(33)  
> - Water Carrier(39)  
> - Weapon Dealer(33)  
> - Weapon Dealer(33)  
> - Weaponsmith(10)  
> - Weaponsmith(10)  
> - Weaver(28)  
> - Wheelwright(30)  
> - Wheelwright(44)  
> - Wine Merchant(17)  
> - Wood Carver(16)  
> - Wood Seller(15)  
> - Wool Merchant(25)  
> - Writer(33)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(33)  
> - Advocate(25)  
> - Alchemist(17)  
> - Animal Groomer(13)  
> - Animal Handler(33)  
> - Antiquities(33)  
> - Architect(39)  
> - Armor Dealer(33)  
> - Armorer(11)  
> - Artist(44)  
> - Astrologist(9)  
> - Baker(30)  
> - Banker(11)  
> - Barbarian(18)  
> - Barbarian(97)  
> - Barber(17)  
> - Baron(4)  
> - Barrel Maker(21)  
> - Barrel Maker(36)  
> - Basket Maker(28)  
> - Bather(13)  
> - Beer Merchant(18)  
> - Blacksmith(46)  
> - Bleacher(17)  
> - Book Binder(10)  
> - Bookseller(10)  
> - Bowyer-Fletcher(16)  
> - Bowyer-Fletcher(16)  
> - Brewer(5)  
> - Bricklayer(39)  
> - Brigand(33)  
> - Brigand(97)  
> - Brothel Keeper(14)  
> - Buckle Maker(15)  
> - Buckle Maker(26)  
> - Butcher(20)  
> - Candle Maker(13)  
> - Captain(97)  
> - Caravanner(25)  
> - Carpenter(56)  
> - Cartographer(17)  
> - Chandler(49)  
> - Chandler(49)  
> - Chicken Butcher(20)  
> - Cleric(36)  
> - Clerk(56)  
> - Clock Maker(9)  
> - Cobbler(23)  
> - Cobbler(30)  
> - Conjourer(9)  
> - Cook(21)  
> - Cooper(23)  
> - Council Member(49)  
> - Count(2)  
> - Crime Lord(8)  
> - Crook(39)  
> - Cutler(10)  
> - Dairy Seller(97)  
> - Diplomat(8)  
> - Distiller(18)  
> - Draper(16)  
> - Duke(1)  
> - Dungsweeper(28)  
> - Dye Makers(49)  
> - Dye Makers(49)  
> - Earl(2)  
> - Engineer(39)  
> - Engraver(9)  
> - Farmer - Cabbage(97)  
> - Farmer - Cattle Herder(97)  
> - Farmer - Corn(97)  
> - Farmer - Cow Herder(97)  
> - Farmer - Dairy(97)  
> - Farmer - Goat Herder(97)  
> - Farmer - Pig Herder(97)  
> - Farmer - Potato(97)  
> - Farmer - Sheep Herder(97)  
> - Farmer - Wheat(97)  
> - Farmer(970)  
> - Farmer(Special)(97)  
> - Fisherman(25)  
> - Fishmonger(25)  
> - Florist(17)  
> - Furniture Maker(30)  
> - Furrier(44)  
> - Girdler(15)  
> - Glassblower(14)  
> - Glassblower(33)  
> - Glazier(10)  
> - Glove Merchant(26)  
> - Goldsmith(14)  
> - Goldsmith(22)  
> - Goon(44)  
> - Grain Merchant(5)  
> - Grocer(15)  
> - Guide(33)  
> - Haberdasher(13)  
> - Harness Maker(33)  
> - Hat Maker(13)  
> - Hay Merchant(97)  
> - Herbalist(17)  
> - High Mage(9)  
> - High Priest(14)  
> - Historian(9)  
> - Homestead(1294)  
> - Horse Trader(39)  
> - Huntsman(49)  
> - Illuminator(20)  
> - Innkeeper(26)  
> - Instrument Maker(9)  
> - Inventor(28)  
> - Jeweler(13)  
> - Jeweler(20)  
> - Judge(28)  
> - Kettle Maker(9)  
> - Knight(7)  
> - Laborer(39)  
> - Launderer(26)  
> - Launderer(33)  
> - Leatherworker(18)  
> - Leatherworker(20)  
> - Librarian(9)  
> - Livestock Merchant(26)  
> - Locksmith(12)  
> - Lord(7)  
> - Magical Artisan(9)  
> - Magical Artisan(9)  
> - Magical Tutor(9)  
> - Mason(39)  
> - Mayor(1)  
> - Meat Butcher(17)  
> - Messenger(30)  
> - Miller(49)  
> - Minstrel(33)  
> - Missionary(130)  
> - Mountainman(15)  
> - Mountainman(97)  
> - Naval Outfitter(10)  
> - Oil Trader(49)  
> - Oil Trader(49)  
> - Painter(Art)(36)  
> - Painter(Building)(39)  
> - Pastry Maker(25)  
> - Pathfinder(17)  
> - Pawnbroker(11)  
> - Perfumer(14)  
> - Physic/Chirurgeon(17)  
> - Pirate(49)  
> - Plasterer(39)  
> - Potionmakers(17)  
> - Potter(33)  
> - Preacher(78)  
> - Priest(44)  
> - Professor(9)  
> - Purse Maker(17)  
> - Roofer(39)  
> - Roofer(39)  
> - Rope Maker(23)  
> - Rug Maker(12)  
> - Saddler(25)  
> - Sage(9)  
> - Sail Maker(28)  
> - Sailor(65)  
> - Scout(17)  
> - Scribe(9)  
> - Sculptor(9)  
> - SellSpell(9)  
> - Ship Builder(12)  
> - Shoe Maker(23)  
> - Shoe Maker(23)  
> - Silversmith(12)  
> - Silversmith(28)  
> - Skinner(20)  
> - Slaver(33)  
> - Slaver(33)  
> - Soap Maker(17)  
> - Spice Merchant(33)  
> - Spice Merchant(33)  
> - Stabler(35)  
> - Storyteller(33)  
> - Tailor(26)  
> - Tanner(25)  
> - Tanner(25)  
> - Tavern Keeper(36)  
> - Tax Collector(5)  
> - Taxidermist(33)  
> - Taxidermist(33)  
> - Teacher(9)  
> - Teamster(39)  
> - Tiler(39)  
> - Tinker(11)  
> - Tinker(49)  
> - Tobacco Merchant(33)  
> - Tobacco Merchant(33)  
> - Town Crier(56)  
> - Town Justice(13)  
> - Toymaker(15)  
> - Toymaker(9)  
> - Trading Post(49)  
> - Troubadours(33)  
> - Tutor(9)  
> - Undertaker(11)  
> - Used Garment Trader(41)  
> - Vestment Maker(23)  
> - Vintner(21)  
> - Viscount(3)  
> - Wagon Maker(28)  
> - Warehouser(33)  
> - Water Carrier(39)  
> - Weapon Dealer(33)  
> - Weapon Dealer(33)  
> - Weaponsmith(10)  
> - Weaponsmith(10)  
> - Weaver(28)  
> - Wheelwright(30)  
> - Wheelwright(44)  
> - Wine Merchant(17)  
> - Wood Carver(16)  
> - Wood Seller(15)  
> - Wool Merchant(25)  
> - Writer(33)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



