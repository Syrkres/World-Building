---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeTown
kingdom: KingdomName
region: RegionName
settlementName: Named LargeTown (4812)
terrain: Savannah Forest 
settlementDescription: 
population: 4812
culture: Roman 
technology: Bronze Age 
leader: 
govermentType: Anarchy 
demographics: 
- Acrobat(9) 
- Minstrel(9) 
- Storyteller(9) 
- Troubadours(9) 
- Writer(9) 
- Advocate(7) 
- Clerk(14) 
- Council Member(13) 
- Diplomat(2) 
- Judge(7) 
- Mayor(1) 
- Alchemist(5) 
- Chandler(13) 
- Dye Makers(13) 
- Florist(5) 
- Herbalist(5) 
- Potionmakers(5) 
- Sage(3) 
- Spice Merchant(9) 
- Taxidermist(9) 
- Tobacco Merchant(9) 
- Animal Groomer(4) 
- Animal Handler(9) 
- Caravanner(7) 
- Horse Trader(10) 
- Livestock Merchant(7) 
- Stabler(9) 
- Antiquities(9) 
- Armor Dealer(9) 
- Launderer(9) 
- Oil Trader(13) 
- Trading Post(13) 
- Slaver(9) 
- Spice Merchant(9) 
- Taxidermist(9) 
- Tobacco Merchant(9) 
- Warehouser(9) 
- Weapon Dealer(9) 
- Architect(10) 
- Bricklayer(10) 
- Engineer(10) 
- Laborer(10) 
- Mason(10) 
- Painter(Building)(10) 
- Plasterer(10) 
- Roofer(10) 
- Teamster(10) 
- Tiler(10) 
- Armorer(3) 
- Blacksmith(12) 
- Bowyer-Fletcher(4) 
- Jeweler(4) 
- Silversmith(3) 
- Weapon Dealer(9) 
- Weaponsmith(3) 
- Artist(11) 
- Glassblower(9) 
- Goldsmith(6) 
- Inventor(7) 
- Jeweler(5) 
- Magical Artisan(3) 
- Painter(Art)(9) 
- Silversmith(7) 
- Tinker(13) 
- Toymaker(4) 
- Astrologist(3) 
- Conjourer(3) 
- High Mage(3) 
- Historian(3) 
- Librarian(3) 
- Magical Artisan(3) 
- Magical Tutor(3) 
- Professor(3) 
- Scribe(3) 
- SellSpell(3) 
- Teacher(3) 
- Tutor(3) 
- Baker(8) 
- Beer Merchant(5) 
- Brewer(1) 
- Butcher(5) 
- Chicken Butcher(5) 
- Cook(6) 
- Dairy Seller(25) 
- Distiller(5) 
- Hay Merchant(25) 
- Fisherman(7) 
- Fishmonger(7) 
- Grain Merchant(1) 
- Grocer(4) 
- Meat Butcher(5) 
- Miller(13) 
- Pastry Maker(7) 
- Vintner(6) 
- Banker(3) 
- Pawnbroker(3) 
- Barbarian(25) 
- Brigand(25) 
- Captain(25) 
- Mountainman(25) 
- Barbarian(5) 
- Cartographer(5) 
- Guide(9) 
- Huntsman(13) 
- Mountainman(4) 
- Pathfinder(5) 
- Scout(5) 
- Slaver(9) 
- Barrel Maker(6) 
- Basket Maker(7) 
- Book Binder(3) 
- Bookseller(3) 
- Buckle Maker(4) 
- Candle Maker(4) 
- Clock Maker(3) 
- Cobbler(8) 
- Cooper(6) 
- Cutler(3) 
- Engraver(3) 
- Furniture Maker(8) 
- Glassblower(4) 
- Glazier(3) 
- Glove Merchant(7) 
- Goldsmith(4) 
- Harness Maker(9) 
- Hat Maker(4) 
- Instrument Maker(3) 
- Kettle Maker(3) 
- Locksmith(3) 
- Perfumer(4) 
- Potter(9) 
- Rope Maker(6) 
- Rug Maker(3) 
- Saddler(7) 
- Sculptor(3) 
- Shoe Maker(6) 
- Soap Maker(5) 
- Tanner(7) 
- Tinker(3) 
- Toymaker(3) 
- Weaponsmith(3) 
- Weaver(7) 
- Wheelwright(11) 
- Wine Merchant(5) 
- Wool Merchant(7) 
- Lord(2) 
- Knight(2) 
- Baron(1) 
- Barrel Maker(9) 
- Bowyer-Fletcher(4) 
- Carpenter(14) 
- Roofer(10) 
- Wagon Maker(7) 
- Wheelwright(8) 
- Wood Carver(4) 
- Wood Seller(4) 
- Barber(5) 
- Bleacher(5) 
- Physic/Chirurgeon(5) 
- Bather(4) 
- Brigand(9) 
- Crime Lord(2) 
- Crook(10) 
- Goon(11) 
- Brothel Keeper(4) 
- Innkeeper(7) 
- Tavern Keeper(9) 
- Buckle Maker(7) 
- Cobbler(6) 
- Draper(4) 
- Furrier(11) 
- Girdler(4) 
- Haberdasher(4) 
- Launderer(7) 
- Leatherworker(5) 
- Purse Maker(5) 
- Shoe Maker(6) 
- Tailor(7) 
- Tanner(7) 
- Used Garment Trader(11) 
- Vestment Maker(6) 
- Chandler(13) 
- Dye Makers(13) 
- Oil Trader(13) 
- Cleric(9) 
- High Priest(4) 
- Missionary(33) 
- Preacher(20) 
- Priest(11) 
- Farmer(241) 
- Homestead(321) 
- Farmer - Cabbage(25) 
- Farmer - Cattle Herder(25) 
- Farmer - Corn(25) 
- Farmer - Cow Herder(25) 
- Farmer - Dairy(25) 
- Farmer - Goat Herder(25) 
- Farmer - Pig Herder(25) 
- Farmer - Potato(25) 
- Farmer - Sheep Herder(25) 
- Farmer - Wheat(25) 
- Farmer(Special)(25) 
- Dungsweeper(7) 
- Illuminator(5) 
- Messenger(8) 
- Tax Collector(1) 
- Town Crier(14) 
- Town Justice(4) 
- Undertaker(3) 
- Water Carrier(10) 
- Leatherworker(5) 
- Skinner(5) 
- Naval Outfitter(3) 
- Pirate(13) 
- Sail Maker(7) 
- Sailor(17) 
- Ship Builder(3) 
imports: 
- Metals  
exports: 
- Grain  
defenses: Killing Fields 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(9)  
> - Advocate(7)  
> - Alchemist(5)  
> - Animal Groomer(4)  
> - Animal Handler(9)  
> - Antiquities(9)  
> - Architect(10)  
> - Armor Dealer(9)  
> - Armorer(3)  
> - Artist(11)  
> - Astrologist(3)  
> - Baker(8)  
> - Banker(3)  
> - Barbarian(25)  
> - Barbarian(5)  
> - Barber(5)  
> - Baron(1)  
> - Barrel Maker(6)  
> - Barrel Maker(9)  
> - Basket Maker(7)  
> - Bather(4)  
> - Beer Merchant(5)  
> - Blacksmith(12)  
> - Bleacher(5)  
> - Book Binder(3)  
> - Bookseller(3)  
> - Bowyer-Fletcher(4)  
> - Bowyer-Fletcher(4)  
> - Brewer(1)  
> - Bricklayer(10)  
> - Brigand(25)  
> - Brigand(9)  
> - Brothel Keeper(4)  
> - Buckle Maker(4)  
> - Buckle Maker(7)  
> - Butcher(5)  
> - Candle Maker(4)  
> - Captain(25)  
> - Caravanner(7)  
> - Carpenter(14)  
> - Cartographer(5)  
> - Chandler(13)  
> - Chandler(13)  
> - Chicken Butcher(5)  
> - Cleric(9)  
> - Clerk(14)  
> - Clock Maker(3)  
> - Cobbler(6)  
> - Cobbler(8)  
> - Conjourer(3)  
> - Cook(6)  
> - Cooper(6)  
> - Council Member(13)  
> - Crime Lord(2)  
> - Crook(10)  
> - Cutler(3)  
> - Dairy Seller(25)  
> - Diplomat(2)  
> - Distiller(5)  
> - Draper(4)  
> - Dungsweeper(7)  
> - Dye Makers(13)  
> - Dye Makers(13)  
> - Engineer(10)  
> - Engraver(3)  
> - Farmer - Cabbage(25)  
> - Farmer - Cattle Herder(25)  
> - Farmer - Corn(25)  
> - Farmer - Cow Herder(25)  
> - Farmer - Dairy(25)  
> - Farmer - Goat Herder(25)  
> - Farmer - Pig Herder(25)  
> - Farmer - Potato(25)  
> - Farmer - Sheep Herder(25)  
> - Farmer - Wheat(25)  
> - Farmer(241)  
> - Farmer(Special)(25)  
> - Fisherman(7)  
> - Fishmonger(7)  
> - Florist(5)  
> - Furniture Maker(8)  
> - Furrier(11)  
> - Girdler(4)  
> - Glassblower(4)  
> - Glassblower(9)  
> - Glazier(3)  
> - Glove Merchant(7)  
> - Goldsmith(4)  
> - Goldsmith(6)  
> - Goon(11)  
> - Grain Merchant(1)  
> - Grocer(4)  
> - Guide(9)  
> - Haberdasher(4)  
> - Harness Maker(9)  
> - Hat Maker(4)  
> - Hay Merchant(25)  
> - Herbalist(5)  
> - High Mage(3)  
> - High Priest(4)  
> - Historian(3)  
> - Homestead(321)  
> - Horse Trader(10)  
> - Huntsman(13)  
> - Illuminator(5)  
> - Innkeeper(7)  
> - Instrument Maker(3)  
> - Inventor(7)  
> - Jeweler(4)  
> - Jeweler(5)  
> - Judge(7)  
> - Kettle Maker(3)  
> - Knight(2)  
> - Laborer(10)  
> - Launderer(7)  
> - Launderer(9)  
> - Leatherworker(5)  
> - Leatherworker(5)  
> - Librarian(3)  
> - Livestock Merchant(7)  
> - Locksmith(3)  
> - Lord(2)  
> - Magical Artisan(3)  
> - Magical Artisan(3)  
> - Magical Tutor(3)  
> - Mason(10)  
> - Mayor(1)  
> - Meat Butcher(5)  
> - Messenger(8)  
> - Miller(13)  
> - Minstrel(9)  
> - Missionary(33)  
> - Mountainman(25)  
> - Mountainman(4)  
> - Naval Outfitter(3)  
> - Oil Trader(13)  
> - Oil Trader(13)  
> - Painter(Art)(9)  
> - Painter(Building)(10)  
> - Pastry Maker(7)  
> - Pathfinder(5)  
> - Pawnbroker(3)  
> - Perfumer(4)  
> - Physic/Chirurgeon(5)  
> - Pirate(13)  
> - Plasterer(10)  
> - Potionmakers(5)  
> - Potter(9)  
> - Preacher(20)  
> - Priest(11)  
> - Professor(3)  
> - Purse Maker(5)  
> - Roofer(10)  
> - Roofer(10)  
> - Rope Maker(6)  
> - Rug Maker(3)  
> - Saddler(7)  
> - Sage(3)  
> - Sail Maker(7)  
> - Sailor(17)  
> - Scout(5)  
> - Scribe(3)  
> - Sculptor(3)  
> - SellSpell(3)  
> - Ship Builder(3)  
> - Shoe Maker(6)  
> - Shoe Maker(6)  
> - Silversmith(3)  
> - Silversmith(7)  
> - Skinner(5)  
> - Slaver(9)  
> - Slaver(9)  
> - Soap Maker(5)  
> - Spice Merchant(9)  
> - Spice Merchant(9)  
> - Stabler(9)  
> - Storyteller(9)  
> - Tailor(7)  
> - Tanner(7)  
> - Tanner(7)  
> - Tavern Keeper(9)  
> - Tax Collector(1)  
> - Taxidermist(9)  
> - Taxidermist(9)  
> - Teacher(3)  
> - Teamster(10)  
> - Tiler(10)  
> - Tinker(13)  
> - Tinker(3)  
> - Tobacco Merchant(9)  
> - Tobacco Merchant(9)  
> - Town Crier(14)  
> - Town Justice(4)  
> - Toymaker(3)  
> - Toymaker(4)  
> - Trading Post(13)  
> - Troubadours(9)  
> - Tutor(3)  
> - Undertaker(3)  
> - Used Garment Trader(11)  
> - Vestment Maker(6)  
> - Vintner(6)  
> - Wagon Maker(7)  
> - Warehouser(9)  
> - Water Carrier(10)  
> - Weapon Dealer(9)  
> - Weapon Dealer(9)  
> - Weaponsmith(3)  
> - Weaponsmith(3)  
> - Weaver(7)  
> - Wheelwright(11)  
> - Wheelwright(8)  
> - Wine Merchant(5)  
> - Wood Carver(4)  
> - Wood Seller(4)  
> - Wool Merchant(7)  
> - Writer(9)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(9)  
> - Advocate(7)  
> - Alchemist(5)  
> - Animal Groomer(4)  
> - Animal Handler(9)  
> - Antiquities(9)  
> - Architect(10)  
> - Armor Dealer(9)  
> - Armorer(3)  
> - Artist(11)  
> - Astrologist(3)  
> - Baker(8)  
> - Banker(3)  
> - Barbarian(25)  
> - Barbarian(5)  
> - Barber(5)  
> - Baron(1)  
> - Barrel Maker(6)  
> - Barrel Maker(9)  
> - Basket Maker(7)  
> - Bather(4)  
> - Beer Merchant(5)  
> - Blacksmith(12)  
> - Bleacher(5)  
> - Book Binder(3)  
> - Bookseller(3)  
> - Bowyer-Fletcher(4)  
> - Bowyer-Fletcher(4)  
> - Brewer(1)  
> - Bricklayer(10)  
> - Brigand(25)  
> - Brigand(9)  
> - Brothel Keeper(4)  
> - Buckle Maker(4)  
> - Buckle Maker(7)  
> - Butcher(5)  
> - Candle Maker(4)  
> - Captain(25)  
> - Caravanner(7)  
> - Carpenter(14)  
> - Cartographer(5)  
> - Chandler(13)  
> - Chandler(13)  
> - Chicken Butcher(5)  
> - Cleric(9)  
> - Clerk(14)  
> - Clock Maker(3)  
> - Cobbler(6)  
> - Cobbler(8)  
> - Conjourer(3)  
> - Cook(6)  
> - Cooper(6)  
> - Council Member(13)  
> - Crime Lord(2)  
> - Crook(10)  
> - Cutler(3)  
> - Dairy Seller(25)  
> - Diplomat(2)  
> - Distiller(5)  
> - Draper(4)  
> - Dungsweeper(7)  
> - Dye Makers(13)  
> - Dye Makers(13)  
> - Engineer(10)  
> - Engraver(3)  
> - Farmer - Cabbage(25)  
> - Farmer - Cattle Herder(25)  
> - Farmer - Corn(25)  
> - Farmer - Cow Herder(25)  
> - Farmer - Dairy(25)  
> - Farmer - Goat Herder(25)  
> - Farmer - Pig Herder(25)  
> - Farmer - Potato(25)  
> - Farmer - Sheep Herder(25)  
> - Farmer - Wheat(25)  
> - Farmer(241)  
> - Farmer(Special)(25)  
> - Fisherman(7)  
> - Fishmonger(7)  
> - Florist(5)  
> - Furniture Maker(8)  
> - Furrier(11)  
> - Girdler(4)  
> - Glassblower(4)  
> - Glassblower(9)  
> - Glazier(3)  
> - Glove Merchant(7)  
> - Goldsmith(4)  
> - Goldsmith(6)  
> - Goon(11)  
> - Grain Merchant(1)  
> - Grocer(4)  
> - Guide(9)  
> - Haberdasher(4)  
> - Harness Maker(9)  
> - Hat Maker(4)  
> - Hay Merchant(25)  
> - Herbalist(5)  
> - High Mage(3)  
> - High Priest(4)  
> - Historian(3)  
> - Homestead(321)  
> - Horse Trader(10)  
> - Huntsman(13)  
> - Illuminator(5)  
> - Innkeeper(7)  
> - Instrument Maker(3)  
> - Inventor(7)  
> - Jeweler(4)  
> - Jeweler(5)  
> - Judge(7)  
> - Kettle Maker(3)  
> - Knight(2)  
> - Laborer(10)  
> - Launderer(7)  
> - Launderer(9)  
> - Leatherworker(5)  
> - Leatherworker(5)  
> - Librarian(3)  
> - Livestock Merchant(7)  
> - Locksmith(3)  
> - Lord(2)  
> - Magical Artisan(3)  
> - Magical Artisan(3)  
> - Magical Tutor(3)  
> - Mason(10)  
> - Mayor(1)  
> - Meat Butcher(5)  
> - Messenger(8)  
> - Miller(13)  
> - Minstrel(9)  
> - Missionary(33)  
> - Mountainman(25)  
> - Mountainman(4)  
> - Naval Outfitter(3)  
> - Oil Trader(13)  
> - Oil Trader(13)  
> - Painter(Art)(9)  
> - Painter(Building)(10)  
> - Pastry Maker(7)  
> - Pathfinder(5)  
> - Pawnbroker(3)  
> - Perfumer(4)  
> - Physic/Chirurgeon(5)  
> - Pirate(13)  
> - Plasterer(10)  
> - Potionmakers(5)  
> - Potter(9)  
> - Preacher(20)  
> - Priest(11)  
> - Professor(3)  
> - Purse Maker(5)  
> - Roofer(10)  
> - Roofer(10)  
> - Rope Maker(6)  
> - Rug Maker(3)  
> - Saddler(7)  
> - Sage(3)  
> - Sail Maker(7)  
> - Sailor(17)  
> - Scout(5)  
> - Scribe(3)  
> - Sculptor(3)  
> - SellSpell(3)  
> - Ship Builder(3)  
> - Shoe Maker(6)  
> - Shoe Maker(6)  
> - Silversmith(3)  
> - Silversmith(7)  
> - Skinner(5)  
> - Slaver(9)  
> - Slaver(9)  
> - Soap Maker(5)  
> - Spice Merchant(9)  
> - Spice Merchant(9)  
> - Stabler(9)  
> - Storyteller(9)  
> - Tailor(7)  
> - Tanner(7)  
> - Tanner(7)  
> - Tavern Keeper(9)  
> - Tax Collector(1)  
> - Taxidermist(9)  
> - Taxidermist(9)  
> - Teacher(3)  
> - Teamster(10)  
> - Tiler(10)  
> - Tinker(13)  
> - Tinker(3)  
> - Tobacco Merchant(9)  
> - Tobacco Merchant(9)  
> - Town Crier(14)  
> - Town Justice(4)  
> - Toymaker(3)  
> - Toymaker(4)  
> - Trading Post(13)  
> - Troubadours(9)  
> - Tutor(3)  
> - Undertaker(3)  
> - Used Garment Trader(11)  
> - Vestment Maker(6)  
> - Vintner(6)  
> - Wagon Maker(7)  
> - Warehouser(9)  
> - Water Carrier(10)  
> - Weapon Dealer(9)  
> - Weapon Dealer(9)  
> - Weaponsmith(3)  
> - Weaponsmith(3)  
> - Weaver(7)  
> - Wheelwright(11)  
> - Wheelwright(8)  
> - Wine Merchant(5)  
> - Wood Carver(4)  
> - Wood Seller(4)  
> - Wool Merchant(7)  
> - Writer(9)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



