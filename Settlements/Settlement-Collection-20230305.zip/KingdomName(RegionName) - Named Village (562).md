---
cssclass: oRPGPage
fileType: settlement
settlementType: Village
kingdom: KingdomName
region: RegionName
settlementName: Named Village (562)
terrain: Moutain 
settlementDescription: 
population: 562
culture: Oriental 
technology: Crusades 
leader: 
govermentType: Monarchy 
demographics: 
- Advocate(1) 
- Clerk(2) 
- Council Member(1) 
- Judge(1) 
- Mayor(1) 
- Chandler(1) 
- Dye Makers(1) 
- Animal Handler(1) 
- Caravanner(1) 
- Horse Trader(1) 
- Stabler(2) 
- Oil Trader(1) 
- Trading Post(2) 
- Architect(1) 
- Bricklayer(1) 
- Engineer(1) 
- Laborer(1) 
- Mason(1) 
- Painter(Building)(1) 
- Plasterer(1) 
- Roofer(1) 
- Teamster(1) 
- Tiler(1) 
- Blacksmith(2) 
- Artist(1) 
- Glassblower(1) 
- Inventor(1) 
- Painter(Art)(1) 
- Tinker(2) 
- Miller(1) 
- Barbarian(3) 
- Brigand(3) 
- Captain(3) 
- Mountainman(3) 
- Barbarian(1) 
- Guide(1) 
- Huntsman(1) 
- Barrel Maker(1) 
- Cobbler(1) 
- Cooper(1) 
- Harness Maker(1) 
- Potter(1) 
- Wheelwright(1) 
- Wool Merchant(1) 
- Barrel Maker(2) 
- Carpenter(1) 
- Roofer(1) 
- Wheelwright(1) 
- Brigand(1) 
- Crook(2) 
- Goon(2) 
- Innkeeper(1) 
- Tavern Keeper(2) 
- Buckle Maker(1) 
- Cobbler(1) 
- Draper(1) 
- Furrier(2) 
- Launderer(1) 
- Leatherworker(1) 
- Shoe Maker(1) 
- Tailor(1) 
- Tanner(1) 
- Used Garment Trader(2) 
- Chandler(1) 
- Dye Makers(1) 
- Oil Trader(1) 
- Cleric(1) 
- Missionary(4) 
- Preacher(3) 
- Priest(1) 
- Farmer(29) 
- Homestead(38) 
- Farmer - Cabbage(1) 
- Farmer - Cattle Herder(1) 
- Farmer - Corn(3) 
- Farmer - Cow Herder(3) 
- Farmer - Dairy(1) 
- Farmer - Goat Herder(3) 
- Farmer - Pig Herder(3) 
- Farmer - Potato(3) 
- Farmer - Sheep Herder(3) 
- Farmer - Wheat(3) 
- Farmer(Special)(1) 
- Dungsweeper(1) 
- Messenger(1) 
- Town Crier(1) 
- Town Justice(1) 
- Water Carrier(1) 
- Pirate(2) 
- Sail Maker(1) 
- Sailor(2) 
imports: 
- Bamboo  
exports: 
- Cotton  
defenses: Wood Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Advocate(1)  
> - Animal Handler(1)  
> - Architect(1)  
> - Artist(1)  
> - Barbarian(1)  
> - Barbarian(3)  
> - Barrel Maker(1)  
> - Barrel Maker(2)  
> - Blacksmith(2)  
> - Bricklayer(1)  
> - Brigand(1)  
> - Brigand(3)  
> - Buckle Maker(1)  
> - Captain(3)  
> - Caravanner(1)  
> - Carpenter(1)  
> - Chandler(1)  
> - Chandler(1)  
> - Cleric(1)  
> - Clerk(2)  
> - Cobbler(1)  
> - Cobbler(1)  
> - Cooper(1)  
> - Council Member(1)  
> - Crook(2)  
> - Draper(1)  
> - Dungsweeper(1)  
> - Dye Makers(1)  
> - Dye Makers(1)  
> - Engineer(1)  
> - Farmer - Cabbage(1)  
> - Farmer - Cattle Herder(1)  
> - Farmer - Corn(3)  
> - Farmer - Cow Herder(3)  
> - Farmer - Dairy(1)  
> - Farmer - Goat Herder(3)  
> - Farmer - Pig Herder(3)  
> - Farmer - Potato(3)  
> - Farmer - Sheep Herder(3)  
> - Farmer - Wheat(3)  
> - Farmer(29)  
> - Farmer(Special)(1)  
> - Furrier(2)  
> - Glassblower(1)  
> - Goon(2)  
> - Guide(1)  
> - Harness Maker(1)  
> - Homestead(38)  
> - Horse Trader(1)  
> - Huntsman(1)  
> - Innkeeper(1)  
> - Inventor(1)  
> - Judge(1)  
> - Laborer(1)  
> - Launderer(1)  
> - Leatherworker(1)  
> - Mason(1)  
> - Mayor(1)  
> - Messenger(1)  
> - Miller(1)  
> - Missionary(4)  
> - Mountainman(3)  
> - Oil Trader(1)  
> - Oil Trader(1)  
> - Painter(Art)(1)  
> - Painter(Building)(1)  
> - Pirate(2)  
> - Plasterer(1)  
> - Potter(1)  
> - Preacher(3)  
> - Priest(1)  
> - Roofer(1)  
> - Roofer(1)  
> - Sail Maker(1)  
> - Sailor(2)  
> - Shoe Maker(1)  
> - Stabler(2)  
> - Tailor(1)  
> - Tanner(1)  
> - Tavern Keeper(2)  
> - Teamster(1)  
> - Tiler(1)  
> - Tinker(2)  
> - Town Crier(1)  
> - Town Justice(1)  
> - Trading Post(2)  
> - Used Garment Trader(2)  
> - Water Carrier(1)  
> - Wheelwright(1)  
> - Wheelwright(1)  
> - Wool Merchant(1)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Advocate(1)  
> - Animal Handler(1)  
> - Architect(1)  
> - Artist(1)  
> - Barbarian(1)  
> - Barbarian(3)  
> - Barrel Maker(1)  
> - Barrel Maker(2)  
> - Blacksmith(2)  
> - Bricklayer(1)  
> - Brigand(1)  
> - Brigand(3)  
> - Buckle Maker(1)  
> - Captain(3)  
> - Caravanner(1)  
> - Carpenter(1)  
> - Chandler(1)  
> - Chandler(1)  
> - Cleric(1)  
> - Clerk(2)  
> - Cobbler(1)  
> - Cobbler(1)  
> - Cooper(1)  
> - Council Member(1)  
> - Crook(2)  
> - Draper(1)  
> - Dungsweeper(1)  
> - Dye Makers(1)  
> - Dye Makers(1)  
> - Engineer(1)  
> - Farmer - Cabbage(1)  
> - Farmer - Cattle Herder(1)  
> - Farmer - Corn(3)  
> - Farmer - Cow Herder(3)  
> - Farmer - Dairy(1)  
> - Farmer - Goat Herder(3)  
> - Farmer - Pig Herder(3)  
> - Farmer - Potato(3)  
> - Farmer - Sheep Herder(3)  
> - Farmer - Wheat(3)  
> - Farmer(29)  
> - Farmer(Special)(1)  
> - Furrier(2)  
> - Glassblower(1)  
> - Goon(2)  
> - Guide(1)  
> - Harness Maker(1)  
> - Homestead(38)  
> - Horse Trader(1)  
> - Huntsman(1)  
> - Innkeeper(1)  
> - Inventor(1)  
> - Judge(1)  
> - Laborer(1)  
> - Launderer(1)  
> - Leatherworker(1)  
> - Mason(1)  
> - Mayor(1)  
> - Messenger(1)  
> - Miller(1)  
> - Missionary(4)  
> - Mountainman(3)  
> - Oil Trader(1)  
> - Oil Trader(1)  
> - Painter(Art)(1)  
> - Painter(Building)(1)  
> - Pirate(2)  
> - Plasterer(1)  
> - Potter(1)  
> - Preacher(3)  
> - Priest(1)  
> - Roofer(1)  
> - Roofer(1)  
> - Sail Maker(1)  
> - Sailor(2)  
> - Shoe Maker(1)  
> - Stabler(2)  
> - Tailor(1)  
> - Tanner(1)  
> - Tavern Keeper(2)  
> - Teamster(1)  
> - Tiler(1)  
> - Tinker(2)  
> - Town Crier(1)  
> - Town Justice(1)  
> - Trading Post(2)  
> - Used Garment Trader(2)  
> - Water Carrier(1)  
> - Wheelwright(1)  
> - Wheelwright(1)  
> - Wool Merchant(1)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



