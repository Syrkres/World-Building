---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (27347)
terrain: Forest Heavy 
settlementDescription: 
population: 27347
culture: Egyptian 
technology: Roman 
leader: 
govermentType: Anarchy 
demographics: 
- Acrobat(46) 
- Minstrel(46) 
- Storyteller(46) 
- Troubadours(46) 
- Writer(46) 
- Advocate(35) 
- Clerk(79) 
- Council Member(69) 
- Diplomat(11) 
- Judge(40) 
- Mayor(1) 
- Alchemist(23) 
- Chandler(69) 
- Dye Makers(69) 
- Florist(23) 
- Herbalist(23) 
- Potionmakers(23) 
- Sage(13) 
- Spice Merchant(46) 
- Taxidermist(46) 
- Tobacco Merchant(46) 
- Animal Groomer(19) 
- Animal Handler(46) 
- Caravanner(35) 
- Horse Trader(55) 
- Livestock Merchant(37) 
- Stabler(49) 
- Antiquities(46) 
- Armor Dealer(46) 
- Launderer(46) 
- Oil Trader(69) 
- Trading Post(69) 
- Slaver(46) 
- Spice Merchant(46) 
- Taxidermist(46) 
- Tobacco Merchant(46) 
- Warehouser(46) 
- Weapon Dealer(46) 
- Architect(55) 
- Bricklayer(55) 
- Engineer(55) 
- Laborer(55) 
- Mason(55) 
- Painter(Building)(55) 
- Plasterer(55) 
- Roofer(55) 
- Teamster(55) 
- Tiler(55) 
- Armorer(15) 
- Blacksmith(65) 
- Bowyer-Fletcher(22) 
- Jeweler(18) 
- Silversmith(17) 
- Weapon Dealer(46) 
- Weaponsmith(14) 
- Artist(61) 
- Glassblower(46) 
- Goldsmith(31) 
- Inventor(40) 
- Jeweler(28) 
- Magical Artisan(13) 
- Painter(Art)(50) 
- Silversmith(40) 
- Tinker(69) 
- Toymaker(22) 
- Astrologist(13) 
- Conjourer(13) 
- High Mage(13) 
- Historian(13) 
- Librarian(13) 
- Magical Artisan(13) 
- Magical Tutor(13) 
- Professor(13) 
- Scribe(13) 
- SellSpell(13) 
- Teacher(13) 
- Tutor(13) 
- Baker(43) 
- Beer Merchant(25) 
- Brewer(7) 
- Butcher(28) 
- Chicken Butcher(28) 
- Cook(29) 
- Dairy Seller(137) 
- Distiller(25) 
- Hay Merchant(137) 
- Fisherman(35) 
- Fishmonger(35) 
- Grain Merchant(7) 
- Grocer(21) 
- Meat Butcher(23) 
- Miller(69) 
- Pastry Maker(35) 
- Vintner(29) 
- Banker(16) 
- Pawnbroker(16) 
- Barbarian(137) 
- Brigand(137) 
- Captain(137) 
- Mountainman(137) 
- Barbarian(25) 
- Cartographer(23) 
- Guide(46) 
- Huntsman(69) 
- Mountainman(22) 
- Pathfinder(23) 
- Scout(23) 
- Slaver(46) 
- Barrel Maker(29) 
- Basket Maker(40) 
- Book Binder(14) 
- Bookseller(14) 
- Buckle Maker(22) 
- Candle Maker(18) 
- Clock Maker(13) 
- Cobbler(43) 
- Cooper(33) 
- Cutler(14) 
- Engraver(13) 
- Furniture Maker(43) 
- Glassblower(20) 
- Glazier(14) 
- Glove Merchant(37) 
- Goldsmith(20) 
- Harness Maker(46) 
- Hat Maker(19) 
- Instrument Maker(13) 
- Kettle Maker(12) 
- Locksmith(17) 
- Perfumer(19) 
- Potter(46) 
- Rope Maker(33) 
- Rug Maker(17) 
- Saddler(35) 
- Sculptor(12) 
- Shoe Maker(33) 
- Soap Maker(23) 
- Tanner(35) 
- Tinker(16) 
- Toymaker(13) 
- Weaponsmith(14) 
- Weaver(40) 
- Wheelwright(61) 
- Wine Merchant(23) 
- Wool Merchant(35) 
- Lord(10) 
- Knight(10) 
- Baron(6) 
- Viscount(4) 
- Earl(3) 
- Count(3) 
- Duke(2) 
- ArchDuke(1) 
- Barrel Maker(50) 
- Bowyer-Fletcher(22) 
- Carpenter(79) 
- Roofer(55) 
- Wagon Maker(40) 
- Wheelwright(43) 
- Wood Carver(22) 
- Wood Seller(21) 
- Barber(23) 
- Bleacher(23) 
- Physic/Chirurgeon(23) 
- Bather(19) 
- Brigand(46) 
- Crime Lord(11) 
- Crook(55) 
- Goon(61) 
- Brothel Keeper(19) 
- Innkeeper(37) 
- Tavern Keeper(50) 
- Buckle Maker(37) 
- Cobbler(33) 
- Draper(23) 
- Furrier(61) 
- Girdler(21) 
- Haberdasher(18) 
- Launderer(37) 
- Leatherworker(25) 
- Purse Maker(23) 
- Shoe Maker(33) 
- Tailor(37) 
- Tanner(35) 
- Used Garment Trader(58) 
- Vestment Maker(33) 
- Chandler(69) 
- Dye Makers(69) 
- Oil Trader(69) 
- Cleric(50) 
- High Priest(19) 
- Missionary(183) 
- Preacher(110) 
- Priest(61) 
- Farmer(1368) 
- Homestead(1824) 
- Farmer - Cabbage(137) 
- Farmer - Cattle Herder(137) 
- Farmer - Corn(137) 
- Farmer - Cow Herder(137) 
- Farmer - Dairy(137) 
- Farmer - Goat Herder(137) 
- Farmer - Pig Herder(137) 
- Farmer - Potato(137) 
- Farmer - Sheep Herder(137) 
- Farmer - Wheat(137) 
- Farmer(Special)(137) 
- Dungsweeper(39) 
- Illuminator(28) 
- Messenger(43) 
- Tax Collector(7) 
- Town Crier(79) 
- Town Justice(19) 
- Undertaker(16) 
- Water Carrier(55) 
- Leatherworker(28) 
- Skinner(28) 
- Naval Outfitter(15) 
- Pirate(69) 
- Sail Maker(40) 
- Sailor(92) 
- Ship Builder(17) 
imports: 
- Furs  
exports: 
- Tortoise Shells  
defenses: Stone Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(46)  
> - Advocate(35)  
> - Alchemist(23)  
> - Animal Groomer(19)  
> - Animal Handler(46)  
> - Antiquities(46)  
> - ArchDuke(1)  
> - Architect(55)  
> - Armor Dealer(46)  
> - Armorer(15)  
> - Artist(61)  
> - Astrologist(13)  
> - Baker(43)  
> - Banker(16)  
> - Barbarian(137)  
> - Barbarian(25)  
> - Barber(23)  
> - Baron(6)  
> - Barrel Maker(29)  
> - Barrel Maker(50)  
> - Basket Maker(40)  
> - Bather(19)  
> - Beer Merchant(25)  
> - Blacksmith(65)  
> - Bleacher(23)  
> - Book Binder(14)  
> - Bookseller(14)  
> - Bowyer-Fletcher(22)  
> - Bowyer-Fletcher(22)  
> - Brewer(7)  
> - Bricklayer(55)  
> - Brigand(137)  
> - Brigand(46)  
> - Brothel Keeper(19)  
> - Buckle Maker(22)  
> - Buckle Maker(37)  
> - Butcher(28)  
> - Candle Maker(18)  
> - Captain(137)  
> - Caravanner(35)  
> - Carpenter(79)  
> - Cartographer(23)  
> - Chandler(69)  
> - Chandler(69)  
> - Chicken Butcher(28)  
> - Cleric(50)  
> - Clerk(79)  
> - Clock Maker(13)  
> - Cobbler(33)  
> - Cobbler(43)  
> - Conjourer(13)  
> - Cook(29)  
> - Cooper(33)  
> - Council Member(69)  
> - Count(3)  
> - Crime Lord(11)  
> - Crook(55)  
> - Cutler(14)  
> - Dairy Seller(137)  
> - Diplomat(11)  
> - Distiller(25)  
> - Draper(23)  
> - Duke(2)  
> - Dungsweeper(39)  
> - Dye Makers(69)  
> - Dye Makers(69)  
> - Earl(3)  
> - Engineer(55)  
> - Engraver(13)  
> - Farmer - Cabbage(137)  
> - Farmer - Cattle Herder(137)  
> - Farmer - Corn(137)  
> - Farmer - Cow Herder(137)  
> - Farmer - Dairy(137)  
> - Farmer - Goat Herder(137)  
> - Farmer - Pig Herder(137)  
> - Farmer - Potato(137)  
> - Farmer - Sheep Herder(137)  
> - Farmer - Wheat(137)  
> - Farmer(1368)  
> - Farmer(Special)(137)  
> - Fisherman(35)  
> - Fishmonger(35)  
> - Florist(23)  
> - Furniture Maker(43)  
> - Furrier(61)  
> - Girdler(21)  
> - Glassblower(20)  
> - Glassblower(46)  
> - Glazier(14)  
> - Glove Merchant(37)  
> - Goldsmith(20)  
> - Goldsmith(31)  
> - Goon(61)  
> - Grain Merchant(7)  
> - Grocer(21)  
> - Guide(46)  
> - Haberdasher(18)  
> - Harness Maker(46)  
> - Hat Maker(19)  
> - Hay Merchant(137)  
> - Herbalist(23)  
> - High Mage(13)  
> - High Priest(19)  
> - Historian(13)  
> - Homestead(1824)  
> - Horse Trader(55)  
> - Huntsman(69)  
> - Illuminator(28)  
> - Innkeeper(37)  
> - Instrument Maker(13)  
> - Inventor(40)  
> - Jeweler(18)  
> - Jeweler(28)  
> - Judge(40)  
> - Kettle Maker(12)  
> - Knight(10)  
> - Laborer(55)  
> - Launderer(37)  
> - Launderer(46)  
> - Leatherworker(25)  
> - Leatherworker(28)  
> - Librarian(13)  
> - Livestock Merchant(37)  
> - Locksmith(17)  
> - Lord(10)  
> - Magical Artisan(13)  
> - Magical Artisan(13)  
> - Magical Tutor(13)  
> - Mason(55)  
> - Mayor(1)  
> - Meat Butcher(23)  
> - Messenger(43)  
> - Miller(69)  
> - Minstrel(46)  
> - Missionary(183)  
> - Mountainman(137)  
> - Mountainman(22)  
> - Naval Outfitter(15)  
> - Oil Trader(69)  
> - Oil Trader(69)  
> - Painter(Art)(50)  
> - Painter(Building)(55)  
> - Pastry Maker(35)  
> - Pathfinder(23)  
> - Pawnbroker(16)  
> - Perfumer(19)  
> - Physic/Chirurgeon(23)  
> - Pirate(69)  
> - Plasterer(55)  
> - Potionmakers(23)  
> - Potter(46)  
> - Preacher(110)  
> - Priest(61)  
> - Professor(13)  
> - Purse Maker(23)  
> - Roofer(55)  
> - Roofer(55)  
> - Rope Maker(33)  
> - Rug Maker(17)  
> - Saddler(35)  
> - Sage(13)  
> - Sail Maker(40)  
> - Sailor(92)  
> - Scout(23)  
> - Scribe(13)  
> - Sculptor(12)  
> - SellSpell(13)  
> - Ship Builder(17)  
> - Shoe Maker(33)  
> - Shoe Maker(33)  
> - Silversmith(17)  
> - Silversmith(40)  
> - Skinner(28)  
> - Slaver(46)  
> - Slaver(46)  
> - Soap Maker(23)  
> - Spice Merchant(46)  
> - Spice Merchant(46)  
> - Stabler(49)  
> - Storyteller(46)  
> - Tailor(37)  
> - Tanner(35)  
> - Tanner(35)  
> - Tavern Keeper(50)  
> - Tax Collector(7)  
> - Taxidermist(46)  
> - Taxidermist(46)  
> - Teacher(13)  
> - Teamster(55)  
> - Tiler(55)  
> - Tinker(16)  
> - Tinker(69)  
> - Tobacco Merchant(46)  
> - Tobacco Merchant(46)  
> - Town Crier(79)  
> - Town Justice(19)  
> - Toymaker(13)  
> - Toymaker(22)  
> - Trading Post(69)  
> - Troubadours(46)  
> - Tutor(13)  
> - Undertaker(16)  
> - Used Garment Trader(58)  
> - Vestment Maker(33)  
> - Vintner(29)  
> - Viscount(4)  
> - Wagon Maker(40)  
> - Warehouser(46)  
> - Water Carrier(55)  
> - Weapon Dealer(46)  
> - Weapon Dealer(46)  
> - Weaponsmith(14)  
> - Weaponsmith(14)  
> - Weaver(40)  
> - Wheelwright(43)  
> - Wheelwright(61)  
> - Wine Merchant(23)  
> - Wood Carver(22)  
> - Wood Seller(21)  
> - Wool Merchant(35)  
> - Writer(46)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(46)  
> - Advocate(35)  
> - Alchemist(23)  
> - Animal Groomer(19)  
> - Animal Handler(46)  
> - Antiquities(46)  
> - ArchDuke(1)  
> - Architect(55)  
> - Armor Dealer(46)  
> - Armorer(15)  
> - Artist(61)  
> - Astrologist(13)  
> - Baker(43)  
> - Banker(16)  
> - Barbarian(137)  
> - Barbarian(25)  
> - Barber(23)  
> - Baron(6)  
> - Barrel Maker(29)  
> - Barrel Maker(50)  
> - Basket Maker(40)  
> - Bather(19)  
> - Beer Merchant(25)  
> - Blacksmith(65)  
> - Bleacher(23)  
> - Book Binder(14)  
> - Bookseller(14)  
> - Bowyer-Fletcher(22)  
> - Bowyer-Fletcher(22)  
> - Brewer(7)  
> - Bricklayer(55)  
> - Brigand(137)  
> - Brigand(46)  
> - Brothel Keeper(19)  
> - Buckle Maker(22)  
> - Buckle Maker(37)  
> - Butcher(28)  
> - Candle Maker(18)  
> - Captain(137)  
> - Caravanner(35)  
> - Carpenter(79)  
> - Cartographer(23)  
> - Chandler(69)  
> - Chandler(69)  
> - Chicken Butcher(28)  
> - Cleric(50)  
> - Clerk(79)  
> - Clock Maker(13)  
> - Cobbler(33)  
> - Cobbler(43)  
> - Conjourer(13)  
> - Cook(29)  
> - Cooper(33)  
> - Council Member(69)  
> - Count(3)  
> - Crime Lord(11)  
> - Crook(55)  
> - Cutler(14)  
> - Dairy Seller(137)  
> - Diplomat(11)  
> - Distiller(25)  
> - Draper(23)  
> - Duke(2)  
> - Dungsweeper(39)  
> - Dye Makers(69)  
> - Dye Makers(69)  
> - Earl(3)  
> - Engineer(55)  
> - Engraver(13)  
> - Farmer - Cabbage(137)  
> - Farmer - Cattle Herder(137)  
> - Farmer - Corn(137)  
> - Farmer - Cow Herder(137)  
> - Farmer - Dairy(137)  
> - Farmer - Goat Herder(137)  
> - Farmer - Pig Herder(137)  
> - Farmer - Potato(137)  
> - Farmer - Sheep Herder(137)  
> - Farmer - Wheat(137)  
> - Farmer(1368)  
> - Farmer(Special)(137)  
> - Fisherman(35)  
> - Fishmonger(35)  
> - Florist(23)  
> - Furniture Maker(43)  
> - Furrier(61)  
> - Girdler(21)  
> - Glassblower(20)  
> - Glassblower(46)  
> - Glazier(14)  
> - Glove Merchant(37)  
> - Goldsmith(20)  
> - Goldsmith(31)  
> - Goon(61)  
> - Grain Merchant(7)  
> - Grocer(21)  
> - Guide(46)  
> - Haberdasher(18)  
> - Harness Maker(46)  
> - Hat Maker(19)  
> - Hay Merchant(137)  
> - Herbalist(23)  
> - High Mage(13)  
> - High Priest(19)  
> - Historian(13)  
> - Homestead(1824)  
> - Horse Trader(55)  
> - Huntsman(69)  
> - Illuminator(28)  
> - Innkeeper(37)  
> - Instrument Maker(13)  
> - Inventor(40)  
> - Jeweler(18)  
> - Jeweler(28)  
> - Judge(40)  
> - Kettle Maker(12)  
> - Knight(10)  
> - Laborer(55)  
> - Launderer(37)  
> - Launderer(46)  
> - Leatherworker(25)  
> - Leatherworker(28)  
> - Librarian(13)  
> - Livestock Merchant(37)  
> - Locksmith(17)  
> - Lord(10)  
> - Magical Artisan(13)  
> - Magical Artisan(13)  
> - Magical Tutor(13)  
> - Mason(55)  
> - Mayor(1)  
> - Meat Butcher(23)  
> - Messenger(43)  
> - Miller(69)  
> - Minstrel(46)  
> - Missionary(183)  
> - Mountainman(137)  
> - Mountainman(22)  
> - Naval Outfitter(15)  
> - Oil Trader(69)  
> - Oil Trader(69)  
> - Painter(Art)(50)  
> - Painter(Building)(55)  
> - Pastry Maker(35)  
> - Pathfinder(23)  
> - Pawnbroker(16)  
> - Perfumer(19)  
> - Physic/Chirurgeon(23)  
> - Pirate(69)  
> - Plasterer(55)  
> - Potionmakers(23)  
> - Potter(46)  
> - Preacher(110)  
> - Priest(61)  
> - Professor(13)  
> - Purse Maker(23)  
> - Roofer(55)  
> - Roofer(55)  
> - Rope Maker(33)  
> - Rug Maker(17)  
> - Saddler(35)  
> - Sage(13)  
> - Sail Maker(40)  
> - Sailor(92)  
> - Scout(23)  
> - Scribe(13)  
> - Sculptor(12)  
> - SellSpell(13)  
> - Ship Builder(17)  
> - Shoe Maker(33)  
> - Shoe Maker(33)  
> - Silversmith(17)  
> - Silversmith(40)  
> - Skinner(28)  
> - Slaver(46)  
> - Slaver(46)  
> - Soap Maker(23)  
> - Spice Merchant(46)  
> - Spice Merchant(46)  
> - Stabler(49)  
> - Storyteller(46)  
> - Tailor(37)  
> - Tanner(35)  
> - Tanner(35)  
> - Tavern Keeper(50)  
> - Tax Collector(7)  
> - Taxidermist(46)  
> - Taxidermist(46)  
> - Teacher(13)  
> - Teamster(55)  
> - Tiler(55)  
> - Tinker(16)  
> - Tinker(69)  
> - Tobacco Merchant(46)  
> - Tobacco Merchant(46)  
> - Town Crier(79)  
> - Town Justice(19)  
> - Toymaker(13)  
> - Toymaker(22)  
> - Trading Post(69)  
> - Troubadours(46)  
> - Tutor(13)  
> - Undertaker(16)  
> - Used Garment Trader(58)  
> - Vestment Maker(33)  
> - Vintner(29)  
> - Viscount(4)  
> - Wagon Maker(40)  
> - Warehouser(46)  
> - Water Carrier(55)  
> - Weapon Dealer(46)  
> - Weapon Dealer(46)  
> - Weaponsmith(14)  
> - Weaponsmith(14)  
> - Weaver(40)  
> - Wheelwright(43)  
> - Wheelwright(61)  
> - Wine Merchant(23)  
> - Wood Carver(22)  
> - Wood Seller(21)  
> - Wool Merchant(35)  
> - Writer(46)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



