---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallCity
kingdom: KingdomName
region: RegionName
settlementName: Named SmallCity (9269)
terrain: Forest Heavy Fungal 
settlementDescription: 
population: 9269
culture: Viking 
technology: Bronze Age 
leader: 
govermentType: Confederation 
demographics: 
- Acrobat(16) 
- Minstrel(16) 
- Storyteller(16) 
- Troubadours(16) 
- Writer(16) 
- Advocate(12) 
- Clerk(27) 
- Council Member(24) 
- Diplomat(4) 
- Judge(14) 
- Mayor(1) 
- Alchemist(8) 
- Chandler(24) 
- Dye Makers(24) 
- Florist(8) 
- Herbalist(8) 
- Potionmakers(8) 
- Sage(5) 
- Spice Merchant(16) 
- Taxidermist(16) 
- Tobacco Merchant(16) 
- Animal Groomer(7) 
- Animal Handler(16) 
- Caravanner(12) 
- Horse Trader(19) 
- Livestock Merchant(13) 
- Stabler(17) 
- Antiquities(16) 
- Armor Dealer(16) 
- Launderer(16) 
- Oil Trader(24) 
- Trading Post(24) 
- Slaver(16) 
- Spice Merchant(16) 
- Taxidermist(16) 
- Tobacco Merchant(16) 
- Warehouser(16) 
- Weapon Dealer(16) 
- Architect(19) 
- Bricklayer(19) 
- Engineer(19) 
- Laborer(19) 
- Mason(19) 
- Painter(Building)(19) 
- Plasterer(19) 
- Roofer(19) 
- Teamster(19) 
- Tiler(19) 
- Armorer(5) 
- Blacksmith(22) 
- Bowyer-Fletcher(8) 
- Jeweler(6) 
- Silversmith(6) 
- Weapon Dealer(16) 
- Weaponsmith(5) 
- Artist(21) 
- Glassblower(16) 
- Goldsmith(11) 
- Inventor(14) 
- Jeweler(10) 
- Magical Artisan(5) 
- Painter(Art)(17) 
- Silversmith(14) 
- Tinker(24) 
- Toymaker(8) 
- Astrologist(5) 
- Conjourer(5) 
- High Mage(5) 
- Historian(5) 
- Librarian(5) 
- Magical Artisan(5) 
- Magical Tutor(5) 
- Professor(5) 
- Scribe(5) 
- SellSpell(5) 
- Teacher(5) 
- Tutor(5) 
- Baker(15) 
- Beer Merchant(9) 
- Brewer(3) 
- Butcher(10) 
- Chicken Butcher(10) 
- Cook(10) 
- Dairy Seller(47) 
- Distiller(9) 
- Hay Merchant(47) 
- Fisherman(12) 
- Fishmonger(12) 
- Grain Merchant(3) 
- Grocer(7) 
- Meat Butcher(8) 
- Miller(24) 
- Pastry Maker(12) 
- Vintner(10) 
- Banker(6) 
- Pawnbroker(6) 
- Barbarian(47) 
- Brigand(47) 
- Captain(47) 
- Mountainman(47) 
- Barbarian(9) 
- Cartographer(8) 
- Guide(16) 
- Huntsman(24) 
- Mountainman(8) 
- Pathfinder(8) 
- Scout(8) 
- Slaver(16) 
- Barrel Maker(10) 
- Basket Maker(14) 
- Book Binder(5) 
- Bookseller(5) 
- Buckle Maker(8) 
- Candle Maker(6) 
- Clock Maker(5) 
- Cobbler(15) 
- Cooper(11) 
- Cutler(5) 
- Engraver(5) 
- Furniture Maker(15) 
- Glassblower(7) 
- Glazier(5) 
- Glove Merchant(13) 
- Goldsmith(7) 
- Harness Maker(16) 
- Hat Maker(7) 
- Instrument Maker(5) 
- Kettle Maker(5) 
- Locksmith(6) 
- Perfumer(7) 
- Potter(16) 
- Rope Maker(11) 
- Rug Maker(6) 
- Saddler(12) 
- Sculptor(4) 
- Shoe Maker(11) 
- Soap Maker(8) 
- Tanner(12) 
- Tinker(6) 
- Toymaker(5) 
- Weaponsmith(5) 
- Weaver(14) 
- Wheelwright(21) 
- Wine Merchant(8) 
- Wool Merchant(12) 
- Lord(4) 
- Knight(4) 
- Baron(2) 
- Viscount(1) 
- Earl(1) 
- Count(1) 
- Barrel Maker(17) 
- Bowyer-Fletcher(8) 
- Carpenter(27) 
- Roofer(19) 
- Wagon Maker(14) 
- Wheelwright(15) 
- Wood Carver(8) 
- Wood Seller(7) 
- Barber(8) 
- Bleacher(8) 
- Physic/Chirurgeon(8) 
- Bather(7) 
- Brigand(16) 
- Crime Lord(4) 
- Crook(19) 
- Goon(21) 
- Brothel Keeper(7) 
- Innkeeper(13) 
- Tavern Keeper(17) 
- Buckle Maker(13) 
- Cobbler(11) 
- Draper(8) 
- Furrier(21) 
- Girdler(7) 
- Haberdasher(6) 
- Launderer(13) 
- Leatherworker(9) 
- Purse Maker(8) 
- Shoe Maker(11) 
- Tailor(13) 
- Tanner(12) 
- Used Garment Trader(20) 
- Vestment Maker(11) 
- Chandler(24) 
- Dye Makers(24) 
- Oil Trader(24) 
- Cleric(17) 
- High Priest(7) 
- Missionary(62) 
- Preacher(38) 
- Priest(21) 
- Farmer(464) 
- Homestead(618) 
- Farmer - Cabbage(47) 
- Farmer - Cattle Herder(47) 
- Farmer - Corn(47) 
- Farmer - Cow Herder(47) 
- Farmer - Dairy(47) 
- Farmer - Goat Herder(47) 
- Farmer - Pig Herder(47) 
- Farmer - Potato(47) 
- Farmer - Sheep Herder(47) 
- Farmer - Wheat(47) 
- Farmer(Special)(47) 
- Dungsweeper(14) 
- Illuminator(10) 
- Messenger(15) 
- Tax Collector(3) 
- Town Crier(27) 
- Town Justice(7) 
- Undertaker(6) 
- Water Carrier(19) 
- Leatherworker(10) 
- Skinner(10) 
- Naval Outfitter(5) 
- Pirate(24) 
- Sail Maker(14) 
- Sailor(31) 
- Ship Builder(6) 
imports: 
- Ivory  
exports: 
- Cotton  
defenses: Turrets 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(16)  
> - Advocate(12)  
> - Alchemist(8)  
> - Animal Groomer(7)  
> - Animal Handler(16)  
> - Antiquities(16)  
> - Architect(19)  
> - Armor Dealer(16)  
> - Armorer(5)  
> - Artist(21)  
> - Astrologist(5)  
> - Baker(15)  
> - Banker(6)  
> - Barbarian(47)  
> - Barbarian(9)  
> - Barber(8)  
> - Baron(2)  
> - Barrel Maker(10)  
> - Barrel Maker(17)  
> - Basket Maker(14)  
> - Bather(7)  
> - Beer Merchant(9)  
> - Blacksmith(22)  
> - Bleacher(8)  
> - Book Binder(5)  
> - Bookseller(5)  
> - Bowyer-Fletcher(8)  
> - Bowyer-Fletcher(8)  
> - Brewer(3)  
> - Bricklayer(19)  
> - Brigand(16)  
> - Brigand(47)  
> - Brothel Keeper(7)  
> - Buckle Maker(13)  
> - Buckle Maker(8)  
> - Butcher(10)  
> - Candle Maker(6)  
> - Captain(47)  
> - Caravanner(12)  
> - Carpenter(27)  
> - Cartographer(8)  
> - Chandler(24)  
> - Chandler(24)  
> - Chicken Butcher(10)  
> - Cleric(17)  
> - Clerk(27)  
> - Clock Maker(5)  
> - Cobbler(11)  
> - Cobbler(15)  
> - Conjourer(5)  
> - Cook(10)  
> - Cooper(11)  
> - Council Member(24)  
> - Count(1)  
> - Crime Lord(4)  
> - Crook(19)  
> - Cutler(5)  
> - Dairy Seller(47)  
> - Diplomat(4)  
> - Distiller(9)  
> - Draper(8)  
> - Dungsweeper(14)  
> - Dye Makers(24)  
> - Dye Makers(24)  
> - Earl(1)  
> - Engineer(19)  
> - Engraver(5)  
> - Farmer - Cabbage(47)  
> - Farmer - Cattle Herder(47)  
> - Farmer - Corn(47)  
> - Farmer - Cow Herder(47)  
> - Farmer - Dairy(47)  
> - Farmer - Goat Herder(47)  
> - Farmer - Pig Herder(47)  
> - Farmer - Potato(47)  
> - Farmer - Sheep Herder(47)  
> - Farmer - Wheat(47)  
> - Farmer(464)  
> - Farmer(Special)(47)  
> - Fisherman(12)  
> - Fishmonger(12)  
> - Florist(8)  
> - Furniture Maker(15)  
> - Furrier(21)  
> - Girdler(7)  
> - Glassblower(16)  
> - Glassblower(7)  
> - Glazier(5)  
> - Glove Merchant(13)  
> - Goldsmith(11)  
> - Goldsmith(7)  
> - Goon(21)  
> - Grain Merchant(3)  
> - Grocer(7)  
> - Guide(16)  
> - Haberdasher(6)  
> - Harness Maker(16)  
> - Hat Maker(7)  
> - Hay Merchant(47)  
> - Herbalist(8)  
> - High Mage(5)  
> - High Priest(7)  
> - Historian(5)  
> - Homestead(618)  
> - Horse Trader(19)  
> - Huntsman(24)  
> - Illuminator(10)  
> - Innkeeper(13)  
> - Instrument Maker(5)  
> - Inventor(14)  
> - Jeweler(10)  
> - Jeweler(6)  
> - Judge(14)  
> - Kettle Maker(5)  
> - Knight(4)  
> - Laborer(19)  
> - Launderer(13)  
> - Launderer(16)  
> - Leatherworker(10)  
> - Leatherworker(9)  
> - Librarian(5)  
> - Livestock Merchant(13)  
> - Locksmith(6)  
> - Lord(4)  
> - Magical Artisan(5)  
> - Magical Artisan(5)  
> - Magical Tutor(5)  
> - Mason(19)  
> - Mayor(1)  
> - Meat Butcher(8)  
> - Messenger(15)  
> - Miller(24)  
> - Minstrel(16)  
> - Missionary(62)  
> - Mountainman(47)  
> - Mountainman(8)  
> - Naval Outfitter(5)  
> - Oil Trader(24)  
> - Oil Trader(24)  
> - Painter(Art)(17)  
> - Painter(Building)(19)  
> - Pastry Maker(12)  
> - Pathfinder(8)  
> - Pawnbroker(6)  
> - Perfumer(7)  
> - Physic/Chirurgeon(8)  
> - Pirate(24)  
> - Plasterer(19)  
> - Potionmakers(8)  
> - Potter(16)  
> - Preacher(38)  
> - Priest(21)  
> - Professor(5)  
> - Purse Maker(8)  
> - Roofer(19)  
> - Roofer(19)  
> - Rope Maker(11)  
> - Rug Maker(6)  
> - Saddler(12)  
> - Sage(5)  
> - Sail Maker(14)  
> - Sailor(31)  
> - Scout(8)  
> - Scribe(5)  
> - Sculptor(4)  
> - SellSpell(5)  
> - Ship Builder(6)  
> - Shoe Maker(11)  
> - Shoe Maker(11)  
> - Silversmith(14)  
> - Silversmith(6)  
> - Skinner(10)  
> - Slaver(16)  
> - Slaver(16)  
> - Soap Maker(8)  
> - Spice Merchant(16)  
> - Spice Merchant(16)  
> - Stabler(17)  
> - Storyteller(16)  
> - Tailor(13)  
> - Tanner(12)  
> - Tanner(12)  
> - Tavern Keeper(17)  
> - Tax Collector(3)  
> - Taxidermist(16)  
> - Taxidermist(16)  
> - Teacher(5)  
> - Teamster(19)  
> - Tiler(19)  
> - Tinker(24)  
> - Tinker(6)  
> - Tobacco Merchant(16)  
> - Tobacco Merchant(16)  
> - Town Crier(27)  
> - Town Justice(7)  
> - Toymaker(5)  
> - Toymaker(8)  
> - Trading Post(24)  
> - Troubadours(16)  
> - Tutor(5)  
> - Undertaker(6)  
> - Used Garment Trader(20)  
> - Vestment Maker(11)  
> - Vintner(10)  
> - Viscount(1)  
> - Wagon Maker(14)  
> - Warehouser(16)  
> - Water Carrier(19)  
> - Weapon Dealer(16)  
> - Weapon Dealer(16)  
> - Weaponsmith(5)  
> - Weaponsmith(5)  
> - Weaver(14)  
> - Wheelwright(15)  
> - Wheelwright(21)  
> - Wine Merchant(8)  
> - Wood Carver(8)  
> - Wood Seller(7)  
> - Wool Merchant(12)  
> - Writer(16)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(16)  
> - Advocate(12)  
> - Alchemist(8)  
> - Animal Groomer(7)  
> - Animal Handler(16)  
> - Antiquities(16)  
> - Architect(19)  
> - Armor Dealer(16)  
> - Armorer(5)  
> - Artist(21)  
> - Astrologist(5)  
> - Baker(15)  
> - Banker(6)  
> - Barbarian(47)  
> - Barbarian(9)  
> - Barber(8)  
> - Baron(2)  
> - Barrel Maker(10)  
> - Barrel Maker(17)  
> - Basket Maker(14)  
> - Bather(7)  
> - Beer Merchant(9)  
> - Blacksmith(22)  
> - Bleacher(8)  
> - Book Binder(5)  
> - Bookseller(5)  
> - Bowyer-Fletcher(8)  
> - Bowyer-Fletcher(8)  
> - Brewer(3)  
> - Bricklayer(19)  
> - Brigand(16)  
> - Brigand(47)  
> - Brothel Keeper(7)  
> - Buckle Maker(13)  
> - Buckle Maker(8)  
> - Butcher(10)  
> - Candle Maker(6)  
> - Captain(47)  
> - Caravanner(12)  
> - Carpenter(27)  
> - Cartographer(8)  
> - Chandler(24)  
> - Chandler(24)  
> - Chicken Butcher(10)  
> - Cleric(17)  
> - Clerk(27)  
> - Clock Maker(5)  
> - Cobbler(11)  
> - Cobbler(15)  
> - Conjourer(5)  
> - Cook(10)  
> - Cooper(11)  
> - Council Member(24)  
> - Count(1)  
> - Crime Lord(4)  
> - Crook(19)  
> - Cutler(5)  
> - Dairy Seller(47)  
> - Diplomat(4)  
> - Distiller(9)  
> - Draper(8)  
> - Dungsweeper(14)  
> - Dye Makers(24)  
> - Dye Makers(24)  
> - Earl(1)  
> - Engineer(19)  
> - Engraver(5)  
> - Farmer - Cabbage(47)  
> - Farmer - Cattle Herder(47)  
> - Farmer - Corn(47)  
> - Farmer - Cow Herder(47)  
> - Farmer - Dairy(47)  
> - Farmer - Goat Herder(47)  
> - Farmer - Pig Herder(47)  
> - Farmer - Potato(47)  
> - Farmer - Sheep Herder(47)  
> - Farmer - Wheat(47)  
> - Farmer(464)  
> - Farmer(Special)(47)  
> - Fisherman(12)  
> - Fishmonger(12)  
> - Florist(8)  
> - Furniture Maker(15)  
> - Furrier(21)  
> - Girdler(7)  
> - Glassblower(16)  
> - Glassblower(7)  
> - Glazier(5)  
> - Glove Merchant(13)  
> - Goldsmith(11)  
> - Goldsmith(7)  
> - Goon(21)  
> - Grain Merchant(3)  
> - Grocer(7)  
> - Guide(16)  
> - Haberdasher(6)  
> - Harness Maker(16)  
> - Hat Maker(7)  
> - Hay Merchant(47)  
> - Herbalist(8)  
> - High Mage(5)  
> - High Priest(7)  
> - Historian(5)  
> - Homestead(618)  
> - Horse Trader(19)  
> - Huntsman(24)  
> - Illuminator(10)  
> - Innkeeper(13)  
> - Instrument Maker(5)  
> - Inventor(14)  
> - Jeweler(10)  
> - Jeweler(6)  
> - Judge(14)  
> - Kettle Maker(5)  
> - Knight(4)  
> - Laborer(19)  
> - Launderer(13)  
> - Launderer(16)  
> - Leatherworker(10)  
> - Leatherworker(9)  
> - Librarian(5)  
> - Livestock Merchant(13)  
> - Locksmith(6)  
> - Lord(4)  
> - Magical Artisan(5)  
> - Magical Artisan(5)  
> - Magical Tutor(5)  
> - Mason(19)  
> - Mayor(1)  
> - Meat Butcher(8)  
> - Messenger(15)  
> - Miller(24)  
> - Minstrel(16)  
> - Missionary(62)  
> - Mountainman(47)  
> - Mountainman(8)  
> - Naval Outfitter(5)  
> - Oil Trader(24)  
> - Oil Trader(24)  
> - Painter(Art)(17)  
> - Painter(Building)(19)  
> - Pastry Maker(12)  
> - Pathfinder(8)  
> - Pawnbroker(6)  
> - Perfumer(7)  
> - Physic/Chirurgeon(8)  
> - Pirate(24)  
> - Plasterer(19)  
> - Potionmakers(8)  
> - Potter(16)  
> - Preacher(38)  
> - Priest(21)  
> - Professor(5)  
> - Purse Maker(8)  
> - Roofer(19)  
> - Roofer(19)  
> - Rope Maker(11)  
> - Rug Maker(6)  
> - Saddler(12)  
> - Sage(5)  
> - Sail Maker(14)  
> - Sailor(31)  
> - Scout(8)  
> - Scribe(5)  
> - Sculptor(4)  
> - SellSpell(5)  
> - Ship Builder(6)  
> - Shoe Maker(11)  
> - Shoe Maker(11)  
> - Silversmith(14)  
> - Silversmith(6)  
> - Skinner(10)  
> - Slaver(16)  
> - Slaver(16)  
> - Soap Maker(8)  
> - Spice Merchant(16)  
> - Spice Merchant(16)  
> - Stabler(17)  
> - Storyteller(16)  
> - Tailor(13)  
> - Tanner(12)  
> - Tanner(12)  
> - Tavern Keeper(17)  
> - Tax Collector(3)  
> - Taxidermist(16)  
> - Taxidermist(16)  
> - Teacher(5)  
> - Teamster(19)  
> - Tiler(19)  
> - Tinker(24)  
> - Tinker(6)  
> - Tobacco Merchant(16)  
> - Tobacco Merchant(16)  
> - Town Crier(27)  
> - Town Justice(7)  
> - Toymaker(5)  
> - Toymaker(8)  
> - Trading Post(24)  
> - Troubadours(16)  
> - Tutor(5)  
> - Undertaker(6)  
> - Used Garment Trader(20)  
> - Vestment Maker(11)  
> - Vintner(10)  
> - Viscount(1)  
> - Wagon Maker(14)  
> - Warehouser(16)  
> - Water Carrier(19)  
> - Weapon Dealer(16)  
> - Weapon Dealer(16)  
> - Weaponsmith(5)  
> - Weaponsmith(5)  
> - Weaver(14)  
> - Wheelwright(15)  
> - Wheelwright(21)  
> - Wine Merchant(8)  
> - Wood Carver(8)  
> - Wood Seller(7)  
> - Wool Merchant(12)  
> - Writer(16)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



