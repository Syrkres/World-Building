---
cssclass: oRPGPage
fileType: settlement
settlementType: Village
kingdom: KingdomName
region: RegionName
settlementName: Named Village (662)
terrain: Desert Cactus 
settlementDescription: 
population: 662
culture: Indian 
technology: Bronze Age 
leader: 
govermentType: Monarchy 
demographics: 
- Acrobat(1) 
- Minstrel(1) 
- Storyteller(1) 
- Troubadours(1) 
- Writer(1) 
- Advocate(1) 
- Clerk(2) 
- Council Member(1) 
- Judge(1) 
- Mayor(1) 
- Chandler(1) 
- Dye Makers(1) 
- Spice Merchant(1) 
- Taxidermist(1) 
- Tobacco Merchant(1) 
- Animal Handler(1) 
- Caravanner(1) 
- Horse Trader(1) 
- Livestock Merchant(1) 
- Stabler(2) 
- Antiquities(1) 
- Armor Dealer(1) 
- Launderer(1) 
- Oil Trader(1) 
- Trading Post(2) 
- Slaver(1) 
- Spice Merchant(1) 
- Taxidermist(1) 
- Tobacco Merchant(1) 
- Warehouser(1) 
- Weapon Dealer(1) 
- Architect(1) 
- Bricklayer(1) 
- Engineer(1) 
- Laborer(1) 
- Mason(1) 
- Painter(Building)(1) 
- Plasterer(1) 
- Roofer(1) 
- Teamster(1) 
- Tiler(1) 
- Blacksmith(2) 
- Jeweler(1) 
- Weapon Dealer(1) 
- Artist(1) 
- Glassblower(1) 
- Inventor(1) 
- Painter(Art)(1) 
- Tinker(2) 
- Baker(1) 
- Dairy Seller(1) 
- Miller(1) 
- Barbarian(4) 
- Brigand(4) 
- Captain(4) 
- Mountainman(4) 
- Barbarian(1) 
- Guide(1) 
- Huntsman(1) 
- Slaver(1) 
- Barrel Maker(1) 
- Basket Maker(1) 
- Cobbler(1) 
- Cooper(1) 
- Furniture Maker(1) 
- Glove Merchant(1) 
- Harness Maker(1) 
- Potter(1) 
- Saddler(1) 
- Shoe Maker(1) 
- Weaver(1) 
- Wheelwright(1) 
- Wool Merchant(1) 
- Barrel Maker(2) 
- Carpenter(1) 
- Roofer(1) 
- Wheelwright(2) 
- Physic/Chirurgeon(1) 
- Brigand(2) 
- Crook(2) 
- Goon(2) 
- Innkeeper(1) 
- Tavern Keeper(2) 
- Buckle Maker(1) 
- Cobbler(1) 
- Draper(1) 
- Furrier(2) 
- Launderer(1) 
- Leatherworker(1) 
- Shoe Maker(1) 
- Tailor(1) 
- Tanner(1) 
- Used Garment Trader(2) 
- Vestment Maker(1) 
- Chandler(1) 
- Dye Makers(1) 
- Oil Trader(1) 
- Cleric(1) 
- Missionary(5) 
- Preacher(3) 
- Priest(1) 
- Farmer(34) 
- Homestead(45) 
- Farmer - Cabbage(1) 
- Farmer - Cattle Herder(1) 
- Farmer - Corn(4) 
- Farmer - Cow Herder(4) 
- Farmer - Dairy(1) 
- Farmer - Goat Herder(4) 
- Farmer - Pig Herder(4) 
- Farmer - Potato(4) 
- Farmer - Sheep Herder(4) 
- Farmer - Wheat(4) 
- Farmer(Special)(1) 
- Dungsweeper(1) 
- Messenger(1) 
- Town Crier(2) 
- Town Justice(1) 
- Undertaker(1) 
- Water Carrier(2) 
- Pirate(2) 
- Sail Maker(1) 
- Sailor(3) 
imports: 
- Jute  
exports: 
- Skins  
defenses: Keeps 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(1)  
> - Advocate(1)  
> - Animal Handler(1)  
> - Antiquities(1)  
> - Architect(1)  
> - Armor Dealer(1)  
> - Artist(1)  
> - Baker(1)  
> - Barbarian(1)  
> - Barbarian(4)  
> - Barrel Maker(1)  
> - Barrel Maker(2)  
> - Basket Maker(1)  
> - Blacksmith(2)  
> - Bricklayer(1)  
> - Brigand(2)  
> - Brigand(4)  
> - Buckle Maker(1)  
> - Captain(4)  
> - Caravanner(1)  
> - Carpenter(1)  
> - Chandler(1)  
> - Chandler(1)  
> - Cleric(1)  
> - Clerk(2)  
> - Cobbler(1)  
> - Cobbler(1)  
> - Cooper(1)  
> - Council Member(1)  
> - Crook(2)  
> - Dairy Seller(1)  
> - Draper(1)  
> - Dungsweeper(1)  
> - Dye Makers(1)  
> - Dye Makers(1)  
> - Engineer(1)  
> - Farmer - Cabbage(1)  
> - Farmer - Cattle Herder(1)  
> - Farmer - Corn(4)  
> - Farmer - Cow Herder(4)  
> - Farmer - Dairy(1)  
> - Farmer - Goat Herder(4)  
> - Farmer - Pig Herder(4)  
> - Farmer - Potato(4)  
> - Farmer - Sheep Herder(4)  
> - Farmer - Wheat(4)  
> - Farmer(34)  
> - Farmer(Special)(1)  
> - Furniture Maker(1)  
> - Furrier(2)  
> - Glassblower(1)  
> - Glove Merchant(1)  
> - Goon(2)  
> - Guide(1)  
> - Harness Maker(1)  
> - Homestead(45)  
> - Horse Trader(1)  
> - Huntsman(1)  
> - Innkeeper(1)  
> - Inventor(1)  
> - Jeweler(1)  
> - Judge(1)  
> - Laborer(1)  
> - Launderer(1)  
> - Launderer(1)  
> - Leatherworker(1)  
> - Livestock Merchant(1)  
> - Mason(1)  
> - Mayor(1)  
> - Messenger(1)  
> - Miller(1)  
> - Minstrel(1)  
> - Missionary(5)  
> - Mountainman(4)  
> - Oil Trader(1)  
> - Oil Trader(1)  
> - Painter(Art)(1)  
> - Painter(Building)(1)  
> - Physic/Chirurgeon(1)  
> - Pirate(2)  
> - Plasterer(1)  
> - Potter(1)  
> - Preacher(3)  
> - Priest(1)  
> - Roofer(1)  
> - Roofer(1)  
> - Saddler(1)  
> - Sail Maker(1)  
> - Sailor(3)  
> - Shoe Maker(1)  
> - Shoe Maker(1)  
> - Slaver(1)  
> - Slaver(1)  
> - Spice Merchant(1)  
> - Spice Merchant(1)  
> - Stabler(2)  
> - Storyteller(1)  
> - Tailor(1)  
> - Tanner(1)  
> - Tavern Keeper(2)  
> - Taxidermist(1)  
> - Taxidermist(1)  
> - Teamster(1)  
> - Tiler(1)  
> - Tinker(2)  
> - Tobacco Merchant(1)  
> - Tobacco Merchant(1)  
> - Town Crier(2)  
> - Town Justice(1)  
> - Trading Post(2)  
> - Troubadours(1)  
> - Undertaker(1)  
> - Used Garment Trader(2)  
> - Vestment Maker(1)  
> - Warehouser(1)  
> - Water Carrier(2)  
> - Weapon Dealer(1)  
> - Weapon Dealer(1)  
> - Weaver(1)  
> - Wheelwright(1)  
> - Wheelwright(2)  
> - Wool Merchant(1)  
> - Writer(1)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(1)  
> - Advocate(1)  
> - Animal Handler(1)  
> - Antiquities(1)  
> - Architect(1)  
> - Armor Dealer(1)  
> - Artist(1)  
> - Baker(1)  
> - Barbarian(1)  
> - Barbarian(4)  
> - Barrel Maker(1)  
> - Barrel Maker(2)  
> - Basket Maker(1)  
> - Blacksmith(2)  
> - Bricklayer(1)  
> - Brigand(2)  
> - Brigand(4)  
> - Buckle Maker(1)  
> - Captain(4)  
> - Caravanner(1)  
> - Carpenter(1)  
> - Chandler(1)  
> - Chandler(1)  
> - Cleric(1)  
> - Clerk(2)  
> - Cobbler(1)  
> - Cobbler(1)  
> - Cooper(1)  
> - Council Member(1)  
> - Crook(2)  
> - Dairy Seller(1)  
> - Draper(1)  
> - Dungsweeper(1)  
> - Dye Makers(1)  
> - Dye Makers(1)  
> - Engineer(1)  
> - Farmer - Cabbage(1)  
> - Farmer - Cattle Herder(1)  
> - Farmer - Corn(4)  
> - Farmer - Cow Herder(4)  
> - Farmer - Dairy(1)  
> - Farmer - Goat Herder(4)  
> - Farmer - Pig Herder(4)  
> - Farmer - Potato(4)  
> - Farmer - Sheep Herder(4)  
> - Farmer - Wheat(4)  
> - Farmer(34)  
> - Farmer(Special)(1)  
> - Furniture Maker(1)  
> - Furrier(2)  
> - Glassblower(1)  
> - Glove Merchant(1)  
> - Goon(2)  
> - Guide(1)  
> - Harness Maker(1)  
> - Homestead(45)  
> - Horse Trader(1)  
> - Huntsman(1)  
> - Innkeeper(1)  
> - Inventor(1)  
> - Jeweler(1)  
> - Judge(1)  
> - Laborer(1)  
> - Launderer(1)  
> - Launderer(1)  
> - Leatherworker(1)  
> - Livestock Merchant(1)  
> - Mason(1)  
> - Mayor(1)  
> - Messenger(1)  
> - Miller(1)  
> - Minstrel(1)  
> - Missionary(5)  
> - Mountainman(4)  
> - Oil Trader(1)  
> - Oil Trader(1)  
> - Painter(Art)(1)  
> - Painter(Building)(1)  
> - Physic/Chirurgeon(1)  
> - Pirate(2)  
> - Plasterer(1)  
> - Potter(1)  
> - Preacher(3)  
> - Priest(1)  
> - Roofer(1)  
> - Roofer(1)  
> - Saddler(1)  
> - Sail Maker(1)  
> - Sailor(3)  
> - Shoe Maker(1)  
> - Shoe Maker(1)  
> - Slaver(1)  
> - Slaver(1)  
> - Spice Merchant(1)  
> - Spice Merchant(1)  
> - Stabler(2)  
> - Storyteller(1)  
> - Tailor(1)  
> - Tanner(1)  
> - Tavern Keeper(2)  
> - Taxidermist(1)  
> - Taxidermist(1)  
> - Teamster(1)  
> - Tiler(1)  
> - Tinker(2)  
> - Tobacco Merchant(1)  
> - Tobacco Merchant(1)  
> - Town Crier(2)  
> - Town Justice(1)  
> - Trading Post(2)  
> - Troubadours(1)  
> - Undertaker(1)  
> - Used Garment Trader(2)  
> - Vestment Maker(1)  
> - Warehouser(1)  
> - Water Carrier(2)  
> - Weapon Dealer(1)  
> - Weapon Dealer(1)  
> - Weaver(1)  
> - Wheelwright(1)  
> - Wheelwright(2)  
> - Wool Merchant(1)  
> - Writer(1)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



