---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (14075)
terrain: Desert Brokenlands 
settlementDescription: 
population: 14075
culture: European 
technology: Dark Ages 
leader: 
govermentType: Socialism 
demographics: 
- Acrobat(24) 
- Minstrel(24) 
- Storyteller(24) 
- Troubadours(24) 
- Writer(24) 
- Advocate(18) 
- Clerk(41) 
- Council Member(36) 
- Diplomat(6) 
- Judge(21) 
- Mayor(1) 
- Alchemist(12) 
- Chandler(36) 
- Dye Makers(36) 
- Florist(12) 
- Herbalist(12) 
- Potionmakers(12) 
- Sage(7) 
- Spice Merchant(24) 
- Taxidermist(24) 
- Tobacco Merchant(24) 
- Animal Groomer(10) 
- Animal Handler(24) 
- Caravanner(18) 
- Horse Trader(29) 
- Livestock Merchant(19) 
- Stabler(26) 
- Antiquities(24) 
- Armor Dealer(24) 
- Launderer(24) 
- Oil Trader(36) 
- Trading Post(36) 
- Slaver(24) 
- Spice Merchant(24) 
- Taxidermist(24) 
- Tobacco Merchant(24) 
- Warehouser(24) 
- Weapon Dealer(24) 
- Architect(29) 
- Bricklayer(29) 
- Engineer(29) 
- Laborer(29) 
- Mason(29) 
- Painter(Building)(29) 
- Plasterer(29) 
- Roofer(29) 
- Teamster(29) 
- Tiler(29) 
- Armorer(8) 
- Blacksmith(34) 
- Bowyer-Fletcher(12) 
- Jeweler(9) 
- Silversmith(9) 
- Weapon Dealer(24) 
- Weaponsmith(7) 
- Artist(32) 
- Glassblower(24) 
- Goldsmith(16) 
- Inventor(21) 
- Jeweler(15) 
- Magical Artisan(7) 
- Painter(Art)(26) 
- Silversmith(21) 
- Tinker(36) 
- Toymaker(11) 
- Astrologist(7) 
- Conjourer(7) 
- High Mage(7) 
- Historian(7) 
- Librarian(7) 
- Magical Artisan(7) 
- Magical Tutor(7) 
- Professor(7) 
- Scribe(7) 
- SellSpell(7) 
- Teacher(7) 
- Tutor(7) 
- Baker(22) 
- Beer Merchant(13) 
- Brewer(4) 
- Butcher(15) 
- Chicken Butcher(15) 
- Cook(15) 
- Dairy Seller(71) 
- Distiller(13) 
- Hay Merchant(71) 
- Fisherman(18) 
- Fishmonger(18) 
- Grain Merchant(4) 
- Grocer(11) 
- Meat Butcher(12) 
- Miller(36) 
- Pastry Maker(18) 
- Vintner(15) 
- Banker(8) 
- Pawnbroker(8) 
- Barbarian(71) 
- Brigand(71) 
- Captain(71) 
- Mountainman(71) 
- Barbarian(13) 
- Cartographer(12) 
- Guide(24) 
- Huntsman(36) 
- Mountainman(11) 
- Pathfinder(12) 
- Scout(12) 
- Slaver(24) 
- Barrel Maker(15) 
- Basket Maker(21) 
- Book Binder(8) 
- Bookseller(7) 
- Buckle Maker(11) 
- Candle Maker(9) 
- Clock Maker(7) 
- Cobbler(22) 
- Cooper(17) 
- Cutler(8) 
- Engraver(7) 
- Furniture Maker(22) 
- Glassblower(11) 
- Glazier(7) 
- Glove Merchant(19) 
- Goldsmith(11) 
- Harness Maker(24) 
- Hat Maker(10) 
- Instrument Maker(7) 
- Kettle Maker(7) 
- Locksmith(9) 
- Perfumer(10) 
- Potter(24) 
- Rope Maker(17) 
- Rug Maker(9) 
- Saddler(18) 
- Sculptor(6) 
- Shoe Maker(17) 
- Soap Maker(12) 
- Tanner(18) 
- Tinker(8) 
- Toymaker(7) 
- Weaponsmith(7) 
- Weaver(21) 
- Wheelwright(32) 
- Wine Merchant(12) 
- Wool Merchant(18) 
- Lord(5) 
- Knight(5) 
- Baron(3) 
- Viscount(2) 
- Earl(2) 
- Count(2) 
- Duke(1) 
- Barrel Maker(26) 
- Bowyer-Fletcher(12) 
- Carpenter(41) 
- Roofer(29) 
- Wagon Maker(21) 
- Wheelwright(22) 
- Wood Carver(12) 
- Wood Seller(11) 
- Barber(12) 
- Bleacher(12) 
- Physic/Chirurgeon(12) 
- Bather(10) 
- Brigand(24) 
- Crime Lord(6) 
- Crook(29) 
- Goon(32) 
- Brothel Keeper(10) 
- Innkeeper(19) 
- Tavern Keeper(26) 
- Buckle Maker(19) 
- Cobbler(17) 
- Draper(12) 
- Furrier(32) 
- Girdler(11) 
- Haberdasher(10) 
- Launderer(19) 
- Leatherworker(13) 
- Purse Maker(12) 
- Shoe Maker(17) 
- Tailor(19) 
- Tanner(18) 
- Used Garment Trader(30) 
- Vestment Maker(17) 
- Chandler(36) 
- Dye Makers(36) 
- Oil Trader(36) 
- Cleric(26) 
- High Priest(10) 
- Missionary(94) 
- Preacher(57) 
- Priest(32) 
- Farmer(704) 
- Homestead(939) 
- Farmer - Cabbage(71) 
- Farmer - Cattle Herder(71) 
- Farmer - Corn(71) 
- Farmer - Cow Herder(71) 
- Farmer - Dairy(71) 
- Farmer - Goat Herder(71) 
- Farmer - Pig Herder(71) 
- Farmer - Potato(71) 
- Farmer - Sheep Herder(71) 
- Farmer - Wheat(71) 
- Farmer(Special)(71) 
- Dungsweeper(20) 
- Illuminator(15) 
- Messenger(22) 
- Tax Collector(4) 
- Town Crier(41) 
- Town Justice(10) 
- Undertaker(8) 
- Water Carrier(29) 
- Leatherworker(15) 
- Skinner(15) 
- Naval Outfitter(8) 
- Pirate(36) 
- Sail Maker(21) 
- Sailor(47) 
- Ship Builder(9) 
imports: 
- Ivory  
exports: 
- Silicates  
defenses: Moats 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(24)  
> - Advocate(18)  
> - Alchemist(12)  
> - Animal Groomer(10)  
> - Animal Handler(24)  
> - Antiquities(24)  
> - Architect(29)  
> - Armor Dealer(24)  
> - Armorer(8)  
> - Artist(32)  
> - Astrologist(7)  
> - Baker(22)  
> - Banker(8)  
> - Barbarian(13)  
> - Barbarian(71)  
> - Barber(12)  
> - Baron(3)  
> - Barrel Maker(15)  
> - Barrel Maker(26)  
> - Basket Maker(21)  
> - Bather(10)  
> - Beer Merchant(13)  
> - Blacksmith(34)  
> - Bleacher(12)  
> - Book Binder(8)  
> - Bookseller(7)  
> - Bowyer-Fletcher(12)  
> - Bowyer-Fletcher(12)  
> - Brewer(4)  
> - Bricklayer(29)  
> - Brigand(24)  
> - Brigand(71)  
> - Brothel Keeper(10)  
> - Buckle Maker(11)  
> - Buckle Maker(19)  
> - Butcher(15)  
> - Candle Maker(9)  
> - Captain(71)  
> - Caravanner(18)  
> - Carpenter(41)  
> - Cartographer(12)  
> - Chandler(36)  
> - Chandler(36)  
> - Chicken Butcher(15)  
> - Cleric(26)  
> - Clerk(41)  
> - Clock Maker(7)  
> - Cobbler(17)  
> - Cobbler(22)  
> - Conjourer(7)  
> - Cook(15)  
> - Cooper(17)  
> - Council Member(36)  
> - Count(2)  
> - Crime Lord(6)  
> - Crook(29)  
> - Cutler(8)  
> - Dairy Seller(71)  
> - Diplomat(6)  
> - Distiller(13)  
> - Draper(12)  
> - Duke(1)  
> - Dungsweeper(20)  
> - Dye Makers(36)  
> - Dye Makers(36)  
> - Earl(2)  
> - Engineer(29)  
> - Engraver(7)  
> - Farmer - Cabbage(71)  
> - Farmer - Cattle Herder(71)  
> - Farmer - Corn(71)  
> - Farmer - Cow Herder(71)  
> - Farmer - Dairy(71)  
> - Farmer - Goat Herder(71)  
> - Farmer - Pig Herder(71)  
> - Farmer - Potato(71)  
> - Farmer - Sheep Herder(71)  
> - Farmer - Wheat(71)  
> - Farmer(704)  
> - Farmer(Special)(71)  
> - Fisherman(18)  
> - Fishmonger(18)  
> - Florist(12)  
> - Furniture Maker(22)  
> - Furrier(32)  
> - Girdler(11)  
> - Glassblower(11)  
> - Glassblower(24)  
> - Glazier(7)  
> - Glove Merchant(19)  
> - Goldsmith(11)  
> - Goldsmith(16)  
> - Goon(32)  
> - Grain Merchant(4)  
> - Grocer(11)  
> - Guide(24)  
> - Haberdasher(10)  
> - Harness Maker(24)  
> - Hat Maker(10)  
> - Hay Merchant(71)  
> - Herbalist(12)  
> - High Mage(7)  
> - High Priest(10)  
> - Historian(7)  
> - Homestead(939)  
> - Horse Trader(29)  
> - Huntsman(36)  
> - Illuminator(15)  
> - Innkeeper(19)  
> - Instrument Maker(7)  
> - Inventor(21)  
> - Jeweler(15)  
> - Jeweler(9)  
> - Judge(21)  
> - Kettle Maker(7)  
> - Knight(5)  
> - Laborer(29)  
> - Launderer(19)  
> - Launderer(24)  
> - Leatherworker(13)  
> - Leatherworker(15)  
> - Librarian(7)  
> - Livestock Merchant(19)  
> - Locksmith(9)  
> - Lord(5)  
> - Magical Artisan(7)  
> - Magical Artisan(7)  
> - Magical Tutor(7)  
> - Mason(29)  
> - Mayor(1)  
> - Meat Butcher(12)  
> - Messenger(22)  
> - Miller(36)  
> - Minstrel(24)  
> - Missionary(94)  
> - Mountainman(11)  
> - Mountainman(71)  
> - Naval Outfitter(8)  
> - Oil Trader(36)  
> - Oil Trader(36)  
> - Painter(Art)(26)  
> - Painter(Building)(29)  
> - Pastry Maker(18)  
> - Pathfinder(12)  
> - Pawnbroker(8)  
> - Perfumer(10)  
> - Physic/Chirurgeon(12)  
> - Pirate(36)  
> - Plasterer(29)  
> - Potionmakers(12)  
> - Potter(24)  
> - Preacher(57)  
> - Priest(32)  
> - Professor(7)  
> - Purse Maker(12)  
> - Roofer(29)  
> - Roofer(29)  
> - Rope Maker(17)  
> - Rug Maker(9)  
> - Saddler(18)  
> - Sage(7)  
> - Sail Maker(21)  
> - Sailor(47)  
> - Scout(12)  
> - Scribe(7)  
> - Sculptor(6)  
> - SellSpell(7)  
> - Ship Builder(9)  
> - Shoe Maker(17)  
> - Shoe Maker(17)  
> - Silversmith(21)  
> - Silversmith(9)  
> - Skinner(15)  
> - Slaver(24)  
> - Slaver(24)  
> - Soap Maker(12)  
> - Spice Merchant(24)  
> - Spice Merchant(24)  
> - Stabler(26)  
> - Storyteller(24)  
> - Tailor(19)  
> - Tanner(18)  
> - Tanner(18)  
> - Tavern Keeper(26)  
> - Tax Collector(4)  
> - Taxidermist(24)  
> - Taxidermist(24)  
> - Teacher(7)  
> - Teamster(29)  
> - Tiler(29)  
> - Tinker(36)  
> - Tinker(8)  
> - Tobacco Merchant(24)  
> - Tobacco Merchant(24)  
> - Town Crier(41)  
> - Town Justice(10)  
> - Toymaker(11)  
> - Toymaker(7)  
> - Trading Post(36)  
> - Troubadours(24)  
> - Tutor(7)  
> - Undertaker(8)  
> - Used Garment Trader(30)  
> - Vestment Maker(17)  
> - Vintner(15)  
> - Viscount(2)  
> - Wagon Maker(21)  
> - Warehouser(24)  
> - Water Carrier(29)  
> - Weapon Dealer(24)  
> - Weapon Dealer(24)  
> - Weaponsmith(7)  
> - Weaponsmith(7)  
> - Weaver(21)  
> - Wheelwright(22)  
> - Wheelwright(32)  
> - Wine Merchant(12)  
> - Wood Carver(12)  
> - Wood Seller(11)  
> - Wool Merchant(18)  
> - Writer(24)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(24)  
> - Advocate(18)  
> - Alchemist(12)  
> - Animal Groomer(10)  
> - Animal Handler(24)  
> - Antiquities(24)  
> - Architect(29)  
> - Armor Dealer(24)  
> - Armorer(8)  
> - Artist(32)  
> - Astrologist(7)  
> - Baker(22)  
> - Banker(8)  
> - Barbarian(13)  
> - Barbarian(71)  
> - Barber(12)  
> - Baron(3)  
> - Barrel Maker(15)  
> - Barrel Maker(26)  
> - Basket Maker(21)  
> - Bather(10)  
> - Beer Merchant(13)  
> - Blacksmith(34)  
> - Bleacher(12)  
> - Book Binder(8)  
> - Bookseller(7)  
> - Bowyer-Fletcher(12)  
> - Bowyer-Fletcher(12)  
> - Brewer(4)  
> - Bricklayer(29)  
> - Brigand(24)  
> - Brigand(71)  
> - Brothel Keeper(10)  
> - Buckle Maker(11)  
> - Buckle Maker(19)  
> - Butcher(15)  
> - Candle Maker(9)  
> - Captain(71)  
> - Caravanner(18)  
> - Carpenter(41)  
> - Cartographer(12)  
> - Chandler(36)  
> - Chandler(36)  
> - Chicken Butcher(15)  
> - Cleric(26)  
> - Clerk(41)  
> - Clock Maker(7)  
> - Cobbler(17)  
> - Cobbler(22)  
> - Conjourer(7)  
> - Cook(15)  
> - Cooper(17)  
> - Council Member(36)  
> - Count(2)  
> - Crime Lord(6)  
> - Crook(29)  
> - Cutler(8)  
> - Dairy Seller(71)  
> - Diplomat(6)  
> - Distiller(13)  
> - Draper(12)  
> - Duke(1)  
> - Dungsweeper(20)  
> - Dye Makers(36)  
> - Dye Makers(36)  
> - Earl(2)  
> - Engineer(29)  
> - Engraver(7)  
> - Farmer - Cabbage(71)  
> - Farmer - Cattle Herder(71)  
> - Farmer - Corn(71)  
> - Farmer - Cow Herder(71)  
> - Farmer - Dairy(71)  
> - Farmer - Goat Herder(71)  
> - Farmer - Pig Herder(71)  
> - Farmer - Potato(71)  
> - Farmer - Sheep Herder(71)  
> - Farmer - Wheat(71)  
> - Farmer(704)  
> - Farmer(Special)(71)  
> - Fisherman(18)  
> - Fishmonger(18)  
> - Florist(12)  
> - Furniture Maker(22)  
> - Furrier(32)  
> - Girdler(11)  
> - Glassblower(11)  
> - Glassblower(24)  
> - Glazier(7)  
> - Glove Merchant(19)  
> - Goldsmith(11)  
> - Goldsmith(16)  
> - Goon(32)  
> - Grain Merchant(4)  
> - Grocer(11)  
> - Guide(24)  
> - Haberdasher(10)  
> - Harness Maker(24)  
> - Hat Maker(10)  
> - Hay Merchant(71)  
> - Herbalist(12)  
> - High Mage(7)  
> - High Priest(10)  
> - Historian(7)  
> - Homestead(939)  
> - Horse Trader(29)  
> - Huntsman(36)  
> - Illuminator(15)  
> - Innkeeper(19)  
> - Instrument Maker(7)  
> - Inventor(21)  
> - Jeweler(15)  
> - Jeweler(9)  
> - Judge(21)  
> - Kettle Maker(7)  
> - Knight(5)  
> - Laborer(29)  
> - Launderer(19)  
> - Launderer(24)  
> - Leatherworker(13)  
> - Leatherworker(15)  
> - Librarian(7)  
> - Livestock Merchant(19)  
> - Locksmith(9)  
> - Lord(5)  
> - Magical Artisan(7)  
> - Magical Artisan(7)  
> - Magical Tutor(7)  
> - Mason(29)  
> - Mayor(1)  
> - Meat Butcher(12)  
> - Messenger(22)  
> - Miller(36)  
> - Minstrel(24)  
> - Missionary(94)  
> - Mountainman(11)  
> - Mountainman(71)  
> - Naval Outfitter(8)  
> - Oil Trader(36)  
> - Oil Trader(36)  
> - Painter(Art)(26)  
> - Painter(Building)(29)  
> - Pastry Maker(18)  
> - Pathfinder(12)  
> - Pawnbroker(8)  
> - Perfumer(10)  
> - Physic/Chirurgeon(12)  
> - Pirate(36)  
> - Plasterer(29)  
> - Potionmakers(12)  
> - Potter(24)  
> - Preacher(57)  
> - Priest(32)  
> - Professor(7)  
> - Purse Maker(12)  
> - Roofer(29)  
> - Roofer(29)  
> - Rope Maker(17)  
> - Rug Maker(9)  
> - Saddler(18)  
> - Sage(7)  
> - Sail Maker(21)  
> - Sailor(47)  
> - Scout(12)  
> - Scribe(7)  
> - Sculptor(6)  
> - SellSpell(7)  
> - Ship Builder(9)  
> - Shoe Maker(17)  
> - Shoe Maker(17)  
> - Silversmith(21)  
> - Silversmith(9)  
> - Skinner(15)  
> - Slaver(24)  
> - Slaver(24)  
> - Soap Maker(12)  
> - Spice Merchant(24)  
> - Spice Merchant(24)  
> - Stabler(26)  
> - Storyteller(24)  
> - Tailor(19)  
> - Tanner(18)  
> - Tanner(18)  
> - Tavern Keeper(26)  
> - Tax Collector(4)  
> - Taxidermist(24)  
> - Taxidermist(24)  
> - Teacher(7)  
> - Teamster(29)  
> - Tiler(29)  
> - Tinker(36)  
> - Tinker(8)  
> - Tobacco Merchant(24)  
> - Tobacco Merchant(24)  
> - Town Crier(41)  
> - Town Justice(10)  
> - Toymaker(11)  
> - Toymaker(7)  
> - Trading Post(36)  
> - Troubadours(24)  
> - Tutor(7)  
> - Undertaker(8)  
> - Used Garment Trader(30)  
> - Vestment Maker(17)  
> - Vintner(15)  
> - Viscount(2)  
> - Wagon Maker(21)  
> - Warehouser(24)  
> - Water Carrier(29)  
> - Weapon Dealer(24)  
> - Weapon Dealer(24)  
> - Weaponsmith(7)  
> - Weaponsmith(7)  
> - Weaver(21)  
> - Wheelwright(22)  
> - Wheelwright(32)  
> - Wine Merchant(12)  
> - Wood Carver(12)  
> - Wood Seller(11)  
> - Wool Merchant(18)  
> - Writer(24)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



