---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeTown
kingdom: KingdomName
region: RegionName
settlementName: Named LargeTown (4211)
terrain: Wetlands Brokenlands 
settlementDescription: 
population: 4211
culture: African 
technology: Bronze Age 
leader: 
govermentType: Oligarchy 
demographics: 
- Acrobat(8) 
- Minstrel(8) 
- Storyteller(8) 
- Troubadours(8) 
- Writer(8) 
- Advocate(6) 
- Clerk(13) 
- Council Member(11) 
- Diplomat(2) 
- Judge(7) 
- Mayor(1) 
- Alchemist(4) 
- Chandler(11) 
- Dye Makers(11) 
- Florist(4) 
- Herbalist(4) 
- Potionmakers(4) 
- Sage(1) 
- Spice Merchant(8) 
- Taxidermist(8) 
- Tobacco Merchant(8) 
- Animal Groomer(3) 
- Animal Handler(8) 
- Caravanner(6) 
- Horse Trader(9) 
- Livestock Merchant(6) 
- Stabler(8) 
- Antiquities(8) 
- Armor Dealer(8) 
- Launderer(8) 
- Oil Trader(11) 
- Trading Post(11) 
- Slaver(8) 
- Spice Merchant(8) 
- Taxidermist(8) 
- Tobacco Merchant(8) 
- Warehouser(8) 
- Weapon Dealer(8) 
- Architect(9) 
- Bricklayer(9) 
- Engineer(9) 
- Laborer(9) 
- Mason(9) 
- Painter(Building)(9) 
- Plasterer(9) 
- Roofer(9) 
- Teamster(9) 
- Tiler(9) 
- Armorer(3) 
- Blacksmith(10) 
- Bowyer-Fletcher(4) 
- Jeweler(3) 
- Silversmith(3) 
- Weapon Dealer(8) 
- Weaponsmith(3) 
- Artist(10) 
- Glassblower(8) 
- Goldsmith(5) 
- Inventor(7) 
- Jeweler(5) 
- Magical Artisan(1) 
- Painter(Art)(8) 
- Silversmith(7) 
- Tinker(11) 
- Toymaker(4) 
- Astrologist(1) 
- Conjourer(1) 
- High Mage(1) 
- Historian(1) 
- Librarian(1) 
- Magical Artisan(1) 
- Magical Tutor(1) 
- Professor(1) 
- Scribe(1) 
- SellSpell(1) 
- Teacher(1) 
- Tutor(1) 
- Baker(7) 
- Beer Merchant(4) 
- Butcher(5) 
- Chicken Butcher(5) 
- Cook(5) 
- Dairy Seller(22) 
- Distiller(4) 
- Hay Merchant(22) 
- Fisherman(6) 
- Fishmonger(6) 
- Grain Merchant(1) 
- Grocer(4) 
- Meat Butcher(4) 
- Miller(11) 
- Pastry Maker(6) 
- Vintner(5) 
- Banker(3) 
- Pawnbroker(3) 
- Barbarian(22) 
- Brigand(22) 
- Captain(22) 
- Mountainman(22) 
- Barbarian(4) 
- Cartographer(4) 
- Guide(8) 
- Huntsman(11) 
- Mountainman(4) 
- Pathfinder(4) 
- Scout(4) 
- Slaver(8) 
- Barrel Maker(5) 
- Basket Maker(7) 
- Book Binder(3) 
- Bookseller(3) 
- Buckle Maker(4) 
- Candle Maker(3) 
- Clock Maker(2) 
- Cobbler(7) 
- Cooper(5) 
- Cutler(3) 
- Engraver(2) 
- Furniture Maker(7) 
- Glassblower(4) 
- Glazier(3) 
- Glove Merchant(6) 
- Goldsmith(4) 
- Harness Maker(8) 
- Hat Maker(3) 
- Instrument Maker(2) 
- Kettle Maker(2) 
- Locksmith(3) 
- Perfumer(3) 
- Potter(8) 
- Rope Maker(5) 
- Rug Maker(3) 
- Saddler(6) 
- Sculptor(2) 
- Shoe Maker(5) 
- Soap Maker(4) 
- Tanner(6) 
- Tinker(3) 
- Toymaker(2) 
- Weaponsmith(3) 
- Weaver(7) 
- Wheelwright(10) 
- Wine Merchant(4) 
- Wool Merchant(6) 
- Lord(2) 
- Knight(2) 
- Baron(1) 
- Barrel Maker(8) 
- Bowyer-Fletcher(4) 
- Carpenter(13) 
- Roofer(9) 
- Wagon Maker(7) 
- Wheelwright(7) 
- Wood Carver(4) 
- Wood Seller(4) 
- Barber(4) 
- Bleacher(4) 
- Physic/Chirurgeon(4) 
- Bather(3) 
- Brigand(8) 
- Crime Lord(2) 
- Crook(9) 
- Goon(10) 
- Brothel Keeper(3) 
- Innkeeper(6) 
- Tavern Keeper(8) 
- Buckle Maker(6) 
- Cobbler(5) 
- Draper(4) 
- Furrier(10) 
- Girdler(4) 
- Haberdasher(3) 
- Launderer(6) 
- Leatherworker(4) 
- Purse Maker(4) 
- Shoe Maker(5) 
- Tailor(6) 
- Tanner(6) 
- Used Garment Trader(9) 
- Vestment Maker(5) 
- Chandler(11) 
- Dye Makers(11) 
- Oil Trader(11) 
- Cleric(8) 
- High Priest(3) 
- Missionary(29) 
- Preacher(17) 
- Priest(10) 
- Farmer(211) 
- Homestead(281) 
- Farmer - Cabbage(22) 
- Farmer - Cattle Herder(22) 
- Farmer - Corn(22) 
- Farmer - Cow Herder(22) 
- Farmer - Dairy(22) 
- Farmer - Goat Herder(22) 
- Farmer - Pig Herder(22) 
- Farmer - Potato(22) 
- Farmer - Sheep Herder(22) 
- Farmer - Wheat(22) 
- Farmer(Special)(22) 
- Dungsweeper(6) 
- Illuminator(5) 
- Messenger(7) 
- Tax Collector(1) 
- Town Crier(13) 
- Town Justice(3) 
- Undertaker(3) 
- Water Carrier(9) 
- Leatherworker(5) 
- Skinner(5) 
- Naval Outfitter(3) 
- Pirate(11) 
- Sail Maker(7) 
- Sailor(15) 
- Ship Builder(3) 
imports: 
- Ore  
exports: 
- Malachite  
defenses: Keeps 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(8)  
> - Advocate(6)  
> - Alchemist(4)  
> - Animal Groomer(3)  
> - Animal Handler(8)  
> - Antiquities(8)  
> - Architect(9)  
> - Armor Dealer(8)  
> - Armorer(3)  
> - Artist(10)  
> - Astrologist(1)  
> - Baker(7)  
> - Banker(3)  
> - Barbarian(22)  
> - Barbarian(4)  
> - Barber(4)  
> - Baron(1)  
> - Barrel Maker(5)  
> - Barrel Maker(8)  
> - Basket Maker(7)  
> - Bather(3)  
> - Beer Merchant(4)  
> - Blacksmith(10)  
> - Bleacher(4)  
> - Book Binder(3)  
> - Bookseller(3)  
> - Bowyer-Fletcher(4)  
> - Bowyer-Fletcher(4)  
> - Bricklayer(9)  
> - Brigand(22)  
> - Brigand(8)  
> - Brothel Keeper(3)  
> - Buckle Maker(4)  
> - Buckle Maker(6)  
> - Butcher(5)  
> - Candle Maker(3)  
> - Captain(22)  
> - Caravanner(6)  
> - Carpenter(13)  
> - Cartographer(4)  
> - Chandler(11)  
> - Chandler(11)  
> - Chicken Butcher(5)  
> - Cleric(8)  
> - Clerk(13)  
> - Clock Maker(2)  
> - Cobbler(5)  
> - Cobbler(7)  
> - Conjourer(1)  
> - Cook(5)  
> - Cooper(5)  
> - Council Member(11)  
> - Crime Lord(2)  
> - Crook(9)  
> - Cutler(3)  
> - Dairy Seller(22)  
> - Diplomat(2)  
> - Distiller(4)  
> - Draper(4)  
> - Dungsweeper(6)  
> - Dye Makers(11)  
> - Dye Makers(11)  
> - Engineer(9)  
> - Engraver(2)  
> - Farmer - Cabbage(22)  
> - Farmer - Cattle Herder(22)  
> - Farmer - Corn(22)  
> - Farmer - Cow Herder(22)  
> - Farmer - Dairy(22)  
> - Farmer - Goat Herder(22)  
> - Farmer - Pig Herder(22)  
> - Farmer - Potato(22)  
> - Farmer - Sheep Herder(22)  
> - Farmer - Wheat(22)  
> - Farmer(211)  
> - Farmer(Special)(22)  
> - Fisherman(6)  
> - Fishmonger(6)  
> - Florist(4)  
> - Furniture Maker(7)  
> - Furrier(10)  
> - Girdler(4)  
> - Glassblower(4)  
> - Glassblower(8)  
> - Glazier(3)  
> - Glove Merchant(6)  
> - Goldsmith(4)  
> - Goldsmith(5)  
> - Goon(10)  
> - Grain Merchant(1)  
> - Grocer(4)  
> - Guide(8)  
> - Haberdasher(3)  
> - Harness Maker(8)  
> - Hat Maker(3)  
> - Hay Merchant(22)  
> - Herbalist(4)  
> - High Mage(1)  
> - High Priest(3)  
> - Historian(1)  
> - Homestead(281)  
> - Horse Trader(9)  
> - Huntsman(11)  
> - Illuminator(5)  
> - Innkeeper(6)  
> - Instrument Maker(2)  
> - Inventor(7)  
> - Jeweler(3)  
> - Jeweler(5)  
> - Judge(7)  
> - Kettle Maker(2)  
> - Knight(2)  
> - Laborer(9)  
> - Launderer(6)  
> - Launderer(8)  
> - Leatherworker(4)  
> - Leatherworker(5)  
> - Librarian(1)  
> - Livestock Merchant(6)  
> - Locksmith(3)  
> - Lord(2)  
> - Magical Artisan(1)  
> - Magical Artisan(1)  
> - Magical Tutor(1)  
> - Mason(9)  
> - Mayor(1)  
> - Meat Butcher(4)  
> - Messenger(7)  
> - Miller(11)  
> - Minstrel(8)  
> - Missionary(29)  
> - Mountainman(22)  
> - Mountainman(4)  
> - Naval Outfitter(3)  
> - Oil Trader(11)  
> - Oil Trader(11)  
> - Painter(Art)(8)  
> - Painter(Building)(9)  
> - Pastry Maker(6)  
> - Pathfinder(4)  
> - Pawnbroker(3)  
> - Perfumer(3)  
> - Physic/Chirurgeon(4)  
> - Pirate(11)  
> - Plasterer(9)  
> - Potionmakers(4)  
> - Potter(8)  
> - Preacher(17)  
> - Priest(10)  
> - Professor(1)  
> - Purse Maker(4)  
> - Roofer(9)  
> - Roofer(9)  
> - Rope Maker(5)  
> - Rug Maker(3)  
> - Saddler(6)  
> - Sage(1)  
> - Sail Maker(7)  
> - Sailor(15)  
> - Scout(4)  
> - Scribe(1)  
> - Sculptor(2)  
> - SellSpell(1)  
> - Ship Builder(3)  
> - Shoe Maker(5)  
> - Shoe Maker(5)  
> - Silversmith(3)  
> - Silversmith(7)  
> - Skinner(5)  
> - Slaver(8)  
> - Slaver(8)  
> - Soap Maker(4)  
> - Spice Merchant(8)  
> - Spice Merchant(8)  
> - Stabler(8)  
> - Storyteller(8)  
> - Tailor(6)  
> - Tanner(6)  
> - Tanner(6)  
> - Tavern Keeper(8)  
> - Tax Collector(1)  
> - Taxidermist(8)  
> - Taxidermist(8)  
> - Teacher(1)  
> - Teamster(9)  
> - Tiler(9)  
> - Tinker(11)  
> - Tinker(3)  
> - Tobacco Merchant(8)  
> - Tobacco Merchant(8)  
> - Town Crier(13)  
> - Town Justice(3)  
> - Toymaker(2)  
> - Toymaker(4)  
> - Trading Post(11)  
> - Troubadours(8)  
> - Tutor(1)  
> - Undertaker(3)  
> - Used Garment Trader(9)  
> - Vestment Maker(5)  
> - Vintner(5)  
> - Wagon Maker(7)  
> - Warehouser(8)  
> - Water Carrier(9)  
> - Weapon Dealer(8)  
> - Weapon Dealer(8)  
> - Weaponsmith(3)  
> - Weaponsmith(3)  
> - Weaver(7)  
> - Wheelwright(10)  
> - Wheelwright(7)  
> - Wine Merchant(4)  
> - Wood Carver(4)  
> - Wood Seller(4)  
> - Wool Merchant(6)  
> - Writer(8)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(8)  
> - Advocate(6)  
> - Alchemist(4)  
> - Animal Groomer(3)  
> - Animal Handler(8)  
> - Antiquities(8)  
> - Architect(9)  
> - Armor Dealer(8)  
> - Armorer(3)  
> - Artist(10)  
> - Astrologist(1)  
> - Baker(7)  
> - Banker(3)  
> - Barbarian(22)  
> - Barbarian(4)  
> - Barber(4)  
> - Baron(1)  
> - Barrel Maker(5)  
> - Barrel Maker(8)  
> - Basket Maker(7)  
> - Bather(3)  
> - Beer Merchant(4)  
> - Blacksmith(10)  
> - Bleacher(4)  
> - Book Binder(3)  
> - Bookseller(3)  
> - Bowyer-Fletcher(4)  
> - Bowyer-Fletcher(4)  
> - Bricklayer(9)  
> - Brigand(22)  
> - Brigand(8)  
> - Brothel Keeper(3)  
> - Buckle Maker(4)  
> - Buckle Maker(6)  
> - Butcher(5)  
> - Candle Maker(3)  
> - Captain(22)  
> - Caravanner(6)  
> - Carpenter(13)  
> - Cartographer(4)  
> - Chandler(11)  
> - Chandler(11)  
> - Chicken Butcher(5)  
> - Cleric(8)  
> - Clerk(13)  
> - Clock Maker(2)  
> - Cobbler(5)  
> - Cobbler(7)  
> - Conjourer(1)  
> - Cook(5)  
> - Cooper(5)  
> - Council Member(11)  
> - Crime Lord(2)  
> - Crook(9)  
> - Cutler(3)  
> - Dairy Seller(22)  
> - Diplomat(2)  
> - Distiller(4)  
> - Draper(4)  
> - Dungsweeper(6)  
> - Dye Makers(11)  
> - Dye Makers(11)  
> - Engineer(9)  
> - Engraver(2)  
> - Farmer - Cabbage(22)  
> - Farmer - Cattle Herder(22)  
> - Farmer - Corn(22)  
> - Farmer - Cow Herder(22)  
> - Farmer - Dairy(22)  
> - Farmer - Goat Herder(22)  
> - Farmer - Pig Herder(22)  
> - Farmer - Potato(22)  
> - Farmer - Sheep Herder(22)  
> - Farmer - Wheat(22)  
> - Farmer(211)  
> - Farmer(Special)(22)  
> - Fisherman(6)  
> - Fishmonger(6)  
> - Florist(4)  
> - Furniture Maker(7)  
> - Furrier(10)  
> - Girdler(4)  
> - Glassblower(4)  
> - Glassblower(8)  
> - Glazier(3)  
> - Glove Merchant(6)  
> - Goldsmith(4)  
> - Goldsmith(5)  
> - Goon(10)  
> - Grain Merchant(1)  
> - Grocer(4)  
> - Guide(8)  
> - Haberdasher(3)  
> - Harness Maker(8)  
> - Hat Maker(3)  
> - Hay Merchant(22)  
> - Herbalist(4)  
> - High Mage(1)  
> - High Priest(3)  
> - Historian(1)  
> - Homestead(281)  
> - Horse Trader(9)  
> - Huntsman(11)  
> - Illuminator(5)  
> - Innkeeper(6)  
> - Instrument Maker(2)  
> - Inventor(7)  
> - Jeweler(3)  
> - Jeweler(5)  
> - Judge(7)  
> - Kettle Maker(2)  
> - Knight(2)  
> - Laborer(9)  
> - Launderer(6)  
> - Launderer(8)  
> - Leatherworker(4)  
> - Leatherworker(5)  
> - Librarian(1)  
> - Livestock Merchant(6)  
> - Locksmith(3)  
> - Lord(2)  
> - Magical Artisan(1)  
> - Magical Artisan(1)  
> - Magical Tutor(1)  
> - Mason(9)  
> - Mayor(1)  
> - Meat Butcher(4)  
> - Messenger(7)  
> - Miller(11)  
> - Minstrel(8)  
> - Missionary(29)  
> - Mountainman(22)  
> - Mountainman(4)  
> - Naval Outfitter(3)  
> - Oil Trader(11)  
> - Oil Trader(11)  
> - Painter(Art)(8)  
> - Painter(Building)(9)  
> - Pastry Maker(6)  
> - Pathfinder(4)  
> - Pawnbroker(3)  
> - Perfumer(3)  
> - Physic/Chirurgeon(4)  
> - Pirate(11)  
> - Plasterer(9)  
> - Potionmakers(4)  
> - Potter(8)  
> - Preacher(17)  
> - Priest(10)  
> - Professor(1)  
> - Purse Maker(4)  
> - Roofer(9)  
> - Roofer(9)  
> - Rope Maker(5)  
> - Rug Maker(3)  
> - Saddler(6)  
> - Sage(1)  
> - Sail Maker(7)  
> - Sailor(15)  
> - Scout(4)  
> - Scribe(1)  
> - Sculptor(2)  
> - SellSpell(1)  
> - Ship Builder(3)  
> - Shoe Maker(5)  
> - Shoe Maker(5)  
> - Silversmith(3)  
> - Silversmith(7)  
> - Skinner(5)  
> - Slaver(8)  
> - Slaver(8)  
> - Soap Maker(4)  
> - Spice Merchant(8)  
> - Spice Merchant(8)  
> - Stabler(8)  
> - Storyteller(8)  
> - Tailor(6)  
> - Tanner(6)  
> - Tanner(6)  
> - Tavern Keeper(8)  
> - Tax Collector(1)  
> - Taxidermist(8)  
> - Taxidermist(8)  
> - Teacher(1)  
> - Teamster(9)  
> - Tiler(9)  
> - Tinker(11)  
> - Tinker(3)  
> - Tobacco Merchant(8)  
> - Tobacco Merchant(8)  
> - Town Crier(13)  
> - Town Justice(3)  
> - Toymaker(2)  
> - Toymaker(4)  
> - Trading Post(11)  
> - Troubadours(8)  
> - Tutor(1)  
> - Undertaker(3)  
> - Used Garment Trader(9)  
> - Vestment Maker(5)  
> - Vintner(5)  
> - Wagon Maker(7)  
> - Warehouser(8)  
> - Water Carrier(9)  
> - Weapon Dealer(8)  
> - Weapon Dealer(8)  
> - Weaponsmith(3)  
> - Weaponsmith(3)  
> - Weaver(7)  
> - Wheelwright(10)  
> - Wheelwright(7)  
> - Wine Merchant(4)  
> - Wood Carver(4)  
> - Wood Seller(4)  
> - Wool Merchant(6)  
> - Writer(8)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



