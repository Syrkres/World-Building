---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (13270)
terrain: Glacier 
settlementDescription: 
population: 13270
culture: African 
technology: Crusades 
leader: 
govermentType: Aristocracy 
demographics: 
- Acrobat(23) 
- Minstrel(23) 
- Storyteller(23) 
- Troubadours(23) 
- Writer(23) 
- Advocate(17) 
- Clerk(38) 
- Council Member(34) 
- Diplomat(6) 
- Judge(19) 
- Mayor(1) 
- Alchemist(12) 
- Chandler(34) 
- Dye Makers(34) 
- Florist(12) 
- Herbalist(12) 
- Potionmakers(12) 
- Sage(7) 
- Spice Merchant(23) 
- Taxidermist(23) 
- Tobacco Merchant(23) 
- Animal Groomer(9) 
- Animal Handler(23) 
- Caravanner(17) 
- Horse Trader(27) 
- Livestock Merchant(18) 
- Stabler(24) 
- Antiquities(23) 
- Armor Dealer(23) 
- Launderer(23) 
- Oil Trader(34) 
- Trading Post(34) 
- Slaver(23) 
- Spice Merchant(23) 
- Taxidermist(23) 
- Tobacco Merchant(23) 
- Warehouser(23) 
- Weapon Dealer(23) 
- Architect(27) 
- Bricklayer(27) 
- Engineer(27) 
- Laborer(27) 
- Mason(27) 
- Painter(Building)(27) 
- Plasterer(27) 
- Roofer(27) 
- Teamster(27) 
- Tiler(27) 
- Armorer(7) 
- Blacksmith(32) 
- Bowyer-Fletcher(11) 
- Jeweler(9) 
- Silversmith(8) 
- Weapon Dealer(23) 
- Weaponsmith(7) 
- Artist(30) 
- Glassblower(23) 
- Goldsmith(15) 
- Inventor(19) 
- Jeweler(14) 
- Magical Artisan(7) 
- Painter(Art)(25) 
- Silversmith(19) 
- Tinker(34) 
- Toymaker(11) 
- Astrologist(7) 
- Conjourer(7) 
- High Mage(7) 
- Historian(7) 
- Librarian(7) 
- Magical Artisan(7) 
- Magical Tutor(7) 
- Professor(7) 
- Scribe(7) 
- SellSpell(7) 
- Teacher(7) 
- Tutor(7) 
- Baker(21) 
- Beer Merchant(13) 
- Brewer(4) 
- Butcher(14) 
- Chicken Butcher(14) 
- Cook(14) 
- Dairy Seller(67) 
- Distiller(13) 
- Hay Merchant(67) 
- Fisherman(17) 
- Fishmonger(17) 
- Grain Merchant(4) 
- Grocer(10) 
- Meat Butcher(12) 
- Miller(34) 
- Pastry Maker(17) 
- Vintner(14) 
- Banker(8) 
- Pawnbroker(8) 
- Barbarian(67) 
- Brigand(67) 
- Captain(67) 
- Mountainman(67) 
- Barbarian(13) 
- Cartographer(12) 
- Guide(23) 
- Huntsman(34) 
- Mountainman(11) 
- Pathfinder(12) 
- Scout(12) 
- Slaver(23) 
- Barrel Maker(14) 
- Basket Maker(19) 
- Book Binder(7) 
- Bookseller(7) 
- Buckle Maker(11) 
- Candle Maker(9) 
- Clock Maker(7) 
- Cobbler(21) 
- Cooper(16) 
- Cutler(7) 
- Engraver(7) 
- Furniture Maker(21) 
- Glassblower(10) 
- Glazier(7) 
- Glove Merchant(18) 
- Goldsmith(10) 
- Harness Maker(23) 
- Hat Maker(9) 
- Instrument Maker(7) 
- Kettle Maker(6) 
- Locksmith(8) 
- Perfumer(10) 
- Potter(23) 
- Rope Maker(16) 
- Rug Maker(9) 
- Saddler(17) 
- Sculptor(6) 
- Shoe Maker(16) 
- Soap Maker(12) 
- Tanner(17) 
- Tinker(8) 
- Toymaker(7) 
- Weaponsmith(7) 
- Weaver(19) 
- Wheelwright(30) 
- Wine Merchant(12) 
- Wool Merchant(17) 
- Lord(5) 
- Knight(5) 
- Baron(3) 
- Viscount(2) 
- Earl(2) 
- Count(1) 
- Duke(1) 
- Barrel Maker(25) 
- Bowyer-Fletcher(11) 
- Carpenter(38) 
- Roofer(27) 
- Wagon Maker(19) 
- Wheelwright(21) 
- Wood Carver(11) 
- Wood Seller(10) 
- Barber(12) 
- Bleacher(12) 
- Physic/Chirurgeon(12) 
- Bather(9) 
- Brigand(23) 
- Crime Lord(6) 
- Crook(27) 
- Goon(30) 
- Brothel Keeper(10) 
- Innkeeper(18) 
- Tavern Keeper(25) 
- Buckle Maker(18) 
- Cobbler(16) 
- Draper(11) 
- Furrier(30) 
- Girdler(10) 
- Haberdasher(9) 
- Launderer(18) 
- Leatherworker(13) 
- Purse Maker(12) 
- Shoe Maker(16) 
- Tailor(18) 
- Tanner(17) 
- Used Garment Trader(28) 
- Vestment Maker(16) 
- Chandler(34) 
- Dye Makers(34) 
- Oil Trader(34) 
- Cleric(25) 
- High Priest(10) 
- Missionary(89) 
- Preacher(54) 
- Priest(30) 
- Farmer(664) 
- Homestead(885) 
- Farmer - Cabbage(67) 
- Farmer - Cattle Herder(67) 
- Farmer - Corn(67) 
- Farmer - Cow Herder(67) 
- Farmer - Dairy(67) 
- Farmer - Goat Herder(67) 
- Farmer - Pig Herder(67) 
- Farmer - Potato(67) 
- Farmer - Sheep Herder(67) 
- Farmer - Wheat(67) 
- Farmer(Special)(67) 
- Dungsweeper(19) 
- Illuminator(14) 
- Messenger(21) 
- Tax Collector(4) 
- Town Crier(38) 
- Town Justice(9) 
- Undertaker(8) 
- Water Carrier(27) 
- Leatherworker(14) 
- Skinner(14) 
- Naval Outfitter(7) 
- Pirate(34) 
- Sail Maker(19) 
- Sailor(45) 
- Ship Builder(8) 
imports: 
- Wine  
exports: 
- Marble  
defenses: Stone Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(23)  
> - Advocate(17)  
> - Alchemist(12)  
> - Animal Groomer(9)  
> - Animal Handler(23)  
> - Antiquities(23)  
> - Architect(27)  
> - Armor Dealer(23)  
> - Armorer(7)  
> - Artist(30)  
> - Astrologist(7)  
> - Baker(21)  
> - Banker(8)  
> - Barbarian(13)  
> - Barbarian(67)  
> - Barber(12)  
> - Baron(3)  
> - Barrel Maker(14)  
> - Barrel Maker(25)  
> - Basket Maker(19)  
> - Bather(9)  
> - Beer Merchant(13)  
> - Blacksmith(32)  
> - Bleacher(12)  
> - Book Binder(7)  
> - Bookseller(7)  
> - Bowyer-Fletcher(11)  
> - Bowyer-Fletcher(11)  
> - Brewer(4)  
> - Bricklayer(27)  
> - Brigand(23)  
> - Brigand(67)  
> - Brothel Keeper(10)  
> - Buckle Maker(11)  
> - Buckle Maker(18)  
> - Butcher(14)  
> - Candle Maker(9)  
> - Captain(67)  
> - Caravanner(17)  
> - Carpenter(38)  
> - Cartographer(12)  
> - Chandler(34)  
> - Chandler(34)  
> - Chicken Butcher(14)  
> - Cleric(25)  
> - Clerk(38)  
> - Clock Maker(7)  
> - Cobbler(16)  
> - Cobbler(21)  
> - Conjourer(7)  
> - Cook(14)  
> - Cooper(16)  
> - Council Member(34)  
> - Count(1)  
> - Crime Lord(6)  
> - Crook(27)  
> - Cutler(7)  
> - Dairy Seller(67)  
> - Diplomat(6)  
> - Distiller(13)  
> - Draper(11)  
> - Duke(1)  
> - Dungsweeper(19)  
> - Dye Makers(34)  
> - Dye Makers(34)  
> - Earl(2)  
> - Engineer(27)  
> - Engraver(7)  
> - Farmer - Cabbage(67)  
> - Farmer - Cattle Herder(67)  
> - Farmer - Corn(67)  
> - Farmer - Cow Herder(67)  
> - Farmer - Dairy(67)  
> - Farmer - Goat Herder(67)  
> - Farmer - Pig Herder(67)  
> - Farmer - Potato(67)  
> - Farmer - Sheep Herder(67)  
> - Farmer - Wheat(67)  
> - Farmer(664)  
> - Farmer(Special)(67)  
> - Fisherman(17)  
> - Fishmonger(17)  
> - Florist(12)  
> - Furniture Maker(21)  
> - Furrier(30)  
> - Girdler(10)  
> - Glassblower(10)  
> - Glassblower(23)  
> - Glazier(7)  
> - Glove Merchant(18)  
> - Goldsmith(10)  
> - Goldsmith(15)  
> - Goon(30)  
> - Grain Merchant(4)  
> - Grocer(10)  
> - Guide(23)  
> - Haberdasher(9)  
> - Harness Maker(23)  
> - Hat Maker(9)  
> - Hay Merchant(67)  
> - Herbalist(12)  
> - High Mage(7)  
> - High Priest(10)  
> - Historian(7)  
> - Homestead(885)  
> - Horse Trader(27)  
> - Huntsman(34)  
> - Illuminator(14)  
> - Innkeeper(18)  
> - Instrument Maker(7)  
> - Inventor(19)  
> - Jeweler(14)  
> - Jeweler(9)  
> - Judge(19)  
> - Kettle Maker(6)  
> - Knight(5)  
> - Laborer(27)  
> - Launderer(18)  
> - Launderer(23)  
> - Leatherworker(13)  
> - Leatherworker(14)  
> - Librarian(7)  
> - Livestock Merchant(18)  
> - Locksmith(8)  
> - Lord(5)  
> - Magical Artisan(7)  
> - Magical Artisan(7)  
> - Magical Tutor(7)  
> - Mason(27)  
> - Mayor(1)  
> - Meat Butcher(12)  
> - Messenger(21)  
> - Miller(34)  
> - Minstrel(23)  
> - Missionary(89)  
> - Mountainman(11)  
> - Mountainman(67)  
> - Naval Outfitter(7)  
> - Oil Trader(34)  
> - Oil Trader(34)  
> - Painter(Art)(25)  
> - Painter(Building)(27)  
> - Pastry Maker(17)  
> - Pathfinder(12)  
> - Pawnbroker(8)  
> - Perfumer(10)  
> - Physic/Chirurgeon(12)  
> - Pirate(34)  
> - Plasterer(27)  
> - Potionmakers(12)  
> - Potter(23)  
> - Preacher(54)  
> - Priest(30)  
> - Professor(7)  
> - Purse Maker(12)  
> - Roofer(27)  
> - Roofer(27)  
> - Rope Maker(16)  
> - Rug Maker(9)  
> - Saddler(17)  
> - Sage(7)  
> - Sail Maker(19)  
> - Sailor(45)  
> - Scout(12)  
> - Scribe(7)  
> - Sculptor(6)  
> - SellSpell(7)  
> - Ship Builder(8)  
> - Shoe Maker(16)  
> - Shoe Maker(16)  
> - Silversmith(19)  
> - Silversmith(8)  
> - Skinner(14)  
> - Slaver(23)  
> - Slaver(23)  
> - Soap Maker(12)  
> - Spice Merchant(23)  
> - Spice Merchant(23)  
> - Stabler(24)  
> - Storyteller(23)  
> - Tailor(18)  
> - Tanner(17)  
> - Tanner(17)  
> - Tavern Keeper(25)  
> - Tax Collector(4)  
> - Taxidermist(23)  
> - Taxidermist(23)  
> - Teacher(7)  
> - Teamster(27)  
> - Tiler(27)  
> - Tinker(34)  
> - Tinker(8)  
> - Tobacco Merchant(23)  
> - Tobacco Merchant(23)  
> - Town Crier(38)  
> - Town Justice(9)  
> - Toymaker(11)  
> - Toymaker(7)  
> - Trading Post(34)  
> - Troubadours(23)  
> - Tutor(7)  
> - Undertaker(8)  
> - Used Garment Trader(28)  
> - Vestment Maker(16)  
> - Vintner(14)  
> - Viscount(2)  
> - Wagon Maker(19)  
> - Warehouser(23)  
> - Water Carrier(27)  
> - Weapon Dealer(23)  
> - Weapon Dealer(23)  
> - Weaponsmith(7)  
> - Weaponsmith(7)  
> - Weaver(19)  
> - Wheelwright(21)  
> - Wheelwright(30)  
> - Wine Merchant(12)  
> - Wood Carver(11)  
> - Wood Seller(10)  
> - Wool Merchant(17)  
> - Writer(23)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(23)  
> - Advocate(17)  
> - Alchemist(12)  
> - Animal Groomer(9)  
> - Animal Handler(23)  
> - Antiquities(23)  
> - Architect(27)  
> - Armor Dealer(23)  
> - Armorer(7)  
> - Artist(30)  
> - Astrologist(7)  
> - Baker(21)  
> - Banker(8)  
> - Barbarian(13)  
> - Barbarian(67)  
> - Barber(12)  
> - Baron(3)  
> - Barrel Maker(14)  
> - Barrel Maker(25)  
> - Basket Maker(19)  
> - Bather(9)  
> - Beer Merchant(13)  
> - Blacksmith(32)  
> - Bleacher(12)  
> - Book Binder(7)  
> - Bookseller(7)  
> - Bowyer-Fletcher(11)  
> - Bowyer-Fletcher(11)  
> - Brewer(4)  
> - Bricklayer(27)  
> - Brigand(23)  
> - Brigand(67)  
> - Brothel Keeper(10)  
> - Buckle Maker(11)  
> - Buckle Maker(18)  
> - Butcher(14)  
> - Candle Maker(9)  
> - Captain(67)  
> - Caravanner(17)  
> - Carpenter(38)  
> - Cartographer(12)  
> - Chandler(34)  
> - Chandler(34)  
> - Chicken Butcher(14)  
> - Cleric(25)  
> - Clerk(38)  
> - Clock Maker(7)  
> - Cobbler(16)  
> - Cobbler(21)  
> - Conjourer(7)  
> - Cook(14)  
> - Cooper(16)  
> - Council Member(34)  
> - Count(1)  
> - Crime Lord(6)  
> - Crook(27)  
> - Cutler(7)  
> - Dairy Seller(67)  
> - Diplomat(6)  
> - Distiller(13)  
> - Draper(11)  
> - Duke(1)  
> - Dungsweeper(19)  
> - Dye Makers(34)  
> - Dye Makers(34)  
> - Earl(2)  
> - Engineer(27)  
> - Engraver(7)  
> - Farmer - Cabbage(67)  
> - Farmer - Cattle Herder(67)  
> - Farmer - Corn(67)  
> - Farmer - Cow Herder(67)  
> - Farmer - Dairy(67)  
> - Farmer - Goat Herder(67)  
> - Farmer - Pig Herder(67)  
> - Farmer - Potato(67)  
> - Farmer - Sheep Herder(67)  
> - Farmer - Wheat(67)  
> - Farmer(664)  
> - Farmer(Special)(67)  
> - Fisherman(17)  
> - Fishmonger(17)  
> - Florist(12)  
> - Furniture Maker(21)  
> - Furrier(30)  
> - Girdler(10)  
> - Glassblower(10)  
> - Glassblower(23)  
> - Glazier(7)  
> - Glove Merchant(18)  
> - Goldsmith(10)  
> - Goldsmith(15)  
> - Goon(30)  
> - Grain Merchant(4)  
> - Grocer(10)  
> - Guide(23)  
> - Haberdasher(9)  
> - Harness Maker(23)  
> - Hat Maker(9)  
> - Hay Merchant(67)  
> - Herbalist(12)  
> - High Mage(7)  
> - High Priest(10)  
> - Historian(7)  
> - Homestead(885)  
> - Horse Trader(27)  
> - Huntsman(34)  
> - Illuminator(14)  
> - Innkeeper(18)  
> - Instrument Maker(7)  
> - Inventor(19)  
> - Jeweler(14)  
> - Jeweler(9)  
> - Judge(19)  
> - Kettle Maker(6)  
> - Knight(5)  
> - Laborer(27)  
> - Launderer(18)  
> - Launderer(23)  
> - Leatherworker(13)  
> - Leatherworker(14)  
> - Librarian(7)  
> - Livestock Merchant(18)  
> - Locksmith(8)  
> - Lord(5)  
> - Magical Artisan(7)  
> - Magical Artisan(7)  
> - Magical Tutor(7)  
> - Mason(27)  
> - Mayor(1)  
> - Meat Butcher(12)  
> - Messenger(21)  
> - Miller(34)  
> - Minstrel(23)  
> - Missionary(89)  
> - Mountainman(11)  
> - Mountainman(67)  
> - Naval Outfitter(7)  
> - Oil Trader(34)  
> - Oil Trader(34)  
> - Painter(Art)(25)  
> - Painter(Building)(27)  
> - Pastry Maker(17)  
> - Pathfinder(12)  
> - Pawnbroker(8)  
> - Perfumer(10)  
> - Physic/Chirurgeon(12)  
> - Pirate(34)  
> - Plasterer(27)  
> - Potionmakers(12)  
> - Potter(23)  
> - Preacher(54)  
> - Priest(30)  
> - Professor(7)  
> - Purse Maker(12)  
> - Roofer(27)  
> - Roofer(27)  
> - Rope Maker(16)  
> - Rug Maker(9)  
> - Saddler(17)  
> - Sage(7)  
> - Sail Maker(19)  
> - Sailor(45)  
> - Scout(12)  
> - Scribe(7)  
> - Sculptor(6)  
> - SellSpell(7)  
> - Ship Builder(8)  
> - Shoe Maker(16)  
> - Shoe Maker(16)  
> - Silversmith(19)  
> - Silversmith(8)  
> - Skinner(14)  
> - Slaver(23)  
> - Slaver(23)  
> - Soap Maker(12)  
> - Spice Merchant(23)  
> - Spice Merchant(23)  
> - Stabler(24)  
> - Storyteller(23)  
> - Tailor(18)  
> - Tanner(17)  
> - Tanner(17)  
> - Tavern Keeper(25)  
> - Tax Collector(4)  
> - Taxidermist(23)  
> - Taxidermist(23)  
> - Teacher(7)  
> - Teamster(27)  
> - Tiler(27)  
> - Tinker(34)  
> - Tinker(8)  
> - Tobacco Merchant(23)  
> - Tobacco Merchant(23)  
> - Town Crier(38)  
> - Town Justice(9)  
> - Toymaker(11)  
> - Toymaker(7)  
> - Trading Post(34)  
> - Troubadours(23)  
> - Tutor(7)  
> - Undertaker(8)  
> - Used Garment Trader(28)  
> - Vestment Maker(16)  
> - Vintner(14)  
> - Viscount(2)  
> - Wagon Maker(19)  
> - Warehouser(23)  
> - Water Carrier(27)  
> - Weapon Dealer(23)  
> - Weapon Dealer(23)  
> - Weaponsmith(7)  
> - Weaponsmith(7)  
> - Weaver(19)  
> - Wheelwright(21)  
> - Wheelwright(30)  
> - Wine Merchant(12)  
> - Wood Carver(11)  
> - Wood Seller(10)  
> - Wool Merchant(17)  
> - Writer(23)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



