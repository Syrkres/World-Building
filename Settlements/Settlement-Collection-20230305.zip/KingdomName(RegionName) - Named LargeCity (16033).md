---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (16033)
terrain: Marsh 
settlementDescription: 
population: 16033
culture: Arabic 
technology: Renaissance 
leader: 
govermentType: Democracy 
demographics: 
- Acrobat(27) 
- Minstrel(27) 
- Storyteller(27) 
- Troubadours(27) 
- Writer(27) 
- Advocate(21) 
- Clerk(46) 
- Council Member(41) 
- Diplomat(7) 
- Judge(23) 
- Mayor(1) 
- Alchemist(14) 
- Chandler(41) 
- Dye Makers(41) 
- Florist(14) 
- Herbalist(14) 
- Potionmakers(14) 
- Sage(8) 
- Spice Merchant(27) 
- Taxidermist(27) 
- Tobacco Merchant(27) 
- Animal Groomer(11) 
- Animal Handler(27) 
- Caravanner(21) 
- Horse Trader(33) 
- Livestock Merchant(22) 
- Stabler(29) 
- Antiquities(27) 
- Armor Dealer(27) 
- Launderer(27) 
- Oil Trader(41) 
- Trading Post(41) 
- Slaver(27) 
- Spice Merchant(27) 
- Taxidermist(27) 
- Tobacco Merchant(27) 
- Warehouser(27) 
- Weapon Dealer(27) 
- Architect(33) 
- Bricklayer(33) 
- Engineer(33) 
- Laborer(33) 
- Mason(33) 
- Painter(Building)(33) 
- Plasterer(33) 
- Roofer(33) 
- Teamster(33) 
- Tiler(33) 
- Armorer(9) 
- Blacksmith(38) 
- Bowyer-Fletcher(13) 
- Jeweler(11) 
- Silversmith(10) 
- Weapon Dealer(27) 
- Weaponsmith(8) 
- Artist(36) 
- Glassblower(27) 
- Goldsmith(18) 
- Inventor(23) 
- Jeweler(17) 
- Magical Artisan(8) 
- Painter(Art)(30) 
- Silversmith(23) 
- Tinker(41) 
- Toymaker(13) 
- Astrologist(8) 
- Conjourer(8) 
- High Mage(8) 
- Historian(8) 
- Librarian(8) 
- Magical Artisan(8) 
- Magical Tutor(8) 
- Professor(8) 
- Scribe(8) 
- SellSpell(8) 
- Teacher(8) 
- Tutor(8) 
- Baker(25) 
- Beer Merchant(15) 
- Brewer(4) 
- Butcher(17) 
- Chicken Butcher(17) 
- Cook(17) 
- Dairy Seller(81) 
- Distiller(15) 
- Hay Merchant(81) 
- Fisherman(21) 
- Fishmonger(21) 
- Grain Merchant(5) 
- Grocer(12) 
- Meat Butcher(14) 
- Miller(41) 
- Pastry Maker(21) 
- Vintner(17) 
- Banker(9) 
- Pawnbroker(9) 
- Barbarian(81) 
- Brigand(81) 
- Captain(81) 
- Mountainman(81) 
- Barbarian(15) 
- Cartographer(14) 
- Guide(27) 
- Huntsman(41) 
- Mountainman(13) 
- Pathfinder(14) 
- Scout(14) 
- Slaver(27) 
- Barrel Maker(17) 
- Basket Maker(23) 
- Book Binder(9) 
- Bookseller(8) 
- Buckle Maker(13) 
- Candle Maker(11) 
- Clock Maker(8) 
- Cobbler(25) 
- Cooper(19) 
- Cutler(9) 
- Engraver(8) 
- Furniture Maker(25) 
- Glassblower(12) 
- Glazier(8) 
- Glove Merchant(22) 
- Goldsmith(12) 
- Harness Maker(27) 
- Hat Maker(11) 
- Instrument Maker(8) 
- Kettle Maker(7) 
- Locksmith(10) 
- Perfumer(12) 
- Potter(27) 
- Rope Maker(19) 
- Rug Maker(10) 
- Saddler(21) 
- Sculptor(7) 
- Shoe Maker(19) 
- Soap Maker(14) 
- Tanner(21) 
- Tinker(9) 
- Toymaker(8) 
- Weaponsmith(8) 
- Weaver(23) 
- Wheelwright(36) 
- Wine Merchant(14) 
- Wool Merchant(21) 
- Lord(6) 
- Knight(6) 
- Baron(4) 
- Viscount(3) 
- Earl(2) 
- Count(2) 
- Duke(1) 
- Barrel Maker(30) 
- Bowyer-Fletcher(13) 
- Carpenter(46) 
- Roofer(33) 
- Wagon Maker(23) 
- Wheelwright(25) 
- Wood Carver(13) 
- Wood Seller(12) 
- Barber(14) 
- Bleacher(14) 
- Physic/Chirurgeon(14) 
- Bather(11) 
- Brigand(27) 
- Crime Lord(7) 
- Crook(33) 
- Goon(36) 
- Brothel Keeper(12) 
- Innkeeper(22) 
- Tavern Keeper(30) 
- Buckle Maker(22) 
- Cobbler(19) 
- Draper(14) 
- Furrier(36) 
- Girdler(12) 
- Haberdasher(11) 
- Launderer(22) 
- Leatherworker(15) 
- Purse Maker(14) 
- Shoe Maker(19) 
- Tailor(22) 
- Tanner(21) 
- Used Garment Trader(34) 
- Vestment Maker(19) 
- Chandler(41) 
- Dye Makers(41) 
- Oil Trader(41) 
- Cleric(30) 
- High Priest(12) 
- Missionary(107) 
- Preacher(65) 
- Priest(36) 
- Farmer(802) 
- Homestead(1069) 
- Farmer - Cabbage(81) 
- Farmer - Cattle Herder(81) 
- Farmer - Corn(81) 
- Farmer - Cow Herder(81) 
- Farmer - Dairy(81) 
- Farmer - Goat Herder(81) 
- Farmer - Pig Herder(81) 
- Farmer - Potato(81) 
- Farmer - Sheep Herder(81) 
- Farmer - Wheat(81) 
- Farmer(Special)(81) 
- Dungsweeper(23) 
- Illuminator(17) 
- Messenger(25) 
- Tax Collector(5) 
- Town Crier(46) 
- Town Justice(11) 
- Undertaker(9) 
- Water Carrier(33) 
- Leatherworker(17) 
- Skinner(17) 
- Naval Outfitter(9) 
- Pirate(41) 
- Sail Maker(23) 
- Sailor(54) 
- Ship Builder(10) 
imports: 
- Beeswax  
exports: 
- Grease  
defenses: Keeps 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(27)  
> - Advocate(21)  
> - Alchemist(14)  
> - Animal Groomer(11)  
> - Animal Handler(27)  
> - Antiquities(27)  
> - Architect(33)  
> - Armor Dealer(27)  
> - Armorer(9)  
> - Artist(36)  
> - Astrologist(8)  
> - Baker(25)  
> - Banker(9)  
> - Barbarian(15)  
> - Barbarian(81)  
> - Barber(14)  
> - Baron(4)  
> - Barrel Maker(17)  
> - Barrel Maker(30)  
> - Basket Maker(23)  
> - Bather(11)  
> - Beer Merchant(15)  
> - Blacksmith(38)  
> - Bleacher(14)  
> - Book Binder(9)  
> - Bookseller(8)  
> - Bowyer-Fletcher(13)  
> - Bowyer-Fletcher(13)  
> - Brewer(4)  
> - Bricklayer(33)  
> - Brigand(27)  
> - Brigand(81)  
> - Brothel Keeper(12)  
> - Buckle Maker(13)  
> - Buckle Maker(22)  
> - Butcher(17)  
> - Candle Maker(11)  
> - Captain(81)  
> - Caravanner(21)  
> - Carpenter(46)  
> - Cartographer(14)  
> - Chandler(41)  
> - Chandler(41)  
> - Chicken Butcher(17)  
> - Cleric(30)  
> - Clerk(46)  
> - Clock Maker(8)  
> - Cobbler(19)  
> - Cobbler(25)  
> - Conjourer(8)  
> - Cook(17)  
> - Cooper(19)  
> - Council Member(41)  
> - Count(2)  
> - Crime Lord(7)  
> - Crook(33)  
> - Cutler(9)  
> - Dairy Seller(81)  
> - Diplomat(7)  
> - Distiller(15)  
> - Draper(14)  
> - Duke(1)  
> - Dungsweeper(23)  
> - Dye Makers(41)  
> - Dye Makers(41)  
> - Earl(2)  
> - Engineer(33)  
> - Engraver(8)  
> - Farmer - Cabbage(81)  
> - Farmer - Cattle Herder(81)  
> - Farmer - Corn(81)  
> - Farmer - Cow Herder(81)  
> - Farmer - Dairy(81)  
> - Farmer - Goat Herder(81)  
> - Farmer - Pig Herder(81)  
> - Farmer - Potato(81)  
> - Farmer - Sheep Herder(81)  
> - Farmer - Wheat(81)  
> - Farmer(802)  
> - Farmer(Special)(81)  
> - Fisherman(21)  
> - Fishmonger(21)  
> - Florist(14)  
> - Furniture Maker(25)  
> - Furrier(36)  
> - Girdler(12)  
> - Glassblower(12)  
> - Glassblower(27)  
> - Glazier(8)  
> - Glove Merchant(22)  
> - Goldsmith(12)  
> - Goldsmith(18)  
> - Goon(36)  
> - Grain Merchant(5)  
> - Grocer(12)  
> - Guide(27)  
> - Haberdasher(11)  
> - Harness Maker(27)  
> - Hat Maker(11)  
> - Hay Merchant(81)  
> - Herbalist(14)  
> - High Mage(8)  
> - High Priest(12)  
> - Historian(8)  
> - Homestead(1069)  
> - Horse Trader(33)  
> - Huntsman(41)  
> - Illuminator(17)  
> - Innkeeper(22)  
> - Instrument Maker(8)  
> - Inventor(23)  
> - Jeweler(11)  
> - Jeweler(17)  
> - Judge(23)  
> - Kettle Maker(7)  
> - Knight(6)  
> - Laborer(33)  
> - Launderer(22)  
> - Launderer(27)  
> - Leatherworker(15)  
> - Leatherworker(17)  
> - Librarian(8)  
> - Livestock Merchant(22)  
> - Locksmith(10)  
> - Lord(6)  
> - Magical Artisan(8)  
> - Magical Artisan(8)  
> - Magical Tutor(8)  
> - Mason(33)  
> - Mayor(1)  
> - Meat Butcher(14)  
> - Messenger(25)  
> - Miller(41)  
> - Minstrel(27)  
> - Missionary(107)  
> - Mountainman(13)  
> - Mountainman(81)  
> - Naval Outfitter(9)  
> - Oil Trader(41)  
> - Oil Trader(41)  
> - Painter(Art)(30)  
> - Painter(Building)(33)  
> - Pastry Maker(21)  
> - Pathfinder(14)  
> - Pawnbroker(9)  
> - Perfumer(12)  
> - Physic/Chirurgeon(14)  
> - Pirate(41)  
> - Plasterer(33)  
> - Potionmakers(14)  
> - Potter(27)  
> - Preacher(65)  
> - Priest(36)  
> - Professor(8)  
> - Purse Maker(14)  
> - Roofer(33)  
> - Roofer(33)  
> - Rope Maker(19)  
> - Rug Maker(10)  
> - Saddler(21)  
> - Sage(8)  
> - Sail Maker(23)  
> - Sailor(54)  
> - Scout(14)  
> - Scribe(8)  
> - Sculptor(7)  
> - SellSpell(8)  
> - Ship Builder(10)  
> - Shoe Maker(19)  
> - Shoe Maker(19)  
> - Silversmith(10)  
> - Silversmith(23)  
> - Skinner(17)  
> - Slaver(27)  
> - Slaver(27)  
> - Soap Maker(14)  
> - Spice Merchant(27)  
> - Spice Merchant(27)  
> - Stabler(29)  
> - Storyteller(27)  
> - Tailor(22)  
> - Tanner(21)  
> - Tanner(21)  
> - Tavern Keeper(30)  
> - Tax Collector(5)  
> - Taxidermist(27)  
> - Taxidermist(27)  
> - Teacher(8)  
> - Teamster(33)  
> - Tiler(33)  
> - Tinker(41)  
> - Tinker(9)  
> - Tobacco Merchant(27)  
> - Tobacco Merchant(27)  
> - Town Crier(46)  
> - Town Justice(11)  
> - Toymaker(13)  
> - Toymaker(8)  
> - Trading Post(41)  
> - Troubadours(27)  
> - Tutor(8)  
> - Undertaker(9)  
> - Used Garment Trader(34)  
> - Vestment Maker(19)  
> - Vintner(17)  
> - Viscount(3)  
> - Wagon Maker(23)  
> - Warehouser(27)  
> - Water Carrier(33)  
> - Weapon Dealer(27)  
> - Weapon Dealer(27)  
> - Weaponsmith(8)  
> - Weaponsmith(8)  
> - Weaver(23)  
> - Wheelwright(25)  
> - Wheelwright(36)  
> - Wine Merchant(14)  
> - Wood Carver(13)  
> - Wood Seller(12)  
> - Wool Merchant(21)  
> - Writer(27)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(27)  
> - Advocate(21)  
> - Alchemist(14)  
> - Animal Groomer(11)  
> - Animal Handler(27)  
> - Antiquities(27)  
> - Architect(33)  
> - Armor Dealer(27)  
> - Armorer(9)  
> - Artist(36)  
> - Astrologist(8)  
> - Baker(25)  
> - Banker(9)  
> - Barbarian(15)  
> - Barbarian(81)  
> - Barber(14)  
> - Baron(4)  
> - Barrel Maker(17)  
> - Barrel Maker(30)  
> - Basket Maker(23)  
> - Bather(11)  
> - Beer Merchant(15)  
> - Blacksmith(38)  
> - Bleacher(14)  
> - Book Binder(9)  
> - Bookseller(8)  
> - Bowyer-Fletcher(13)  
> - Bowyer-Fletcher(13)  
> - Brewer(4)  
> - Bricklayer(33)  
> - Brigand(27)  
> - Brigand(81)  
> - Brothel Keeper(12)  
> - Buckle Maker(13)  
> - Buckle Maker(22)  
> - Butcher(17)  
> - Candle Maker(11)  
> - Captain(81)  
> - Caravanner(21)  
> - Carpenter(46)  
> - Cartographer(14)  
> - Chandler(41)  
> - Chandler(41)  
> - Chicken Butcher(17)  
> - Cleric(30)  
> - Clerk(46)  
> - Clock Maker(8)  
> - Cobbler(19)  
> - Cobbler(25)  
> - Conjourer(8)  
> - Cook(17)  
> - Cooper(19)  
> - Council Member(41)  
> - Count(2)  
> - Crime Lord(7)  
> - Crook(33)  
> - Cutler(9)  
> - Dairy Seller(81)  
> - Diplomat(7)  
> - Distiller(15)  
> - Draper(14)  
> - Duke(1)  
> - Dungsweeper(23)  
> - Dye Makers(41)  
> - Dye Makers(41)  
> - Earl(2)  
> - Engineer(33)  
> - Engraver(8)  
> - Farmer - Cabbage(81)  
> - Farmer - Cattle Herder(81)  
> - Farmer - Corn(81)  
> - Farmer - Cow Herder(81)  
> - Farmer - Dairy(81)  
> - Farmer - Goat Herder(81)  
> - Farmer - Pig Herder(81)  
> - Farmer - Potato(81)  
> - Farmer - Sheep Herder(81)  
> - Farmer - Wheat(81)  
> - Farmer(802)  
> - Farmer(Special)(81)  
> - Fisherman(21)  
> - Fishmonger(21)  
> - Florist(14)  
> - Furniture Maker(25)  
> - Furrier(36)  
> - Girdler(12)  
> - Glassblower(12)  
> - Glassblower(27)  
> - Glazier(8)  
> - Glove Merchant(22)  
> - Goldsmith(12)  
> - Goldsmith(18)  
> - Goon(36)  
> - Grain Merchant(5)  
> - Grocer(12)  
> - Guide(27)  
> - Haberdasher(11)  
> - Harness Maker(27)  
> - Hat Maker(11)  
> - Hay Merchant(81)  
> - Herbalist(14)  
> - High Mage(8)  
> - High Priest(12)  
> - Historian(8)  
> - Homestead(1069)  
> - Horse Trader(33)  
> - Huntsman(41)  
> - Illuminator(17)  
> - Innkeeper(22)  
> - Instrument Maker(8)  
> - Inventor(23)  
> - Jeweler(11)  
> - Jeweler(17)  
> - Judge(23)  
> - Kettle Maker(7)  
> - Knight(6)  
> - Laborer(33)  
> - Launderer(22)  
> - Launderer(27)  
> - Leatherworker(15)  
> - Leatherworker(17)  
> - Librarian(8)  
> - Livestock Merchant(22)  
> - Locksmith(10)  
> - Lord(6)  
> - Magical Artisan(8)  
> - Magical Artisan(8)  
> - Magical Tutor(8)  
> - Mason(33)  
> - Mayor(1)  
> - Meat Butcher(14)  
> - Messenger(25)  
> - Miller(41)  
> - Minstrel(27)  
> - Missionary(107)  
> - Mountainman(13)  
> - Mountainman(81)  
> - Naval Outfitter(9)  
> - Oil Trader(41)  
> - Oil Trader(41)  
> - Painter(Art)(30)  
> - Painter(Building)(33)  
> - Pastry Maker(21)  
> - Pathfinder(14)  
> - Pawnbroker(9)  
> - Perfumer(12)  
> - Physic/Chirurgeon(14)  
> - Pirate(41)  
> - Plasterer(33)  
> - Potionmakers(14)  
> - Potter(27)  
> - Preacher(65)  
> - Priest(36)  
> - Professor(8)  
> - Purse Maker(14)  
> - Roofer(33)  
> - Roofer(33)  
> - Rope Maker(19)  
> - Rug Maker(10)  
> - Saddler(21)  
> - Sage(8)  
> - Sail Maker(23)  
> - Sailor(54)  
> - Scout(14)  
> - Scribe(8)  
> - Sculptor(7)  
> - SellSpell(8)  
> - Ship Builder(10)  
> - Shoe Maker(19)  
> - Shoe Maker(19)  
> - Silversmith(10)  
> - Silversmith(23)  
> - Skinner(17)  
> - Slaver(27)  
> - Slaver(27)  
> - Soap Maker(14)  
> - Spice Merchant(27)  
> - Spice Merchant(27)  
> - Stabler(29)  
> - Storyteller(27)  
> - Tailor(22)  
> - Tanner(21)  
> - Tanner(21)  
> - Tavern Keeper(30)  
> - Tax Collector(5)  
> - Taxidermist(27)  
> - Taxidermist(27)  
> - Teacher(8)  
> - Teamster(33)  
> - Tiler(33)  
> - Tinker(41)  
> - Tinker(9)  
> - Tobacco Merchant(27)  
> - Tobacco Merchant(27)  
> - Town Crier(46)  
> - Town Justice(11)  
> - Toymaker(13)  
> - Toymaker(8)  
> - Trading Post(41)  
> - Troubadours(27)  
> - Tutor(8)  
> - Undertaker(9)  
> - Used Garment Trader(34)  
> - Vestment Maker(19)  
> - Vintner(17)  
> - Viscount(3)  
> - Wagon Maker(23)  
> - Warehouser(27)  
> - Water Carrier(33)  
> - Weapon Dealer(27)  
> - Weapon Dealer(27)  
> - Weaponsmith(8)  
> - Weaponsmith(8)  
> - Weaver(23)  
> - Wheelwright(25)  
> - Wheelwright(36)  
> - Wine Merchant(14)  
> - Wood Carver(13)  
> - Wood Seller(12)  
> - Wool Merchant(21)  
> - Writer(27)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



