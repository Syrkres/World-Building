---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallCity
kingdom: KingdomName
region: RegionName
settlementName: Named SmallCity (10775)
terrain: Mountain Forest Boreal 
settlementDescription: 
population: 10775
culture: Incan 
technology: Dark Ages 
leader: 
govermentType: Theocracy 
demographics: 
- Acrobat(18) 
- Minstrel(18) 
- Storyteller(18) 
- Troubadours(18) 
- Writer(18) 
- Advocate(14) 
- Clerk(31) 
- Council Member(27) 
- Diplomat(5) 
- Judge(16) 
- Mayor(1) 
- Alchemist(9) 
- Chandler(27) 
- Dye Makers(27) 
- Florist(9) 
- Herbalist(9) 
- Potionmakers(9) 
- Sage(5) 
- Spice Merchant(18) 
- Taxidermist(18) 
- Tobacco Merchant(18) 
- Animal Groomer(8) 
- Animal Handler(18) 
- Caravanner(14) 
- Horse Trader(22) 
- Livestock Merchant(15) 
- Stabler(20) 
- Antiquities(18) 
- Armor Dealer(18) 
- Launderer(18) 
- Oil Trader(27) 
- Trading Post(27) 
- Slaver(18) 
- Spice Merchant(18) 
- Taxidermist(18) 
- Tobacco Merchant(18) 
- Warehouser(18) 
- Weapon Dealer(18) 
- Architect(22) 
- Bricklayer(22) 
- Engineer(22) 
- Laborer(22) 
- Mason(22) 
- Painter(Building)(22) 
- Plasterer(22) 
- Roofer(22) 
- Teamster(22) 
- Tiler(22) 
- Armorer(6) 
- Blacksmith(26) 
- Bowyer-Fletcher(9) 
- Jeweler(7) 
- Silversmith(7) 
- Weapon Dealer(18) 
- Weaponsmith(6) 
- Artist(24) 
- Glassblower(18) 
- Goldsmith(12) 
- Inventor(16) 
- Jeweler(11) 
- Magical Artisan(5) 
- Painter(Art)(20) 
- Silversmith(16) 
- Tinker(27) 
- Toymaker(9) 
- Astrologist(5) 
- Conjourer(5) 
- High Mage(5) 
- Historian(5) 
- Librarian(5) 
- Magical Artisan(5) 
- Magical Tutor(5) 
- Professor(5) 
- Scribe(5) 
- SellSpell(5) 
- Teacher(5) 
- Tutor(5) 
- Baker(17) 
- Beer Merchant(10) 
- Brewer(3) 
- Butcher(11) 
- Chicken Butcher(11) 
- Cook(12) 
- Dairy Seller(54) 
- Distiller(10) 
- Hay Merchant(54) 
- Fisherman(14) 
- Fishmonger(14) 
- Grain Merchant(3) 
- Grocer(8) 
- Meat Butcher(9) 
- Miller(27) 
- Pastry Maker(14) 
- Vintner(12) 
- Banker(6) 
- Pawnbroker(6) 
- Barbarian(54) 
- Brigand(54) 
- Captain(54) 
- Mountainman(54) 
- Barbarian(10) 
- Cartographer(9) 
- Guide(18) 
- Huntsman(27) 
- Mountainman(9) 
- Pathfinder(9) 
- Scout(9) 
- Slaver(18) 
- Barrel Maker(12) 
- Basket Maker(16) 
- Book Binder(6) 
- Bookseller(6) 
- Buckle Maker(9) 
- Candle Maker(7) 
- Clock Maker(5) 
- Cobbler(17) 
- Cooper(13) 
- Cutler(6) 
- Engraver(5) 
- Furniture Maker(17) 
- Glassblower(8) 
- Glazier(6) 
- Glove Merchant(15) 
- Goldsmith(8) 
- Harness Maker(18) 
- Hat Maker(8) 
- Instrument Maker(5) 
- Kettle Maker(5) 
- Locksmith(7) 
- Perfumer(8) 
- Potter(18) 
- Rope Maker(13) 
- Rug Maker(7) 
- Saddler(14) 
- Sculptor(5) 
- Shoe Maker(13) 
- Soap Maker(9) 
- Tanner(14) 
- Tinker(6) 
- Toymaker(5) 
- Weaponsmith(6) 
- Weaver(16) 
- Wheelwright(24) 
- Wine Merchant(9) 
- Wool Merchant(14) 
- Lord(4) 
- Knight(4) 
- Baron(3) 
- Viscount(2) 
- Earl(1) 
- Count(1) 
- Duke(1) 
- Barrel Maker(20) 
- Bowyer-Fletcher(9) 
- Carpenter(31) 
- Roofer(22) 
- Wagon Maker(16) 
- Wheelwright(17) 
- Wood Carver(9) 
- Wood Seller(8) 
- Barber(9) 
- Bleacher(9) 
- Physic/Chirurgeon(9) 
- Bather(8) 
- Brigand(18) 
- Crime Lord(5) 
- Crook(22) 
- Goon(24) 
- Brothel Keeper(8) 
- Innkeeper(15) 
- Tavern Keeper(20) 
- Buckle Maker(15) 
- Cobbler(13) 
- Draper(9) 
- Furrier(24) 
- Girdler(8) 
- Haberdasher(7) 
- Launderer(15) 
- Leatherworker(10) 
- Purse Maker(9) 
- Shoe Maker(13) 
- Tailor(15) 
- Tanner(14) 
- Used Garment Trader(23) 
- Vestment Maker(13) 
- Chandler(27) 
- Dye Makers(27) 
- Oil Trader(27) 
- Cleric(20) 
- High Priest(8) 
- Missionary(72) 
- Preacher(44) 
- Priest(24) 
- Farmer(539) 
- Homestead(719) 
- Farmer - Cabbage(54) 
- Farmer - Cattle Herder(54) 
- Farmer - Corn(54) 
- Farmer - Cow Herder(54) 
- Farmer - Dairy(54) 
- Farmer - Goat Herder(54) 
- Farmer - Pig Herder(54) 
- Farmer - Potato(54) 
- Farmer - Sheep Herder(54) 
- Farmer - Wheat(54) 
- Farmer(Special)(54) 
- Dungsweeper(16) 
- Illuminator(11) 
- Messenger(17) 
- Tax Collector(3) 
- Town Crier(31) 
- Town Justice(8) 
- Undertaker(6) 
- Water Carrier(22) 
- Leatherworker(11) 
- Skinner(11) 
- Naval Outfitter(6) 
- Pirate(27) 
- Sail Maker(16) 
- Sailor(36) 
- Ship Builder(7) 
imports: 
- Silicates  
exports: 
- Perls  
defenses: Killing Fields 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(18)  
> - Advocate(14)  
> - Alchemist(9)  
> - Animal Groomer(8)  
> - Animal Handler(18)  
> - Antiquities(18)  
> - Architect(22)  
> - Armor Dealer(18)  
> - Armorer(6)  
> - Artist(24)  
> - Astrologist(5)  
> - Baker(17)  
> - Banker(6)  
> - Barbarian(10)  
> - Barbarian(54)  
> - Barber(9)  
> - Baron(3)  
> - Barrel Maker(12)  
> - Barrel Maker(20)  
> - Basket Maker(16)  
> - Bather(8)  
> - Beer Merchant(10)  
> - Blacksmith(26)  
> - Bleacher(9)  
> - Book Binder(6)  
> - Bookseller(6)  
> - Bowyer-Fletcher(9)  
> - Bowyer-Fletcher(9)  
> - Brewer(3)  
> - Bricklayer(22)  
> - Brigand(18)  
> - Brigand(54)  
> - Brothel Keeper(8)  
> - Buckle Maker(15)  
> - Buckle Maker(9)  
> - Butcher(11)  
> - Candle Maker(7)  
> - Captain(54)  
> - Caravanner(14)  
> - Carpenter(31)  
> - Cartographer(9)  
> - Chandler(27)  
> - Chandler(27)  
> - Chicken Butcher(11)  
> - Cleric(20)  
> - Clerk(31)  
> - Clock Maker(5)  
> - Cobbler(13)  
> - Cobbler(17)  
> - Conjourer(5)  
> - Cook(12)  
> - Cooper(13)  
> - Council Member(27)  
> - Count(1)  
> - Crime Lord(5)  
> - Crook(22)  
> - Cutler(6)  
> - Dairy Seller(54)  
> - Diplomat(5)  
> - Distiller(10)  
> - Draper(9)  
> - Duke(1)  
> - Dungsweeper(16)  
> - Dye Makers(27)  
> - Dye Makers(27)  
> - Earl(1)  
> - Engineer(22)  
> - Engraver(5)  
> - Farmer - Cabbage(54)  
> - Farmer - Cattle Herder(54)  
> - Farmer - Corn(54)  
> - Farmer - Cow Herder(54)  
> - Farmer - Dairy(54)  
> - Farmer - Goat Herder(54)  
> - Farmer - Pig Herder(54)  
> - Farmer - Potato(54)  
> - Farmer - Sheep Herder(54)  
> - Farmer - Wheat(54)  
> - Farmer(539)  
> - Farmer(Special)(54)  
> - Fisherman(14)  
> - Fishmonger(14)  
> - Florist(9)  
> - Furniture Maker(17)  
> - Furrier(24)  
> - Girdler(8)  
> - Glassblower(18)  
> - Glassblower(8)  
> - Glazier(6)  
> - Glove Merchant(15)  
> - Goldsmith(12)  
> - Goldsmith(8)  
> - Goon(24)  
> - Grain Merchant(3)  
> - Grocer(8)  
> - Guide(18)  
> - Haberdasher(7)  
> - Harness Maker(18)  
> - Hat Maker(8)  
> - Hay Merchant(54)  
> - Herbalist(9)  
> - High Mage(5)  
> - High Priest(8)  
> - Historian(5)  
> - Homestead(719)  
> - Horse Trader(22)  
> - Huntsman(27)  
> - Illuminator(11)  
> - Innkeeper(15)  
> - Instrument Maker(5)  
> - Inventor(16)  
> - Jeweler(11)  
> - Jeweler(7)  
> - Judge(16)  
> - Kettle Maker(5)  
> - Knight(4)  
> - Laborer(22)  
> - Launderer(15)  
> - Launderer(18)  
> - Leatherworker(10)  
> - Leatherworker(11)  
> - Librarian(5)  
> - Livestock Merchant(15)  
> - Locksmith(7)  
> - Lord(4)  
> - Magical Artisan(5)  
> - Magical Artisan(5)  
> - Magical Tutor(5)  
> - Mason(22)  
> - Mayor(1)  
> - Meat Butcher(9)  
> - Messenger(17)  
> - Miller(27)  
> - Minstrel(18)  
> - Missionary(72)  
> - Mountainman(54)  
> - Mountainman(9)  
> - Naval Outfitter(6)  
> - Oil Trader(27)  
> - Oil Trader(27)  
> - Painter(Art)(20)  
> - Painter(Building)(22)  
> - Pastry Maker(14)  
> - Pathfinder(9)  
> - Pawnbroker(6)  
> - Perfumer(8)  
> - Physic/Chirurgeon(9)  
> - Pirate(27)  
> - Plasterer(22)  
> - Potionmakers(9)  
> - Potter(18)  
> - Preacher(44)  
> - Priest(24)  
> - Professor(5)  
> - Purse Maker(9)  
> - Roofer(22)  
> - Roofer(22)  
> - Rope Maker(13)  
> - Rug Maker(7)  
> - Saddler(14)  
> - Sage(5)  
> - Sail Maker(16)  
> - Sailor(36)  
> - Scout(9)  
> - Scribe(5)  
> - Sculptor(5)  
> - SellSpell(5)  
> - Ship Builder(7)  
> - Shoe Maker(13)  
> - Shoe Maker(13)  
> - Silversmith(16)  
> - Silversmith(7)  
> - Skinner(11)  
> - Slaver(18)  
> - Slaver(18)  
> - Soap Maker(9)  
> - Spice Merchant(18)  
> - Spice Merchant(18)  
> - Stabler(20)  
> - Storyteller(18)  
> - Tailor(15)  
> - Tanner(14)  
> - Tanner(14)  
> - Tavern Keeper(20)  
> - Tax Collector(3)  
> - Taxidermist(18)  
> - Taxidermist(18)  
> - Teacher(5)  
> - Teamster(22)  
> - Tiler(22)  
> - Tinker(27)  
> - Tinker(6)  
> - Tobacco Merchant(18)  
> - Tobacco Merchant(18)  
> - Town Crier(31)  
> - Town Justice(8)  
> - Toymaker(5)  
> - Toymaker(9)  
> - Trading Post(27)  
> - Troubadours(18)  
> - Tutor(5)  
> - Undertaker(6)  
> - Used Garment Trader(23)  
> - Vestment Maker(13)  
> - Vintner(12)  
> - Viscount(2)  
> - Wagon Maker(16)  
> - Warehouser(18)  
> - Water Carrier(22)  
> - Weapon Dealer(18)  
> - Weapon Dealer(18)  
> - Weaponsmith(6)  
> - Weaponsmith(6)  
> - Weaver(16)  
> - Wheelwright(17)  
> - Wheelwright(24)  
> - Wine Merchant(9)  
> - Wood Carver(9)  
> - Wood Seller(8)  
> - Wool Merchant(14)  
> - Writer(18)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(18)  
> - Advocate(14)  
> - Alchemist(9)  
> - Animal Groomer(8)  
> - Animal Handler(18)  
> - Antiquities(18)  
> - Architect(22)  
> - Armor Dealer(18)  
> - Armorer(6)  
> - Artist(24)  
> - Astrologist(5)  
> - Baker(17)  
> - Banker(6)  
> - Barbarian(10)  
> - Barbarian(54)  
> - Barber(9)  
> - Baron(3)  
> - Barrel Maker(12)  
> - Barrel Maker(20)  
> - Basket Maker(16)  
> - Bather(8)  
> - Beer Merchant(10)  
> - Blacksmith(26)  
> - Bleacher(9)  
> - Book Binder(6)  
> - Bookseller(6)  
> - Bowyer-Fletcher(9)  
> - Bowyer-Fletcher(9)  
> - Brewer(3)  
> - Bricklayer(22)  
> - Brigand(18)  
> - Brigand(54)  
> - Brothel Keeper(8)  
> - Buckle Maker(15)  
> - Buckle Maker(9)  
> - Butcher(11)  
> - Candle Maker(7)  
> - Captain(54)  
> - Caravanner(14)  
> - Carpenter(31)  
> - Cartographer(9)  
> - Chandler(27)  
> - Chandler(27)  
> - Chicken Butcher(11)  
> - Cleric(20)  
> - Clerk(31)  
> - Clock Maker(5)  
> - Cobbler(13)  
> - Cobbler(17)  
> - Conjourer(5)  
> - Cook(12)  
> - Cooper(13)  
> - Council Member(27)  
> - Count(1)  
> - Crime Lord(5)  
> - Crook(22)  
> - Cutler(6)  
> - Dairy Seller(54)  
> - Diplomat(5)  
> - Distiller(10)  
> - Draper(9)  
> - Duke(1)  
> - Dungsweeper(16)  
> - Dye Makers(27)  
> - Dye Makers(27)  
> - Earl(1)  
> - Engineer(22)  
> - Engraver(5)  
> - Farmer - Cabbage(54)  
> - Farmer - Cattle Herder(54)  
> - Farmer - Corn(54)  
> - Farmer - Cow Herder(54)  
> - Farmer - Dairy(54)  
> - Farmer - Goat Herder(54)  
> - Farmer - Pig Herder(54)  
> - Farmer - Potato(54)  
> - Farmer - Sheep Herder(54)  
> - Farmer - Wheat(54)  
> - Farmer(539)  
> - Farmer(Special)(54)  
> - Fisherman(14)  
> - Fishmonger(14)  
> - Florist(9)  
> - Furniture Maker(17)  
> - Furrier(24)  
> - Girdler(8)  
> - Glassblower(18)  
> - Glassblower(8)  
> - Glazier(6)  
> - Glove Merchant(15)  
> - Goldsmith(12)  
> - Goldsmith(8)  
> - Goon(24)  
> - Grain Merchant(3)  
> - Grocer(8)  
> - Guide(18)  
> - Haberdasher(7)  
> - Harness Maker(18)  
> - Hat Maker(8)  
> - Hay Merchant(54)  
> - Herbalist(9)  
> - High Mage(5)  
> - High Priest(8)  
> - Historian(5)  
> - Homestead(719)  
> - Horse Trader(22)  
> - Huntsman(27)  
> - Illuminator(11)  
> - Innkeeper(15)  
> - Instrument Maker(5)  
> - Inventor(16)  
> - Jeweler(11)  
> - Jeweler(7)  
> - Judge(16)  
> - Kettle Maker(5)  
> - Knight(4)  
> - Laborer(22)  
> - Launderer(15)  
> - Launderer(18)  
> - Leatherworker(10)  
> - Leatherworker(11)  
> - Librarian(5)  
> - Livestock Merchant(15)  
> - Locksmith(7)  
> - Lord(4)  
> - Magical Artisan(5)  
> - Magical Artisan(5)  
> - Magical Tutor(5)  
> - Mason(22)  
> - Mayor(1)  
> - Meat Butcher(9)  
> - Messenger(17)  
> - Miller(27)  
> - Minstrel(18)  
> - Missionary(72)  
> - Mountainman(54)  
> - Mountainman(9)  
> - Naval Outfitter(6)  
> - Oil Trader(27)  
> - Oil Trader(27)  
> - Painter(Art)(20)  
> - Painter(Building)(22)  
> - Pastry Maker(14)  
> - Pathfinder(9)  
> - Pawnbroker(6)  
> - Perfumer(8)  
> - Physic/Chirurgeon(9)  
> - Pirate(27)  
> - Plasterer(22)  
> - Potionmakers(9)  
> - Potter(18)  
> - Preacher(44)  
> - Priest(24)  
> - Professor(5)  
> - Purse Maker(9)  
> - Roofer(22)  
> - Roofer(22)  
> - Rope Maker(13)  
> - Rug Maker(7)  
> - Saddler(14)  
> - Sage(5)  
> - Sail Maker(16)  
> - Sailor(36)  
> - Scout(9)  
> - Scribe(5)  
> - Sculptor(5)  
> - SellSpell(5)  
> - Ship Builder(7)  
> - Shoe Maker(13)  
> - Shoe Maker(13)  
> - Silversmith(16)  
> - Silversmith(7)  
> - Skinner(11)  
> - Slaver(18)  
> - Slaver(18)  
> - Soap Maker(9)  
> - Spice Merchant(18)  
> - Spice Merchant(18)  
> - Stabler(20)  
> - Storyteller(18)  
> - Tailor(15)  
> - Tanner(14)  
> - Tanner(14)  
> - Tavern Keeper(20)  
> - Tax Collector(3)  
> - Taxidermist(18)  
> - Taxidermist(18)  
> - Teacher(5)  
> - Teamster(22)  
> - Tiler(22)  
> - Tinker(27)  
> - Tinker(6)  
> - Tobacco Merchant(18)  
> - Tobacco Merchant(18)  
> - Town Crier(31)  
> - Town Justice(8)  
> - Toymaker(5)  
> - Toymaker(9)  
> - Trading Post(27)  
> - Troubadours(18)  
> - Tutor(5)  
> - Undertaker(6)  
> - Used Garment Trader(23)  
> - Vestment Maker(13)  
> - Vintner(12)  
> - Viscount(2)  
> - Wagon Maker(16)  
> - Warehouser(18)  
> - Water Carrier(22)  
> - Weapon Dealer(18)  
> - Weapon Dealer(18)  
> - Weaponsmith(6)  
> - Weaponsmith(6)  
> - Weaver(16)  
> - Wheelwright(17)  
> - Wheelwright(24)  
> - Wine Merchant(9)  
> - Wood Carver(9)  
> - Wood Seller(8)  
> - Wool Merchant(14)  
> - Writer(18)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



