---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallCity
kingdom: KingdomName
region: RegionName
settlementName: Named SmallCity (6761)
terrain: Hills Forest 
settlementDescription: 
population: 6761
culture: Arabic 
technology: Bronze Age 
leader: 
govermentType: Plutocracy 
demographics: 
- Acrobat(12) 
- Minstrel(12) 
- Storyteller(12) 
- Troubadours(12) 
- Writer(12) 
- Advocate(9) 
- Clerk(20) 
- Council Member(17) 
- Diplomat(3) 
- Judge(10) 
- Mayor(1) 
- Alchemist(6) 
- Chandler(17) 
- Dye Makers(17) 
- Florist(6) 
- Herbalist(6) 
- Potionmakers(6) 
- Sage(4) 
- Spice Merchant(12) 
- Taxidermist(12) 
- Tobacco Merchant(12) 
- Animal Groomer(5) 
- Animal Handler(12) 
- Caravanner(9) 
- Horse Trader(14) 
- Livestock Merchant(10) 
- Stabler(13) 
- Antiquities(12) 
- Armor Dealer(12) 
- Launderer(12) 
- Oil Trader(17) 
- Trading Post(17) 
- Slaver(12) 
- Spice Merchant(12) 
- Taxidermist(12) 
- Tobacco Merchant(12) 
- Warehouser(12) 
- Weapon Dealer(12) 
- Architect(14) 
- Bricklayer(14) 
- Engineer(14) 
- Laborer(14) 
- Mason(14) 
- Painter(Building)(14) 
- Plasterer(14) 
- Roofer(14) 
- Teamster(14) 
- Tiler(14) 
- Armorer(4) 
- Blacksmith(16) 
- Bowyer-Fletcher(6) 
- Jeweler(5) 
- Silversmith(4) 
- Weapon Dealer(12) 
- Weaponsmith(4) 
- Artist(16) 
- Glassblower(12) 
- Goldsmith(8) 
- Inventor(10) 
- Jeweler(7) 
- Magical Artisan(4) 
- Painter(Art)(13) 
- Silversmith(10) 
- Tinker(17) 
- Toymaker(6) 
- Astrologist(4) 
- Conjourer(4) 
- High Mage(4) 
- Historian(4) 
- Librarian(4) 
- Magical Artisan(4) 
- Magical Tutor(4) 
- Professor(4) 
- Scribe(4) 
- SellSpell(4) 
- Teacher(4) 
- Tutor(4) 
- Baker(11) 
- Beer Merchant(7) 
- Brewer(1) 
- Butcher(7) 
- Chicken Butcher(7) 
- Cook(8) 
- Dairy Seller(34) 
- Distiller(7) 
- Hay Merchant(34) 
- Fisherman(9) 
- Fishmonger(9) 
- Grain Merchant(1) 
- Grocer(6) 
- Meat Butcher(6) 
- Miller(17) 
- Pastry Maker(9) 
- Vintner(8) 
- Banker(4) 
- Pawnbroker(4) 
- Barbarian(34) 
- Brigand(34) 
- Captain(34) 
- Mountainman(34) 
- Barbarian(7) 
- Cartographer(6) 
- Guide(12) 
- Huntsman(17) 
- Mountainman(6) 
- Pathfinder(6) 
- Scout(6) 
- Slaver(12) 
- Barrel Maker(8) 
- Basket Maker(10) 
- Book Binder(4) 
- Bookseller(4) 
- Buckle Maker(6) 
- Candle Maker(5) 
- Clock Maker(4) 
- Cobbler(11) 
- Cooper(8) 
- Cutler(4) 
- Engraver(4) 
- Furniture Maker(11) 
- Glassblower(5) 
- Glazier(4) 
- Glove Merchant(10) 
- Goldsmith(5) 
- Harness Maker(12) 
- Hat Maker(5) 
- Instrument Maker(4) 
- Kettle Maker(3) 
- Locksmith(4) 
- Perfumer(5) 
- Potter(12) 
- Rope Maker(8) 
- Rug Maker(5) 
- Saddler(9) 
- Sculptor(3) 
- Shoe Maker(8) 
- Soap Maker(6) 
- Tanner(9) 
- Tinker(4) 
- Toymaker(4) 
- Weaponsmith(4) 
- Weaver(10) 
- Wheelwright(16) 
- Wine Merchant(6) 
- Wool Merchant(9) 
- Lord(3) 
- Knight(3) 
- Baron(2) 
- Viscount(1) 
- Earl(1) 
- Barrel Maker(13) 
- Bowyer-Fletcher(6) 
- Carpenter(20) 
- Roofer(14) 
- Wagon Maker(10) 
- Wheelwright(11) 
- Wood Carver(6) 
- Wood Seller(6) 
- Barber(6) 
- Bleacher(6) 
- Physic/Chirurgeon(6) 
- Bather(5) 
- Brigand(12) 
- Crime Lord(3) 
- Crook(14) 
- Goon(16) 
- Brothel Keeper(5) 
- Innkeeper(10) 
- Tavern Keeper(13) 
- Buckle Maker(10) 
- Cobbler(8) 
- Draper(6) 
- Furrier(16) 
- Girdler(6) 
- Haberdasher(5) 
- Launderer(10) 
- Leatherworker(7) 
- Purse Maker(6) 
- Shoe Maker(8) 
- Tailor(10) 
- Tanner(9) 
- Used Garment Trader(15) 
- Vestment Maker(8) 
- Chandler(17) 
- Dye Makers(17) 
- Oil Trader(17) 
- Cleric(13) 
- High Priest(5) 
- Missionary(46) 
- Preacher(28) 
- Priest(16) 
- Farmer(339) 
- Homestead(451) 
- Farmer - Cabbage(34) 
- Farmer - Cattle Herder(34) 
- Farmer - Corn(34) 
- Farmer - Cow Herder(34) 
- Farmer - Dairy(34) 
- Farmer - Goat Herder(34) 
- Farmer - Pig Herder(34) 
- Farmer - Potato(34) 
- Farmer - Sheep Herder(34) 
- Farmer - Wheat(34) 
- Farmer(Special)(34) 
- Dungsweeper(10) 
- Illuminator(7) 
- Messenger(11) 
- Tax Collector(2) 
- Town Crier(20) 
- Town Justice(5) 
- Undertaker(4) 
- Water Carrier(14) 
- Leatherworker(7) 
- Skinner(7) 
- Naval Outfitter(4) 
- Pirate(17) 
- Sail Maker(10) 
- Sailor(23) 
- Ship Builder(4) 
imports: 
- Construction Stone  
exports: 
- Limestone  
defenses: Curtain Wall 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(12)  
> - Advocate(9)  
> - Alchemist(6)  
> - Animal Groomer(5)  
> - Animal Handler(12)  
> - Antiquities(12)  
> - Architect(14)  
> - Armor Dealer(12)  
> - Armorer(4)  
> - Artist(16)  
> - Astrologist(4)  
> - Baker(11)  
> - Banker(4)  
> - Barbarian(34)  
> - Barbarian(7)  
> - Barber(6)  
> - Baron(2)  
> - Barrel Maker(13)  
> - Barrel Maker(8)  
> - Basket Maker(10)  
> - Bather(5)  
> - Beer Merchant(7)  
> - Blacksmith(16)  
> - Bleacher(6)  
> - Book Binder(4)  
> - Bookseller(4)  
> - Bowyer-Fletcher(6)  
> - Bowyer-Fletcher(6)  
> - Brewer(1)  
> - Bricklayer(14)  
> - Brigand(12)  
> - Brigand(34)  
> - Brothel Keeper(5)  
> - Buckle Maker(10)  
> - Buckle Maker(6)  
> - Butcher(7)  
> - Candle Maker(5)  
> - Captain(34)  
> - Caravanner(9)  
> - Carpenter(20)  
> - Cartographer(6)  
> - Chandler(17)  
> - Chandler(17)  
> - Chicken Butcher(7)  
> - Cleric(13)  
> - Clerk(20)  
> - Clock Maker(4)  
> - Cobbler(11)  
> - Cobbler(8)  
> - Conjourer(4)  
> - Cook(8)  
> - Cooper(8)  
> - Council Member(17)  
> - Crime Lord(3)  
> - Crook(14)  
> - Cutler(4)  
> - Dairy Seller(34)  
> - Diplomat(3)  
> - Distiller(7)  
> - Draper(6)  
> - Dungsweeper(10)  
> - Dye Makers(17)  
> - Dye Makers(17)  
> - Earl(1)  
> - Engineer(14)  
> - Engraver(4)  
> - Farmer - Cabbage(34)  
> - Farmer - Cattle Herder(34)  
> - Farmer - Corn(34)  
> - Farmer - Cow Herder(34)  
> - Farmer - Dairy(34)  
> - Farmer - Goat Herder(34)  
> - Farmer - Pig Herder(34)  
> - Farmer - Potato(34)  
> - Farmer - Sheep Herder(34)  
> - Farmer - Wheat(34)  
> - Farmer(339)  
> - Farmer(Special)(34)  
> - Fisherman(9)  
> - Fishmonger(9)  
> - Florist(6)  
> - Furniture Maker(11)  
> - Furrier(16)  
> - Girdler(6)  
> - Glassblower(12)  
> - Glassblower(5)  
> - Glazier(4)  
> - Glove Merchant(10)  
> - Goldsmith(5)  
> - Goldsmith(8)  
> - Goon(16)  
> - Grain Merchant(1)  
> - Grocer(6)  
> - Guide(12)  
> - Haberdasher(5)  
> - Harness Maker(12)  
> - Hat Maker(5)  
> - Hay Merchant(34)  
> - Herbalist(6)  
> - High Mage(4)  
> - High Priest(5)  
> - Historian(4)  
> - Homestead(451)  
> - Horse Trader(14)  
> - Huntsman(17)  
> - Illuminator(7)  
> - Innkeeper(10)  
> - Instrument Maker(4)  
> - Inventor(10)  
> - Jeweler(5)  
> - Jeweler(7)  
> - Judge(10)  
> - Kettle Maker(3)  
> - Knight(3)  
> - Laborer(14)  
> - Launderer(10)  
> - Launderer(12)  
> - Leatherworker(7)  
> - Leatherworker(7)  
> - Librarian(4)  
> - Livestock Merchant(10)  
> - Locksmith(4)  
> - Lord(3)  
> - Magical Artisan(4)  
> - Magical Artisan(4)  
> - Magical Tutor(4)  
> - Mason(14)  
> - Mayor(1)  
> - Meat Butcher(6)  
> - Messenger(11)  
> - Miller(17)  
> - Minstrel(12)  
> - Missionary(46)  
> - Mountainman(34)  
> - Mountainman(6)  
> - Naval Outfitter(4)  
> - Oil Trader(17)  
> - Oil Trader(17)  
> - Painter(Art)(13)  
> - Painter(Building)(14)  
> - Pastry Maker(9)  
> - Pathfinder(6)  
> - Pawnbroker(4)  
> - Perfumer(5)  
> - Physic/Chirurgeon(6)  
> - Pirate(17)  
> - Plasterer(14)  
> - Potionmakers(6)  
> - Potter(12)  
> - Preacher(28)  
> - Priest(16)  
> - Professor(4)  
> - Purse Maker(6)  
> - Roofer(14)  
> - Roofer(14)  
> - Rope Maker(8)  
> - Rug Maker(5)  
> - Saddler(9)  
> - Sage(4)  
> - Sail Maker(10)  
> - Sailor(23)  
> - Scout(6)  
> - Scribe(4)  
> - Sculptor(3)  
> - SellSpell(4)  
> - Ship Builder(4)  
> - Shoe Maker(8)  
> - Shoe Maker(8)  
> - Silversmith(10)  
> - Silversmith(4)  
> - Skinner(7)  
> - Slaver(12)  
> - Slaver(12)  
> - Soap Maker(6)  
> - Spice Merchant(12)  
> - Spice Merchant(12)  
> - Stabler(13)  
> - Storyteller(12)  
> - Tailor(10)  
> - Tanner(9)  
> - Tanner(9)  
> - Tavern Keeper(13)  
> - Tax Collector(2)  
> - Taxidermist(12)  
> - Taxidermist(12)  
> - Teacher(4)  
> - Teamster(14)  
> - Tiler(14)  
> - Tinker(17)  
> - Tinker(4)  
> - Tobacco Merchant(12)  
> - Tobacco Merchant(12)  
> - Town Crier(20)  
> - Town Justice(5)  
> - Toymaker(4)  
> - Toymaker(6)  
> - Trading Post(17)  
> - Troubadours(12)  
> - Tutor(4)  
> - Undertaker(4)  
> - Used Garment Trader(15)  
> - Vestment Maker(8)  
> - Vintner(8)  
> - Viscount(1)  
> - Wagon Maker(10)  
> - Warehouser(12)  
> - Water Carrier(14)  
> - Weapon Dealer(12)  
> - Weapon Dealer(12)  
> - Weaponsmith(4)  
> - Weaponsmith(4)  
> - Weaver(10)  
> - Wheelwright(11)  
> - Wheelwright(16)  
> - Wine Merchant(6)  
> - Wood Carver(6)  
> - Wood Seller(6)  
> - Wool Merchant(9)  
> - Writer(12)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(12)  
> - Advocate(9)  
> - Alchemist(6)  
> - Animal Groomer(5)  
> - Animal Handler(12)  
> - Antiquities(12)  
> - Architect(14)  
> - Armor Dealer(12)  
> - Armorer(4)  
> - Artist(16)  
> - Astrologist(4)  
> - Baker(11)  
> - Banker(4)  
> - Barbarian(34)  
> - Barbarian(7)  
> - Barber(6)  
> - Baron(2)  
> - Barrel Maker(13)  
> - Barrel Maker(8)  
> - Basket Maker(10)  
> - Bather(5)  
> - Beer Merchant(7)  
> - Blacksmith(16)  
> - Bleacher(6)  
> - Book Binder(4)  
> - Bookseller(4)  
> - Bowyer-Fletcher(6)  
> - Bowyer-Fletcher(6)  
> - Brewer(1)  
> - Bricklayer(14)  
> - Brigand(12)  
> - Brigand(34)  
> - Brothel Keeper(5)  
> - Buckle Maker(10)  
> - Buckle Maker(6)  
> - Butcher(7)  
> - Candle Maker(5)  
> - Captain(34)  
> - Caravanner(9)  
> - Carpenter(20)  
> - Cartographer(6)  
> - Chandler(17)  
> - Chandler(17)  
> - Chicken Butcher(7)  
> - Cleric(13)  
> - Clerk(20)  
> - Clock Maker(4)  
> - Cobbler(11)  
> - Cobbler(8)  
> - Conjourer(4)  
> - Cook(8)  
> - Cooper(8)  
> - Council Member(17)  
> - Crime Lord(3)  
> - Crook(14)  
> - Cutler(4)  
> - Dairy Seller(34)  
> - Diplomat(3)  
> - Distiller(7)  
> - Draper(6)  
> - Dungsweeper(10)  
> - Dye Makers(17)  
> - Dye Makers(17)  
> - Earl(1)  
> - Engineer(14)  
> - Engraver(4)  
> - Farmer - Cabbage(34)  
> - Farmer - Cattle Herder(34)  
> - Farmer - Corn(34)  
> - Farmer - Cow Herder(34)  
> - Farmer - Dairy(34)  
> - Farmer - Goat Herder(34)  
> - Farmer - Pig Herder(34)  
> - Farmer - Potato(34)  
> - Farmer - Sheep Herder(34)  
> - Farmer - Wheat(34)  
> - Farmer(339)  
> - Farmer(Special)(34)  
> - Fisherman(9)  
> - Fishmonger(9)  
> - Florist(6)  
> - Furniture Maker(11)  
> - Furrier(16)  
> - Girdler(6)  
> - Glassblower(12)  
> - Glassblower(5)  
> - Glazier(4)  
> - Glove Merchant(10)  
> - Goldsmith(5)  
> - Goldsmith(8)  
> - Goon(16)  
> - Grain Merchant(1)  
> - Grocer(6)  
> - Guide(12)  
> - Haberdasher(5)  
> - Harness Maker(12)  
> - Hat Maker(5)  
> - Hay Merchant(34)  
> - Herbalist(6)  
> - High Mage(4)  
> - High Priest(5)  
> - Historian(4)  
> - Homestead(451)  
> - Horse Trader(14)  
> - Huntsman(17)  
> - Illuminator(7)  
> - Innkeeper(10)  
> - Instrument Maker(4)  
> - Inventor(10)  
> - Jeweler(5)  
> - Jeweler(7)  
> - Judge(10)  
> - Kettle Maker(3)  
> - Knight(3)  
> - Laborer(14)  
> - Launderer(10)  
> - Launderer(12)  
> - Leatherworker(7)  
> - Leatherworker(7)  
> - Librarian(4)  
> - Livestock Merchant(10)  
> - Locksmith(4)  
> - Lord(3)  
> - Magical Artisan(4)  
> - Magical Artisan(4)  
> - Magical Tutor(4)  
> - Mason(14)  
> - Mayor(1)  
> - Meat Butcher(6)  
> - Messenger(11)  
> - Miller(17)  
> - Minstrel(12)  
> - Missionary(46)  
> - Mountainman(34)  
> - Mountainman(6)  
> - Naval Outfitter(4)  
> - Oil Trader(17)  
> - Oil Trader(17)  
> - Painter(Art)(13)  
> - Painter(Building)(14)  
> - Pastry Maker(9)  
> - Pathfinder(6)  
> - Pawnbroker(4)  
> - Perfumer(5)  
> - Physic/Chirurgeon(6)  
> - Pirate(17)  
> - Plasterer(14)  
> - Potionmakers(6)  
> - Potter(12)  
> - Preacher(28)  
> - Priest(16)  
> - Professor(4)  
> - Purse Maker(6)  
> - Roofer(14)  
> - Roofer(14)  
> - Rope Maker(8)  
> - Rug Maker(5)  
> - Saddler(9)  
> - Sage(4)  
> - Sail Maker(10)  
> - Sailor(23)  
> - Scout(6)  
> - Scribe(4)  
> - Sculptor(3)  
> - SellSpell(4)  
> - Ship Builder(4)  
> - Shoe Maker(8)  
> - Shoe Maker(8)  
> - Silversmith(10)  
> - Silversmith(4)  
> - Skinner(7)  
> - Slaver(12)  
> - Slaver(12)  
> - Soap Maker(6)  
> - Spice Merchant(12)  
> - Spice Merchant(12)  
> - Stabler(13)  
> - Storyteller(12)  
> - Tailor(10)  
> - Tanner(9)  
> - Tanner(9)  
> - Tavern Keeper(13)  
> - Tax Collector(2)  
> - Taxidermist(12)  
> - Taxidermist(12)  
> - Teacher(4)  
> - Teamster(14)  
> - Tiler(14)  
> - Tinker(17)  
> - Tinker(4)  
> - Tobacco Merchant(12)  
> - Tobacco Merchant(12)  
> - Town Crier(20)  
> - Town Justice(5)  
> - Toymaker(4)  
> - Toymaker(6)  
> - Trading Post(17)  
> - Troubadours(12)  
> - Tutor(4)  
> - Undertaker(4)  
> - Used Garment Trader(15)  
> - Vestment Maker(8)  
> - Vintner(8)  
> - Viscount(1)  
> - Wagon Maker(10)  
> - Warehouser(12)  
> - Water Carrier(14)  
> - Weapon Dealer(12)  
> - Weapon Dealer(12)  
> - Weaponsmith(4)  
> - Weaponsmith(4)  
> - Weaver(10)  
> - Wheelwright(11)  
> - Wheelwright(16)  
> - Wine Merchant(6)  
> - Wood Carver(6)  
> - Wood Seller(6)  
> - Wool Merchant(9)  
> - Writer(12)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



