---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (24462)
terrain: Desert Badlands 
settlementDescription: 
population: 24462
culture: Indian 
technology: Dark Ages 
leader: 
govermentType: Theocracy 
demographics: 
- Acrobat(41) 
- Minstrel(41) 
- Storyteller(41) 
- Troubadours(41) 
- Writer(41) 
- Advocate(31) 
- Clerk(70) 
- Council Member(62) 
- Diplomat(10) 
- Judge(35) 
- Mayor(1) 
- Alchemist(21) 
- Chandler(62) 
- Dye Makers(62) 
- Florist(21) 
- Herbalist(21) 
- Potionmakers(21) 
- Sage(12) 
- Spice Merchant(41) 
- Taxidermist(41) 
- Tobacco Merchant(41) 
- Animal Groomer(17) 
- Animal Handler(41) 
- Caravanner(31) 
- Horse Trader(49) 
- Livestock Merchant(33) 
- Stabler(44) 
- Antiquities(41) 
- Armor Dealer(41) 
- Launderer(41) 
- Oil Trader(62) 
- Trading Post(62) 
- Slaver(41) 
- Spice Merchant(41) 
- Taxidermist(41) 
- Tobacco Merchant(41) 
- Warehouser(41) 
- Weapon Dealer(41) 
- Architect(49) 
- Bricklayer(49) 
- Engineer(49) 
- Laborer(49) 
- Mason(49) 
- Painter(Building)(49) 
- Plasterer(49) 
- Roofer(49) 
- Teamster(49) 
- Tiler(49) 
- Armorer(13) 
- Blacksmith(58) 
- Bowyer-Fletcher(20) 
- Jeweler(16) 
- Silversmith(15) 
- Weapon Dealer(41) 
- Weaponsmith(12) 
- Artist(55) 
- Glassblower(41) 
- Goldsmith(28) 
- Inventor(35) 
- Jeweler(25) 
- Magical Artisan(12) 
- Painter(Art)(45) 
- Silversmith(35) 
- Tinker(62) 
- Toymaker(19) 
- Astrologist(12) 
- Conjourer(12) 
- High Mage(12) 
- Historian(12) 
- Librarian(12) 
- Magical Artisan(12) 
- Magical Tutor(12) 
- Professor(12) 
- Scribe(12) 
- SellSpell(12) 
- Teacher(12) 
- Tutor(12) 
- Baker(38) 
- Beer Merchant(23) 
- Brewer(6) 
- Butcher(25) 
- Chicken Butcher(25) 
- Cook(26) 
- Dairy Seller(123) 
- Distiller(23) 
- Hay Merchant(123) 
- Fisherman(31) 
- Fishmonger(31) 
- Grain Merchant(7) 
- Grocer(19) 
- Meat Butcher(21) 
- Miller(62) 
- Pastry Maker(31) 
- Vintner(26) 
- Banker(14) 
- Pawnbroker(14) 
- Barbarian(123) 
- Brigand(123) 
- Captain(123) 
- Mountainman(123) 
- Barbarian(23) 
- Cartographer(21) 
- Guide(41) 
- Huntsman(62) 
- Mountainman(19) 
- Pathfinder(21) 
- Scout(21) 
- Slaver(41) 
- Barrel Maker(26) 
- Basket Maker(35) 
- Book Binder(13) 
- Bookseller(12) 
- Buckle Maker(19) 
- Candle Maker(16) 
- Clock Maker(12) 
- Cobbler(38) 
- Cooper(29) 
- Cutler(13) 
- Engraver(12) 
- Furniture Maker(38) 
- Glassblower(18) 
- Glazier(12) 
- Glove Merchant(33) 
- Goldsmith(18) 
- Harness Maker(41) 
- Hat Maker(17) 
- Instrument Maker(12) 
- Kettle Maker(11) 
- Locksmith(15) 
- Perfumer(17) 
- Potter(41) 
- Rope Maker(29) 
- Rug Maker(15) 
- Saddler(31) 
- Sculptor(11) 
- Shoe Maker(29) 
- Soap Maker(21) 
- Tanner(31) 
- Tinker(14) 
- Toymaker(12) 
- Weaponsmith(12) 
- Weaver(35) 
- Wheelwright(55) 
- Wine Merchant(21) 
- Wool Merchant(31) 
- Lord(9) 
- Knight(9) 
- Baron(5) 
- Viscount(4) 
- Earl(3) 
- Count(3) 
- Duke(2) 
- ArchDuke(1) 
- Barrel Maker(45) 
- Bowyer-Fletcher(20) 
- Carpenter(70) 
- Roofer(49) 
- Wagon Maker(35) 
- Wheelwright(38) 
- Wood Carver(20) 
- Wood Seller(19) 
- Barber(21) 
- Bleacher(21) 
- Physic/Chirurgeon(21) 
- Bather(17) 
- Brigand(41) 
- Crime Lord(10) 
- Crook(49) 
- Goon(55) 
- Brothel Keeper(17) 
- Innkeeper(33) 
- Tavern Keeper(45) 
- Buckle Maker(33) 
- Cobbler(29) 
- Draper(21) 
- Furrier(55) 
- Girdler(19) 
- Haberdasher(16) 
- Launderer(33) 
- Leatherworker(23) 
- Purse Maker(21) 
- Shoe Maker(29) 
- Tailor(33) 
- Tanner(31) 
- Used Garment Trader(52) 
- Vestment Maker(29) 
- Chandler(62) 
- Dye Makers(62) 
- Oil Trader(62) 
- Cleric(45) 
- High Priest(17) 
- Missionary(164) 
- Preacher(98) 
- Priest(55) 
- Farmer(1224) 
- Homestead(1631) 
- Farmer - Cabbage(123) 
- Farmer - Cattle Herder(123) 
- Farmer - Corn(123) 
- Farmer - Cow Herder(123) 
- Farmer - Dairy(123) 
- Farmer - Goat Herder(123) 
- Farmer - Pig Herder(123) 
- Farmer - Potato(123) 
- Farmer - Sheep Herder(123) 
- Farmer - Wheat(123) 
- Farmer(Special)(123) 
- Dungsweeper(35) 
- Illuminator(25) 
- Messenger(38) 
- Tax Collector(7) 
- Town Crier(70) 
- Town Justice(17) 
- Undertaker(14) 
- Water Carrier(49) 
- Leatherworker(25) 
- Skinner(25) 
- Naval Outfitter(13) 
- Pirate(62) 
- Sail Maker(35) 
- Sailor(82) 
- Ship Builder(15) 
imports: 
- Salt  
exports: 
- Granite  
defenses: Archer towers 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(41)  
> - Advocate(31)  
> - Alchemist(21)  
> - Animal Groomer(17)  
> - Animal Handler(41)  
> - Antiquities(41)  
> - ArchDuke(1)  
> - Architect(49)  
> - Armor Dealer(41)  
> - Armorer(13)  
> - Artist(55)  
> - Astrologist(12)  
> - Baker(38)  
> - Banker(14)  
> - Barbarian(123)  
> - Barbarian(23)  
> - Barber(21)  
> - Baron(5)  
> - Barrel Maker(26)  
> - Barrel Maker(45)  
> - Basket Maker(35)  
> - Bather(17)  
> - Beer Merchant(23)  
> - Blacksmith(58)  
> - Bleacher(21)  
> - Book Binder(13)  
> - Bookseller(12)  
> - Bowyer-Fletcher(20)  
> - Bowyer-Fletcher(20)  
> - Brewer(6)  
> - Bricklayer(49)  
> - Brigand(123)  
> - Brigand(41)  
> - Brothel Keeper(17)  
> - Buckle Maker(19)  
> - Buckle Maker(33)  
> - Butcher(25)  
> - Candle Maker(16)  
> - Captain(123)  
> - Caravanner(31)  
> - Carpenter(70)  
> - Cartographer(21)  
> - Chandler(62)  
> - Chandler(62)  
> - Chicken Butcher(25)  
> - Cleric(45)  
> - Clerk(70)  
> - Clock Maker(12)  
> - Cobbler(29)  
> - Cobbler(38)  
> - Conjourer(12)  
> - Cook(26)  
> - Cooper(29)  
> - Council Member(62)  
> - Count(3)  
> - Crime Lord(10)  
> - Crook(49)  
> - Cutler(13)  
> - Dairy Seller(123)  
> - Diplomat(10)  
> - Distiller(23)  
> - Draper(21)  
> - Duke(2)  
> - Dungsweeper(35)  
> - Dye Makers(62)  
> - Dye Makers(62)  
> - Earl(3)  
> - Engineer(49)  
> - Engraver(12)  
> - Farmer - Cabbage(123)  
> - Farmer - Cattle Herder(123)  
> - Farmer - Corn(123)  
> - Farmer - Cow Herder(123)  
> - Farmer - Dairy(123)  
> - Farmer - Goat Herder(123)  
> - Farmer - Pig Herder(123)  
> - Farmer - Potato(123)  
> - Farmer - Sheep Herder(123)  
> - Farmer - Wheat(123)  
> - Farmer(1224)  
> - Farmer(Special)(123)  
> - Fisherman(31)  
> - Fishmonger(31)  
> - Florist(21)  
> - Furniture Maker(38)  
> - Furrier(55)  
> - Girdler(19)  
> - Glassblower(18)  
> - Glassblower(41)  
> - Glazier(12)  
> - Glove Merchant(33)  
> - Goldsmith(18)  
> - Goldsmith(28)  
> - Goon(55)  
> - Grain Merchant(7)  
> - Grocer(19)  
> - Guide(41)  
> - Haberdasher(16)  
> - Harness Maker(41)  
> - Hat Maker(17)  
> - Hay Merchant(123)  
> - Herbalist(21)  
> - High Mage(12)  
> - High Priest(17)  
> - Historian(12)  
> - Homestead(1631)  
> - Horse Trader(49)  
> - Huntsman(62)  
> - Illuminator(25)  
> - Innkeeper(33)  
> - Instrument Maker(12)  
> - Inventor(35)  
> - Jeweler(16)  
> - Jeweler(25)  
> - Judge(35)  
> - Kettle Maker(11)  
> - Knight(9)  
> - Laborer(49)  
> - Launderer(33)  
> - Launderer(41)  
> - Leatherworker(23)  
> - Leatherworker(25)  
> - Librarian(12)  
> - Livestock Merchant(33)  
> - Locksmith(15)  
> - Lord(9)  
> - Magical Artisan(12)  
> - Magical Artisan(12)  
> - Magical Tutor(12)  
> - Mason(49)  
> - Mayor(1)  
> - Meat Butcher(21)  
> - Messenger(38)  
> - Miller(62)  
> - Minstrel(41)  
> - Missionary(164)  
> - Mountainman(123)  
> - Mountainman(19)  
> - Naval Outfitter(13)  
> - Oil Trader(62)  
> - Oil Trader(62)  
> - Painter(Art)(45)  
> - Painter(Building)(49)  
> - Pastry Maker(31)  
> - Pathfinder(21)  
> - Pawnbroker(14)  
> - Perfumer(17)  
> - Physic/Chirurgeon(21)  
> - Pirate(62)  
> - Plasterer(49)  
> - Potionmakers(21)  
> - Potter(41)  
> - Preacher(98)  
> - Priest(55)  
> - Professor(12)  
> - Purse Maker(21)  
> - Roofer(49)  
> - Roofer(49)  
> - Rope Maker(29)  
> - Rug Maker(15)  
> - Saddler(31)  
> - Sage(12)  
> - Sail Maker(35)  
> - Sailor(82)  
> - Scout(21)  
> - Scribe(12)  
> - Sculptor(11)  
> - SellSpell(12)  
> - Ship Builder(15)  
> - Shoe Maker(29)  
> - Shoe Maker(29)  
> - Silversmith(15)  
> - Silversmith(35)  
> - Skinner(25)  
> - Slaver(41)  
> - Slaver(41)  
> - Soap Maker(21)  
> - Spice Merchant(41)  
> - Spice Merchant(41)  
> - Stabler(44)  
> - Storyteller(41)  
> - Tailor(33)  
> - Tanner(31)  
> - Tanner(31)  
> - Tavern Keeper(45)  
> - Tax Collector(7)  
> - Taxidermist(41)  
> - Taxidermist(41)  
> - Teacher(12)  
> - Teamster(49)  
> - Tiler(49)  
> - Tinker(14)  
> - Tinker(62)  
> - Tobacco Merchant(41)  
> - Tobacco Merchant(41)  
> - Town Crier(70)  
> - Town Justice(17)  
> - Toymaker(12)  
> - Toymaker(19)  
> - Trading Post(62)  
> - Troubadours(41)  
> - Tutor(12)  
> - Undertaker(14)  
> - Used Garment Trader(52)  
> - Vestment Maker(29)  
> - Vintner(26)  
> - Viscount(4)  
> - Wagon Maker(35)  
> - Warehouser(41)  
> - Water Carrier(49)  
> - Weapon Dealer(41)  
> - Weapon Dealer(41)  
> - Weaponsmith(12)  
> - Weaponsmith(12)  
> - Weaver(35)  
> - Wheelwright(38)  
> - Wheelwright(55)  
> - Wine Merchant(21)  
> - Wood Carver(20)  
> - Wood Seller(19)  
> - Wool Merchant(31)  
> - Writer(41)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(41)  
> - Advocate(31)  
> - Alchemist(21)  
> - Animal Groomer(17)  
> - Animal Handler(41)  
> - Antiquities(41)  
> - ArchDuke(1)  
> - Architect(49)  
> - Armor Dealer(41)  
> - Armorer(13)  
> - Artist(55)  
> - Astrologist(12)  
> - Baker(38)  
> - Banker(14)  
> - Barbarian(123)  
> - Barbarian(23)  
> - Barber(21)  
> - Baron(5)  
> - Barrel Maker(26)  
> - Barrel Maker(45)  
> - Basket Maker(35)  
> - Bather(17)  
> - Beer Merchant(23)  
> - Blacksmith(58)  
> - Bleacher(21)  
> - Book Binder(13)  
> - Bookseller(12)  
> - Bowyer-Fletcher(20)  
> - Bowyer-Fletcher(20)  
> - Brewer(6)  
> - Bricklayer(49)  
> - Brigand(123)  
> - Brigand(41)  
> - Brothel Keeper(17)  
> - Buckle Maker(19)  
> - Buckle Maker(33)  
> - Butcher(25)  
> - Candle Maker(16)  
> - Captain(123)  
> - Caravanner(31)  
> - Carpenter(70)  
> - Cartographer(21)  
> - Chandler(62)  
> - Chandler(62)  
> - Chicken Butcher(25)  
> - Cleric(45)  
> - Clerk(70)  
> - Clock Maker(12)  
> - Cobbler(29)  
> - Cobbler(38)  
> - Conjourer(12)  
> - Cook(26)  
> - Cooper(29)  
> - Council Member(62)  
> - Count(3)  
> - Crime Lord(10)  
> - Crook(49)  
> - Cutler(13)  
> - Dairy Seller(123)  
> - Diplomat(10)  
> - Distiller(23)  
> - Draper(21)  
> - Duke(2)  
> - Dungsweeper(35)  
> - Dye Makers(62)  
> - Dye Makers(62)  
> - Earl(3)  
> - Engineer(49)  
> - Engraver(12)  
> - Farmer - Cabbage(123)  
> - Farmer - Cattle Herder(123)  
> - Farmer - Corn(123)  
> - Farmer - Cow Herder(123)  
> - Farmer - Dairy(123)  
> - Farmer - Goat Herder(123)  
> - Farmer - Pig Herder(123)  
> - Farmer - Potato(123)  
> - Farmer - Sheep Herder(123)  
> - Farmer - Wheat(123)  
> - Farmer(1224)  
> - Farmer(Special)(123)  
> - Fisherman(31)  
> - Fishmonger(31)  
> - Florist(21)  
> - Furniture Maker(38)  
> - Furrier(55)  
> - Girdler(19)  
> - Glassblower(18)  
> - Glassblower(41)  
> - Glazier(12)  
> - Glove Merchant(33)  
> - Goldsmith(18)  
> - Goldsmith(28)  
> - Goon(55)  
> - Grain Merchant(7)  
> - Grocer(19)  
> - Guide(41)  
> - Haberdasher(16)  
> - Harness Maker(41)  
> - Hat Maker(17)  
> - Hay Merchant(123)  
> - Herbalist(21)  
> - High Mage(12)  
> - High Priest(17)  
> - Historian(12)  
> - Homestead(1631)  
> - Horse Trader(49)  
> - Huntsman(62)  
> - Illuminator(25)  
> - Innkeeper(33)  
> - Instrument Maker(12)  
> - Inventor(35)  
> - Jeweler(16)  
> - Jeweler(25)  
> - Judge(35)  
> - Kettle Maker(11)  
> - Knight(9)  
> - Laborer(49)  
> - Launderer(33)  
> - Launderer(41)  
> - Leatherworker(23)  
> - Leatherworker(25)  
> - Librarian(12)  
> - Livestock Merchant(33)  
> - Locksmith(15)  
> - Lord(9)  
> - Magical Artisan(12)  
> - Magical Artisan(12)  
> - Magical Tutor(12)  
> - Mason(49)  
> - Mayor(1)  
> - Meat Butcher(21)  
> - Messenger(38)  
> - Miller(62)  
> - Minstrel(41)  
> - Missionary(164)  
> - Mountainman(123)  
> - Mountainman(19)  
> - Naval Outfitter(13)  
> - Oil Trader(62)  
> - Oil Trader(62)  
> - Painter(Art)(45)  
> - Painter(Building)(49)  
> - Pastry Maker(31)  
> - Pathfinder(21)  
> - Pawnbroker(14)  
> - Perfumer(17)  
> - Physic/Chirurgeon(21)  
> - Pirate(62)  
> - Plasterer(49)  
> - Potionmakers(21)  
> - Potter(41)  
> - Preacher(98)  
> - Priest(55)  
> - Professor(12)  
> - Purse Maker(21)  
> - Roofer(49)  
> - Roofer(49)  
> - Rope Maker(29)  
> - Rug Maker(15)  
> - Saddler(31)  
> - Sage(12)  
> - Sail Maker(35)  
> - Sailor(82)  
> - Scout(21)  
> - Scribe(12)  
> - Sculptor(11)  
> - SellSpell(12)  
> - Ship Builder(15)  
> - Shoe Maker(29)  
> - Shoe Maker(29)  
> - Silversmith(15)  
> - Silversmith(35)  
> - Skinner(25)  
> - Slaver(41)  
> - Slaver(41)  
> - Soap Maker(21)  
> - Spice Merchant(41)  
> - Spice Merchant(41)  
> - Stabler(44)  
> - Storyteller(41)  
> - Tailor(33)  
> - Tanner(31)  
> - Tanner(31)  
> - Tavern Keeper(45)  
> - Tax Collector(7)  
> - Taxidermist(41)  
> - Taxidermist(41)  
> - Teacher(12)  
> - Teamster(49)  
> - Tiler(49)  
> - Tinker(14)  
> - Tinker(62)  
> - Tobacco Merchant(41)  
> - Tobacco Merchant(41)  
> - Town Crier(70)  
> - Town Justice(17)  
> - Toymaker(12)  
> - Toymaker(19)  
> - Trading Post(62)  
> - Troubadours(41)  
> - Tutor(12)  
> - Undertaker(14)  
> - Used Garment Trader(52)  
> - Vestment Maker(29)  
> - Vintner(26)  
> - Viscount(4)  
> - Wagon Maker(35)  
> - Warehouser(41)  
> - Water Carrier(49)  
> - Weapon Dealer(41)  
> - Weapon Dealer(41)  
> - Weaponsmith(12)  
> - Weaponsmith(12)  
> - Weaver(35)  
> - Wheelwright(38)  
> - Wheelwright(55)  
> - Wine Merchant(21)  
> - Wood Carver(20)  
> - Wood Seller(19)  
> - Wool Merchant(31)  
> - Writer(41)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



