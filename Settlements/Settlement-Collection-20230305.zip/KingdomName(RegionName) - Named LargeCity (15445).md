---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (15445)
terrain: Grasslands 
settlementDescription: 
population: 15445
culture: Aztec 
technology: Renaissance 
leader: 
govermentType: Magocracy 
demographics: 
- Acrobat(26) 
- Minstrel(26) 
- Storyteller(26) 
- Troubadours(26) 
- Writer(26) 
- Advocate(20) 
- Clerk(45) 
- Council Member(39) 
- Diplomat(7) 
- Judge(23) 
- Mayor(1) 
- Alchemist(13) 
- Chandler(39) 
- Dye Makers(39) 
- Florist(13) 
- Herbalist(13) 
- Potionmakers(13) 
- Sage(8) 
- Spice Merchant(26) 
- Taxidermist(26) 
- Tobacco Merchant(26) 
- Animal Groomer(11) 
- Animal Handler(26) 
- Caravanner(20) 
- Horse Trader(31) 
- Livestock Merchant(21) 
- Stabler(28) 
- Antiquities(26) 
- Armor Dealer(26) 
- Launderer(26) 
- Oil Trader(39) 
- Trading Post(39) 
- Slaver(26) 
- Spice Merchant(26) 
- Taxidermist(26) 
- Tobacco Merchant(26) 
- Warehouser(26) 
- Weapon Dealer(26) 
- Architect(31) 
- Bricklayer(31) 
- Engineer(31) 
- Laborer(31) 
- Mason(31) 
- Painter(Building)(31) 
- Plasterer(31) 
- Roofer(31) 
- Teamster(31) 
- Tiler(31) 
- Armorer(9) 
- Blacksmith(37) 
- Bowyer-Fletcher(13) 
- Jeweler(10) 
- Silversmith(10) 
- Weapon Dealer(26) 
- Weaponsmith(8) 
- Artist(35) 
- Glassblower(26) 
- Goldsmith(18) 
- Inventor(23) 
- Jeweler(16) 
- Magical Artisan(8) 
- Painter(Art)(29) 
- Silversmith(23) 
- Tinker(39) 
- Toymaker(12) 
- Astrologist(8) 
- Conjourer(8) 
- High Mage(8) 
- Historian(8) 
- Librarian(8) 
- Magical Artisan(8) 
- Magical Tutor(8) 
- Professor(8) 
- Scribe(8) 
- SellSpell(8) 
- Teacher(8) 
- Tutor(8) 
- Baker(24) 
- Beer Merchant(15) 
- Brewer(4) 
- Butcher(16) 
- Chicken Butcher(16) 
- Cook(17) 
- Dairy Seller(78) 
- Distiller(15) 
- Hay Merchant(78) 
- Fisherman(20) 
- Fishmonger(20) 
- Grain Merchant(4) 
- Grocer(12) 
- Meat Butcher(13) 
- Miller(39) 
- Pastry Maker(20) 
- Vintner(17) 
- Banker(9) 
- Pawnbroker(9) 
- Barbarian(78) 
- Brigand(78) 
- Captain(78) 
- Mountainman(78) 
- Barbarian(15) 
- Cartographer(13) 
- Guide(26) 
- Huntsman(39) 
- Mountainman(12) 
- Pathfinder(13) 
- Scout(13) 
- Slaver(26) 
- Barrel Maker(17) 
- Basket Maker(23) 
- Book Binder(8) 
- Bookseller(8) 
- Buckle Maker(12) 
- Candle Maker(10) 
- Clock Maker(8) 
- Cobbler(24) 
- Cooper(19) 
- Cutler(8) 
- Engraver(8) 
- Furniture Maker(24) 
- Glassblower(12) 
- Glazier(8) 
- Glove Merchant(21) 
- Goldsmith(12) 
- Harness Maker(26) 
- Hat Maker(11) 
- Instrument Maker(8) 
- Kettle Maker(7) 
- Locksmith(10) 
- Perfumer(11) 
- Potter(26) 
- Rope Maker(19) 
- Rug Maker(10) 
- Saddler(20) 
- Sculptor(7) 
- Shoe Maker(19) 
- Soap Maker(13) 
- Tanner(20) 
- Tinker(9) 
- Toymaker(8) 
- Weaponsmith(8) 
- Weaver(23) 
- Wheelwright(35) 
- Wine Merchant(13) 
- Wool Merchant(20) 
- Lord(6) 
- Knight(6) 
- Baron(4) 
- Viscount(2) 
- Earl(2) 
- Count(2) 
- Duke(1) 
- Barrel Maker(29) 
- Bowyer-Fletcher(13) 
- Carpenter(45) 
- Roofer(31) 
- Wagon Maker(23) 
- Wheelwright(24) 
- Wood Carver(13) 
- Wood Seller(12) 
- Barber(13) 
- Bleacher(13) 
- Physic/Chirurgeon(13) 
- Bather(11) 
- Brigand(26) 
- Crime Lord(7) 
- Crook(31) 
- Goon(35) 
- Brothel Keeper(11) 
- Innkeeper(21) 
- Tavern Keeper(29) 
- Buckle Maker(21) 
- Cobbler(19) 
- Draper(13) 
- Furrier(35) 
- Girdler(12) 
- Haberdasher(10) 
- Launderer(21) 
- Leatherworker(15) 
- Purse Maker(13) 
- Shoe Maker(19) 
- Tailor(21) 
- Tanner(20) 
- Used Garment Trader(33) 
- Vestment Maker(19) 
- Chandler(39) 
- Dye Makers(39) 
- Oil Trader(39) 
- Cleric(29) 
- High Priest(11) 
- Missionary(103) 
- Preacher(62) 
- Priest(35) 
- Farmer(773) 
- Homestead(1030) 
- Farmer - Cabbage(78) 
- Farmer - Cattle Herder(78) 
- Farmer - Corn(78) 
- Farmer - Cow Herder(78) 
- Farmer - Dairy(78) 
- Farmer - Goat Herder(78) 
- Farmer - Pig Herder(78) 
- Farmer - Potato(78) 
- Farmer - Sheep Herder(78) 
- Farmer - Wheat(78) 
- Farmer(Special)(78) 
- Dungsweeper(22) 
- Illuminator(16) 
- Messenger(24) 
- Tax Collector(4) 
- Town Crier(45) 
- Town Justice(11) 
- Undertaker(9) 
- Water Carrier(31) 
- Leatherworker(16) 
- Skinner(16) 
- Naval Outfitter(8) 
- Pirate(39) 
- Sail Maker(23) 
- Sailor(52) 
- Ship Builder(10) 
imports: 
- Salt  
exports: 
- Wine  
defenses: Baileys 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(26)  
> - Advocate(20)  
> - Alchemist(13)  
> - Animal Groomer(11)  
> - Animal Handler(26)  
> - Antiquities(26)  
> - Architect(31)  
> - Armor Dealer(26)  
> - Armorer(9)  
> - Artist(35)  
> - Astrologist(8)  
> - Baker(24)  
> - Banker(9)  
> - Barbarian(15)  
> - Barbarian(78)  
> - Barber(13)  
> - Baron(4)  
> - Barrel Maker(17)  
> - Barrel Maker(29)  
> - Basket Maker(23)  
> - Bather(11)  
> - Beer Merchant(15)  
> - Blacksmith(37)  
> - Bleacher(13)  
> - Book Binder(8)  
> - Bookseller(8)  
> - Bowyer-Fletcher(13)  
> - Bowyer-Fletcher(13)  
> - Brewer(4)  
> - Bricklayer(31)  
> - Brigand(26)  
> - Brigand(78)  
> - Brothel Keeper(11)  
> - Buckle Maker(12)  
> - Buckle Maker(21)  
> - Butcher(16)  
> - Candle Maker(10)  
> - Captain(78)  
> - Caravanner(20)  
> - Carpenter(45)  
> - Cartographer(13)  
> - Chandler(39)  
> - Chandler(39)  
> - Chicken Butcher(16)  
> - Cleric(29)  
> - Clerk(45)  
> - Clock Maker(8)  
> - Cobbler(19)  
> - Cobbler(24)  
> - Conjourer(8)  
> - Cook(17)  
> - Cooper(19)  
> - Council Member(39)  
> - Count(2)  
> - Crime Lord(7)  
> - Crook(31)  
> - Cutler(8)  
> - Dairy Seller(78)  
> - Diplomat(7)  
> - Distiller(15)  
> - Draper(13)  
> - Duke(1)  
> - Dungsweeper(22)  
> - Dye Makers(39)  
> - Dye Makers(39)  
> - Earl(2)  
> - Engineer(31)  
> - Engraver(8)  
> - Farmer - Cabbage(78)  
> - Farmer - Cattle Herder(78)  
> - Farmer - Corn(78)  
> - Farmer - Cow Herder(78)  
> - Farmer - Dairy(78)  
> - Farmer - Goat Herder(78)  
> - Farmer - Pig Herder(78)  
> - Farmer - Potato(78)  
> - Farmer - Sheep Herder(78)  
> - Farmer - Wheat(78)  
> - Farmer(773)  
> - Farmer(Special)(78)  
> - Fisherman(20)  
> - Fishmonger(20)  
> - Florist(13)  
> - Furniture Maker(24)  
> - Furrier(35)  
> - Girdler(12)  
> - Glassblower(12)  
> - Glassblower(26)  
> - Glazier(8)  
> - Glove Merchant(21)  
> - Goldsmith(12)  
> - Goldsmith(18)  
> - Goon(35)  
> - Grain Merchant(4)  
> - Grocer(12)  
> - Guide(26)  
> - Haberdasher(10)  
> - Harness Maker(26)  
> - Hat Maker(11)  
> - Hay Merchant(78)  
> - Herbalist(13)  
> - High Mage(8)  
> - High Priest(11)  
> - Historian(8)  
> - Homestead(1030)  
> - Horse Trader(31)  
> - Huntsman(39)  
> - Illuminator(16)  
> - Innkeeper(21)  
> - Instrument Maker(8)  
> - Inventor(23)  
> - Jeweler(10)  
> - Jeweler(16)  
> - Judge(23)  
> - Kettle Maker(7)  
> - Knight(6)  
> - Laborer(31)  
> - Launderer(21)  
> - Launderer(26)  
> - Leatherworker(15)  
> - Leatherworker(16)  
> - Librarian(8)  
> - Livestock Merchant(21)  
> - Locksmith(10)  
> - Lord(6)  
> - Magical Artisan(8)  
> - Magical Artisan(8)  
> - Magical Tutor(8)  
> - Mason(31)  
> - Mayor(1)  
> - Meat Butcher(13)  
> - Messenger(24)  
> - Miller(39)  
> - Minstrel(26)  
> - Missionary(103)  
> - Mountainman(12)  
> - Mountainman(78)  
> - Naval Outfitter(8)  
> - Oil Trader(39)  
> - Oil Trader(39)  
> - Painter(Art)(29)  
> - Painter(Building)(31)  
> - Pastry Maker(20)  
> - Pathfinder(13)  
> - Pawnbroker(9)  
> - Perfumer(11)  
> - Physic/Chirurgeon(13)  
> - Pirate(39)  
> - Plasterer(31)  
> - Potionmakers(13)  
> - Potter(26)  
> - Preacher(62)  
> - Priest(35)  
> - Professor(8)  
> - Purse Maker(13)  
> - Roofer(31)  
> - Roofer(31)  
> - Rope Maker(19)  
> - Rug Maker(10)  
> - Saddler(20)  
> - Sage(8)  
> - Sail Maker(23)  
> - Sailor(52)  
> - Scout(13)  
> - Scribe(8)  
> - Sculptor(7)  
> - SellSpell(8)  
> - Ship Builder(10)  
> - Shoe Maker(19)  
> - Shoe Maker(19)  
> - Silversmith(10)  
> - Silversmith(23)  
> - Skinner(16)  
> - Slaver(26)  
> - Slaver(26)  
> - Soap Maker(13)  
> - Spice Merchant(26)  
> - Spice Merchant(26)  
> - Stabler(28)  
> - Storyteller(26)  
> - Tailor(21)  
> - Tanner(20)  
> - Tanner(20)  
> - Tavern Keeper(29)  
> - Tax Collector(4)  
> - Taxidermist(26)  
> - Taxidermist(26)  
> - Teacher(8)  
> - Teamster(31)  
> - Tiler(31)  
> - Tinker(39)  
> - Tinker(9)  
> - Tobacco Merchant(26)  
> - Tobacco Merchant(26)  
> - Town Crier(45)  
> - Town Justice(11)  
> - Toymaker(12)  
> - Toymaker(8)  
> - Trading Post(39)  
> - Troubadours(26)  
> - Tutor(8)  
> - Undertaker(9)  
> - Used Garment Trader(33)  
> - Vestment Maker(19)  
> - Vintner(17)  
> - Viscount(2)  
> - Wagon Maker(23)  
> - Warehouser(26)  
> - Water Carrier(31)  
> - Weapon Dealer(26)  
> - Weapon Dealer(26)  
> - Weaponsmith(8)  
> - Weaponsmith(8)  
> - Weaver(23)  
> - Wheelwright(24)  
> - Wheelwright(35)  
> - Wine Merchant(13)  
> - Wood Carver(13)  
> - Wood Seller(12)  
> - Wool Merchant(20)  
> - Writer(26)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(26)  
> - Advocate(20)  
> - Alchemist(13)  
> - Animal Groomer(11)  
> - Animal Handler(26)  
> - Antiquities(26)  
> - Architect(31)  
> - Armor Dealer(26)  
> - Armorer(9)  
> - Artist(35)  
> - Astrologist(8)  
> - Baker(24)  
> - Banker(9)  
> - Barbarian(15)  
> - Barbarian(78)  
> - Barber(13)  
> - Baron(4)  
> - Barrel Maker(17)  
> - Barrel Maker(29)  
> - Basket Maker(23)  
> - Bather(11)  
> - Beer Merchant(15)  
> - Blacksmith(37)  
> - Bleacher(13)  
> - Book Binder(8)  
> - Bookseller(8)  
> - Bowyer-Fletcher(13)  
> - Bowyer-Fletcher(13)  
> - Brewer(4)  
> - Bricklayer(31)  
> - Brigand(26)  
> - Brigand(78)  
> - Brothel Keeper(11)  
> - Buckle Maker(12)  
> - Buckle Maker(21)  
> - Butcher(16)  
> - Candle Maker(10)  
> - Captain(78)  
> - Caravanner(20)  
> - Carpenter(45)  
> - Cartographer(13)  
> - Chandler(39)  
> - Chandler(39)  
> - Chicken Butcher(16)  
> - Cleric(29)  
> - Clerk(45)  
> - Clock Maker(8)  
> - Cobbler(19)  
> - Cobbler(24)  
> - Conjourer(8)  
> - Cook(17)  
> - Cooper(19)  
> - Council Member(39)  
> - Count(2)  
> - Crime Lord(7)  
> - Crook(31)  
> - Cutler(8)  
> - Dairy Seller(78)  
> - Diplomat(7)  
> - Distiller(15)  
> - Draper(13)  
> - Duke(1)  
> - Dungsweeper(22)  
> - Dye Makers(39)  
> - Dye Makers(39)  
> - Earl(2)  
> - Engineer(31)  
> - Engraver(8)  
> - Farmer - Cabbage(78)  
> - Farmer - Cattle Herder(78)  
> - Farmer - Corn(78)  
> - Farmer - Cow Herder(78)  
> - Farmer - Dairy(78)  
> - Farmer - Goat Herder(78)  
> - Farmer - Pig Herder(78)  
> - Farmer - Potato(78)  
> - Farmer - Sheep Herder(78)  
> - Farmer - Wheat(78)  
> - Farmer(773)  
> - Farmer(Special)(78)  
> - Fisherman(20)  
> - Fishmonger(20)  
> - Florist(13)  
> - Furniture Maker(24)  
> - Furrier(35)  
> - Girdler(12)  
> - Glassblower(12)  
> - Glassblower(26)  
> - Glazier(8)  
> - Glove Merchant(21)  
> - Goldsmith(12)  
> - Goldsmith(18)  
> - Goon(35)  
> - Grain Merchant(4)  
> - Grocer(12)  
> - Guide(26)  
> - Haberdasher(10)  
> - Harness Maker(26)  
> - Hat Maker(11)  
> - Hay Merchant(78)  
> - Herbalist(13)  
> - High Mage(8)  
> - High Priest(11)  
> - Historian(8)  
> - Homestead(1030)  
> - Horse Trader(31)  
> - Huntsman(39)  
> - Illuminator(16)  
> - Innkeeper(21)  
> - Instrument Maker(8)  
> - Inventor(23)  
> - Jeweler(10)  
> - Jeweler(16)  
> - Judge(23)  
> - Kettle Maker(7)  
> - Knight(6)  
> - Laborer(31)  
> - Launderer(21)  
> - Launderer(26)  
> - Leatherworker(15)  
> - Leatherworker(16)  
> - Librarian(8)  
> - Livestock Merchant(21)  
> - Locksmith(10)  
> - Lord(6)  
> - Magical Artisan(8)  
> - Magical Artisan(8)  
> - Magical Tutor(8)  
> - Mason(31)  
> - Mayor(1)  
> - Meat Butcher(13)  
> - Messenger(24)  
> - Miller(39)  
> - Minstrel(26)  
> - Missionary(103)  
> - Mountainman(12)  
> - Mountainman(78)  
> - Naval Outfitter(8)  
> - Oil Trader(39)  
> - Oil Trader(39)  
> - Painter(Art)(29)  
> - Painter(Building)(31)  
> - Pastry Maker(20)  
> - Pathfinder(13)  
> - Pawnbroker(9)  
> - Perfumer(11)  
> - Physic/Chirurgeon(13)  
> - Pirate(39)  
> - Plasterer(31)  
> - Potionmakers(13)  
> - Potter(26)  
> - Preacher(62)  
> - Priest(35)  
> - Professor(8)  
> - Purse Maker(13)  
> - Roofer(31)  
> - Roofer(31)  
> - Rope Maker(19)  
> - Rug Maker(10)  
> - Saddler(20)  
> - Sage(8)  
> - Sail Maker(23)  
> - Sailor(52)  
> - Scout(13)  
> - Scribe(8)  
> - Sculptor(7)  
> - SellSpell(8)  
> - Ship Builder(10)  
> - Shoe Maker(19)  
> - Shoe Maker(19)  
> - Silversmith(10)  
> - Silversmith(23)  
> - Skinner(16)  
> - Slaver(26)  
> - Slaver(26)  
> - Soap Maker(13)  
> - Spice Merchant(26)  
> - Spice Merchant(26)  
> - Stabler(28)  
> - Storyteller(26)  
> - Tailor(21)  
> - Tanner(20)  
> - Tanner(20)  
> - Tavern Keeper(29)  
> - Tax Collector(4)  
> - Taxidermist(26)  
> - Taxidermist(26)  
> - Teacher(8)  
> - Teamster(31)  
> - Tiler(31)  
> - Tinker(39)  
> - Tinker(9)  
> - Tobacco Merchant(26)  
> - Tobacco Merchant(26)  
> - Town Crier(45)  
> - Town Justice(11)  
> - Toymaker(12)  
> - Toymaker(8)  
> - Trading Post(39)  
> - Troubadours(26)  
> - Tutor(8)  
> - Undertaker(9)  
> - Used Garment Trader(33)  
> - Vestment Maker(19)  
> - Vintner(17)  
> - Viscount(2)  
> - Wagon Maker(23)  
> - Warehouser(26)  
> - Water Carrier(31)  
> - Weapon Dealer(26)  
> - Weapon Dealer(26)  
> - Weaponsmith(8)  
> - Weaponsmith(8)  
> - Weaver(23)  
> - Wheelwright(24)  
> - Wheelwright(35)  
> - Wine Merchant(13)  
> - Wood Carver(13)  
> - Wood Seller(12)  
> - Wool Merchant(20)  
> - Writer(26)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



