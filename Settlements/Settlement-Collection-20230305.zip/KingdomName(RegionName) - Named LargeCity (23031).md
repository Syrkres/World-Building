---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (23031)
terrain: Forest Heavy Fungal 
settlementDescription: 
population: 23031
culture: Viking 
technology: Renaissance 
leader: 
govermentType: Magocracy 
demographics: 
- Acrobat(39) 
- Minstrel(39) 
- Storyteller(39) 
- Troubadours(39) 
- Writer(39) 
- Advocate(29) 
- Clerk(66) 
- Council Member(58) 
- Diplomat(10) 
- Judge(33) 
- Mayor(1) 
- Alchemist(20) 
- Chandler(58) 
- Dye Makers(58) 
- Florist(20) 
- Herbalist(20) 
- Potionmakers(20) 
- Sage(11) 
- Spice Merchant(39) 
- Taxidermist(39) 
- Tobacco Merchant(39) 
- Animal Groomer(16) 
- Animal Handler(39) 
- Caravanner(29) 
- Horse Trader(47) 
- Livestock Merchant(31) 
- Stabler(42) 
- Antiquities(39) 
- Armor Dealer(39) 
- Launderer(39) 
- Oil Trader(58) 
- Trading Post(58) 
- Slaver(39) 
- Spice Merchant(39) 
- Taxidermist(39) 
- Tobacco Merchant(39) 
- Warehouser(39) 
- Weapon Dealer(39) 
- Architect(47) 
- Bricklayer(47) 
- Engineer(47) 
- Laborer(47) 
- Mason(47) 
- Painter(Building)(47) 
- Plasterer(47) 
- Roofer(47) 
- Teamster(47) 
- Tiler(47) 
- Armorer(13) 
- Blacksmith(55) 
- Bowyer-Fletcher(19) 
- Jeweler(15) 
- Silversmith(14) 
- Weapon Dealer(39) 
- Weaponsmith(11) 
- Artist(52) 
- Glassblower(39) 
- Goldsmith(26) 
- Inventor(33) 
- Jeweler(24) 
- Magical Artisan(11) 
- Painter(Art)(42) 
- Silversmith(33) 
- Tinker(58) 
- Toymaker(18) 
- Astrologist(11) 
- Conjourer(11) 
- High Mage(11) 
- Historian(11) 
- Librarian(11) 
- Magical Artisan(11) 
- Magical Tutor(11) 
- Professor(11) 
- Scribe(11) 
- SellSpell(11) 
- Teacher(11) 
- Tutor(11) 
- Baker(36) 
- Beer Merchant(21) 
- Brewer(6) 
- Butcher(24) 
- Chicken Butcher(24) 
- Cook(25) 
- Dairy Seller(116) 
- Distiller(21) 
- Hay Merchant(116) 
- Fisherman(29) 
- Fishmonger(29) 
- Grain Merchant(6) 
- Grocer(18) 
- Meat Butcher(20) 
- Miller(58) 
- Pastry Maker(29) 
- Vintner(25) 
- Banker(13) 
- Pawnbroker(13) 
- Barbarian(116) 
- Brigand(116) 
- Captain(116) 
- Mountainman(116) 
- Barbarian(21) 
- Cartographer(20) 
- Guide(39) 
- Huntsman(58) 
- Mountainman(18) 
- Pathfinder(20) 
- Scout(20) 
- Slaver(39) 
- Barrel Maker(25) 
- Basket Maker(33) 
- Book Binder(12) 
- Bookseller(11) 
- Buckle Maker(18) 
- Candle Maker(15) 
- Clock Maker(11) 
- Cobbler(36) 
- Cooper(28) 
- Cutler(12) 
- Engraver(11) 
- Furniture Maker(36) 
- Glassblower(17) 
- Glazier(11) 
- Glove Merchant(31) 
- Goldsmith(17) 
- Harness Maker(39) 
- Hat Maker(16) 
- Instrument Maker(11) 
- Kettle Maker(11) 
- Locksmith(14) 
- Perfumer(16) 
- Potter(39) 
- Rope Maker(28) 
- Rug Maker(14) 
- Saddler(29) 
- Sculptor(10) 
- Shoe Maker(28) 
- Soap Maker(20) 
- Tanner(29) 
- Tinker(13) 
- Toymaker(11) 
- Weaponsmith(11) 
- Weaver(33) 
- Wheelwright(52) 
- Wine Merchant(20) 
- Wool Merchant(29) 
- Lord(8) 
- Knight(8) 
- Baron(5) 
- Viscount(3) 
- Earl(3) 
- Count(3) 
- Duke(2) 
- ArchDuke(1) 
- Barrel Maker(42) 
- Bowyer-Fletcher(19) 
- Carpenter(66) 
- Roofer(47) 
- Wagon Maker(33) 
- Wheelwright(36) 
- Wood Carver(19) 
- Wood Seller(18) 
- Barber(20) 
- Bleacher(20) 
- Physic/Chirurgeon(20) 
- Bather(16) 
- Brigand(39) 
- Crime Lord(10) 
- Crook(47) 
- Goon(52) 
- Brothel Keeper(16) 
- Innkeeper(31) 
- Tavern Keeper(42) 
- Buckle Maker(31) 
- Cobbler(28) 
- Draper(19) 
- Furrier(52) 
- Girdler(18) 
- Haberdasher(15) 
- Launderer(31) 
- Leatherworker(21) 
- Purse Maker(20) 
- Shoe Maker(28) 
- Tailor(31) 
- Tanner(29) 
- Used Garment Trader(49) 
- Vestment Maker(28) 
- Chandler(58) 
- Dye Makers(58) 
- Oil Trader(58) 
- Cleric(42) 
- High Priest(16) 
- Missionary(154) 
- Preacher(93) 
- Priest(52) 
- Farmer(1152) 
- Homestead(1536) 
- Farmer - Cabbage(116) 
- Farmer - Cattle Herder(116) 
- Farmer - Corn(116) 
- Farmer - Cow Herder(116) 
- Farmer - Dairy(116) 
- Farmer - Goat Herder(116) 
- Farmer - Pig Herder(116) 
- Farmer - Potato(116) 
- Farmer - Sheep Herder(116) 
- Farmer - Wheat(116) 
- Farmer(Special)(116) 
- Dungsweeper(33) 
- Illuminator(24) 
- Messenger(36) 
- Tax Collector(6) 
- Town Crier(66) 
- Town Justice(16) 
- Undertaker(13) 
- Water Carrier(47) 
- Leatherworker(24) 
- Skinner(24) 
- Naval Outfitter(12) 
- Pirate(58) 
- Sail Maker(33) 
- Sailor(77) 
- Ship Builder(14) 
imports: 
- Hides  
exports: 
- Beeswax  
defenses: Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(39)  
> - Advocate(29)  
> - Alchemist(20)  
> - Animal Groomer(16)  
> - Animal Handler(39)  
> - Antiquities(39)  
> - ArchDuke(1)  
> - Architect(47)  
> - Armor Dealer(39)  
> - Armorer(13)  
> - Artist(52)  
> - Astrologist(11)  
> - Baker(36)  
> - Banker(13)  
> - Barbarian(116)  
> - Barbarian(21)  
> - Barber(20)  
> - Baron(5)  
> - Barrel Maker(25)  
> - Barrel Maker(42)  
> - Basket Maker(33)  
> - Bather(16)  
> - Beer Merchant(21)  
> - Blacksmith(55)  
> - Bleacher(20)  
> - Book Binder(12)  
> - Bookseller(11)  
> - Bowyer-Fletcher(19)  
> - Bowyer-Fletcher(19)  
> - Brewer(6)  
> - Bricklayer(47)  
> - Brigand(116)  
> - Brigand(39)  
> - Brothel Keeper(16)  
> - Buckle Maker(18)  
> - Buckle Maker(31)  
> - Butcher(24)  
> - Candle Maker(15)  
> - Captain(116)  
> - Caravanner(29)  
> - Carpenter(66)  
> - Cartographer(20)  
> - Chandler(58)  
> - Chandler(58)  
> - Chicken Butcher(24)  
> - Cleric(42)  
> - Clerk(66)  
> - Clock Maker(11)  
> - Cobbler(28)  
> - Cobbler(36)  
> - Conjourer(11)  
> - Cook(25)  
> - Cooper(28)  
> - Council Member(58)  
> - Count(3)  
> - Crime Lord(10)  
> - Crook(47)  
> - Cutler(12)  
> - Dairy Seller(116)  
> - Diplomat(10)  
> - Distiller(21)  
> - Draper(19)  
> - Duke(2)  
> - Dungsweeper(33)  
> - Dye Makers(58)  
> - Dye Makers(58)  
> - Earl(3)  
> - Engineer(47)  
> - Engraver(11)  
> - Farmer - Cabbage(116)  
> - Farmer - Cattle Herder(116)  
> - Farmer - Corn(116)  
> - Farmer - Cow Herder(116)  
> - Farmer - Dairy(116)  
> - Farmer - Goat Herder(116)  
> - Farmer - Pig Herder(116)  
> - Farmer - Potato(116)  
> - Farmer - Sheep Herder(116)  
> - Farmer - Wheat(116)  
> - Farmer(1152)  
> - Farmer(Special)(116)  
> - Fisherman(29)  
> - Fishmonger(29)  
> - Florist(20)  
> - Furniture Maker(36)  
> - Furrier(52)  
> - Girdler(18)  
> - Glassblower(17)  
> - Glassblower(39)  
> - Glazier(11)  
> - Glove Merchant(31)  
> - Goldsmith(17)  
> - Goldsmith(26)  
> - Goon(52)  
> - Grain Merchant(6)  
> - Grocer(18)  
> - Guide(39)  
> - Haberdasher(15)  
> - Harness Maker(39)  
> - Hat Maker(16)  
> - Hay Merchant(116)  
> - Herbalist(20)  
> - High Mage(11)  
> - High Priest(16)  
> - Historian(11)  
> - Homestead(1536)  
> - Horse Trader(47)  
> - Huntsman(58)  
> - Illuminator(24)  
> - Innkeeper(31)  
> - Instrument Maker(11)  
> - Inventor(33)  
> - Jeweler(15)  
> - Jeweler(24)  
> - Judge(33)  
> - Kettle Maker(11)  
> - Knight(8)  
> - Laborer(47)  
> - Launderer(31)  
> - Launderer(39)  
> - Leatherworker(21)  
> - Leatherworker(24)  
> - Librarian(11)  
> - Livestock Merchant(31)  
> - Locksmith(14)  
> - Lord(8)  
> - Magical Artisan(11)  
> - Magical Artisan(11)  
> - Magical Tutor(11)  
> - Mason(47)  
> - Mayor(1)  
> - Meat Butcher(20)  
> - Messenger(36)  
> - Miller(58)  
> - Minstrel(39)  
> - Missionary(154)  
> - Mountainman(116)  
> - Mountainman(18)  
> - Naval Outfitter(12)  
> - Oil Trader(58)  
> - Oil Trader(58)  
> - Painter(Art)(42)  
> - Painter(Building)(47)  
> - Pastry Maker(29)  
> - Pathfinder(20)  
> - Pawnbroker(13)  
> - Perfumer(16)  
> - Physic/Chirurgeon(20)  
> - Pirate(58)  
> - Plasterer(47)  
> - Potionmakers(20)  
> - Potter(39)  
> - Preacher(93)  
> - Priest(52)  
> - Professor(11)  
> - Purse Maker(20)  
> - Roofer(47)  
> - Roofer(47)  
> - Rope Maker(28)  
> - Rug Maker(14)  
> - Saddler(29)  
> - Sage(11)  
> - Sail Maker(33)  
> - Sailor(77)  
> - Scout(20)  
> - Scribe(11)  
> - Sculptor(10)  
> - SellSpell(11)  
> - Ship Builder(14)  
> - Shoe Maker(28)  
> - Shoe Maker(28)  
> - Silversmith(14)  
> - Silversmith(33)  
> - Skinner(24)  
> - Slaver(39)  
> - Slaver(39)  
> - Soap Maker(20)  
> - Spice Merchant(39)  
> - Spice Merchant(39)  
> - Stabler(42)  
> - Storyteller(39)  
> - Tailor(31)  
> - Tanner(29)  
> - Tanner(29)  
> - Tavern Keeper(42)  
> - Tax Collector(6)  
> - Taxidermist(39)  
> - Taxidermist(39)  
> - Teacher(11)  
> - Teamster(47)  
> - Tiler(47)  
> - Tinker(13)  
> - Tinker(58)  
> - Tobacco Merchant(39)  
> - Tobacco Merchant(39)  
> - Town Crier(66)  
> - Town Justice(16)  
> - Toymaker(11)  
> - Toymaker(18)  
> - Trading Post(58)  
> - Troubadours(39)  
> - Tutor(11)  
> - Undertaker(13)  
> - Used Garment Trader(49)  
> - Vestment Maker(28)  
> - Vintner(25)  
> - Viscount(3)  
> - Wagon Maker(33)  
> - Warehouser(39)  
> - Water Carrier(47)  
> - Weapon Dealer(39)  
> - Weapon Dealer(39)  
> - Weaponsmith(11)  
> - Weaponsmith(11)  
> - Weaver(33)  
> - Wheelwright(36)  
> - Wheelwright(52)  
> - Wine Merchant(20)  
> - Wood Carver(19)  
> - Wood Seller(18)  
> - Wool Merchant(29)  
> - Writer(39)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(39)  
> - Advocate(29)  
> - Alchemist(20)  
> - Animal Groomer(16)  
> - Animal Handler(39)  
> - Antiquities(39)  
> - ArchDuke(1)  
> - Architect(47)  
> - Armor Dealer(39)  
> - Armorer(13)  
> - Artist(52)  
> - Astrologist(11)  
> - Baker(36)  
> - Banker(13)  
> - Barbarian(116)  
> - Barbarian(21)  
> - Barber(20)  
> - Baron(5)  
> - Barrel Maker(25)  
> - Barrel Maker(42)  
> - Basket Maker(33)  
> - Bather(16)  
> - Beer Merchant(21)  
> - Blacksmith(55)  
> - Bleacher(20)  
> - Book Binder(12)  
> - Bookseller(11)  
> - Bowyer-Fletcher(19)  
> - Bowyer-Fletcher(19)  
> - Brewer(6)  
> - Bricklayer(47)  
> - Brigand(116)  
> - Brigand(39)  
> - Brothel Keeper(16)  
> - Buckle Maker(18)  
> - Buckle Maker(31)  
> - Butcher(24)  
> - Candle Maker(15)  
> - Captain(116)  
> - Caravanner(29)  
> - Carpenter(66)  
> - Cartographer(20)  
> - Chandler(58)  
> - Chandler(58)  
> - Chicken Butcher(24)  
> - Cleric(42)  
> - Clerk(66)  
> - Clock Maker(11)  
> - Cobbler(28)  
> - Cobbler(36)  
> - Conjourer(11)  
> - Cook(25)  
> - Cooper(28)  
> - Council Member(58)  
> - Count(3)  
> - Crime Lord(10)  
> - Crook(47)  
> - Cutler(12)  
> - Dairy Seller(116)  
> - Diplomat(10)  
> - Distiller(21)  
> - Draper(19)  
> - Duke(2)  
> - Dungsweeper(33)  
> - Dye Makers(58)  
> - Dye Makers(58)  
> - Earl(3)  
> - Engineer(47)  
> - Engraver(11)  
> - Farmer - Cabbage(116)  
> - Farmer - Cattle Herder(116)  
> - Farmer - Corn(116)  
> - Farmer - Cow Herder(116)  
> - Farmer - Dairy(116)  
> - Farmer - Goat Herder(116)  
> - Farmer - Pig Herder(116)  
> - Farmer - Potato(116)  
> - Farmer - Sheep Herder(116)  
> - Farmer - Wheat(116)  
> - Farmer(1152)  
> - Farmer(Special)(116)  
> - Fisherman(29)  
> - Fishmonger(29)  
> - Florist(20)  
> - Furniture Maker(36)  
> - Furrier(52)  
> - Girdler(18)  
> - Glassblower(17)  
> - Glassblower(39)  
> - Glazier(11)  
> - Glove Merchant(31)  
> - Goldsmith(17)  
> - Goldsmith(26)  
> - Goon(52)  
> - Grain Merchant(6)  
> - Grocer(18)  
> - Guide(39)  
> - Haberdasher(15)  
> - Harness Maker(39)  
> - Hat Maker(16)  
> - Hay Merchant(116)  
> - Herbalist(20)  
> - High Mage(11)  
> - High Priest(16)  
> - Historian(11)  
> - Homestead(1536)  
> - Horse Trader(47)  
> - Huntsman(58)  
> - Illuminator(24)  
> - Innkeeper(31)  
> - Instrument Maker(11)  
> - Inventor(33)  
> - Jeweler(15)  
> - Jeweler(24)  
> - Judge(33)  
> - Kettle Maker(11)  
> - Knight(8)  
> - Laborer(47)  
> - Launderer(31)  
> - Launderer(39)  
> - Leatherworker(21)  
> - Leatherworker(24)  
> - Librarian(11)  
> - Livestock Merchant(31)  
> - Locksmith(14)  
> - Lord(8)  
> - Magical Artisan(11)  
> - Magical Artisan(11)  
> - Magical Tutor(11)  
> - Mason(47)  
> - Mayor(1)  
> - Meat Butcher(20)  
> - Messenger(36)  
> - Miller(58)  
> - Minstrel(39)  
> - Missionary(154)  
> - Mountainman(116)  
> - Mountainman(18)  
> - Naval Outfitter(12)  
> - Oil Trader(58)  
> - Oil Trader(58)  
> - Painter(Art)(42)  
> - Painter(Building)(47)  
> - Pastry Maker(29)  
> - Pathfinder(20)  
> - Pawnbroker(13)  
> - Perfumer(16)  
> - Physic/Chirurgeon(20)  
> - Pirate(58)  
> - Plasterer(47)  
> - Potionmakers(20)  
> - Potter(39)  
> - Preacher(93)  
> - Priest(52)  
> - Professor(11)  
> - Purse Maker(20)  
> - Roofer(47)  
> - Roofer(47)  
> - Rope Maker(28)  
> - Rug Maker(14)  
> - Saddler(29)  
> - Sage(11)  
> - Sail Maker(33)  
> - Sailor(77)  
> - Scout(20)  
> - Scribe(11)  
> - Sculptor(10)  
> - SellSpell(11)  
> - Ship Builder(14)  
> - Shoe Maker(28)  
> - Shoe Maker(28)  
> - Silversmith(14)  
> - Silversmith(33)  
> - Skinner(24)  
> - Slaver(39)  
> - Slaver(39)  
> - Soap Maker(20)  
> - Spice Merchant(39)  
> - Spice Merchant(39)  
> - Stabler(42)  
> - Storyteller(39)  
> - Tailor(31)  
> - Tanner(29)  
> - Tanner(29)  
> - Tavern Keeper(42)  
> - Tax Collector(6)  
> - Taxidermist(39)  
> - Taxidermist(39)  
> - Teacher(11)  
> - Teamster(47)  
> - Tiler(47)  
> - Tinker(13)  
> - Tinker(58)  
> - Tobacco Merchant(39)  
> - Tobacco Merchant(39)  
> - Town Crier(66)  
> - Town Justice(16)  
> - Toymaker(11)  
> - Toymaker(18)  
> - Trading Post(58)  
> - Troubadours(39)  
> - Tutor(11)  
> - Undertaker(13)  
> - Used Garment Trader(49)  
> - Vestment Maker(28)  
> - Vintner(25)  
> - Viscount(3)  
> - Wagon Maker(33)  
> - Warehouser(39)  
> - Water Carrier(47)  
> - Weapon Dealer(39)  
> - Weapon Dealer(39)  
> - Weaponsmith(11)  
> - Weaponsmith(11)  
> - Weaver(33)  
> - Wheelwright(36)  
> - Wheelwright(52)  
> - Wine Merchant(20)  
> - Wood Carver(19)  
> - Wood Seller(18)  
> - Wool Merchant(29)  
> - Writer(39)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



