---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (28101)
terrain: Desert Sands 
settlementDescription: 
population: 28101
culture: African 
technology: Bronze Age 
leader: 
govermentType: Anarchy 
demographics: 
- Acrobat(47) 
- Minstrel(47) 
- Storyteller(47) 
- Troubadours(47) 
- Writer(47) 
- Advocate(36) 
- Clerk(81) 
- Council Member(71) 
- Diplomat(12) 
- Judge(41) 
- Mayor(1) 
- Alchemist(24) 
- Chandler(71) 
- Dye Makers(71) 
- Florist(24) 
- Herbalist(24) 
- Potionmakers(24) 
- Sage(13) 
- Spice Merchant(47) 
- Taxidermist(47) 
- Tobacco Merchant(47) 
- Animal Groomer(19) 
- Animal Handler(47) 
- Caravanner(36) 
- Horse Trader(57) 
- Livestock Merchant(38) 
- Stabler(51) 
- Antiquities(47) 
- Armor Dealer(47) 
- Launderer(47) 
- Oil Trader(71) 
- Trading Post(71) 
- Slaver(47) 
- Spice Merchant(47) 
- Taxidermist(47) 
- Tobacco Merchant(47) 
- Warehouser(47) 
- Weapon Dealer(47) 
- Architect(57) 
- Bricklayer(57) 
- Engineer(57) 
- Laborer(57) 
- Mason(57) 
- Painter(Building)(57) 
- Plasterer(57) 
- Roofer(57) 
- Teamster(57) 
- Tiler(57) 
- Armorer(15) 
- Blacksmith(67) 
- Bowyer-Fletcher(23) 
- Jeweler(18) 
- Silversmith(17) 
- Weapon Dealer(47) 
- Weaponsmith(14) 
- Artist(63) 
- Glassblower(47) 
- Goldsmith(32) 
- Inventor(41) 
- Jeweler(29) 
- Magical Artisan(13) 
- Painter(Art)(52) 
- Silversmith(41) 
- Tinker(71) 
- Toymaker(22) 
- Astrologist(13) 
- Conjourer(13) 
- High Mage(13) 
- Historian(13) 
- Librarian(13) 
- Magical Artisan(13) 
- Magical Tutor(13) 
- Professor(13) 
- Scribe(13) 
- SellSpell(13) 
- Teacher(13) 
- Tutor(13) 
- Baker(44) 
- Beer Merchant(26) 
- Brewer(7) 
- Butcher(29) 
- Chicken Butcher(29) 
- Cook(30) 
- Dairy Seller(141) 
- Distiller(26) 
- Hay Merchant(141) 
- Fisherman(36) 
- Fishmonger(36) 
- Grain Merchant(8) 
- Grocer(21) 
- Meat Butcher(24) 
- Miller(71) 
- Pastry Maker(36) 
- Vintner(30) 
- Banker(16) 
- Pawnbroker(16) 
- Barbarian(141) 
- Brigand(141) 
- Captain(141) 
- Mountainman(141) 
- Barbarian(26) 
- Cartographer(24) 
- Guide(47) 
- Huntsman(71) 
- Mountainman(22) 
- Pathfinder(24) 
- Scout(24) 
- Slaver(47) 
- Barrel Maker(30) 
- Basket Maker(41) 
- Book Binder(15) 
- Bookseller(14) 
- Buckle Maker(22) 
- Candle Maker(18) 
- Clock Maker(13) 
- Cobbler(44) 
- Cooper(34) 
- Cutler(15) 
- Engraver(13) 
- Furniture Maker(44) 
- Glassblower(21) 
- Glazier(14) 
- Glove Merchant(38) 
- Goldsmith(21) 
- Harness Maker(47) 
- Hat Maker(19) 
- Instrument Maker(13) 
- Kettle Maker(13) 
- Locksmith(17) 
- Perfumer(20) 
- Potter(47) 
- Rope Maker(34) 
- Rug Maker(18) 
- Saddler(36) 
- Sculptor(12) 
- Shoe Maker(34) 
- Soap Maker(24) 
- Tanner(36) 
- Tinker(16) 
- Toymaker(13) 
- Weaponsmith(14) 
- Weaver(41) 
- Wheelwright(63) 
- Wine Merchant(24) 
- Wool Merchant(36) 
- Lord(10) 
- Knight(10) 
- Baron(6) 
- Viscount(4) 
- Earl(3) 
- Count(3) 
- Duke(2) 
- ArchDuke(1) 
- Barrel Maker(52) 
- Bowyer-Fletcher(23) 
- Carpenter(81) 
- Roofer(57) 
- Wagon Maker(41) 
- Wheelwright(44) 
- Wood Carver(23) 
- Wood Seller(21) 
- Barber(24) 
- Bleacher(24) 
- Physic/Chirurgeon(24) 
- Bather(19) 
- Brigand(47) 
- Crime Lord(12) 
- Crook(57) 
- Goon(63) 
- Brothel Keeper(20) 
- Innkeeper(38) 
- Tavern Keeper(52) 
- Buckle Maker(38) 
- Cobbler(34) 
- Draper(24) 
- Furrier(63) 
- Girdler(21) 
- Haberdasher(19) 
- Launderer(38) 
- Leatherworker(26) 
- Purse Maker(24) 
- Shoe Maker(34) 
- Tailor(38) 
- Tanner(36) 
- Used Garment Trader(60) 
- Vestment Maker(34) 
- Chandler(71) 
- Dye Makers(71) 
- Oil Trader(71) 
- Cleric(52) 
- High Priest(20) 
- Missionary(188) 
- Preacher(113) 
- Priest(63) 
- Farmer(1406) 
- Homestead(1874) 
- Farmer - Cabbage(141) 
- Farmer - Cattle Herder(141) 
- Farmer - Corn(141) 
- Farmer - Cow Herder(141) 
- Farmer - Dairy(141) 
- Farmer - Goat Herder(141) 
- Farmer - Pig Herder(141) 
- Farmer - Potato(141) 
- Farmer - Sheep Herder(141) 
- Farmer - Wheat(141) 
- Farmer(Special)(141) 
- Dungsweeper(40) 
- Illuminator(29) 
- Messenger(44) 
- Tax Collector(8) 
- Town Crier(81) 
- Town Justice(19) 
- Undertaker(16) 
- Water Carrier(57) 
- Leatherworker(29) 
- Skinner(29) 
- Naval Outfitter(15) 
- Pirate(71) 
- Sail Maker(41) 
- Sailor(94) 
- Ship Builder(17) 
imports: 
- Sandstone  
exports: 
- Herbs  
defenses: Killing Fields 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(47)  
> - Advocate(36)  
> - Alchemist(24)  
> - Animal Groomer(19)  
> - Animal Handler(47)  
> - Antiquities(47)  
> - ArchDuke(1)  
> - Architect(57)  
> - Armor Dealer(47)  
> - Armorer(15)  
> - Artist(63)  
> - Astrologist(13)  
> - Baker(44)  
> - Banker(16)  
> - Barbarian(141)  
> - Barbarian(26)  
> - Barber(24)  
> - Baron(6)  
> - Barrel Maker(30)  
> - Barrel Maker(52)  
> - Basket Maker(41)  
> - Bather(19)  
> - Beer Merchant(26)  
> - Blacksmith(67)  
> - Bleacher(24)  
> - Book Binder(15)  
> - Bookseller(14)  
> - Bowyer-Fletcher(23)  
> - Bowyer-Fletcher(23)  
> - Brewer(7)  
> - Bricklayer(57)  
> - Brigand(141)  
> - Brigand(47)  
> - Brothel Keeper(20)  
> - Buckle Maker(22)  
> - Buckle Maker(38)  
> - Butcher(29)  
> - Candle Maker(18)  
> - Captain(141)  
> - Caravanner(36)  
> - Carpenter(81)  
> - Cartographer(24)  
> - Chandler(71)  
> - Chandler(71)  
> - Chicken Butcher(29)  
> - Cleric(52)  
> - Clerk(81)  
> - Clock Maker(13)  
> - Cobbler(34)  
> - Cobbler(44)  
> - Conjourer(13)  
> - Cook(30)  
> - Cooper(34)  
> - Council Member(71)  
> - Count(3)  
> - Crime Lord(12)  
> - Crook(57)  
> - Cutler(15)  
> - Dairy Seller(141)  
> - Diplomat(12)  
> - Distiller(26)  
> - Draper(24)  
> - Duke(2)  
> - Dungsweeper(40)  
> - Dye Makers(71)  
> - Dye Makers(71)  
> - Earl(3)  
> - Engineer(57)  
> - Engraver(13)  
> - Farmer - Cabbage(141)  
> - Farmer - Cattle Herder(141)  
> - Farmer - Corn(141)  
> - Farmer - Cow Herder(141)  
> - Farmer - Dairy(141)  
> - Farmer - Goat Herder(141)  
> - Farmer - Pig Herder(141)  
> - Farmer - Potato(141)  
> - Farmer - Sheep Herder(141)  
> - Farmer - Wheat(141)  
> - Farmer(1406)  
> - Farmer(Special)(141)  
> - Fisherman(36)  
> - Fishmonger(36)  
> - Florist(24)  
> - Furniture Maker(44)  
> - Furrier(63)  
> - Girdler(21)  
> - Glassblower(21)  
> - Glassblower(47)  
> - Glazier(14)  
> - Glove Merchant(38)  
> - Goldsmith(21)  
> - Goldsmith(32)  
> - Goon(63)  
> - Grain Merchant(8)  
> - Grocer(21)  
> - Guide(47)  
> - Haberdasher(19)  
> - Harness Maker(47)  
> - Hat Maker(19)  
> - Hay Merchant(141)  
> - Herbalist(24)  
> - High Mage(13)  
> - High Priest(20)  
> - Historian(13)  
> - Homestead(1874)  
> - Horse Trader(57)  
> - Huntsman(71)  
> - Illuminator(29)  
> - Innkeeper(38)  
> - Instrument Maker(13)  
> - Inventor(41)  
> - Jeweler(18)  
> - Jeweler(29)  
> - Judge(41)  
> - Kettle Maker(13)  
> - Knight(10)  
> - Laborer(57)  
> - Launderer(38)  
> - Launderer(47)  
> - Leatherworker(26)  
> - Leatherworker(29)  
> - Librarian(13)  
> - Livestock Merchant(38)  
> - Locksmith(17)  
> - Lord(10)  
> - Magical Artisan(13)  
> - Magical Artisan(13)  
> - Magical Tutor(13)  
> - Mason(57)  
> - Mayor(1)  
> - Meat Butcher(24)  
> - Messenger(44)  
> - Miller(71)  
> - Minstrel(47)  
> - Missionary(188)  
> - Mountainman(141)  
> - Mountainman(22)  
> - Naval Outfitter(15)  
> - Oil Trader(71)  
> - Oil Trader(71)  
> - Painter(Art)(52)  
> - Painter(Building)(57)  
> - Pastry Maker(36)  
> - Pathfinder(24)  
> - Pawnbroker(16)  
> - Perfumer(20)  
> - Physic/Chirurgeon(24)  
> - Pirate(71)  
> - Plasterer(57)  
> - Potionmakers(24)  
> - Potter(47)  
> - Preacher(113)  
> - Priest(63)  
> - Professor(13)  
> - Purse Maker(24)  
> - Roofer(57)  
> - Roofer(57)  
> - Rope Maker(34)  
> - Rug Maker(18)  
> - Saddler(36)  
> - Sage(13)  
> - Sail Maker(41)  
> - Sailor(94)  
> - Scout(24)  
> - Scribe(13)  
> - Sculptor(12)  
> - SellSpell(13)  
> - Ship Builder(17)  
> - Shoe Maker(34)  
> - Shoe Maker(34)  
> - Silversmith(17)  
> - Silversmith(41)  
> - Skinner(29)  
> - Slaver(47)  
> - Slaver(47)  
> - Soap Maker(24)  
> - Spice Merchant(47)  
> - Spice Merchant(47)  
> - Stabler(51)  
> - Storyteller(47)  
> - Tailor(38)  
> - Tanner(36)  
> - Tanner(36)  
> - Tavern Keeper(52)  
> - Tax Collector(8)  
> - Taxidermist(47)  
> - Taxidermist(47)  
> - Teacher(13)  
> - Teamster(57)  
> - Tiler(57)  
> - Tinker(16)  
> - Tinker(71)  
> - Tobacco Merchant(47)  
> - Tobacco Merchant(47)  
> - Town Crier(81)  
> - Town Justice(19)  
> - Toymaker(13)  
> - Toymaker(22)  
> - Trading Post(71)  
> - Troubadours(47)  
> - Tutor(13)  
> - Undertaker(16)  
> - Used Garment Trader(60)  
> - Vestment Maker(34)  
> - Vintner(30)  
> - Viscount(4)  
> - Wagon Maker(41)  
> - Warehouser(47)  
> - Water Carrier(57)  
> - Weapon Dealer(47)  
> - Weapon Dealer(47)  
> - Weaponsmith(14)  
> - Weaponsmith(14)  
> - Weaver(41)  
> - Wheelwright(44)  
> - Wheelwright(63)  
> - Wine Merchant(24)  
> - Wood Carver(23)  
> - Wood Seller(21)  
> - Wool Merchant(36)  
> - Writer(47)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(47)  
> - Advocate(36)  
> - Alchemist(24)  
> - Animal Groomer(19)  
> - Animal Handler(47)  
> - Antiquities(47)  
> - ArchDuke(1)  
> - Architect(57)  
> - Armor Dealer(47)  
> - Armorer(15)  
> - Artist(63)  
> - Astrologist(13)  
> - Baker(44)  
> - Banker(16)  
> - Barbarian(141)  
> - Barbarian(26)  
> - Barber(24)  
> - Baron(6)  
> - Barrel Maker(30)  
> - Barrel Maker(52)  
> - Basket Maker(41)  
> - Bather(19)  
> - Beer Merchant(26)  
> - Blacksmith(67)  
> - Bleacher(24)  
> - Book Binder(15)  
> - Bookseller(14)  
> - Bowyer-Fletcher(23)  
> - Bowyer-Fletcher(23)  
> - Brewer(7)  
> - Bricklayer(57)  
> - Brigand(141)  
> - Brigand(47)  
> - Brothel Keeper(20)  
> - Buckle Maker(22)  
> - Buckle Maker(38)  
> - Butcher(29)  
> - Candle Maker(18)  
> - Captain(141)  
> - Caravanner(36)  
> - Carpenter(81)  
> - Cartographer(24)  
> - Chandler(71)  
> - Chandler(71)  
> - Chicken Butcher(29)  
> - Cleric(52)  
> - Clerk(81)  
> - Clock Maker(13)  
> - Cobbler(34)  
> - Cobbler(44)  
> - Conjourer(13)  
> - Cook(30)  
> - Cooper(34)  
> - Council Member(71)  
> - Count(3)  
> - Crime Lord(12)  
> - Crook(57)  
> - Cutler(15)  
> - Dairy Seller(141)  
> - Diplomat(12)  
> - Distiller(26)  
> - Draper(24)  
> - Duke(2)  
> - Dungsweeper(40)  
> - Dye Makers(71)  
> - Dye Makers(71)  
> - Earl(3)  
> - Engineer(57)  
> - Engraver(13)  
> - Farmer - Cabbage(141)  
> - Farmer - Cattle Herder(141)  
> - Farmer - Corn(141)  
> - Farmer - Cow Herder(141)  
> - Farmer - Dairy(141)  
> - Farmer - Goat Herder(141)  
> - Farmer - Pig Herder(141)  
> - Farmer - Potato(141)  
> - Farmer - Sheep Herder(141)  
> - Farmer - Wheat(141)  
> - Farmer(1406)  
> - Farmer(Special)(141)  
> - Fisherman(36)  
> - Fishmonger(36)  
> - Florist(24)  
> - Furniture Maker(44)  
> - Furrier(63)  
> - Girdler(21)  
> - Glassblower(21)  
> - Glassblower(47)  
> - Glazier(14)  
> - Glove Merchant(38)  
> - Goldsmith(21)  
> - Goldsmith(32)  
> - Goon(63)  
> - Grain Merchant(8)  
> - Grocer(21)  
> - Guide(47)  
> - Haberdasher(19)  
> - Harness Maker(47)  
> - Hat Maker(19)  
> - Hay Merchant(141)  
> - Herbalist(24)  
> - High Mage(13)  
> - High Priest(20)  
> - Historian(13)  
> - Homestead(1874)  
> - Horse Trader(57)  
> - Huntsman(71)  
> - Illuminator(29)  
> - Innkeeper(38)  
> - Instrument Maker(13)  
> - Inventor(41)  
> - Jeweler(18)  
> - Jeweler(29)  
> - Judge(41)  
> - Kettle Maker(13)  
> - Knight(10)  
> - Laborer(57)  
> - Launderer(38)  
> - Launderer(47)  
> - Leatherworker(26)  
> - Leatherworker(29)  
> - Librarian(13)  
> - Livestock Merchant(38)  
> - Locksmith(17)  
> - Lord(10)  
> - Magical Artisan(13)  
> - Magical Artisan(13)  
> - Magical Tutor(13)  
> - Mason(57)  
> - Mayor(1)  
> - Meat Butcher(24)  
> - Messenger(44)  
> - Miller(71)  
> - Minstrel(47)  
> - Missionary(188)  
> - Mountainman(141)  
> - Mountainman(22)  
> - Naval Outfitter(15)  
> - Oil Trader(71)  
> - Oil Trader(71)  
> - Painter(Art)(52)  
> - Painter(Building)(57)  
> - Pastry Maker(36)  
> - Pathfinder(24)  
> - Pawnbroker(16)  
> - Perfumer(20)  
> - Physic/Chirurgeon(24)  
> - Pirate(71)  
> - Plasterer(57)  
> - Potionmakers(24)  
> - Potter(47)  
> - Preacher(113)  
> - Priest(63)  
> - Professor(13)  
> - Purse Maker(24)  
> - Roofer(57)  
> - Roofer(57)  
> - Rope Maker(34)  
> - Rug Maker(18)  
> - Saddler(36)  
> - Sage(13)  
> - Sail Maker(41)  
> - Sailor(94)  
> - Scout(24)  
> - Scribe(13)  
> - Sculptor(12)  
> - SellSpell(13)  
> - Ship Builder(17)  
> - Shoe Maker(34)  
> - Shoe Maker(34)  
> - Silversmith(17)  
> - Silversmith(41)  
> - Skinner(29)  
> - Slaver(47)  
> - Slaver(47)  
> - Soap Maker(24)  
> - Spice Merchant(47)  
> - Spice Merchant(47)  
> - Stabler(51)  
> - Storyteller(47)  
> - Tailor(38)  
> - Tanner(36)  
> - Tanner(36)  
> - Tavern Keeper(52)  
> - Tax Collector(8)  
> - Taxidermist(47)  
> - Taxidermist(47)  
> - Teacher(13)  
> - Teamster(57)  
> - Tiler(57)  
> - Tinker(16)  
> - Tinker(71)  
> - Tobacco Merchant(47)  
> - Tobacco Merchant(47)  
> - Town Crier(81)  
> - Town Justice(19)  
> - Toymaker(13)  
> - Toymaker(22)  
> - Trading Post(71)  
> - Troubadours(47)  
> - Tutor(13)  
> - Undertaker(16)  
> - Used Garment Trader(60)  
> - Vestment Maker(34)  
> - Vintner(30)  
> - Viscount(4)  
> - Wagon Maker(41)  
> - Warehouser(47)  
> - Water Carrier(57)  
> - Weapon Dealer(47)  
> - Weapon Dealer(47)  
> - Weaponsmith(14)  
> - Weaponsmith(14)  
> - Weaver(41)  
> - Wheelwright(44)  
> - Wheelwright(63)  
> - Wine Merchant(24)  
> - Wood Carver(23)  
> - Wood Seller(21)  
> - Wool Merchant(36)  
> - Writer(47)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



