---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (20198)
terrain: Valley 
settlementDescription: 
population: 20198
culture: Persian 
technology: Savage 
leader: 
govermentType: Oligarchy 
demographics: 
- Acrobat(34) 
- Minstrel(34) 
- Storyteller(34) 
- Troubadours(34) 
- Writer(34) 
- Advocate(26) 
- Clerk(58) 
- Council Member(51) 
- Diplomat(9) 
- Judge(29) 
- Mayor(1) 
- Alchemist(17) 
- Chandler(51) 
- Dye Makers(51) 
- Florist(17) 
- Herbalist(17) 
- Potionmakers(17) 
- Sage(10) 
- Spice Merchant(34) 
- Taxidermist(34) 
- Tobacco Merchant(34) 
- Animal Groomer(14) 
- Animal Handler(34) 
- Caravanner(26) 
- Horse Trader(41) 
- Livestock Merchant(27) 
- Stabler(37) 
- Antiquities(34) 
- Armor Dealer(34) 
- Launderer(34) 
- Oil Trader(51) 
- Trading Post(51) 
- Slaver(34) 
- Spice Merchant(34) 
- Taxidermist(34) 
- Tobacco Merchant(34) 
- Warehouser(34) 
- Weapon Dealer(34) 
- Architect(41) 
- Bricklayer(41) 
- Engineer(41) 
- Laborer(41) 
- Mason(41) 
- Painter(Building)(41) 
- Plasterer(41) 
- Roofer(41) 
- Teamster(41) 
- Tiler(41) 
- Armorer(11) 
- Blacksmith(48) 
- Bowyer-Fletcher(17) 
- Jeweler(13) 
- Silversmith(12) 
- Weapon Dealer(34) 
- Weaponsmith(10) 
- Artist(45) 
- Glassblower(34) 
- Goldsmith(23) 
- Inventor(29) 
- Jeweler(21) 
- Magical Artisan(10) 
- Painter(Art)(37) 
- Silversmith(29) 
- Tinker(51) 
- Toymaker(16) 
- Astrologist(10) 
- Conjourer(10) 
- High Mage(10) 
- Historian(10) 
- Librarian(10) 
- Magical Artisan(10) 
- Magical Tutor(10) 
- Professor(10) 
- Scribe(10) 
- SellSpell(10) 
- Teacher(10) 
- Tutor(10) 
- Baker(32) 
- Beer Merchant(19) 
- Brewer(5) 
- Butcher(21) 
- Chicken Butcher(21) 
- Cook(22) 
- Dairy Seller(101) 
- Distiller(19) 
- Hay Merchant(101) 
- Fisherman(26) 
- Fishmonger(26) 
- Grain Merchant(6) 
- Grocer(15) 
- Meat Butcher(17) 
- Miller(51) 
- Pastry Maker(26) 
- Vintner(22) 
- Banker(12) 
- Pawnbroker(12) 
- Barbarian(101) 
- Brigand(101) 
- Captain(101) 
- Mountainman(101) 
- Barbarian(19) 
- Cartographer(17) 
- Guide(34) 
- Huntsman(51) 
- Mountainman(16) 
- Pathfinder(17) 
- Scout(17) 
- Slaver(34) 
- Barrel Maker(22) 
- Basket Maker(29) 
- Book Binder(11) 
- Bookseller(10) 
- Buckle Maker(16) 
- Candle Maker(13) 
- Clock Maker(10) 
- Cobbler(32) 
- Cooper(24) 
- Cutler(11) 
- Engraver(10) 
- Furniture Maker(32) 
- Glassblower(15) 
- Glazier(10) 
- Glove Merchant(27) 
- Goldsmith(15) 
- Harness Maker(34) 
- Hat Maker(14) 
- Instrument Maker(10) 
- Kettle Maker(9) 
- Locksmith(12) 
- Perfumer(14) 
- Potter(34) 
- Rope Maker(24) 
- Rug Maker(13) 
- Saddler(26) 
- Sculptor(9) 
- Shoe Maker(24) 
- Soap Maker(17) 
- Tanner(26) 
- Tinker(12) 
- Toymaker(10) 
- Weaponsmith(10) 
- Weaver(29) 
- Wheelwright(45) 
- Wine Merchant(17) 
- Wool Merchant(26) 
- Lord(7) 
- Knight(7) 
- Baron(5) 
- Viscount(3) 
- Earl(3) 
- Count(2) 
- Duke(2) 
- ArchDuke(1) 
- Barrel Maker(37) 
- Bowyer-Fletcher(17) 
- Carpenter(58) 
- Roofer(41) 
- Wagon Maker(29) 
- Wheelwright(32) 
- Wood Carver(17) 
- Wood Seller(15) 
- Barber(17) 
- Bleacher(17) 
- Physic/Chirurgeon(17) 
- Bather(14) 
- Brigand(34) 
- Crime Lord(9) 
- Crook(41) 
- Goon(45) 
- Brothel Keeper(14) 
- Innkeeper(27) 
- Tavern Keeper(37) 
- Buckle Maker(27) 
- Cobbler(24) 
- Draper(17) 
- Furrier(45) 
- Girdler(15) 
- Haberdasher(14) 
- Launderer(27) 
- Leatherworker(19) 
- Purse Maker(17) 
- Shoe Maker(24) 
- Tailor(27) 
- Tanner(26) 
- Used Garment Trader(43) 
- Vestment Maker(24) 
- Chandler(51) 
- Dye Makers(51) 
- Oil Trader(51) 
- Cleric(37) 
- High Priest(14) 
- Missionary(135) 
- Preacher(81) 
- Priest(45) 
- Farmer(1010) 
- Homestead(1347) 
- Farmer - Cabbage(101) 
- Farmer - Cattle Herder(101) 
- Farmer - Corn(101) 
- Farmer - Cow Herder(101) 
- Farmer - Dairy(101) 
- Farmer - Goat Herder(101) 
- Farmer - Pig Herder(101) 
- Farmer - Potato(101) 
- Farmer - Sheep Herder(101) 
- Farmer - Wheat(101) 
- Farmer(Special)(101) 
- Dungsweeper(29) 
- Illuminator(21) 
- Messenger(32) 
- Tax Collector(6) 
- Town Crier(58) 
- Town Justice(14) 
- Undertaker(12) 
- Water Carrier(41) 
- Leatherworker(21) 
- Skinner(21) 
- Naval Outfitter(11) 
- Pirate(51) 
- Sail Maker(29) 
- Sailor(68) 
- Ship Builder(12) 
imports: 
- Ceramics  
exports: 
- Beer  
defenses: Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(34)  
> - Advocate(26)  
> - Alchemist(17)  
> - Animal Groomer(14)  
> - Animal Handler(34)  
> - Antiquities(34)  
> - ArchDuke(1)  
> - Architect(41)  
> - Armor Dealer(34)  
> - Armorer(11)  
> - Artist(45)  
> - Astrologist(10)  
> - Baker(32)  
> - Banker(12)  
> - Barbarian(101)  
> - Barbarian(19)  
> - Barber(17)  
> - Baron(5)  
> - Barrel Maker(22)  
> - Barrel Maker(37)  
> - Basket Maker(29)  
> - Bather(14)  
> - Beer Merchant(19)  
> - Blacksmith(48)  
> - Bleacher(17)  
> - Book Binder(11)  
> - Bookseller(10)  
> - Bowyer-Fletcher(17)  
> - Bowyer-Fletcher(17)  
> - Brewer(5)  
> - Bricklayer(41)  
> - Brigand(101)  
> - Brigand(34)  
> - Brothel Keeper(14)  
> - Buckle Maker(16)  
> - Buckle Maker(27)  
> - Butcher(21)  
> - Candle Maker(13)  
> - Captain(101)  
> - Caravanner(26)  
> - Carpenter(58)  
> - Cartographer(17)  
> - Chandler(51)  
> - Chandler(51)  
> - Chicken Butcher(21)  
> - Cleric(37)  
> - Clerk(58)  
> - Clock Maker(10)  
> - Cobbler(24)  
> - Cobbler(32)  
> - Conjourer(10)  
> - Cook(22)  
> - Cooper(24)  
> - Council Member(51)  
> - Count(2)  
> - Crime Lord(9)  
> - Crook(41)  
> - Cutler(11)  
> - Dairy Seller(101)  
> - Diplomat(9)  
> - Distiller(19)  
> - Draper(17)  
> - Duke(2)  
> - Dungsweeper(29)  
> - Dye Makers(51)  
> - Dye Makers(51)  
> - Earl(3)  
> - Engineer(41)  
> - Engraver(10)  
> - Farmer - Cabbage(101)  
> - Farmer - Cattle Herder(101)  
> - Farmer - Corn(101)  
> - Farmer - Cow Herder(101)  
> - Farmer - Dairy(101)  
> - Farmer - Goat Herder(101)  
> - Farmer - Pig Herder(101)  
> - Farmer - Potato(101)  
> - Farmer - Sheep Herder(101)  
> - Farmer - Wheat(101)  
> - Farmer(1010)  
> - Farmer(Special)(101)  
> - Fisherman(26)  
> - Fishmonger(26)  
> - Florist(17)  
> - Furniture Maker(32)  
> - Furrier(45)  
> - Girdler(15)  
> - Glassblower(15)  
> - Glassblower(34)  
> - Glazier(10)  
> - Glove Merchant(27)  
> - Goldsmith(15)  
> - Goldsmith(23)  
> - Goon(45)  
> - Grain Merchant(6)  
> - Grocer(15)  
> - Guide(34)  
> - Haberdasher(14)  
> - Harness Maker(34)  
> - Hat Maker(14)  
> - Hay Merchant(101)  
> - Herbalist(17)  
> - High Mage(10)  
> - High Priest(14)  
> - Historian(10)  
> - Homestead(1347)  
> - Horse Trader(41)  
> - Huntsman(51)  
> - Illuminator(21)  
> - Innkeeper(27)  
> - Instrument Maker(10)  
> - Inventor(29)  
> - Jeweler(13)  
> - Jeweler(21)  
> - Judge(29)  
> - Kettle Maker(9)  
> - Knight(7)  
> - Laborer(41)  
> - Launderer(27)  
> - Launderer(34)  
> - Leatherworker(19)  
> - Leatherworker(21)  
> - Librarian(10)  
> - Livestock Merchant(27)  
> - Locksmith(12)  
> - Lord(7)  
> - Magical Artisan(10)  
> - Magical Artisan(10)  
> - Magical Tutor(10)  
> - Mason(41)  
> - Mayor(1)  
> - Meat Butcher(17)  
> - Messenger(32)  
> - Miller(51)  
> - Minstrel(34)  
> - Missionary(135)  
> - Mountainman(101)  
> - Mountainman(16)  
> - Naval Outfitter(11)  
> - Oil Trader(51)  
> - Oil Trader(51)  
> - Painter(Art)(37)  
> - Painter(Building)(41)  
> - Pastry Maker(26)  
> - Pathfinder(17)  
> - Pawnbroker(12)  
> - Perfumer(14)  
> - Physic/Chirurgeon(17)  
> - Pirate(51)  
> - Plasterer(41)  
> - Potionmakers(17)  
> - Potter(34)  
> - Preacher(81)  
> - Priest(45)  
> - Professor(10)  
> - Purse Maker(17)  
> - Roofer(41)  
> - Roofer(41)  
> - Rope Maker(24)  
> - Rug Maker(13)  
> - Saddler(26)  
> - Sage(10)  
> - Sail Maker(29)  
> - Sailor(68)  
> - Scout(17)  
> - Scribe(10)  
> - Sculptor(9)  
> - SellSpell(10)  
> - Ship Builder(12)  
> - Shoe Maker(24)  
> - Shoe Maker(24)  
> - Silversmith(12)  
> - Silversmith(29)  
> - Skinner(21)  
> - Slaver(34)  
> - Slaver(34)  
> - Soap Maker(17)  
> - Spice Merchant(34)  
> - Spice Merchant(34)  
> - Stabler(37)  
> - Storyteller(34)  
> - Tailor(27)  
> - Tanner(26)  
> - Tanner(26)  
> - Tavern Keeper(37)  
> - Tax Collector(6)  
> - Taxidermist(34)  
> - Taxidermist(34)  
> - Teacher(10)  
> - Teamster(41)  
> - Tiler(41)  
> - Tinker(12)  
> - Tinker(51)  
> - Tobacco Merchant(34)  
> - Tobacco Merchant(34)  
> - Town Crier(58)  
> - Town Justice(14)  
> - Toymaker(10)  
> - Toymaker(16)  
> - Trading Post(51)  
> - Troubadours(34)  
> - Tutor(10)  
> - Undertaker(12)  
> - Used Garment Trader(43)  
> - Vestment Maker(24)  
> - Vintner(22)  
> - Viscount(3)  
> - Wagon Maker(29)  
> - Warehouser(34)  
> - Water Carrier(41)  
> - Weapon Dealer(34)  
> - Weapon Dealer(34)  
> - Weaponsmith(10)  
> - Weaponsmith(10)  
> - Weaver(29)  
> - Wheelwright(32)  
> - Wheelwright(45)  
> - Wine Merchant(17)  
> - Wood Carver(17)  
> - Wood Seller(15)  
> - Wool Merchant(26)  
> - Writer(34)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(34)  
> - Advocate(26)  
> - Alchemist(17)  
> - Animal Groomer(14)  
> - Animal Handler(34)  
> - Antiquities(34)  
> - ArchDuke(1)  
> - Architect(41)  
> - Armor Dealer(34)  
> - Armorer(11)  
> - Artist(45)  
> - Astrologist(10)  
> - Baker(32)  
> - Banker(12)  
> - Barbarian(101)  
> - Barbarian(19)  
> - Barber(17)  
> - Baron(5)  
> - Barrel Maker(22)  
> - Barrel Maker(37)  
> - Basket Maker(29)  
> - Bather(14)  
> - Beer Merchant(19)  
> - Blacksmith(48)  
> - Bleacher(17)  
> - Book Binder(11)  
> - Bookseller(10)  
> - Bowyer-Fletcher(17)  
> - Bowyer-Fletcher(17)  
> - Brewer(5)  
> - Bricklayer(41)  
> - Brigand(101)  
> - Brigand(34)  
> - Brothel Keeper(14)  
> - Buckle Maker(16)  
> - Buckle Maker(27)  
> - Butcher(21)  
> - Candle Maker(13)  
> - Captain(101)  
> - Caravanner(26)  
> - Carpenter(58)  
> - Cartographer(17)  
> - Chandler(51)  
> - Chandler(51)  
> - Chicken Butcher(21)  
> - Cleric(37)  
> - Clerk(58)  
> - Clock Maker(10)  
> - Cobbler(24)  
> - Cobbler(32)  
> - Conjourer(10)  
> - Cook(22)  
> - Cooper(24)  
> - Council Member(51)  
> - Count(2)  
> - Crime Lord(9)  
> - Crook(41)  
> - Cutler(11)  
> - Dairy Seller(101)  
> - Diplomat(9)  
> - Distiller(19)  
> - Draper(17)  
> - Duke(2)  
> - Dungsweeper(29)  
> - Dye Makers(51)  
> - Dye Makers(51)  
> - Earl(3)  
> - Engineer(41)  
> - Engraver(10)  
> - Farmer - Cabbage(101)  
> - Farmer - Cattle Herder(101)  
> - Farmer - Corn(101)  
> - Farmer - Cow Herder(101)  
> - Farmer - Dairy(101)  
> - Farmer - Goat Herder(101)  
> - Farmer - Pig Herder(101)  
> - Farmer - Potato(101)  
> - Farmer - Sheep Herder(101)  
> - Farmer - Wheat(101)  
> - Farmer(1010)  
> - Farmer(Special)(101)  
> - Fisherman(26)  
> - Fishmonger(26)  
> - Florist(17)  
> - Furniture Maker(32)  
> - Furrier(45)  
> - Girdler(15)  
> - Glassblower(15)  
> - Glassblower(34)  
> - Glazier(10)  
> - Glove Merchant(27)  
> - Goldsmith(15)  
> - Goldsmith(23)  
> - Goon(45)  
> - Grain Merchant(6)  
> - Grocer(15)  
> - Guide(34)  
> - Haberdasher(14)  
> - Harness Maker(34)  
> - Hat Maker(14)  
> - Hay Merchant(101)  
> - Herbalist(17)  
> - High Mage(10)  
> - High Priest(14)  
> - Historian(10)  
> - Homestead(1347)  
> - Horse Trader(41)  
> - Huntsman(51)  
> - Illuminator(21)  
> - Innkeeper(27)  
> - Instrument Maker(10)  
> - Inventor(29)  
> - Jeweler(13)  
> - Jeweler(21)  
> - Judge(29)  
> - Kettle Maker(9)  
> - Knight(7)  
> - Laborer(41)  
> - Launderer(27)  
> - Launderer(34)  
> - Leatherworker(19)  
> - Leatherworker(21)  
> - Librarian(10)  
> - Livestock Merchant(27)  
> - Locksmith(12)  
> - Lord(7)  
> - Magical Artisan(10)  
> - Magical Artisan(10)  
> - Magical Tutor(10)  
> - Mason(41)  
> - Mayor(1)  
> - Meat Butcher(17)  
> - Messenger(32)  
> - Miller(51)  
> - Minstrel(34)  
> - Missionary(135)  
> - Mountainman(101)  
> - Mountainman(16)  
> - Naval Outfitter(11)  
> - Oil Trader(51)  
> - Oil Trader(51)  
> - Painter(Art)(37)  
> - Painter(Building)(41)  
> - Pastry Maker(26)  
> - Pathfinder(17)  
> - Pawnbroker(12)  
> - Perfumer(14)  
> - Physic/Chirurgeon(17)  
> - Pirate(51)  
> - Plasterer(41)  
> - Potionmakers(17)  
> - Potter(34)  
> - Preacher(81)  
> - Priest(45)  
> - Professor(10)  
> - Purse Maker(17)  
> - Roofer(41)  
> - Roofer(41)  
> - Rope Maker(24)  
> - Rug Maker(13)  
> - Saddler(26)  
> - Sage(10)  
> - Sail Maker(29)  
> - Sailor(68)  
> - Scout(17)  
> - Scribe(10)  
> - Sculptor(9)  
> - SellSpell(10)  
> - Ship Builder(12)  
> - Shoe Maker(24)  
> - Shoe Maker(24)  
> - Silversmith(12)  
> - Silversmith(29)  
> - Skinner(21)  
> - Slaver(34)  
> - Slaver(34)  
> - Soap Maker(17)  
> - Spice Merchant(34)  
> - Spice Merchant(34)  
> - Stabler(37)  
> - Storyteller(34)  
> - Tailor(27)  
> - Tanner(26)  
> - Tanner(26)  
> - Tavern Keeper(37)  
> - Tax Collector(6)  
> - Taxidermist(34)  
> - Taxidermist(34)  
> - Teacher(10)  
> - Teamster(41)  
> - Tiler(41)  
> - Tinker(12)  
> - Tinker(51)  
> - Tobacco Merchant(34)  
> - Tobacco Merchant(34)  
> - Town Crier(58)  
> - Town Justice(14)  
> - Toymaker(10)  
> - Toymaker(16)  
> - Trading Post(51)  
> - Troubadours(34)  
> - Tutor(10)  
> - Undertaker(12)  
> - Used Garment Trader(43)  
> - Vestment Maker(24)  
> - Vintner(22)  
> - Viscount(3)  
> - Wagon Maker(29)  
> - Warehouser(34)  
> - Water Carrier(41)  
> - Weapon Dealer(34)  
> - Weapon Dealer(34)  
> - Weaponsmith(10)  
> - Weaponsmith(10)  
> - Weaver(29)  
> - Wheelwright(32)  
> - Wheelwright(45)  
> - Wine Merchant(17)  
> - Wood Carver(17)  
> - Wood Seller(15)  
> - Wool Merchant(26)  
> - Writer(34)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



