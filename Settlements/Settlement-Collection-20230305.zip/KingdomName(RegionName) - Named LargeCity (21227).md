---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (21227)
terrain: Forest Heavy Boreal 
settlementDescription: 
population: 21227
culture: European 
technology: Crusades 
leader: 
govermentType: Theocracy 
demographics: 
- Acrobat(36) 
- Minstrel(36) 
- Storyteller(36) 
- Troubadours(36) 
- Writer(36) 
- Advocate(27) 
- Clerk(61) 
- Council Member(54) 
- Diplomat(9) 
- Judge(31) 
- Mayor(1) 
- Alchemist(18) 
- Chandler(54) 
- Dye Makers(54) 
- Florist(18) 
- Herbalist(18) 
- Potionmakers(18) 
- Sage(10) 
- Spice Merchant(36) 
- Taxidermist(36) 
- Tobacco Merchant(36) 
- Animal Groomer(15) 
- Animal Handler(36) 
- Caravanner(27) 
- Horse Trader(43) 
- Livestock Merchant(29) 
- Stabler(38) 
- Antiquities(36) 
- Armor Dealer(36) 
- Launderer(36) 
- Oil Trader(54) 
- Trading Post(54) 
- Slaver(36) 
- Spice Merchant(36) 
- Taxidermist(36) 
- Tobacco Merchant(36) 
- Warehouser(36) 
- Weapon Dealer(36) 
- Architect(43) 
- Bricklayer(43) 
- Engineer(43) 
- Laborer(43) 
- Mason(43) 
- Painter(Building)(43) 
- Plasterer(43) 
- Roofer(43) 
- Teamster(43) 
- Tiler(43) 
- Armorer(12) 
- Blacksmith(50) 
- Bowyer-Fletcher(17) 
- Jeweler(14) 
- Silversmith(13) 
- Weapon Dealer(36) 
- Weaponsmith(11) 
- Artist(48) 
- Glassblower(36) 
- Goldsmith(24) 
- Inventor(31) 
- Jeweler(22) 
- Magical Artisan(10) 
- Painter(Art)(39) 
- Silversmith(31) 
- Tinker(54) 
- Toymaker(17) 
- Astrologist(10) 
- Conjourer(10) 
- High Mage(10) 
- Historian(10) 
- Librarian(10) 
- Magical Artisan(10) 
- Magical Tutor(10) 
- Professor(10) 
- Scribe(10) 
- SellSpell(10) 
- Teacher(10) 
- Tutor(10) 
- Baker(33) 
- Beer Merchant(20) 
- Brewer(5) 
- Butcher(22) 
- Chicken Butcher(22) 
- Cook(23) 
- Dairy Seller(107) 
- Distiller(20) 
- Hay Merchant(107) 
- Fisherman(27) 
- Fishmonger(27) 
- Grain Merchant(6) 
- Grocer(16) 
- Meat Butcher(18) 
- Miller(54) 
- Pastry Maker(27) 
- Vintner(23) 
- Banker(12) 
- Pawnbroker(12) 
- Barbarian(107) 
- Brigand(107) 
- Captain(107) 
- Mountainman(107) 
- Barbarian(20) 
- Cartographer(18) 
- Guide(36) 
- Huntsman(54) 
- Mountainman(17) 
- Pathfinder(18) 
- Scout(18) 
- Slaver(36) 
- Barrel Maker(23) 
- Basket Maker(31) 
- Book Binder(11) 
- Bookseller(11) 
- Buckle Maker(17) 
- Candle Maker(14) 
- Clock Maker(10) 
- Cobbler(33) 
- Cooper(25) 
- Cutler(11) 
- Engraver(10) 
- Furniture Maker(33) 
- Glassblower(16) 
- Glazier(11) 
- Glove Merchant(29) 
- Goldsmith(16) 
- Harness Maker(36) 
- Hat Maker(15) 
- Instrument Maker(10) 
- Kettle Maker(10) 
- Locksmith(13) 
- Perfumer(15) 
- Potter(36) 
- Rope Maker(25) 
- Rug Maker(13) 
- Saddler(27) 
- Sculptor(10) 
- Shoe Maker(25) 
- Soap Maker(18) 
- Tanner(27) 
- Tinker(12) 
- Toymaker(10) 
- Weaponsmith(11) 
- Weaver(31) 
- Wheelwright(48) 
- Wine Merchant(18) 
- Wool Merchant(27) 
- Lord(8) 
- Knight(8) 
- Baron(5) 
- Viscount(3) 
- Earl(3) 
- Count(2) 
- Duke(2) 
- ArchDuke(1) 
- Barrel Maker(39) 
- Bowyer-Fletcher(17) 
- Carpenter(61) 
- Roofer(43) 
- Wagon Maker(31) 
- Wheelwright(33) 
- Wood Carver(17) 
- Wood Seller(16) 
- Barber(18) 
- Bleacher(18) 
- Physic/Chirurgeon(18) 
- Bather(15) 
- Brigand(36) 
- Crime Lord(9) 
- Crook(43) 
- Goon(48) 
- Brothel Keeper(15) 
- Innkeeper(29) 
- Tavern Keeper(39) 
- Buckle Maker(29) 
- Cobbler(25) 
- Draper(18) 
- Furrier(48) 
- Girdler(16) 
- Haberdasher(14) 
- Launderer(29) 
- Leatherworker(20) 
- Purse Maker(18) 
- Shoe Maker(25) 
- Tailor(29) 
- Tanner(27) 
- Used Garment Trader(45) 
- Vestment Maker(25) 
- Chandler(54) 
- Dye Makers(54) 
- Oil Trader(54) 
- Cleric(39) 
- High Priest(15) 
- Missionary(142) 
- Preacher(85) 
- Priest(48) 
- Farmer(1062) 
- Homestead(1416) 
- Farmer - Cabbage(107) 
- Farmer - Cattle Herder(107) 
- Farmer - Corn(107) 
- Farmer - Cow Herder(107) 
- Farmer - Dairy(107) 
- Farmer - Goat Herder(107) 
- Farmer - Pig Herder(107) 
- Farmer - Potato(107) 
- Farmer - Sheep Herder(107) 
- Farmer - Wheat(107) 
- Farmer(Special)(107) 
- Dungsweeper(30) 
- Illuminator(22) 
- Messenger(33) 
- Tax Collector(6) 
- Town Crier(61) 
- Town Justice(15) 
- Undertaker(12) 
- Water Carrier(43) 
- Leatherworker(22) 
- Skinner(22) 
- Naval Outfitter(11) 
- Pirate(54) 
- Sail Maker(31) 
- Sailor(71) 
- Ship Builder(13) 
imports: 
- Whale Bones  
exports: 
- Bamboo  
defenses: Archer towers 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(36)  
> - Advocate(27)  
> - Alchemist(18)  
> - Animal Groomer(15)  
> - Animal Handler(36)  
> - Antiquities(36)  
> - ArchDuke(1)  
> - Architect(43)  
> - Armor Dealer(36)  
> - Armorer(12)  
> - Artist(48)  
> - Astrologist(10)  
> - Baker(33)  
> - Banker(12)  
> - Barbarian(107)  
> - Barbarian(20)  
> - Barber(18)  
> - Baron(5)  
> - Barrel Maker(23)  
> - Barrel Maker(39)  
> - Basket Maker(31)  
> - Bather(15)  
> - Beer Merchant(20)  
> - Blacksmith(50)  
> - Bleacher(18)  
> - Book Binder(11)  
> - Bookseller(11)  
> - Bowyer-Fletcher(17)  
> - Bowyer-Fletcher(17)  
> - Brewer(5)  
> - Bricklayer(43)  
> - Brigand(107)  
> - Brigand(36)  
> - Brothel Keeper(15)  
> - Buckle Maker(17)  
> - Buckle Maker(29)  
> - Butcher(22)  
> - Candle Maker(14)  
> - Captain(107)  
> - Caravanner(27)  
> - Carpenter(61)  
> - Cartographer(18)  
> - Chandler(54)  
> - Chandler(54)  
> - Chicken Butcher(22)  
> - Cleric(39)  
> - Clerk(61)  
> - Clock Maker(10)  
> - Cobbler(25)  
> - Cobbler(33)  
> - Conjourer(10)  
> - Cook(23)  
> - Cooper(25)  
> - Council Member(54)  
> - Count(2)  
> - Crime Lord(9)  
> - Crook(43)  
> - Cutler(11)  
> - Dairy Seller(107)  
> - Diplomat(9)  
> - Distiller(20)  
> - Draper(18)  
> - Duke(2)  
> - Dungsweeper(30)  
> - Dye Makers(54)  
> - Dye Makers(54)  
> - Earl(3)  
> - Engineer(43)  
> - Engraver(10)  
> - Farmer - Cabbage(107)  
> - Farmer - Cattle Herder(107)  
> - Farmer - Corn(107)  
> - Farmer - Cow Herder(107)  
> - Farmer - Dairy(107)  
> - Farmer - Goat Herder(107)  
> - Farmer - Pig Herder(107)  
> - Farmer - Potato(107)  
> - Farmer - Sheep Herder(107)  
> - Farmer - Wheat(107)  
> - Farmer(1062)  
> - Farmer(Special)(107)  
> - Fisherman(27)  
> - Fishmonger(27)  
> - Florist(18)  
> - Furniture Maker(33)  
> - Furrier(48)  
> - Girdler(16)  
> - Glassblower(16)  
> - Glassblower(36)  
> - Glazier(11)  
> - Glove Merchant(29)  
> - Goldsmith(16)  
> - Goldsmith(24)  
> - Goon(48)  
> - Grain Merchant(6)  
> - Grocer(16)  
> - Guide(36)  
> - Haberdasher(14)  
> - Harness Maker(36)  
> - Hat Maker(15)  
> - Hay Merchant(107)  
> - Herbalist(18)  
> - High Mage(10)  
> - High Priest(15)  
> - Historian(10)  
> - Homestead(1416)  
> - Horse Trader(43)  
> - Huntsman(54)  
> - Illuminator(22)  
> - Innkeeper(29)  
> - Instrument Maker(10)  
> - Inventor(31)  
> - Jeweler(14)  
> - Jeweler(22)  
> - Judge(31)  
> - Kettle Maker(10)  
> - Knight(8)  
> - Laborer(43)  
> - Launderer(29)  
> - Launderer(36)  
> - Leatherworker(20)  
> - Leatherworker(22)  
> - Librarian(10)  
> - Livestock Merchant(29)  
> - Locksmith(13)  
> - Lord(8)  
> - Magical Artisan(10)  
> - Magical Artisan(10)  
> - Magical Tutor(10)  
> - Mason(43)  
> - Mayor(1)  
> - Meat Butcher(18)  
> - Messenger(33)  
> - Miller(54)  
> - Minstrel(36)  
> - Missionary(142)  
> - Mountainman(107)  
> - Mountainman(17)  
> - Naval Outfitter(11)  
> - Oil Trader(54)  
> - Oil Trader(54)  
> - Painter(Art)(39)  
> - Painter(Building)(43)  
> - Pastry Maker(27)  
> - Pathfinder(18)  
> - Pawnbroker(12)  
> - Perfumer(15)  
> - Physic/Chirurgeon(18)  
> - Pirate(54)  
> - Plasterer(43)  
> - Potionmakers(18)  
> - Potter(36)  
> - Preacher(85)  
> - Priest(48)  
> - Professor(10)  
> - Purse Maker(18)  
> - Roofer(43)  
> - Roofer(43)  
> - Rope Maker(25)  
> - Rug Maker(13)  
> - Saddler(27)  
> - Sage(10)  
> - Sail Maker(31)  
> - Sailor(71)  
> - Scout(18)  
> - Scribe(10)  
> - Sculptor(10)  
> - SellSpell(10)  
> - Ship Builder(13)  
> - Shoe Maker(25)  
> - Shoe Maker(25)  
> - Silversmith(13)  
> - Silversmith(31)  
> - Skinner(22)  
> - Slaver(36)  
> - Slaver(36)  
> - Soap Maker(18)  
> - Spice Merchant(36)  
> - Spice Merchant(36)  
> - Stabler(38)  
> - Storyteller(36)  
> - Tailor(29)  
> - Tanner(27)  
> - Tanner(27)  
> - Tavern Keeper(39)  
> - Tax Collector(6)  
> - Taxidermist(36)  
> - Taxidermist(36)  
> - Teacher(10)  
> - Teamster(43)  
> - Tiler(43)  
> - Tinker(12)  
> - Tinker(54)  
> - Tobacco Merchant(36)  
> - Tobacco Merchant(36)  
> - Town Crier(61)  
> - Town Justice(15)  
> - Toymaker(10)  
> - Toymaker(17)  
> - Trading Post(54)  
> - Troubadours(36)  
> - Tutor(10)  
> - Undertaker(12)  
> - Used Garment Trader(45)  
> - Vestment Maker(25)  
> - Vintner(23)  
> - Viscount(3)  
> - Wagon Maker(31)  
> - Warehouser(36)  
> - Water Carrier(43)  
> - Weapon Dealer(36)  
> - Weapon Dealer(36)  
> - Weaponsmith(11)  
> - Weaponsmith(11)  
> - Weaver(31)  
> - Wheelwright(33)  
> - Wheelwright(48)  
> - Wine Merchant(18)  
> - Wood Carver(17)  
> - Wood Seller(16)  
> - Wool Merchant(27)  
> - Writer(36)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(36)  
> - Advocate(27)  
> - Alchemist(18)  
> - Animal Groomer(15)  
> - Animal Handler(36)  
> - Antiquities(36)  
> - ArchDuke(1)  
> - Architect(43)  
> - Armor Dealer(36)  
> - Armorer(12)  
> - Artist(48)  
> - Astrologist(10)  
> - Baker(33)  
> - Banker(12)  
> - Barbarian(107)  
> - Barbarian(20)  
> - Barber(18)  
> - Baron(5)  
> - Barrel Maker(23)  
> - Barrel Maker(39)  
> - Basket Maker(31)  
> - Bather(15)  
> - Beer Merchant(20)  
> - Blacksmith(50)  
> - Bleacher(18)  
> - Book Binder(11)  
> - Bookseller(11)  
> - Bowyer-Fletcher(17)  
> - Bowyer-Fletcher(17)  
> - Brewer(5)  
> - Bricklayer(43)  
> - Brigand(107)  
> - Brigand(36)  
> - Brothel Keeper(15)  
> - Buckle Maker(17)  
> - Buckle Maker(29)  
> - Butcher(22)  
> - Candle Maker(14)  
> - Captain(107)  
> - Caravanner(27)  
> - Carpenter(61)  
> - Cartographer(18)  
> - Chandler(54)  
> - Chandler(54)  
> - Chicken Butcher(22)  
> - Cleric(39)  
> - Clerk(61)  
> - Clock Maker(10)  
> - Cobbler(25)  
> - Cobbler(33)  
> - Conjourer(10)  
> - Cook(23)  
> - Cooper(25)  
> - Council Member(54)  
> - Count(2)  
> - Crime Lord(9)  
> - Crook(43)  
> - Cutler(11)  
> - Dairy Seller(107)  
> - Diplomat(9)  
> - Distiller(20)  
> - Draper(18)  
> - Duke(2)  
> - Dungsweeper(30)  
> - Dye Makers(54)  
> - Dye Makers(54)  
> - Earl(3)  
> - Engineer(43)  
> - Engraver(10)  
> - Farmer - Cabbage(107)  
> - Farmer - Cattle Herder(107)  
> - Farmer - Corn(107)  
> - Farmer - Cow Herder(107)  
> - Farmer - Dairy(107)  
> - Farmer - Goat Herder(107)  
> - Farmer - Pig Herder(107)  
> - Farmer - Potato(107)  
> - Farmer - Sheep Herder(107)  
> - Farmer - Wheat(107)  
> - Farmer(1062)  
> - Farmer(Special)(107)  
> - Fisherman(27)  
> - Fishmonger(27)  
> - Florist(18)  
> - Furniture Maker(33)  
> - Furrier(48)  
> - Girdler(16)  
> - Glassblower(16)  
> - Glassblower(36)  
> - Glazier(11)  
> - Glove Merchant(29)  
> - Goldsmith(16)  
> - Goldsmith(24)  
> - Goon(48)  
> - Grain Merchant(6)  
> - Grocer(16)  
> - Guide(36)  
> - Haberdasher(14)  
> - Harness Maker(36)  
> - Hat Maker(15)  
> - Hay Merchant(107)  
> - Herbalist(18)  
> - High Mage(10)  
> - High Priest(15)  
> - Historian(10)  
> - Homestead(1416)  
> - Horse Trader(43)  
> - Huntsman(54)  
> - Illuminator(22)  
> - Innkeeper(29)  
> - Instrument Maker(10)  
> - Inventor(31)  
> - Jeweler(14)  
> - Jeweler(22)  
> - Judge(31)  
> - Kettle Maker(10)  
> - Knight(8)  
> - Laborer(43)  
> - Launderer(29)  
> - Launderer(36)  
> - Leatherworker(20)  
> - Leatherworker(22)  
> - Librarian(10)  
> - Livestock Merchant(29)  
> - Locksmith(13)  
> - Lord(8)  
> - Magical Artisan(10)  
> - Magical Artisan(10)  
> - Magical Tutor(10)  
> - Mason(43)  
> - Mayor(1)  
> - Meat Butcher(18)  
> - Messenger(33)  
> - Miller(54)  
> - Minstrel(36)  
> - Missionary(142)  
> - Mountainman(107)  
> - Mountainman(17)  
> - Naval Outfitter(11)  
> - Oil Trader(54)  
> - Oil Trader(54)  
> - Painter(Art)(39)  
> - Painter(Building)(43)  
> - Pastry Maker(27)  
> - Pathfinder(18)  
> - Pawnbroker(12)  
> - Perfumer(15)  
> - Physic/Chirurgeon(18)  
> - Pirate(54)  
> - Plasterer(43)  
> - Potionmakers(18)  
> - Potter(36)  
> - Preacher(85)  
> - Priest(48)  
> - Professor(10)  
> - Purse Maker(18)  
> - Roofer(43)  
> - Roofer(43)  
> - Rope Maker(25)  
> - Rug Maker(13)  
> - Saddler(27)  
> - Sage(10)  
> - Sail Maker(31)  
> - Sailor(71)  
> - Scout(18)  
> - Scribe(10)  
> - Sculptor(10)  
> - SellSpell(10)  
> - Ship Builder(13)  
> - Shoe Maker(25)  
> - Shoe Maker(25)  
> - Silversmith(13)  
> - Silversmith(31)  
> - Skinner(22)  
> - Slaver(36)  
> - Slaver(36)  
> - Soap Maker(18)  
> - Spice Merchant(36)  
> - Spice Merchant(36)  
> - Stabler(38)  
> - Storyteller(36)  
> - Tailor(29)  
> - Tanner(27)  
> - Tanner(27)  
> - Tavern Keeper(39)  
> - Tax Collector(6)  
> - Taxidermist(36)  
> - Taxidermist(36)  
> - Teacher(10)  
> - Teamster(43)  
> - Tiler(43)  
> - Tinker(12)  
> - Tinker(54)  
> - Tobacco Merchant(36)  
> - Tobacco Merchant(36)  
> - Town Crier(61)  
> - Town Justice(15)  
> - Toymaker(10)  
> - Toymaker(17)  
> - Trading Post(54)  
> - Troubadours(36)  
> - Tutor(10)  
> - Undertaker(12)  
> - Used Garment Trader(45)  
> - Vestment Maker(25)  
> - Vintner(23)  
> - Viscount(3)  
> - Wagon Maker(31)  
> - Warehouser(36)  
> - Water Carrier(43)  
> - Weapon Dealer(36)  
> - Weapon Dealer(36)  
> - Weaponsmith(11)  
> - Weaponsmith(11)  
> - Weaver(31)  
> - Wheelwright(33)  
> - Wheelwright(48)  
> - Wine Merchant(18)  
> - Wood Carver(17)  
> - Wood Seller(16)  
> - Wool Merchant(27)  
> - Writer(36)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



