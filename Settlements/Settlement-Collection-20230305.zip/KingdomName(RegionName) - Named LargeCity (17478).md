---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (17478)
terrain: Desert Brokenlands 
settlementDescription: 
population: 17478
culture: Viking 
technology: Roman 
leader: 
govermentType: Federation 
demographics: 
- Acrobat(30) 
- Minstrel(30) 
- Storyteller(30) 
- Troubadours(30) 
- Writer(30) 
- Advocate(22) 
- Clerk(50) 
- Council Member(44) 
- Diplomat(7) 
- Judge(25) 
- Mayor(1) 
- Alchemist(15) 
- Chandler(44) 
- Dye Makers(44) 
- Florist(15) 
- Herbalist(15) 
- Potionmakers(15) 
- Sage(8) 
- Spice Merchant(30) 
- Taxidermist(30) 
- Tobacco Merchant(30) 
- Animal Groomer(12) 
- Animal Handler(30) 
- Caravanner(22) 
- Horse Trader(35) 
- Livestock Merchant(24) 
- Stabler(32) 
- Antiquities(30) 
- Armor Dealer(30) 
- Launderer(30) 
- Oil Trader(44) 
- Trading Post(44) 
- Slaver(30) 
- Spice Merchant(30) 
- Taxidermist(30) 
- Tobacco Merchant(30) 
- Warehouser(30) 
- Weapon Dealer(30) 
- Architect(35) 
- Bricklayer(35) 
- Engineer(35) 
- Laborer(35) 
- Mason(35) 
- Painter(Building)(35) 
- Plasterer(35) 
- Roofer(35) 
- Teamster(35) 
- Tiler(35) 
- Armorer(10) 
- Blacksmith(42) 
- Bowyer-Fletcher(14) 
- Jeweler(11) 
- Silversmith(11) 
- Weapon Dealer(30) 
- Weaponsmith(9) 
- Artist(39) 
- Glassblower(30) 
- Goldsmith(20) 
- Inventor(25) 
- Jeweler(18) 
- Magical Artisan(8) 
- Painter(Art)(32) 
- Silversmith(25) 
- Tinker(44) 
- Toymaker(14) 
- Astrologist(8) 
- Conjourer(8) 
- High Mage(8) 
- Historian(8) 
- Librarian(8) 
- Magical Artisan(8) 
- Magical Tutor(8) 
- Professor(8) 
- Scribe(8) 
- SellSpell(8) 
- Teacher(8) 
- Tutor(8) 
- Baker(27) 
- Beer Merchant(16) 
- Brewer(5) 
- Butcher(18) 
- Chicken Butcher(18) 
- Cook(19) 
- Dairy Seller(88) 
- Distiller(16) 
- Hay Merchant(88) 
- Fisherman(22) 
- Fishmonger(22) 
- Grain Merchant(5) 
- Grocer(13) 
- Meat Butcher(15) 
- Miller(44) 
- Pastry Maker(22) 
- Vintner(19) 
- Banker(10) 
- Pawnbroker(10) 
- Barbarian(88) 
- Brigand(88) 
- Captain(88) 
- Mountainman(88) 
- Barbarian(16) 
- Cartographer(15) 
- Guide(30) 
- Huntsman(44) 
- Mountainman(14) 
- Pathfinder(15) 
- Scout(15) 
- Slaver(30) 
- Barrel Maker(19) 
- Basket Maker(25) 
- Book Binder(9) 
- Bookseller(9) 
- Buckle Maker(14) 
- Candle Maker(11) 
- Clock Maker(8) 
- Cobbler(27) 
- Cooper(21) 
- Cutler(9) 
- Engraver(8) 
- Furniture Maker(27) 
- Glassblower(13) 
- Glazier(9) 
- Glove Merchant(24) 
- Goldsmith(13) 
- Harness Maker(30) 
- Hat Maker(12) 
- Instrument Maker(8) 
- Kettle Maker(8) 
- Locksmith(11) 
- Perfumer(13) 
- Potter(30) 
- Rope Maker(21) 
- Rug Maker(11) 
- Saddler(22) 
- Sculptor(8) 
- Shoe Maker(21) 
- Soap Maker(15) 
- Tanner(22) 
- Tinker(10) 
- Toymaker(8) 
- Weaponsmith(9) 
- Weaver(25) 
- Wheelwright(39) 
- Wine Merchant(15) 
- Wool Merchant(22) 
- Lord(6) 
- Knight(6) 
- Baron(4) 
- Viscount(3) 
- Earl(2) 
- Count(2) 
- Duke(1) 
- Barrel Maker(32) 
- Bowyer-Fletcher(14) 
- Carpenter(50) 
- Roofer(35) 
- Wagon Maker(25) 
- Wheelwright(27) 
- Wood Carver(14) 
- Wood Seller(13) 
- Barber(15) 
- Bleacher(15) 
- Physic/Chirurgeon(15) 
- Bather(12) 
- Brigand(30) 
- Crime Lord(7) 
- Crook(35) 
- Goon(39) 
- Brothel Keeper(13) 
- Innkeeper(24) 
- Tavern Keeper(32) 
- Buckle Maker(24) 
- Cobbler(21) 
- Draper(15) 
- Furrier(39) 
- Girdler(13) 
- Haberdasher(12) 
- Launderer(24) 
- Leatherworker(16) 
- Purse Maker(15) 
- Shoe Maker(21) 
- Tailor(24) 
- Tanner(22) 
- Used Garment Trader(37) 
- Vestment Maker(21) 
- Chandler(44) 
- Dye Makers(44) 
- Oil Trader(44) 
- Cleric(32) 
- High Priest(13) 
- Missionary(117) 
- Preacher(70) 
- Priest(39) 
- Farmer(874) 
- Homestead(1166) 
- Farmer - Cabbage(88) 
- Farmer - Cattle Herder(88) 
- Farmer - Corn(88) 
- Farmer - Cow Herder(88) 
- Farmer - Dairy(88) 
- Farmer - Goat Herder(88) 
- Farmer - Pig Herder(88) 
- Farmer - Potato(88) 
- Farmer - Sheep Herder(88) 
- Farmer - Wheat(88) 
- Farmer(Special)(88) 
- Dungsweeper(25) 
- Illuminator(18) 
- Messenger(27) 
- Tax Collector(5) 
- Town Crier(50) 
- Town Justice(12) 
- Undertaker(10) 
- Water Carrier(35) 
- Leatherworker(18) 
- Skinner(18) 
- Naval Outfitter(9) 
- Pirate(44) 
- Sail Maker(25) 
- Sailor(59) 
- Ship Builder(11) 
imports: 
- Silicates  
exports: 
- Soapstone  
defenses: Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(30)  
> - Advocate(22)  
> - Alchemist(15)  
> - Animal Groomer(12)  
> - Animal Handler(30)  
> - Antiquities(30)  
> - Architect(35)  
> - Armor Dealer(30)  
> - Armorer(10)  
> - Artist(39)  
> - Astrologist(8)  
> - Baker(27)  
> - Banker(10)  
> - Barbarian(16)  
> - Barbarian(88)  
> - Barber(15)  
> - Baron(4)  
> - Barrel Maker(19)  
> - Barrel Maker(32)  
> - Basket Maker(25)  
> - Bather(12)  
> - Beer Merchant(16)  
> - Blacksmith(42)  
> - Bleacher(15)  
> - Book Binder(9)  
> - Bookseller(9)  
> - Bowyer-Fletcher(14)  
> - Bowyer-Fletcher(14)  
> - Brewer(5)  
> - Bricklayer(35)  
> - Brigand(30)  
> - Brigand(88)  
> - Brothel Keeper(13)  
> - Buckle Maker(14)  
> - Buckle Maker(24)  
> - Butcher(18)  
> - Candle Maker(11)  
> - Captain(88)  
> - Caravanner(22)  
> - Carpenter(50)  
> - Cartographer(15)  
> - Chandler(44)  
> - Chandler(44)  
> - Chicken Butcher(18)  
> - Cleric(32)  
> - Clerk(50)  
> - Clock Maker(8)  
> - Cobbler(21)  
> - Cobbler(27)  
> - Conjourer(8)  
> - Cook(19)  
> - Cooper(21)  
> - Council Member(44)  
> - Count(2)  
> - Crime Lord(7)  
> - Crook(35)  
> - Cutler(9)  
> - Dairy Seller(88)  
> - Diplomat(7)  
> - Distiller(16)  
> - Draper(15)  
> - Duke(1)  
> - Dungsweeper(25)  
> - Dye Makers(44)  
> - Dye Makers(44)  
> - Earl(2)  
> - Engineer(35)  
> - Engraver(8)  
> - Farmer - Cabbage(88)  
> - Farmer - Cattle Herder(88)  
> - Farmer - Corn(88)  
> - Farmer - Cow Herder(88)  
> - Farmer - Dairy(88)  
> - Farmer - Goat Herder(88)  
> - Farmer - Pig Herder(88)  
> - Farmer - Potato(88)  
> - Farmer - Sheep Herder(88)  
> - Farmer - Wheat(88)  
> - Farmer(874)  
> - Farmer(Special)(88)  
> - Fisherman(22)  
> - Fishmonger(22)  
> - Florist(15)  
> - Furniture Maker(27)  
> - Furrier(39)  
> - Girdler(13)  
> - Glassblower(13)  
> - Glassblower(30)  
> - Glazier(9)  
> - Glove Merchant(24)  
> - Goldsmith(13)  
> - Goldsmith(20)  
> - Goon(39)  
> - Grain Merchant(5)  
> - Grocer(13)  
> - Guide(30)  
> - Haberdasher(12)  
> - Harness Maker(30)  
> - Hat Maker(12)  
> - Hay Merchant(88)  
> - Herbalist(15)  
> - High Mage(8)  
> - High Priest(13)  
> - Historian(8)  
> - Homestead(1166)  
> - Horse Trader(35)  
> - Huntsman(44)  
> - Illuminator(18)  
> - Innkeeper(24)  
> - Instrument Maker(8)  
> - Inventor(25)  
> - Jeweler(11)  
> - Jeweler(18)  
> - Judge(25)  
> - Kettle Maker(8)  
> - Knight(6)  
> - Laborer(35)  
> - Launderer(24)  
> - Launderer(30)  
> - Leatherworker(16)  
> - Leatherworker(18)  
> - Librarian(8)  
> - Livestock Merchant(24)  
> - Locksmith(11)  
> - Lord(6)  
> - Magical Artisan(8)  
> - Magical Artisan(8)  
> - Magical Tutor(8)  
> - Mason(35)  
> - Mayor(1)  
> - Meat Butcher(15)  
> - Messenger(27)  
> - Miller(44)  
> - Minstrel(30)  
> - Missionary(117)  
> - Mountainman(14)  
> - Mountainman(88)  
> - Naval Outfitter(9)  
> - Oil Trader(44)  
> - Oil Trader(44)  
> - Painter(Art)(32)  
> - Painter(Building)(35)  
> - Pastry Maker(22)  
> - Pathfinder(15)  
> - Pawnbroker(10)  
> - Perfumer(13)  
> - Physic/Chirurgeon(15)  
> - Pirate(44)  
> - Plasterer(35)  
> - Potionmakers(15)  
> - Potter(30)  
> - Preacher(70)  
> - Priest(39)  
> - Professor(8)  
> - Purse Maker(15)  
> - Roofer(35)  
> - Roofer(35)  
> - Rope Maker(21)  
> - Rug Maker(11)  
> - Saddler(22)  
> - Sage(8)  
> - Sail Maker(25)  
> - Sailor(59)  
> - Scout(15)  
> - Scribe(8)  
> - Sculptor(8)  
> - SellSpell(8)  
> - Ship Builder(11)  
> - Shoe Maker(21)  
> - Shoe Maker(21)  
> - Silversmith(11)  
> - Silversmith(25)  
> - Skinner(18)  
> - Slaver(30)  
> - Slaver(30)  
> - Soap Maker(15)  
> - Spice Merchant(30)  
> - Spice Merchant(30)  
> - Stabler(32)  
> - Storyteller(30)  
> - Tailor(24)  
> - Tanner(22)  
> - Tanner(22)  
> - Tavern Keeper(32)  
> - Tax Collector(5)  
> - Taxidermist(30)  
> - Taxidermist(30)  
> - Teacher(8)  
> - Teamster(35)  
> - Tiler(35)  
> - Tinker(10)  
> - Tinker(44)  
> - Tobacco Merchant(30)  
> - Tobacco Merchant(30)  
> - Town Crier(50)  
> - Town Justice(12)  
> - Toymaker(14)  
> - Toymaker(8)  
> - Trading Post(44)  
> - Troubadours(30)  
> - Tutor(8)  
> - Undertaker(10)  
> - Used Garment Trader(37)  
> - Vestment Maker(21)  
> - Vintner(19)  
> - Viscount(3)  
> - Wagon Maker(25)  
> - Warehouser(30)  
> - Water Carrier(35)  
> - Weapon Dealer(30)  
> - Weapon Dealer(30)  
> - Weaponsmith(9)  
> - Weaponsmith(9)  
> - Weaver(25)  
> - Wheelwright(27)  
> - Wheelwright(39)  
> - Wine Merchant(15)  
> - Wood Carver(14)  
> - Wood Seller(13)  
> - Wool Merchant(22)  
> - Writer(30)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(30)  
> - Advocate(22)  
> - Alchemist(15)  
> - Animal Groomer(12)  
> - Animal Handler(30)  
> - Antiquities(30)  
> - Architect(35)  
> - Armor Dealer(30)  
> - Armorer(10)  
> - Artist(39)  
> - Astrologist(8)  
> - Baker(27)  
> - Banker(10)  
> - Barbarian(16)  
> - Barbarian(88)  
> - Barber(15)  
> - Baron(4)  
> - Barrel Maker(19)  
> - Barrel Maker(32)  
> - Basket Maker(25)  
> - Bather(12)  
> - Beer Merchant(16)  
> - Blacksmith(42)  
> - Bleacher(15)  
> - Book Binder(9)  
> - Bookseller(9)  
> - Bowyer-Fletcher(14)  
> - Bowyer-Fletcher(14)  
> - Brewer(5)  
> - Bricklayer(35)  
> - Brigand(30)  
> - Brigand(88)  
> - Brothel Keeper(13)  
> - Buckle Maker(14)  
> - Buckle Maker(24)  
> - Butcher(18)  
> - Candle Maker(11)  
> - Captain(88)  
> - Caravanner(22)  
> - Carpenter(50)  
> - Cartographer(15)  
> - Chandler(44)  
> - Chandler(44)  
> - Chicken Butcher(18)  
> - Cleric(32)  
> - Clerk(50)  
> - Clock Maker(8)  
> - Cobbler(21)  
> - Cobbler(27)  
> - Conjourer(8)  
> - Cook(19)  
> - Cooper(21)  
> - Council Member(44)  
> - Count(2)  
> - Crime Lord(7)  
> - Crook(35)  
> - Cutler(9)  
> - Dairy Seller(88)  
> - Diplomat(7)  
> - Distiller(16)  
> - Draper(15)  
> - Duke(1)  
> - Dungsweeper(25)  
> - Dye Makers(44)  
> - Dye Makers(44)  
> - Earl(2)  
> - Engineer(35)  
> - Engraver(8)  
> - Farmer - Cabbage(88)  
> - Farmer - Cattle Herder(88)  
> - Farmer - Corn(88)  
> - Farmer - Cow Herder(88)  
> - Farmer - Dairy(88)  
> - Farmer - Goat Herder(88)  
> - Farmer - Pig Herder(88)  
> - Farmer - Potato(88)  
> - Farmer - Sheep Herder(88)  
> - Farmer - Wheat(88)  
> - Farmer(874)  
> - Farmer(Special)(88)  
> - Fisherman(22)  
> - Fishmonger(22)  
> - Florist(15)  
> - Furniture Maker(27)  
> - Furrier(39)  
> - Girdler(13)  
> - Glassblower(13)  
> - Glassblower(30)  
> - Glazier(9)  
> - Glove Merchant(24)  
> - Goldsmith(13)  
> - Goldsmith(20)  
> - Goon(39)  
> - Grain Merchant(5)  
> - Grocer(13)  
> - Guide(30)  
> - Haberdasher(12)  
> - Harness Maker(30)  
> - Hat Maker(12)  
> - Hay Merchant(88)  
> - Herbalist(15)  
> - High Mage(8)  
> - High Priest(13)  
> - Historian(8)  
> - Homestead(1166)  
> - Horse Trader(35)  
> - Huntsman(44)  
> - Illuminator(18)  
> - Innkeeper(24)  
> - Instrument Maker(8)  
> - Inventor(25)  
> - Jeweler(11)  
> - Jeweler(18)  
> - Judge(25)  
> - Kettle Maker(8)  
> - Knight(6)  
> - Laborer(35)  
> - Launderer(24)  
> - Launderer(30)  
> - Leatherworker(16)  
> - Leatherworker(18)  
> - Librarian(8)  
> - Livestock Merchant(24)  
> - Locksmith(11)  
> - Lord(6)  
> - Magical Artisan(8)  
> - Magical Artisan(8)  
> - Magical Tutor(8)  
> - Mason(35)  
> - Mayor(1)  
> - Meat Butcher(15)  
> - Messenger(27)  
> - Miller(44)  
> - Minstrel(30)  
> - Missionary(117)  
> - Mountainman(14)  
> - Mountainman(88)  
> - Naval Outfitter(9)  
> - Oil Trader(44)  
> - Oil Trader(44)  
> - Painter(Art)(32)  
> - Painter(Building)(35)  
> - Pastry Maker(22)  
> - Pathfinder(15)  
> - Pawnbroker(10)  
> - Perfumer(13)  
> - Physic/Chirurgeon(15)  
> - Pirate(44)  
> - Plasterer(35)  
> - Potionmakers(15)  
> - Potter(30)  
> - Preacher(70)  
> - Priest(39)  
> - Professor(8)  
> - Purse Maker(15)  
> - Roofer(35)  
> - Roofer(35)  
> - Rope Maker(21)  
> - Rug Maker(11)  
> - Saddler(22)  
> - Sage(8)  
> - Sail Maker(25)  
> - Sailor(59)  
> - Scout(15)  
> - Scribe(8)  
> - Sculptor(8)  
> - SellSpell(8)  
> - Ship Builder(11)  
> - Shoe Maker(21)  
> - Shoe Maker(21)  
> - Silversmith(11)  
> - Silversmith(25)  
> - Skinner(18)  
> - Slaver(30)  
> - Slaver(30)  
> - Soap Maker(15)  
> - Spice Merchant(30)  
> - Spice Merchant(30)  
> - Stabler(32)  
> - Storyteller(30)  
> - Tailor(24)  
> - Tanner(22)  
> - Tanner(22)  
> - Tavern Keeper(32)  
> - Tax Collector(5)  
> - Taxidermist(30)  
> - Taxidermist(30)  
> - Teacher(8)  
> - Teamster(35)  
> - Tiler(35)  
> - Tinker(10)  
> - Tinker(44)  
> - Tobacco Merchant(30)  
> - Tobacco Merchant(30)  
> - Town Crier(50)  
> - Town Justice(12)  
> - Toymaker(14)  
> - Toymaker(8)  
> - Trading Post(44)  
> - Troubadours(30)  
> - Tutor(8)  
> - Undertaker(10)  
> - Used Garment Trader(37)  
> - Vestment Maker(21)  
> - Vintner(19)  
> - Viscount(3)  
> - Wagon Maker(25)  
> - Warehouser(30)  
> - Water Carrier(35)  
> - Weapon Dealer(30)  
> - Weapon Dealer(30)  
> - Weaponsmith(9)  
> - Weaponsmith(9)  
> - Weaver(25)  
> - Wheelwright(27)  
> - Wheelwright(39)  
> - Wine Merchant(15)  
> - Wood Carver(14)  
> - Wood Seller(13)  
> - Wool Merchant(22)  
> - Writer(30)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



