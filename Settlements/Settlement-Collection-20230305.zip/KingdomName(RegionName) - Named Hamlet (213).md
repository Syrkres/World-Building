---
cssclass: oRPGPage
fileType: settlement
settlementType: Hamlet
kingdom: KingdomName
region: RegionName
settlementName: Named Hamlet (213)
terrain: Wetlands Forest 
settlementDescription: 
population: 213
culture: Central Asian 
technology: Crusades 
leader: 
govermentType: Oligarchy 
demographics: 
- Clerk(1) 
- Mayor(1) 
- Trading Post(1) 
- Blacksmith(1) 
- Barbarian(1) 
- Brigand(1) 
- Captain(1) 
- Mountainman(1) 
- Barbarian(1) 
- Barrel Maker(1) 
- Cooper(1) 
- Barrel Maker(1) 
- Wheelwright(1) 
- Brigand(1) 
- Crook(1) 
- Goon(1) 
- Innkeeper(1) 
- Tavern Keeper(1) 
- Buckle Maker(1) 
- Tanner(1) 
- Missionary(1) 
- Farmer(11) 
- Homestead(15) 
- Farmer - Corn(2) 
- Farmer - Goat Herder(1) 
- Farmer - Pig Herder(1) 
- Farmer - Potato(1) 
- Farmer - Sheep Herder(1) 
- Farmer - Wheat(1) 
- Pirate(1) 
- Sail Maker(1) 
- Sailor(1) 
imports: 
- Silver  
exports: 
- Gold  
defenses: Turrets 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Barbarian(1)  
> - Barbarian(1)  
> - Barrel Maker(1)  
> - Barrel Maker(1)  
> - Blacksmith(1)  
> - Brigand(1)  
> - Brigand(1)  
> - Buckle Maker(1)  
> - Captain(1)  
> - Clerk(1)  
> - Cooper(1)  
> - Crook(1)  
> - Farmer - Corn(2)  
> - Farmer - Goat Herder(1)  
> - Farmer - Pig Herder(1)  
> - Farmer - Potato(1)  
> - Farmer - Sheep Herder(1)  
> - Farmer - Wheat(1)  
> - Farmer(11)  
> - Goon(1)  
> - Homestead(15)  
> - Innkeeper(1)  
> - Mayor(1)  
> - Missionary(1)  
> - Mountainman(1)  
> - Pirate(1)  
> - Sail Maker(1)  
> - Sailor(1)  
> - Tanner(1)  
> - Tavern Keeper(1)  
> - Trading Post(1)  
> - Wheelwright(1)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Barbarian(1)  
> - Barbarian(1)  
> - Barrel Maker(1)  
> - Barrel Maker(1)  
> - Blacksmith(1)  
> - Brigand(1)  
> - Brigand(1)  
> - Buckle Maker(1)  
> - Captain(1)  
> - Clerk(1)  
> - Cooper(1)  
> - Crook(1)  
> - Farmer - Corn(2)  
> - Farmer - Goat Herder(1)  
> - Farmer - Pig Herder(1)  
> - Farmer - Potato(1)  
> - Farmer - Sheep Herder(1)  
> - Farmer - Wheat(1)  
> - Farmer(11)  
> - Goon(1)  
> - Homestead(15)  
> - Innkeeper(1)  
> - Mayor(1)  
> - Missionary(1)  
> - Mountainman(1)  
> - Pirate(1)  
> - Sail Maker(1)  
> - Sailor(1)  
> - Tanner(1)  
> - Tavern Keeper(1)  
> - Trading Post(1)  
> - Wheelwright(1)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



