---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallCity
kingdom: KingdomName
region: RegionName
settlementName: Named SmallCity (11297)
terrain: Forest Fungal 
settlementDescription: 
population: 11297
culture: Aboriginal 
technology: Crusades 
leader: 
govermentType: Federation 
demographics: 
- Acrobat(19) 
- Minstrel(19) 
- Storyteller(19) 
- Troubadours(19) 
- Writer(19) 
- Advocate(15) 
- Clerk(33) 
- Council Member(29) 
- Diplomat(5) 
- Judge(17) 
- Mayor(1) 
- Alchemist(10) 
- Chandler(29) 
- Dye Makers(29) 
- Florist(10) 
- Herbalist(10) 
- Potionmakers(10) 
- Sage(6) 
- Spice Merchant(19) 
- Taxidermist(19) 
- Tobacco Merchant(19) 
- Animal Groomer(8) 
- Animal Handler(19) 
- Caravanner(15) 
- Horse Trader(23) 
- Livestock Merchant(16) 
- Stabler(21) 
- Antiquities(19) 
- Armor Dealer(19) 
- Launderer(19) 
- Oil Trader(29) 
- Trading Post(29) 
- Slaver(19) 
- Spice Merchant(19) 
- Taxidermist(19) 
- Tobacco Merchant(19) 
- Warehouser(19) 
- Weapon Dealer(19) 
- Architect(23) 
- Bricklayer(23) 
- Engineer(23) 
- Laborer(23) 
- Mason(23) 
- Painter(Building)(23) 
- Plasterer(23) 
- Roofer(23) 
- Teamster(23) 
- Tiler(23) 
- Armorer(6) 
- Blacksmith(27) 
- Bowyer-Fletcher(10) 
- Jeweler(8) 
- Silversmith(7) 
- Weapon Dealer(19) 
- Weaponsmith(6) 
- Artist(26) 
- Glassblower(19) 
- Goldsmith(13) 
- Inventor(17) 
- Jeweler(12) 
- Magical Artisan(6) 
- Painter(Art)(21) 
- Silversmith(17) 
- Tinker(29) 
- Toymaker(9) 
- Astrologist(6) 
- Conjourer(6) 
- High Mage(6) 
- Historian(6) 
- Librarian(6) 
- Magical Artisan(6) 
- Magical Tutor(6) 
- Professor(6) 
- Scribe(6) 
- SellSpell(6) 
- Teacher(6) 
- Tutor(6) 
- Baker(18) 
- Beer Merchant(11) 
- Brewer(3) 
- Butcher(12) 
- Chicken Butcher(12) 
- Cook(12) 
- Dairy Seller(57) 
- Distiller(11) 
- Hay Merchant(57) 
- Fisherman(15) 
- Fishmonger(15) 
- Grain Merchant(3) 
- Grocer(9) 
- Meat Butcher(10) 
- Miller(29) 
- Pastry Maker(15) 
- Vintner(12) 
- Banker(7) 
- Pawnbroker(7) 
- Barbarian(57) 
- Brigand(57) 
- Captain(57) 
- Mountainman(57) 
- Barbarian(11) 
- Cartographer(10) 
- Guide(19) 
- Huntsman(29) 
- Mountainman(9) 
- Pathfinder(10) 
- Scout(10) 
- Slaver(19) 
- Barrel Maker(12) 
- Basket Maker(17) 
- Book Binder(6) 
- Bookseller(6) 
- Buckle Maker(9) 
- Candle Maker(8) 
- Clock Maker(6) 
- Cobbler(18) 
- Cooper(14) 
- Cutler(6) 
- Engraver(6) 
- Furniture Maker(18) 
- Glassblower(9) 
- Glazier(6) 
- Glove Merchant(16) 
- Goldsmith(9) 
- Harness Maker(19) 
- Hat Maker(8) 
- Instrument Maker(6) 
- Kettle Maker(5) 
- Locksmith(7) 
- Perfumer(8) 
- Potter(19) 
- Rope Maker(14) 
- Rug Maker(7) 
- Saddler(15) 
- Sculptor(5) 
- Shoe Maker(14) 
- Soap Maker(10) 
- Tanner(15) 
- Tinker(7) 
- Toymaker(6) 
- Weaponsmith(6) 
- Weaver(17) 
- Wheelwright(26) 
- Wine Merchant(10) 
- Wool Merchant(15) 
- Lord(4) 
- Knight(4) 
- Baron(3) 
- Viscount(2) 
- Earl(1) 
- Count(1) 
- Duke(1) 
- Barrel Maker(21) 
- Bowyer-Fletcher(10) 
- Carpenter(33) 
- Roofer(23) 
- Wagon Maker(17) 
- Wheelwright(18) 
- Wood Carver(10) 
- Wood Seller(9) 
- Barber(10) 
- Bleacher(10) 
- Physic/Chirurgeon(10) 
- Bather(8) 
- Brigand(19) 
- Crime Lord(5) 
- Crook(23) 
- Goon(26) 
- Brothel Keeper(8) 
- Innkeeper(16) 
- Tavern Keeper(21) 
- Buckle Maker(16) 
- Cobbler(14) 
- Draper(10) 
- Furrier(26) 
- Girdler(9) 
- Haberdasher(8) 
- Launderer(16) 
- Leatherworker(11) 
- Purse Maker(10) 
- Shoe Maker(14) 
- Tailor(16) 
- Tanner(15) 
- Used Garment Trader(24) 
- Vestment Maker(14) 
- Chandler(29) 
- Dye Makers(29) 
- Oil Trader(29) 
- Cleric(21) 
- High Priest(8) 
- Missionary(76) 
- Preacher(46) 
- Priest(26) 
- Farmer(565) 
- Homestead(754) 
- Farmer - Cabbage(57) 
- Farmer - Cattle Herder(57) 
- Farmer - Corn(57) 
- Farmer - Cow Herder(57) 
- Farmer - Dairy(57) 
- Farmer - Goat Herder(57) 
- Farmer - Pig Herder(57) 
- Farmer - Potato(57) 
- Farmer - Sheep Herder(57) 
- Farmer - Wheat(57) 
- Farmer(Special)(57) 
- Dungsweeper(16) 
- Illuminator(12) 
- Messenger(18) 
- Tax Collector(3) 
- Town Crier(33) 
- Town Justice(8) 
- Undertaker(7) 
- Water Carrier(23) 
- Leatherworker(12) 
- Skinner(12) 
- Naval Outfitter(6) 
- Pirate(29) 
- Sail Maker(17) 
- Sailor(38) 
- Ship Builder(7) 
imports: 
- Coral  
exports: 
- Mead  
defenses: Moats 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(19)  
> - Advocate(15)  
> - Alchemist(10)  
> - Animal Groomer(8)  
> - Animal Handler(19)  
> - Antiquities(19)  
> - Architect(23)  
> - Armor Dealer(19)  
> - Armorer(6)  
> - Artist(26)  
> - Astrologist(6)  
> - Baker(18)  
> - Banker(7)  
> - Barbarian(11)  
> - Barbarian(57)  
> - Barber(10)  
> - Baron(3)  
> - Barrel Maker(12)  
> - Barrel Maker(21)  
> - Basket Maker(17)  
> - Bather(8)  
> - Beer Merchant(11)  
> - Blacksmith(27)  
> - Bleacher(10)  
> - Book Binder(6)  
> - Bookseller(6)  
> - Bowyer-Fletcher(10)  
> - Bowyer-Fletcher(10)  
> - Brewer(3)  
> - Bricklayer(23)  
> - Brigand(19)  
> - Brigand(57)  
> - Brothel Keeper(8)  
> - Buckle Maker(16)  
> - Buckle Maker(9)  
> - Butcher(12)  
> - Candle Maker(8)  
> - Captain(57)  
> - Caravanner(15)  
> - Carpenter(33)  
> - Cartographer(10)  
> - Chandler(29)  
> - Chandler(29)  
> - Chicken Butcher(12)  
> - Cleric(21)  
> - Clerk(33)  
> - Clock Maker(6)  
> - Cobbler(14)  
> - Cobbler(18)  
> - Conjourer(6)  
> - Cook(12)  
> - Cooper(14)  
> - Council Member(29)  
> - Count(1)  
> - Crime Lord(5)  
> - Crook(23)  
> - Cutler(6)  
> - Dairy Seller(57)  
> - Diplomat(5)  
> - Distiller(11)  
> - Draper(10)  
> - Duke(1)  
> - Dungsweeper(16)  
> - Dye Makers(29)  
> - Dye Makers(29)  
> - Earl(1)  
> - Engineer(23)  
> - Engraver(6)  
> - Farmer - Cabbage(57)  
> - Farmer - Cattle Herder(57)  
> - Farmer - Corn(57)  
> - Farmer - Cow Herder(57)  
> - Farmer - Dairy(57)  
> - Farmer - Goat Herder(57)  
> - Farmer - Pig Herder(57)  
> - Farmer - Potato(57)  
> - Farmer - Sheep Herder(57)  
> - Farmer - Wheat(57)  
> - Farmer(565)  
> - Farmer(Special)(57)  
> - Fisherman(15)  
> - Fishmonger(15)  
> - Florist(10)  
> - Furniture Maker(18)  
> - Furrier(26)  
> - Girdler(9)  
> - Glassblower(19)  
> - Glassblower(9)  
> - Glazier(6)  
> - Glove Merchant(16)  
> - Goldsmith(13)  
> - Goldsmith(9)  
> - Goon(26)  
> - Grain Merchant(3)  
> - Grocer(9)  
> - Guide(19)  
> - Haberdasher(8)  
> - Harness Maker(19)  
> - Hat Maker(8)  
> - Hay Merchant(57)  
> - Herbalist(10)  
> - High Mage(6)  
> - High Priest(8)  
> - Historian(6)  
> - Homestead(754)  
> - Horse Trader(23)  
> - Huntsman(29)  
> - Illuminator(12)  
> - Innkeeper(16)  
> - Instrument Maker(6)  
> - Inventor(17)  
> - Jeweler(12)  
> - Jeweler(8)  
> - Judge(17)  
> - Kettle Maker(5)  
> - Knight(4)  
> - Laborer(23)  
> - Launderer(16)  
> - Launderer(19)  
> - Leatherworker(11)  
> - Leatherworker(12)  
> - Librarian(6)  
> - Livestock Merchant(16)  
> - Locksmith(7)  
> - Lord(4)  
> - Magical Artisan(6)  
> - Magical Artisan(6)  
> - Magical Tutor(6)  
> - Mason(23)  
> - Mayor(1)  
> - Meat Butcher(10)  
> - Messenger(18)  
> - Miller(29)  
> - Minstrel(19)  
> - Missionary(76)  
> - Mountainman(57)  
> - Mountainman(9)  
> - Naval Outfitter(6)  
> - Oil Trader(29)  
> - Oil Trader(29)  
> - Painter(Art)(21)  
> - Painter(Building)(23)  
> - Pastry Maker(15)  
> - Pathfinder(10)  
> - Pawnbroker(7)  
> - Perfumer(8)  
> - Physic/Chirurgeon(10)  
> - Pirate(29)  
> - Plasterer(23)  
> - Potionmakers(10)  
> - Potter(19)  
> - Preacher(46)  
> - Priest(26)  
> - Professor(6)  
> - Purse Maker(10)  
> - Roofer(23)  
> - Roofer(23)  
> - Rope Maker(14)  
> - Rug Maker(7)  
> - Saddler(15)  
> - Sage(6)  
> - Sail Maker(17)  
> - Sailor(38)  
> - Scout(10)  
> - Scribe(6)  
> - Sculptor(5)  
> - SellSpell(6)  
> - Ship Builder(7)  
> - Shoe Maker(14)  
> - Shoe Maker(14)  
> - Silversmith(17)  
> - Silversmith(7)  
> - Skinner(12)  
> - Slaver(19)  
> - Slaver(19)  
> - Soap Maker(10)  
> - Spice Merchant(19)  
> - Spice Merchant(19)  
> - Stabler(21)  
> - Storyteller(19)  
> - Tailor(16)  
> - Tanner(15)  
> - Tanner(15)  
> - Tavern Keeper(21)  
> - Tax Collector(3)  
> - Taxidermist(19)  
> - Taxidermist(19)  
> - Teacher(6)  
> - Teamster(23)  
> - Tiler(23)  
> - Tinker(29)  
> - Tinker(7)  
> - Tobacco Merchant(19)  
> - Tobacco Merchant(19)  
> - Town Crier(33)  
> - Town Justice(8)  
> - Toymaker(6)  
> - Toymaker(9)  
> - Trading Post(29)  
> - Troubadours(19)  
> - Tutor(6)  
> - Undertaker(7)  
> - Used Garment Trader(24)  
> - Vestment Maker(14)  
> - Vintner(12)  
> - Viscount(2)  
> - Wagon Maker(17)  
> - Warehouser(19)  
> - Water Carrier(23)  
> - Weapon Dealer(19)  
> - Weapon Dealer(19)  
> - Weaponsmith(6)  
> - Weaponsmith(6)  
> - Weaver(17)  
> - Wheelwright(18)  
> - Wheelwright(26)  
> - Wine Merchant(10)  
> - Wood Carver(10)  
> - Wood Seller(9)  
> - Wool Merchant(15)  
> - Writer(19)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(19)  
> - Advocate(15)  
> - Alchemist(10)  
> - Animal Groomer(8)  
> - Animal Handler(19)  
> - Antiquities(19)  
> - Architect(23)  
> - Armor Dealer(19)  
> - Armorer(6)  
> - Artist(26)  
> - Astrologist(6)  
> - Baker(18)  
> - Banker(7)  
> - Barbarian(11)  
> - Barbarian(57)  
> - Barber(10)  
> - Baron(3)  
> - Barrel Maker(12)  
> - Barrel Maker(21)  
> - Basket Maker(17)  
> - Bather(8)  
> - Beer Merchant(11)  
> - Blacksmith(27)  
> - Bleacher(10)  
> - Book Binder(6)  
> - Bookseller(6)  
> - Bowyer-Fletcher(10)  
> - Bowyer-Fletcher(10)  
> - Brewer(3)  
> - Bricklayer(23)  
> - Brigand(19)  
> - Brigand(57)  
> - Brothel Keeper(8)  
> - Buckle Maker(16)  
> - Buckle Maker(9)  
> - Butcher(12)  
> - Candle Maker(8)  
> - Captain(57)  
> - Caravanner(15)  
> - Carpenter(33)  
> - Cartographer(10)  
> - Chandler(29)  
> - Chandler(29)  
> - Chicken Butcher(12)  
> - Cleric(21)  
> - Clerk(33)  
> - Clock Maker(6)  
> - Cobbler(14)  
> - Cobbler(18)  
> - Conjourer(6)  
> - Cook(12)  
> - Cooper(14)  
> - Council Member(29)  
> - Count(1)  
> - Crime Lord(5)  
> - Crook(23)  
> - Cutler(6)  
> - Dairy Seller(57)  
> - Diplomat(5)  
> - Distiller(11)  
> - Draper(10)  
> - Duke(1)  
> - Dungsweeper(16)  
> - Dye Makers(29)  
> - Dye Makers(29)  
> - Earl(1)  
> - Engineer(23)  
> - Engraver(6)  
> - Farmer - Cabbage(57)  
> - Farmer - Cattle Herder(57)  
> - Farmer - Corn(57)  
> - Farmer - Cow Herder(57)  
> - Farmer - Dairy(57)  
> - Farmer - Goat Herder(57)  
> - Farmer - Pig Herder(57)  
> - Farmer - Potato(57)  
> - Farmer - Sheep Herder(57)  
> - Farmer - Wheat(57)  
> - Farmer(565)  
> - Farmer(Special)(57)  
> - Fisherman(15)  
> - Fishmonger(15)  
> - Florist(10)  
> - Furniture Maker(18)  
> - Furrier(26)  
> - Girdler(9)  
> - Glassblower(19)  
> - Glassblower(9)  
> - Glazier(6)  
> - Glove Merchant(16)  
> - Goldsmith(13)  
> - Goldsmith(9)  
> - Goon(26)  
> - Grain Merchant(3)  
> - Grocer(9)  
> - Guide(19)  
> - Haberdasher(8)  
> - Harness Maker(19)  
> - Hat Maker(8)  
> - Hay Merchant(57)  
> - Herbalist(10)  
> - High Mage(6)  
> - High Priest(8)  
> - Historian(6)  
> - Homestead(754)  
> - Horse Trader(23)  
> - Huntsman(29)  
> - Illuminator(12)  
> - Innkeeper(16)  
> - Instrument Maker(6)  
> - Inventor(17)  
> - Jeweler(12)  
> - Jeweler(8)  
> - Judge(17)  
> - Kettle Maker(5)  
> - Knight(4)  
> - Laborer(23)  
> - Launderer(16)  
> - Launderer(19)  
> - Leatherworker(11)  
> - Leatherworker(12)  
> - Librarian(6)  
> - Livestock Merchant(16)  
> - Locksmith(7)  
> - Lord(4)  
> - Magical Artisan(6)  
> - Magical Artisan(6)  
> - Magical Tutor(6)  
> - Mason(23)  
> - Mayor(1)  
> - Meat Butcher(10)  
> - Messenger(18)  
> - Miller(29)  
> - Minstrel(19)  
> - Missionary(76)  
> - Mountainman(57)  
> - Mountainman(9)  
> - Naval Outfitter(6)  
> - Oil Trader(29)  
> - Oil Trader(29)  
> - Painter(Art)(21)  
> - Painter(Building)(23)  
> - Pastry Maker(15)  
> - Pathfinder(10)  
> - Pawnbroker(7)  
> - Perfumer(8)  
> - Physic/Chirurgeon(10)  
> - Pirate(29)  
> - Plasterer(23)  
> - Potionmakers(10)  
> - Potter(19)  
> - Preacher(46)  
> - Priest(26)  
> - Professor(6)  
> - Purse Maker(10)  
> - Roofer(23)  
> - Roofer(23)  
> - Rope Maker(14)  
> - Rug Maker(7)  
> - Saddler(15)  
> - Sage(6)  
> - Sail Maker(17)  
> - Sailor(38)  
> - Scout(10)  
> - Scribe(6)  
> - Sculptor(5)  
> - SellSpell(6)  
> - Ship Builder(7)  
> - Shoe Maker(14)  
> - Shoe Maker(14)  
> - Silversmith(17)  
> - Silversmith(7)  
> - Skinner(12)  
> - Slaver(19)  
> - Slaver(19)  
> - Soap Maker(10)  
> - Spice Merchant(19)  
> - Spice Merchant(19)  
> - Stabler(21)  
> - Storyteller(19)  
> - Tailor(16)  
> - Tanner(15)  
> - Tanner(15)  
> - Tavern Keeper(21)  
> - Tax Collector(3)  
> - Taxidermist(19)  
> - Taxidermist(19)  
> - Teacher(6)  
> - Teamster(23)  
> - Tiler(23)  
> - Tinker(29)  
> - Tinker(7)  
> - Tobacco Merchant(19)  
> - Tobacco Merchant(19)  
> - Town Crier(33)  
> - Town Justice(8)  
> - Toymaker(6)  
> - Toymaker(9)  
> - Trading Post(29)  
> - Troubadours(19)  
> - Tutor(6)  
> - Undertaker(7)  
> - Used Garment Trader(24)  
> - Vestment Maker(14)  
> - Vintner(12)  
> - Viscount(2)  
> - Wagon Maker(17)  
> - Warehouser(19)  
> - Water Carrier(23)  
> - Weapon Dealer(19)  
> - Weapon Dealer(19)  
> - Weaponsmith(6)  
> - Weaponsmith(6)  
> - Weaver(17)  
> - Wheelwright(18)  
> - Wheelwright(26)  
> - Wine Merchant(10)  
> - Wood Carver(10)  
> - Wood Seller(9)  
> - Wool Merchant(15)  
> - Writer(19)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



