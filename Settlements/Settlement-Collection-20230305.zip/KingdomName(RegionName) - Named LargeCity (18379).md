---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeCity
kingdom: KingdomName
region: RegionName
settlementName: Named LargeCity (18379)
terrain: Hills 
settlementDescription: 
population: 18379
culture: African 
technology: Crusades 
leader: 
govermentType: Monarchy 
demographics: 
- Acrobat(31) 
- Minstrel(31) 
- Storyteller(31) 
- Troubadours(31) 
- Writer(31) 
- Advocate(23) 
- Clerk(53) 
- Council Member(46) 
- Diplomat(8) 
- Judge(27) 
- Mayor(1) 
- Alchemist(16) 
- Chandler(46) 
- Dye Makers(46) 
- Florist(16) 
- Herbalist(16) 
- Potionmakers(16) 
- Sage(9) 
- Spice Merchant(31) 
- Taxidermist(31) 
- Tobacco Merchant(31) 
- Animal Groomer(13) 
- Animal Handler(31) 
- Caravanner(23) 
- Horse Trader(37) 
- Livestock Merchant(25) 
- Stabler(33) 
- Antiquities(31) 
- Armor Dealer(31) 
- Launderer(31) 
- Oil Trader(46) 
- Trading Post(46) 
- Slaver(31) 
- Spice Merchant(31) 
- Taxidermist(31) 
- Tobacco Merchant(31) 
- Warehouser(31) 
- Weapon Dealer(31) 
- Architect(37) 
- Bricklayer(37) 
- Engineer(37) 
- Laborer(37) 
- Mason(37) 
- Painter(Building)(37) 
- Plasterer(37) 
- Roofer(37) 
- Teamster(37) 
- Tiler(37) 
- Armorer(10) 
- Blacksmith(44) 
- Bowyer-Fletcher(15) 
- Jeweler(12) 
- Silversmith(11) 
- Weapon Dealer(31) 
- Weaponsmith(9) 
- Artist(41) 
- Glassblower(31) 
- Goldsmith(21) 
- Inventor(27) 
- Jeweler(19) 
- Magical Artisan(9) 
- Painter(Art)(34) 
- Silversmith(27) 
- Tinker(46) 
- Toymaker(15) 
- Astrologist(9) 
- Conjourer(9) 
- High Mage(9) 
- Historian(9) 
- Librarian(9) 
- Magical Artisan(9) 
- Magical Tutor(9) 
- Professor(9) 
- Scribe(9) 
- SellSpell(9) 
- Teacher(9) 
- Tutor(9) 
- Baker(29) 
- Beer Merchant(17) 
- Brewer(5) 
- Butcher(19) 
- Chicken Butcher(19) 
- Cook(20) 
- Dairy Seller(92) 
- Distiller(17) 
- Hay Merchant(92) 
- Fisherman(23) 
- Fishmonger(23) 
- Grain Merchant(5) 
- Grocer(14) 
- Meat Butcher(16) 
- Miller(46) 
- Pastry Maker(23) 
- Vintner(20) 
- Banker(11) 
- Pawnbroker(11) 
- Barbarian(92) 
- Brigand(92) 
- Captain(92) 
- Mountainman(92) 
- Barbarian(17) 
- Cartographer(16) 
- Guide(31) 
- Huntsman(46) 
- Mountainman(15) 
- Pathfinder(16) 
- Scout(16) 
- Slaver(31) 
- Barrel Maker(20) 
- Basket Maker(27) 
- Book Binder(10) 
- Bookseller(9) 
- Buckle Maker(15) 
- Candle Maker(12) 
- Clock Maker(9) 
- Cobbler(29) 
- Cooper(22) 
- Cutler(10) 
- Engraver(9) 
- Furniture Maker(29) 
- Glassblower(14) 
- Glazier(9) 
- Glove Merchant(25) 
- Goldsmith(14) 
- Harness Maker(31) 
- Hat Maker(13) 
- Instrument Maker(9) 
- Kettle Maker(8) 
- Locksmith(11) 
- Perfumer(13) 
- Potter(31) 
- Rope Maker(22) 
- Rug Maker(12) 
- Saddler(23) 
- Sculptor(8) 
- Shoe Maker(22) 
- Soap Maker(16) 
- Tanner(23) 
- Tinker(11) 
- Toymaker(9) 
- Weaponsmith(9) 
- Weaver(27) 
- Wheelwright(41) 
- Wine Merchant(16) 
- Wool Merchant(23) 
- Lord(7) 
- Knight(7) 
- Baron(4) 
- Viscount(3) 
- Earl(2) 
- Count(2) 
- Duke(1) 
- Barrel Maker(34) 
- Bowyer-Fletcher(15) 
- Carpenter(53) 
- Roofer(37) 
- Wagon Maker(27) 
- Wheelwright(29) 
- Wood Carver(15) 
- Wood Seller(14) 
- Barber(16) 
- Bleacher(16) 
- Physic/Chirurgeon(16) 
- Bather(13) 
- Brigand(31) 
- Crime Lord(8) 
- Crook(37) 
- Goon(41) 
- Brothel Keeper(13) 
- Innkeeper(25) 
- Tavern Keeper(34) 
- Buckle Maker(25) 
- Cobbler(22) 
- Draper(16) 
- Furrier(41) 
- Girdler(14) 
- Haberdasher(12) 
- Launderer(25) 
- Leatherworker(17) 
- Purse Maker(16) 
- Shoe Maker(22) 
- Tailor(25) 
- Tanner(23) 
- Used Garment Trader(39) 
- Vestment Maker(22) 
- Chandler(46) 
- Dye Makers(46) 
- Oil Trader(46) 
- Cleric(34) 
- High Priest(13) 
- Missionary(123) 
- Preacher(74) 
- Priest(41) 
- Farmer(919) 
- Homestead(1226) 
- Farmer - Cabbage(92) 
- Farmer - Cattle Herder(92) 
- Farmer - Corn(92) 
- Farmer - Cow Herder(92) 
- Farmer - Dairy(92) 
- Farmer - Goat Herder(92) 
- Farmer - Pig Herder(92) 
- Farmer - Potato(92) 
- Farmer - Sheep Herder(92) 
- Farmer - Wheat(92) 
- Farmer(Special)(92) 
- Dungsweeper(26) 
- Illuminator(19) 
- Messenger(29) 
- Tax Collector(5) 
- Town Crier(53) 
- Town Justice(13) 
- Undertaker(11) 
- Water Carrier(37) 
- Leatherworker(19) 
- Skinner(19) 
- Naval Outfitter(10) 
- Pirate(46) 
- Sail Maker(27) 
- Sailor(62) 
- Ship Builder(11) 
imports: 
- Jute  
exports: 
- Jute  
defenses: Keeps 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(31)  
> - Advocate(23)  
> - Alchemist(16)  
> - Animal Groomer(13)  
> - Animal Handler(31)  
> - Antiquities(31)  
> - Architect(37)  
> - Armor Dealer(31)  
> - Armorer(10)  
> - Artist(41)  
> - Astrologist(9)  
> - Baker(29)  
> - Banker(11)  
> - Barbarian(17)  
> - Barbarian(92)  
> - Barber(16)  
> - Baron(4)  
> - Barrel Maker(20)  
> - Barrel Maker(34)  
> - Basket Maker(27)  
> - Bather(13)  
> - Beer Merchant(17)  
> - Blacksmith(44)  
> - Bleacher(16)  
> - Book Binder(10)  
> - Bookseller(9)  
> - Bowyer-Fletcher(15)  
> - Bowyer-Fletcher(15)  
> - Brewer(5)  
> - Bricklayer(37)  
> - Brigand(31)  
> - Brigand(92)  
> - Brothel Keeper(13)  
> - Buckle Maker(15)  
> - Buckle Maker(25)  
> - Butcher(19)  
> - Candle Maker(12)  
> - Captain(92)  
> - Caravanner(23)  
> - Carpenter(53)  
> - Cartographer(16)  
> - Chandler(46)  
> - Chandler(46)  
> - Chicken Butcher(19)  
> - Cleric(34)  
> - Clerk(53)  
> - Clock Maker(9)  
> - Cobbler(22)  
> - Cobbler(29)  
> - Conjourer(9)  
> - Cook(20)  
> - Cooper(22)  
> - Council Member(46)  
> - Count(2)  
> - Crime Lord(8)  
> - Crook(37)  
> - Cutler(10)  
> - Dairy Seller(92)  
> - Diplomat(8)  
> - Distiller(17)  
> - Draper(16)  
> - Duke(1)  
> - Dungsweeper(26)  
> - Dye Makers(46)  
> - Dye Makers(46)  
> - Earl(2)  
> - Engineer(37)  
> - Engraver(9)  
> - Farmer - Cabbage(92)  
> - Farmer - Cattle Herder(92)  
> - Farmer - Corn(92)  
> - Farmer - Cow Herder(92)  
> - Farmer - Dairy(92)  
> - Farmer - Goat Herder(92)  
> - Farmer - Pig Herder(92)  
> - Farmer - Potato(92)  
> - Farmer - Sheep Herder(92)  
> - Farmer - Wheat(92)  
> - Farmer(919)  
> - Farmer(Special)(92)  
> - Fisherman(23)  
> - Fishmonger(23)  
> - Florist(16)  
> - Furniture Maker(29)  
> - Furrier(41)  
> - Girdler(14)  
> - Glassblower(14)  
> - Glassblower(31)  
> - Glazier(9)  
> - Glove Merchant(25)  
> - Goldsmith(14)  
> - Goldsmith(21)  
> - Goon(41)  
> - Grain Merchant(5)  
> - Grocer(14)  
> - Guide(31)  
> - Haberdasher(12)  
> - Harness Maker(31)  
> - Hat Maker(13)  
> - Hay Merchant(92)  
> - Herbalist(16)  
> - High Mage(9)  
> - High Priest(13)  
> - Historian(9)  
> - Homestead(1226)  
> - Horse Trader(37)  
> - Huntsman(46)  
> - Illuminator(19)  
> - Innkeeper(25)  
> - Instrument Maker(9)  
> - Inventor(27)  
> - Jeweler(12)  
> - Jeweler(19)  
> - Judge(27)  
> - Kettle Maker(8)  
> - Knight(7)  
> - Laborer(37)  
> - Launderer(25)  
> - Launderer(31)  
> - Leatherworker(17)  
> - Leatherworker(19)  
> - Librarian(9)  
> - Livestock Merchant(25)  
> - Locksmith(11)  
> - Lord(7)  
> - Magical Artisan(9)  
> - Magical Artisan(9)  
> - Magical Tutor(9)  
> - Mason(37)  
> - Mayor(1)  
> - Meat Butcher(16)  
> - Messenger(29)  
> - Miller(46)  
> - Minstrel(31)  
> - Missionary(123)  
> - Mountainman(15)  
> - Mountainman(92)  
> - Naval Outfitter(10)  
> - Oil Trader(46)  
> - Oil Trader(46)  
> - Painter(Art)(34)  
> - Painter(Building)(37)  
> - Pastry Maker(23)  
> - Pathfinder(16)  
> - Pawnbroker(11)  
> - Perfumer(13)  
> - Physic/Chirurgeon(16)  
> - Pirate(46)  
> - Plasterer(37)  
> - Potionmakers(16)  
> - Potter(31)  
> - Preacher(74)  
> - Priest(41)  
> - Professor(9)  
> - Purse Maker(16)  
> - Roofer(37)  
> - Roofer(37)  
> - Rope Maker(22)  
> - Rug Maker(12)  
> - Saddler(23)  
> - Sage(9)  
> - Sail Maker(27)  
> - Sailor(62)  
> - Scout(16)  
> - Scribe(9)  
> - Sculptor(8)  
> - SellSpell(9)  
> - Ship Builder(11)  
> - Shoe Maker(22)  
> - Shoe Maker(22)  
> - Silversmith(11)  
> - Silversmith(27)  
> - Skinner(19)  
> - Slaver(31)  
> - Slaver(31)  
> - Soap Maker(16)  
> - Spice Merchant(31)  
> - Spice Merchant(31)  
> - Stabler(33)  
> - Storyteller(31)  
> - Tailor(25)  
> - Tanner(23)  
> - Tanner(23)  
> - Tavern Keeper(34)  
> - Tax Collector(5)  
> - Taxidermist(31)  
> - Taxidermist(31)  
> - Teacher(9)  
> - Teamster(37)  
> - Tiler(37)  
> - Tinker(11)  
> - Tinker(46)  
> - Tobacco Merchant(31)  
> - Tobacco Merchant(31)  
> - Town Crier(53)  
> - Town Justice(13)  
> - Toymaker(15)  
> - Toymaker(9)  
> - Trading Post(46)  
> - Troubadours(31)  
> - Tutor(9)  
> - Undertaker(11)  
> - Used Garment Trader(39)  
> - Vestment Maker(22)  
> - Vintner(20)  
> - Viscount(3)  
> - Wagon Maker(27)  
> - Warehouser(31)  
> - Water Carrier(37)  
> - Weapon Dealer(31)  
> - Weapon Dealer(31)  
> - Weaponsmith(9)  
> - Weaponsmith(9)  
> - Weaver(27)  
> - Wheelwright(29)  
> - Wheelwright(41)  
> - Wine Merchant(16)  
> - Wood Carver(15)  
> - Wood Seller(14)  
> - Wool Merchant(23)  
> - Writer(31)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes





> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(31)  
> - Advocate(23)  
> - Alchemist(16)  
> - Animal Groomer(13)  
> - Animal Handler(31)  
> - Antiquities(31)  
> - Architect(37)  
> - Armor Dealer(31)  
> - Armorer(10)  
> - Artist(41)  
> - Astrologist(9)  
> - Baker(29)  
> - Banker(11)  
> - Barbarian(17)  
> - Barbarian(92)  
> - Barber(16)  
> - Baron(4)  
> - Barrel Maker(20)  
> - Barrel Maker(34)  
> - Basket Maker(27)  
> - Bather(13)  
> - Beer Merchant(17)  
> - Blacksmith(44)  
> - Bleacher(16)  
> - Book Binder(10)  
> - Bookseller(9)  
> - Bowyer-Fletcher(15)  
> - Bowyer-Fletcher(15)  
> - Brewer(5)  
> - Bricklayer(37)  
> - Brigand(31)  
> - Brigand(92)  
> - Brothel Keeper(13)  
> - Buckle Maker(15)  
> - Buckle Maker(25)  
> - Butcher(19)  
> - Candle Maker(12)  
> - Captain(92)  
> - Caravanner(23)  
> - Carpenter(53)  
> - Cartographer(16)  
> - Chandler(46)  
> - Chandler(46)  
> - Chicken Butcher(19)  
> - Cleric(34)  
> - Clerk(53)  
> - Clock Maker(9)  
> - Cobbler(22)  
> - Cobbler(29)  
> - Conjourer(9)  
> - Cook(20)  
> - Cooper(22)  
> - Council Member(46)  
> - Count(2)  
> - Crime Lord(8)  
> - Crook(37)  
> - Cutler(10)  
> - Dairy Seller(92)  
> - Diplomat(8)  
> - Distiller(17)  
> - Draper(16)  
> - Duke(1)  
> - Dungsweeper(26)  
> - Dye Makers(46)  
> - Dye Makers(46)  
> - Earl(2)  
> - Engineer(37)  
> - Engraver(9)  
> - Farmer - Cabbage(92)  
> - Farmer - Cattle Herder(92)  
> - Farmer - Corn(92)  
> - Farmer - Cow Herder(92)  
> - Farmer - Dairy(92)  
> - Farmer - Goat Herder(92)  
> - Farmer - Pig Herder(92)  
> - Farmer - Potato(92)  
> - Farmer - Sheep Herder(92)  
> - Farmer - Wheat(92)  
> - Farmer(919)  
> - Farmer(Special)(92)  
> - Fisherman(23)  
> - Fishmonger(23)  
> - Florist(16)  
> - Furniture Maker(29)  
> - Furrier(41)  
> - Girdler(14)  
> - Glassblower(14)  
> - Glassblower(31)  
> - Glazier(9)  
> - Glove Merchant(25)  
> - Goldsmith(14)  
> - Goldsmith(21)  
> - Goon(41)  
> - Grain Merchant(5)  
> - Grocer(14)  
> - Guide(31)  
> - Haberdasher(12)  
> - Harness Maker(31)  
> - Hat Maker(13)  
> - Hay Merchant(92)  
> - Herbalist(16)  
> - High Mage(9)  
> - High Priest(13)  
> - Historian(9)  
> - Homestead(1226)  
> - Horse Trader(37)  
> - Huntsman(46)  
> - Illuminator(19)  
> - Innkeeper(25)  
> - Instrument Maker(9)  
> - Inventor(27)  
> - Jeweler(12)  
> - Jeweler(19)  
> - Judge(27)  
> - Kettle Maker(8)  
> - Knight(7)  
> - Laborer(37)  
> - Launderer(25)  
> - Launderer(31)  
> - Leatherworker(17)  
> - Leatherworker(19)  
> - Librarian(9)  
> - Livestock Merchant(25)  
> - Locksmith(11)  
> - Lord(7)  
> - Magical Artisan(9)  
> - Magical Artisan(9)  
> - Magical Tutor(9)  
> - Mason(37)  
> - Mayor(1)  
> - Meat Butcher(16)  
> - Messenger(29)  
> - Miller(46)  
> - Minstrel(31)  
> - Missionary(123)  
> - Mountainman(15)  
> - Mountainman(92)  
> - Naval Outfitter(10)  
> - Oil Trader(46)  
> - Oil Trader(46)  
> - Painter(Art)(34)  
> - Painter(Building)(37)  
> - Pastry Maker(23)  
> - Pathfinder(16)  
> - Pawnbroker(11)  
> - Perfumer(13)  
> - Physic/Chirurgeon(16)  
> - Pirate(46)  
> - Plasterer(37)  
> - Potionmakers(16)  
> - Potter(31)  
> - Preacher(74)  
> - Priest(41)  
> - Professor(9)  
> - Purse Maker(16)  
> - Roofer(37)  
> - Roofer(37)  
> - Rope Maker(22)  
> - Rug Maker(12)  
> - Saddler(23)  
> - Sage(9)  
> - Sail Maker(27)  
> - Sailor(62)  
> - Scout(16)  
> - Scribe(9)  
> - Sculptor(8)  
> - SellSpell(9)  
> - Ship Builder(11)  
> - Shoe Maker(22)  
> - Shoe Maker(22)  
> - Silversmith(11)  
> - Silversmith(27)  
> - Skinner(19)  
> - Slaver(31)  
> - Slaver(31)  
> - Soap Maker(16)  
> - Spice Merchant(31)  
> - Spice Merchant(31)  
> - Stabler(33)  
> - Storyteller(31)  
> - Tailor(25)  
> - Tanner(23)  
> - Tanner(23)  
> - Tavern Keeper(34)  
> - Tax Collector(5)  
> - Taxidermist(31)  
> - Taxidermist(31)  
> - Teacher(9)  
> - Teamster(37)  
> - Tiler(37)  
> - Tinker(11)  
> - Tinker(46)  
> - Tobacco Merchant(31)  
> - Tobacco Merchant(31)  
> - Town Crier(53)  
> - Town Justice(13)  
> - Toymaker(15)  
> - Toymaker(9)  
> - Trading Post(46)  
> - Troubadours(31)  
> - Tutor(9)  
> - Undertaker(11)  
> - Used Garment Trader(39)  
> - Vestment Maker(22)  
> - Vintner(20)  
> - Viscount(3)  
> - Wagon Maker(27)  
> - Warehouser(31)  
> - Water Carrier(37)  
> - Weapon Dealer(31)  
> - Weapon Dealer(31)  
> - Weaponsmith(9)  
> - Weaponsmith(9)  
> - Weaver(27)  
> - Wheelwright(29)  
> - Wheelwright(41)  
> - Wine Merchant(16)  
> - Wood Carver(15)  
> - Wood Seller(14)  
> - Wool Merchant(23)  
> - Writer(31)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType != "POI"
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



