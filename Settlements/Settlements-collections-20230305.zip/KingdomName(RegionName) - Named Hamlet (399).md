---
cssclass: oRPGPage
fileType: settlement
settlementType: Hamlet
kingdom: KingdomName
region: RegionName
settlementName: Named Hamlet (399)
terrain: Forest Heavy Fungal 
settlementDescription: 
population: 399
culture: Viking 
technology: Dark Ages 
leader: 
govermentType: Plutocracy 
demographics: 
- Clerk(1) 
- Judge(1) 
- Mayor(1) 
- Horse Trader(1) 
- Stabler(1) 
- Trading Post(1) 
- Blacksmith(1) 
- Tinker(1) 
- Barbarian(1) 
- Brigand(1) 
- Captain(1) 
- Mountainman(1) 
- Barbarian(1) 
- Huntsman(1) 
- Barrel Maker(1) 
- Cooper(1) 
- Wheelwright(1) 
- Barrel Maker(1) 
- Carpenter(1) 
- Wheelwright(1) 
- Brigand(1) 
- Crook(1) 
- Goon(1) 
- Innkeeper(1) 
- Tavern Keeper(1) 
- Buckle Maker(1) 
- Cobbler(1) 
- Furrier(1) 
- Shoe Maker(1) 
- Tailor(1) 
- Tanner(1) 
- Used Garment Trader(1) 
- Missionary(3) 
- Preacher(1) 
- Priest(1) 
- Farmer(20) 
- Homestead(27) 
- Farmer - Corn(2) 
- Farmer - Cow Herder(1) 
- Farmer - Dairy(1) 
- Farmer - Goat Herder(2) 
- Farmer - Pig Herder(2) 
- Farmer - Potato(1) 
- Farmer - Sheep Herder(1) 
- Farmer - Wheat(2) 
- Town Crier(1) 
- Town Justice(1) 
- Water Carrier(1) 
- Pirate(1) 
- Sail Maker(1) 
- Sailor(1) 
imports: 
- Beer  
exports: 
- Beeswax  
defenses: Turrets 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Barbarian(1)  
> - Barbarian(1)  
> - Barrel Maker(1)  
> - Barrel Maker(1)  
> - Blacksmith(1)  
> - Brigand(1)  
> - Brigand(1)  
> - Buckle Maker(1)  
> - Captain(1)  
> - Carpenter(1)  
> - Clerk(1)  
> - Cobbler(1)  
> - Cooper(1)  
> - Crook(1)  
> - Farmer - Corn(2)  
> - Farmer - Cow Herder(1)  
> - Farmer - Dairy(1)  
> - Farmer - Goat Herder(2)  
> - Farmer - Pig Herder(2)  
> - Farmer - Potato(1)  
> - Farmer - Sheep Herder(1)  
> - Farmer - Wheat(2)  
> - Farmer(20)  
> - Furrier(1)  
> - Goon(1)  
> - Homestead(27)  
> - Horse Trader(1)  
> - Huntsman(1)  
> - Innkeeper(1)  
> - Judge(1)  
> - Mayor(1)  
> - Missionary(3)  
> - Mountainman(1)  
> - Pirate(1)  
> - Preacher(1)  
> - Priest(1)  
> - Sail Maker(1)  
> - Sailor(1)  
> - Shoe Maker(1)  
> - Stabler(1)  
> - Tailor(1)  
> - Tanner(1)  
> - Tavern Keeper(1)  
> - Tinker(1)  
> - Town Crier(1)  
> - Town Justice(1)  
> - Trading Post(1)  
> - Used Garment Trader(1)  
> - Water Carrier(1)  
> - Wheelwright(1)  
> - Wheelwright(1)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC


> ###### Notable Points of Interest
> ```dataview
table without ID file.link AS Name, wardType AS "Type"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC


## Notable Characters

> ###### Notable Characters
> ```dataview
table without ID file.link AS Name, race as Race, PrimaryOccupation as Profession
where kingdom=this.kingdom and settlementName=this.settlementName  and (fileType="npc"  and importance > 5)
sort importance DESC


## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



