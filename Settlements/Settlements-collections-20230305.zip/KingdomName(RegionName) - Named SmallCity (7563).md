---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallCity
kingdom: KingdomName
region: RegionName
settlementName: Named SmallCity (7563)
terrain: Desert Oasis 
settlementDescription: 
population: 7563
culture: Oriental 
technology: Stone Age 
leader: 
govermentType: Confederation 
demographics: 
- Acrobat(13) 
- Minstrel(13) 
- Storyteller(13) 
- Troubadours(13) 
- Writer(13) 
- Advocate(10) 
- Clerk(22) 
- Council Member(19) 
- Diplomat(4) 
- Judge(11) 
- Mayor(1) 
- Alchemist(7) 
- Chandler(19) 
- Dye Makers(19) 
- Florist(7) 
- Herbalist(7) 
- Potionmakers(7) 
- Sage(4) 
- Spice Merchant(13) 
- Taxidermist(13) 
- Tobacco Merchant(13) 
- Animal Groomer(6) 
- Animal Handler(13) 
- Caravanner(10) 
- Horse Trader(16) 
- Livestock Merchant(11) 
- Stabler(14) 
- Antiquities(13) 
- Armor Dealer(13) 
- Launderer(13) 
- Oil Trader(19) 
- Trading Post(19) 
- Slaver(13) 
- Spice Merchant(13) 
- Taxidermist(13) 
- Tobacco Merchant(13) 
- Warehouser(13) 
- Weapon Dealer(13) 
- Architect(16) 
- Bricklayer(16) 
- Engineer(16) 
- Laborer(16) 
- Mason(16) 
- Painter(Building)(16) 
- Plasterer(16) 
- Roofer(16) 
- Teamster(16) 
- Tiler(16) 
- Armorer(4) 
- Blacksmith(18) 
- Bowyer-Fletcher(7) 
- Jeweler(5) 
- Silversmith(5) 
- Weapon Dealer(13) 
- Weaponsmith(4) 
- Artist(17) 
- Glassblower(13) 
- Goldsmith(9) 
- Inventor(11) 
- Jeweler(8) 
- Magical Artisan(4) 
- Painter(Art)(14) 
- Silversmith(11) 
- Tinker(19) 
- Toymaker(6) 
- Astrologist(4) 
- Conjourer(4) 
- High Mage(4) 
- Historian(4) 
- Librarian(4) 
- Magical Artisan(4) 
- Magical Tutor(4) 
- Professor(4) 
- Scribe(4) 
- SellSpell(4) 
- Teacher(4) 
- Tutor(4) 
- Baker(12) 
- Beer Merchant(7) 
- Brewer(1) 
- Butcher(8) 
- Chicken Butcher(8) 
- Cook(8) 
- Dairy Seller(38) 
- Distiller(7) 
- Hay Merchant(38) 
- Fisherman(10) 
- Fishmonger(10) 
- Grain Merchant(1) 
- Grocer(6) 
- Meat Butcher(7) 
- Miller(19) 
- Pastry Maker(10) 
- Vintner(8) 
- Banker(5) 
- Pawnbroker(5) 
- Barbarian(38) 
- Brigand(38) 
- Captain(38) 
- Mountainman(38) 
- Barbarian(7) 
- Cartographer(7) 
- Guide(13) 
- Huntsman(19) 
- Mountainman(6) 
- Pathfinder(7) 
- Scout(7) 
- Slaver(13) 
- Barrel Maker(8) 
- Basket Maker(11) 
- Book Binder(4) 
- Bookseller(4) 
- Buckle Maker(6) 
- Candle Maker(5) 
- Clock Maker(4) 
- Cobbler(12) 
- Cooper(9) 
- Cutler(4) 
- Engraver(4) 
- Furniture Maker(12) 
- Glassblower(6) 
- Glazier(4) 
- Glove Merchant(11) 
- Goldsmith(6) 
- Harness Maker(13) 
- Hat Maker(6) 
- Instrument Maker(4) 
- Kettle Maker(4) 
- Locksmith(5) 
- Perfumer(6) 
- Potter(13) 
- Rope Maker(9) 
- Rug Maker(5) 
- Saddler(10) 
- Sculptor(4) 
- Shoe Maker(9) 
- Soap Maker(7) 
- Tanner(10) 
- Tinker(5) 
- Toymaker(4) 
- Weaponsmith(4) 
- Weaver(11) 
- Wheelwright(17) 
- Wine Merchant(7) 
- Wool Merchant(10) 
- Lord(3) 
- Knight(3) 
- Baron(2) 
- Viscount(1) 
- Earl(1) 
- Count(1) 
- Barrel Maker(14) 
- Bowyer-Fletcher(7) 
- Carpenter(22) 
- Roofer(16) 
- Wagon Maker(11) 
- Wheelwright(12) 
- Wood Carver(7) 
- Wood Seller(6) 
- Barber(7) 
- Bleacher(7) 
- Physic/Chirurgeon(7) 
- Bather(6) 
- Brigand(13) 
- Crime Lord(4) 
- Crook(16) 
- Goon(17) 
- Brothel Keeper(6) 
- Innkeeper(11) 
- Tavern Keeper(14) 
- Buckle Maker(11) 
- Cobbler(9) 
- Draper(7) 
- Furrier(17) 
- Girdler(6) 
- Haberdasher(5) 
- Launderer(11) 
- Leatherworker(7) 
- Purse Maker(7) 
- Shoe Maker(9) 
- Tailor(11) 
- Tanner(10) 
- Used Garment Trader(16) 
- Vestment Maker(9) 
- Chandler(19) 
- Dye Makers(19) 
- Oil Trader(19) 
- Cleric(14) 
- High Priest(6) 
- Missionary(51) 
- Preacher(31) 
- Priest(17) 
- Farmer(379) 
- Homestead(505) 
- Farmer - Cabbage(38) 
- Farmer - Cattle Herder(38) 
- Farmer - Corn(38) 
- Farmer - Cow Herder(38) 
- Farmer - Dairy(38) 
- Farmer - Goat Herder(38) 
- Farmer - Pig Herder(38) 
- Farmer - Potato(38) 
- Farmer - Sheep Herder(38) 
- Farmer - Wheat(38) 
- Farmer(Special)(38) 
- Dungsweeper(11) 
- Illuminator(8) 
- Messenger(12) 
- Tax Collector(2) 
- Town Crier(22) 
- Town Justice(6) 
- Undertaker(5) 
- Water Carrier(16) 
- Leatherworker(8) 
- Skinner(8) 
- Naval Outfitter(4) 
- Pirate(19) 
- Sail Maker(11) 
- Sailor(26) 
- Ship Builder(5) 
imports: 
- Star Ruby  
exports: 
- Salt  
defenses: Stone Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(13)  
> - Advocate(10)  
> - Alchemist(7)  
> - Animal Groomer(6)  
> - Animal Handler(13)  
> - Antiquities(13)  
> - Architect(16)  
> - Armor Dealer(13)  
> - Armorer(4)  
> - Artist(17)  
> - Astrologist(4)  
> - Baker(12)  
> - Banker(5)  
> - Barbarian(38)  
> - Barbarian(7)  
> - Barber(7)  
> - Baron(2)  
> - Barrel Maker(14)  
> - Barrel Maker(8)  
> - Basket Maker(11)  
> - Bather(6)  
> - Beer Merchant(7)  
> - Blacksmith(18)  
> - Bleacher(7)  
> - Book Binder(4)  
> - Bookseller(4)  
> - Bowyer-Fletcher(7)  
> - Bowyer-Fletcher(7)  
> - Brewer(1)  
> - Bricklayer(16)  
> - Brigand(13)  
> - Brigand(38)  
> - Brothel Keeper(6)  
> - Buckle Maker(11)  
> - Buckle Maker(6)  
> - Butcher(8)  
> - Candle Maker(5)  
> - Captain(38)  
> - Caravanner(10)  
> - Carpenter(22)  
> - Cartographer(7)  
> - Chandler(19)  
> - Chandler(19)  
> - Chicken Butcher(8)  
> - Cleric(14)  
> - Clerk(22)  
> - Clock Maker(4)  
> - Cobbler(12)  
> - Cobbler(9)  
> - Conjourer(4)  
> - Cook(8)  
> - Cooper(9)  
> - Council Member(19)  
> - Count(1)  
> - Crime Lord(4)  
> - Crook(16)  
> - Cutler(4)  
> - Dairy Seller(38)  
> - Diplomat(4)  
> - Distiller(7)  
> - Draper(7)  
> - Dungsweeper(11)  
> - Dye Makers(19)  
> - Dye Makers(19)  
> - Earl(1)  
> - Engineer(16)  
> - Engraver(4)  
> - Farmer - Cabbage(38)  
> - Farmer - Cattle Herder(38)  
> - Farmer - Corn(38)  
> - Farmer - Cow Herder(38)  
> - Farmer - Dairy(38)  
> - Farmer - Goat Herder(38)  
> - Farmer - Pig Herder(38)  
> - Farmer - Potato(38)  
> - Farmer - Sheep Herder(38)  
> - Farmer - Wheat(38)  
> - Farmer(379)  
> - Farmer(Special)(38)  
> - Fisherman(10)  
> - Fishmonger(10)  
> - Florist(7)  
> - Furniture Maker(12)  
> - Furrier(17)  
> - Girdler(6)  
> - Glassblower(13)  
> - Glassblower(6)  
> - Glazier(4)  
> - Glove Merchant(11)  
> - Goldsmith(6)  
> - Goldsmith(9)  
> - Goon(17)  
> - Grain Merchant(1)  
> - Grocer(6)  
> - Guide(13)  
> - Haberdasher(5)  
> - Harness Maker(13)  
> - Hat Maker(6)  
> - Hay Merchant(38)  
> - Herbalist(7)  
> - High Mage(4)  
> - High Priest(6)  
> - Historian(4)  
> - Homestead(505)  
> - Horse Trader(16)  
> - Huntsman(19)  
> - Illuminator(8)  
> - Innkeeper(11)  
> - Instrument Maker(4)  
> - Inventor(11)  
> - Jeweler(5)  
> - Jeweler(8)  
> - Judge(11)  
> - Kettle Maker(4)  
> - Knight(3)  
> - Laborer(16)  
> - Launderer(11)  
> - Launderer(13)  
> - Leatherworker(7)  
> - Leatherworker(8)  
> - Librarian(4)  
> - Livestock Merchant(11)  
> - Locksmith(5)  
> - Lord(3)  
> - Magical Artisan(4)  
> - Magical Artisan(4)  
> - Magical Tutor(4)  
> - Mason(16)  
> - Mayor(1)  
> - Meat Butcher(7)  
> - Messenger(12)  
> - Miller(19)  
> - Minstrel(13)  
> - Missionary(51)  
> - Mountainman(38)  
> - Mountainman(6)  
> - Naval Outfitter(4)  
> - Oil Trader(19)  
> - Oil Trader(19)  
> - Painter(Art)(14)  
> - Painter(Building)(16)  
> - Pastry Maker(10)  
> - Pathfinder(7)  
> - Pawnbroker(5)  
> - Perfumer(6)  
> - Physic/Chirurgeon(7)  
> - Pirate(19)  
> - Plasterer(16)  
> - Potionmakers(7)  
> - Potter(13)  
> - Preacher(31)  
> - Priest(17)  
> - Professor(4)  
> - Purse Maker(7)  
> - Roofer(16)  
> - Roofer(16)  
> - Rope Maker(9)  
> - Rug Maker(5)  
> - Saddler(10)  
> - Sage(4)  
> - Sail Maker(11)  
> - Sailor(26)  
> - Scout(7)  
> - Scribe(4)  
> - Sculptor(4)  
> - SellSpell(4)  
> - Ship Builder(5)  
> - Shoe Maker(9)  
> - Shoe Maker(9)  
> - Silversmith(11)  
> - Silversmith(5)  
> - Skinner(8)  
> - Slaver(13)  
> - Slaver(13)  
> - Soap Maker(7)  
> - Spice Merchant(13)  
> - Spice Merchant(13)  
> - Stabler(14)  
> - Storyteller(13)  
> - Tailor(11)  
> - Tanner(10)  
> - Tanner(10)  
> - Tavern Keeper(14)  
> - Tax Collector(2)  
> - Taxidermist(13)  
> - Taxidermist(13)  
> - Teacher(4)  
> - Teamster(16)  
> - Tiler(16)  
> - Tinker(19)  
> - Tinker(5)  
> - Tobacco Merchant(13)  
> - Tobacco Merchant(13)  
> - Town Crier(22)  
> - Town Justice(6)  
> - Toymaker(4)  
> - Toymaker(6)  
> - Trading Post(19)  
> - Troubadours(13)  
> - Tutor(4)  
> - Undertaker(5)  
> - Used Garment Trader(16)  
> - Vestment Maker(9)  
> - Vintner(8)  
> - Viscount(1)  
> - Wagon Maker(11)  
> - Warehouser(13)  
> - Water Carrier(16)  
> - Weapon Dealer(13)  
> - Weapon Dealer(13)  
> - Weaponsmith(4)  
> - Weaponsmith(4)  
> - Weaver(11)  
> - Wheelwright(12)  
> - Wheelwright(17)  
> - Wine Merchant(7)  
> - Wood Carver(7)  
> - Wood Seller(6)  
> - Wool Merchant(10)  
> - Writer(13)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC


> ###### Notable Points of Interest
> ```dataview
table without ID file.link AS Name, wardType AS "Type"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC


## Notable Characters

> ###### Notable Characters
> ```dataview
table without ID file.link AS Name, race as Race, PrimaryOccupation as Profession
where kingdom=this.kingdom and settlementName=this.settlementName  and (fileType="npc"  and importance > 5)
sort importance DESC


## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



