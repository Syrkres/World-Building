---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeTown
kingdom: KingdomName
region: RegionName
settlementName: Named LargeTown (3448)
terrain: Forest Boreal 
settlementDescription: 
population: 3448
culture: Barbarian 
technology: Savage 
leader: 
govermentType: Theocracy 
demographics: 
- Acrobat(6) 
- Minstrel(6) 
- Storyteller(6) 
- Troubadours(6) 
- Writer(6) 
- Advocate(5) 
- Clerk(10) 
- Council Member(9) 
- Diplomat(2) 
- Judge(5) 
- Mayor(1) 
- Alchemist(3) 
- Chandler(9) 
- Dye Makers(9) 
- Florist(3) 
- Herbalist(3) 
- Potionmakers(3) 
- Sage(1) 
- Spice Merchant(6) 
- Taxidermist(6) 
- Tobacco Merchant(6) 
- Animal Groomer(3) 
- Animal Handler(6) 
- Caravanner(5) 
- Horse Trader(7) 
- Livestock Merchant(5) 
- Stabler(7) 
- Antiquities(6) 
- Armor Dealer(6) 
- Launderer(6) 
- Oil Trader(9) 
- Trading Post(9) 
- Slaver(6) 
- Spice Merchant(6) 
- Taxidermist(6) 
- Tobacco Merchant(6) 
- Warehouser(6) 
- Weapon Dealer(6) 
- Architect(7) 
- Bricklayer(7) 
- Engineer(7) 
- Laborer(7) 
- Mason(7) 
- Painter(Building)(7) 
- Plasterer(7) 
- Roofer(7) 
- Teamster(7) 
- Tiler(7) 
- Armorer(2) 
- Blacksmith(9) 
- Bowyer-Fletcher(3) 
- Jeweler(3) 
- Silversmith(3) 
- Weapon Dealer(6) 
- Weaponsmith(1) 
- Artist(8) 
- Glassblower(6) 
- Goldsmith(4) 
- Inventor(5) 
- Jeweler(4) 
- Magical Artisan(1) 
- Painter(Art)(7) 
- Silversmith(5) 
- Tinker(9) 
- Toymaker(3) 
- Astrologist(1) 
- Conjourer(1) 
- High Mage(1) 
- Historian(1) 
- Librarian(1) 
- Magical Artisan(1) 
- Magical Tutor(1) 
- Professor(1) 
- Scribe(1) 
- SellSpell(1) 
- Teacher(1) 
- Tutor(1) 
- Baker(6) 
- Beer Merchant(4) 
- Butcher(4) 
- Chicken Butcher(4) 
- Cook(4) 
- Dairy Seller(18) 
- Distiller(4) 
- Hay Merchant(18) 
- Fisherman(5) 
- Fishmonger(5) 
- Grocer(3) 
- Meat Butcher(3) 
- Miller(9) 
- Pastry Maker(5) 
- Vintner(4) 
- Banker(1) 
- Pawnbroker(1) 
- Barbarian(18) 
- Brigand(18) 
- Captain(18) 
- Mountainman(18) 
- Barbarian(4) 
- Cartographer(3) 
- Guide(6) 
- Huntsman(9) 
- Mountainman(3) 
- Pathfinder(3) 
- Scout(3) 
- Slaver(6) 
- Barrel Maker(4) 
- Basket Maker(5) 
- Book Binder(2) 
- Bookseller(1) 
- Buckle Maker(3) 
- Candle Maker(3) 
- Clock Maker(1) 
- Cobbler(6) 
- Cooper(5) 
- Cutler(2) 
- Engraver(2) 
- Furniture Maker(6) 
- Glassblower(3) 
- Glazier(2) 
- Glove Merchant(5) 
- Goldsmith(3) 
- Harness Maker(6) 
- Hat Maker(3) 
- Instrument Maker(1) 
- Kettle Maker(1) 
- Locksmith(3) 
- Perfumer(3) 
- Potter(6) 
- Rope Maker(5) 
- Rug Maker(3) 
- Saddler(5) 
- Sculptor(2) 
- Shoe Maker(5) 
- Soap Maker(3) 
- Tanner(5) 
- Tinker(2) 
- Toymaker(1) 
- Weaponsmith(1) 
- Weaver(5) 
- Wheelwright(8) 
- Wine Merchant(3) 
- Wool Merchant(5) 
- Lord(2) 
- Knight(2) 
- Baron(1) 
- Barrel Maker(7) 
- Bowyer-Fletcher(3) 
- Carpenter(10) 
- Roofer(7) 
- Wagon Maker(5) 
- Wheelwright(6) 
- Wood Carver(3) 
- Wood Seller(3) 
- Barber(3) 
- Bleacher(3) 
- Physic/Chirurgeon(3) 
- Bather(3) 
- Brigand(6) 
- Crime Lord(1) 
- Crook(7) 
- Goon(8) 
- Brothel Keeper(3) 
- Innkeeper(5) 
- Tavern Keeper(7) 
- Buckle Maker(5) 
- Cobbler(5) 
- Draper(3) 
- Furrier(8) 
- Girdler(3) 
- Haberdasher(3) 
- Launderer(5) 
- Leatherworker(4) 
- Purse Maker(3) 
- Shoe Maker(5) 
- Tailor(5) 
- Tanner(5) 
- Used Garment Trader(8) 
- Vestment Maker(5) 
- Chandler(9) 
- Dye Makers(9) 
- Oil Trader(9) 
- Cleric(7) 
- High Priest(3) 
- Missionary(23) 
- Preacher(14) 
- Priest(8) 
- Farmer(173) 
- Homestead(230) 
- Farmer - Cabbage(18) 
- Farmer - Cattle Herder(18) 
- Farmer - Corn(18) 
- Farmer - Cow Herder(18) 
- Farmer - Dairy(18) 
- Farmer - Goat Herder(18) 
- Farmer - Pig Herder(18) 
- Farmer - Potato(18) 
- Farmer - Sheep Herder(18) 
- Farmer - Wheat(18) 
- Farmer(Special)(18) 
- Dungsweeper(5) 
- Illuminator(4) 
- Messenger(6) 
- Tax Collector(1) 
- Town Crier(10) 
- Town Justice(3) 
- Undertaker(2) 
- Water Carrier(7) 
- Leatherworker(4) 
- Skinner(4) 
- Naval Outfitter(2) 
- Pirate(9) 
- Sail Maker(5) 
- Sailor(12) 
- Ship Builder(3) 
imports: 
- Mead  
exports: 
- Perls  
defenses: Keeps 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(6)  
> - Advocate(5)  
> - Alchemist(3)  
> - Animal Groomer(3)  
> - Animal Handler(6)  
> - Antiquities(6)  
> - Architect(7)  
> - Armor Dealer(6)  
> - Armorer(2)  
> - Artist(8)  
> - Astrologist(1)  
> - Baker(6)  
> - Banker(1)  
> - Barbarian(18)  
> - Barbarian(4)  
> - Barber(3)  
> - Baron(1)  
> - Barrel Maker(4)  
> - Barrel Maker(7)  
> - Basket Maker(5)  
> - Bather(3)  
> - Beer Merchant(4)  
> - Blacksmith(9)  
> - Bleacher(3)  
> - Book Binder(2)  
> - Bookseller(1)  
> - Bowyer-Fletcher(3)  
> - Bowyer-Fletcher(3)  
> - Bricklayer(7)  
> - Brigand(18)  
> - Brigand(6)  
> - Brothel Keeper(3)  
> - Buckle Maker(3)  
> - Buckle Maker(5)  
> - Butcher(4)  
> - Candle Maker(3)  
> - Captain(18)  
> - Caravanner(5)  
> - Carpenter(10)  
> - Cartographer(3)  
> - Chandler(9)  
> - Chandler(9)  
> - Chicken Butcher(4)  
> - Cleric(7)  
> - Clerk(10)  
> - Clock Maker(1)  
> - Cobbler(5)  
> - Cobbler(6)  
> - Conjourer(1)  
> - Cook(4)  
> - Cooper(5)  
> - Council Member(9)  
> - Crime Lord(1)  
> - Crook(7)  
> - Cutler(2)  
> - Dairy Seller(18)  
> - Diplomat(2)  
> - Distiller(4)  
> - Draper(3)  
> - Dungsweeper(5)  
> - Dye Makers(9)  
> - Dye Makers(9)  
> - Engineer(7)  
> - Engraver(2)  
> - Farmer - Cabbage(18)  
> - Farmer - Cattle Herder(18)  
> - Farmer - Corn(18)  
> - Farmer - Cow Herder(18)  
> - Farmer - Dairy(18)  
> - Farmer - Goat Herder(18)  
> - Farmer - Pig Herder(18)  
> - Farmer - Potato(18)  
> - Farmer - Sheep Herder(18)  
> - Farmer - Wheat(18)  
> - Farmer(173)  
> - Farmer(Special)(18)  
> - Fisherman(5)  
> - Fishmonger(5)  
> - Florist(3)  
> - Furniture Maker(6)  
> - Furrier(8)  
> - Girdler(3)  
> - Glassblower(3)  
> - Glassblower(6)  
> - Glazier(2)  
> - Glove Merchant(5)  
> - Goldsmith(3)  
> - Goldsmith(4)  
> - Goon(8)  
> - Grocer(3)  
> - Guide(6)  
> - Haberdasher(3)  
> - Harness Maker(6)  
> - Hat Maker(3)  
> - Hay Merchant(18)  
> - Herbalist(3)  
> - High Mage(1)  
> - High Priest(3)  
> - Historian(1)  
> - Homestead(230)  
> - Horse Trader(7)  
> - Huntsman(9)  
> - Illuminator(4)  
> - Innkeeper(5)  
> - Instrument Maker(1)  
> - Inventor(5)  
> - Jeweler(3)  
> - Jeweler(4)  
> - Judge(5)  
> - Kettle Maker(1)  
> - Knight(2)  
> - Laborer(7)  
> - Launderer(5)  
> - Launderer(6)  
> - Leatherworker(4)  
> - Leatherworker(4)  
> - Librarian(1)  
> - Livestock Merchant(5)  
> - Locksmith(3)  
> - Lord(2)  
> - Magical Artisan(1)  
> - Magical Artisan(1)  
> - Magical Tutor(1)  
> - Mason(7)  
> - Mayor(1)  
> - Meat Butcher(3)  
> - Messenger(6)  
> - Miller(9)  
> - Minstrel(6)  
> - Missionary(23)  
> - Mountainman(18)  
> - Mountainman(3)  
> - Naval Outfitter(2)  
> - Oil Trader(9)  
> - Oil Trader(9)  
> - Painter(Art)(7)  
> - Painter(Building)(7)  
> - Pastry Maker(5)  
> - Pathfinder(3)  
> - Pawnbroker(1)  
> - Perfumer(3)  
> - Physic/Chirurgeon(3)  
> - Pirate(9)  
> - Plasterer(7)  
> - Potionmakers(3)  
> - Potter(6)  
> - Preacher(14)  
> - Priest(8)  
> - Professor(1)  
> - Purse Maker(3)  
> - Roofer(7)  
> - Roofer(7)  
> - Rope Maker(5)  
> - Rug Maker(3)  
> - Saddler(5)  
> - Sage(1)  
> - Sail Maker(5)  
> - Sailor(12)  
> - Scout(3)  
> - Scribe(1)  
> - Sculptor(2)  
> - SellSpell(1)  
> - Ship Builder(3)  
> - Shoe Maker(5)  
> - Shoe Maker(5)  
> - Silversmith(3)  
> - Silversmith(5)  
> - Skinner(4)  
> - Slaver(6)  
> - Slaver(6)  
> - Soap Maker(3)  
> - Spice Merchant(6)  
> - Spice Merchant(6)  
> - Stabler(7)  
> - Storyteller(6)  
> - Tailor(5)  
> - Tanner(5)  
> - Tanner(5)  
> - Tavern Keeper(7)  
> - Tax Collector(1)  
> - Taxidermist(6)  
> - Taxidermist(6)  
> - Teacher(1)  
> - Teamster(7)  
> - Tiler(7)  
> - Tinker(2)  
> - Tinker(9)  
> - Tobacco Merchant(6)  
> - Tobacco Merchant(6)  
> - Town Crier(10)  
> - Town Justice(3)  
> - Toymaker(1)  
> - Toymaker(3)  
> - Trading Post(9)  
> - Troubadours(6)  
> - Tutor(1)  
> - Undertaker(2)  
> - Used Garment Trader(8)  
> - Vestment Maker(5)  
> - Vintner(4)  
> - Wagon Maker(5)  
> - Warehouser(6)  
> - Water Carrier(7)  
> - Weapon Dealer(6)  
> - Weapon Dealer(6)  
> - Weaponsmith(1)  
> - Weaponsmith(1)  
> - Weaver(5)  
> - Wheelwright(6)  
> - Wheelwright(8)  
> - Wine Merchant(3)  
> - Wood Carver(3)  
> - Wood Seller(3)  
> - Wool Merchant(5)  
> - Writer(6)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC


> ###### Notable Points of Interest
> ```dataview
table without ID file.link AS Name, wardType AS "Type"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC


## Notable Characters

> ###### Notable Characters
> ```dataview
table without ID file.link AS Name, race as Race, PrimaryOccupation as Profession
where kingdom=this.kingdom and settlementName=this.settlementName  and (fileType="npc"  and importance > 5)
sort importance DESC


## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



