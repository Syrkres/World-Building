---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeTown
kingdom: KingdomName
region: RegionName
settlementName: Named LargeTown (2814)
terrain: Forest Heavy Boreal 
settlementDescription: 
population: 2814
culture: Indian 
technology: Crusades 
leader: 
govermentType: Confederation 
demographics: 
- Acrobat(5) 
- Minstrel(5) 
- Storyteller(5) 
- Troubadours(5) 
- Writer(5) 
- Advocate(4) 
- Clerk(9) 
- Council Member(8) 
- Diplomat(2) 
- Judge(5) 
- Mayor(1) 
- Alchemist(3) 
- Chandler(8) 
- Dye Makers(8) 
- Florist(3) 
- Herbalist(3) 
- Potionmakers(3) 
- Sage(1) 
- Spice Merchant(5) 
- Taxidermist(5) 
- Tobacco Merchant(5) 
- Animal Groomer(2) 
- Animal Handler(5) 
- Caravanner(4) 
- Horse Trader(6) 
- Livestock Merchant(4) 
- Stabler(6) 
- Antiquities(5) 
- Armor Dealer(5) 
- Launderer(5) 
- Oil Trader(8) 
- Trading Post(8) 
- Slaver(5) 
- Spice Merchant(5) 
- Taxidermist(5) 
- Tobacco Merchant(5) 
- Warehouser(5) 
- Weapon Dealer(5) 
- Architect(6) 
- Bricklayer(6) 
- Engineer(6) 
- Laborer(6) 
- Mason(6) 
- Painter(Building)(6) 
- Plasterer(6) 
- Roofer(6) 
- Teamster(6) 
- Tiler(6) 
- Armorer(2) 
- Blacksmith(7) 
- Bowyer-Fletcher(3) 
- Jeweler(2) 
- Silversmith(2) 
- Weapon Dealer(5) 
- Weaponsmith(1) 
- Artist(7) 
- Glassblower(5) 
- Goldsmith(4) 
- Inventor(5) 
- Jeweler(3) 
- Magical Artisan(1) 
- Painter(Art)(6) 
- Silversmith(5) 
- Tinker(8) 
- Toymaker(3) 
- Astrologist(1) 
- Conjourer(1) 
- High Mage(1) 
- Historian(1) 
- Librarian(1) 
- Magical Artisan(1) 
- Magical Tutor(1) 
- Professor(1) 
- Scribe(1) 
- SellSpell(1) 
- Teacher(1) 
- Tutor(1) 
- Baker(5) 
- Beer Merchant(3) 
- Butcher(3) 
- Chicken Butcher(3) 
- Cook(3) 
- Dairy Seller(15) 
- Distiller(3) 
- Hay Merchant(15) 
- Fisherman(4) 
- Fishmonger(4) 
- Grocer(3) 
- Meat Butcher(3) 
- Miller(8) 
- Pastry Maker(4) 
- Vintner(3) 
- Banker(1) 
- Pawnbroker(1) 
- Barbarian(15) 
- Brigand(15) 
- Captain(15) 
- Mountainman(15) 
- Barbarian(3) 
- Cartographer(3) 
- Guide(5) 
- Huntsman(8) 
- Mountainman(3) 
- Pathfinder(3) 
- Scout(3) 
- Slaver(5) 
- Barrel Maker(3) 
- Basket Maker(5) 
- Book Binder(1) 
- Bookseller(1) 
- Buckle Maker(3) 
- Candle Maker(2) 
- Clock Maker(1) 
- Cobbler(5) 
- Cooper(4) 
- Cutler(2) 
- Engraver(1) 
- Furniture Maker(5) 
- Glassblower(3) 
- Glazier(2) 
- Glove Merchant(4) 
- Goldsmith(3) 
- Harness Maker(5) 
- Hat Maker(2) 
- Instrument Maker(1) 
- Kettle Maker(1) 
- Locksmith(1) 
- Perfumer(1) 
- Potter(5) 
- Rope Maker(4) 
- Rug Maker(2) 
- Saddler(4) 
- Sculptor(2) 
- Shoe Maker(4) 
- Soap Maker(3) 
- Tanner(4) 
- Tinker(2) 
- Toymaker(1) 
- Weaponsmith(1) 
- Weaver(5) 
- Wheelwright(7) 
- Wine Merchant(3) 
- Wool Merchant(4) 
- Lord(1) 
- Knight(1) 
- Barrel Maker(6) 
- Bowyer-Fletcher(3) 
- Carpenter(9) 
- Roofer(6) 
- Wagon Maker(5) 
- Wheelwright(5) 
- Wood Carver(3) 
- Wood Seller(3) 
- Barber(3) 
- Bleacher(3) 
- Physic/Chirurgeon(3) 
- Bather(2) 
- Brigand(5) 
- Crime Lord(1) 
- Crook(6) 
- Goon(7) 
- Brothel Keeper(2) 
- Innkeeper(4) 
- Tavern Keeper(6) 
- Buckle Maker(4) 
- Cobbler(4) 
- Draper(3) 
- Furrier(7) 
- Girdler(3) 
- Haberdasher(2) 
- Launderer(4) 
- Leatherworker(3) 
- Purse Maker(3) 
- Shoe Maker(4) 
- Tailor(4) 
- Tanner(4) 
- Used Garment Trader(6) 
- Vestment Maker(4) 
- Chandler(8) 
- Dye Makers(8) 
- Oil Trader(8) 
- Cleric(6) 
- High Priest(2) 
- Missionary(19) 
- Preacher(12) 
- Priest(7) 
- Farmer(141) 
- Homestead(188) 
- Farmer - Cabbage(15) 
- Farmer - Cattle Herder(15) 
- Farmer - Corn(15) 
- Farmer - Cow Herder(15) 
- Farmer - Dairy(15) 
- Farmer - Goat Herder(15) 
- Farmer - Pig Herder(15) 
- Farmer - Potato(15) 
- Farmer - Sheep Herder(15) 
- Farmer - Wheat(15) 
- Farmer(Special)(15) 
- Dungsweeper(4) 
- Illuminator(3) 
- Messenger(5) 
- Town Crier(9) 
- Town Justice(2) 
- Undertaker(2) 
- Water Carrier(6) 
- Leatherworker(3) 
- Skinner(3) 
- Naval Outfitter(1) 
- Pirate(8) 
- Sail Maker(5) 
- Sailor(10) 
- Ship Builder(1) 
imports: 
- Granite  
exports: 
- Iron  
defenses: Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(5)  
> - Advocate(4)  
> - Alchemist(3)  
> - Animal Groomer(2)  
> - Animal Handler(5)  
> - Antiquities(5)  
> - Architect(6)  
> - Armor Dealer(5)  
> - Armorer(2)  
> - Artist(7)  
> - Astrologist(1)  
> - Baker(5)  
> - Banker(1)  
> - Barbarian(15)  
> - Barbarian(3)  
> - Barber(3)  
> - Barrel Maker(3)  
> - Barrel Maker(6)  
> - Basket Maker(5)  
> - Bather(2)  
> - Beer Merchant(3)  
> - Blacksmith(7)  
> - Bleacher(3)  
> - Book Binder(1)  
> - Bookseller(1)  
> - Bowyer-Fletcher(3)  
> - Bowyer-Fletcher(3)  
> - Bricklayer(6)  
> - Brigand(15)  
> - Brigand(5)  
> - Brothel Keeper(2)  
> - Buckle Maker(3)  
> - Buckle Maker(4)  
> - Butcher(3)  
> - Candle Maker(2)  
> - Captain(15)  
> - Caravanner(4)  
> - Carpenter(9)  
> - Cartographer(3)  
> - Chandler(8)  
> - Chandler(8)  
> - Chicken Butcher(3)  
> - Cleric(6)  
> - Clerk(9)  
> - Clock Maker(1)  
> - Cobbler(4)  
> - Cobbler(5)  
> - Conjourer(1)  
> - Cook(3)  
> - Cooper(4)  
> - Council Member(8)  
> - Crime Lord(1)  
> - Crook(6)  
> - Cutler(2)  
> - Dairy Seller(15)  
> - Diplomat(2)  
> - Distiller(3)  
> - Draper(3)  
> - Dungsweeper(4)  
> - Dye Makers(8)  
> - Dye Makers(8)  
> - Engineer(6)  
> - Engraver(1)  
> - Farmer - Cabbage(15)  
> - Farmer - Cattle Herder(15)  
> - Farmer - Corn(15)  
> - Farmer - Cow Herder(15)  
> - Farmer - Dairy(15)  
> - Farmer - Goat Herder(15)  
> - Farmer - Pig Herder(15)  
> - Farmer - Potato(15)  
> - Farmer - Sheep Herder(15)  
> - Farmer - Wheat(15)  
> - Farmer(141)  
> - Farmer(Special)(15)  
> - Fisherman(4)  
> - Fishmonger(4)  
> - Florist(3)  
> - Furniture Maker(5)  
> - Furrier(7)  
> - Girdler(3)  
> - Glassblower(3)  
> - Glassblower(5)  
> - Glazier(2)  
> - Glove Merchant(4)  
> - Goldsmith(3)  
> - Goldsmith(4)  
> - Goon(7)  
> - Grocer(3)  
> - Guide(5)  
> - Haberdasher(2)  
> - Harness Maker(5)  
> - Hat Maker(2)  
> - Hay Merchant(15)  
> - Herbalist(3)  
> - High Mage(1)  
> - High Priest(2)  
> - Historian(1)  
> - Homestead(188)  
> - Horse Trader(6)  
> - Huntsman(8)  
> - Illuminator(3)  
> - Innkeeper(4)  
> - Instrument Maker(1)  
> - Inventor(5)  
> - Jeweler(2)  
> - Jeweler(3)  
> - Judge(5)  
> - Kettle Maker(1)  
> - Knight(1)  
> - Laborer(6)  
> - Launderer(4)  
> - Launderer(5)  
> - Leatherworker(3)  
> - Leatherworker(3)  
> - Librarian(1)  
> - Livestock Merchant(4)  
> - Locksmith(1)  
> - Lord(1)  
> - Magical Artisan(1)  
> - Magical Artisan(1)  
> - Magical Tutor(1)  
> - Mason(6)  
> - Mayor(1)  
> - Meat Butcher(3)  
> - Messenger(5)  
> - Miller(8)  
> - Minstrel(5)  
> - Missionary(19)  
> - Mountainman(15)  
> - Mountainman(3)  
> - Naval Outfitter(1)  
> - Oil Trader(8)  
> - Oil Trader(8)  
> - Painter(Art)(6)  
> - Painter(Building)(6)  
> - Pastry Maker(4)  
> - Pathfinder(3)  
> - Pawnbroker(1)  
> - Perfumer(1)  
> - Physic/Chirurgeon(3)  
> - Pirate(8)  
> - Plasterer(6)  
> - Potionmakers(3)  
> - Potter(5)  
> - Preacher(12)  
> - Priest(7)  
> - Professor(1)  
> - Purse Maker(3)  
> - Roofer(6)  
> - Roofer(6)  
> - Rope Maker(4)  
> - Rug Maker(2)  
> - Saddler(4)  
> - Sage(1)  
> - Sail Maker(5)  
> - Sailor(10)  
> - Scout(3)  
> - Scribe(1)  
> - Sculptor(2)  
> - SellSpell(1)  
> - Ship Builder(1)  
> - Shoe Maker(4)  
> - Shoe Maker(4)  
> - Silversmith(2)  
> - Silversmith(5)  
> - Skinner(3)  
> - Slaver(5)  
> - Slaver(5)  
> - Soap Maker(3)  
> - Spice Merchant(5)  
> - Spice Merchant(5)  
> - Stabler(6)  
> - Storyteller(5)  
> - Tailor(4)  
> - Tanner(4)  
> - Tanner(4)  
> - Tavern Keeper(6)  
> - Taxidermist(5)  
> - Taxidermist(5)  
> - Teacher(1)  
> - Teamster(6)  
> - Tiler(6)  
> - Tinker(2)  
> - Tinker(8)  
> - Tobacco Merchant(5)  
> - Tobacco Merchant(5)  
> - Town Crier(9)  
> - Town Justice(2)  
> - Toymaker(1)  
> - Toymaker(3)  
> - Trading Post(8)  
> - Troubadours(5)  
> - Tutor(1)  
> - Undertaker(2)  
> - Used Garment Trader(6)  
> - Vestment Maker(4)  
> - Vintner(3)  
> - Wagon Maker(5)  
> - Warehouser(5)  
> - Water Carrier(6)  
> - Weapon Dealer(5)  
> - Weapon Dealer(5)  
> - Weaponsmith(1)  
> - Weaponsmith(1)  
> - Weaver(5)  
> - Wheelwright(5)  
> - Wheelwright(7)  
> - Wine Merchant(3)  
> - Wood Carver(3)  
> - Wood Seller(3)  
> - Wool Merchant(4)  
> - Writer(5)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC


> ###### Notable Points of Interest
> ```dataview
table without ID file.link AS Name, wardType AS "Type"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC


## Notable Characters

> ###### Notable Characters
> ```dataview
table without ID file.link AS Name, race as Race, PrimaryOccupation as Profession
where kingdom=this.kingdom and settlementName=this.settlementName  and (fileType="npc"  and importance > 5)
sort importance DESC


## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



