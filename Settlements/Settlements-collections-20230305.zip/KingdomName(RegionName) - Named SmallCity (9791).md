---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallCity
kingdom: KingdomName
region: RegionName
settlementName: Named SmallCity (9791)
terrain: Savannah Forest 
settlementDescription: 
population: 9791
culture: Aztec 
technology: Bronze Age 
leader: 
govermentType: Republic 
demographics: 
- Acrobat(17) 
- Minstrel(17) 
- Storyteller(17) 
- Troubadours(17) 
- Writer(17) 
- Advocate(13) 
- Clerk(28) 
- Council Member(25) 
- Diplomat(4) 
- Judge(14) 
- Mayor(1) 
- Alchemist(9) 
- Chandler(25) 
- Dye Makers(25) 
- Florist(9) 
- Herbalist(9) 
- Potionmakers(9) 
- Sage(5) 
- Spice Merchant(17) 
- Taxidermist(17) 
- Tobacco Merchant(17) 
- Animal Groomer(7) 
- Animal Handler(17) 
- Caravanner(13) 
- Horse Trader(20) 
- Livestock Merchant(14) 
- Stabler(18) 
- Antiquities(17) 
- Armor Dealer(17) 
- Launderer(17) 
- Oil Trader(25) 
- Trading Post(25) 
- Slaver(17) 
- Spice Merchant(17) 
- Taxidermist(17) 
- Tobacco Merchant(17) 
- Warehouser(17) 
- Weapon Dealer(17) 
- Architect(20) 
- Bricklayer(20) 
- Engineer(20) 
- Laborer(20) 
- Mason(20) 
- Painter(Building)(20) 
- Plasterer(20) 
- Roofer(20) 
- Teamster(20) 
- Tiler(20) 
- Armorer(6) 
- Blacksmith(24) 
- Bowyer-Fletcher(8) 
- Jeweler(7) 
- Silversmith(6) 
- Weapon Dealer(17) 
- Weaponsmith(5) 
- Artist(22) 
- Glassblower(17) 
- Goldsmith(11) 
- Inventor(14) 
- Jeweler(10) 
- Magical Artisan(5) 
- Painter(Art)(18) 
- Silversmith(14) 
- Tinker(25) 
- Toymaker(8) 
- Astrologist(5) 
- Conjourer(5) 
- High Mage(5) 
- Historian(5) 
- Librarian(5) 
- Magical Artisan(5) 
- Magical Tutor(5) 
- Professor(5) 
- Scribe(5) 
- SellSpell(5) 
- Teacher(5) 
- Tutor(5) 
- Baker(16) 
- Beer Merchant(9) 
- Brewer(3) 
- Butcher(10) 
- Chicken Butcher(10) 
- Cook(11) 
- Dairy Seller(49) 
- Distiller(9) 
- Hay Merchant(49) 
- Fisherman(13) 
- Fishmonger(13) 
- Grain Merchant(3) 
- Grocer(8) 
- Meat Butcher(9) 
- Miller(25) 
- Pastry Maker(13) 
- Vintner(11) 
- Banker(6) 
- Pawnbroker(6) 
- Barbarian(49) 
- Brigand(49) 
- Captain(49) 
- Mountainman(49) 
- Barbarian(9) 
- Cartographer(9) 
- Guide(17) 
- Huntsman(25) 
- Mountainman(8) 
- Pathfinder(9) 
- Scout(9) 
- Slaver(17) 
- Barrel Maker(11) 
- Basket Maker(14) 
- Book Binder(5) 
- Bookseller(5) 
- Buckle Maker(8) 
- Candle Maker(7) 
- Clock Maker(5) 
- Cobbler(16) 
- Cooper(12) 
- Cutler(5) 
- Engraver(5) 
- Furniture Maker(16) 
- Glassblower(7) 
- Glazier(5) 
- Glove Merchant(14) 
- Goldsmith(7) 
- Harness Maker(17) 
- Hat Maker(7) 
- Instrument Maker(5) 
- Kettle Maker(5) 
- Locksmith(6) 
- Perfumer(7) 
- Potter(17) 
- Rope Maker(12) 
- Rug Maker(6) 
- Saddler(13) 
- Sculptor(5) 
- Shoe Maker(12) 
- Soap Maker(9) 
- Tanner(13) 
- Tinker(6) 
- Toymaker(5) 
- Weaponsmith(5) 
- Weaver(14) 
- Wheelwright(22) 
- Wine Merchant(9) 
- Wool Merchant(13) 
- Lord(4) 
- Knight(4) 
- Baron(2) 
- Viscount(1) 
- Earl(1) 
- Count(1) 
- Barrel Maker(18) 
- Bowyer-Fletcher(8) 
- Carpenter(28) 
- Roofer(20) 
- Wagon Maker(14) 
- Wheelwright(16) 
- Wood Carver(8) 
- Wood Seller(8) 
- Barber(9) 
- Bleacher(9) 
- Physic/Chirurgeon(9) 
- Bather(7) 
- Brigand(17) 
- Crime Lord(4) 
- Crook(20) 
- Goon(22) 
- Brothel Keeper(7) 
- Innkeeper(14) 
- Tavern Keeper(18) 
- Buckle Maker(14) 
- Cobbler(12) 
- Draper(9) 
- Furrier(22) 
- Girdler(8) 
- Haberdasher(7) 
- Launderer(14) 
- Leatherworker(9) 
- Purse Maker(9) 
- Shoe Maker(12) 
- Tailor(14) 
- Tanner(13) 
- Used Garment Trader(21) 
- Vestment Maker(12) 
- Chandler(25) 
- Dye Makers(25) 
- Oil Trader(25) 
- Cleric(18) 
- High Priest(7) 
- Missionary(66) 
- Preacher(40) 
- Priest(22) 
- Farmer(490) 
- Homestead(653) 
- Farmer - Cabbage(49) 
- Farmer - Cattle Herder(49) 
- Farmer - Corn(49) 
- Farmer - Cow Herder(49) 
- Farmer - Dairy(49) 
- Farmer - Goat Herder(49) 
- Farmer - Pig Herder(49) 
- Farmer - Potato(49) 
- Farmer - Sheep Herder(49) 
- Farmer - Wheat(49) 
- Farmer(Special)(49) 
- Dungsweeper(14) 
- Illuminator(10) 
- Messenger(16) 
- Tax Collector(3) 
- Town Crier(28) 
- Town Justice(7) 
- Undertaker(6) 
- Water Carrier(20) 
- Leatherworker(10) 
- Skinner(10) 
- Naval Outfitter(6) 
- Pirate(25) 
- Sail Maker(14) 
- Sailor(33) 
- Ship Builder(6) 
imports: 
- Mead  
exports: 
- Dyes  
defenses: Baileys 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(17)  
> - Advocate(13)  
> - Alchemist(9)  
> - Animal Groomer(7)  
> - Animal Handler(17)  
> - Antiquities(17)  
> - Architect(20)  
> - Armor Dealer(17)  
> - Armorer(6)  
> - Artist(22)  
> - Astrologist(5)  
> - Baker(16)  
> - Banker(6)  
> - Barbarian(49)  
> - Barbarian(9)  
> - Barber(9)  
> - Baron(2)  
> - Barrel Maker(11)  
> - Barrel Maker(18)  
> - Basket Maker(14)  
> - Bather(7)  
> - Beer Merchant(9)  
> - Blacksmith(24)  
> - Bleacher(9)  
> - Book Binder(5)  
> - Bookseller(5)  
> - Bowyer-Fletcher(8)  
> - Bowyer-Fletcher(8)  
> - Brewer(3)  
> - Bricklayer(20)  
> - Brigand(17)  
> - Brigand(49)  
> - Brothel Keeper(7)  
> - Buckle Maker(14)  
> - Buckle Maker(8)  
> - Butcher(10)  
> - Candle Maker(7)  
> - Captain(49)  
> - Caravanner(13)  
> - Carpenter(28)  
> - Cartographer(9)  
> - Chandler(25)  
> - Chandler(25)  
> - Chicken Butcher(10)  
> - Cleric(18)  
> - Clerk(28)  
> - Clock Maker(5)  
> - Cobbler(12)  
> - Cobbler(16)  
> - Conjourer(5)  
> - Cook(11)  
> - Cooper(12)  
> - Council Member(25)  
> - Count(1)  
> - Crime Lord(4)  
> - Crook(20)  
> - Cutler(5)  
> - Dairy Seller(49)  
> - Diplomat(4)  
> - Distiller(9)  
> - Draper(9)  
> - Dungsweeper(14)  
> - Dye Makers(25)  
> - Dye Makers(25)  
> - Earl(1)  
> - Engineer(20)  
> - Engraver(5)  
> - Farmer - Cabbage(49)  
> - Farmer - Cattle Herder(49)  
> - Farmer - Corn(49)  
> - Farmer - Cow Herder(49)  
> - Farmer - Dairy(49)  
> - Farmer - Goat Herder(49)  
> - Farmer - Pig Herder(49)  
> - Farmer - Potato(49)  
> - Farmer - Sheep Herder(49)  
> - Farmer - Wheat(49)  
> - Farmer(490)  
> - Farmer(Special)(49)  
> - Fisherman(13)  
> - Fishmonger(13)  
> - Florist(9)  
> - Furniture Maker(16)  
> - Furrier(22)  
> - Girdler(8)  
> - Glassblower(17)  
> - Glassblower(7)  
> - Glazier(5)  
> - Glove Merchant(14)  
> - Goldsmith(11)  
> - Goldsmith(7)  
> - Goon(22)  
> - Grain Merchant(3)  
> - Grocer(8)  
> - Guide(17)  
> - Haberdasher(7)  
> - Harness Maker(17)  
> - Hat Maker(7)  
> - Hay Merchant(49)  
> - Herbalist(9)  
> - High Mage(5)  
> - High Priest(7)  
> - Historian(5)  
> - Homestead(653)  
> - Horse Trader(20)  
> - Huntsman(25)  
> - Illuminator(10)  
> - Innkeeper(14)  
> - Instrument Maker(5)  
> - Inventor(14)  
> - Jeweler(10)  
> - Jeweler(7)  
> - Judge(14)  
> - Kettle Maker(5)  
> - Knight(4)  
> - Laborer(20)  
> - Launderer(14)  
> - Launderer(17)  
> - Leatherworker(10)  
> - Leatherworker(9)  
> - Librarian(5)  
> - Livestock Merchant(14)  
> - Locksmith(6)  
> - Lord(4)  
> - Magical Artisan(5)  
> - Magical Artisan(5)  
> - Magical Tutor(5)  
> - Mason(20)  
> - Mayor(1)  
> - Meat Butcher(9)  
> - Messenger(16)  
> - Miller(25)  
> - Minstrel(17)  
> - Missionary(66)  
> - Mountainman(49)  
> - Mountainman(8)  
> - Naval Outfitter(6)  
> - Oil Trader(25)  
> - Oil Trader(25)  
> - Painter(Art)(18)  
> - Painter(Building)(20)  
> - Pastry Maker(13)  
> - Pathfinder(9)  
> - Pawnbroker(6)  
> - Perfumer(7)  
> - Physic/Chirurgeon(9)  
> - Pirate(25)  
> - Plasterer(20)  
> - Potionmakers(9)  
> - Potter(17)  
> - Preacher(40)  
> - Priest(22)  
> - Professor(5)  
> - Purse Maker(9)  
> - Roofer(20)  
> - Roofer(20)  
> - Rope Maker(12)  
> - Rug Maker(6)  
> - Saddler(13)  
> - Sage(5)  
> - Sail Maker(14)  
> - Sailor(33)  
> - Scout(9)  
> - Scribe(5)  
> - Sculptor(5)  
> - SellSpell(5)  
> - Ship Builder(6)  
> - Shoe Maker(12)  
> - Shoe Maker(12)  
> - Silversmith(14)  
> - Silversmith(6)  
> - Skinner(10)  
> - Slaver(17)  
> - Slaver(17)  
> - Soap Maker(9)  
> - Spice Merchant(17)  
> - Spice Merchant(17)  
> - Stabler(18)  
> - Storyteller(17)  
> - Tailor(14)  
> - Tanner(13)  
> - Tanner(13)  
> - Tavern Keeper(18)  
> - Tax Collector(3)  
> - Taxidermist(17)  
> - Taxidermist(17)  
> - Teacher(5)  
> - Teamster(20)  
> - Tiler(20)  
> - Tinker(25)  
> - Tinker(6)  
> - Tobacco Merchant(17)  
> - Tobacco Merchant(17)  
> - Town Crier(28)  
> - Town Justice(7)  
> - Toymaker(5)  
> - Toymaker(8)  
> - Trading Post(25)  
> - Troubadours(17)  
> - Tutor(5)  
> - Undertaker(6)  
> - Used Garment Trader(21)  
> - Vestment Maker(12)  
> - Vintner(11)  
> - Viscount(1)  
> - Wagon Maker(14)  
> - Warehouser(17)  
> - Water Carrier(20)  
> - Weapon Dealer(17)  
> - Weapon Dealer(17)  
> - Weaponsmith(5)  
> - Weaponsmith(5)  
> - Weaver(14)  
> - Wheelwright(16)  
> - Wheelwright(22)  
> - Wine Merchant(9)  
> - Wood Carver(8)  
> - Wood Seller(8)  
> - Wool Merchant(13)  
> - Writer(17)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC


> ###### Notable Points of Interest
> ```dataview
table without ID file.link AS Name, wardType AS "Type"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC


## Notable Characters

> ###### Notable Characters
> ```dataview
table without ID file.link AS Name, race as Race, PrimaryOccupation as Profession
where kingdom=this.kingdom and settlementName=this.settlementName  and (fileType="npc"  and importance > 5)
sort importance DESC


## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



