---
cssclass: oRPGPage
fileType: settlement
settlementType: Hamlet
kingdom: KingdomName
region: RegionName
settlementName: Named Hamlet (101)
terrain: Hills Forest Mixed 
settlementDescription: 
population: 101
culture: Viking 
technology: Savage 
leader: 
govermentType: Magocracy 
demographics: 
- Trading Post(1) 
- Blacksmith(1) 
- Cooper(1) 
- Tavern Keeper(1) 
- Farmer(6) 
- Homestead(7) 
- Farmer - Corn(1) 
imports: 
- Linen  
exports: 
- Skins  
defenses: Curtain Wall 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Blacksmith(1)  
> - Cooper(1)  
> - Farmer - Corn(1)  
> - Farmer(6)  
> - Homestead(7)  
> - Tavern Keeper(1)  
> - Trading Post(1)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC


> ###### Notable Points of Interest
> ```dataview
table without ID file.link AS Name, wardType AS "Type"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC


## Notable Characters

> ###### Notable Characters
> ```dataview
table without ID file.link AS Name, race as Race, PrimaryOccupation as Profession
where kingdom=this.kingdom and settlementName=this.settlementName  and (fileType="npc"  and importance > 5)
sort importance DESC


## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



