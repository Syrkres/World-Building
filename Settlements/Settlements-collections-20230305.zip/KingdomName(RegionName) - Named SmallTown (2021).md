---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallTown
kingdom: KingdomName
region: RegionName
settlementName: Named SmallTown (2021)
terrain: Mountains 
settlementDescription: 
population: 2021
culture: Indian 
technology: Crusades 
leader: 
govermentType: Magocracy 
demographics: 
- Acrobat(4) 
- Minstrel(4) 
- Storyteller(4) 
- Troubadours(4) 
- Writer(4) 
- Advocate(3) 
- Clerk(6) 
- Council Member(6) 
- Diplomat(1) 
- Judge(3) 
- Mayor(1) 
- Alchemist(1) 
- Chandler(6) 
- Dye Makers(6) 
- Florist(1) 
- Herbalist(1) 
- Potionmakers(1) 
- Spice Merchant(4) 
- Taxidermist(4) 
- Tobacco Merchant(4) 
- Animal Groomer(1) 
- Animal Handler(4) 
- Caravanner(3) 
- Horse Trader(5) 
- Livestock Merchant(3) 
- Stabler(4) 
- Antiquities(4) 
- Armor Dealer(4) 
- Launderer(4) 
- Oil Trader(6) 
- Trading Post(6) 
- Slaver(4) 
- Spice Merchant(4) 
- Taxidermist(4) 
- Tobacco Merchant(4) 
- Warehouser(4) 
- Weapon Dealer(4) 
- Architect(5) 
- Bricklayer(5) 
- Engineer(5) 
- Laborer(5) 
- Mason(5) 
- Painter(Building)(5) 
- Plasterer(5) 
- Roofer(5) 
- Teamster(5) 
- Tiler(5) 
- Armorer(1) 
- Blacksmith(5) 
- Bowyer-Fletcher(2) 
- Jeweler(2) 
- Silversmith(2) 
- Weapon Dealer(4) 
- Weaponsmith(1) 
- Artist(5) 
- Glassblower(4) 
- Goldsmith(3) 
- Inventor(3) 
- Jeweler(3) 
- Painter(Art)(4) 
- Silversmith(3) 
- Tinker(6) 
- Toymaker(1) 
- Baker(4) 
- Beer Merchant(1) 
- Butcher(3) 
- Chicken Butcher(3) 
- Cook(3) 
- Dairy Seller(11) 
- Distiller(1) 
- Hay Merchant(11) 
- Fisherman(3) 
- Fishmonger(3) 
- Grocer(1) 
- Meat Butcher(1) 
- Miller(6) 
- Pastry Maker(3) 
- Vintner(3) 
- Banker(1) 
- Pawnbroker(1) 
- Barbarian(11) 
- Brigand(11) 
- Captain(11) 
- Mountainman(11) 
- Barbarian(2) 
- Cartographer(1) 
- Guide(4) 
- Huntsman(6) 
- Mountainman(1) 
- Pathfinder(2) 
- Scout(2) 
- Slaver(4) 
- Barrel Maker(3) 
- Basket Maker(3) 
- Book Binder(1) 
- Bookseller(1) 
- Buckle Maker(1) 
- Candle Maker(1) 
- Cobbler(4) 
- Cooper(3) 
- Cutler(1) 
- Engraver(1) 
- Furniture Maker(4) 
- Glassblower(1) 
- Glazier(1) 
- Glove Merchant(3) 
- Goldsmith(1) 
- Harness Maker(4) 
- Hat Maker(1) 
- Kettle Maker(1) 
- Locksmith(1) 
- Perfumer(1) 
- Potter(4) 
- Rope Maker(3) 
- Rug Maker(1) 
- Saddler(3) 
- Sculptor(1) 
- Shoe Maker(3) 
- Soap Maker(2) 
- Tanner(3) 
- Tinker(1) 
- Weaver(3) 
- Wheelwright(5) 
- Wine Merchant(2) 
- Wool Merchant(3) 
- Lord(1) 
- Knight(1) 
- Barrel Maker(4) 
- Bowyer-Fletcher(1) 
- Carpenter(6) 
- Roofer(5) 
- Wagon Maker(3) 
- Wheelwright(4) 
- Wood Carver(1) 
- Wood Seller(1) 
- Barber(2) 
- Bleacher(1) 
- Physic/Chirurgeon(2) 
- Bather(2) 
- Brigand(4) 
- Crook(5) 
- Goon(5) 
- Brothel Keeper(1) 
- Innkeeper(3) 
- Tavern Keeper(4) 
- Buckle Maker(3) 
- Cobbler(3) 
- Draper(2) 
- Furrier(5) 
- Girdler(1) 
- Haberdasher(1) 
- Launderer(3) 
- Leatherworker(2) 
- Purse Maker(2) 
- Shoe Maker(3) 
- Tailor(3) 
- Tanner(3) 
- Used Garment Trader(5) 
- Vestment Maker(3) 
- Chandler(6) 
- Dye Makers(6) 
- Oil Trader(6) 
- Cleric(4) 
- High Priest(1) 
- Missionary(14) 
- Preacher(9) 
- Priest(5) 
- Farmer(102) 
- Homestead(135) 
- Farmer - Cabbage(11) 
- Farmer - Cattle Herder(11) 
- Farmer - Corn(11) 
- Farmer - Cow Herder(11) 
- Farmer - Dairy(11) 
- Farmer - Goat Herder(11) 
- Farmer - Pig Herder(11) 
- Farmer - Potato(11) 
- Farmer - Sheep Herder(11) 
- Farmer - Wheat(11) 
- Farmer(Special)(11) 
- Dungsweeper(3) 
- Illuminator(3) 
- Messenger(4) 
- Town Crier(6) 
- Town Justice(2) 
- Undertaker(2) 
- Water Carrier(5) 
- Leatherworker(3) 
- Skinner(3) 
- Naval Outfitter(1) 
- Pirate(6) 
- Sail Maker(3) 
- Sailor(7) 
- Ship Builder(1) 
imports: 
- Gold  
exports: 
- Grain  
defenses: City Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(4)  
> - Advocate(3)  
> - Alchemist(1)  
> - Animal Groomer(1)  
> - Animal Handler(4)  
> - Antiquities(4)  
> - Architect(5)  
> - Armor Dealer(4)  
> - Armorer(1)  
> - Artist(5)  
> - Baker(4)  
> - Banker(1)  
> - Barbarian(11)  
> - Barbarian(2)  
> - Barber(2)  
> - Barrel Maker(3)  
> - Barrel Maker(4)  
> - Basket Maker(3)  
> - Bather(2)  
> - Beer Merchant(1)  
> - Blacksmith(5)  
> - Bleacher(1)  
> - Book Binder(1)  
> - Bookseller(1)  
> - Bowyer-Fletcher(1)  
> - Bowyer-Fletcher(2)  
> - Bricklayer(5)  
> - Brigand(11)  
> - Brigand(4)  
> - Brothel Keeper(1)  
> - Buckle Maker(1)  
> - Buckle Maker(3)  
> - Butcher(3)  
> - Candle Maker(1)  
> - Captain(11)  
> - Caravanner(3)  
> - Carpenter(6)  
> - Cartographer(1)  
> - Chandler(6)  
> - Chandler(6)  
> - Chicken Butcher(3)  
> - Cleric(4)  
> - Clerk(6)  
> - Cobbler(3)  
> - Cobbler(4)  
> - Cook(3)  
> - Cooper(3)  
> - Council Member(6)  
> - Crook(5)  
> - Cutler(1)  
> - Dairy Seller(11)  
> - Diplomat(1)  
> - Distiller(1)  
> - Draper(2)  
> - Dungsweeper(3)  
> - Dye Makers(6)  
> - Dye Makers(6)  
> - Engineer(5)  
> - Engraver(1)  
> - Farmer - Cabbage(11)  
> - Farmer - Cattle Herder(11)  
> - Farmer - Corn(11)  
> - Farmer - Cow Herder(11)  
> - Farmer - Dairy(11)  
> - Farmer - Goat Herder(11)  
> - Farmer - Pig Herder(11)  
> - Farmer - Potato(11)  
> - Farmer - Sheep Herder(11)  
> - Farmer - Wheat(11)  
> - Farmer(102)  
> - Farmer(Special)(11)  
> - Fisherman(3)  
> - Fishmonger(3)  
> - Florist(1)  
> - Furniture Maker(4)  
> - Furrier(5)  
> - Girdler(1)  
> - Glassblower(1)  
> - Glassblower(4)  
> - Glazier(1)  
> - Glove Merchant(3)  
> - Goldsmith(1)  
> - Goldsmith(3)  
> - Goon(5)  
> - Grocer(1)  
> - Guide(4)  
> - Haberdasher(1)  
> - Harness Maker(4)  
> - Hat Maker(1)  
> - Hay Merchant(11)  
> - Herbalist(1)  
> - High Priest(1)  
> - Homestead(135)  
> - Horse Trader(5)  
> - Huntsman(6)  
> - Illuminator(3)  
> - Innkeeper(3)  
> - Inventor(3)  
> - Jeweler(2)  
> - Jeweler(3)  
> - Judge(3)  
> - Kettle Maker(1)  
> - Knight(1)  
> - Laborer(5)  
> - Launderer(3)  
> - Launderer(4)  
> - Leatherworker(2)  
> - Leatherworker(3)  
> - Livestock Merchant(3)  
> - Locksmith(1)  
> - Lord(1)  
> - Mason(5)  
> - Mayor(1)  
> - Meat Butcher(1)  
> - Messenger(4)  
> - Miller(6)  
> - Minstrel(4)  
> - Missionary(14)  
> - Mountainman(1)  
> - Mountainman(11)  
> - Naval Outfitter(1)  
> - Oil Trader(6)  
> - Oil Trader(6)  
> - Painter(Art)(4)  
> - Painter(Building)(5)  
> - Pastry Maker(3)  
> - Pathfinder(2)  
> - Pawnbroker(1)  
> - Perfumer(1)  
> - Physic/Chirurgeon(2)  
> - Pirate(6)  
> - Plasterer(5)  
> - Potionmakers(1)  
> - Potter(4)  
> - Preacher(9)  
> - Priest(5)  
> - Purse Maker(2)  
> - Roofer(5)  
> - Roofer(5)  
> - Rope Maker(3)  
> - Rug Maker(1)  
> - Saddler(3)  
> - Sail Maker(3)  
> - Sailor(7)  
> - Scout(2)  
> - Sculptor(1)  
> - Ship Builder(1)  
> - Shoe Maker(3)  
> - Shoe Maker(3)  
> - Silversmith(2)  
> - Silversmith(3)  
> - Skinner(3)  
> - Slaver(4)  
> - Slaver(4)  
> - Soap Maker(2)  
> - Spice Merchant(4)  
> - Spice Merchant(4)  
> - Stabler(4)  
> - Storyteller(4)  
> - Tailor(3)  
> - Tanner(3)  
> - Tanner(3)  
> - Tavern Keeper(4)  
> - Taxidermist(4)  
> - Taxidermist(4)  
> - Teamster(5)  
> - Tiler(5)  
> - Tinker(1)  
> - Tinker(6)  
> - Tobacco Merchant(4)  
> - Tobacco Merchant(4)  
> - Town Crier(6)  
> - Town Justice(2)  
> - Toymaker(1)  
> - Trading Post(6)  
> - Troubadours(4)  
> - Undertaker(2)  
> - Used Garment Trader(5)  
> - Vestment Maker(3)  
> - Vintner(3)  
> - Wagon Maker(3)  
> - Warehouser(4)  
> - Water Carrier(5)  
> - Weapon Dealer(4)  
> - Weapon Dealer(4)  
> - Weaponsmith(1)  
> - Weaver(3)  
> - Wheelwright(4)  
> - Wheelwright(5)  
> - Wine Merchant(2)  
> - Wood Carver(1)  
> - Wood Seller(1)  
> - Wool Merchant(3)  
> - Writer(4)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC


> ###### Notable Points of Interest
> ```dataview
table without ID file.link AS Name, wardType AS "Type"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC


## Notable Characters

> ###### Notable Characters
> ```dataview
table without ID file.link AS Name, race as Race, PrimaryOccupation as Profession
where kingdom=this.kingdom and settlementName=this.settlementName  and (fileType="npc"  and importance > 5)
sort importance DESC


## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



