---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeTown
kingdom: KingdomName
region: RegionName
settlementName: Named LargeTown (4572)
terrain: Hills 
settlementDescription: 
population: 4572
culture: Savage 
technology: Savage 
leader: 
govermentType: Confederation 
demographics: 
- Acrobat(8) 
- Minstrel(8) 
- Storyteller(8) 
- Troubadours(8) 
- Writer(8) 
- Advocate(6) 
- Clerk(14) 
- Council Member(12) 
- Diplomat(2) 
- Judge(7) 
- Mayor(1) 
- Alchemist(4) 
- Chandler(12) 
- Dye Makers(12) 
- Florist(4) 
- Herbalist(4) 
- Potionmakers(4) 
- Sage(3) 
- Spice Merchant(8) 
- Taxidermist(8) 
- Tobacco Merchant(8) 
- Animal Groomer(4) 
- Animal Handler(8) 
- Caravanner(6) 
- Horse Trader(10) 
- Livestock Merchant(7) 
- Stabler(9) 
- Antiquities(8) 
- Armor Dealer(8) 
- Launderer(8) 
- Oil Trader(12) 
- Trading Post(12) 
- Slaver(8) 
- Spice Merchant(8) 
- Taxidermist(8) 
- Tobacco Merchant(8) 
- Warehouser(8) 
- Weapon Dealer(8) 
- Architect(10) 
- Bricklayer(10) 
- Engineer(10) 
- Laborer(10) 
- Mason(10) 
- Painter(Building)(10) 
- Plasterer(10) 
- Roofer(10) 
- Teamster(10) 
- Tiler(10) 
- Armorer(3) 
- Blacksmith(11) 
- Bowyer-Fletcher(4) 
- Jeweler(3) 
- Silversmith(3) 
- Weapon Dealer(8) 
- Weaponsmith(3) 
- Artist(11) 
- Glassblower(8) 
- Goldsmith(6) 
- Inventor(7) 
- Jeweler(5) 
- Magical Artisan(3) 
- Painter(Art)(9) 
- Silversmith(7) 
- Tinker(12) 
- Toymaker(4) 
- Astrologist(3) 
- Conjourer(3) 
- High Mage(3) 
- Historian(3) 
- Librarian(3) 
- Magical Artisan(3) 
- Magical Tutor(3) 
- Professor(3) 
- Scribe(3) 
- SellSpell(3) 
- Teacher(3) 
- Tutor(3) 
- Baker(8) 
- Beer Merchant(5) 
- Brewer(1) 
- Butcher(5) 
- Chicken Butcher(5) 
- Cook(5) 
- Dairy Seller(23) 
- Distiller(5) 
- Hay Merchant(23) 
- Fisherman(6) 
- Fishmonger(6) 
- Grain Merchant(1) 
- Grocer(4) 
- Meat Butcher(4) 
- Miller(12) 
- Pastry Maker(6) 
- Vintner(5) 
- Banker(3) 
- Pawnbroker(3) 
- Barbarian(23) 
- Brigand(23) 
- Captain(23) 
- Mountainman(23) 
- Barbarian(5) 
- Cartographer(4) 
- Guide(8) 
- Huntsman(12) 
- Mountainman(4) 
- Pathfinder(4) 
- Scout(4) 
- Slaver(8) 
- Barrel Maker(5) 
- Basket Maker(7) 
- Book Binder(3) 
- Bookseller(3) 
- Buckle Maker(4) 
- Candle Maker(3) 
- Clock Maker(3) 
- Cobbler(8) 
- Cooper(6) 
- Cutler(3) 
- Engraver(3) 
- Furniture Maker(8) 
- Glassblower(4) 
- Glazier(3) 
- Glove Merchant(7) 
- Goldsmith(4) 
- Harness Maker(8) 
- Hat Maker(4) 
- Instrument Maker(3) 
- Kettle Maker(2) 
- Locksmith(3) 
- Perfumer(4) 
- Potter(8) 
- Rope Maker(6) 
- Rug Maker(3) 
- Saddler(6) 
- Sculptor(2) 
- Shoe Maker(6) 
- Soap Maker(4) 
- Tanner(6) 
- Tinker(3) 
- Toymaker(3) 
- Weaponsmith(3) 
- Weaver(7) 
- Wheelwright(11) 
- Wine Merchant(4) 
- Wool Merchant(6) 
- Lord(2) 
- Knight(2) 
- Baron(1) 
- Barrel Maker(9) 
- Bowyer-Fletcher(4) 
- Carpenter(14) 
- Roofer(10) 
- Wagon Maker(7) 
- Wheelwright(8) 
- Wood Carver(4) 
- Wood Seller(4) 
- Barber(4) 
- Bleacher(4) 
- Physic/Chirurgeon(4) 
- Bather(4) 
- Brigand(8) 
- Crime Lord(2) 
- Crook(10) 
- Goon(11) 
- Brothel Keeper(4) 
- Innkeeper(7) 
- Tavern Keeper(9) 
- Buckle Maker(7) 
- Cobbler(6) 
- Draper(4) 
- Furrier(11) 
- Girdler(4) 
- Haberdasher(3) 
- Launderer(7) 
- Leatherworker(5) 
- Purse Maker(4) 
- Shoe Maker(6) 
- Tailor(7) 
- Tanner(6) 
- Used Garment Trader(10) 
- Vestment Maker(6) 
- Chandler(12) 
- Dye Makers(12) 
- Oil Trader(12) 
- Cleric(9) 
- High Priest(4) 
- Missionary(31) 
- Preacher(19) 
- Priest(11) 
- Farmer(229) 
- Homestead(305) 
- Farmer - Cabbage(23) 
- Farmer - Cattle Herder(23) 
- Farmer - Corn(23) 
- Farmer - Cow Herder(23) 
- Farmer - Dairy(23) 
- Farmer - Goat Herder(23) 
- Farmer - Pig Herder(23) 
- Farmer - Potato(23) 
- Farmer - Sheep Herder(23) 
- Farmer - Wheat(23) 
- Farmer(Special)(23) 
- Dungsweeper(7) 
- Illuminator(5) 
- Messenger(8) 
- Tax Collector(1) 
- Town Crier(14) 
- Town Justice(4) 
- Undertaker(3) 
- Water Carrier(10) 
- Leatherworker(5) 
- Skinner(5) 
- Naval Outfitter(3) 
- Pirate(12) 
- Sail Maker(7) 
- Sailor(16) 
- Ship Builder(3) 
imports: 
- Honey  
exports: 
- Soapstone  
defenses: Killing Fields 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(8)  
> - Advocate(6)  
> - Alchemist(4)  
> - Animal Groomer(4)  
> - Animal Handler(8)  
> - Antiquities(8)  
> - Architect(10)  
> - Armor Dealer(8)  
> - Armorer(3)  
> - Artist(11)  
> - Astrologist(3)  
> - Baker(8)  
> - Banker(3)  
> - Barbarian(23)  
> - Barbarian(5)  
> - Barber(4)  
> - Baron(1)  
> - Barrel Maker(5)  
> - Barrel Maker(9)  
> - Basket Maker(7)  
> - Bather(4)  
> - Beer Merchant(5)  
> - Blacksmith(11)  
> - Bleacher(4)  
> - Book Binder(3)  
> - Bookseller(3)  
> - Bowyer-Fletcher(4)  
> - Bowyer-Fletcher(4)  
> - Brewer(1)  
> - Bricklayer(10)  
> - Brigand(23)  
> - Brigand(8)  
> - Brothel Keeper(4)  
> - Buckle Maker(4)  
> - Buckle Maker(7)  
> - Butcher(5)  
> - Candle Maker(3)  
> - Captain(23)  
> - Caravanner(6)  
> - Carpenter(14)  
> - Cartographer(4)  
> - Chandler(12)  
> - Chandler(12)  
> - Chicken Butcher(5)  
> - Cleric(9)  
> - Clerk(14)  
> - Clock Maker(3)  
> - Cobbler(6)  
> - Cobbler(8)  
> - Conjourer(3)  
> - Cook(5)  
> - Cooper(6)  
> - Council Member(12)  
> - Crime Lord(2)  
> - Crook(10)  
> - Cutler(3)  
> - Dairy Seller(23)  
> - Diplomat(2)  
> - Distiller(5)  
> - Draper(4)  
> - Dungsweeper(7)  
> - Dye Makers(12)  
> - Dye Makers(12)  
> - Engineer(10)  
> - Engraver(3)  
> - Farmer - Cabbage(23)  
> - Farmer - Cattle Herder(23)  
> - Farmer - Corn(23)  
> - Farmer - Cow Herder(23)  
> - Farmer - Dairy(23)  
> - Farmer - Goat Herder(23)  
> - Farmer - Pig Herder(23)  
> - Farmer - Potato(23)  
> - Farmer - Sheep Herder(23)  
> - Farmer - Wheat(23)  
> - Farmer(229)  
> - Farmer(Special)(23)  
> - Fisherman(6)  
> - Fishmonger(6)  
> - Florist(4)  
> - Furniture Maker(8)  
> - Furrier(11)  
> - Girdler(4)  
> - Glassblower(4)  
> - Glassblower(8)  
> - Glazier(3)  
> - Glove Merchant(7)  
> - Goldsmith(4)  
> - Goldsmith(6)  
> - Goon(11)  
> - Grain Merchant(1)  
> - Grocer(4)  
> - Guide(8)  
> - Haberdasher(3)  
> - Harness Maker(8)  
> - Hat Maker(4)  
> - Hay Merchant(23)  
> - Herbalist(4)  
> - High Mage(3)  
> - High Priest(4)  
> - Historian(3)  
> - Homestead(305)  
> - Horse Trader(10)  
> - Huntsman(12)  
> - Illuminator(5)  
> - Innkeeper(7)  
> - Instrument Maker(3)  
> - Inventor(7)  
> - Jeweler(3)  
> - Jeweler(5)  
> - Judge(7)  
> - Kettle Maker(2)  
> - Knight(2)  
> - Laborer(10)  
> - Launderer(7)  
> - Launderer(8)  
> - Leatherworker(5)  
> - Leatherworker(5)  
> - Librarian(3)  
> - Livestock Merchant(7)  
> - Locksmith(3)  
> - Lord(2)  
> - Magical Artisan(3)  
> - Magical Artisan(3)  
> - Magical Tutor(3)  
> - Mason(10)  
> - Mayor(1)  
> - Meat Butcher(4)  
> - Messenger(8)  
> - Miller(12)  
> - Minstrel(8)  
> - Missionary(31)  
> - Mountainman(23)  
> - Mountainman(4)  
> - Naval Outfitter(3)  
> - Oil Trader(12)  
> - Oil Trader(12)  
> - Painter(Art)(9)  
> - Painter(Building)(10)  
> - Pastry Maker(6)  
> - Pathfinder(4)  
> - Pawnbroker(3)  
> - Perfumer(4)  
> - Physic/Chirurgeon(4)  
> - Pirate(12)  
> - Plasterer(10)  
> - Potionmakers(4)  
> - Potter(8)  
> - Preacher(19)  
> - Priest(11)  
> - Professor(3)  
> - Purse Maker(4)  
> - Roofer(10)  
> - Roofer(10)  
> - Rope Maker(6)  
> - Rug Maker(3)  
> - Saddler(6)  
> - Sage(3)  
> - Sail Maker(7)  
> - Sailor(16)  
> - Scout(4)  
> - Scribe(3)  
> - Sculptor(2)  
> - SellSpell(3)  
> - Ship Builder(3)  
> - Shoe Maker(6)  
> - Shoe Maker(6)  
> - Silversmith(3)  
> - Silversmith(7)  
> - Skinner(5)  
> - Slaver(8)  
> - Slaver(8)  
> - Soap Maker(4)  
> - Spice Merchant(8)  
> - Spice Merchant(8)  
> - Stabler(9)  
> - Storyteller(8)  
> - Tailor(7)  
> - Tanner(6)  
> - Tanner(6)  
> - Tavern Keeper(9)  
> - Tax Collector(1)  
> - Taxidermist(8)  
> - Taxidermist(8)  
> - Teacher(3)  
> - Teamster(10)  
> - Tiler(10)  
> - Tinker(12)  
> - Tinker(3)  
> - Tobacco Merchant(8)  
> - Tobacco Merchant(8)  
> - Town Crier(14)  
> - Town Justice(4)  
> - Toymaker(3)  
> - Toymaker(4)  
> - Trading Post(12)  
> - Troubadours(8)  
> - Tutor(3)  
> - Undertaker(3)  
> - Used Garment Trader(10)  
> - Vestment Maker(6)  
> - Vintner(5)  
> - Wagon Maker(7)  
> - Warehouser(8)  
> - Water Carrier(10)  
> - Weapon Dealer(8)  
> - Weapon Dealer(8)  
> - Weaponsmith(3)  
> - Weaponsmith(3)  
> - Weaver(7)  
> - Wheelwright(11)  
> - Wheelwright(8)  
> - Wine Merchant(4)  
> - Wood Carver(4)  
> - Wood Seller(4)  
> - Wool Merchant(6)  
> - Writer(8)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC


> ###### Notable Points of Interest
> ```dataview
table without ID file.link AS Name, wardType AS "Type"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC


## Notable Characters

> ###### Notable Characters
> ```dataview
table without ID file.link AS Name, race as Race, PrimaryOccupation as Profession
where kingdom=this.kingdom and settlementName=this.settlementName  and (fileType="npc"  and importance > 5)
sort importance DESC


## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



