---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeTown
kingdom: KingdomName
region: RegionName
settlementName: Named LargeTown (3055)
terrain: Marsh 
settlementDescription: 
population: 3055
culture: Oriental 
technology: Roman 
leader: 
govermentType: Totalitarian 
demographics: 
- Acrobat(6) 
- Minstrel(6) 
- Storyteller(6) 
- Troubadours(6) 
- Writer(6) 
- Advocate(4) 
- Clerk(9) 
- Council Member(8) 
- Diplomat(2) 
- Judge(5) 
- Mayor(1) 
- Alchemist(3) 
- Chandler(8) 
- Dye Makers(8) 
- Florist(3) 
- Herbalist(3) 
- Potionmakers(3) 
- Sage(1) 
- Spice Merchant(6) 
- Taxidermist(6) 
- Tobacco Merchant(6) 
- Animal Groomer(3) 
- Animal Handler(6) 
- Caravanner(4) 
- Horse Trader(7) 
- Livestock Merchant(5) 
- Stabler(6) 
- Antiquities(6) 
- Armor Dealer(6) 
- Launderer(6) 
- Oil Trader(8) 
- Trading Post(8) 
- Slaver(6) 
- Spice Merchant(6) 
- Taxidermist(6) 
- Tobacco Merchant(6) 
- Warehouser(6) 
- Weapon Dealer(6) 
- Architect(7) 
- Bricklayer(7) 
- Engineer(7) 
- Laborer(7) 
- Mason(7) 
- Painter(Building)(7) 
- Plasterer(7) 
- Roofer(7) 
- Teamster(7) 
- Tiler(7) 
- Armorer(2) 
- Blacksmith(8) 
- Bowyer-Fletcher(3) 
- Jeweler(2) 
- Silversmith(2) 
- Weapon Dealer(6) 
- Weaponsmith(1) 
- Artist(7) 
- Glassblower(6) 
- Goldsmith(4) 
- Inventor(5) 
- Jeweler(4) 
- Magical Artisan(1) 
- Painter(Art)(6) 
- Silversmith(5) 
- Tinker(8) 
- Toymaker(3) 
- Astrologist(1) 
- Conjourer(1) 
- High Mage(1) 
- Historian(1) 
- Librarian(1) 
- Magical Artisan(1) 
- Magical Tutor(1) 
- Professor(1) 
- Scribe(1) 
- SellSpell(1) 
- Teacher(1) 
- Tutor(1) 
- Baker(5) 
- Beer Merchant(3) 
- Butcher(4) 
- Chicken Butcher(4) 
- Cook(4) 
- Dairy Seller(16) 
- Distiller(3) 
- Hay Merchant(16) 
- Fisherman(4) 
- Fishmonger(4) 
- Grocer(3) 
- Meat Butcher(3) 
- Miller(8) 
- Pastry Maker(4) 
- Vintner(4) 
- Banker(1) 
- Pawnbroker(1) 
- Barbarian(16) 
- Brigand(16) 
- Captain(16) 
- Mountainman(16) 
- Barbarian(3) 
- Cartographer(3) 
- Guide(6) 
- Huntsman(8) 
- Mountainman(3) 
- Pathfinder(3) 
- Scout(3) 
- Slaver(6) 
- Barrel Maker(4) 
- Basket Maker(5) 
- Book Binder(1) 
- Bookseller(1) 
- Buckle Maker(3) 
- Candle Maker(2) 
- Clock Maker(1) 
- Cobbler(5) 
- Cooper(4) 
- Cutler(2) 
- Engraver(2) 
- Furniture Maker(5) 
- Glassblower(3) 
- Glazier(2) 
- Glove Merchant(5) 
- Goldsmith(3) 
- Harness Maker(6) 
- Hat Maker(3) 
- Instrument Maker(1) 
- Kettle Maker(1) 
- Locksmith(2) 
- Perfumer(3) 
- Potter(6) 
- Rope Maker(4) 
- Rug Maker(2) 
- Saddler(4) 
- Sculptor(2) 
- Shoe Maker(4) 
- Soap Maker(3) 
- Tanner(4) 
- Tinker(2) 
- Toymaker(1) 
- Weaponsmith(1) 
- Weaver(5) 
- Wheelwright(7) 
- Wine Merchant(3) 
- Wool Merchant(4) 
- Lord(2) 
- Knight(2) 
- Baron(1) 
- Barrel Maker(6) 
- Bowyer-Fletcher(3) 
- Carpenter(9) 
- Roofer(7) 
- Wagon Maker(5) 
- Wheelwright(5) 
- Wood Carver(3) 
- Wood Seller(3) 
- Barber(3) 
- Bleacher(3) 
- Physic/Chirurgeon(3) 
- Bather(3) 
- Brigand(6) 
- Crime Lord(1) 
- Crook(7) 
- Goon(7) 
- Brothel Keeper(3) 
- Innkeeper(5) 
- Tavern Keeper(6) 
- Buckle Maker(5) 
- Cobbler(4) 
- Draper(3) 
- Furrier(7) 
- Girdler(3) 
- Haberdasher(2) 
- Launderer(5) 
- Leatherworker(3) 
- Purse Maker(3) 
- Shoe Maker(4) 
- Tailor(5) 
- Tanner(4) 
- Used Garment Trader(7) 
- Vestment Maker(4) 
- Chandler(8) 
- Dye Makers(8) 
- Oil Trader(8) 
- Cleric(6) 
- High Priest(3) 
- Missionary(21) 
- Preacher(13) 
- Priest(7) 
- Farmer(153) 
- Homestead(204) 
- Farmer - Cabbage(16) 
- Farmer - Cattle Herder(16) 
- Farmer - Corn(16) 
- Farmer - Cow Herder(16) 
- Farmer - Dairy(16) 
- Farmer - Goat Herder(16) 
- Farmer - Pig Herder(16) 
- Farmer - Potato(16) 
- Farmer - Sheep Herder(16) 
- Farmer - Wheat(16) 
- Farmer(Special)(16) 
- Dungsweeper(5) 
- Illuminator(4) 
- Messenger(5) 
- Tax Collector(1) 
- Town Crier(9) 
- Town Justice(3) 
- Undertaker(2) 
- Water Carrier(7) 
- Leatherworker(4) 
- Skinner(4) 
- Naval Outfitter(1) 
- Pirate(8) 
- Sail Maker(5) 
- Sailor(11) 
- Ship Builder(2) 
imports: 
- Silk  
exports: 
- Wine  
defenses: Curtain Wall 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(6)  
> - Advocate(4)  
> - Alchemist(3)  
> - Animal Groomer(3)  
> - Animal Handler(6)  
> - Antiquities(6)  
> - Architect(7)  
> - Armor Dealer(6)  
> - Armorer(2)  
> - Artist(7)  
> - Astrologist(1)  
> - Baker(5)  
> - Banker(1)  
> - Barbarian(16)  
> - Barbarian(3)  
> - Barber(3)  
> - Baron(1)  
> - Barrel Maker(4)  
> - Barrel Maker(6)  
> - Basket Maker(5)  
> - Bather(3)  
> - Beer Merchant(3)  
> - Blacksmith(8)  
> - Bleacher(3)  
> - Book Binder(1)  
> - Bookseller(1)  
> - Bowyer-Fletcher(3)  
> - Bowyer-Fletcher(3)  
> - Bricklayer(7)  
> - Brigand(16)  
> - Brigand(6)  
> - Brothel Keeper(3)  
> - Buckle Maker(3)  
> - Buckle Maker(5)  
> - Butcher(4)  
> - Candle Maker(2)  
> - Captain(16)  
> - Caravanner(4)  
> - Carpenter(9)  
> - Cartographer(3)  
> - Chandler(8)  
> - Chandler(8)  
> - Chicken Butcher(4)  
> - Cleric(6)  
> - Clerk(9)  
> - Clock Maker(1)  
> - Cobbler(4)  
> - Cobbler(5)  
> - Conjourer(1)  
> - Cook(4)  
> - Cooper(4)  
> - Council Member(8)  
> - Crime Lord(1)  
> - Crook(7)  
> - Cutler(2)  
> - Dairy Seller(16)  
> - Diplomat(2)  
> - Distiller(3)  
> - Draper(3)  
> - Dungsweeper(5)  
> - Dye Makers(8)  
> - Dye Makers(8)  
> - Engineer(7)  
> - Engraver(2)  
> - Farmer - Cabbage(16)  
> - Farmer - Cattle Herder(16)  
> - Farmer - Corn(16)  
> - Farmer - Cow Herder(16)  
> - Farmer - Dairy(16)  
> - Farmer - Goat Herder(16)  
> - Farmer - Pig Herder(16)  
> - Farmer - Potato(16)  
> - Farmer - Sheep Herder(16)  
> - Farmer - Wheat(16)  
> - Farmer(153)  
> - Farmer(Special)(16)  
> - Fisherman(4)  
> - Fishmonger(4)  
> - Florist(3)  
> - Furniture Maker(5)  
> - Furrier(7)  
> - Girdler(3)  
> - Glassblower(3)  
> - Glassblower(6)  
> - Glazier(2)  
> - Glove Merchant(5)  
> - Goldsmith(3)  
> - Goldsmith(4)  
> - Goon(7)  
> - Grocer(3)  
> - Guide(6)  
> - Haberdasher(2)  
> - Harness Maker(6)  
> - Hat Maker(3)  
> - Hay Merchant(16)  
> - Herbalist(3)  
> - High Mage(1)  
> - High Priest(3)  
> - Historian(1)  
> - Homestead(204)  
> - Horse Trader(7)  
> - Huntsman(8)  
> - Illuminator(4)  
> - Innkeeper(5)  
> - Instrument Maker(1)  
> - Inventor(5)  
> - Jeweler(2)  
> - Jeweler(4)  
> - Judge(5)  
> - Kettle Maker(1)  
> - Knight(2)  
> - Laborer(7)  
> - Launderer(5)  
> - Launderer(6)  
> - Leatherworker(3)  
> - Leatherworker(4)  
> - Librarian(1)  
> - Livestock Merchant(5)  
> - Locksmith(2)  
> - Lord(2)  
> - Magical Artisan(1)  
> - Magical Artisan(1)  
> - Magical Tutor(1)  
> - Mason(7)  
> - Mayor(1)  
> - Meat Butcher(3)  
> - Messenger(5)  
> - Miller(8)  
> - Minstrel(6)  
> - Missionary(21)  
> - Mountainman(16)  
> - Mountainman(3)  
> - Naval Outfitter(1)  
> - Oil Trader(8)  
> - Oil Trader(8)  
> - Painter(Art)(6)  
> - Painter(Building)(7)  
> - Pastry Maker(4)  
> - Pathfinder(3)  
> - Pawnbroker(1)  
> - Perfumer(3)  
> - Physic/Chirurgeon(3)  
> - Pirate(8)  
> - Plasterer(7)  
> - Potionmakers(3)  
> - Potter(6)  
> - Preacher(13)  
> - Priest(7)  
> - Professor(1)  
> - Purse Maker(3)  
> - Roofer(7)  
> - Roofer(7)  
> - Rope Maker(4)  
> - Rug Maker(2)  
> - Saddler(4)  
> - Sage(1)  
> - Sail Maker(5)  
> - Sailor(11)  
> - Scout(3)  
> - Scribe(1)  
> - Sculptor(2)  
> - SellSpell(1)  
> - Ship Builder(2)  
> - Shoe Maker(4)  
> - Shoe Maker(4)  
> - Silversmith(2)  
> - Silversmith(5)  
> - Skinner(4)  
> - Slaver(6)  
> - Slaver(6)  
> - Soap Maker(3)  
> - Spice Merchant(6)  
> - Spice Merchant(6)  
> - Stabler(6)  
> - Storyteller(6)  
> - Tailor(5)  
> - Tanner(4)  
> - Tanner(4)  
> - Tavern Keeper(6)  
> - Tax Collector(1)  
> - Taxidermist(6)  
> - Taxidermist(6)  
> - Teacher(1)  
> - Teamster(7)  
> - Tiler(7)  
> - Tinker(2)  
> - Tinker(8)  
> - Tobacco Merchant(6)  
> - Tobacco Merchant(6)  
> - Town Crier(9)  
> - Town Justice(3)  
> - Toymaker(1)  
> - Toymaker(3)  
> - Trading Post(8)  
> - Troubadours(6)  
> - Tutor(1)  
> - Undertaker(2)  
> - Used Garment Trader(7)  
> - Vestment Maker(4)  
> - Vintner(4)  
> - Wagon Maker(5)  
> - Warehouser(6)  
> - Water Carrier(7)  
> - Weapon Dealer(6)  
> - Weapon Dealer(6)  
> - Weaponsmith(1)  
> - Weaponsmith(1)  
> - Weaver(5)  
> - Wheelwright(5)  
> - Wheelwright(7)  
> - Wine Merchant(3)  
> - Wood Carver(3)  
> - Wood Seller(3)  
> - Wool Merchant(4)  
> - Writer(6)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC


> ###### Notable Points of Interest
> ```dataview
table without ID file.link AS Name, wardType AS "Type"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC


## Notable Characters

> ###### Notable Characters
> ```dataview
table without ID file.link AS Name, race as Race, PrimaryOccupation as Profession
where kingdom=this.kingdom and settlementName=this.settlementName  and (fileType="npc"  and importance > 5)
sort importance DESC


## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



