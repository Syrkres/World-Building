---
cssclass: oRPGPage
fileType: settlement
settlementType: SmallTown
kingdom: KingdomName
region: RegionName
settlementName: Named SmallTown (1540)
terrain: Forest Fungal 
settlementDescription: 
population: 1540
culture: Barbarian 
technology: Renaissance 
leader: 
govermentType: Republic 
demographics: 
- Acrobat(3) 
- Minstrel(3) 
- Storyteller(3) 
- Troubadours(3) 
- Writer(3) 
- Advocate(2) 
- Clerk(5) 
- Council Member(4) 
- Diplomat(1) 
- Judge(3) 
- Mayor(1) 
- Alchemist(1) 
- Chandler(4) 
- Dye Makers(4) 
- Florist(1) 
- Herbalist(1) 
- Potionmakers(1) 
- Spice Merchant(3) 
- Taxidermist(3) 
- Tobacco Merchant(3) 
- Animal Groomer(1) 
- Animal Handler(3) 
- Caravanner(2) 
- Horse Trader(4) 
- Livestock Merchant(3) 
- Stabler(3) 
- Antiquities(3) 
- Armor Dealer(3) 
- Launderer(3) 
- Oil Trader(4) 
- Trading Post(4) 
- Slaver(3) 
- Spice Merchant(3) 
- Taxidermist(3) 
- Tobacco Merchant(3) 
- Warehouser(3) 
- Weapon Dealer(3) 
- Architect(4) 
- Bricklayer(4) 
- Engineer(4) 
- Laborer(4) 
- Mason(4) 
- Painter(Building)(4) 
- Plasterer(4) 
- Roofer(4) 
- Teamster(4) 
- Tiler(4) 
- Armorer(1) 
- Blacksmith(4) 
- Bowyer-Fletcher(2) 
- Jeweler(1) 
- Silversmith(1) 
- Weapon Dealer(3) 
- Artist(4) 
- Glassblower(3) 
- Goldsmith(1) 
- Inventor(3) 
- Jeweler(1) 
- Painter(Art)(3) 
- Silversmith(3) 
- Tinker(4) 
- Toymaker(1) 
- Baker(3) 
- Beer Merchant(1) 
- Butcher(1) 
- Chicken Butcher(1) 
- Cook(1) 
- Dairy Seller(8) 
- Distiller(1) 
- Hay Merchant(1) 
- Fisherman(1) 
- Fishmonger(1) 
- Grocer(1) 
- Meat Butcher(1) 
- Miller(4) 
- Pastry Maker(1) 
- Vintner(1) 
- Barbarian(8) 
- Brigand(8) 
- Captain(8) 
- Mountainman(8) 
- Barbarian(2) 
- Cartographer(1) 
- Guide(3) 
- Huntsman(4) 
- Mountainman(1) 
- Pathfinder(2) 
- Scout(1) 
- Slaver(3) 
- Barrel Maker(2) 
- Basket Maker(3) 
- Buckle Maker(1) 
- Candle Maker(1) 
- Cobbler(3) 
- Cooper(2) 
- Cutler(1) 
- Engraver(1) 
- Furniture Maker(3) 
- Glassblower(1) 
- Glazier(1) 
- Glove Merchant(3) 
- Goldsmith(1) 
- Harness Maker(3) 
- Hat Maker(1) 
- Locksmith(1) 
- Perfumer(1) 
- Potter(3) 
- Rope Maker(2) 
- Rug Maker(1) 
- Saddler(2) 
- Sculptor(1) 
- Shoe Maker(2) 
- Soap Maker(1) 
- Tanner(1) 
- Tinker(1) 
- Weaver(3) 
- Wheelwright(4) 
- Wine Merchant(2) 
- Wool Merchant(2) 
- Lord(1) 
- Knight(1) 
- Barrel Maker(3) 
- Bowyer-Fletcher(1) 
- Carpenter(5) 
- Roofer(4) 
- Wagon Maker(3) 
- Wheelwright(3) 
- Wood Carver(1) 
- Wood Seller(1) 
- Barber(2) 
- Bleacher(1) 
- Physic/Chirurgeon(2) 
- Bather(2) 
- Brigand(3) 
- Crook(4) 
- Goon(4) 
- Brothel Keeper(1) 
- Innkeeper(3) 
- Tavern Keeper(3) 
- Buckle Maker(3) 
- Cobbler(2) 
- Draper(2) 
- Furrier(4) 
- Girdler(1) 
- Haberdasher(1) 
- Launderer(3) 
- Leatherworker(2) 
- Purse Maker(1) 
- Shoe Maker(2) 
- Tailor(3) 
- Tanner(2) 
- Used Garment Trader(4) 
- Vestment Maker(2) 
- Chandler(4) 
- Dye Makers(4) 
- Oil Trader(4) 
- Cleric(3) 
- High Priest(1) 
- Missionary(11) 
- Preacher(7) 
- Priest(4) 
- Farmer(78) 
- Homestead(103) 
- Farmer - Cabbage(8) 
- Farmer - Cattle Herder(8) 
- Farmer - Corn(8) 
- Farmer - Cow Herder(8) 
- Farmer - Dairy(8) 
- Farmer - Goat Herder(8) 
- Farmer - Pig Herder(8) 
- Farmer - Potato(8) 
- Farmer - Sheep Herder(8) 
- Farmer - Wheat(8) 
- Farmer(Special)(8) 
- Dungsweeper(3) 
- Illuminator(2) 
- Messenger(3) 
- Town Crier(5) 
- Town Justice(2) 
- Undertaker(1) 
- Water Carrier(4) 
- Leatherworker(1) 
- Skinner(1) 
- Pirate(4) 
- Sail Maker(3) 
- Sailor(6) 
- Ship Builder(1) 
imports: 
- Bamboo  
exports: 
- Grease  
defenses: Baileys 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(3)  
> - Advocate(2)  
> - Alchemist(1)  
> - Animal Groomer(1)  
> - Animal Handler(3)  
> - Antiquities(3)  
> - Architect(4)  
> - Armor Dealer(3)  
> - Armorer(1)  
> - Artist(4)  
> - Baker(3)  
> - Barbarian(2)  
> - Barbarian(8)  
> - Barber(2)  
> - Barrel Maker(2)  
> - Barrel Maker(3)  
> - Basket Maker(3)  
> - Bather(2)  
> - Beer Merchant(1)  
> - Blacksmith(4)  
> - Bleacher(1)  
> - Bowyer-Fletcher(1)  
> - Bowyer-Fletcher(2)  
> - Bricklayer(4)  
> - Brigand(3)  
> - Brigand(8)  
> - Brothel Keeper(1)  
> - Buckle Maker(1)  
> - Buckle Maker(3)  
> - Butcher(1)  
> - Candle Maker(1)  
> - Captain(8)  
> - Caravanner(2)  
> - Carpenter(5)  
> - Cartographer(1)  
> - Chandler(4)  
> - Chandler(4)  
> - Chicken Butcher(1)  
> - Cleric(3)  
> - Clerk(5)  
> - Cobbler(2)  
> - Cobbler(3)  
> - Cook(1)  
> - Cooper(2)  
> - Council Member(4)  
> - Crook(4)  
> - Cutler(1)  
> - Dairy Seller(8)  
> - Diplomat(1)  
> - Distiller(1)  
> - Draper(2)  
> - Dungsweeper(3)  
> - Dye Makers(4)  
> - Dye Makers(4)  
> - Engineer(4)  
> - Engraver(1)  
> - Farmer - Cabbage(8)  
> - Farmer - Cattle Herder(8)  
> - Farmer - Corn(8)  
> - Farmer - Cow Herder(8)  
> - Farmer - Dairy(8)  
> - Farmer - Goat Herder(8)  
> - Farmer - Pig Herder(8)  
> - Farmer - Potato(8)  
> - Farmer - Sheep Herder(8)  
> - Farmer - Wheat(8)  
> - Farmer(78)  
> - Farmer(Special)(8)  
> - Fisherman(1)  
> - Fishmonger(1)  
> - Florist(1)  
> - Furniture Maker(3)  
> - Furrier(4)  
> - Girdler(1)  
> - Glassblower(1)  
> - Glassblower(3)  
> - Glazier(1)  
> - Glove Merchant(3)  
> - Goldsmith(1)  
> - Goldsmith(1)  
> - Goon(4)  
> - Grocer(1)  
> - Guide(3)  
> - Haberdasher(1)  
> - Harness Maker(3)  
> - Hat Maker(1)  
> - Hay Merchant(1)  
> - Herbalist(1)  
> - High Priest(1)  
> - Homestead(103)  
> - Horse Trader(4)  
> - Huntsman(4)  
> - Illuminator(2)  
> - Innkeeper(3)  
> - Inventor(3)  
> - Jeweler(1)  
> - Jeweler(1)  
> - Judge(3)  
> - Knight(1)  
> - Laborer(4)  
> - Launderer(3)  
> - Launderer(3)  
> - Leatherworker(1)  
> - Leatherworker(2)  
> - Livestock Merchant(3)  
> - Locksmith(1)  
> - Lord(1)  
> - Mason(4)  
> - Mayor(1)  
> - Meat Butcher(1)  
> - Messenger(3)  
> - Miller(4)  
> - Minstrel(3)  
> - Missionary(11)  
> - Mountainman(1)  
> - Mountainman(8)  
> - Oil Trader(4)  
> - Oil Trader(4)  
> - Painter(Art)(3)  
> - Painter(Building)(4)  
> - Pastry Maker(1)  
> - Pathfinder(2)  
> - Perfumer(1)  
> - Physic/Chirurgeon(2)  
> - Pirate(4)  
> - Plasterer(4)  
> - Potionmakers(1)  
> - Potter(3)  
> - Preacher(7)  
> - Priest(4)  
> - Purse Maker(1)  
> - Roofer(4)  
> - Roofer(4)  
> - Rope Maker(2)  
> - Rug Maker(1)  
> - Saddler(2)  
> - Sail Maker(3)  
> - Sailor(6)  
> - Scout(1)  
> - Sculptor(1)  
> - Ship Builder(1)  
> - Shoe Maker(2)  
> - Shoe Maker(2)  
> - Silversmith(1)  
> - Silversmith(3)  
> - Skinner(1)  
> - Slaver(3)  
> - Slaver(3)  
> - Soap Maker(1)  
> - Spice Merchant(3)  
> - Spice Merchant(3)  
> - Stabler(3)  
> - Storyteller(3)  
> - Tailor(3)  
> - Tanner(1)  
> - Tanner(2)  
> - Tavern Keeper(3)  
> - Taxidermist(3)  
> - Taxidermist(3)  
> - Teamster(4)  
> - Tiler(4)  
> - Tinker(1)  
> - Tinker(4)  
> - Tobacco Merchant(3)  
> - Tobacco Merchant(3)  
> - Town Crier(5)  
> - Town Justice(2)  
> - Toymaker(1)  
> - Trading Post(4)  
> - Troubadours(3)  
> - Undertaker(1)  
> - Used Garment Trader(4)  
> - Vestment Maker(2)  
> - Vintner(1)  
> - Wagon Maker(3)  
> - Warehouser(3)  
> - Water Carrier(4)  
> - Weapon Dealer(3)  
> - Weapon Dealer(3)  
> - Weaver(3)  
> - Wheelwright(3)  
> - Wheelwright(4)  
> - Wine Merchant(2)  
> - Wood Carver(1)  
> - Wood Seller(1)  
> - Wool Merchant(2)  
> - Writer(3)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC


> ###### Notable Points of Interest
> ```dataview
table without ID file.link AS Name, wardType AS "Type"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC


## Notable Characters

> ###### Notable Characters
> ```dataview
table without ID file.link AS Name, race as Race, PrimaryOccupation as Profession
where kingdom=this.kingdom and settlementName=this.settlementName  and (fileType="npc"  and importance > 5)
sort importance DESC


## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



