---
cssclass: oRPGPage
fileType: settlement
settlementType: LargeTown
kingdom: KingdomName
region: RegionName
settlementName: Named LargeTown (4043)
terrain: Mountain Range 
settlementDescription: 
population: 4043
culture: Incan 
technology: Bronze Age 
leader: 
govermentType: Aristocracy 
demographics: 
- Acrobat(7) 
- Minstrel(7) 
- Storyteller(7) 
- Troubadours(7) 
- Writer(7) 
- Advocate(6) 
- Clerk(12) 
- Council Member(11) 
- Diplomat(2) 
- Judge(6) 
- Mayor(1) 
- Alchemist(4) 
- Chandler(11) 
- Dye Makers(11) 
- Florist(4) 
- Herbalist(4) 
- Potionmakers(4) 
- Sage(1) 
- Spice Merchant(7) 
- Taxidermist(7) 
- Tobacco Merchant(7) 
- Animal Groomer(3) 
- Animal Handler(7) 
- Caravanner(6) 
- Horse Trader(9) 
- Livestock Merchant(6) 
- Stabler(8) 
- Antiquities(7) 
- Armor Dealer(7) 
- Launderer(7) 
- Oil Trader(11) 
- Trading Post(11) 
- Slaver(7) 
- Spice Merchant(7) 
- Taxidermist(7) 
- Tobacco Merchant(7) 
- Warehouser(7) 
- Weapon Dealer(7) 
- Architect(9) 
- Bricklayer(9) 
- Engineer(9) 
- Laborer(9) 
- Mason(9) 
- Painter(Building)(9) 
- Plasterer(9) 
- Roofer(9) 
- Teamster(9) 
- Tiler(9) 
- Armorer(3) 
- Blacksmith(10) 
- Bowyer-Fletcher(4) 
- Jeweler(3) 
- Silversmith(3) 
- Weapon Dealer(7) 
- Weaponsmith(2) 
- Artist(9) 
- Glassblower(7) 
- Goldsmith(5) 
- Inventor(6) 
- Jeweler(5) 
- Magical Artisan(1) 
- Painter(Art)(8) 
- Silversmith(6) 
- Tinker(11) 
- Toymaker(4) 
- Astrologist(1) 
- Conjourer(1) 
- High Mage(1) 
- Historian(1) 
- Librarian(1) 
- Magical Artisan(1) 
- Magical Tutor(1) 
- Professor(1) 
- Scribe(1) 
- SellSpell(1) 
- Teacher(1) 
- Tutor(1) 
- Baker(7) 
- Beer Merchant(4) 
- Butcher(5) 
- Chicken Butcher(5) 
- Cook(5) 
- Dairy Seller(21) 
- Distiller(4) 
- Hay Merchant(21) 
- Fisherman(6) 
- Fishmonger(6) 
- Grain Merchant(1) 
- Grocer(3) 
- Meat Butcher(4) 
- Miller(11) 
- Pastry Maker(6) 
- Vintner(5) 
- Banker(3) 
- Pawnbroker(3) 
- Barbarian(21) 
- Brigand(21) 
- Captain(21) 
- Mountainman(21) 
- Barbarian(4) 
- Cartographer(4) 
- Guide(7) 
- Huntsman(11) 
- Mountainman(4) 
- Pathfinder(4) 
- Scout(4) 
- Slaver(7) 
- Barrel Maker(5) 
- Basket Maker(6) 
- Book Binder(3) 
- Bookseller(2) 
- Buckle Maker(4) 
- Candle Maker(3) 
- Clock Maker(1) 
- Cobbler(7) 
- Cooper(5) 
- Cutler(3) 
- Engraver(2) 
- Furniture Maker(7) 
- Glassblower(3) 
- Glazier(2) 
- Glove Merchant(6) 
- Goldsmith(3) 
- Harness Maker(7) 
- Hat Maker(3) 
- Instrument Maker(1) 
- Kettle Maker(2) 
- Locksmith(3) 
- Perfumer(3) 
- Potter(7) 
- Rope Maker(5) 
- Rug Maker(3) 
- Saddler(6) 
- Sculptor(2) 
- Shoe Maker(5) 
- Soap Maker(4) 
- Tanner(6) 
- Tinker(3) 
- Toymaker(1) 
- Weaponsmith(1) 
- Weaver(6) 
- Wheelwright(9) 
- Wine Merchant(4) 
- Wool Merchant(6) 
- Lord(2) 
- Knight(2) 
- Baron(1) 
- Barrel Maker(8) 
- Bowyer-Fletcher(4) 
- Carpenter(12) 
- Roofer(9) 
- Wagon Maker(6) 
- Wheelwright(7) 
- Wood Carver(4) 
- Wood Seller(3) 
- Barber(4) 
- Bleacher(4) 
- Physic/Chirurgeon(4) 
- Bather(3) 
- Brigand(7) 
- Crime Lord(1) 
- Crook(9) 
- Goon(9) 
- Brothel Keeper(3) 
- Innkeeper(6) 
- Tavern Keeper(8) 
- Buckle Maker(6) 
- Cobbler(5) 
- Draper(4) 
- Furrier(9) 
- Girdler(3) 
- Haberdasher(3) 
- Launderer(6) 
- Leatherworker(4) 
- Purse Maker(4) 
- Shoe Maker(5) 
- Tailor(6) 
- Tanner(6) 
- Used Garment Trader(9) 
- Vestment Maker(5) 
- Chandler(11) 
- Dye Makers(11) 
- Oil Trader(11) 
- Cleric(8) 
- High Priest(3) 
- Missionary(27) 
- Preacher(17) 
- Priest(9) 
- Farmer(203) 
- Homestead(270) 
- Farmer - Cabbage(21) 
- Farmer - Cattle Herder(21) 
- Farmer - Corn(21) 
- Farmer - Cow Herder(21) 
- Farmer - Dairy(21) 
- Farmer - Goat Herder(21) 
- Farmer - Pig Herder(21) 
- Farmer - Potato(21) 
- Farmer - Sheep Herder(21) 
- Farmer - Wheat(21) 
- Farmer(Special)(21) 
- Dungsweeper(6) 
- Illuminator(5) 
- Messenger(7) 
- Tax Collector(1) 
- Town Crier(12) 
- Town Justice(3) 
- Undertaker(3) 
- Water Carrier(9) 
- Leatherworker(5) 
- Skinner(5) 
- Naval Outfitter(3) 
- Pirate(11) 
- Sail Maker(6) 
- Sailor(14) 
- Ship Builder(3) 
imports: 
- Tin  
exports: 
- Tortoise Shells  
defenses: Stone Walls 
wards:
---



> [!infobox]
> # `=this.settlementType`
> **Pronounced:**  "`=this.Pronounced`"
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Type:** | `=this.settlementType` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` |
> **Kingdom/Region:** | `=link(this.kingdom)` |, `=link(this.region)` |
> **Terrain:** | `=this.terrain` |
> ###### Politics
>  |
> ---|---|
> **Ruler / Leaders:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> **Religion(s):** | `=link(this.religions)` |
> ###### Commerce/Trade
>  |
> ---|---|
> **Imports** | `=this.imports` |
> **Exports** | `=this.exports` |
> ###### Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.settlementName`**
> [!info|bg-c-purple] Overview
`=this.settlementDescription`

> [!info|bg-c-yellow]- Demographics
> List of demographics for the settlement:
> - Acrobat(7)  
> - Advocate(6)  
> - Alchemist(4)  
> - Animal Groomer(3)  
> - Animal Handler(7)  
> - Antiquities(7)  
> - Architect(9)  
> - Armor Dealer(7)  
> - Armorer(3)  
> - Artist(9)  
> - Astrologist(1)  
> - Baker(7)  
> - Banker(3)  
> - Barbarian(21)  
> - Barbarian(4)  
> - Barber(4)  
> - Baron(1)  
> - Barrel Maker(5)  
> - Barrel Maker(8)  
> - Basket Maker(6)  
> - Bather(3)  
> - Beer Merchant(4)  
> - Blacksmith(10)  
> - Bleacher(4)  
> - Book Binder(3)  
> - Bookseller(2)  
> - Bowyer-Fletcher(4)  
> - Bowyer-Fletcher(4)  
> - Bricklayer(9)  
> - Brigand(21)  
> - Brigand(7)  
> - Brothel Keeper(3)  
> - Buckle Maker(4)  
> - Buckle Maker(6)  
> - Butcher(5)  
> - Candle Maker(3)  
> - Captain(21)  
> - Caravanner(6)  
> - Carpenter(12)  
> - Cartographer(4)  
> - Chandler(11)  
> - Chandler(11)  
> - Chicken Butcher(5)  
> - Cleric(8)  
> - Clerk(12)  
> - Clock Maker(1)  
> - Cobbler(5)  
> - Cobbler(7)  
> - Conjourer(1)  
> - Cook(5)  
> - Cooper(5)  
> - Council Member(11)  
> - Crime Lord(1)  
> - Crook(9)  
> - Cutler(3)  
> - Dairy Seller(21)  
> - Diplomat(2)  
> - Distiller(4)  
> - Draper(4)  
> - Dungsweeper(6)  
> - Dye Makers(11)  
> - Dye Makers(11)  
> - Engineer(9)  
> - Engraver(2)  
> - Farmer - Cabbage(21)  
> - Farmer - Cattle Herder(21)  
> - Farmer - Corn(21)  
> - Farmer - Cow Herder(21)  
> - Farmer - Dairy(21)  
> - Farmer - Goat Herder(21)  
> - Farmer - Pig Herder(21)  
> - Farmer - Potato(21)  
> - Farmer - Sheep Herder(21)  
> - Farmer - Wheat(21)  
> - Farmer(203)  
> - Farmer(Special)(21)  
> - Fisherman(6)  
> - Fishmonger(6)  
> - Florist(4)  
> - Furniture Maker(7)  
> - Furrier(9)  
> - Girdler(3)  
> - Glassblower(3)  
> - Glassblower(7)  
> - Glazier(2)  
> - Glove Merchant(6)  
> - Goldsmith(3)  
> - Goldsmith(5)  
> - Goon(9)  
> - Grain Merchant(1)  
> - Grocer(3)  
> - Guide(7)  
> - Haberdasher(3)  
> - Harness Maker(7)  
> - Hat Maker(3)  
> - Hay Merchant(21)  
> - Herbalist(4)  
> - High Mage(1)  
> - High Priest(3)  
> - Historian(1)  
> - Homestead(270)  
> - Horse Trader(9)  
> - Huntsman(11)  
> - Illuminator(5)  
> - Innkeeper(6)  
> - Instrument Maker(1)  
> - Inventor(6)  
> - Jeweler(3)  
> - Jeweler(5)  
> - Judge(6)  
> - Kettle Maker(2)  
> - Knight(2)  
> - Laborer(9)  
> - Launderer(6)  
> - Launderer(7)  
> - Leatherworker(4)  
> - Leatherworker(5)  
> - Librarian(1)  
> - Livestock Merchant(6)  
> - Locksmith(3)  
> - Lord(2)  
> - Magical Artisan(1)  
> - Magical Artisan(1)  
> - Magical Tutor(1)  
> - Mason(9)  
> - Mayor(1)  
> - Meat Butcher(4)  
> - Messenger(7)  
> - Miller(11)  
> - Minstrel(7)  
> - Missionary(27)  
> - Mountainman(21)  
> - Mountainman(4)  
> - Naval Outfitter(3)  
> - Oil Trader(11)  
> - Oil Trader(11)  
> - Painter(Art)(8)  
> - Painter(Building)(9)  
> - Pastry Maker(6)  
> - Pathfinder(4)  
> - Pawnbroker(3)  
> - Perfumer(3)  
> - Physic/Chirurgeon(4)  
> - Pirate(11)  
> - Plasterer(9)  
> - Potionmakers(4)  
> - Potter(7)  
> - Preacher(17)  
> - Priest(9)  
> - Professor(1)  
> - Purse Maker(4)  
> - Roofer(9)  
> - Roofer(9)  
> - Rope Maker(5)  
> - Rug Maker(3)  
> - Saddler(6)  
> - Sage(1)  
> - Sail Maker(6)  
> - Sailor(14)  
> - Scout(4)  
> - Scribe(1)  
> - Sculptor(2)  
> - SellSpell(1)  
> - Ship Builder(3)  
> - Shoe Maker(5)  
> - Shoe Maker(5)  
> - Silversmith(3)  
> - Silversmith(6)  
> - Skinner(5)  
> - Slaver(7)  
> - Slaver(7)  
> - Soap Maker(4)  
> - Spice Merchant(7)  
> - Spice Merchant(7)  
> - Stabler(8)  
> - Storyteller(7)  
> - Tailor(6)  
> - Tanner(6)  
> - Tanner(6)  
> - Tavern Keeper(8)  
> - Tax Collector(1)  
> - Taxidermist(7)  
> - Taxidermist(7)  
> - Teacher(1)  
> - Teamster(9)  
> - Tiler(9)  
> - Tinker(11)  
> - Tinker(3)  
> - Tobacco Merchant(7)  
> - Tobacco Merchant(7)  
> - Town Crier(12)  
> - Town Justice(3)  
> - Toymaker(1)  
> - Toymaker(4)  
> - Trading Post(11)  
> - Troubadours(7)  
> - Tutor(1)  
> - Undertaker(3)  
> - Used Garment Trader(9)  
> - Vestment Maker(5)  
> - Vintner(5)  
> - Wagon Maker(6)  
> - Warehouser(7)  
> - Water Carrier(9)  
> - Weapon Dealer(7)  
> - Weapon Dealer(7)  
> - Weaponsmith(1)  
> - Weaponsmith(2)  
> - Weaver(6)  
> - Wheelwright(7)  
> - Wheelwright(9)  
> - Wine Merchant(4)  
> - Wood Carver(4)  
> - Wood Seller(3)  
> - Wool Merchant(6)  
> - Writer(7)  


## Notable Locations

> [!info|bg-c-purple]- Districts
> List of Districts for the settlement:
> ```dataview
table  without ID  "[[" + file.name + "|" + wardName + "]]" as Name, wardType as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC



> ###### Notable Shops/Services
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and structureType = "Profession"
SORT file.name ASC


> ###### Notable Points of Interest
> ```dataview
table without ID file.link AS Name, wardType AS "Type"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "ward"
SORT file.name ASC


## Notable Characters

> ###### Notable Characters
> ```dataview
table without ID file.link AS Name, race as Race, PrimaryOccupation as Profession
where kingdom=this.kingdom and settlementName=this.settlementName  and (fileType="npc"  and importance > 5)
sort importance DESC


## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



