getNPC get a NPC from the folder
   {folder path: "01. Worlds/Cevoria/- World Stuff/NPCs"}

__
```
^getNPC ?([a-zA-Z]*) ?(m*|f*|male*|female*)$
```
__
```js
let npcFolderPath = "01. Worlds/Cevoria/- World Stuff/NPCs";
//console.log("getNPC:", $1, $2);
// (?:m|M|male|Male|f|F|female|Female)
delete _inlineScripts.state.sessionState.nPick["NPCS"];
//console.log("Race:" + $1);
//console.log("Gender:" + $2);
let data = expand(
    "selectNPCFrontMatter \"" + npcFolderPath + "\" " + $1 + " " + $2);

if (!data) {
    return "Unable to get any NPC(s)";
}
//console.log("Name from getNPC:", data);

// Create link to the NPC
result = "[[" + data + "]]\n";

return result;
```
__
getNPC {race name: text} {gender: m|f|male|female} - Randomly selects a NPC from Folder(variable: npcFolderPath).
  - __Parameters:__
    - __race__ (Optional) The race you are searching for (human/halfling/half-elf/etc). 
    - __gender__ (Optional) The gender you are looking for (m|f|male|female). Race must be passed in to pass in gender.
  - __Examples:__
    - `;;getNPC halfling female::`
    - `;;getNPC halfling::`
    - `;;getNPC::`


__
```
^selectNPCFrontMatter (".+") ?([a-zA-Z]*) ?(m*|f*|male*|female*)$ 
```
__
```js
// Remove any quotes around the folder path
//console.log("selectNPCFrontMatter", $1, $2, $3);
//console.log("Race:" + $2);
//console.log("Gender:" + $3);


let result = expUnformat(
    expand("getFolderFiles " + $1 ));
//console.log("Session", _inlineScripts.state.sessionState.nPick["NPCS"]);
//console.log("Result:", result);
//let filesSelected =  _inlineScripts.state.sessionState.nPick["NPCS"];

// Get the front matter for the items.  If error, early-out.
result = expUnformat(expand("getFrontmatter NPCS" ));
//console.log("Result:", result);
if (!result[0]) { return expFormat(result); }

let folderFiles = result[1];
//console.log("selectNPCFrontMatter", $2, $3);
let selectedFiles = [];
Object.keys(folderFiles).sort().forEach(function(key,index) {
    console.log(key);
    //console.log(folderFiles[key]);

    let match = false;
    if ($2.trim().length > 0) {
        let fileRace = folderFiles[key].Race;
        if (typeof fileRace != undefined )  {
            if (fileRace.toUpperCase().trim() === $2.toUpperCase().trim()) {
                match = true;
            } else {
            }
        }
        
        if ($3.trim().length > 0) {
            let fileGender = folderFiles[key].Gender;
            if ((typeof fileGender != undefined ) && (match)) {
                if (fileGender.toUpperCase().trim() === $3.toUpperCase().trim()) {
                    match = true;
                } else {
                    match = false;
                }
            } 
        } 
    } else {
        match = true;
    }

    if (match) {
        selectedFiles.push(key);
    }
    
});

//console.log("Selected Files:", selectedFiles);
return selectedFiles[Math.floor(Math.random() * selectedFiles.length)];
```
__
selectNPCFrontMatter {folder name: path text}


__
```
^getFolderFiles ("[^ \t\\:*?"<>|][^\t\\:*?"<>|]*"|[^ \t\\:*?"<>|]+)$
```
__
```js
// Remove any quotes around the folder path
$1 = $1.replace(/^"(.*)"$/, "$1");

// Get the file object for the given folder.  Early out of doesn't exist or is a file
const folder = app.vault.fileMap[$1];
if (!folder)
{
	return expFormat([ "","No files picked.  Folder __" + $1 + "__ doesn't exist." ]);
}
if (!folder.children)
{
	return expFormat([ "", "No files picked.  __" + $1 + "__ isn't a folder." ]);
}

// Get the non-folder children of folder
let files = folder.children.filter(v => !v.children).map(v => v.path);

// Remove the files excluded by the "to ignore" parameter
//files = files.filter(v => !$4.includes(v));

// If file count is under the pick count, early out.
if (files.length < 1)
{
	return expFormat(
		[ "", "No files picked.  Not enough files in Folder __" + $1 + "__." ]);
}

// Randomly pick <count> of the files.
//console.log("Files selected:", files.length);
//console.log(files);

// Add the files picked to the state
_inlineScripts.state.sessionState.nPick["NPCS"] = files;

return expFormat([ files.length + " file(s) picked." ]);
```
__
getFolderFiles {folder name: path text}


__
```
^getFrontmatter ?([_a-zA-Z][_a-zA-Z]*|)$
```
__
```js
//console.log("getFrontmatter:", $1);
// Get the specified pick from the state.  Early out if specified pick isn't stored.
const pick = _inlineScripts.state.sessionState.nPick[$1];
if (!pick) {
    //console.log("NO PICK?", pick);
	return expFormat(
		[ "", "No frontmatter gathered.  Pick id __" + $1 + "__ not found." ]);
}
//console.log("PICK:", pick);

// Get the file objects of the picks
const files = pick.map(v => app.vault.fileMap[v]);

// Confirm that all picks have valid file objects.  If not, early out.
for (let i = 0; i < pick.length; i++)
{
	if (!files[i])
	{
		return expFormat(
			[ "", "No frontmatter gathered.  __" + fileNotFound + "__ not found." ]);
	}
}

// Get the frontmatter for each of the picks.
let result = {};
for (const file of files)
{
	result[file.name.replace(/.md$/, "")] =
		app.metadataCache.getFileCache(file).frontmatter || {};
}

return expFormat(
	[ "Frontmatter gathered for " + pick.length + " note(s).\n", result, "" ]);
```
__
getFrontmatter {pick id: name text, default: ""} - Gets the frontmatter from the notes that are remembered in {pick id}.

