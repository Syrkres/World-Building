# Inline Scripts for Settlements 


The following inline scripts are good to use for working with the settlements, or selecting NPCs.

There are currently three scripts included:
;; getNPC - use for randomly selecting an unused NPC 
;; getProf - use for selecting an unused Profession 
;; getWard - used for selecting unused Ward


### Paths variables:
let wardFolderPath = "01. Worlds/Cevoria/- World Stuff/Wards";
let professionFolderPath = "01. Worlds/Cevoria/- World Stuff/Professions";
let npcFolderPath = "01. Worlds/Cevoria/- World Stuff/NPCs";

