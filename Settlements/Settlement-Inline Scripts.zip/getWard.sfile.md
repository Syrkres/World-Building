getWard get a ward type from the folder
   {folder path: "01. Worlds/Cevoria/- World Stuff/wards"}

__
```
^getWard$
```
__
```js
let wardFolderPath = "01. Worlds/Cevoria/- World Stuff/Wards";
//console.log("getWard:", $1);
delete _inlineScripts.state.sessionState.nPick["WARDS"];
//console.log("Searching for ward:" + $1);
let data = expand("selectWardFrontMatter \"" + wardFolderPath + "\"");

if (!data) {
    return "Unable to get any wards(s)";
}

// Create link to the ward
result = "[[" + data + "]]\n";

return result;
```
__
getWard - Randomly selects a ward from Folder(variable: wardFolderPath) that has "No Owner Assigned" (ownerName).
  - __Parameters:__
    - __None__ 
  - __Examples:__
    - `;;getWard::`


__
```
^selectWardFrontMatter (".+")$ 
```
__
```js
//console.log("selectWardFrontMatter:", $1, $2);
let result = expUnformat(expand("getWardFolderFiles " + $1 ));

// Get the front matter for the items.  If error, early-out.
result = expUnformat(expand("getWardFrontmatter WARDS" ));
//console.log("Result:", result);
if (!result[0]) { return expFormat(result); }

let folderFiles = result[1];
//console.log("selectWardFrontMatter", $2);
let selectedFiles = [];
Object.keys(folderFiles).sort().forEach(function(key,index) {
    let match = false;
    console.log("Owner[" + folderFiles[key].ownerName + "]")
    if (folderFiles[key].settlementName === "Not Assigned") {
            match = true;
    }

    if (match) {
        selectedFiles.push(key);
    }
    
});

//console.log("Selected Files:", selectedFiles);
return selectedFiles[Math.floor(Math.random() * selectedFiles.length)];
```
__
selectWardFrontMatter {folder name: path text}


__
```
^getWardFolderFiles ("[^ \t\\:*?"<>|][^\t\\:*?"<>|]*"|[^ \t\\:*?"<>|]+)$
```
__
```js
// Remove any quotes around the folder path
$1 = $1.replace(/^"(.*)"$/, "$1");

//console.log("getWardFolderFiles", $1);

// Get the file object for the given folder.  Early out of doesn't exist or is a file
const folder = app.vault.fileMap[$1];
if (!folder)
{
	return expFormat([ "","No files selected.  Folder __" + $1 + "__ doesn't exist." ]);
}
if (!folder.children)
{
	return expFormat([ "", "No files selected.  __" + $1 + "__ isn't a folder." ]);
}

// Get the non-folder children of folder
let files = folder.children.filter(v => !v.children).map(v => v.path);

// If file count is under the pick count, early out.
if (files.length < 1)
{
	return expFormat(
		[ "", "No files picked.  Not enough files in Folder __" + $1 + "__." ]);
}

// Add the files picked to the state
_inlineScripts.state.sessionState.nPick["WARDS"] = files;

return expFormat([ files.length + " file(s) picked." ]);
```
__
getWardFolderFiles {folder name: path text}


__
```
^getWardFrontmatter ?([_a-zA-Z][_a-zA-Z]*|)$
```
__
```js
//console.log("getWardFrontmatter:", $1);
// Get the specified pick from the state.  Early out if specified pick isn't stored.
const pick = _inlineScripts.state.sessionState.nPick["WARDS"];
if (!pick) {
    //console.log("NO PICK?", pick);
	return expFormat(
		[ "", "No frontmatter gathered.  Note: __" + pick + "__ not found." ]);
}
// Get the file objects of the picks
const files = pick.map(v => app.vault.fileMap[v]);

// Confirm that all picks have valid file objects.  If not, early out.
for (let i = 0; i < pick.length; i++)
{
	if (!files[i])
	{
		return expFormat(
			[ "", "No frontmatter gathered.  __" + fileNotFound + "__ not found." ]);
	}
}

// Get the frontmatter for each of the picks.
let result = {};
for (const file of files)
{
	result[file.name.replace(/.md$/, "")] =
		app.metadataCache.getFileCache(file).frontmatter || {};
}

return expFormat(
	[ "Frontmatter gathered for " + pick.length + " note(s).\n", result, "" ]);
```
__
getWardFrontmatter {pick id: name text, default: ""} - Gets the frontmatter from the notes that are remembered in {pick id}.

