getProf get a Profession type from the folder
   {folder path: "01. Worlds/Cevoria/- World Stuff/Professions"}

__
```
^getProf ?([a-zA-Z]*)$
```
__
```js
let professionFolderPath = "01. Worlds/Cevoria/- World Stuff/Professions";
//console.log("getProf:", $1);
delete _inlineScripts.state.sessionState.nPick["PROF"];
//console.log("Searching for Profession:" + $1);
let data = expand(
    "selectProfessionFrontMatter \"" + professionFolderPath + "\" " + $1);

if (!data) {
    return "Unable to get any Professions(s)";
}

// Create link to the Profession
result = "[[" + data + "]]\n";

return result;
```
__
getProf {profession name: text}  - Randomly selects a profession from Folder(variable: professionFolderPath) that has "No Owner Assigned" (ownerName).
  - __Parameters:__
    - __profession-type__ (Optional) The profession you are searching for (Tavern/Farmer/etc). 
  - __Examples:__
    - `;;getProf Tavern::`
    - `;;getProf::`


__
```
^selectProfessionFrontMatter (".+") ?([a-zA-Z]*)$ 
```
__
```js
//console.log("selectProfessionFrontMatter:", $1, $2);
let result = expUnformat(
    expand("getProfessionFolderFiles " + $1 ));

// Get the front matter for the items.  If error, early-out.
result = expUnformat(expand("getProfessionFrontmatter PROF" ));
//console.log("Result:", result);
if (!result[0]) { return expFormat(result); }

let folderFiles = result[1];
//console.log("selectProfessionFrontMatter", $2);
let selectedFiles = [];
Object.keys(folderFiles).sort().forEach(function(key,index) {
    //console.log("Checking FrontMatter");
    //console.log(key);
    //console.log(folderFiles[key]);
    let match = false;
    console.log("Owner[" + folderFiles[key].ownerName + "]")
    if (folderFiles[key].ownerName === "No Owner Assigned") {
        if ($2.trim().length > 0) {
            let merchantType = folderFiles[key].merchantType;

            // If merchantType matches
            if (typeof merchantType != undefined )  {
                if (merchantType.toUpperCase().trim().indexOf($2.toUpperCase().trim()) > -1) {
                    match = true;
                } 
            } 

            // If category matches
            let merchantCategory = folderFiles[key].merchantCategory;
            if (typeof merchantCategory != undefined )  {
                if (merchantCategory.toUpperCase().trim().indexOf($2.toUpperCase().trim()) > -1) {
                    match = true;
                }
            }
            
        } else {
            match = true;
        }
    }

    if (match) {
        selectedFiles.push(key);
    }
    
});

//console.log("Selected Files:", selectedFiles);
return selectedFiles[Math.floor(Math.random() * selectedFiles.length)];
```
__
selectProfessionFrontMatter {folder name: path text}


__
```
^getProfessionFolderFiles ("[^ \t\\:*?"<>|][^\t\\:*?"<>|]*"|[^ \t\\:*?"<>|]+)$
```
__
```js
// Remove any quotes around the folder path
$1 = $1.replace(/^"(.*)"$/, "$1");

//console.log("getProfessionFolderFiles", $1);

// Get the file object for the given folder.  Early out of doesn't exist or is a file
const folder = app.vault.fileMap[$1];
if (!folder)
{
	return expFormat([ "","No files selected.  Folder __" + $1 + "__ doesn't exist." ]);
}
if (!folder.children)
{
	return expFormat([ "", "No files selected.  __" + $1 + "__ isn't a folder." ]);
}

// Get the non-folder children of folder
let files = folder.children.filter(v => !v.children).map(v => v.path);

// If file count is under the pick count, early out.
if (files.length < 1)
{
	return expFormat(
		[ "", "No files picked.  Not enough files in Folder __" + $1 + "__." ]);
}

// Add the files picked to the state
_inlineScripts.state.sessionState.nPick["PROF"] = files;

return expFormat([ files.length + " file(s) picked." ]);
```
__
getProfessionFolderFiles {folder name: path text}


__
```
^getProfessionFrontmatter ?([_a-zA-Z][_a-zA-Z]*|)$
```
__
```js
//console.log("getProfessionFrontmatter:", $1);
// Get the specified pick from the state.  Early out if specified pick isn't stored.
const pick = _inlineScripts.state.sessionState.nPick["PROF"];
if (!pick) {
    //console.log("NO PICK?", pick);
	return expFormat(
		[ "", "No frontmatter gathered.  Note: __" + pick + "__ not found." ]);
}
// Get the file objects of the picks
const files = pick.map(v => app.vault.fileMap[v]);

// Confirm that all picks have valid file objects.  If not, early out.
for (let i = 0; i < pick.length; i++)
{
	if (!files[i])
	{
		return expFormat(
			[ "", "No frontmatter gathered.  __" + fileNotFound + "__ not found." ]);
	}
}

// Get the frontmatter for each of the picks.
let result = {};
for (const file of files)
{
	result[file.name.replace(/.md$/, "")] =
		app.metadataCache.getFileCache(file).frontmatter || {};
}

return expFormat(
	[ "Frontmatter gathered for " + pick.length + " note(s).\n", result, "" ]);
```
__
getProfessionFrontmatter {pick id: name text, default: ""} - Gets the frontmatter from the notes that are remembered in {pick id}.

