---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Conjourer 
merchantCategory: Entertainer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: Ye Summoned Stone 
ownerName: Jeardra Zaiganthym 
ownerLink: "[[Conjourer(Entertainer) - Jeardra Zaiganthym|Jeardra Zaiganthym]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Entertainer( Average   quality, High  costs) 
- Performance( Low   quality, Below Average  costs) 
exterior: An new building with new paint and with planked siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Entertainer |  Average   quality |  High  costs | 
> | Performance |  Low   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

