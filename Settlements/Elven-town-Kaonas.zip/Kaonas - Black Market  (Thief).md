---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thief 
merchantCategory: Criminal
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: Black Market 
ownerName: Aumrauth Tinvihamraheal 
ownerLink: "[[Thief(Criminal) - Aumrauth Tinvihamraheal|Aumrauth Tinvihamraheal]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Criminal( Low   quality, Below Average  costs) 
- Deception( Good   quality, Low  costs) 
exterior: An new building with faded paint and with planked siding with a few round windows. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Criminal |  Low   quality |  Below Average  costs | 
> | Deception |  Good   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

