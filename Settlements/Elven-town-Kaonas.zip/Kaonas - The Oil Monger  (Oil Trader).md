---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Oil Trader 
merchantCategory: Merchant
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Grove 
structure: SHOP,HOUSE
title: The Oil Monger 
ownerName: Rychell Ilwylwovalsa 
ownerLink: "[[Oil Trader(Merchant) - Rychell Ilwylwovalsa|Rychell Ilwylwovalsa]]"
ownerRace: High  Elf
apprentices: 
- Wharton (Mature Adult ) Male who is Sick  
- Upton (Mature Adult ) Female who is Healthy  
services: 
- Merchant( Low   quality, Below Average  costs) 
- Oil Trader( Poor   quality, Low  costs) 
exterior: An long two story building with new paint and with brick siding with a front short window that has a carved sign hanging to the side with the merchants name. The roof is Celing. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Low   quality |  Below Average  costs | 
> | Oil Trader |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Wharton  | Mature Adult  |  Male who is Sick   | 
>> | Upton  | Mature Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

