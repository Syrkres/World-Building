---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: PawnBroker 
merchantCategory: Specialty Service
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: ComePound 
ownerName: Taegen Salinathem 
ownerLink: "[[PawnBroker(Specialty Service) - Taegen Salinathem|Taegen Salinathem]]"
ownerRace: Elf
apprentices: 
- Hallewell (Teen ) Female who is Ailing  
services: 
- Money Lender( Good   quality, Low  costs) 
- Trader( Average   quality, Above Average  costs) 
exterior: An one story building with new paint and with planked siding. The roof is House. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Money Lender |  Good   quality |  Low  costs | 
> | Trader |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hallewell  | Teen  |  Female who is Ailing   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

