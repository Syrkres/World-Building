---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Merc 
merchantCategory: Merc
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: JAIL,HOUSE
title: Company Hall 
ownerName: Ruith Ideasanea 
ownerLink: "[[Merc(Merc) - Ruith Ideasanea|Ruith Ideasanea]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Mercenary( Low   quality, Above Average  costs) 
- Intimidation( Average   quality, Below Average  costs) 
- Guarding( Excellent   quality, High  costs) 
exterior: An old two story building with faded paint and with shingled siding. The roof is Dome. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Low   quality |  Above Average  costs | 
> | Intimidation |  Average   quality |  Below Average  costs | 
> | Guarding |  Excellent   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

