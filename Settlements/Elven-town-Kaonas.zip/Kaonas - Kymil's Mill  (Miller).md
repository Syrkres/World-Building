---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Miller 
merchantCategory: Cook
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: SHOP,HOUSE
title: Kymil's Mill 
ownerName: Kymil Krargolsithek 
ownerLink: "[[Miller(Cook) - Kymil Krargolsithek|Kymil Krargolsithek]]"
ownerRace: Elf
apprentices: 
- Tindall (Young Adult ) Female who is Healthy  
- Winthrop (Teen ) Female who is All Right  
services: 
- Miller( Good   quality, Low  costs) 
- Harvester( Average   quality, High  costs) 
exterior: An new long building with brick siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Miller |  Good   quality |  Low  costs | 
> | Harvester |  Average   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Tindall  | Young Adult  |  Female who is Healthy   | 
>> | Winthrop  | Teen  |  Female who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

