---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities 
merchantCategory: Merchant
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,EXOTIC ARTISAN
title: The old The new Table     
ownerName: Hycis Henziovalsa 
ownerLink: "[[Antiquities(Merchant) - Hycis Henziovalsa|Hycis Henziovalsa]]"
ownerRace: Elf
apprentices: 
- Read (Teen ) Female who is Healthy  
services: 
- Merchant( Low   quality, Average  costs) 
- Item Research( Average   quality, Low  costs) 
exterior: An new building with faded paint and with shingled siding. The roof is Canopy. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Low   quality |  Average  costs | 
> | Item Research |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Read  | Teen  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

