---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chicken Butcher 
merchantCategory: Cook
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: 
structure: SHOP,HOUSE
title: Ye Plucked Kingfisher 
ownerName: Faeranduil Invusomathem 
ownerLink: "[[Chicken Butcher(Cook) - Faeranduil Invusomathem|Faeranduil Invusomathem]]"
ownerRace: High  Elf
apprentices: 
- Yardley (Young Adult ) Female who is All Right  
services: 
- Cook( Poor   quality, High  costs) 
- Meat Processing( Good   quality, Low  costs) 
exterior: An old building with planked siding with a missing short window. The roof is Canopy. A Oak pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Poor   quality |  High  costs | 
> | Meat Processing |  Good   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Yardley  | Young Adult  |  Female who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

