---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Elected Official 
merchantCategory: Elected Official
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: JAIL,HOUSE
title: County Clerks 
ownerName: Haalaari Aritianitryn 
ownerLink: "[[Elected Official(Elected Official) - Haalaari Aritianitryn|Haalaari Aritianitryn]]"
ownerRace: High  Elf
apprentices: 
- Wedgwood (Teen ) Female who is Unwell  
- Ramsay (Young Adult ) Female who is Healthy  
services: 
- Elected Official( Good   quality, Below Average  costs) 
- Diplomacy( Poor   quality, Below Average  costs) 
- Clerk( Low   quality, Low  costs) 
- Administration( Horrible   quality, Low  costs) 
exterior: An new building with planked siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is Celing. A Yellow Birch shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Elected Official |  Good   quality |  Below Average  costs | 
> | Diplomacy |  Poor   quality |  Below Average  costs | 
> | Clerk |  Low   quality |  Low  costs | 
> | Administration |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Wedgwood  | Teen  |  Female who is Unwell   | 
>> | Ramsay  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

