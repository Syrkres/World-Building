---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barrel Maker 
merchantCategory: Craftsman
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: The Beech chest Maker 
ownerName: Moryggan Aldreelrvis 
ownerLink: "[[Barrel Maker(Craftsman) - Moryggan Aldreelrvis|Moryggan Aldreelrvis]]"
ownerRace: High  Elf
apprentices: 
- Charlton (Young Adult ) Male who is Indisposed  
services: 
- Craftsman( Average   quality, Above Average  costs) 
- Barrel Crafting( Poor   quality, High  costs) 
exterior: An old building with new paint and with planked siding with a front round boarded window that has a sign hanging above with the merchants name. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Average   quality |  Above Average  costs | 
> | Barrel Crafting |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Charlton  | Young Adult  |  Male who is Indisposed   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

