---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Kettle Maker 
merchantCategory: Craftsman
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: The Adamentite Pan 
ownerName: Aermhar Pemyrrae 
ownerLink: "[[Kettle Maker(Craftsman) - Aermhar Pemyrrae|Aermhar Pemyrrae]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Craftsman( Good   quality, Low  costs) 
- Merchant( Good   quality, Above Average  costs) 
exterior: An long building with planked siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Good   quality |  Low  costs | 
> | Merchant |  Good   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

