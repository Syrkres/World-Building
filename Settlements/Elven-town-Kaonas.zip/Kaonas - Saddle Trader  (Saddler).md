---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Saddler 
merchantCategory: Craftsman
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: Saddle Trader 
ownerName: Ondroth Arkeneaanea 
ownerLink: "[[Saddler(Craftsman) - Ondroth Arkeneaanea|Ondroth Arkeneaanea]]"
ownerRace: Elf
apprentices: 
- Hartford (Adult ) Female who is Healthy  
- Morton (Young Adult ) Female who is Fit  
services: 
- Craftsman( Average   quality, Average  costs) 
- Saddler( Horrible   quality, Above Average  costs) 
exterior: An new narrow tall building with faded paint and with planked siding with a few tall boarded windows. The roof is Canopy. A Beech shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Average   quality |  Average  costs | 
> | Saddler |  Horrible   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hartford  | Adult  |  Female who is Healthy   | 
>> | Morton  | Young Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

