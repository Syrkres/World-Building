---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Goon 
merchantCategory: Criminal
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: JAIL,HOUSE
title: TAVERNSHOPNAME 
ownerName: Maasli Migalanea 
ownerLink: "[[Goon(Criminal) - Maasli Migalanea|Maasli Migalanea]]"
ownerRace: Elf
apprentices: 
- Atterton (Young Adult ) Female who is Healthy  
services: 
- Criminal( Low   quality, Below Average  costs) 
- Deception( Low   quality, High  costs) 
- Enforcement( Horrible   quality, Average  costs) 
- Guarding( Poor   quality, Below Average  costs) 
exterior: An long two story building with shingled siding with a missing short window. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Criminal |  Low   quality |  Below Average  costs | 
> | Deception |  Low   quality |  High  costs | 
> | Enforcement |  Horrible   quality |  Average  costs | 
> | Guarding |  Poor   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Atterton  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

