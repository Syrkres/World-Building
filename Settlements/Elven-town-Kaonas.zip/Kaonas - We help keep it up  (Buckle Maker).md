---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Buckle Maker 
merchantCategory: Garment Trade
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: We help keep it up 
ownerName: Khaalindaan Ilerylghymn 
ownerLink: "[[Buckle Maker(Garment Trade) - Khaalindaan Ilerylghymn|Khaalindaan Ilerylghymn]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Garment Trade( Average   quality, High  costs) 
- Crafting( Horrible   quality, Low  costs) 
exterior: An building with new paint and with shingled siding with a few shuttered windows. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Average   quality |  High  costs | 
> | Crafting |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

