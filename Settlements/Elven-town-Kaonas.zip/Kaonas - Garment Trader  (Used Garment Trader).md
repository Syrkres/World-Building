---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Used Garment Trader 
merchantCategory: Garment Trade
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: Garment Trader 
ownerName: Filaurel Urlinindlues 
ownerLink: "[[Used Garment Trader(Garment Trade) - Filaurel Urlinindlues|Filaurel Urlinindlues]]"
ownerRace: Elf
apprentices: 
- Bristol (Teen ) Female who is Inured  
services: 
- Garment Trade( Low   quality, Average  costs) 
- Trader( Excellent   quality, Above Average  costs) 
exterior: An old narrow building with stoned siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Low   quality |  Average  costs | 
> | Trader |  Excellent   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Bristol  | Teen  |  Female who is Inured   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

