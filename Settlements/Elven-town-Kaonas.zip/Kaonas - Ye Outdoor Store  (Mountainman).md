---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Mountainman 
merchantCategory: Tracker
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: Ye Outdoor Store 
ownerName: Quamara Arabighymn 
ownerLink: "[[Mountainman(Tracker) - Quamara Arabighymn|Quamara Arabighymn]]"
ownerRace: Wood Elf
apprentices: 
- England (Young Adult ) Male who is Healthy  
- Anderton (Teen ) Female who is Inured  
services: 
- Tracker( Average   quality, High  costs) 
- Hunting( Excellent   quality, Above Average  costs) 
exterior: An long one story building with brick siding. The roof is Celing. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Tracker |  Average   quality |  High  costs | 
> | Hunting |  Excellent   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | England  | Young Adult  |  Male who is Healthy   | 
>> | Anderton  | Teen  |  Female who is Inured   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

