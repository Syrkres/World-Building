---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wagon Maker 
merchantCategory: Craftsman
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Grove 
structure: SHOP,HOUSE
title: Wagon Maker 
ownerName: Estelar Nelumtlarn 
ownerLink: "[[Wagon Maker(Craftsman) - Estelar Nelumtlarn|Estelar Nelumtlarn]]"
ownerRace: High  Elf
apprentices: 
- Altham (Young Adult ) Female who is Hurt  
- Winterbourne (Mature Adult ) Female who is Fit  
services: 
- Craftsman( Excellent   quality, High  costs) 
- Wagon Maker( Average   quality, Below Average  costs) 
exterior: An old building with new paint and with brick siding. The roof is Celing. A Beech shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Excellent   quality |  High  costs | 
> | Wagon Maker |  Average   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Altham  | Young Adult  |  Female who is Hurt   | 
>> | Winterbourne  | Mature Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

