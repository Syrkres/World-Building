---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Magical Tutor 
merchantCategory: Sage
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,ALCHEMIST
title: Ye Inventive Tutor 
ownerName: Ornthalas Heasitlithar 
ownerLink: "[[Magical Tutor(Sage) - Ornthalas Heasitlithar|Ornthalas Heasitlithar]]"
ownerRace: Wood Elf
apprentices: 
- Myerscough (Teen ) Female who is Healthy  
- Astley (Young Adult ) Male who is Wounded  
services: 
- Sage( Good   quality, High  costs) 
- Spell Research( Excellent   quality, Above Average  costs) 
- Spell Learning( Average   quality, High  costs) 
exterior: An narrow building with shingled siding. The roof is Roof. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Good   quality |  High  costs | 
> | Spell Research |  Excellent   quality |  Above Average  costs | 
> | Spell Learning |  Average   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Myerscough  | Teen  |  Female who is Healthy   | 
>> | Astley  | Young Adult  |  Male who is Wounded   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

