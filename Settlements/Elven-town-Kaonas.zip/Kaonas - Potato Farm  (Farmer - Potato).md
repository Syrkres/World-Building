---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Potato 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: FARM,HOUSE
title: Potato Farm 
ownerName: Thasitalia Ailonathem 
ownerLink: "[[Farmer - Potato(Farmer) - Thasitalia Ailonathem|Thasitalia Ailonathem]]"
ownerRace: High  Elf
apprentices: 
- Sutton (Teen ) Female who is Not oneself  
- Darlington (Adult ) Male who is Well  
services: 
- Farmer( Average   quality, Low  costs) 
- Food( Poor   quality, Below Average  costs) 
exterior: An new building with shingled siding with a few windows. The roof is Canopy. A Hickory shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Average   quality |  Low  costs | 
> | Food |  Poor   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Sutton  | Teen  |  Female who is Not oneself   | 
>> | Darlington  | Adult  |  Male who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

