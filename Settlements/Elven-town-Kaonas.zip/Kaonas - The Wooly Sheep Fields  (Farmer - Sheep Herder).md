---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Sheep Herder 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: FARM,HOUSE
title: The Wooly Sheep Fields 
ownerName: Pyrravym Imesahitryn 
ownerLink: "[[Farmer - Sheep Herder(Farmer) - Pyrravym Imesahitryn|Pyrravym Imesahitryn]]"
ownerRace: Wood Elf
apprentices: 
- Bradley (Young Adult ) Male who is Healthy  
services: 
- Farmer( Horrible   quality, Above Average  costs) 
- Food( Low   quality, Below Average  costs) 
- Herding( Average   quality, Average  costs) 
exterior: An new one story building with faded paint and with brick siding with a few windows. The roof is Dome. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Horrible   quality |  Above Average  costs | 
> | Food |  Low   quality |  Below Average  costs | 
> | Herding |  Average   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Bradley  | Young Adult  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

