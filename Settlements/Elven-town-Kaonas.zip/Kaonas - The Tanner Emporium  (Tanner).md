---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tanner 
merchantCategory: Craftsman
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: The Tanner Emporium 
ownerName: Iolas Salinurdrenn 
ownerLink: "[[Tanner(Craftsman) - Iolas Salinurdrenn|Iolas Salinurdrenn]]"
ownerRace: Elf
apprentices: 
- Stafford (Teen ) Female who is Healthy  
services: 
- Craftsman( Poor   quality, Average  costs) 
- Tanner( Poor   quality, High  costs) 
exterior: An narrow building with new paint and with shingled siding with a few windows. The roof is Celing. A Maple shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Poor   quality |  Average  costs | 
> | Tanner |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Stafford  | Teen  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

