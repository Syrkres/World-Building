---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Soap Maker 
merchantCategory: Craftsman
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: Soap Hawker 
ownerName: Calarel Wyvulrretyn 
ownerLink: "[[Soap Maker(Craftsman) - Calarel Wyvulrretyn|Calarel Wyvulrretyn]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Craftsman( Excellent   quality, Above Average  costs) 
- Soap Maker( Excellent   quality, Above Average  costs) 
exterior: An two story building with faded paint and with stoned siding. The roof is House. A Elm shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Excellent   quality |  Above Average  costs | 
> | Soap Maker |  Excellent   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

