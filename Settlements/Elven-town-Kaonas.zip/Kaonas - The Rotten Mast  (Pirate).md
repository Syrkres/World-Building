---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Pirate 
merchantCategory: Merc
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: The Rotten Mast 
ownerName: Anfalen Purginwainarnith 
ownerLink: "[[Pirate(Merc) - Anfalen Purginwainarnith|Anfalen Purginwainarnith]]"
ownerRace: Wood Elf
apprentices: 
- Thackeray (Young Adult ) Male who is Dying  
services: 
- Mercenary( Excellent   quality, Average  costs) 
- Intimidation( Low   quality, Average  costs) 
- Shipping( Good   quality, Average  costs) 
- Guarding( Low   quality, Average  costs) 
exterior: An long two story building with new paint and with shingled siding with a front tall broken window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Excellent   quality |  Average  costs | 
> | Intimidation |  Low   quality |  Average  costs | 
> | Shipping |  Good   quality |  Average  costs | 
> | Guarding |  Low   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Thackeray  | Young Adult  |  Male who is Dying   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

