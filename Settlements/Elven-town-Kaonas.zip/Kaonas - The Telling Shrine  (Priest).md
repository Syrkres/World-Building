---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Priest 
merchantCategory: Clergy
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHRINE,HOUSE
title: The Telling Shrine 
ownerName: Iefyr Aleamitore 
ownerLink: "[[Priest(Clergy) - Iefyr Aleamitore|Iefyr Aleamitore]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Clergy( Horrible   quality, Below Average  costs) 
- Religion( Poor   quality, Average  costs) 
- Healing( Poor   quality, Below Average  costs) 
exterior: An one story building with faded paint and with brick siding with a front short boarded window that has a painted sign hanging above with the merchants name. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Horrible   quality |  Below Average  costs | 
> | Religion |  Poor   quality |  Average  costs | 
> | Healing |  Poor   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

