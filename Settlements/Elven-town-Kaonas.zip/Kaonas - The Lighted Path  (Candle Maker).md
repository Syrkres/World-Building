---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Candle Maker 
merchantCategory: Specialty Service
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: The Lighted Path 
ownerName: Raerauntha Hubugonsithek 
ownerLink: "[[Candle Maker(Specialty Service) - Raerauntha Hubugonsithek|Raerauntha Hubugonsithek]]"
ownerRace: High  Elf
apprentices: 
- Dalton (Adult ) Male who is Fine  
services: 
- Specialty Service( Poor   quality, High  costs) 
- Candle Making( Low   quality, Above Average  costs) 
exterior: An building with brick siding with a front broken window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Specialty Service |  Poor   quality |  High  costs | 
> | Candle Making |  Low   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Dalton  | Adult  |  Male who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

