---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crime Lord 
merchantCategory: Criminal
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: The Black Book 
ownerName: Schimae Zuldrinnddare 
ownerLink: "[[Crime Lord(Criminal) - Schimae Zuldrinnddare|Schimae Zuldrinnddare]]"
ownerRace: Wood Elf
apprentices: 
- Churchill (Mature Adult ) Male who is Healthy  
- Beverly (Adult ) Female who is Fit  
services: 
- Blackmarket( Low   quality, High  costs) 
- Merchant( Horrible   quality, Above Average  costs) 
- Transfer of Goods( Poor   quality, Low  costs) 
exterior: An two story building with shingled siding with a front short window that has a carved sign hanging to the side with the merchants name. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Blackmarket |  Low   quality |  High  costs | 
> | Merchant |  Horrible   quality |  Above Average  costs | 
> | Transfer of Goods |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Churchill  | Mature Adult  |  Male who is Healthy   | 
>> | Beverly  | Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

