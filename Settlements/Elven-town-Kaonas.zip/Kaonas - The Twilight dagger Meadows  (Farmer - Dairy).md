---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Dairy 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: FARM,HOUSE
title: The Twilight dagger Meadows 
ownerName: Nueleth Eyllistlithar 
ownerLink: "[[Farmer - Dairy(Farmer) - Nueleth Eyllistlithar|Nueleth Eyllistlithar]]"
ownerRace: Wood Elf
apprentices: 
- Hayden (Young Adult ) Female who is All Right  
services: 
- Farmer( Horrible   quality, Average  costs) 
- Milk( Average   quality, Above Average  costs) 
- Food( Poor   quality, Average  costs) 
exterior: An new tall building with planked siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Horrible   quality |  Average  costs | 
> | Milk |  Average   quality |  Above Average  costs | 
> | Food |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hayden  | Young Adult  |  Female who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

