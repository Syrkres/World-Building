---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Fishmonger 
merchantCategory: Cook
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: The Trout Maker 
ownerName: Ysmyrlda Maernrretyn 
ownerLink: "[[Fishmonger(Cook) - Ysmyrlda Maernrretyn|Ysmyrlda Maernrretyn]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Cook( Poor   quality, Low  costs) 
- Food( Poor   quality, High  costs) 
exterior: An old long building with shingled siding with a missing short window. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Poor   quality |  Low  costs | 
> | Food |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

