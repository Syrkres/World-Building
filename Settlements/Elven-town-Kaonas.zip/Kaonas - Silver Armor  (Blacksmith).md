---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Blacksmith 
merchantCategory: Blacksmith
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: 
structure: SHOP,SMITHY
title: Silver Armor 
ownerName: Eallyrl Gyssevalsa 
ownerLink: "[[Blacksmith(Blacksmith) - Eallyrl Gyssevalsa|Eallyrl Gyssevalsa]]"
ownerRace: Elf
apprentices: 
- Allerton (Young Adult ) Female who is Scraped up  
- Yardley (Young Adult ) Female who is Healthy  
services: 
- Metal Craftsman( Excellent   quality, Below Average  costs) 
- Blacksmithing( Poor   quality, Low  costs) 
exterior: An long one story building with faded paint and with shingled siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Metal Craftsman |  Excellent   quality |  Below Average  costs | 
> | Blacksmithing |  Poor   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Allerton  | Young Adult  |  Female who is Scraped up   | 
>> | Yardley  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

