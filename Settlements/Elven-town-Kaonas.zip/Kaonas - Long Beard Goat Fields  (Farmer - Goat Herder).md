---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Goat Herder 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: FARM,HOUSE
title: Long Beard Goat Fields 
ownerName: Dalyor Prosperghymn 
ownerLink: "[[Farmer - Goat Herder(Farmer) - Dalyor Prosperghymn|Dalyor Prosperghymn]]"
ownerRace: High  Elf
apprentices: 
- Ryley (Young Adult ) Male who is Deceased  
services: 
- Farmer( Excellent   quality, Above Average  costs) 
- Food( Excellent   quality, Below Average  costs) 
- Herding( Average   quality, Low  costs) 
exterior: An building with faded paint and with stoned siding. The roof is Canopy. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Excellent   quality |  Above Average  costs | 
> | Food |  Excellent   quality |  Below Average  costs | 
> | Herding |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Ryley  | Young Adult  |  Male who is Deceased   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

