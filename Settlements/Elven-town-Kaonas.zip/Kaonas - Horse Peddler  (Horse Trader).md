---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Horse Trader 
merchantCategory: Merchant
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: Horse Peddler 
ownerName: Neldor Ideasneldth 
ownerLink: "[[Horse Trader(Merchant) - Neldor Ideasneldth|Neldor Ideasneldth]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Horse Trading( Excellent   quality, Average  costs) 
- Trader( Average   quality, Above Average  costs) 
- Horse Breeding( Average   quality, Low  costs) 
exterior: An new two story building with shingled siding with a few windows. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Horse Trading |  Excellent   quality |  Average  costs | 
> | Trader |  Average   quality |  Above Average  costs | 
> | Horse Breeding |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

