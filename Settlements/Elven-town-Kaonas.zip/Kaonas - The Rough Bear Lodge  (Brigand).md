---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand 
merchantCategory: Merc
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: JAIL,HOUSE
title: The Rough Bear Lodge 
ownerName: Sudryl Dryearmitore 
ownerLink: "[[Brigand(Merc) - Sudryl Dryearmitore|Sudryl Dryearmitore]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Mercenary( Poor   quality, High  costs) 
- Enforcement( Horrible   quality, High  costs) 
- Intimidation( Low   quality, Above Average  costs) 
exterior: An building with stoned siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Poor   quality |  High  costs | 
> | Enforcement |  Horrible   quality |  High  costs | 
> | Intimidation |  Low   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

