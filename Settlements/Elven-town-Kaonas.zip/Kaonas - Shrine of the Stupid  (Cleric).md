---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric 
merchantCategory: Clergy
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHRINE,HOUSE
title: Shrine of the Stupid 
ownerName: Ruavia Vulrarvirrea 
ownerLink: "[[Cleric(Clergy) - Ruavia Vulrarvirrea|Ruavia Vulrarvirrea]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Clergy( Average   quality, High  costs) 
- Religion( Excellent   quality, Above Average  costs) 
- House of Worship( Low   quality, High  costs) 
- Curse Removal( Excellent   quality, Low  costs) 
- Spell Research( Good   quality, Low  costs) 
- Healing( Good   quality, Average  costs) 
- Potions( Average   quality, Above Average  costs) 
exterior: An new two story building with shingled siding. The roof is Dome. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Average   quality |  High  costs | 
> | Religion |  Excellent   quality |  Above Average  costs | 
> | House of Worship |  Low   quality |  High  costs | 
> | Curse Removal |  Excellent   quality |  Low  costs | 
> | Spell Research |  Good   quality |  Low  costs | 
> | Healing |  Good   quality |  Average  costs | 
> | Potions |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

