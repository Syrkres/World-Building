---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Silversmith 
merchantCategory: Artisan
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: The old Market Stall 
ownerName: Pleufan Wikrimeplith 
ownerLink: "[[Silversmith(Artisan) - Pleufan Wikrimeplith|Pleufan Wikrimeplith]]"
ownerRace: Elf
apprentices: 
- Yeardley (Young Adult ) Male who is Not oneself  
services: 
- Jewelery Crafting( Excellent   quality, Above Average  costs) 
- Silver Crafting( Poor   quality, Below Average  costs) 
- Gem Cutting( Low   quality, High  costs) 
exterior: An old long building with shingled siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Jewelery Crafting |  Excellent   quality |  Above Average  costs | 
> | Silver Crafting |  Poor   quality |  Below Average  costs | 
> | Gem Cutting |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Yeardley  | Young Adult  |  Male who is Not oneself   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

