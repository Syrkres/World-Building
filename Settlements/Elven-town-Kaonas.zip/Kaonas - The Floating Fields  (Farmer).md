---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: The Floating Fields 
ownerName: Ynshael Tinvihamrretyn 
ownerLink: "[[Farmer(Farmer) - Ynshael Tinvihamrretyn|Ynshael Tinvihamrretyn]]"
ownerRace: High  Elf
apprentices: 
- Hale (Teen ) Male who is Healthy  
- Colby (Young Adult ) Male who is Dead  
services: 
- Farmer( Low   quality, Above Average  costs) 
- Food( Excellent   quality, Low  costs) 
exterior: An old two story building with new paint and with brick siding with a front tall window that has a painted sign hanging above with the merchants name. The roof is Canopy. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Low   quality |  Above Average  costs | 
> | Food |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hale  | Teen  |  Male who is Healthy   | 
>> | Colby  | Young Adult  |  Male who is Dead   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

