---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Stabler 
merchantCategory: Animal Handler
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: SHOP,HOUSE
title: Stabler 
ownerName: Yrneha Krargolarnith 
ownerLink: "[[Stabler(Animal Handler) - Yrneha Krargolarnith|Yrneha Krargolarnith]]"
ownerRace: Elf
apprentices: 
- Windsor (Young Adult ) Male who is Scraped up  
- Lincoln (Young Adult ) Female who is Dead  
services: 
- Animal Handler( Horrible   quality, Below Average  costs) 
- Stabler( Good   quality, Low  costs) 
exterior: An new building with faded paint and with shingled siding with a front window that has a painted sign hanging above with the merchants name. The roof is Canopy. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Horrible   quality |  Below Average  costs | 
> | Stabler |  Good   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Windsor  | Young Adult  |  Male who is Scraped up   | 
>> | Lincoln  | Young Adult  |  Female who is Dead   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

