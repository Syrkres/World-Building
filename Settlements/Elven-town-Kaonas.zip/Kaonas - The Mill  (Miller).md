---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Miller 
merchantCategory: Cook
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: The Mill 
ownerName: Tiriara Opulumatear 
ownerLink: "[[Miller(Cook) - Tiriara Opulumatear|Tiriara Opulumatear]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Miller( Excellent   quality, Low  costs) 
- Harvester( Low   quality, High  costs) 
exterior: An long building with faded paint and with shingled siding. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Miller |  Excellent   quality |  Low  costs | 
> | Harvester |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

