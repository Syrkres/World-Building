---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Shoe Maker 
merchantCategory: Garment Trade
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: Shoe Maker 
ownerName: Mylaerla Ulinkenvirrea 
ownerLink: "[[Shoe Maker(Garment Trade) - Mylaerla Ulinkenvirrea|Mylaerla Ulinkenvirrea]]"
ownerRace: High  Elf
apprentices: 
- Clinton (Young Adult ) Female who is Sick  
services: 
- Garment Trade( Low   quality, Below Average  costs) 
- Shoe Maker( Poor   quality, Below Average  costs) 
exterior: An long building with brick siding with a few tall boarded windows. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Low   quality |  Below Average  costs | 
> | Shoe Maker |  Poor   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Clinton  | Young Adult  |  Female who is Sick   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

