---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Taverner 
merchantCategory: Hostelers
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: The Running Leopard Pub 
ownerName: Illitran Baequivalsa 
ownerLink: "[[Taverner(Hostelers) - Illitran Baequivalsa|Illitran Baequivalsa]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Eatery( Horrible   quality, Average  costs) 
- Room (Sleeping)( Excellent   quality, Low  costs) 
- Common Room (Sleeping)( Low   quality, Above Average  costs) 
- Room (Meeting)( Excellent   quality, Average  costs) 
exterior: An old long building with shingled siding with a few boarded windows. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Eatery |  Horrible   quality |  Average  costs | 
> | Room  | Sleeping | ( Excellent   quality | 
> | Common Room  | Sleeping | ( Low   quality | 
> | Room  | Meeting | ( Excellent   quality | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

