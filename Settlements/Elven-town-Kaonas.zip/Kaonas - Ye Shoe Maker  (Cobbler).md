---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cobbler 
merchantCategory: Garment Trade
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: Ye Shoe Maker 
ownerName: Rathiain Bilnenkerae 
ownerLink: "[[Cobbler(Garment Trade) - Rathiain Bilnenkerae|Rathiain Bilnenkerae]]"
ownerRace: Wood Elf
apprentices: 
- Alston (Adult ) Female who is Fit  
services: 
- Garment Trade( Good   quality, High  costs) 
- Shoe Repair( Poor   quality, Above Average  costs) 
exterior: An new building with brick siding with a missing tall window. The roof is Roof. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Good   quality |  High  costs | 
> | Shoe Repair |  Poor   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Alston  | Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

