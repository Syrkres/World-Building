---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Scribe 
merchantCategory: Professional Specialties
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHRINE,ALCHEMIST
title: Scribes Reseller 
ownerName: Renestrae Denkervalsa 
ownerLink: "[[Scribe(Professional Specialties) - Renestrae Denkervalsa|Renestrae Denkervalsa]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Research( Good   quality, Above Average  costs) 
- Scribe( Good   quality, Low  costs) 
exterior: An building with faded paint and with brick siding with a few tall windows. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Research |  Good   quality |  Above Average  costs | 
> | Scribe |  Good   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

