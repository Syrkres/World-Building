---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Laborer 
merchantCategory: Laborer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: Club Hall 
ownerName: Haladavar Tyrtlithar 
ownerLink: "[[Laborer(Laborer) - Haladavar Tyrtlithar|Haladavar Tyrtlithar]]"
ownerRace: Elf
apprentices: 
- Read (Young Adult ) Female who is Fit  
services: 
- Laborer( Low   quality, Average  costs) 
exterior: An new two story building with planked siding with a front round broken window that has a painted sign hanging above with the merchants name. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Laborer |  Low   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Read  | Young Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

