---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crook 
merchantCategory: Criminal
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: Pawn Shop 
ownerName: Ioelena Ailonnddare 
ownerLink: "[[Crook(Criminal) - Ioelena Ailonnddare|Ioelena Ailonnddare]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Criminal( Poor   quality, High  costs) 
- Deception( Poor   quality, Average  costs) 
- Theft( Poor   quality, High  costs) 
exterior: An new narrow tall building with brick siding with a missing round window. The roof is Celing. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Criminal |  Poor   quality |  High  costs | 
> | Deception |  Poor   quality |  Average  costs | 
> | Theft |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

