---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer(Special) 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: FARM,HOUSE
title: This Unique Past farm 
ownerName: Napraeleon Crogreltalanea 
ownerLink: "[[Farmer(Special)(Farmer) - Napraeleon Crogreltalanea|Napraeleon Crogreltalanea]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Farmer( Horrible   quality, Above Average  costs) 
- Food( Horrible   quality, Average  costs) 
- Herding( Horrible   quality, Average  costs) 
exterior: An new two story building with new paint and with planked siding with a missing window. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Horrible   quality |  Above Average  costs | 
> | Food |  Horrible   quality |  Average  costs | 
> | Herding |  Horrible   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

