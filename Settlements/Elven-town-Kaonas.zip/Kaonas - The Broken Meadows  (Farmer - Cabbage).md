---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cabbage 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: FARM,HOUSE
title: The Broken Meadows 
ownerName: Sakrattars Aritianundlin 
ownerLink: "[[Farmer - Cabbage(Farmer) - Sakrattars Aritianundlin|Sakrattars Aritianundlin]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Farmer( Low   quality, Above Average  costs) 
- Food( Horrible   quality, Average  costs) 
exterior: An building with shingled siding with a few shuttered windows. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Low   quality |  Above Average  costs | 
> | Food |  Horrible   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

