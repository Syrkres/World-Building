---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Herbalist 
merchantCategory: Professional Specialties
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,ALCHEMIST
title: The Dark Brown Emporium 
ownerName: Mariona Beltinghymn 
ownerLink: "[[Herbalist(Professional Specialties) - Mariona Beltinghymn|Mariona Beltinghymn]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Professional Specialties( Low   quality, Average  costs) 
- Healing( Excellent   quality, Low  costs) 
- Potion Brewing( Average   quality, Below Average  costs) 
- Remedy Crafting( Horrible   quality, Below Average  costs) 
exterior: An two story building with stoned siding with a front round boarded window that has a carved sign hanging to the side with the merchants name. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Low   quality |  Average  costs | 
> | Healing |  Excellent   quality |  Low  costs | 
> | Potion Brewing |  Average   quality |  Below Average  costs | 
> | Remedy Crafting |  Horrible   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

