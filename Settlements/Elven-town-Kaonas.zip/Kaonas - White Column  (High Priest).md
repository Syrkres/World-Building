---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Priest 
merchantCategory: Clergy
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHRINE,HOUSE
title: White Column 
ownerName: Beldroth Perlelaltin 
ownerLink: "[[High Priest(Clergy) - Beldroth Perlelaltin|Beldroth Perlelaltin]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Clergy( Good   quality, Above Average  costs) 
- Scroll Crafting( Poor   quality, High  costs) 
- Potion Crafting( Low   quality, Below Average  costs) 
- Spell Research( Low   quality, Average  costs) 
- Healing( Average   quality, Above Average  costs) 
exterior: An tall building with new paint and with planked siding with a front round window that has a painted sign hanging above with the merchants name. The roof is Celing. A Yellow Birch shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Good   quality |  Above Average  costs | 
> | Scroll Crafting |  Poor   quality |  High  costs | 
> | Potion Crafting |  Low   quality |  Below Average  costs | 
> | Spell Research |  Low   quality |  Average  costs | 
> | Healing |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

