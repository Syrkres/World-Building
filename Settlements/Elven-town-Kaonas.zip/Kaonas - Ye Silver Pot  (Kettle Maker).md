---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Kettle Maker 
merchantCategory: Craftsman
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Grove 
structure: SHOP,HOUSE
title: Ye Silver Pot 
ownerName: Rubrae Takelsedlues 
ownerLink: "[[Kettle Maker(Craftsman) - Rubrae Takelsedlues|Rubrae Takelsedlues]]"
ownerRace: Elf
apprentices: 
- Asheton (Teen ) Female who is Not oneself  
services: 
- Craftsman( Excellent   quality, Average  costs) 
- Merchant( Good   quality, Low  costs) 
exterior: An old building with new paint and with stoned siding. The roof is Dome. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Excellent   quality |  Average  costs | 
> | Merchant |  Good   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Asheton  | Teen  |  Female who is Not oneself   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

