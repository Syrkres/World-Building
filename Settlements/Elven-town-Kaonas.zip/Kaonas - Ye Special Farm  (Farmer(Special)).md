---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer(Special) 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: FARM,HOUSE
title: Ye Special Farm 
ownerName: Namyriitha Ulmenraheal 
ownerLink: "[[Farmer(Special)(Farmer) - Namyriitha Ulmenraheal|Namyriitha Ulmenraheal]]"
ownerRace: Wood Elf
apprentices: 
- Thornton (Teen ) Male who is Dying  
services: 
- Farmer( Average   quality, Average  costs) 
- Food( Excellent   quality, Low  costs) 
- Herding( Good   quality, Average  costs) 
exterior: An building with faded paint and with planked siding with a few windows. The roof is Canopy. A Beech pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Average   quality |  Average  costs | 
> | Food |  Excellent   quality |  Low  costs | 
> | Herding |  Good   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Thornton  | Teen  |  Male who is Dying   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

