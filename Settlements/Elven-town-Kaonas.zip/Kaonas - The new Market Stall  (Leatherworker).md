---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Leatherworker 
merchantCategory: Craftsman
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: The new Market Stall 
ownerName: Tammson Voldrelundlin 
ownerLink: "[[Leatherworker(Craftsman) - Tammson Voldrelundlin|Tammson Voldrelundlin]]"
ownerRace: Elf
apprentices: 
- Astley (Teen ) Male who is Healthy  
services: 
- Craftsman( Good   quality, High  costs) 
- Tanner( Good   quality, High  costs) 
- Taxidermy( Average   quality, Low  costs) 
exterior: An new one story building with new paint and with stoned siding with a missing window. The roof is House. A Yellow Birch shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Good   quality |  High  costs | 
> | Tanner |  Good   quality |  High  costs | 
> | Taxidermy |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Astley  | Teen  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

