---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tailor 
merchantCategory: Garment Trade
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: The Fit Tailor 
ownerName: Caerthynna Tyrrretyn 
ownerLink: "[[Tailor(Garment Trade) - Caerthynna Tyrrretyn|Caerthynna Tyrrretyn]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Garment Trade( Good   quality, Average  costs) 
- Tailor( Low   quality, Low  costs) 
exterior: An narrow one story building with new paint and with shingled siding with a few short windows. The roof is Roof. A Maple shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Good   quality |  Average  costs | 
> | Tailor |  Low   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

