---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Merc 
merchantCategory: Merc
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: JAIL,HOUSE
title: Federation Hall 
ownerName: Erlathan Killelylth 
ownerLink: "[[Merc(Merc) - Erlathan Killelylth|Erlathan Killelylth]]"
ownerRace: Wood Elf
apprentices: 
- Morton (Adult ) Female who is All Right  
services: 
- Mercenary( Horrible   quality, Average  costs) 
- Intimidation( Good   quality, High  costs) 
- Guarding( Low   quality, Low  costs) 
exterior: An old one story building with new paint and with stoned siding. The roof is Canopy. A Elm pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Horrible   quality |  Average  costs | 
> | Intimidation |  Good   quality |  High  costs | 
> | Guarding |  Low   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Morton  | Adult  |  Female who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

