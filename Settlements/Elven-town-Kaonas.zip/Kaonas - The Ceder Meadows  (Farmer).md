---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: The Ceder Meadows 
ownerName: Fhaornik Kelrarannia 
ownerLink: "[[Farmer(Farmer) - Fhaornik Kelrarannia|Fhaornik Kelrarannia]]"
ownerRace: High  Elf
apprentices: 
- Hamilton (Teen ) Female who is Fit as a fiddle  
services: 
- Farmer( Good   quality, Low  costs) 
- Food( Low   quality, Average  costs) 
exterior: An narrow one story building with brick siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Good   quality |  Low  costs | 
> | Food |  Low   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hamilton  | Teen  |  Female who is Fit as a fiddle   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

