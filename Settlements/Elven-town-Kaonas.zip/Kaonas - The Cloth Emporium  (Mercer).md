---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Mercer 
merchantCategory: Garment Trade
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: The Cloth Emporium 
ownerName: Ralikanthae Osupraaltin 
ownerLink: "[[Mercer(Garment Trade) - Ralikanthae Osupraaltin|Ralikanthae Osupraaltin]]"
ownerRace: High  Elf
apprentices: 
- Cromwell (Young Adult ) Female who is Healthy  
- Bradley (Teen ) Male who is Inured  
services: 
- Garment Trade( Average   quality, Average  costs) 
- Trader( Low   quality, Above Average  costs) 
exterior: An long building with new paint and with stoned siding. The roof is Dome. A Beech shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Average   quality |  Average  costs | 
> | Trader |  Low   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Cromwell  | Young Adult  |  Female who is Healthy   | 
>> | Bradley  | Teen  |  Male who is Inured   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

