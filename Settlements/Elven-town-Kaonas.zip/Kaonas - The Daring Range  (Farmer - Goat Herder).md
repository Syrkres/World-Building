---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Goat Herder 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: FARM,HOUSE
title: The Daring Range 
ownerName: Taranath Eytherurdrenn 
ownerLink: "[[Farmer - Goat Herder(Farmer) - Taranath Eytherurdrenn|Taranath Eytherurdrenn]]"
ownerRace: Elf
apprentices: 
- Weston (Teen ) Female who is Indisposed  
- Stanton (Teen ) Male who is Dying  
services: 
- Farmer( Average   quality, High  costs) 
- Food( Horrible   quality, Average  costs) 
- Herding( Average   quality, Low  costs) 
exterior: An old narrow two story building with brick siding with a front tall broken window that has a carved sign hanging to the side with the merchants name. The roof is Celing. A Maple pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Average   quality |  High  costs | 
> | Food |  Horrible   quality |  Average  costs | 
> | Herding |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Weston  | Teen  |  Female who is Indisposed   | 
>> | Stanton  | Teen  |  Male who is Dying   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

