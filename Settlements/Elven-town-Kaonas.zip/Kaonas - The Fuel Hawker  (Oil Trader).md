---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Oil Trader 
merchantCategory: Merchant
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: The Fuel Hawker 
ownerName: Katyr Ideashutanea 
ownerLink: "[[Oil Trader(Merchant) - Katyr Ideashutanea|Katyr Ideashutanea]]"
ownerRace: Elf
apprentices: 
- Hamilton (Child ) Male who is Inured  
- Charlton (Adult ) Female who is Dying  
services: 
- Merchant( Poor   quality, Below Average  costs) 
- Oil Trader( Low   quality, High  costs) 
exterior: An building with faded paint and with planked siding with a missing short window. The roof is Roof. A Hickory shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Poor   quality |  Below Average  costs | 
> | Oil Trader |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hamilton  | Child  |  Male who is Inured   | 
>> | Charlton  | Adult  |  Female who is Dying   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

