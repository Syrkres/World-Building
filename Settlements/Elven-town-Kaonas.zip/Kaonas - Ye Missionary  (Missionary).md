---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Missionary 
merchantCategory: Clergy
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHRINE,HOUSE
title: Ye Missionary 
ownerName: Valindra Norrerretyn 
ownerLink: "[[Missionary(Clergy) - Valindra Norrerretyn|Valindra Norrerretyn]]"
ownerRace: Wood Elf
apprentices: 
- Winthrop (Teen ) Male who is Not oneself  
services: 
- Clergy( Poor   quality, High  costs) 
- Religion( Poor   quality, High  costs) 
- Remedies( Average   quality, Low  costs) 
exterior: An tall building with planked siding with a few tall windows. The roof is Roof. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Poor   quality |  High  costs | 
> | Religion |  Poor   quality |  High  costs | 
> | Remedies |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Winthrop  | Teen  |  Male who is Not oneself   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

