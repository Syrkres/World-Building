---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Thug 
merchantCategory: Criminal
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: The Running Tigger Pub 
ownerName: Selgauth Myrthghymn 
ownerLink: "[[Thug(Criminal) - Selgauth Myrthghymn|Selgauth Myrthghymn]]"
ownerRace: Elf
apprentices: 
- Livingstone (Teen ) Male who is Dead  
services: 
- Criminal( Horrible   quality, Average  costs) 
- Deception( Horrible   quality, Below Average  costs) 
- Guarding( Average   quality, Above Average  costs) 
exterior: An two story building with faded paint and with brick siding. The roof is Canopy. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Criminal |  Horrible   quality |  Average  costs | 
> | Deception |  Horrible   quality |  Below Average  costs | 
> | Guarding |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Livingstone  | Teen  |  Male who is Dead   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

