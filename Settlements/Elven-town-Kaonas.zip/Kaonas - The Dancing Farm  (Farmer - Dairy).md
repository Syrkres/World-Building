---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Dairy 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: FARM,HOUSE
title: The Dancing Farm 
ownerName: Emmyth Ilenatear 
ownerLink: "[[Farmer - Dairy(Farmer) - Emmyth Ilenatear|Emmyth Ilenatear]]"
ownerRace: Elf
apprentices: 
- Clayton (Adult ) Male who is Inured  
services: 
- Farmer( Average   quality, Average  costs) 
- Milk( Average   quality, Above Average  costs) 
- Food( Average   quality, Above Average  costs) 
exterior: An new tall building with new paint and with planked siding with a front tall shuttered window that has a carved sign hanging to the side with the merchants name. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Average   quality |  Average  costs | 
> | Milk |  Average   quality |  Above Average  costs | 
> | Food |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Clayton  | Adult  |  Male who is Inured   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

