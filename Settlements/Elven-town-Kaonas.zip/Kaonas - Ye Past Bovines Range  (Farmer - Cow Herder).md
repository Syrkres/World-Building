---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cow Herder 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: FARM,HOUSE
title: Ye Past Bovines Range 
ownerName: Lathai Boltolarnith 
ownerLink: "[[Farmer - Cow Herder(Farmer) - Lathai Boltolarnith|Lathai Boltolarnith]]"
ownerRace: Elf
apprentices: 
- Shelly (Child ) Female who is Fit  
- Elton (Young Adult ) Male who is Fit  
services: 
- Farmer( Average   quality, High  costs) 
- Food( Excellent   quality, Low  costs) 
exterior: An building with faded paint and with planked siding. The roof is House. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Average   quality |  High  costs | 
> | Food |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Shelly  | Child  |  Female who is Fit   | 
>> | Elton  | Young Adult  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

