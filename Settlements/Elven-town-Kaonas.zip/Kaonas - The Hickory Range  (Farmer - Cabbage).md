---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cabbage 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: FARM,HOUSE
title: The Hickory Range 
ownerName: Anaharae Nelumzea 
ownerLink: "[[Farmer - Cabbage(Farmer) - Anaharae Nelumzea|Anaharae Nelumzea]]"
ownerRace: Wood Elf
apprentices: 
- Stanford (Teen ) Male who is Healthy  
services: 
- Farmer( Good   quality, Low  costs) 
- Food( Low   quality, High  costs) 
exterior: An tall building with faded paint and with shingled siding with a missing window. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Good   quality |  Low  costs | 
> | Food |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Stanford  | Teen  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

