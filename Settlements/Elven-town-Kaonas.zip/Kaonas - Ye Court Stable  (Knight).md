---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Knight 
merchantCategory: Knight
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: Ye Court Stable 
ownerName: Naevys Auvrealylth 
ownerLink: "[[Knight(Knight) - Naevys Auvrealylth|Naevys Auvrealylth]]"
ownerRace: Wood Elf
apprentices: 
- Lindsay (Teen ) Male who is Ailing  
- Richmond (Young Adult ) Male who is Fine  
services: 
- Guard( Poor   quality, High  costs) 
- Religion( Good   quality, Below Average  costs) 
exterior: An long tall building with faded paint and with planked siding. The roof is Dome. A Elm shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Guard |  Poor   quality |  High  costs | 
> | Religion |  Good   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Lindsay  | Teen  |  Male who is Ailing   | 
>> | Richmond  | Young Adult  |  Male who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

