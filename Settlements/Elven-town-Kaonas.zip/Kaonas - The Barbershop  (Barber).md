---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barber 
merchantCategory: Specialty Service
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: The Barbershop 
ownerName: Seanchai Lonmumtlarn 
ownerLink: "[[Barber(Specialty Service) - Seanchai Lonmumtlarn|Seanchai Lonmumtlarn]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Specialty Service( Average   quality, Low  costs) 
- Surgery( Excellent   quality, Low  costs) 
exterior: An old one story building with shingled siding with a missing tall window. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Specialty Service |  Average   quality |  Low  costs | 
> | Surgery |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

