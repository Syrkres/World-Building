---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Teamster 
merchantCategory: Laborer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: Order Structure 
ownerName: Lathai Vitarizea 
ownerLink: "[[Teamster(Laborer) - Lathai Vitarizea|Lathai Vitarizea]]"
ownerRace: Wood Elf
apprentices: 
- Remington (Young Adult ) Female who is Expired  
- Gresham (Young Adult ) Male who is Healthy  
services: 
- Laborer( Good   quality, Below Average  costs) 
- Teamster( Average   quality, High  costs) 
exterior: An one story building with shingled siding. The roof is House. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Laborer |  Good   quality |  Below Average  costs | 
> | Teamster |  Average   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Remington  | Young Adult  |  Female who is Expired   | 
>> | Gresham  | Young Adult  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

