---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cow Herder 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: FARM,HOUSE
title: Ye Old Pine Farm 
ownerName: Kahvoerm Boltolitryn 
ownerLink: "[[Farmer - Cow Herder(Farmer) - Kahvoerm Boltolitryn|Kahvoerm Boltolitryn]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Farmer( Horrible   quality, Average  costs) 
- Food( Average   quality, High  costs) 
exterior: An one story building with new paint and with planked siding with a few broken windows. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Horrible   quality |  Average  costs | 
> | Food |  Average   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

