---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wheelwright 
merchantCategory: Craftsman
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: Wheelright 
ownerName: Aesar Zuldrinmitore 
ownerLink: "[[Wheelwright(Craftsman) - Aesar Zuldrinmitore|Aesar Zuldrinmitore]]"
ownerRace: Wood Elf
apprentices: 
- Eastaughffe (Young Adult ) Female who is Fit  
services: 
- Craftsman( Poor   quality, Average  costs) 
- Wheelwright( Average   quality, Low  costs) 
exterior: An long two story building with stoned siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Poor   quality |  Average  costs | 
> | Wheelwright |  Average   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Eastaughffe  | Young Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

