---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Jeweler 
merchantCategory: Artisan
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: 
structure: SHOP,HOUSE
title: Ye Gold Ring 
ownerName: Oslarelar Ideasluxlylth 
ownerLink: "[[Jeweler(Artisan) - Oslarelar Ideasluxlylth|Oslarelar Ideasluxlylth]]"
ownerRace: High  Elf
apprentices: 
- Ashley (Young Adult ) Male who is Well  
- Leighton (Adult ) Female who is Fit  
services: 
- Jewelery Crafting( Average   quality, Low  costs) 
- Craft( Excellent   quality, Above Average  costs) 
- Gem Cutting( Low   quality, Below Average  costs) 
exterior: An new tall building with faded paint and with planked siding with a few tall windows. The roof is Canopy. A Beech shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Jewelery Crafting |  Average   quality |  Low  costs | 
> | Craft |  Excellent   quality |  Above Average  costs | 
> | Gem Cutting |  Low   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Ashley  | Young Adult  |  Male who is Well   | 
>> | Leighton  | Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

