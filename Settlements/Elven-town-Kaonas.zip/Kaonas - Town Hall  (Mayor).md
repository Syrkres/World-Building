---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Mayor 
merchantCategory: Elected Official
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: Town Hall 
ownerName: Zabbas Denkerneldth 
ownerLink: "[[Mayor(Elected Official) - Zabbas Denkerneldth|Zabbas Denkerneldth]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Elected Official( Excellent   quality, High  costs) 
- Diplomacy( Horrible   quality, Low  costs) 
exterior: An new building with stoned siding with a few broken windows. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Elected Official |  Excellent   quality |  High  costs | 
> | Diplomacy |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

