---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Pig Herder 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: FARM,HOUSE
title: Ye Solid Hog Monger 
ownerName: Lianthorn Zuldrinsithek 
ownerLink: "[[Farmer - Pig Herder(Farmer) - Lianthorn Zuldrinsithek|Lianthorn Zuldrinsithek]]"
ownerRace: High  Elf
apprentices: 
- Wesley (Young Adult ) Male who is Fine  
services: 
- Farmer( Excellent   quality, High  costs) 
- Food( Good   quality, Low  costs) 
- Herding( Excellent   quality, Low  costs) 
exterior: An building with new paint and with shingled siding with a front window that has a sign hanging above with the merchants name. The roof is Canopy. A Pine shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Excellent   quality |  High  costs | 
> | Food |  Good   quality |  Low  costs | 
> | Herding |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Wesley  | Young Adult  |  Male who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

