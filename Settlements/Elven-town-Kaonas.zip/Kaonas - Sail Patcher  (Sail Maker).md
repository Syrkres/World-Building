---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sail Maker 
merchantCategory: Craftsman
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: Sail Patcher 
ownerName: Illithor Rilynnarnith 
ownerLink: "[[Sail Maker(Craftsman) - Illithor Rilynnarnith|Illithor Rilynnarnith]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Craftsman( Excellent   quality, Above Average  costs) 
- Sail Maker( Excellent   quality, Low  costs) 
exterior: An long building with new paint and with planked siding. The roof is House. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Excellent   quality |  Above Average  costs | 
> | Sail Maker |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

