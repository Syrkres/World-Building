---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crime Lord 
merchantCategory: Criminal
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: The Black Tome 
ownerName: Imra Ousseaurdrenn 
ownerLink: "[[Crime Lord(Criminal) - Imra Ousseaurdrenn|Imra Ousseaurdrenn]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Blackmarket( Good   quality, Low  costs) 
- Merchant( Low   quality, Low  costs) 
- Transfer of Goods( Low   quality, High  costs) 
exterior: An two story building with new paint and with planked siding with a missing round window. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Blackmarket |  Good   quality |  Low  costs | 
> | Merchant |  Low   quality |  Low  costs | 
> | Transfer of Goods |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

