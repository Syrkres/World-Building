---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: SellSpell 
merchantCategory: Sage
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHRINE,ALCHEMIST
title: Casters Parlor 
ownerName: Arkhun Freanitylar 
ownerLink: "[[SellSpell(Sage) - Arkhun Freanitylar|Arkhun Freanitylar]]"
ownerRace: High  Elf
apprentices: 
- Ramsay (Teen ) Male who is Well  
- Yardley (Teen ) Female who is Fit  
services: 
- Sage( Horrible   quality, Low  costs) 
- Spellcraft( Good   quality, Low  costs) 
- Spell Research( Average   quality, Above Average  costs) 
- Spell Casting( Average   quality, Below Average  costs) 
exterior: An old narrow building with planked siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Horrible   quality |  Low  costs | 
> | Spellcraft |  Good   quality |  Low  costs | 
> | Spell Research |  Average   quality |  Above Average  costs | 
> | Spell Casting |  Average   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Ramsay  | Teen  |  Male who is Well   | 
>> | Yardley  | Teen  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

