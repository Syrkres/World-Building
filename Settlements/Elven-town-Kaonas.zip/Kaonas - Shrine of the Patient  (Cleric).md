---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric 
merchantCategory: Clergy
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: 
structure: SHRINE,HOUSE
title: Shrine of the Patient 
ownerName: Neldor Rirwozea 
ownerLink: "[[Cleric(Clergy) - Neldor Rirwozea|Neldor Rirwozea]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Clergy( Excellent   quality, Low  costs) 
- Religion( Average   quality, Above Average  costs) 
- House of Worship( Low   quality, Low  costs) 
- Curse Removal( Good   quality, Above Average  costs) 
- Spell Research( Excellent   quality, Average  costs) 
- Healing( Average   quality, Average  costs) 
- Potions( Excellent   quality, High  costs) 
exterior: An old long tall building with new paint and with brick siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Excellent   quality |  Low  costs | 
> | Religion |  Average   quality |  Above Average  costs | 
> | House of Worship |  Low   quality |  Low  costs | 
> | Curse Removal |  Good   quality |  Above Average  costs | 
> | Spell Research |  Excellent   quality |  Average  costs | 
> | Healing |  Average   quality |  Average  costs | 
> | Potions |  Excellent   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

