---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand 
merchantCategory: Merc
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: JAIL,HOUSE
title: The Rough Tigger Club 
ownerName: Myrin Aleanelrvis 
ownerLink: "[[Brigand(Merc) - Myrin Aleanelrvis|Myrin Aleanelrvis]]"
ownerRace: Wood Elf
apprentices: 
- Hayes (Young Adult ) Female who is Healthy  
- Beverly (Young Adult ) Male who is Well  
services: 
- Mercenary( Poor   quality, Average  costs) 
- Enforcement( Excellent   quality, Average  costs) 
- Intimidation( Low   quality, Below Average  costs) 
exterior: An one story building with brick siding with a front round window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. A Yellow Birch pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Poor   quality |  Average  costs | 
> | Enforcement |  Excellent   quality |  Average  costs | 
> | Intimidation |  Low   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hayes  | Young Adult  |  Female who is Healthy   | 
>> | Beverly  | Young Adult  |  Male who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

