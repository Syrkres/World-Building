---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brothel Keeper 
merchantCategory: Hostelers
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: SHOP,HOUSE
title: The Sweet Bed 
ownerName: Symkalr Kralseberaltin 
ownerLink: "[[Brothel Keeper(Hostelers) - Symkalr Kralseberaltin|Symkalr Kralseberaltin]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Room (Pleasure)( Low   quality, Above Average  costs) 
- Common Room (Sleeping)( Poor   quality, Average  costs) 
- Room (Meeting)( Horrible   quality, Above Average  costs) 
exterior: An new building with shingled siding with a few round windows. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Room  | Pleasure | ( Low   quality | 
> | Common Room  | Sleeping | ( Poor   quality | 
> | Room  | Meeting | ( Horrible   quality | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

