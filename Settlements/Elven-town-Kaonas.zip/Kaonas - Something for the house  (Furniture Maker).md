---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Furniture Maker 
merchantCategory: Artisan
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: SHOP,HOUSE
title: Something for the house 
ownerName: Chathanglas Hollyatear 
ownerLink: "[[Furniture Maker(Artisan) - Chathanglas Hollyatear|Chathanglas Hollyatear]]"
ownerRace: Wood Elf
apprentices: 
- Harley (Teen ) Male who is Maimed  
services: 
- Artisan( Good   quality, Low  costs) 
- Furniture( Excellent   quality, High  costs) 
- Wood Carver( Horrible   quality, Above Average  costs) 
- Carpentry( Poor   quality, High  costs) 
exterior: An building with brick siding with a few windows. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Artisan |  Good   quality |  Low  costs | 
> | Furniture |  Excellent   quality |  High  costs | 
> | Wood Carver |  Horrible   quality |  Above Average  costs | 
> | Carpentry |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Harley  | Teen  |  Male who is Maimed   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

