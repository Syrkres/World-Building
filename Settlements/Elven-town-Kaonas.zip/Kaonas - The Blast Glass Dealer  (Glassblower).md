---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Glassblower 
merchantCategory: Craftsman
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: The Blast Glass Dealer 
ownerName: El�naril Hlaelylth 
ownerLink: "[[Glassblower(Craftsman) - El�naril Hlaelylth|El�naril Hlaelylth]]"
ownerRace: High  Elf
apprentices: 
- Burton (Young Adult ) Female who is Well  
- Reed (Adult ) Female who is Fit  
services: 
- Craftsman( Average   quality, Average  costs) 
- Glass Blowing( Poor   quality, Average  costs) 
exterior: An building with faded paint and with planked siding with a few windows. The roof is Roof. A Elm shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Average   quality |  Average  costs | 
> | Glass Blowing |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Burton  | Young Adult  |  Female who is Well   | 
>> | Reed  | Adult  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

