---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Furrier 
merchantCategory: Garment Trade
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: SHOP,HOUSE
title: Ye Warmest Fur 
ownerName: Ain'silver Krargolrae 
ownerLink: "[[Furrier(Garment Trade) - Ain'silver Krargolrae|Ain'silver Krargolrae]]"
ownerRace: Wood Elf
apprentices: 
- Payton (Young Adult ) Male who is Impaired  
- Hayley (Young Adult ) Male who is All Right  
services: 
- Garment Trade( Excellent   quality, Average  costs) 
- Fur Processing( Low   quality, Below Average  costs) 
exterior: An new tall building with new paint and with shingled siding with a front broken window that has a painted sign hanging above with the merchants name. The roof is House. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Excellent   quality |  Average  costs | 
> | Fur Processing |  Low   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Payton  | Young Adult  |  Male who is Impaired   | 
>> | Hayley  | Young Adult  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

