---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Maidservant 
merchantCategory: Laborer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: Well Clean for you 
ownerName: Taeglyn CyGreendlues 
ownerLink: "[[Maidservant(Laborer) - Taeglyn CyGreendlues|Taeglyn CyGreendlues]]"
ownerRace: Wood Elf
apprentices: 
- Thackeray (Teen ) Male who is Expired  
- Blackwood (Young Adult ) Male who is Fit  
services: 
- Laborer( Good   quality, Above Average  costs) 
- Maid( Excellent   quality, Above Average  costs) 
- Cleaning( Good   quality, High  costs) 
exterior: An tall building with new paint and with brick siding with a few windows. The roof is Celing. A Cherry shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Laborer |  Good   quality |  Above Average  costs | 
> | Maid |  Excellent   quality |  Above Average  costs | 
> | Cleaning |  Good   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Thackeray  | Teen  |  Male who is Expired   | 
>> | Blackwood  | Young Adult  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

