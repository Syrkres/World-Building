---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tutor 
merchantCategory: Sage
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: Teachers Guild 
ownerName: Ashemmi Zimrenaltin 
ownerLink: "[[Tutor(Sage) - Ashemmi Zimrenaltin|Ashemmi Zimrenaltin]]"
ownerRace: Elf
apprentices: 
- Addington (Teen ) Female who is Wounded  
- York (Teen ) Female who is Healthy  
services: 
- Sage( Low   quality, Above Average  costs) 
- Teaching( Good   quality, Average  costs) 
- Research( Good   quality, Above Average  costs) 
exterior: An old one story building with new paint and with shingled siding with a front window that has a painted sign hanging above with the merchants name. The roof is Roof. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Low   quality |  Above Average  costs | 
> | Teaching |  Good   quality |  Average  costs | 
> | Research |  Good   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Addington  | Teen  |  Female who is Wounded   | 
>> | York  | Teen  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

