---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer(Special) 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: FARM,HOUSE
title: The Special Farm 
ownerName: Jastra Sentalialzea 
ownerLink: "[[Farmer(Special)(Farmer) - Jastra Sentalialzea|Jastra Sentalialzea]]"
ownerRace: High  Elf
apprentices: 
- Wordsworth (Teen ) Male who is Healthy  
services: 
- Farmer( Good   quality, Above Average  costs) 
- Food( Average   quality, Average  costs) 
- Herding( Low   quality, Low  costs) 
exterior: An old tall building with faded paint and with stoned siding. The roof is Dome. A Oak pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Good   quality |  Above Average  costs | 
> | Food |  Average   quality |  Average  costs | 
> | Herding |  Low   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Wordsworth  | Teen  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

