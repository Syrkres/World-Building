---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Mercer 
merchantCategory: Garment Trade
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: Ye Cloth Emporium 
ownerName: Eltaor Berenundlin 
ownerLink: "[[Mercer(Garment Trade) - Eltaor Berenundlin|Eltaor Berenundlin]]"
ownerRace: High  Elf
apprentices: 
- Bradford (Teen ) Female who is Indisposed  
services: 
- Garment Trade( Average   quality, Below Average  costs) 
- Trader( Average   quality, Below Average  costs) 
exterior: An old tall building with planked siding with a missing round window. The roof is Dome. A Pine pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Average   quality |  Below Average  costs | 
> | Trader |  Average   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Bradford  | Teen  |  Female who is Indisposed   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

