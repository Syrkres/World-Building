---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weapon Dealer 
merchantCategory: Merchant
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Grove 
structure: SHOP,HOUSE
title: The Light Brown Sword 
ownerName: Jharym Rhosurulaear 
ownerLink: "[[Weapon Dealer(Merchant) - Jharym Rhosurulaear|Jharym Rhosurulaear]]"
ownerRace: Elf
apprentices: 
- Langley (Young Adult ) Female who is Unwell  
services: 
- Merchant( Low   quality, Below Average  costs) 
- Weapon Dealer( Average   quality, Below Average  costs) 
exterior: An long building with planked siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Low   quality |  Below Average  costs | 
> | Weapon Dealer |  Average   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Langley  | Young Adult  |  Female who is Unwell   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

