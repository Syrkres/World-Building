---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Juggler 
merchantCategory: Entertainer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: Ye Laughing Pin 
ownerName: Csharynn Tukwoderannia 
ownerLink: "[[Juggler(Entertainer) - Csharynn Tukwoderannia|Csharynn Tukwoderannia]]"
ownerRace: Elf
apprentices: 
- Anderton (Young Adult ) Male who is Fine  
- Compton (Young Adult ) Male who is Incapacitaed  
services: 
- Entertainer( Average   quality, High  costs) 
- Performance( Average   quality, High  costs) 
exterior: An new two story building with shingled siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Entertainer |  Average   quality |  High  costs | 
> | Performance |  Average   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Anderton  | Young Adult  |  Male who is Fine   | 
>> | Compton  | Young Adult  |  Male who is Incapacitaed   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

