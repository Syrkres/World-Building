---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer 
merchantCategory: Animal Handler
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: TANNERY,FARM,STABLE
title: Spot Tails 
ownerName: Fenian Momrimzea 
ownerLink: "[[Animal Groomer(Animal Handler) - Fenian Momrimzea|Fenian Momrimzea]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Animal Handler( Horrible   quality, High  costs) 
- Pet Training( Poor   quality, Below Average  costs) 
- Animal Training( Low   quality, Average  costs) 
exterior: An old narrow building with faded paint and with brick siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Horrible   quality |  High  costs | 
> | Pet Training |  Poor   quality |  Below Average  costs | 
> | Animal Training |  Low   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

