---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Teamster 
merchantCategory: Laborer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: Federation Guild 
ownerName: Thalanil Mizunurdrenn 
ownerLink: "[[Teamster(Laborer) - Thalanil Mizunurdrenn|Thalanil Mizunurdrenn]]"
ownerRace: High  Elf
apprentices: 
- Quinton (Young Adult ) Female who is Wounded  
- Langdon (Teen ) Male who is Maimed  
services: 
- Laborer( Low   quality, High  costs) 
- Teamster( Excellent   quality, Low  costs) 
exterior: An narrow two story building with brick siding with a missing tall window. The roof is Dome. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Laborer |  Low   quality |  High  costs | 
> | Teamster |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Quinton  | Young Adult  |  Female who is Wounded   | 
>> | Langdon  | Teen  |  Male who is Maimed   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

