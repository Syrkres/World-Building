---
fileType: npc
Art: elvenBanner01.png
Name: Eldar
Surname: Invusomrretyn
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Wood Elf
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Average athletic build, with hazel eyes and wavy black hair. Their face is doe-eyed and their speech is a guttural slur 
Age: Mature Adult 
Condition: Nauseos 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Grove 
Location: Mythiune(Northlands) / Kaonas(Central Grove )
Likes: 
    - Getting lost 
Dislikes: 
    - Facial hair 
Acquaintances: 
PrimaryOccupation: Barrel Maker
PrimaryOccupationCategory: Craftsman
Occupation:
    - Barrel Maker 
Importance: 7
SpouseName: 
SpouseAge: 
SpouseGender: 
SpouseCondition: 
Parents: 
    - Ahskahala(Mother) Elderly  Female who is Healthy 
    - Lafarallin(Father) Ancient  Male who is All Right 
Children: 
    No Children
AssociatedGroup:
    - Merchants Guild 
AssociatedReligion:
PersonalityTrait:
- Naive  
SocialTrait:
- Talkative  
- Lenient  
MentalTrait:
- Reckless  
PersonalGoals: Have their work recognized. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
