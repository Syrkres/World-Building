---
fileType: npc
Art: elvenBanner01.png
Name: Arkhun
Surname: Freanitylar
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: High  Elf
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Extra tall strong build, with white eyes and bald white hair. Their face has nose pierced and their speech is halting 
Age: Adult 
Condition: Unwell 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
Location: Mythiune(Northlands) / Kaonas(Temple Square )
Likes: 
    - Foraging 
    - Politics 
    - Knife throwing 
    - Gossip 
Dislikes: 
    - Witchcraft 
    - Woodworking 
    - Reading books 
    - Mountains 
Acquaintances: 
PrimaryOccupation: SellSpell
PrimaryOccupationCategory: Sage
Occupation:
    - SellSpell 
Importance: 7
SpouseName: 
SpouseAge: 
SpouseGender: 
SpouseCondition: 
Parents: 
    - Tisharu(Mother) Elderly  Female who is Healthy 
    - Jharym(Father) Ancient  Male who is Impaired 
Children: 
    No Children
AssociatedGroup:
    - Secret Order 
AssociatedReligion:
PersonalityTrait:
- Respectful  
SocialTrait:
- Selfless  
MentalTrait:
- Analytical  
- Reckless  
PersonalGoals: Reach the promised lands. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
