---
fileType: npc
Art: elvenBanner01.png
Name: Aermhar
Surname: Pemyrrae
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Wood Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Squat weak build, with red eyes and pony-tail blond hair. Their face has a missing eye and their speech is nervous 
Age: Adult 
Condition: Dying 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
Location: Mythiune(Northlands) / Kaonas(Merchants Market )
Likes: 
    - Road trips 
Dislikes: 
    - Flail 
Acquaintances: 
PrimaryOccupation: Kettle Maker
PrimaryOccupationCategory: Craftsman
Occupation:
    - Kettle Maker 
Importance: 7
SpouseName: Kavrala(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: All Right 
Parents: 
    - Phantyni(Mother) Adult  Female who is Deceased
    - Illithor(Father) Elderly  Male who is Deceased
Children: 
    - Rolim(Child) Teen  Boy who is Fit  
    - Vander(Child) Infant  Boy who is Healthy  
    - Arlayna(Child) Young Adult  Girl who is All Right  
AssociatedGroup:
    - Merchants Guild 
AssociatedReligion:
PersonalityTrait:
- Smooth  
SocialTrait:
- Dependable  
- Impartial  
- Selfless  
MentalTrait:
- Ambitious  
PersonalGoals: Create a work of art. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
