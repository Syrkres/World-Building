---
fileType: npc
Art: elvenBanner01.png
Name: Beldroth
Surname: Wakirulmitore
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: High  Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Average thin build, with red eyes and frazzled white hair. Their face has stained teeth and their speech is loud 
Age: Adult 
Condition: Wounded 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
Location: Mythiune(Northlands) / Kaonas(Central Quarter )
Likes: 
    - Closed spaces 
    - Soap carving 
    - Making dice 
Dislikes: 
    - The stars 
    - Making jewelry 
Acquaintances: 
PrimaryOccupation: Herbalist
PrimaryOccupationCategory: Professional Specialties
Occupation:
    - Herbalist 
Importance: 7
SpouseName: Csharynn(Wife)
SpouseAge: Mature Adult 
SpouseGender: Female
SpouseCondition: Healthy 
Parents: 
    - Keishara(Mother) Elderly  Female who is Deceased
    - Arlen(Father) Elderly  Male who is Deceased
Children: 
    - Faahresc(Child) Child  Boy who is Well  
    - Mlossae(Child) Child  Boy who is Fine  
    - Rilitar(Child) Infant  Boy who is Fine  
AssociatedGroup:
    - Merchants Guild 
AssociatedReligion:
PersonalityTrait:
- Smooth  
- Respectful  
SocialTrait:
- Trusting  
- Unfriendly  
- Stingy  
MentalTrait:
- Inattentive  
- Stupid  
PersonalGoals: Be in control. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
