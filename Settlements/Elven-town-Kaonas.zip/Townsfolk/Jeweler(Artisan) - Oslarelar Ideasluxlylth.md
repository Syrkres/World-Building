---
fileType: npc
Art: elvenBanner01.png
Name: Oslarelar
Surname: Ideasluxlylth
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: High  Elf
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Tall anorexic build, with brown eyes and limp grey hair. Their face is gap-toothed and their speech is stuttered 
Age: Mature Adult 
Condition: Healthy 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: 
Location: Mythiune(Northlands) / Kaonas()
Likes: 
    - The stars 
    - Going outside 
    - Pirates 
Dislikes: 
    - The moon 
    - Staying inside 
Acquaintances: 
PrimaryOccupation: Jeweler
PrimaryOccupationCategory: Artisan
Occupation:
    - Jeweler 
Importance: 7
SpouseName: 
SpouseAge: 
SpouseGender: 
SpouseCondition: 
Parents: 
    - Blythswana(Mother) Elderly  Female who is Under the weather 
    - Skalanis(Father) Elderly  Male who is Deceased
Children: 
    No Children
AssociatedGroup:
AssociatedReligion:
PersonalityTrait:
- Depressed  
SocialTrait:
- Bossy  
- Selfless  
MentalTrait:
- Incompetent  
- Tenacious  
PersonalGoals: Become a leader. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
