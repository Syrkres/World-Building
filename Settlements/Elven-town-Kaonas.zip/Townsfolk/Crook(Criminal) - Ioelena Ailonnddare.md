---
fileType: npc
Art: elvenBanner01.png
Name: Ioelena
Surname: Ailonnddare
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Normal strong build, with white eyes and messy grey hair. Their face has small scar on left cheek and their speech is halting 
Age: Adult 
Condition: Healthy 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
Location: Mythiune(Northlands) / Kaonas(Merchants Market )
Likes: 
    - Eldritch monsters 
Dislikes: 
    - The stars 
    - Rain 
Acquaintances: 
PrimaryOccupation: Crook
PrimaryOccupationCategory: Criminal
Occupation:
    - Crook 
Importance: 1
SpouseName: 
SpouseAge: 
SpouseGender: 
SpouseCondition: 
Parents: 
    - Vaervenshalice(Mother) Elderly  Female who is Deceased
    - Zhoron(Father) Elderly  Male who is Deceased
Children: 
    - Yathlanae(Child) Young Adult  Girl who is Dead  
    - Nardual(Child) Child  Boy who is Fine  
    - Mariona(Child) Child  Girl who is All Right  
AssociatedGroup:
    - Secret Order 
AssociatedReligion:
PersonalityTrait:
- Savvy  
- Incoherent  
SocialTrait:
- Suspicious  
- Suspicious  
- Loyal  
MentalTrait:
- Perceptive  
PersonalGoals: Be in control. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
