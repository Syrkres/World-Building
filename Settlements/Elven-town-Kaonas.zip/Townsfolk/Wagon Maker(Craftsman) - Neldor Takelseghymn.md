---
fileType: npc
Art: elvenBanner01.png
Name: Neldor
Surname: Takelseghymn
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Wood Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Average strong build, with blue eyes and long brown hair. Their face is missing teeth and their speech is fast 
Age: Ancient 
Condition: Dying 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
Location: Mythiune(Northlands) / Kaonas(Downtown Corner )
Likes: 
    - Bird watching 
    - Closed spaces 
Dislikes: 
    - Quilting 
    - Parades 
    - Festivals 
    - Map making 
Acquaintances: 
PrimaryOccupation: Wagon Maker
PrimaryOccupationCategory: Craftsman
Occupation:
    - Wagon Maker 
Importance: 7
SpouseName: Dathlue(Wife)
SpouseAge: Young Adult 
SpouseGender: Female
SpouseCondition: Healthy 
Parents: 
    - Tamara(Mother) Elderly  Female who is Deceased
    - Deldrach(Father) Elderly  Male who is Fine 
Children: 
    - Phuingara(Child) Teen  Girl who is At death's door  
    - Galather(Child) Child  Boy who is Fine  
    - Shonassir(Child) Infant  Boy who is Nauseos  
AssociatedGroup:
    - Artisans Guild 
AssociatedReligion:
PersonalityTrait:
- Wrathful  
- Gentle  
SocialTrait:
- Honest  
- Dependable  
MentalTrait:
- Tenacious  
- Courageous  
PersonalGoals: Escape death. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
