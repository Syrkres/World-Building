---
fileType: npc
Art: elvenBanner01.png
Name: Nym
Surname: Ilentlithar
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: High  Elf
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Average strong build, with white eyes and greasy white hair. Their face has stained teeth and their speech is raspy 
Age: Mature Adult 
Condition: Healthy 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
Location: Mythiune(Northlands) / Kaonas(Merchants Market )
Likes: 
    - Pottery 
    - Danger 
    - The moon 
Dislikes: 
    - Reading books 
    - Repairing items 
Acquaintances: 
PrimaryOccupation: Magical Tutor
PrimaryOccupationCategory: Sage
Occupation:
    - Magical Tutor 
Importance: 9
SpouseName: 
SpouseAge: 
SpouseGender: 
SpouseCondition: 
Parents: 
    - Jhiilsraa(Mother) Ancient  Female who is Deceased
    - Druindar(Father) Elderly  Male who is All Right 
Children: 
    - Syviis(Child) Teen  Girl who is Nauseos  
    - Rothilion(Child) Teen  Boy who is Fine  
    - Shadowmoon(Child) Child  Girl who is Inured  
AssociatedGroup:
    - Mages Circle 
AssociatedReligion:
PersonalityTrait:
- Sensitive  
SocialTrait:
- Talkative  
- Peaceful  
- Peaceful  
MentalTrait:
- Skillful  
PersonalGoals: Find a new home. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
