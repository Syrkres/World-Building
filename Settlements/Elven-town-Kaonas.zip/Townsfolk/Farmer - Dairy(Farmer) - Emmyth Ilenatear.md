---
fileType: npc
Art: elvenBanner01.png
Name: Emmyth
Surname: Ilenatear
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Short weak build, with hazel eyes and dreadlocks auburn hair. Their face has acne and their speech is low-pitched 
Age: Adult 
Condition: At death's door 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
Location: Mythiune(Northlands) / Kaonas(Merchants Market )
Likes: 
    - Baking 
Dislikes: 
    - Card games 
Acquaintances: 
PrimaryOccupation: Farmer - Dairy
PrimaryOccupationCategory: Farmer
Occupation:
    - Farmer - Dairy 
Importance: 3
SpouseName: Aneirin(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Fine 
Parents: 
    - Sharaera(Mother) Elderly  Female who is Healthy 
    - Amrynn(Father) Adult  Male who is Incapacitaed 
Children: 
    - Yeschant(Child) Infant  Boy who is Fit  
    - Ygrainne(Child) Teen  Girl who is Indisposed  
    - Alerathla(Child) Infant  Girl who is Under the weather  
AssociatedGroup:
    - Mages Circle 
AssociatedReligion:
PersonalityTrait:
- Listless  
- Eccentric  
SocialTrait:
- Secretive  
MentalTrait:
- Patient  
- Comformist  
- Secular  
PersonalGoals: Conquer their fear. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
