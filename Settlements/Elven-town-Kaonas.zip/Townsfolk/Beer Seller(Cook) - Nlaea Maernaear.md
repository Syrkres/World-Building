---
fileType: npc
Art: elvenBanner01.png
Name: Nlaea
Surname: Maernaear
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Wood Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Tall average build, with brown eyes and limp black hair. Their face is chiseled and their speech is whiny 
Age: Elderly 
Condition: Hurt 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Grove 
Location: Mythiune(Northlands) / Kaonas(Central Grove )
Likes: 
    - Abandoned buildings 
Dislikes: 
    - Camping 
    - Mist / Fog 
    - The ocean 
Acquaintances: 
PrimaryOccupation: Beer Seller
PrimaryOccupationCategory: Cook
Occupation:
    - Beer Seller 
Importance: 4
SpouseName: Vaalyun(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Healthy 
Parents: 
    - Valindra(Mother) Elderly  Female who is Dying 
    - Nevarth(Father) Adult  Male who is Deceased
Children: 
    - Duilya(Child) Young Adult  Girl who is Scraped up  
    - Faoraar(Child) Young Adult  Boy who is Fit  
    - Syviis(Child) Teen  Girl who is All Right  
AssociatedGroup:
    - Entertainer Union 
AssociatedReligion:
PersonalityTrait:
- Pessimistic  
SocialTrait:
- Tolerant  
- Unfaithful  
- Forthcoming  
MentalTrait:
- Superstitious  
- Perceptive  
PersonalGoals: Be accepted by society. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
