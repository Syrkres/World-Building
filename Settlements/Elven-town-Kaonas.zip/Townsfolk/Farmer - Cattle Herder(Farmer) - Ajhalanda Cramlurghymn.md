---
fileType: npc
Art: elvenBanner01.png
Name: Ajhalanda
Surname: Cramlurghymn
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Tall athletic build, with brown eyes and limp red hair. Their face has a missing right eye and their speech is slured 
Age: Young Adult 
Condition: Under the weather 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
Location: Mythiune(Northlands) / Kaonas(Temple Square )
Likes: 
    - Storytelling 
    - Extravagant things 
    - Comfortable silence 
Dislikes: 
    - Nature 
    - Metalworking 
    - Chalk 
    - Sailing 
Acquaintances: 
PrimaryOccupation: Farmer - Cattle Herder
PrimaryOccupationCategory: Farmer
Occupation:
    - Farmer - Cattle Herder 
Importance: 3
SpouseName: 
SpouseAge: 
SpouseGender: 
SpouseCondition: 
Parents: 
    - Nakiasha(Mother) Elderly  Female who is Healthy 
    - Tamnaeuth(Father) Ancient  Male who is Healthy 
Children: 
    No Children
AssociatedGroup:
    - Mages Circle 
AssociatedReligion:
PersonalityTrait:
- Depressed  
SocialTrait:
- Violent  
MentalTrait:
- Stupid  
- Inattentive  
- Superstitious  
PersonalGoals: Redeem somebody. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
