---
fileType: npc
Art: elvenBanner01.png
Name: Nambra
Surname: Ilennddare
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: High  Elf
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Extra tall fat build, with white eyes and strange hairstyle blond hair. Their face has no eyebrows and their speech is stuttered 
Age: Adult 
Condition: Ill 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
Location: Mythiune(Northlands) / Kaonas(Upper Quarter )
Likes: 
    - Falconry 
    - The ocean 
Dislikes: 
    - Archery 
    - Farmer 
    - Hail 
Acquaintances: 
PrimaryOccupation: Laborer
PrimaryOccupationCategory: Laborer
Occupation:
    - Laborer 
Importance: 2
SpouseName: Purtham(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Healthy 
Parents: 
    - Deularla(Mother) Elderly  Female who is Deceased
    - Rumathil(Father) Adult  Male who is Deceased
Children: 
    - Selgauth(Child) Infant  Boy who is Expired  
AssociatedGroup:
    - Union 
AssociatedReligion:
PersonalityTrait:
- Gentle  
SocialTrait:
- Unreliable  
MentalTrait:
- Reckless  
- Skeptical  
PersonalGoals: Start a family. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
