---
fileType: npc
Art: elvenBanner01.png
Name: Adorellan
Surname: Maernthym
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Extra short lean build, with green eyes and short black hair. Their face has a goatee and their speech is breathless 
Age: Adult 
Condition: Well 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
Location: Mythiune(Northlands) / Kaonas(Central Quarter )
Likes: 
    - Crowds 
    - Going outside 
Dislikes: 
    - Touching 
    - Staying inside 
    - The sound of birds in the morning 
    - Cemeteries 
Acquaintances: 
PrimaryOccupation: Goon
PrimaryOccupationCategory: Criminal
Occupation:
    - Goon 
Importance: 1
SpouseName: Imramarthree(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Fit 
Parents: 
    - Hhora(Mother) Ancient  Female who is Deceased
    - Cheyrth(Father) Elderly  Male who is Deceased
Children: 
    - Jhaumrithe(Child) Young Adult  Girl who is Indisposed  
    - Syrune(Child) Teen  Girl who is Fine  
    - Ara(Child) Child  Girl who is Ailing  
AssociatedGroup:
    - Syndicate 
AssociatedReligion:
PersonalityTrait:
- Enthusiastic  
- Gentle  
SocialTrait:
- Cruel  
- Unfaithful  
- Friendly  
MentalTrait:
- Reckless  
- Perceptive  
- Cautious  
PersonalGoals: Overcome mockery from the past. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
