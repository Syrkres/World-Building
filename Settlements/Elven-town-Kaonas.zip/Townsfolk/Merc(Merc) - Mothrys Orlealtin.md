---
fileType: npc
Art: elvenBanner01.png
Name: Mothrys
Surname: Orlealtin
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Wood Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Average athletic build, with brown eyes and strange hairstyle grey hair. Their face has a missing right eye and their speech is slured 
Age: Adult 
Condition: Healthy 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
Location: Mythiune(Northlands) / Kaonas(Upper Quarter )
Likes: 
    - Fireworks 
    - Gossip 
    - Reading books 
    - Hiking 
Dislikes: 
    - Lockpicking 
    - Throwing rocks 
    - Making dice 
Acquaintances: 
PrimaryOccupation: Merc
PrimaryOccupationCategory: Merc
Occupation:
    - Merc 
Importance: 3
SpouseName: Phaerl(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Healthy 
Parents: 
    - Imizael(Mother) Elderly  Female who is Healthy 
    - Mihangyl(Father) Elderly  Male who is Well 
Children: 
    - Raeranthur(Child) Child  Boy who is Healthy  
AssociatedGroup:
    - Vanguard 
AssociatedReligion:
PersonalityTrait:
- Gentle  
- Overt  
SocialTrait:
- Bossy  
MentalTrait:
- Religious  
- Skeptical  
PersonalGoals: Find a thrilling life. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
