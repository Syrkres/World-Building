---
fileType: npc
Art: elvenBanner01.png
Name: Lafarallin
Surname: Pemyrmitore
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: High  Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Normal thin build, with brown eyes and pony-tail black hair. Their face is toothless and their speech is with lisps 
Age: Adult 
Condition: Healthy 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Grove 
Location: Mythiune(Northlands) / Kaonas(Central Grove )
Likes: 
    - Nature 
    - Facial hair 
Dislikes: 
    - Dark Green 
    - Woodworking 
    - Farming 
Acquaintances: 
PrimaryOccupation: Horse Trader
PrimaryOccupationCategory: Merchant
Occupation:
    - Horse Trader 
Importance: 4
SpouseName: Filauria(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Fit as a fiddle 
Parents: 
    - Chichlandra(Mother) Elderly  Female who is Deceased
    - Samblar(Father) Elderly  Male who is Fit 
Children: 
    No Children
AssociatedGroup:
    - Merchants Guild 
AssociatedReligion:
PersonalityTrait:
- Respectful  
SocialTrait:
- Dependable  
- Bossy  
MentalTrait:
- Skeptical  
- Indecisive  
PersonalGoals: Never be hurt again. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
