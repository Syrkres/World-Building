---
fileType: npc
Art: elvenBanner01.png
Name: Mihangyl
Surname: Ideasvirrea
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Elf
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Tall fat build, with brown eyes and straight grey hair. Their face has large ears and their speech is whiny 
Age: Adult 
Condition: Well 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
Location: Mythiune(Northlands) / Kaonas(Merchants Market )
Likes: 
    - Hail 
Dislikes: 
    - Mist / Fog 
    - Sincerity 
    - The ocean 
    - Cleaning 
Acquaintances: 
PrimaryOccupation: Tutor
PrimaryOccupationCategory: Sage
Occupation:
    - Tutor 
Importance: 9
SpouseName: Gylledha(Wife)
SpouseAge: Young Adult 
SpouseGender: Female
SpouseCondition: Fine 
Parents: 
    - Esta(Mother) Elderly  Female who is Deceased
    - Tanithil(Father) Adult  Male who is Deceased
Children: 
    No Children
AssociatedGroup:
    - Mages Circle 
AssociatedReligion:
PersonalityTrait:
- Smooth  
- Smooth  
SocialTrait:
- Dependable  
- Lenient  
MentalTrait:
- Adaptive  
PersonalGoals: Go on an adventure. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
