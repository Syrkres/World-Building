---
fileType: npc
Art: elvenBanner01.png
Name: Edic've
Surname: Teasen'fathem
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Short weak build, with brown eyes and bald auburn hair. Their face is pierced and their speech is low-pitched 
Age: Ancient 
Condition: Nauseos 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
Location: Mythiune(Northlands) / Kaonas(Temple Square )
Likes: 
    - Dried Meat 
    - Tarot card readings 
Dislikes: 
    - Seashells 
    - Animals 
    - Children 
    - Patterned socks 
Acquaintances: 
PrimaryOccupation: Laborer
PrimaryOccupationCategory: Laborer
Occupation:
    - Laborer 
Importance: 2
SpouseName: Ciyradyl(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Scraped up 
Parents: 
    - Chalsarda(Mother) Ancient  Female who is Healthy 
    - Chaalmyth(Father) Elderly  Male who is Fit 
Children: 
    - Ruardh(Child) Infant  Boy who is Healthy  
    - Hycis(Child) Young Adult  Girl who is Ailing  
AssociatedGroup:
    - Union 
AssociatedReligion:
PersonalityTrait:
- Thick-skinned  
SocialTrait:
- Dishonest  
MentalTrait:
- Incompetent  
PersonalGoals: Escape a bad situation. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
