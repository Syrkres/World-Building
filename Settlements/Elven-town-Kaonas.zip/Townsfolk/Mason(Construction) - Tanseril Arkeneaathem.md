---
fileType: npc
Art: elvenBanner01.png
Name: Tanseril
Surname: Arkeneaathem
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Elf
Alignment: chaotic
Gender: Male
Sexuality: Gay 
Appearance: Extra short anorexic build, with hazel eyes and strange hairstyle auburn hair. Their face has a bushy eyebrows and their speech is whispery 
Age: Adult 
Condition: Well 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
Location: Mythiune(Northlands) / Kaonas(Upper Quarter )
Likes: 
    - Urban exploring 
    - Fitted clothing 
    - Dance 
Dislikes: 
    - Flower pressing 
    - Falling leaves 
Acquaintances: 
PrimaryOccupation: Mason
PrimaryOccupationCategory: Construction
Occupation:
    - Mason 
Importance: 2
SpouseName: Ilythyrra(Wife)
SpouseAge: Young Adult 
SpouseGender: Female
SpouseCondition: Fit 
Parents: 
    - Synnorha(Mother) Elderly  Female who is Deceased
    - Evindal(Father) Elderly  Male who is Inured 
Children: 
    - Elaethan(Child) Child  Boy who is Fit as a fiddle  
    - Eroan(Child) Infant  Boy who is Not oneself  
    - Zaos(Child) Child  Boy who is All Right  
AssociatedGroup:
    - Artisans Guild 
AssociatedReligion:
PersonalityTrait:
- Subtle  
- Proud  
SocialTrait:
- Tolerant  
- Suspicious  
- Generous  
MentalTrait:
- Creative  
PersonalGoals: Escape a bad situation. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
