---
fileType: npc
Art: elvenBanner01.png
Name: Meriel
Surname: Denkerdlues
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Grand thin build, with red eyes and dreadlocks white hair. Their face has a missing right eye and their speech is whispery 
Age: Elderly 
Condition: Nauseos 
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: 
Location: Mythiune(Northlands) / Kaonas()
Likes: 
    - Wind chimes 
    - Repairing items 
    - Seashells 
Dislikes: 
    - Keys 
    - Cave exploring 
Acquaintances: 
PrimaryOccupation: Meat Butcher
PrimaryOccupationCategory: Cook
Occupation:
    - Meat Butcher 
Importance: 7
SpouseName: 
SpouseAge: 
SpouseGender: 
SpouseCondition: 
Parents: 
    - Symrustar(Mother) Elderly  Female who is Hurt 
    - Andrathath(Father) Elderly  Male who is At death's door 
Children: 
    - Luirlan(Child) Infant  Boy who is All Right  
    - Iyrandrar(Child) Child  Boy who is Ailing  
    - Auluua(Child) Child  Girl who is Indisposed  
AssociatedGroup:
AssociatedReligion:
PersonalityTrait:
- Mature  
SocialTrait:
- Friendly  
- Loyal  
MentalTrait:
- Tenacious  
- Independent  
PersonalGoals: Never be hurt again. 
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
