---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cleric 
merchantCategory: Clergy
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHRINE,HOUSE
title: Shrine of the Dragon 
ownerName: Aerendyl Aleanghymn 
ownerLink: "[[Cleric(Clergy) - Aerendyl Aleanghymn|Aerendyl Aleanghymn]]"
ownerRace: High  Elf
apprentices: 
- Alby (Teen ) Female who is Dying  
- Yeardley (Adult ) Male who is Fit  
services: 
- Clergy( Excellent   quality, Low  costs) 
- Religion( Low   quality, Average  costs) 
- House of Worship( Good   quality, Average  costs) 
- Curse Removal( Horrible   quality, Low  costs) 
- Spell Research( Horrible   quality, Low  costs) 
- Healing( Good   quality, Average  costs) 
- Potions( Excellent   quality, Above Average  costs) 
exterior: An old narrow two story building with new paint and with shingled siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is House. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Excellent   quality |  Low  costs | 
> | Religion |  Low   quality |  Average  costs | 
> | House of Worship |  Good   quality |  Average  costs | 
> | Curse Removal |  Horrible   quality |  Low  costs | 
> | Spell Research |  Horrible   quality |  Low  costs | 
> | Healing |  Good   quality |  Average  costs | 
> | Potions |  Excellent   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Alby  | Teen  |  Female who is Dying   | 
>> | Yeardley  | Adult  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

