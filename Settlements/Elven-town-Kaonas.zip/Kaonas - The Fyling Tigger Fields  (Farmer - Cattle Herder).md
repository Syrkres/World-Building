---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: FARM,HOUSE
title: The Fyling Tigger Fields 
ownerName: Ajhalanda Cramlurghymn 
ownerLink: "[[Farmer - Cattle Herder(Farmer) - Ajhalanda Cramlurghymn|Ajhalanda Cramlurghymn]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Farmer( Good   quality, Above Average  costs) 
- Food( Horrible   quality, Low  costs) 
exterior: An tall building with brick siding with a missing round window. The roof is Roof. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Good   quality |  Above Average  costs | 
> | Food |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

