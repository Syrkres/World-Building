---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Council Member 
merchantCategory: Elected Official
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: Town Hall 
ownerName: Tarosspur Hlaeitryn 
ownerLink: "[[Council Member(Elected Official) - Tarosspur Hlaeitryn|Tarosspur Hlaeitryn]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Elected Official( Good   quality, Average  costs) 
- Diplomacy( Average   quality, Low  costs) 
- Advise( Excellent   quality, Below Average  costs) 
exterior: An old narrow two story building with stoned siding. The roof is Celing. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Elected Official |  Good   quality |  Average  costs | 
> | Diplomacy |  Average   quality |  Low  costs | 
> | Advise |  Excellent   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

