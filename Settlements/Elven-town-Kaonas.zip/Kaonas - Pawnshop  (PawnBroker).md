---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: PawnBroker 
merchantCategory: Specialty Service
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: Pawnshop 
ownerName: Lyklor Malsaanea 
ownerLink: "[[PawnBroker(Specialty Service) - Lyklor Malsaanea|Lyklor Malsaanea]]"
ownerRace: Wood Elf
apprentices: 
- Vance (Teen ) Male who is Wounded  
- Winterbourne (Young Adult ) Female who is Healthy  
services: 
- Money Lender( Poor   quality, Low  costs) 
- Trader( Horrible   quality, Average  costs) 
exterior: An building with shingled siding. The roof is House. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Money Lender |  Poor   quality |  Low  costs | 
> | Trader |  Horrible   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Vance  | Teen  |  Male who is Wounded   | 
>> | Winterbourne  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

