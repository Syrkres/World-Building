---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wine Seller 
merchantCategory: Cook
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: Orange Wine Shop 
ownerName: Braerindra Ilentlithar 
ownerLink: "[[Wine Seller(Cook) - Braerindra Ilentlithar|Braerindra Ilentlithar]]"
ownerRace: Wood Elf
apprentices: 
- Stafford (Adult ) Male who is Healthy  
- Hayden (Adult ) Male who is Fine  
services: 
- Cook( Poor   quality, Above Average  costs) 
- Wine Seller( Average   quality, Above Average  costs) 
exterior: An old tall building with brick siding with a missing round window. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Poor   quality |  Above Average  costs | 
> | Wine Seller |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Stafford  | Adult  |  Male who is Healthy   | 
>> | Hayden  | Adult  |  Male who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

