---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: FARM,HOUSE
title: Ye Solid Livestock Fields 
ownerName: Nylaathria Perlelvirrea 
ownerLink: "[[Farmer - Cattle Herder(Farmer) - Nylaathria Perlelvirrea|Nylaathria Perlelvirrea]]"
ownerRace: Wood Elf
apprentices: 
- Hackney (Young Adult ) Female who is Healthy  
services: 
- Farmer( Low   quality, Low  costs) 
- Food( Average   quality, High  costs) 
exterior: An new tall building with new paint and with planked siding with a few round shuttered windows. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Low   quality |  Low  costs | 
> | Food |  Average   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hackney  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

