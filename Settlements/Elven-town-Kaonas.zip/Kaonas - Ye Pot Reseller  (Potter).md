---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Potter 
merchantCategory: Craftsman
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Grove 
structure: SHOP,HOUSE
title: Ye Pot Reseller 
ownerName: Gaylia Kelrarathem 
ownerLink: "[[Potter(Craftsman) - Gaylia Kelrarathem|Gaylia Kelrarathem]]"
ownerRace: Wood Elf
apprentices: 
- Cholmondeley (Child ) Male who is All Right  
- Coombs (Mature Adult ) Female who is Indisposed  
services: 
- Craftsman( Good   quality, Below Average  costs) 
- Pottery( Good   quality, Below Average  costs) 
exterior: An tall building with faded paint and with brick siding with a front round window that has a sign hanging above with the merchants name. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Good   quality |  Below Average  costs | 
> | Pottery |  Good   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Cholmondeley  | Child  |  Male who is All Right   | 
>> | Coombs  | Mature Adult  |  Female who is Indisposed   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

