---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crook 
merchantCategory: Criminal
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: Pawn Reseller 
ownerName: Anlyth Nekraanea 
ownerLink: "[[Crook(Criminal) - Anlyth Nekraanea|Anlyth Nekraanea]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Criminal( Low   quality, Low  costs) 
- Deception( Poor   quality, Above Average  costs) 
- Theft( Poor   quality, Below Average  costs) 
exterior: An new two story building with new paint and with stoned siding. The roof is House. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Criminal |  Low   quality |  Low  costs | 
> | Deception |  Poor   quality |  Above Average  costs | 
> | Theft |  Poor   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

