---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Used Garment Trader 
merchantCategory: Garment Trade
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: Garment Maker 
ownerName: Biafyndar Boltolraheal 
ownerLink: "[[Used Garment Trader(Garment Trade) - Biafyndar Boltolraheal|Biafyndar Boltolraheal]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Garment Trade( Average   quality, High  costs) 
- Trader( Low   quality, Below Average  costs) 
exterior: An old long building with faded paint and with shingled siding with a front broken window that has a sign hanging above with the merchants name. The roof is Roof. A Maple pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Average   quality |  High  costs | 
> | Trader |  Low   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

