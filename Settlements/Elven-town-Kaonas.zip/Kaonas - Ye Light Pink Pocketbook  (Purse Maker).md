---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Purse Maker 
merchantCategory: Garment Trade
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: Ye Light Pink Pocketbook 
ownerName: Vhoadan Invusomaltin 
ownerLink: "[[Purse Maker(Garment Trade) - Vhoadan Invusomaltin|Vhoadan Invusomaltin]]"
ownerRace: Wood Elf
apprentices: 
- Barton (Young Adult ) Male who is Wounded  
services: 
- Garment Trade( Good   quality, Average  costs) 
- Purse Maker( Low   quality, Average  costs) 
exterior: An building with new paint and with brick siding. The roof is House. A Ceder shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Good   quality |  Average  costs | 
> | Purse Maker |  Low   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Barton  | Young Adult  |  Male who is Wounded   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

