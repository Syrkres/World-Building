---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brigand 
merchantCategory: Merc
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: JAIL,HOUSE
title: Arms for Hire 
ownerName: Soliania Phimodoneldth 
ownerLink: "[[Brigand(Merc) - Soliania Phimodoneldth|Soliania Phimodoneldth]]"
ownerRace: High  Elf
apprentices: 
- Langley (Teen ) Female who is Under the weather  
- Sutherland (Adult ) Male who is Healthy  
services: 
- Mercenary( Average   quality, Below Average  costs) 
- Enforcement( Low   quality, Below Average  costs) 
- Intimidation( Horrible   quality, Low  costs) 
exterior: An new narrow building with brick siding with a front short window that has a carved sign hanging to the side with the merchants name. The roof is Roof. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Average   quality |  Below Average  costs | 
> | Enforcement |  Low   quality |  Below Average  costs | 
> | Intimidation |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Langley  | Teen  |  Female who is Under the weather   | 
>> | Sutherland  | Adult  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

