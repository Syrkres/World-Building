---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Herbalist 
merchantCategory: Professional Specialties
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: SHOP,ALCHEMIST
title: The new Shop 
ownerName: Beldroth Wakirulmitore 
ownerLink: "[[Herbalist(Professional Specialties) - Beldroth Wakirulmitore|Beldroth Wakirulmitore]]"
ownerRace: High  Elf
apprentices: 
- York (Teen ) Female who is Scraped up  
services: 
- Professional Specialties( Good   quality, Average  costs) 
- Healing( Poor   quality, Average  costs) 
- Potion Brewing( Average   quality, High  costs) 
- Remedy Crafting( Low   quality, Above Average  costs) 
exterior: An building with shingled siding with a few windows. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Good   quality |  Average  costs | 
> | Healing |  Poor   quality |  Average  costs | 
> | Potion Brewing |  Average   quality |  High  costs | 
> | Remedy Crafting |  Low   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | York  | Teen  |  Female who is Scraped up   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

