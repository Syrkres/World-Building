---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Potato 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: FARM,HOUSE
title: Old Stone Farm 
ownerName: Phelorna Crownierannia 
ownerLink: "[[Farmer - Potato(Farmer) - Phelorna Crownierannia|Phelorna Crownierannia]]"
ownerRace: Elf
apprentices: 
- Kimberley (Young Adult ) Male who is Fit as a fiddle  
services: 
- Farmer( Average   quality, High  costs) 
- Food( Average   quality, Average  costs) 
exterior: An new building with brick siding with a few round boarded windows. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Average   quality |  High  costs | 
> | Food |  Average   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Kimberley  | Young Adult  |  Male who is Fit as a fiddle   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

