---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Juggler 
merchantCategory: Entertainer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: The Laughing Pin 
ownerName: Lyari Ulinkentylar 
ownerLink: "[[Juggler(Entertainer) - Lyari Ulinkentylar|Lyari Ulinkentylar]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Entertainer( Average   quality, Below Average  costs) 
- Performance( Horrible   quality, Above Average  costs) 
exterior: An new narrow one story building with shingled siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Entertainer |  Average   quality |  Below Average  costs | 
> | Performance |  Horrible   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

