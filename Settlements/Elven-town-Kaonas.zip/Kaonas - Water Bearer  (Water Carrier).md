---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Water Carrier 
merchantCategory: Laborer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: Water Bearer 
ownerName: Olithir Vitariannia 
ownerLink: "[[Water Carrier(Laborer) - Olithir Vitariannia|Olithir Vitariannia]]"
ownerRace: Elf
apprentices: 
- Morley (Adult ) Male who is Fine  
services: 
- Laborer( Average   quality, Above Average  costs) 
- Water Carrier( Excellent   quality, Average  costs) 
exterior: An narrow one story building with faded paint and with brick siding. The roof is Celing. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Laborer |  Average   quality |  Above Average  costs | 
> | Water Carrier |  Excellent   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Morley  | Adult  |  Male who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

