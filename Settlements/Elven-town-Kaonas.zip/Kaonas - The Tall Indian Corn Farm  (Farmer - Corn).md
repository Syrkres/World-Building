---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Corn 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: FARM,HOUSE
title: The Tall Indian Corn Farm 
ownerName: Elasha Tukwoderlylth 
ownerLink: "[[Farmer - Corn(Farmer) - Elasha Tukwoderlylth|Elasha Tukwoderlylth]]"
ownerRace: High  Elf
apprentices: 
- Breeden (Teen ) Female who is Fit  
- Rutherford (Young Adult ) Female who is Fine  
services: 
- Farmer( Excellent   quality, Below Average  costs) 
- Food( Good   quality, High  costs) 
exterior: An building with new paint and with shingled siding. The roof is Celing. A Ceder shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Excellent   quality |  Below Average  costs | 
> | Food |  Good   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Breeden  | Teen  |  Female who is Fit   | 
>> | Rutherford  | Young Adult  |  Female who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

