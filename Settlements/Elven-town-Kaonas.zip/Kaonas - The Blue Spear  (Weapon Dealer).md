---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weapon Dealer 
merchantCategory: Merchant
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: The Blue Spear 
ownerName: Fylson Ilwylwoatear 
ownerLink: "[[Weapon Dealer(Merchant) - Fylson Ilwylwoatear|Fylson Ilwylwoatear]]"
ownerRace: Wood Elf
apprentices: 
- Bentham (Teen ) Male who is All Right  
- Allerton (Adult ) Male who is Fit  
services: 
- Merchant( Low   quality, Above Average  costs) 
- Weapon Dealer( Poor   quality, Average  costs) 
exterior: An long tall building with new paint and with planked siding with a missing window. The roof is Dome. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Low   quality |  Above Average  costs | 
> | Weapon Dealer |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Bentham  | Teen  |  Male who is All Right   | 
>> | Allerton  | Adult  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

