---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chandler 
merchantCategory: Merchant
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Grove 
structure: SHOP,HOUSE
title: The Wax Candle 
ownerName: Elora Rirwoathem 
ownerLink: "[[Chandler(Merchant) - Elora Rirwoathem|Elora Rirwoathem]]"
ownerRace: Wood Elf
apprentices: 
- Rutland (Young Adult ) Female who is At death's door  
services: 
- Merchant( Horrible   quality, Low  costs) 
- Boat/Ship Merchant( Average   quality, Average  costs) 
exterior: An old building with shingled siding with a missing short window. The roof is Roof. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Horrible   quality |  Low  costs | 
> | Boat/Ship Merchant |  Average   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Rutland  | Young Adult  |  Female who is At death's door   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

