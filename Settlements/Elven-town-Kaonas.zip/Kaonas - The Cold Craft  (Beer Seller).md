---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Beer Seller 
merchantCategory: Cook
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Grove 
structure: SHOP,HOUSE
title: The Cold Craft 
ownerName: Nlaea Maernaear 
ownerLink: "[[Beer Seller(Cook) - Nlaea Maernaear|Nlaea Maernaear]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Ale Sales( Horrible   quality, Low  costs) 
exterior: An long two story building with stoned siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Ale Sales |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

