---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Knight 
merchantCategory: Knight
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: The Court Stable 
ownerName: Naeryndam Crownierundlin 
ownerLink: "[[Knight(Knight) - Naeryndam Crownierundlin|Naeryndam Crownierundlin]]"
ownerRace: High  Elf
apprentices: 
- Remington (Child ) Male who is Healthy  
- Sheldon (Teen ) Male who is Fit as a fiddle  
services: 
- Guard( Average   quality, High  costs) 
- Religion( Average   quality, High  costs) 
exterior: An old long tall building with new paint and with planked siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Guard |  Average   quality |  High  costs | 
> | Religion |  Average   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Remington  | Child  |  Male who is Healthy   | 
>> | Sheldon  | Teen  |  Male who is Fit as a fiddle   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

