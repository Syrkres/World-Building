---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barber 
merchantCategory: Specialty Service
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: Fancy Cuts 
ownerName: Gaylia Crownierurdrenn 
ownerLink: "[[Barber(Specialty Service) - Gaylia Crownierurdrenn|Gaylia Crownierurdrenn]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Specialty Service( Low   quality, Average  costs) 
- Surgery( Low   quality, Low  costs) 
exterior: An building with stoned siding with a few round shuttered windows. The roof is House. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Specialty Service |  Low   quality |  Average  costs | 
> | Surgery |  Low   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

