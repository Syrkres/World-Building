---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cabbage 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: FARM,HOUSE
title: Ye Farm 
ownerName: Purtham Henzioelrvis 
ownerLink: "[[Farmer - Cabbage(Farmer) - Purtham Henzioelrvis|Purtham Henzioelrvis]]"
ownerRace: High  Elf
apprentices: 
- Gladstone (Adult ) Female who is Healthy  
- Rutherford (Teen ) Female who is Sick  
services: 
- Farmer( Good   quality, Below Average  costs) 
- Food( Horrible   quality, Low  costs) 
exterior: An narrow building with shingled siding with a front shuttered window that has a painted sign hanging above with the merchants name. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Good   quality |  Below Average  costs | 
> | Food |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Gladstone  | Adult  |  Female who is Healthy   | 
>> | Rutherford  | Teen  |  Female who is Sick   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

