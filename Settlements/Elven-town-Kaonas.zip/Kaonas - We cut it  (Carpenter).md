---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Carpenter 
merchantCategory: Construction
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Grove 
structure: SHOP,HOUSE
title: We cut it 
ownerName: Duilya Rilynnelrvis 
ownerLink: "[[Carpenter(Construction) - Duilya Rilynnelrvis|Duilya Rilynnelrvis]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Construction( Average   quality, Average  costs) 
- Crafting( Average   quality, Average  costs) 
exterior: An one story building with shingled siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Construction |  Average   quality |  Average  costs | 
> | Crafting |  Average   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

