---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Chandler 
merchantCategory: Merchant
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: Ye Wax Candle 
ownerName: Thurruvyn Momrimraheal 
ownerLink: "[[Chandler(Merchant) - Thurruvyn Momrimraheal|Thurruvyn Momrimraheal]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Merchant( Horrible   quality, Average  costs) 
- Boat/Ship Merchant( Excellent   quality, Low  costs) 
exterior: An two story building with new paint and with stoned siding. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Horrible   quality |  Average  costs | 
> | Boat/Ship Merchant |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

