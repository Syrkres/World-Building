---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Porter 
merchantCategory: Laborer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: We Carry it 
ownerName: Illithor Brulgumrimitore 
ownerLink: "[[Porter(Laborer) - Illithor Brulgumrimitore|Illithor Brulgumrimitore]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Laborer( Horrible   quality, Above Average  costs) 
- Transporter( Good   quality, Above Average  costs) 
exterior: An old long tall building with planked siding with a front broken window that has a painted sign hanging above with the merchants name. The roof is Dome. A Yellow Birch shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Laborer |  Horrible   quality |  Above Average  costs | 
> | Transporter |  Good   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

