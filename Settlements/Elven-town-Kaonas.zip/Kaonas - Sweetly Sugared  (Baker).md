---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker 
merchantCategory: Cook
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Grove 
structure: SHOP,HOUSE
title: Sweetly Sugared 
ownerName: Bonnalurie Kralsebereplith 
ownerLink: "[[Baker(Cook) - Bonnalurie Kralsebereplith|Bonnalurie Kralsebereplith]]"
ownerRace: High  Elf
apprentices: 
- Abram (Teen ) Female who is Fine  
- Burton (Adult ) Female who is Hurt  
services: 
- Cook( Horrible   quality, Above Average  costs) 
- Bread and Pastry Making( Excellent   quality, Low  costs) 
exterior: An two story building with brick siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Horrible   quality |  Above Average  costs | 
> | Bread and Pastry Making |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Abram  | Teen  |  Female who is Fine   | 
>> | Burton  | Adult  |  Female who is Hurt   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

