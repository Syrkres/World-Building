---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barber 
merchantCategory: Specialty Service
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: Care Clippers 
ownerName: Teharissa Sentalialelrvis 
ownerLink: "[[Barber(Specialty Service) - Teharissa Sentalialelrvis|Teharissa Sentalialelrvis]]"
ownerRace: High  Elf
apprentices: 
- Cromwell (Young Adult ) Male who is Fine  
services: 
- Specialty Service( Excellent   quality, Low  costs) 
- Surgery( Horrible   quality, Average  costs) 
exterior: An new tall building with faded paint and with brick siding with a missing tall window. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Specialty Service |  Excellent   quality |  Low  costs | 
> | Surgery |  Horrible   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Cromwell  | Young Adult  |  Male who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

