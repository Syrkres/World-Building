---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Laborer 
merchantCategory: Laborer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: Federation Hall 
ownerName: Nambra Ilennddare 
ownerLink: "[[Laborer(Laborer) - Nambra Ilennddare|Nambra Ilennddare]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Laborer( Excellent   quality, Low  costs) 
exterior: An old building with stoned siding. The roof is Celing. A Maple shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Laborer |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

