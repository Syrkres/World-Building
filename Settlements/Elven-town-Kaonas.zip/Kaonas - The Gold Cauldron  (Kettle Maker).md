---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Kettle Maker 
merchantCategory: Craftsman
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: SHOP,HOUSE
title: The Gold Cauldron 
ownerName: Daratrine Mizunnddare 
ownerLink: "[[Kettle Maker(Craftsman) - Daratrine Mizunnddare|Daratrine Mizunnddare]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Craftsman( Excellent   quality, High  costs) 
- Merchant( Low   quality, High  costs) 
exterior: An new building with stoned siding. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Excellent   quality |  High  costs | 
> | Merchant |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

