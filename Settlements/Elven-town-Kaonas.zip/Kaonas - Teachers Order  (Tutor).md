---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tutor 
merchantCategory: Sage
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: Teachers Order 
ownerName: Mihangyl Ideasvirrea 
ownerLink: "[[Tutor(Sage) - Mihangyl Ideasvirrea|Mihangyl Ideasvirrea]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Sage( Excellent   quality, Low  costs) 
- Teaching( Excellent   quality, Above Average  costs) 
- Research( Low   quality, Low  costs) 
exterior: An new one story building with planked siding with a few windows. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Excellent   quality |  Low  costs | 
> | Teaching |  Excellent   quality |  Above Average  costs | 
> | Research |  Low   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

