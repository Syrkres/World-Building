---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Laborer 
merchantCategory: Laborer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: Union Hall 
ownerName: Edic've Teasen'fathem 
ownerLink: "[[Laborer(Laborer) - Edic've Teasen'fathem|Edic've Teasen'fathem]]"
ownerRace: Elf
apprentices: 
- Hale (Teen ) Male who is At death's door  
- Hale (Teen ) Female who is Hurt  
services: 
- Laborer( Average   quality, High  costs) 
exterior: An narrow one story building with brick siding with a missing window. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Laborer |  Average   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Hale  | Teen  |  Male who is At death's door   | 
>> | Hale  | Teen  |  Female who is Hurt   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

