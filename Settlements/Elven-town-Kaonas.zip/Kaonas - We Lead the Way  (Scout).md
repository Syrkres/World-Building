---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Scout 
merchantCategory: Tracker
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: We Lead the Way 
ownerName: Tiatha Aritianmitore 
ownerLink: "[[Scout(Tracker) - Tiatha Aritianmitore|Tiatha Aritianmitore]]"
ownerRace: Wood Elf
apprentices: 
- Asheton (Mature Adult ) Male who is Deceased  
services: 
- Tracker( Excellent   quality, Above Average  costs) 
- Scout( Horrible   quality, Average  costs) 
exterior: An building with new paint and with shingled siding with a front boarded window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. A Yellow Birch shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Tracker |  Excellent   quality |  Above Average  costs | 
> | Scout |  Horrible   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Asheton  | Mature Adult  |  Male who is Deceased   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

