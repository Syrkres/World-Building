---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Troubadours 
merchantCategory: Entertainer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: Lyrics are Us 
ownerName: Simimar Auvreaettln 
ownerLink: "[[Troubadours(Entertainer) - Simimar Auvreaettln|Simimar Auvreaettln]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Entertainer( Good   quality, Above Average  costs) 
- Troubadours( Excellent   quality, Above Average  costs) 
exterior: An old tall building with faded paint and with shingled siding with a few short windows. The roof is Canopy. A Beech shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Entertainer |  Good   quality |  Above Average  costs | 
> | Troubadours |  Excellent   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

