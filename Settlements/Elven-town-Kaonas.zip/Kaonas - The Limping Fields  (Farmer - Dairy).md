---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Dairy 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: FARM,HOUSE
title: The Limping Fields 
ownerName: Maiele Hunithghymn 
ownerLink: "[[Farmer - Dairy(Farmer) - Maiele Hunithghymn|Maiele Hunithghymn]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Farmer( Low   quality, Low  costs) 
- Milk( Good   quality, Average  costs) 
- Food( Poor   quality, High  costs) 
exterior: An building with new paint and with planked siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Low   quality |  Low  costs | 
> | Milk |  Good   quality |  Average  costs | 
> | Food |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

