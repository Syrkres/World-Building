---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weapon Dealer 
merchantCategory: Merchant
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: The Pink Sword 
ownerName: Taanyth Eytheraltin 
ownerLink: "[[Weapon Dealer(Merchant) - Taanyth Eytheraltin|Taanyth Eytheraltin]]"
ownerRace: High  Elf
apprentices: 
- Rutherford (Adult ) Male who is Fine  
services: 
- Merchant( Average   quality, Average  costs) 
- Weapon Dealer( Horrible   quality, Below Average  costs) 
exterior: An long building with faded paint and with shingled siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Average   quality |  Average  costs | 
> | Weapon Dealer |  Horrible   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Rutherford  | Adult  |  Male who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

