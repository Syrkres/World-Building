---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker 
merchantCategory: Garment Trade
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: SHOP,HOUSE
title: Ye Headgear Maker 
ownerName: Fhaornik Tinvihamneldth 
ownerLink: "[[Hat Maker(Garment Trade) - Fhaornik Tinvihamneldth|Fhaornik Tinvihamneldth]]"
ownerRace: Elf
apprentices: 
- Elton (Adult ) Male who is All Right  
- Davenport (Teen ) Female who is Inured  
services: 
- Garment Trade( Low   quality, Below Average  costs) 
- Hat Maker( Low   quality, Low  costs) 
exterior: An new one story building with shingled siding with a front boarded window that has a carved sign hanging to the side with the merchants name. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Low   quality |  Below Average  costs | 
> | Hat Maker |  Low   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Elton  | Adult  |  Male who is All Right   | 
>> | Davenport  | Teen  |  Female who is Inured   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

