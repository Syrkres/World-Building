---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Potato 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: FARM,HOUSE
title: Old Stone Fields 
ownerName: Ylyndar Wolgoannia 
ownerLink: "[[Farmer - Potato(Farmer) - Ylyndar Wolgoannia|Ylyndar Wolgoannia]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Farmer( Low   quality, High  costs) 
- Food( Good   quality, High  costs) 
exterior: An old one story building with faded paint and with planked siding with a front tall broken window that has a carved sign hanging to the side with the merchants name. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Low   quality |  High  costs | 
> | Food |  Good   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

