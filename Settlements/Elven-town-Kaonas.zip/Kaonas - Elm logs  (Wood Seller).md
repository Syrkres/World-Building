---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wood Seller 
merchantCategory: Merchant
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Grove 
structure: SHOP,HOUSE
title: Elm logs 
ownerName: Talila Opulumatear 
ownerLink: "[[Wood Seller(Merchant) - Talila Opulumatear|Talila Opulumatear]]"
ownerRace: Wood Elf
apprentices: 
- Ainsworth (Teen ) Male who is Healthy  
- Lindsay (Teen ) Female who is Fit  
services: 
- Lumberjack( Low   quality, Low  costs) 
- Wood Seller( Low   quality, High  costs) 
exterior: An one story building with new paint and with shingled siding. The roof is Celing. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Lumberjack |  Low   quality |  Low  costs | 
> | Wood Seller |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Ainsworth  | Teen  |  Male who is Healthy   | 
>> | Lindsay  | Teen  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

