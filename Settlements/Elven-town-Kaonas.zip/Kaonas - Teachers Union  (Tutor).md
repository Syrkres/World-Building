---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tutor 
merchantCategory: Sage
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: Teachers Union 
ownerName: Naertho Ilwylworaheal 
ownerLink: "[[Tutor(Sage) - Naertho Ilwylworaheal|Naertho Ilwylworaheal]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Sage( Excellent   quality, Below Average  costs) 
- Teaching( Low   quality, Low  costs) 
- Research( Average   quality, Above Average  costs) 
exterior: An new long building with faded paint and with brick siding. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Excellent   quality |  Below Average  costs | 
> | Teaching |  Low   quality |  Low  costs | 
> | Research |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

