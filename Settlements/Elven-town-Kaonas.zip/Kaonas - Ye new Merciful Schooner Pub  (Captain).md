---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Captain 
merchantCategory: Merc
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: JAIL
title: Ye new Merciful Schooner Pub 
ownerName: Ilitharath Kralseberaltin 
ownerLink: "[[Captain(Merc) - Ilitharath Kralseberaltin|Ilitharath Kralseberaltin]]"
ownerRace: Elf
apprentices: 
- Thornton (Adult ) Male who is Healthy  
- Beverly (Young Adult ) Female who is Fine  
services: 
- Mercenary( Poor   quality, Low  costs) 
- Leadership( Horrible   quality, High  costs) 
exterior: An new one story building with new paint and with brick siding with a front round broken window that has a carved sign hanging to the side with the merchants name. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Poor   quality |  Low  costs | 
> | Leadership |  Horrible   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Thornton  | Adult  |  Male who is Healthy   | 
>> | Beverly  | Young Adult  |  Female who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

