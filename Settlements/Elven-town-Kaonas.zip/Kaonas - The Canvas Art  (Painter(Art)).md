---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Painter(Art) 
merchantCategory: Artisan
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: 
structure: SHOP,HOUSE
title: The Canvas Art 
ownerName: Ilythyrra Orleelrvis 
ownerLink: "[[Painter(Art)(Artisan) - Ilythyrra Orleelrvis|Ilythyrra Orleelrvis]]"
ownerRace: Elf
apprentices: 
- Nash (Young Adult ) Male who is Well  
services: 
- Artisan( Average   quality, Above Average  costs) 
exterior: An old narrow tall building with brick siding. The roof is Roof. A Beech pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Artisan |  Average   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Nash  | Young Adult  |  Male who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

