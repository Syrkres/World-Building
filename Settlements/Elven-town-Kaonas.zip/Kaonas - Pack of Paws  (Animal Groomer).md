---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Animal Groomer 
merchantCategory: Animal Handler
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: TANNERY,FARM,STABLE
title: Pack of Paws 
ownerName: Ruven Salinathem 
ownerLink: "[[Animal Groomer(Animal Handler) - Ruven Salinathem|Ruven Salinathem]]"
ownerRace: High  Elf
apprentices: 
- Rylan (Young Adult ) Male who is Healthy  
services: 
- Animal Handler( Excellent   quality, Above Average  costs) 
- Pet Training( Horrible   quality, Below Average  costs) 
- Animal Training( Good   quality, Average  costs) 
exterior: An long tall building with stoned siding with a missing window. The roof is Roof. A Pine shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Animal Handler |  Excellent   quality |  Above Average  costs | 
> | Pet Training |  Horrible   quality |  Below Average  costs | 
> | Animal Training |  Good   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Rylan  | Young Adult  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

