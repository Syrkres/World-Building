---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian 
merchantCategory: Merc
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,STABLE
title: The Dark Green Dragon Lodge 
ownerName: Althidon Wolgourdrenn 
ownerLink: "[[Barbarian(Merc) - Althidon Wolgourdrenn|Althidon Wolgourdrenn]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Mercenary( Low   quality, Above Average  costs) 
- Tracking( Horrible   quality, Below Average  costs) 
exterior: An narrow building with new paint and with shingled siding. The roof is House. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Low   quality |  Above Average  costs | 
> | Tracking |  Horrible   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

