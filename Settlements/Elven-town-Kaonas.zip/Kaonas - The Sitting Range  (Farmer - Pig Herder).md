---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Pig Herder 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: FARM,HOUSE
title: The Sitting Range 
ownerName: Nylian Dresarraheal 
ownerLink: "[[Farmer - Pig Herder(Farmer) - Nylian Dresarraheal|Nylian Dresarraheal]]"
ownerRace: High  Elf
apprentices: 
- Ogden (Teen ) Male who is Impaired  
services: 
- Farmer( Poor   quality, Average  costs) 
- Food( Excellent   quality, Above Average  costs) 
- Herding( Good   quality, Below Average  costs) 
exterior: An new narrow one story building with faded paint and with brick siding. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Poor   quality |  Average  costs | 
> | Food |  Excellent   quality |  Above Average  costs | 
> | Herding |  Good   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Ogden  | Teen  |  Male who is Impaired   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

