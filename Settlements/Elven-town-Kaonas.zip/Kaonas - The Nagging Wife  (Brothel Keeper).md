---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brothel Keeper 
merchantCategory: Hostelers
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: The Nagging Wife 
ownerName: Lorelei Opulumsithek 
ownerLink: "[[Brothel Keeper(Hostelers) - Lorelei Opulumsithek|Lorelei Opulumsithek]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Room (Pleasure)( Average   quality, Low  costs) 
- Common Room (Sleeping)( Good   quality, Low  costs) 
- Room (Meeting)( Average   quality, Above Average  costs) 
exterior: An narrow one story building with stoned siding with a missing window. The roof is Roof. A Maple shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Room  | Pleasure | ( Average   quality | 
> | Common Room  | Sleeping | ( Good   quality | 
> | Room  | Meeting | ( Average   quality | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

