---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Shoe Maker 
merchantCategory: Garment Trade
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: Shoe Trader 
ownerName: Iymbryl Erwulylth 
ownerLink: "[[Shoe Maker(Garment Trade) - Iymbryl Erwulylth|Iymbryl Erwulylth]]"
ownerRace: High  Elf
apprentices: 
- Brownrigg (Young Adult ) Male who is Wounded  
- Snape (Adult ) Female who is Fine  
services: 
- Garment Trade( Low   quality, Below Average  costs) 
- Shoe Maker( Excellent   quality, Average  costs) 
exterior: An old building with new paint and with shingled siding with a few tall broken windows. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Low   quality |  Below Average  costs | 
> | Shoe Maker |  Excellent   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Brownrigg  | Young Adult  |  Male who is Wounded   | 
>> | Snape  | Adult  |  Female who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

