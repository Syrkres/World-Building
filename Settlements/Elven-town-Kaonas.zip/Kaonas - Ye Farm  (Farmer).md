---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: Ye Farm 
ownerName: Shalendra Migalarnith 
ownerLink: "[[Farmer(Farmer) - Shalendra Migalarnith|Shalendra Migalarnith]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Farmer( Average   quality, High  costs) 
- Food( Horrible   quality, High  costs) 
exterior: An old two story building with new paint and with planked siding with a missing short window. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Average   quality |  High  costs | 
> | Food |  Horrible   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

