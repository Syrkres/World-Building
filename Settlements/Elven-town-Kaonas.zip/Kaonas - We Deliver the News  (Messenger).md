---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Messenger 
merchantCategory: Laborer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHRINE,HOUSE
title: We Deliver the News 
ownerName: Taleisin Dwin’thym 
ownerLink: "[[Messenger(Laborer) - Taleisin Dwin’thym|Taleisin Dwin’thym]]"
ownerRace: Elf
apprentices: 
- Payton (Young Adult ) Male who is Fit  
services: 
- Messenger( Good   quality, Below Average  costs) 
- Transcripts( Good   quality, Average  costs) 
exterior: An old building with faded paint and with shingled siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Messenger |  Good   quality |  Below Average  costs | 
> | Transcripts |  Good   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Payton  | Young Adult  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

