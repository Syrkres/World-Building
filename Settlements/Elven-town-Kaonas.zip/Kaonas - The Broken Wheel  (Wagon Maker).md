---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Wagon Maker 
merchantCategory: Craftsman
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: The Broken Wheel 
ownerName: Neldor Takelseghymn 
ownerLink: "[[Wagon Maker(Craftsman) - Neldor Takelseghymn|Neldor Takelseghymn]]"
ownerRace: Wood Elf
apprentices: 
- Clayton (Teen ) Male who is Not oneself  
services: 
- Craftsman( Excellent   quality, High  costs) 
- Wagon Maker( Good   quality, Below Average  costs) 
exterior: An building with planked siding with a few short windows. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Excellent   quality |  High  costs | 
> | Wagon Maker |  Good   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Clayton  | Teen  |  Male who is Not oneself   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

