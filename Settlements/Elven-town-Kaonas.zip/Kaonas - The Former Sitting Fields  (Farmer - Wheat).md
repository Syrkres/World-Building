---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Wheat 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: FARM,HOUSE
title: The Former Sitting Fields 
ownerName: Rhespen Vunilmyrghymn 
ownerLink: "[[Farmer - Wheat(Farmer) - Rhespen Vunilmyrghymn|Rhespen Vunilmyrghymn]]"
ownerRace: High  Elf
apprentices: 
- Brent (Young Adult ) Female who is Healthy  
services: 
- Farmer( Horrible   quality, Above Average  costs) 
- Food( Low   quality, Above Average  costs) 
exterior: An new building with faded paint and with planked siding with a missing tall window. The roof is Dome. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Horrible   quality |  Above Average  costs | 
> | Food |  Low   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Brent  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

