---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Weaver 
merchantCategory: Garment Trade
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: Weavers 
ownerName: Kaylessa Hunithundlin 
ownerLink: "[[Weaver(Garment Trade) - Kaylessa Hunithundlin|Kaylessa Hunithundlin]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Garment Trade( Poor   quality, Low  costs) 
- Weaver( Poor   quality, High  costs) 
exterior: An long building with faded paint and with planked siding with a few tall windows. The roof is Dome. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Poor   quality |  Low  costs | 
> | Weaver |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

