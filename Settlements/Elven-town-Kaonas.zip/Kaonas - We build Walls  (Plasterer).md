---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Plasterer 
merchantCategory: Construction
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: We build Walls 
ownerName: Quamara Zepomrarrae 
ownerLink: "[[Plasterer(Construction) - Quamara Zepomrarrae|Quamara Zepomrarrae]]"
ownerRace: Wood Elf
apprentices: 
- Harley (Young Adult ) Female who is Well  
services: 
- Construction( Poor   quality, Average  costs) 
- Plasterer( Poor   quality, Average  costs) 
exterior: An old building with new paint and with planked siding. The roof is Dome. A Pine shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Construction |  Poor   quality |  Average  costs | 
> | Plasterer |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Harley  | Young Adult  |  Female who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

