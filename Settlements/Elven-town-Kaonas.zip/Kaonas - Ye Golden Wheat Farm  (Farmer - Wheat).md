---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Wheat 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: FARM,HOUSE
title: Ye Golden Wheat Farm 
ownerName: Abadda Ulmenrae 
ownerLink: "[[Farmer - Wheat(Farmer) - Abadda Ulmenrae|Abadda Ulmenrae]]"
ownerRace: Wood Elf
apprentices: 
- Oakley (Young Adult ) Male who is All Right  
services: 
- Farmer( Average   quality, Low  costs) 
- Food( Average   quality, Average  costs) 
exterior: An new building with brick siding with a front short shuttered window that has a sign hanging above with the merchants name. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Average   quality |  Low  costs | 
> | Food |  Average   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Oakley  | Young Adult  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

