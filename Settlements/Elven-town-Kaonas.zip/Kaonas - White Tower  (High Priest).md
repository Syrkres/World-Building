---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Priest 
merchantCategory: Clergy
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: 
structure: SHRINE,HOUSE
title: White Tower 
ownerName: Kuornos Hulwarvamtlithar 
ownerLink: "[[High Priest(Clergy) - Kuornos Hulwarvamtlithar|Kuornos Hulwarvamtlithar]]"
ownerRace: High  Elf
apprentices: 
- Wilberforce (Teen ) Female who is Fit as a fiddle  
services: 
- Clergy( Poor   quality, Above Average  costs) 
- Scroll Crafting( Good   quality, Average  costs) 
- Potion Crafting( Good   quality, Average  costs) 
- Spell Research( Good   quality, Low  costs) 
- Healing( Excellent   quality, Average  costs) 
exterior: An narrow two story building with stoned siding with a front boarded window that has a carved sign hanging to the side with the merchants name. The roof is House. A Maple shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Poor   quality |  Above Average  costs | 
> | Scroll Crafting |  Good   quality |  Average  costs | 
> | Potion Crafting |  Good   quality |  Average  costs | 
> | Spell Research |  Good   quality |  Low  costs | 
> | Healing |  Excellent   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Wilberforce  | Teen  |  Female who is Fit as a fiddle   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

