---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sailor 
merchantCategory: Merc
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: Ye Bored WARF Mug 
ownerName: Oslarelar Salinrae 
ownerLink: "[[Sailor(Merc) - Oslarelar Salinrae|Oslarelar Salinrae]]"
ownerRace: Elf
apprentices: 
- Ryley (Teen ) Male who is Healthy  
services: 
- Mercenary( Poor   quality, Low  costs) 
- Sailor( Average   quality, Above Average  costs) 
- Thug( Good   quality, High  costs) 
exterior: An building with faded paint and with planked siding. The roof is Celing. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Poor   quality |  Low  costs | 
> | Sailor |  Average   quality |  Above Average  costs | 
> | Thug |  Good   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Ryley  | Teen  |  Male who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

