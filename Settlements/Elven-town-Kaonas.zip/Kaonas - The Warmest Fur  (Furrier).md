---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Furrier 
merchantCategory: Garment Trade
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: The Warmest Fur 
ownerName: Kuskyn Bilnenkedlues 
ownerLink: "[[Furrier(Garment Trade) - Kuskyn Bilnenkedlues|Kuskyn Bilnenkedlues]]"
ownerRace: Elf
apprentices: 
- Bradley (Teen ) Female who is Expired  
services: 
- Garment Trade( Low   quality, Below Average  costs) 
- Fur Processing( Low   quality, Below Average  costs) 
exterior: An building with faded paint and with shingled siding with a front tall broken window that has a sign hanging above with the merchants name. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Low   quality |  Below Average  costs | 
> | Fur Processing |  Low   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Bradley  | Teen  |  Female who is Expired   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

