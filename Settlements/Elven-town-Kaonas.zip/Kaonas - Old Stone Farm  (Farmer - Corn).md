---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Corn 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: FARM,HOUSE
title: Old Stone Farm 
ownerName: Mlossae Teasen'fraheal 
ownerLink: "[[Farmer - Corn(Farmer) - Mlossae Teasen'fraheal|Mlossae Teasen'fraheal]]"
ownerRace: Wood Elf
apprentices: 
- Alby (Teen ) Male who is Sick  
- Roscoe (Young Adult ) Male who is Well  
services: 
- Farmer( Poor   quality, Low  costs) 
- Food( Excellent   quality, Above Average  costs) 
exterior: An old two story building with faded paint and with stoned siding. The roof is Celing. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Poor   quality |  Low  costs | 
> | Food |  Excellent   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Alby  | Teen  |  Male who is Sick   | 
>> | Roscoe  | Young Adult  |  Male who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

