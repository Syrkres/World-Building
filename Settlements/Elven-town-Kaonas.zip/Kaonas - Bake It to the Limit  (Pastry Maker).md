---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Pastry Maker 
merchantCategory: Cook
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: Bake It to the Limit 
ownerName: Chasianna Sentalialdlues 
ownerLink: "[[Pastry Maker(Cook) - Chasianna Sentalialdlues|Chasianna Sentalialdlues]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Cook( Excellent   quality, Average  costs) 
- Pastry Maker( Poor   quality, Below Average  costs) 
exterior: An building with shingled siding. The roof is Dome. A Yellow Birch shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Excellent   quality |  Average  costs | 
> | Pastry Maker |  Poor   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

