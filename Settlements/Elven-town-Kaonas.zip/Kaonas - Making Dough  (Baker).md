---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Baker 
merchantCategory: Cook
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: Making Dough 
ownerName: Brindarry Arkeneasithek 
ownerLink: "[[Baker(Cook) - Brindarry Arkeneasithek|Brindarry Arkeneasithek]]"
ownerRace: Wood Elf
apprentices: 
- Myerscough (Teen ) Male who is Indisposed  
- Haley (Mature Adult ) Female who is Healthy  
services: 
- Cook( Low   quality, Average  costs) 
- Bread and Pastry Making( Good   quality, Low  costs) 
exterior: An new long two story building with planked siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Low   quality |  Average  costs | 
> | Bread and Pastry Making |  Good   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Myerscough  | Teen  |  Male who is Indisposed   | 
>> | Haley  | Mature Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

