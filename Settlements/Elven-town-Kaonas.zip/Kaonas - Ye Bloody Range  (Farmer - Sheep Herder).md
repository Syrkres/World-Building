---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Sheep Herder 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: FARM,HOUSE
title: Ye Bloody Range 
ownerName: Darfin Kralseberannia 
ownerLink: "[[Farmer - Sheep Herder(Farmer) - Darfin Kralseberannia|Darfin Kralseberannia]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Farmer( Average   quality, Low  costs) 
- Food( Excellent   quality, Low  costs) 
- Herding( Average   quality, Average  costs) 
exterior: An narrow tall building with faded paint and with shingled siding. The roof is Celing. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Average   quality |  Low  costs | 
> | Food |  Excellent   quality |  Low  costs | 
> | Herding |  Average   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

