---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Silversmith 
merchantCategory: Artisan
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: 
structure: SHOP,HOUSE
title: The Emporium 
ownerName: Chin�nesstre Killeaear 
ownerLink: "[[Silversmith(Artisan) - Chin�nesstre Killeaear|Chin�nesstre Killeaear]]"
ownerRace: High  Elf
apprentices: 
- Law (Adult ) Male who is Deceased  
services: 
- Jewelery Crafting( Excellent   quality, Low  costs) 
- Silver Crafting( Poor   quality, Above Average  costs) 
- Gem Cutting( Good   quality, Below Average  costs) 
exterior: An new two story building with new paint and with brick siding. The roof is Celing. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Jewelery Crafting |  Excellent   quality |  Low  costs | 
> | Silver Crafting |  Poor   quality |  Above Average  costs | 
> | Gem Cutting |  Good   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Law  | Adult  |  Male who is Deceased   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

