---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Physic/Chirurgeon 
merchantCategory: Professional Specialties
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,ALCHEMIST
title: We repair You 
ownerName: Roanmara Mizunrretyn 
ownerLink: "[[Physic/Chirurgeon(Professional Specialties) - Roanmara Mizunrretyn|Roanmara Mizunrretyn]]"
ownerRace: High  Elf
apprentices: 
- York (Teen ) Female who is Fit  
services: 
- Healing( Good   quality, Above Average  costs) 
exterior: An old one story building with brick siding with a front short window that has a painted sign hanging above with the merchants name. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Healing |  Good   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | York  | Teen  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

