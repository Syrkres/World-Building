---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Fishmonger 
merchantCategory: Cook
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Grove 
structure: SHOP,HOUSE
title: Ye Pike Trader 
ownerName: Yeschant Ilenannia 
ownerLink: "[[Fishmonger(Cook) - Yeschant Ilenannia|Yeschant Ilenannia]]"
ownerRace: Wood Elf
apprentices: 
- Livingstone (Young Adult ) Male who is Sick  
services: 
- Cook( Good   quality, Average  costs) 
- Food( Horrible   quality, Above Average  costs) 
exterior: An old building with new paint and with planked siding. The roof is Roof. A Oak shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Good   quality |  Average  costs | 
> | Food |  Horrible   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Livingstone  | Young Adult  |  Male who is Sick   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

