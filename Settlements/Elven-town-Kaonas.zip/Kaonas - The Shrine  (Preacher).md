---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Preacher 
merchantCategory: Clergy
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHRINE,HOUSE
title: The Shrine 
ownerName: Tanyl Devonkalathem 
ownerLink: "[[Preacher(Clergy) - Tanyl Devonkalathem|Tanyl Devonkalathem]]"
ownerRace: High  Elf
apprentices: 
- Dryden (Young Adult ) Female who is Out of sorts  
- Willoughby (Teen ) Female who is Healthy  
services: 
- Clergy( Excellent   quality, Below Average  costs) 
- Religion( Good   quality, Low  costs) 
exterior: An narrow two story building with new paint and with stoned siding with a missing short window. The roof is House. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Excellent   quality |  Below Average  costs | 
> | Religion |  Good   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Dryden  | Young Adult  |  Female who is Out of sorts   | 
>> | Willoughby  | Teen  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

