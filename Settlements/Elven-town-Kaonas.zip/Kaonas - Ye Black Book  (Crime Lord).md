---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Crime Lord 
merchantCategory: Criminal
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: Ye Black Book 
ownerName: Tamnaeuth Bunilirmitore 
ownerLink: "[[Crime Lord(Criminal) - Tamnaeuth Bunilirmitore|Tamnaeuth Bunilirmitore]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Blackmarket( Poor   quality, High  costs) 
- Merchant( Poor   quality, High  costs) 
- Transfer of Goods( Excellent   quality, Average  costs) 
exterior: An building with faded paint and with brick siding. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Blackmarket |  Poor   quality |  High  costs | 
> | Merchant |  Poor   quality |  High  costs | 
> | Transfer of Goods |  Excellent   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

