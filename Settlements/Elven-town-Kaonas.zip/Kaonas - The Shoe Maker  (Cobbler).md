---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Cobbler 
merchantCategory: Garment Trade
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: The Shoe Maker 
ownerName: Quynn Aleanarnith 
ownerLink: "[[Cobbler(Garment Trade) - Quynn Aleanarnith|Quynn Aleanarnith]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Garment Trade( Low   quality, Above Average  costs) 
- Shoe Repair( Horrible   quality, Below Average  costs) 
exterior: An new one story building with planked siding with a missing tall window. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Low   quality |  Above Average  costs | 
> | Shoe Repair |  Horrible   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

