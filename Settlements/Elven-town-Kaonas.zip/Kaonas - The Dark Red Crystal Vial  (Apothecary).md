---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Apothecary 
merchantCategory: Professional Specialties
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Grove 
structure: SHOP,ALCHEMIST
title: The Dark Red Crystal Vial 
ownerName: Melisander Ilenitryn 
ownerLink: "[[Apothecary(Professional Specialties) - Melisander Ilenitryn|Melisander Ilenitryn]]"
ownerRace: Elf
apprentices: 
- Acton (Teen ) Male who is Deceased  
- Shelly (Teen ) Female who is Fine  
services: 
- Professional Specialties( Poor   quality, High  costs) 
- Healing( Horrible   quality, High  costs) 
- Potion Brewing( Good   quality, Below Average  costs) 
- Remedy Crafting( Poor   quality, Average  costs) 
exterior: An old one story building with new paint and with stoned siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Professional Specialties |  Poor   quality |  High  costs | 
> | Healing |  Horrible   quality |  High  costs | 
> | Potion Brewing |  Good   quality |  Below Average  costs | 
> | Remedy Crafting |  Poor   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Acton  | Teen  |  Male who is Deceased   | 
>> | Shelly  | Teen  |  Female who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

