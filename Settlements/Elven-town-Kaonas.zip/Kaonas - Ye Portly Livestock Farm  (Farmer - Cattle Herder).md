---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Cattle Herder 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: FARM,HOUSE
title: Ye Portly Livestock Farm 
ownerName: Khuumal Melithathem 
ownerLink: "[[Farmer - Cattle Herder(Farmer) - Khuumal Melithathem|Khuumal Melithathem]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Farmer( Horrible   quality, Above Average  costs) 
- Food( Low   quality, Low  costs) 
exterior: An tall building with faded paint and with shingled siding with a front window that has a carved sign hanging to the side with the merchants name. The roof is Celing. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Horrible   quality |  Above Average  costs | 
> | Food |  Low   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

