---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Oil Trader 
merchantCategory: Merchant
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: Ye Fuel Trader 
ownerName: Nhamashal Rhosurulghymn 
ownerLink: "[[Oil Trader(Merchant) - Nhamashal Rhosurulghymn|Nhamashal Rhosurulghymn]]"
ownerRace: Wood Elf
apprentices: 
- Kendal (Teen ) Male who is Nauseos  
services: 
- Merchant( Average   quality, Low  costs) 
- Oil Trader( Good   quality, Above Average  costs) 
exterior: An building with brick siding. The roof is Celing. A Red Oak shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Average   quality |  Low  costs | 
> | Oil Trader |  Good   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Kendal  | Teen  |  Male who is Nauseos   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

