---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities 
merchantCategory: Merchant
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,EXOTIC ARTISAN
title: The new The old Desk     
ownerName: Hycis Sentalialundlin 
ownerLink: "[[Antiquities(Merchant) - Hycis Sentalialundlin|Hycis Sentalialundlin]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Merchant( Excellent   quality, High  costs) 
- Item Research( Horrible   quality, Above Average  costs) 
exterior: An new tall building with planked siding with a missing window. The roof is Celing. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Excellent   quality |  High  costs | 
> | Item Research |  Horrible   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

