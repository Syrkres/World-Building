---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Mason 
merchantCategory: Construction
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: SHOP,HOUSE
title: The Brick Layer 
ownerName: Chalsarda Ousseaeplith 
ownerLink: "[[Mason(Construction) - Chalsarda Ousseaeplith|Chalsarda Ousseaeplith]]"
ownerRace: Elf
apprentices: 
- Clapham (Teen ) Male who is Out of sorts  
services: 
- Construction( Excellent   quality, High  costs) 
- Laborer( Low   quality, Above Average  costs) 
exterior: An new building with new paint and with planked siding. The roof is House. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Construction |  Excellent   quality |  High  costs | 
> | Laborer |  Low   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Clapham  | Teen  |  Male who is Out of sorts   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

