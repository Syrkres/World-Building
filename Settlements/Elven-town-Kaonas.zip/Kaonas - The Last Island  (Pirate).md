---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Pirate 
merchantCategory: Merc
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: The Last Island 
ownerName: Edwyrd Beltinaear 
ownerLink: "[[Pirate(Merc) - Edwyrd Beltinaear|Edwyrd Beltinaear]]"
ownerRace: High  Elf
apprentices: 
- Digby (Adult ) Female who is Wounded  
services: 
- Mercenary( Good   quality, Above Average  costs) 
- Intimidation( Average   quality, Above Average  costs) 
- Shipping( Low   quality, Average  costs) 
- Guarding( Low   quality, Low  costs) 
exterior: An long building with shingled siding with a few tall windows. The roof is Canopy. A Red Oak pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Good   quality |  Above Average  costs | 
> | Intimidation |  Average   quality |  Above Average  costs | 
> | Shipping |  Low   quality |  Average  costs | 
> | Guarding |  Low   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Digby  | Adult  |  Female who is Wounded   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

