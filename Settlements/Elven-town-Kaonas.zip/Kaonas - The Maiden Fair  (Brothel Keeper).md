---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Brothel Keeper 
merchantCategory: Hostelers
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: The Maiden Fair 
ownerName: Alloralla Lemenkenatear 
ownerLink: "[[Brothel Keeper(Hostelers) - Alloralla Lemenkenatear|Alloralla Lemenkenatear]]"
ownerRace: Elf
apprentices: 
- Ogden (Young Adult ) Male who is Fit  
- Lindsay (Teen ) Female who is Scraped up  
services: 
- Room (Pleasure)( Average   quality, Average  costs) 
- Common Room (Sleeping)( Average   quality, Above Average  costs) 
- Room (Meeting)( Average   quality, Low  costs) 
exterior: An new building with stoned siding with a front window that has a painted sign hanging above with the merchants name. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Room  | Pleasure | ( Average   quality | 
> | Common Room  | Sleeping | ( Average   quality | 
> | Room  | Meeting | ( Average   quality | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Ogden  | Young Adult  |  Male who is Fit   | 
>> | Lindsay  | Teen  |  Female who is Scraped up   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

