---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian 
merchantCategory: Merc
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,STABLE
title: The Lizardman   Club 
ownerName: Nesterin Pemyrsithek 
ownerLink: "[[Barbarian(Merc) - Nesterin Pemyrsithek|Nesterin Pemyrsithek]]"
ownerRace: Elf
apprentices: 
- Dayton (Teen ) Male who is Dying  
- Spaulding (Teen ) Male who is Fit  
services: 
- Mercenary( Excellent   quality, Below Average  costs) 
- Tracking( Excellent   quality, Average  costs) 
exterior: An building with new paint and with planked siding with a few round shuttered windows. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Excellent   quality |  Below Average  costs | 
> | Tracking |  Excellent   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Dayton  | Teen  |  Male who is Dying   | 
>> | Spaulding  | Teen  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

