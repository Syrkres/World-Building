---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Taverner 
merchantCategory: Hostelers
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: SHOP,HOUSE
title: The Broken Dark Black Broach 
ownerName: Orlpar Erwuraheal 
ownerLink: "[[Taverner(Hostelers) - Orlpar Erwuraheal|Orlpar Erwuraheal]]"
ownerRace: Elf
apprentices: 
- Weld (Mature Adult ) Male who is Deceased  
- Landon (Young Adult ) Female who is Healthy  
services: 
- Eatery( Average   quality, Average  costs) 
- Room (Sleeping)( Poor   quality, Below Average  costs) 
- Common Room (Sleeping)( Good   quality, High  costs) 
- Room (Meeting)( Average   quality, Above Average  costs) 
exterior: An two story building with planked siding. The roof is Celing. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Eatery |  Average   quality |  Average  costs | 
> | Room  | Sleeping | ( Poor   quality | 
> | Common Room  | Sleeping | ( Good   quality | 
> | Room  | Meeting | ( Average   quality | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Weld  | Mature Adult  |  Male who is Deceased   | 
>> | Landon  | Young Adult  |  Female who is Healthy   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

