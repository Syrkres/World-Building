---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Mage 
merchantCategory: Sage
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,ALCHEMIST
title: Mage Column 
ownerName: Fhociin Rusiatear 
ownerLink: "[[High Mage(Sage) - Fhociin Rusiatear|Fhociin Rusiatear]]"
ownerRace: Elf
apprentices: 
- Royal (Teen ) Male who is Dying  
services: 
- Sage( Excellent   quality, Above Average  costs) 
- Scroll Crafting( Horrible   quality, Above Average  costs) 
- Potion Crafting( Excellent   quality, Above Average  costs) 
- Spell Research( Horrible   quality, Low  costs) 
exterior: An narrow two story building with new paint and with shingled siding. The roof is Canopy. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Excellent   quality |  Above Average  costs | 
> | Scroll Crafting |  Horrible   quality |  Above Average  costs | 
> | Potion Crafting |  Excellent   quality |  Above Average  costs | 
> | Spell Research |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Royal  | Teen  |  Male who is Dying   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

