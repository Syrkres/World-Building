---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Antiquities 
merchantCategory: Merchant
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,EXOTIC ARTISAN
title: The new The old Table     
ownerName: Shammath Myrthurdrenn 
ownerLink: "[[Antiquities(Merchant) - Shammath Myrthurdrenn|Shammath Myrthurdrenn]]"
ownerRace: Wood Elf
apprentices: 
- Springfield (Young Adult ) Male who is Ailing  
- Upton (Mature Adult ) Male who is Indisposed  
services: 
- Merchant( Average   quality, Low  costs) 
- Item Research( Low   quality, High  costs) 
exterior: An long tall building with planked siding. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Merchant |  Average   quality |  Low  costs | 
> | Item Research |  Low   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Springfield  | Young Adult  |  Male who is Ailing   | 
>> | Upton  | Mature Adult  |  Male who is Indisposed   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

