---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Taverner 
merchantCategory: Hostelers
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: The Grey Belt Buckle 
ownerName: Abadda Zuldrinitryn 
ownerLink: "[[Taverner(Hostelers) - Abadda Zuldrinitryn|Abadda Zuldrinitryn]]"
ownerRace: Elf
apprentices: 
- Huckabee (Young Adult ) Male who is Fit  
- Middleton (Young Adult ) Female who is Not oneself  
services: 
- Eatery( Average   quality, Above Average  costs) 
- Room (Sleeping)( Good   quality, Low  costs) 
- Common Room (Sleeping)( Low   quality, High  costs) 
- Room (Meeting)( Poor   quality, Low  costs) 
exterior: An new one story building with faded paint and with shingled siding with a front boarded window that has a carved sign hanging to the side with the merchants name. The roof is Celing. A Oak shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Eatery |  Average   quality |  Above Average  costs | 
> | Room  | Sleeping | ( Good   quality | 
> | Common Room  | Sleeping | ( Low   quality | 
> | Room  | Meeting | ( Poor   quality | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Huckabee  | Young Adult  |  Male who is Fit   | 
>> | Middleton  | Young Adult  |  Female who is Not oneself   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

