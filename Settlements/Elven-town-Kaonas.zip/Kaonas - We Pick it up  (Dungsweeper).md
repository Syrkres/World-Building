---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Dungsweeper 
merchantCategory: Laborer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: We Pick it up 
ownerName: Voron Phimodolylth 
ownerLink: "[[Dungsweeper(Laborer) - Voron Phimodolylth|Voron Phimodolylth]]"
ownerRace: Elf
apprentices: 
- Oakes (Young Adult ) Male who is Fit as a fiddle  
- Rodney (Young Adult ) Female who is Fine  
services: 
- Laborer( Horrible   quality, Average  costs) 
exterior: An new building with stoned siding with a missing window. The roof is Dome. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Laborer |  Horrible   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Oakes  | Young Adult  |  Male who is Fit as a fiddle   | 
>> | Rodney  | Young Adult  |  Female who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

