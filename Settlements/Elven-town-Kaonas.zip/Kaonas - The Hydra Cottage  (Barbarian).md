---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Barbarian 
merchantCategory: Merc
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,STABLE
title: The Hydra Cottage 
ownerName: Elanalue Berenaltin 
ownerLink: "[[Barbarian(Merc) - Elanalue Berenaltin|Elanalue Berenaltin]]"
ownerRace: Elf
apprentices: 
- Harrington (Young Adult ) Female who is Fine  
services: 
- Mercenary( Poor   quality, Below Average  costs) 
- Tracking( Good   quality, High  costs) 
exterior: An old two story building with shingled siding with a missing round window. The roof is Canopy. A Maple shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Poor   quality |  Below Average  costs | 
> | Tracking |  Good   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Harrington  | Young Adult  |  Female who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

