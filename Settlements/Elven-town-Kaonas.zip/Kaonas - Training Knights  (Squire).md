---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Squire 
merchantCategory: Knight
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: Training Knights 
ownerName: Ruehar Purginwainarnith 
ownerLink: "[[Squire(Knight) - Ruehar Purginwainarnith|Ruehar Purginwainarnith]]"
ownerRace: Wood Elf
apprentices: 
- Copeland (Young Adult ) Male who is All Right  
services: 
- Knight( Excellent   quality, Low  costs) 
- Guarding( Good   quality, Average  costs) 
exterior: An old long one story building with faded paint and with brick siding. The roof is Dome. A pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Knight |  Excellent   quality |  Low  costs | 
> | Guarding |  Good   quality |  Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Copeland  | Young Adult  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

