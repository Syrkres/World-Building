---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Clerk 
merchantCategory: Elected Official
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHRINE,CLERK
title: Clerks Office 
ownerName: Falael Ideashutmitore 
ownerLink: "[[Clerk(Elected Official) - Falael Ideashutmitore|Falael Ideashutmitore]]"
ownerRace: Wood Elf
apprentices: 
- No apprentices
services: 
- Elected Official( Good   quality, Low  costs) 
- Diplomacy( Poor   quality, Average  costs) 
- Note Taking( Excellent   quality, Low  costs) 
exterior: An long building with faded paint and with shingled siding. The roof is Roof. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Elected Official |  Good   quality |  Low  costs | 
> | Diplomacy |  Poor   quality |  Average  costs | 
> | Note Taking |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

