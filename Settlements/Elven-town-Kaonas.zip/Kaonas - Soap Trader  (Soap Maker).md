---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Soap Maker 
merchantCategory: Craftsman
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: Soap Trader 
ownerName: Saevel Auvreatlarn 
ownerLink: "[[Soap Maker(Craftsman) - Saevel Auvreatlarn|Saevel Auvreatlarn]]"
ownerRace: High  Elf
apprentices: 
- Darby (Teen ) Female who is Well  
services: 
- Craftsman( Excellent   quality, High  costs) 
- Soap Maker( Poor   quality, High  costs) 
exterior: An old tall building with faded paint and with planked siding. The roof is House. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Excellent   quality |  High  costs | 
> | Soap Maker |  Poor   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Darby  | Teen  |  Female who is Well   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

