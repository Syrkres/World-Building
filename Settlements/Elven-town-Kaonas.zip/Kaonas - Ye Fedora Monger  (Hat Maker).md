---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Hat Maker 
merchantCategory: Garment Trade
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: Ye Fedora Monger 
ownerName: Fflar Wakirultlarn 
ownerLink: "[[Hat Maker(Garment Trade) - Fflar Wakirultlarn|Fflar Wakirultlarn]]"
ownerRace: Elf
apprentices: 
- Colby (Young Adult ) Male who is Healthy  
- Bradley (Teen ) Male who is All Right  
services: 
- Garment Trade( Average   quality, Low  costs) 
- Hat Maker( Low   quality, Below Average  costs) 
exterior: An narrow building with brick siding with a missing window. The roof is Roof. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Average   quality |  Low  costs | 
> | Hat Maker |  Low   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Colby  | Young Adult  |  Male who is Healthy   | 
>> | Bradley  | Teen  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

