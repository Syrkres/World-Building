---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Jeweler 
merchantCategory: Artisan
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Grove 
structure: SHOP,HOUSE
title: Ye Platinum Ring 
ownerName: Gwynnestri Aleaaltin 
ownerLink: "[[Jeweler(Artisan) - Gwynnestri Aleaaltin|Gwynnestri Aleaaltin]]"
ownerRace: Wood Elf
apprentices: 
- Home (Teen ) Male who is Fine  
- Upton (Young Adult ) Male who is Under the weather  
services: 
- Jewelery Crafting( Good   quality, Below Average  costs) 
- Craft( Poor   quality, High  costs) 
- Gem Cutting( Poor   quality, Below Average  costs) 
exterior: An old long building with shingled siding with a missing window. The roof is Celing. A shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Jewelery Crafting |  Good   quality |  Below Average  costs | 
> | Craft |  Poor   quality |  High  costs | 
> | Gem Cutting |  Poor   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Home  | Teen  |  Male who is Fine   | 
>> | Upton  | Young Adult  |  Male who is Under the weather   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

