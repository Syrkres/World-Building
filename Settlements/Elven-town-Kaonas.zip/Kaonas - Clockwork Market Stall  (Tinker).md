---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Tinker 
merchantCategory: Craftsman
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,HOUSE
title: Clockwork Market Stall 
ownerName: Roanmara Arkeneaurdrenn 
ownerLink: "[[Tinker(Craftsman) - Roanmara Arkeneaurdrenn|Roanmara Arkeneaurdrenn]]"
ownerRace: Elf
apprentices: 
- Allerton (Teen ) Male who is Healthy  
- Weld (Adult ) Female who is All Right  
services: 
- Craftsman( Average   quality, Average  costs) 
- Toy Making( Average   quality, Below Average  costs) 
- Clock Making( Low   quality, Above Average  costs) 
- Tinkerer( Good   quality, Below Average  costs) 
exterior: An long building with new paint and with stoned siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Craftsman |  Average   quality |  Average  costs | 
> | Toy Making |  Average   quality |  Below Average  costs | 
> | Clock Making |  Low   quality |  Above Average  costs | 
> | Tinkerer |  Good   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Allerton  | Teen  |  Male who is Healthy   | 
>> | Weld  | Adult  |  Female who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

