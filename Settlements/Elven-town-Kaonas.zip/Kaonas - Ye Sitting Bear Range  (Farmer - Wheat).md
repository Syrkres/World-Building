---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Farmer - Wheat 
merchantCategory: Farmer
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: FARM,HOUSE
title: Ye Sitting Bear Range 
ownerName: Alavara Maernnddare 
ownerLink: "[[Farmer - Wheat(Farmer) - Alavara Maernnddare|Alavara Maernnddare]]"
ownerRace: Wood Elf
apprentices: 
- Blankley (Young Adult ) Male who is Healthy  
- Wharton (Teen ) Female who is Fit  
services: 
- Farmer( Good   quality, Average  costs) 
- Food( Excellent   quality, Below Average  costs) 
exterior: An old narrow two story building with brick siding. The roof is Roof. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Farmer |  Good   quality |  Average  costs | 
> | Food |  Excellent   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Blankley  | Young Adult  |  Male who is Healthy   | 
>> | Wharton  | Teen  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

