---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: High Mage 
merchantCategory: Sage
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Temple Square 
structure: SHOP,ALCHEMIST
title: Mage Obelisk 
ownerName: Sariandi Krulsalwuanea 
ownerLink: "[[High Mage(Sage) - Sariandi Krulsalwuanea|Sariandi Krulsalwuanea]]"
ownerRace: Elf
apprentices: 
- Charlton (Teen ) Male who is Hurt  
services: 
- Sage( Average   quality, High  costs) 
- Scroll Crafting( Poor   quality, Above Average  costs) 
- Potion Crafting( Horrible   quality, Average  costs) 
- Spell Research( Average   quality, Below Average  costs) 
exterior: An one story building with faded paint and with stoned siding. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Sage |  Average   quality |  High  costs | 
> | Scroll Crafting |  Poor   quality |  Above Average  costs | 
> | Potion Crafting |  Horrible   quality |  Average  costs | 
> | Spell Research |  Average   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Charlton  | Teen  |  Male who is Hurt   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

