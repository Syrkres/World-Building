---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Noble 
merchantCategory: Noble
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Grove 
structure: SHOP,HOUSE
title: Mylaela's Hall 
ownerName: Mylaela Purginwaintlithar 
ownerLink: "[[Noble(Noble) - Mylaela Purginwaintlithar|Mylaela Purginwaintlithar]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Noble( Low   quality, Below Average  costs) 
- Diplomacy( Horrible   quality, Above Average  costs) 
exterior: An narrow tall building with new paint and with brick siding with a missing window. The roof is Celing. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Noble |  Low   quality |  Below Average  costs | 
> | Diplomacy |  Horrible   quality |  Above Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

