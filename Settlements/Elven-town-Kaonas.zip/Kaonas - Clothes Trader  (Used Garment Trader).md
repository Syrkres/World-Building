---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Used Garment Trader 
merchantCategory: Garment Trade
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Central Quarter 
structure: SHOP,HOUSE
title: Clothes Trader 
ownerName: Pyrravym Hubugonettln 
ownerLink: "[[Used Garment Trader(Garment Trade) - Pyrravym Hubugonettln|Pyrravym Hubugonettln]]"
ownerRace: High  Elf
apprentices: 
- No apprentices
services: 
- Garment Trade( Good   quality, Average  costs) 
- Trader( Average   quality, Below Average  costs) 
exterior: An old one story building with brick siding with a few short windows. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Garment Trade |  Good   quality |  Average  costs | 
> | Trader |  Average   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

