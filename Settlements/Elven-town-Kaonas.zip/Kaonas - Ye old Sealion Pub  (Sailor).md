---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Sailor 
merchantCategory: Merc
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: Ye old Sealion Pub 
ownerName: Syviis Wakirulrae 
ownerLink: "[[Sailor(Merc) - Syviis Wakirulrae|Syviis Wakirulrae]]"
ownerRace: Elf
apprentices: 
- No apprentices
services: 
- Mercenary( Horrible   quality, Low  costs) 
- Sailor( Average   quality, High  costs) 
- Thug( Horrible   quality, Below Average  costs) 
exterior: An building with shingled siding with a few tall windows. The roof is House. A Cherry pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Horrible   quality |  Low  costs | 
> | Sailor |  Average   quality |  High  costs | 
> | Thug |  Horrible   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | No apprentices |  |  | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

