---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Pirate 
merchantCategory: Merc
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: Ye Rusted Cutlass 
ownerName: Laeroth Wolgoannia 
ownerLink: "[[Pirate(Merc) - Laeroth Wolgoannia|Laeroth Wolgoannia]]"
ownerRace: Elf
apprentices: 
- Stansfield (Teen ) Male who is Fit  
- Landon (Young Adult ) Female who is Hurt  
services: 
- Mercenary( Poor   quality, Low  costs) 
- Intimidation( Good   quality, High  costs) 
- Shipping( Good   quality, Average  costs) 
- Guarding( Low   quality, Below Average  costs) 
exterior: An building with brick siding with a missing tall window. The roof is Roof. A Maple shed structure is to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Poor   quality |  Low  costs | 
> | Intimidation |  Good   quality |  High  costs | 
> | Shipping |  Good   quality |  Average  costs | 
> | Guarding |  Low   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Stansfield  | Teen  |  Male who is Fit   | 
>> | Landon  | Young Adult  |  Female who is Hurt   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

