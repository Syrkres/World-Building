---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Spicer Maker 
merchantCategory: Cook
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: The Belladonna Nectar 
ownerName: Cystenn Crultaneplith 
ownerLink: "[[Spicer Maker(Cook) - Cystenn Crultaneplith|Cystenn Crultaneplith]]"
ownerRace: Elf
apprentices: 
- Browning (Adult ) Male who is Fit  
- Yardley (Teen ) Female who is Fit  
services: 
- Tradesmen( Poor   quality, Above Average  costs) 
- Spicer Maker( Average   quality, Below Average  costs) 
exterior: An new building with brick siding with a missing window. The roof is Celing. A shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Tradesmen |  Poor   quality |  Above Average  costs | 
> | Spicer Maker |  Average   quality |  Below Average  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Browning  | Adult  |  Male who is Fit   | 
>> | Yardley  | Teen  |  Female who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

