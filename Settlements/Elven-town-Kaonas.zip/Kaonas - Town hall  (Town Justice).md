---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Town Justice 
merchantCategory: Elected Official
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: SHOP,HOUSE
title: Town hall 
ownerName: Vhoori Killeettln 
ownerLink: "[[Town Justice(Elected Official) - Vhoori Killeettln|Vhoori Killeettln]]"
ownerRace: Wood Elf
apprentices: 
- Wade (Teen ) Female who is Fine  
- Marston (Teen ) Female who is Sick  
services: 
- Elected Official( Poor   quality, High  costs) 
- Town Justice( Excellent   quality, High  costs) 
exterior: An narrow building with new paint and with stoned siding with a few tall shuttered windows. The roof is Roof. A Pine shed is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Elected Official |  Poor   quality |  High  costs | 
> | Town Justice |  Excellent   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Wade  | Teen  |  Female who is Fine   | 
>> | Marston  | Teen  |  Female who is Sick   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

