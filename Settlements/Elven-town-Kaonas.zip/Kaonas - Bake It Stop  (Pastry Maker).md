---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Pastry Maker 
merchantCategory: Cook
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Downtown Corner 
structure: SHOP,HOUSE
title: Bake It Stop 
ownerName: Yesheln� Migaleplith 
ownerLink: "[[Pastry Maker(Cook) - Yesheln� Migaleplith|Yesheln� Migaleplith]]"
ownerRace: High  Elf
apprentices: 
- Presley (Adult ) Male who is Out of sorts  
- Yeardley (Teen ) Male who is Fit  
services: 
- Cook( Poor   quality, Low  costs) 
- Pastry Maker( Average   quality, High  costs) 
exterior: An building with stoned siding. The roof is House. A Beech pergola is attached to the side. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Cook |  Poor   quality |  Low  costs | 
> | Pastry Maker |  Average   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Presley  | Adult  |  Male who is Out of sorts   | 
>> | Yeardley  | Teen  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

