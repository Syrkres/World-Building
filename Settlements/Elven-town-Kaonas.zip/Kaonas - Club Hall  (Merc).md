---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Merc 
merchantCategory: Merc
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Upper Quarter 
structure: JAIL,HOUSE
title: Club Hall 
ownerName: Mothrys Orlealtin 
ownerLink: "[[Merc(Merc) - Mothrys Orlealtin|Mothrys Orlealtin]]"
ownerRace: Wood Elf
apprentices: 
- Langdon (Adult ) Female who is Expired  
- Wheatley (Teen ) Male who is Fit  
services: 
- Mercenary( Excellent   quality, Average  costs) 
- Intimidation( Poor   quality, High  costs) 
- Guarding( Horrible   quality, Low  costs) 
exterior: An new long building with faded paint and with stoned siding with a few windows. The roof is House. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Mercenary |  Excellent   quality |  Average  costs | 
> | Intimidation |  Poor   quality |  High  costs | 
> | Guarding |  Horrible   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Langdon  | Adult  |  Female who is Expired   | 
>> | Wheatley  | Teen  |  Male who is Fit   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

