---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Missionary 
merchantCategory: Clergy
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: 
structure: SHRINE,HOUSE
title: The Missionary 
ownerName: Sontar Vitariaear 
ownerLink: "[[Missionary(Clergy) - Sontar Vitariaear|Sontar Vitariaear]]"
ownerRace: Wood Elf
apprentices: 
- Elton (Teen ) Male who is Healthy  
- Prescott (Young Adult ) Male who is All Right  
services: 
- Clergy( Poor   quality, Average  costs) 
- Religion( Horrible   quality, Above Average  costs) 
- Remedies( Excellent   quality, High  costs) 
exterior: An old narrow tall building with brick siding. The roof is Roof. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Clergy |  Poor   quality |  Average  costs | 
> | Religion |  Horrible   quality |  Above Average  costs | 
> | Remedies |  Excellent   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Elton  | Teen  |  Male who is Healthy   | 
>> | Prescott  | Young Adult  |  Male who is All Right   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

