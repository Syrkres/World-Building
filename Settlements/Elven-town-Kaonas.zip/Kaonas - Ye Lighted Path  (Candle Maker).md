---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Candle Maker 
merchantCategory: Specialty Service
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: Merchants Market 
structure: SHOP,HOUSE
title: Ye Lighted Path 
ownerName: Myrin Wikrimundlin 
ownerLink: "[[Candle Maker(Specialty Service) - Myrin Wikrimundlin|Myrin Wikrimundlin]]"
ownerRace: Wood Elf
apprentices: 
- Langley (Mature Adult ) Male who is All Right  
- Deighton (Teen ) Female who is Expired  
services: 
- Specialty Service( Low   quality, Above Average  costs) 
- Candle Making( Horrible   quality, High  costs) 
exterior: An old long two story building with shingled siding with a front short broken window that has a sign hanging above with the merchants name. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Specialty Service |  Low   quality |  Above Average  costs | 
> | Candle Making |  Horrible   quality |  High  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Langley  | Mature Adult  |  Male who is All Right   | 
>> | Deighton  | Teen  |  Female who is Expired   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

