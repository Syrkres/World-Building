---
cssclass: oRPGPage
fileType: structure
structureType: Profession
merchantType: Goldsmith 
merchantCategory: Artisan
kingdom: Mythiune
region: Northlands
settlementName: Kaonas
wardName: 
structure: SHOP,HOUSE
title: The Dark Grey Shop 
ownerName: Dathlue Zuldrinzea 
ownerLink: "[[Goldsmith(Artisan) - Dathlue Zuldrinzea|Dathlue Zuldrinzea]]"
ownerRace: Wood Elf
apprentices: 
- Weston (Young Adult ) Female who is Fit  
- Darlington (Young Adult ) Female who is Fine  
services: 
- Jewelery Crafting( Poor   quality, Above Average  costs) 
- Gold Crafting( Good   quality, Above Average  costs) 
- Gem Cutting( Excellent   quality, Low  costs) 
exterior: An new building with faded paint and with stoned siding. The roof is Canopy. 
---


> [!infobox] 
> # `=this.merchantType` (`=this.merchantCategory`)
> **Structure:** `=this.structure`
> **Resides In** `=link(this.kingdom)`, `=link(this.settlementName) `
>  **Owner:** `=this.ownerLink`
> ###### Services 
> |Name | Quality | Price |
> |:---|:---:|:---:| 
> | Jewelery Crafting |  Poor   quality |  Above Average  costs | 
> | Gold Crafting |  Good   quality |  Above Average  costs | 
> | Gem Cutting |  Excellent   quality |  Low  costs | 
 

# `=this.title`
> [!info|bg-c-purple] Exterior
 `=this.exterior`

> [!column|dataview] Staff
>> [!metadata|text-Center bg-c-yellow]- Apprentices
>>
>> |Name | Age | Notes |
>> |:---|:---:|:---:| 
>> | Weston  | Young Adult  |  Female who is Fit   | 
>> | Darlington  | Young Adult  |  Female who is Fine   | 

>
>

## Inventory



## DM Notes

### Hidden Details

### Notes 

