---
cssclass: oRPGPage
fileType: ward
wardType: Neighborhood 
kingdom: 
region: 
settlementName: Not Assigned
wardName: North Central Garden 
wardDescription: 
population: 
culture: African 
technology: Roman 
representative: 
defenses: Wood Walls 
---



> [!infobox]
> # `=this.wardType `
> ![[emptyGrid.jpg]]
> ###### Info
>  |
> ---|---|
> **Alias:** | `=this.alias` |
> **Settlement:** | `=link(this.settlementName )` |
> **Type:** | `=this.wardType ` |
> **Population:** | `=this.population` |
> **Culture:** | `=this.culture` | 
> ###### Politics
>  |
> ---|---|
> **Representative:** | `=this.leader` |
> **Govt Type:** | `=this.govermentType` |
> **Defenses:** | `=this.defenses` |
> ###### Organizations/Groups
> [[Group Database|Add New Group]]
> ```dataview 
table join(Type, ", ") AS Type
WHERE econtains(Location, this.file.name) AND contains(NoteIcon, "Group")
SORT Type ASC

# **`=this.wardName`**
> [!info|bg-c-purple] Overview
`=this.wardDescription`


## Notable Locations

> ###### Notable Shops/Services
> [[Shop & Service Database|Add New Shop/Service]]
> ```dataview
table  without ID  "[[" + file.name + "|" + title + "]]" as Name, merchantCategory as Type
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and wardName = this.wardName and fileType = "structure" 
SORT file.name ASC

> ###### Notable Points of Interest
> [[POI Database|Add New Point of Interest]]
> ```dataview
table join(Type, ", ") AS Type, join(link(AffiliatedGroup), ", ") AS "Affiliated Group(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and fileType = "POI" and wardName = this.wardName
SORT file.name ASC

## Notable Characters

> ###### Notable Characters
> [[NPC Database|Add New NPC]]
> ```dataview
table Art, Party1Standing AS "Party 1 Standing", join(Occupation, ", ") AS "Occupation(s)", join(link(AssociatedGroup), ", ") AS "Associated Group(s)", join(link(AssociatedReligion), ", ") AS "Associated Religion(s)"
WHERE kingdom = this.kingdom and settlementName = this.settlementName  and urbanArea = this.urbanArea and fileType="npc"
SORT file.name ASC

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes



