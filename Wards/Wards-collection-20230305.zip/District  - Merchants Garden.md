---
cssclass: oRPGPage
fileType: ward
wardType: District 
kingdom: 
region: 
settlementName: Not Assigned
wardName: Merchants Garden 
wardDescription: 
population: 
culture: Roman 
technology: Roman 
representative: 
defenses: Archer towers 
---
