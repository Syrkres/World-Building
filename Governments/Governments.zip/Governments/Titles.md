
|Level|Fighting-Man|Magic-User|Cleric|Thief|
|--- |--- |--- |--- |--- |
|1|Veteran|Medium|Acolyte|Apprentice|
|2|Warrior|Seer|Adept|Footpad|
|3|Swordsman|Conjurer|Village Priest|Robber|
|4|Hero|Theurgist|Vicar|Burglar|
|5|Swashbuckler|Magician|Curate|Cutpurse|
|6|Myrmidon|Enchanter|Bishop|Sharper|
|7|Champion|Warlock|Lama|Pilferer|
|8|Superhero|Sorcerer|Patriarch|Master Pilferer|
|9|Lord|Necromancer|Patriarch, 9th|Thief|
|10|Lord, 10th|Wizard|Patriarch, 10th|Master Thief|

|Level|Druid|Monk|Assassin|
|--- |--- |--- |--- |
|1|Aspirant|Novice|Apprentice|
|2|Initiate of the 1st Circle|Initiate|Killer|
|3|Initiate of the 2nd Circle|Disciple|Murderer|
|4|Initiate of the 3rd Circle|Immaculate|Slayer|
|5|Initiate of the 4th Circle|Master|Cutthroat|
|6|Initiate of the 5th Circle|Grand Master|Dacoit|
|7|Initiate of the 6th Circle|Grand Master of Dragons|Thug|
|8|Initiate of the 7th Circle|Grand Master of North Winds|Executioner|
|9|Initiate of the 8th Circle|Grand Master of West Winds|Assassin|
|10|Initiate of the 9th Circle|Grand Master of South Winds|Senior Assassin|
|11|Druid|Grand Master of East Winds|Expert Assassin|
|12|Archdruid|Grand Master of Winter|Chief Assassin|
|13|The Grand Druid|Grand Master of Autumn|Prime Assassin|
|14||Grand Master of Summer|Guildmaster of Assassins|
|15||Grand Master of Spring||
|16||Grand Master of Flowers||


|Level|Fighter|Magic-User|Cleric|Thief|
|--- |--- |--- |--- |--- |
|1|Veteran|Medium (or Prestidigitator)|Acolyte|Apprentice|
|2|Warrior|Seer (or Evoker)|Adept|Footpad|
|3|Swordmaster|Conjurer|Priest|Robber|
|4|Hero (or Crusader)|Theurgist (or Thaumaturgist)|Vicar|Burglar|
|5|Swashbuckler|Magician|Curate|Cutpurse|
|6|Myrmidon|Enchanter/Enchantress|Bishop|Sharper|
|7|Champion|Warlock|Lama|Pilferer|
|8|Superhero (or Sentinel)|Sorcerer/Sorceress|Patriarch/Matriarch|Master Pilferer|
|9|Lord|Necromancer|High Priest|Thief (or Rogue)|
|10|Lord, 10th|Wizard/Archmaguse|High Priest, 10th|Master Thief|

|Level|Paladin|Ranger|Illusionist|Bard|
|--- |--- |--- |--- |--- |
|1|Gallant|Runner|Prestidigitator|Ryymer|
|2|Keeper|Strider|Minor Trickster|Lyrist|
|3|Protector|Scout|Trickster|Sonnateer|
|4|Defender|Courser|Master Trickster|Skald|
|5|Warder|Tracker|Cabalist|Racaraide|
|6|Guardian|Guide|Visionist|Joungleur|
|7|Chevalier|Pathfinder|Phantasmist|Troubador|
|8|Justiciar|Ranger|Apparitionist|Minstrel|
|9|Paladin|Ranger Knight|Spellbinder|Muse|
|10|Paladin, 10th|Ranger Lord|Illusionist|Lorist|
|11||Ranger Lord, 11th|Illusionist, 11th|Bard|
|12||||Master Bard|
|13||||Master Bard, 13th|

|Level|Druid|Monk|Assassin*|
|--- |--- |--- |--- |
|1|Aspirant|Novice|Bravo|
|2|Ovate|Initiate|Rutterkin|
|3|Initiate of the 1st Circle|Brother|Waghalter|
|4|Initiate of the 2nd Circle|Immaculate|Murderer|
|5|Initiate of the 3rd Circle|Disciple|Thug|
|6|Initiate of the 4th Circle|Master|Killer|
|7|Initiate of the 5th Circle|Superior  Master|Cutthroat|
|8|Initiate of the 6th Circle|Grand Master of Dragons|Executioner|
|9|Initiate of the 7th Circle|Grand Master of North Winds|Assassin|
|10|Initiate of the 8th Circle|Grand Master of West Winds|Expert Assassin|
|11|Initiate of the 9th Circle|Grand Master of South Winds|Senior Assassin|
|12|Druid|Grand Master of East Winds|Chief Assassin|
|13|Archdruid|Grand Master of Winter|Prime Assassin|
|14|The Grand Druid|Grand Master of Autumn|Guildmaster Assassin|
|15||Grand Master of Summer|Grandfather of Assassins|
|16||Grand Master of Spring||
|17||Grand Master of Flowers||

|Level|Druid (Hierophant)|Cavalier|Thief-Acrobat|
|--- |--- |--- |--- |
|1|(as Druid)|Armiger|(as Thief)|
|2|' '|Scutifer|' '|
|3|' '|Esquire|' '|
|4|' '|Knight Errant|' '|
|5|' '|Knight Bachelor|' '|
|6|' '|Knight|Burglar-Acrobat|
|7|' '|Knight Grand|Second-Story Thief|
|8|' '|Knight Banneret|Cat Burglar|
|9|' '|Chevalier|Master Cat Burglar|
|10|' '|Cavalier|Thief-Acrobat|
|11|' '|Cavalier 11th|Master Thief-Acrobat|
|11|' '||Master Thief-Acrobat, 12th|
|12|' '|||
|13|' '|||
|14|' '|||
|15|The Grand Druid|||
|16|Hierophant Druid|||
|17|Hierophant Initiate|||
|18|Hierophant Adept|||
|19|Hierophant Master|||
|20|Numinous Hierophant|||
|21|Mystic Hierophant|||
|22|Arcane Hierophant|||
|23|Hierophant of the Cabal|||


|Title|Origin|Function|Usual Source of Authority|Usual Breadth of Authority|
|--- |--- |--- |--- |--- |
|Abbess or Abbot|Latin|Executive|Elected|Institutional (abbey)|
|Admiral of the Fleet|European|Executive|Appointed|Divisional (highest naval rank)|
|Agha|Kurdish, Turkish, Persian|Administrative|Identified or Appointed (Debatable)|Tribal|
|Aesymnetes|Greek|Executive|Elected|National|
|Agonothetes|Greek|Administrative|Elected|Institutional (sacred games)|
|Agoranomos|Greek|Executive|Elected|Institutional (marketplace)|
|Air Marshal|British|Administrative|Appointed|Divisional (very senior air force rank)|
|Aircraftman|British|Administrative|Appointed|Divisional (lowest air force rank)|
|Akhoond|Persian|Ceremonial|Appointed/ identified?|Institutional (mosque)|
|Alderman|Old English|Administrative/executive|Elected|An elected member of a city council|
|Allamah|Arabic|Ceremonial|Identified|Personal|
|Amban|Manchu|Executive/ legislative|Appointed|Provincial/ supranational|
|Amir al-Mu'minin|Arabic|Executive|Hereditary/ identified|National/ supranational/ tribal|
|Amphipole|Greek|Executive/ judicial|Elected?|National|
|Anax|Greek|Executive|Hereditary|Supranational|
|Apodektai|Greek|Administrative|Appointed|Tribal|
|Apostle|Greek|Ceremonial|Appointed/ Identified|Personal/ supernatural|
|Arahant|Pali|Ceremonial|Identified|Personal/ supernatural|
|Archbishop|Greek|Executive/ judicial|Appointed|Provincial (diocesan)|
|Archdeacon|Christian|Administrative|Appointed|Institutional (local church)|
|Archduchess or Archduke|German|Ceremonial/ executive|Hereditary|Courtly/ supranational|
|Archiater|Greek|Administrative/ executive|Appointed|Institutional (court (royal))|
|Archimandrite|Greek|Ceremonial/ executive|Appointed|Institutional (abbey)|
|Archon|Greek|Executive/ judicial|Elected|Local/ national|
|Archpriest|Christian|Administrative|Appointed|Provincial|
|Argbadh|Persian|Executive|Appointed|Institutional (castle)|
|Arhat|Sanskrit|Ceremonial|Identified|Personal/ supernatural|
|Asapatish|Persian|Executive|Appointed|Divisional (cavalry unit)|
|Aspet|Armenian|Executive|Hereditary|Courtly|
|Assistant in Virtue|Tang dynasty|Ceremonial|Appointed|Courtly|
|Assistant Professor|American|Administrative|Appointed|Institutional (university)|
|Assistant to the President & Deputy National Security Advisor|American|Executive|Appointed|National|
|Associate Professor|American|Administrative|Appointed|Institutional (university)|
|Aswaran Salar|Sasanian Empire|Executive|Appointed|Divisional (entire cavalry)|
|Augusta|Greek|Ceremonial|Appointed|Courtly|
|Ayatollah|Persian|Judicial|Appointed (based on studies at a hawza)|Personal|
|Baivarapatish|Persian|Executive|Appointed|Divisional (baivarabam of 10,000 soldiers)|
|Bapu|Hindi|Ceremonial|Identified|Courtly/ personal|
|Baron or Baroness|French|Executive|Hereditary|Local|
|Basileus or Basilissa|Greek|Executive/ ceremonial/ judicial|Hereditary/ elected|National|
|Beauty|Tang dynasty|Ceremonial|Appointed|Courtly|
|Bishop|Christian|Executive|Appointed|Provincial (diocesan)|
|Blessed|Latin|Ceremonial|Appointed|Supernatural|
|Begum|Turkish|Ceremonial|Appointed|Courtly/ personal|
|Buddha|Pali/ Sanskrit|Ceremonial|Identified|Personal/ supernatural|
|Cardinal|Christian|Administrative|Appointed|Institutional (College of Cardinals)|
|Cardinal-nephew|Latin|Administrative|Appointed|Institutional (College of Cardinals)|
|Caesar|Latin|Ceremonial|Appointed|Courtly|
|Caliph|Arabic|Executive|Elected/ hereditary|Supranational|
|Captain (land)|European|Executive|Appointed|Divisional (75- 200 soldiers)|
|Captain (naval)|English|Executive|Appointed|Divisional (large ship)|
|Catholicos|Greek|Executive|Appointed|Regional|
|Centurion|Latin|Executive|Appointed|Divisional (80 or more soldiers)|
|Chairman or Chairwoman|English|Administrative/ executive/ legislative|Appointed/ elected|Institutional (Meeting)|
|Chakravartin|Sanskrit|Executive|Identified/ hereditary|Supranational|
|Chancellor|Latin|Administrative|Appointed|Courtly|
|Chanyu|Xiongnu|Executive|Hereditary|Tribal|
|Chhatrapati|Marathi|Executive|Hereditary|National/ supranational|
|Chief or Chieftain|Global|Executive/ judicial/ legislative|Elected/ hereditary|Tribal|
|Chiliarch|Greek|Executive|Appointed|Divisional (1,000 soldiers)|
|Chorbishop|Greek|Executive|Appointed|Provincial (diocesan)|
|Choregos|Greek|Administrative/ ceremonial|Purchased|Institutional (theatre festival)|
|City Manager|English|Executive|Appointed|Local|
|Coiffure Attendant|Tang dynasty|Ceremonial|Appointed|Courtly|
|Colonel|English|Honorific|Appointed/Identified|Local|
|Comes|Latin|Ceremonial|Appointed/ identified|Courtly/ supernatural|
|Commissioner|English|Executive/Legislative|Elected/Appointed|Local|
|Commissioner of Baseball|Amero-Canadian|Executive|Elected|Institutional (Major League Baseball)|
|Concubinus|Roman|Ceremonial|Appointed|Personal|
|Consort|Tang dynasty|Ceremonial|Appointed|Courtly|
|Consul|Roman|Executive/ judicial|Elected|National|
|Corporal|Italian|Executive|Appointed|Divisional (2nd in command of a squad of 8 to 14 soldiers)|
|Corrector|Latin|Executive/ judicial|Appointed|Regional|
|Councillor|Latin|Legislative|Elected|Local|
|Count or Countess|Latin|Executive|Hereditary|Provincial|
|Dàifu (Great Man)|Chinese|Ceremonial|Identified|Personal|
|Dalai Lama|Tibetan|Ceremonial|Appointed|Supranational|
|Dame or Dom|Latin|Ceremonial|Appointed/ identified|Institutional (British knighthood, English Benedictine Congregation)|
|Dathapatish|Persian|Executive|Appointed|Divisional (dathabam of 10 soldiers)|
|Deacon or Diakonissa|Greek|Administrative|Appointed|Institutional (local church)|
|Dean (religion)|Christian|Administrative|Appointed|Institutional (local church)|
|Decurio|Roman|Executive|Appointed|Divisional (command of a contubernium of 8 soldiers)|
|Desai|Indo-Aryan|Administrative|Appointed/ hereditary|Provincial|
|Despot|Greek|Ceremonial|Appointed|Courtly|
|Dilochitès|Greek|Executive|Appointed|Divisional (dilochia army double file)|
|Dikastes|Greek|Judicial|Chosen by lot|Tribal|
|Dimoirites|Greek|Executive|Appointed|Divisional (dimoiria army half file)|
|Distinguished Professor|American|Administrative|Appointed|Institutional (university)|
|Divine Adoratrice|Egyptian|Executive/ ceremonial|Hereditary|National|
|Diwan|Persian|Executive|Appointed/ hereditary|National/ provincial|
|Doctor|European|Administrative|Appointed|Institutional (university)|
|Don or Doña|Spanish|Ceremonial/ executive|Identified|Local/ national|
|Duchess or Duke|Latin|Executive|Hereditary|National/ Regional|
|Dux|Latin|Executive|Appointed|Divisional (two legions- 9,000 soldiers or more)|
|Earl or Countess|Anglo-Saxon|Executive|Hereditary|Provincial|
|Earl Marshal|English|Administrative/ judicial|Hereditary|Courtly/ national|
|Ecumenical Patriarch|Greek|Ceremonial/ judicial|Elected?|Supranational|
|Elder|Anglo-Saxon, Arabic, Australian, Germanic, Greek, Latin, Mayan, Slavic|Legislative|Elected/ identified|Tribal|
|Emperor or Empress|Latin|Executive|Hereditary|Supranational|
|En|Sumerian|Ceremonial/ executive|Hereditary?|Local/ national|
|Ephor|Greek|Executive|Elected|National|
|Epihipparch|Greek|Executive|Appointed|Divisional (1,000 horses)|
|Esquire or Squire|French|Administrative/ executive/ judicial/ legislative|Appointed/ hereditary|Local/ personal|
|Evangelist|Christian|Administrative|Appointed|Institutional (Latter Day Saint movement)|
|Exarch|Greek|Executive|Appointed|Provincial|
|Fan-bearer on the Right Side of the King|Egyptian|Ceremonial|Appointed|Courtly|
|Faqih|Arabic|Judicial|Appointed|Institutional (Sharia)|
|Fellow|English|Administrative|Appointed|Institutional (university)|
|Fidalgo|Portuguese|Executive|Hereditary|Provincial|
|Fidei defensor|Latin|Ceremonial|Appointed/ hereditary|National|
|Field Marshal|German|Executive|Appointed|Divisional (highest army rank)|
|Foreign minister|European|Administrative|Appointed|Diplomatic|
|Furén (High-Ranking Madam)|Chinese|Ceremonial|Identified|Personal|
|Fürst or Fürstin|German|Executive|Hereditary|Provincial|
|Ganden Tripa|Tibetan|Ceremonial|Appointed|Institutional (Gelug sect)|
|Generalissimo|Italian|Executive|Elected (by fellow military commanders)|National|
|God's Wife|Egyptian|Ceremonial|Appointed|Institutional (cult of Amun)|
|Gong or Gong Bao (Lord)|Chinese|Ceremonial/ executive|Appointed/ identified|Provincial/ supernatural|
|Goodman or Goodwife|British|Ceremonial|Identified|Personal|
|Gothi or Gyoja|Old Norse|Ceremonial/ executive|Elected?|Tribal|
|Governor|Roman|Executive|Appointed/ elected|Provincial|
|Governor-General|European|Executive|Appointed|National/ regional|
|Grand Admiral|French|Executive|Appointed|Divisional (highest naval rank)|
|Grand duchess or Grand duke|Germanic|Executive|Hereditary|National|
|Grand Inquisitor|Latin|Judicial|Appointed|National/ supranational|
|Grand Master|European|Ceremonial/ executive|Identified|Institutional (Freemasonry, Knights Hospitaller, Knights Templar, Teutonic Knights)/ supranational|
|Grand prince|Latin|Executive|Hereditary|National|
|Guardian Immortal|Tang dynasty|Ceremonial|Appointed|Courtly|
|Hadrat|Arabic|Ceremonial|Identified|Personal|
|Handsome Fairness|Tang dynasty|Ceremonial|Appointed|Courtly|
|Haty-a|Egyptian|Executive|Appointed?|Local|
|Hazarapatish|Persian|Executive|Appointed|Divisional (hazarabam of 1,000 soldiers)|
|Headman|Zuni & !Kung people amongst others|Ceremonial|Identified|Personal|
|Hegumen or Hegumenia|Greek|Executive|Appointed|Institutional (abbey)|
|Hekatontarchès|Greek|Executive|Appointed|Divisional (100 soldiers)|
|Hellenotamiae|Greek|Administrative|Elected?|Tribal|
|Herald|European|Administrative/ diplomatic|Appointed|Institutional/ national|
|Her/His/Your Excellency|English|Ceremonial/ executive|Appointed/ elected/ hereditary|Diplomatic/ national|
|Her/ His/ Your Grace|British|Executive/ legislative|Hereditary|Regional|
|Her/ His/ Your Highness|European|Ceremonial|Hereditary|Courtly|
|Her/ His/ Your Illustrious Highness|European|Ceremonial|Hereditary|Provincial|
|Her/ His/ Your Imperial Highness|European|Ceremonial|Hereditary|Courtly|
|Her/His/Your Imperial Majesty|European|Executive|Hereditary|Supranational|
|Her/Your Ladyship or His/Your Lordship|British|Executive/ legislative|Hereditary|Provincial|
|Her/ His/ Your Majesty|European|Executive|Hereditary|National|
|Her/ His/ Your Royal Highness|European|Ceremonial|Hereditary|Courtly|
|Her/ His/ Your Serene Highness|European|Executive|Hereditary|National|
|Herzog|German|Executive|Hereditary|Regional|
|Hidalgo|Spanish|Executive/ legislative|Appointed/ hereditary|Provincial|
|Hierodeacon|Greek|Administrative|Appointed|Institutional (local church)|
|Hieromonk|Greek|Administrative|Appointed|Institutional (monastery)|
|Hierophant|Greek|Ceremonial|Appointed?|Institutional (Eleusinian Mysteries)|
|High priest or High priestess|Christian, Jewish, Pagan, Samaritan, Santería, Shinto|Ceremonial|Appointed|Institutional (temple)|
|Hipparchus (cavalry officer)|Greek|Executive|Appointed|Divisional (hipparchia of 500 horsemen)|
|His Eminence|Christian|Executive/ administrative|Appointed/ elected|National/ supranational|
|Hojatoleslam|Arabic|Ceremonial|Appointed|Personal|
|Ilarchès|Greek|Executive|Appointed|Divisional (wing cavalry unit)|
|Imam|Arabic|Ceremonial|Identified|Institutional (mosque)/ supernatural|
|Imperator or Imperatrice|Latin|Executive|Identified|Divisional (legion of about 4,500 soldiers)|
|Inquisitor|Latin|Judicial|Appointed|Supranational|
|Jagirdar|Indian|Executive|Appointed|Provincial|
|Jiàoshòu (Instructor)|Chinese|Administrative|Identified|Institutional (university)|
|Junior Technician|British|Administrative|Appointed|Divisional (non-supervisory)|
|Kanstresios|Greek|Administrative|Appointed|Institutional (office of the Ecumenical Patriarch of Constantinople)|
|Karo|Japanese|Administrative|Appointed|Institutional (Castle)|
|Khan or Cham|Central Asian|Executive|Hereditary|National/Supranational|
|Khawaja|Arabic|Ceremonial|Hereditary/ identified|Tribal|
|King or Queen|English|Executive|Hereditary|National|
|King of Arms|European|Ceremonial|Appointed|National|
|Kolakretai|Greek|Administrative|Appointed|Local|
|Kumar or Kumari|Sanskrit|Ceremonial|Appointed/ hereditary|National/ provincial|
|Lady or Lord|British|Executive|Hereditary/ identified/ purchased|Institutional (Manor, Peerage of the United Kingdom)/ Provincial/ Supernatural|
|Lady of His Majesty|Tang dynasty|Ceremonial|Appointed|Courtly|
|Lady of Treasure|Tang dynasty|Ceremonial|Appointed|Courtly|
|Laoshi (Old Master)|Chinese|Executive/ judicial/ legislative|Identified|Personal|
|Lecturer|British|Administrative|Appointed|Institutional (university)|
|Legatus|Roman|Executive|Appointed|Divisional (top rank)|
|Leading Aircraftman or Leading Aircraftwoman|British|Administrative|Appointed|Divisional (non-supervisory)|
|Lochagos|Greek|Executive|Appointed|Divisional (75 to 200 soldiers)|
|Lonko|Mapudungun|Executive|Hereditary?|Tribal|
|Lord Great Chamberlain|English|Ceremonial|Hereditary|Courtly|
|Lord High Constable|English|Ceremonial/ executive/ judicial|Hereditary|Courtly|
|Lord Privy Seal|English|Administrative|Appointed|National|
|Lugal|Sumerian|Executive|Hereditary|Local/ national|
|Madam or Sir|French|Ceremonial/ executive|Appointed/ identified|Divisional (knight)/ personal|
|Magister Officiorum|Latin|Administrative|Appointed|Institutional (palatine secretariat)|
|Magister Militum|Latin|Executive|Appointed|Divisional (top level)|
|Maha-kshtrapa|Sanskrit|Executive|Appointed/ hereditary|Regional|
|Maharaja or Maharani|Sanskrit|Executive|Hereditary|National/ regional|
|Maharana|Hindi|Executive|Hereditary|National/ regional|
|Maharao|Hindi|Executive|Hereditary|National/ regional|
|Mahatma|Sanskrit|Ceremonial|Identified|Personal|
|Major archbishop|Christian|Executive|Appointed|Provincial (diocesan)|
|Malik or Malikah|Arabic|Executive/ legislative/ judicial|Hereditary|Local/ national/ supernatural/ tribal|
|Mandarin|Chinese|Administrative|Appointed (based on Imperial examination)|National|
|Marzban|Persian|Executive|Appointed|Provincial|
|Master of the Horse|Roman|Executive|Appointed|Courtly|
|Master of the Sacred Palace|Christian|Ceremonial|Appointed|Courtly|
|Mawlawi|Persian|Ceremonial|Identified|Institutional (madrassa)|
|Mayor|Latin|Executive/ legislative|Elected/ appointed|Local|
|Metropolitan Bishop|Christian|Executive/ judicial/ legislative|Appointed|Local|
|Mirza|Persian|Executive|Hereditary|Courtly|
|Monsignor|French|Ceremonial|Appointed|Courtly|
|Mullah|Persian|Ceremonial|Identified|Institutional (Sharia)|
|Naib|Arabic|Executive|Appointed/ elected|Local/ tribal|
|Nakharar|Armenian|Executive|Hereditary|Local|
|National Security Advisor|American|Administrative|Appointed|National|
|Navarch|Greek|Executive|Appointed|Divisional (equivalent to a modern four-star rank)|
|Nawab|Hindi/ Urdu|Executive|Hereditary|Provincial|
|Nawabzada or Nawabzadi|Persian/ Urdu|Ceremonial|Hereditary|Courtly|
|Nizam|Urdu|Executive|Hereditary|National/ regional|
|Nobilissimus|Latin|Ceremonial|Appointed|Courtly|
|Nomarch|Egyptian|Executive|Appointed/ hereditary|Provincial|
|Nuncio|Latin|Administrative|Appointed|Diplomatic|
|Nushi (Mistress)|Chinese|Ceremonial|Identified|Personal|
|Optio|Latin|Executive|Appointed|Divisional (centuria of about 100 soldiers)|
|Palatine|Latin|Administrative|Appointed|Provincial/ supernational|
|Pastor|Latin|Ceremonial|Elected|Institutional (local church)|
|Patriarch|Greek|Executive|Identified|Tribal|
|Patroon|Dutch|Executive|Appointed|Institutional (colonial manor)|
|Paygan Salarapoo|Persian|Executive|Appointed?|Divisional (entire infantry)|
|Peace Be Upon Him|Arabic|Ceremonial|Identified|Supernatural|
|Peshwa|Marathi|Executive|Appointed/ hereditary|Supranational|
|Pharaoh|Egyptian|Executive|Hereditary|National|
|Pir or Pirani|Persian|Administrative|Identified|Personal|
|Polemarch|Greek|Executive|Appointed/ chosen by lot/ elected|National|
|Pope|Latin|Executive|Elected|National/ supranational|
|Post Master General|American|Executive|Appointed|National|
|Praetor|Roman|Executive/ legislative|Elected|National|
|Presbyter|Greek|Ceremonial/ Executive|Appointed/ Elected|Local|
|President|Latin|Executive|Elected|Institutional/ national|
|President pro tempore|Latin|legislative|Elected by Senate|state/national|
|Presiding Patriarch|Christian|Administrative|Hereditary|Institutional (Latter Day Saint movement)|
|Priest|Christian, Hindu, Jewish, Neopagan, Pagan, Shinto, Zoroastrian|Ceremonial|Appointed|Institutional (temple)|
|Primate|Latin|Ceremonial/ judicial|Appointed|Courtly/ national|
|Prime minister|English|Executive/ legislative|Appointed|National|
|Prince or Princess|Latin|Ceremonial/ executive|Hereditary|National/ Provincial|
|Princeps|Latin|Executive|Identified|Supranational|
|Principal Lecturer|British|Administrative|Appointed|Institutional (university)|
|Prithvi-vallabha|Indian|Executive|Hereditary|Regional|
|Professor|Latin|Administrative/ ceremonial|Appointed|Institutional (university)|
|Professor Emeritus|Latin|Ceremonial|Identified|Institutional (university)|
|Propagator of Deportment|Tang dynasty|Ceremonial|Appointed|Courtly|
|Protodeacon|Greek|Administrative|Appointed|Institutional (local church)|
|Proxenos|Greek|Administrative|Purchased|Diplomatic|
|Prytaneis|Greek|Administrative|Appointed|Local/ tribal|
|Pursuivant|European|Administrative|Appointed|Institutional (College of Arms or similar body)|
|Rabbi|Hebrew|Ceremonial|Identified|Institutional (synagogue)|
|Raja or Rani|Sanskrit|Executive|Hereditary|National/ tribal|
|Rajmata|Sanskrit|Ceremonial|Appointed|National/ regional|
|Reader|British|Administrative|Appointed|Institutional (university)|
|Recipient from the Inner Chamber|Tang dynasty|Ceremonial|Appointed|Courtly|
|Recipient of Edicts|Tang dynasty|Ceremonial|Appointed|Courtly|
|Rector|Latin|Administrative|Elected|Institutional (university)|
|Reverend|Christian|Ceremonial|Identified|Personal|
|Roju|Japanese|Administrative|Appointed|National|
|Sacristan|Christian|Administrative|Appointed/ elected|Institutional (local church)|
|Saint|Latin|Ceremonial|Appointed/ identified|Institutional/ personal/ supernatural|
|Sakellarios|Greek|Administrative|Appointed|Supranational|
|Sahib or Sahibah|Arabic|Ceremonial/ executive|Hereditary/ identified|National/ personal|
|Satrap|Persian|Executive|Appointed|Provincial|
|Savakabuddha|Pali|Ceremonial|Identified|Personal|
|Sebastokrator|Greek|Ceremonial|Appointed|Courtly|
|Sebastos or Sebaste|Greek|Ceremonial|Appointed|Courtly|
|Secretary of State|European|Administrative|Appointed|Diplomatic/ national|
|Selected Lady|Tang dynasty|Ceremonial|Appointed|Courtly|
|Senior Aircraftman or Senior Aircraftwoman|British|Administrative|Appointed|Divisional (non-supervisory)|
|Senior Lecturer|British|Administrative|Appointed|Institutional (university)|
|Sergeant|Latin|Executive|Appointed|Divisional (squad of 8 to 14 soldiers)|
|Servant in the Place of Truth|Egyptian|Ceremonial|Appointed?|Institutional (Theban Necropolis)|
|Service Provider|Tang dynasty|Ceremonial|Appointed|Courtly|
|Shah|Persian|Executive|Hereditary|National|
|Shaman|Global|Ceremonial|Identified|Tribal|
|sheikh|Arabia | # leader | guide | protector|Allah|Appointed|Anointed|
|Shifu (Protector Teacher)|Chinese|Ceremonial|Identified|Personal|
|Shigong (Teacher of my Teacher)|Chinese|Ceremonial|Identified|Personal|
|Shimu (Woman of my Teacher)|Chinese|Ceremonial|Identified|Personal|
|Shofet|Hebrew|Executive/ judicial|Elected|National/ tribal|
|Shōgun|Japanese|Executive|Hereditary|National|
|Sibyl|Greek|Ceremonial|Identified|Institutional (holy site)|
|Somatophylax|Greek|Executive|Appointed|Courtly|
|Soter|Greek|Ceremonial|Identified|Supernatural|
|Spahbod|Persian|Executive|Appointed|Divisional (army corps of about 60,000 soldiers)|
|Sparapet|Armenian|Executive|Hereditary|Divisional (supreme military commander)|
|Sri or Sushri|Devanagari|Ceremonial|Identified|Personal|
|Starosta|Cyrillic|Executive|Appointed/ elected|Local/ national|
|Strategos|Greek|Executive|Appointed|Divisional (highest army rank)|
|Subedar|British/ Indian|Executive|Appointed|Divisional (highest native rank in British India)|
|Sultan|Arabic|Executive|Hereditary|National|
|Sunim|Korean|Ceremonial|Identified|Institutional (temple)|
|Swami|Sanskrit|Ceremonial|Identified|Personal|
|Syntagmatarchis|Greek|Executive|Appointed|Divisional (regiment of 300 to 5,000 soldiers)|
|Tagmatarchis|Greek|Executive|Appointed|Divisional (tagma of 500 to 1500 soldiers)|
|Taitai (married Madam)|Chinese|Ceremonial|Identified|Personal|
|Talented|Tang dynasty|Ceremonial|Appointed|Courtly|
|Tanuter|Armenian|Executive|Hereditary|Local|
|Taoiseach|Irish|Executive|Appointed|National|
|Taxiarch|Greek|Executive|Appointed|Divisional (brigade of 4,000 to 5,000 soldiers)|
|Temple boy|Thai|Administrative|Appointed|Personal|
|Tenzo|Buddhist|Administrative|Appointed?|Institutional (monastery)|
|Tetrarch|Greek|Executive|Appointed|Supranational|
|Thakore or Thakurani|Indian|Executive|Hereditary|Provincial|
|Theorodokoi|Greek|Administrative|Appointed|Diplomatic|
|Theoroi|Greek|Administrative|Appointed?|Diplomatic|
|The Most Honourable|British|Executive/ legislative|Hereditary|Provincial|
|The Right Honourable|English|Administrative/ ceremonial/ legislative|Appointed/ hereditary|Local/ national|
|Tirbodh|Persian|Executive|Appointed|Divisional (archers)|
|Tóngzhi (Comrade)|Chinese|Ceremonial|Identified|Personal|
|Toqui|Mapudungun|Executive|Elected|Tribal|
|Towel Attendant|Tang dynasty|Ceremonial|Appointed|Courtly|
|Tribune|Latin|Legislative|Elected|National|
|Trierarch|Greek|Executive|Purchased|Divisional (trireme ship)|
|Tsar or Tsaritsa|Bulgarian|Executive|Hereditary|National/ supranational|
|Unsui|Japanese|Ceremonial|Identified|Personal|
|Upasaka|Sanskrit|Ceremonial|Appointed|Personal|
|Upajjhaya|Sanskrit|Ceremonial|Appointed?|Personal|
|Vajracharya|Nepalese|Ceremonial|Hereditary/ identified|Institutional (monastery)|
|Varma|Indian|Executive|Appointed/ hereditary|Courtly/ regional|
|Venerable|Buddhist/ Christian|Ceremonial|Appointed|Institutional/ supernatural|
|Vicar general|Christian|Administrative|Appointed|Provincial (diocesan)|
|Viceroy or Vicereine|European|Executive|Appointed|National/ regional|
|Voivode|Bulgarian|Executive|Appointed/ hereditary|Divisional/ provincial|
|Weiyuán (Delegate)|Chinese|Legislative|Appointed?|National|
|Xiaojie (Little Woman)|Chinese|Ceremonial|Identified|Personal|
|Xiansheng (Firstborn)|Chinese|Ceremonial|Identified|Personal|
|Xiaozhang (Senior)|Chinese|Executive|Appointed|Institutional (school)|
|Xry Hbt|Egyptian|Ceremonial|Appointed?|Institutional (ritual center)|
|Yisheng (Medical Scholar)|Chinese|Administrative|Appointed/ identified|Institutional (Traditional Chinese medicine)/ personal|
|Yishi (Medical Master)|Chinese|Administrative|Identified|Institutional (Traditional Chinese medicine)|
|Yuvraj or Yuvrani|Indian|Ceremonial|Hereditary|Courtly|
|Zamindar|Devanagari|Executive/ judicial|Appointed/ hereditary|Local/ provincial|
|Zongshi (Ancestral Teacher)|Chinese|Ceremonial|Identified|Personal|
|Zhuxi (Chairperson)|Chinese|Executive|Elected|National|
|Lands’ Advocate|Dutch|Executive|Appointed|National|
|Stadtholder (Steward)|Dutch|Executive|Appointed|National|
|Grand Pensionary or councillor pensionary|Dutch|Executive|Appointed|National|

