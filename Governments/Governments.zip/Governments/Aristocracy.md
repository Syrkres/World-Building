
# Aristocracy
A form of government in which power is held by the nobility.