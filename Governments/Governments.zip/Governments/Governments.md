| Name | Details |
|:---|:---|
|**[[Anarchy]]**| absence of government  |
|**[[Aristocracy]]**| Rule by Heirs  |
|**[[Authoritarianism]]**| power is in the hands of a leader or small elite not responsible to the body of the people |
|**[[Confederation]]**| Each individual city or town governs itself, but each contributes to a league or confederation that has as its theoretical purpose the promotion of the common good of all member states |
|**[[Democracy]]** |a government by the people   |
|**[[Dictatorship]]**| a form of government in which a ruler or small clique wield absolute power  |
|**[[Federation]]**| Rule of the States  |
|**[[Feudalism]]** |Rule of Lords and Kings  |
|**[[Magocracy]]**| Rule by Mages  |
|**[[Militocracy]]**| Military Leaders run the nation under martial law |
|**[[Monarchy]]**|  undivided rule or absolute sovereignty by a single person  |
|**[[Oligarchy]]**| rule by few   |
|**[[Pedocracy]]**| Government by the learned associated wtih some form of bureaucracy |
|**[[Plutocracy]]**| Rule by the Rich|
|**[[Republic]]**|a government having a chief of state who is not a monarch and who rule on behalf of the electors |  
|**[[Socialist State]]**| Rule for Public, not Private  |
|**[[Theocracy]]**|  a form of government in which a Deity (or his priests) are recognized as the supreme civil ruler, but the Deity's laws are interpreted by ecclesiastical authorities  
|**[[Totalitarian]]**| centralized control by an autocratic leader or hierarchy  |
{style="td:nth-child(1): 100px"}

