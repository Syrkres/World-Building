# Pedocracy
Government by the learned, sages, or scholars. Usually associated with some form of bureaucracy.