# Democracy
Government by the people, either directly or through elected representatives. A skeletal bureaucracy or miiitocracy may actually do the day-to-day work of government, with positions filled through open elections.

