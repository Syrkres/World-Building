# Theocracy
A form of government in which a Deity (or his priests) are recognized as the supreme civil ruler, but the Deity's laws are interpreted by (church) authorities.