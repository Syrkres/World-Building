# Totalitarian
A form of government that theoretically permits no individual freedom and that seeks to subordinate all aspects of individual life to the authority of the state.