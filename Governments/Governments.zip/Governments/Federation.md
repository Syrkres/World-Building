# Federation
A group of states with a central government but independence in internal affairs.