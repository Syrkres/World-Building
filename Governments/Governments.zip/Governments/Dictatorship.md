# Dictatorship
One supreme ruler holds absolute authority, but is not necessarily dynastic. In other respects this resembles an autocracy.