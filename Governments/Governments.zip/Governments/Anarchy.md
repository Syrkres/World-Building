# Anarchy
A state of disorder due to absence or nonrecognition of authority.