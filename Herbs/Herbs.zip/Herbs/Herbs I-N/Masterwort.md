---
fileType: item
itemType: herb
name: Masterwort
locale: Rural
climate: Temperate
availability: Summer 95%
abilityCheck: Intelligence -15
uses: {Uses}
value: 2 gp/ 7 gp
preparation: 3 weeks
---
>#  Masterwort
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Summer 95%
> **Ability Check:** Intelligence -15
> **Uses:** 7
> **Value:** 2 gp/ 7 gp
> **Preparation:** 3 weeks
> **Description:** Masterwort grows to be about three feet tall and bears umbels of white flowers. It has winged dark green leaves like those of a maple tree. The leaves must be boiled and left to stand for at least twenty days before use. This herb is used as a protection from plague, giving a +2 bonus to any saves vs disease.
{.5eblock}

