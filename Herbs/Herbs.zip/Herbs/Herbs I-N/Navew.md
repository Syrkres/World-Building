---
fileType: item
itemType: herb
name: Navew
locale: Rivers
climate: Subtropical, Tropical
availability: Winter 60%
abilityCheck: 50%
uses: {Uses}
value: 4 gp/ 12 gp
preparation: 5 weeks
---
>#  Navew
>
> **Locale:** Rivers
> **Climate:** Subtropical, Tropical
> **Availability:** Winter 60%
> **Ability Check:** 50%
> **Uses:** 3
> **Value:** 4 gp/ 12 gp
> **Preparation:** 5 weeks
> **Description:** The seeds of Navew dropped in a drinks or on to food before it is eaten acts as counteragent to ingested poisons. It prevents the death of a person poisoned in that meal, though they may still be very ill.
{.5eblock}

