---
fileType: item
itemType: herb
name: Napweed
locale: Rural
climate: Temperate
availability: Spring 40%
abilityCheck: Intelligence -11
uses: {Uses}
value: 1 gp/ 1 gp
preparation: 1 week
---
>#  Napweed
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Spring 40%
> **Ability Check:** Intelligence -11
> **Uses:** 1
> **Value:** 1 gp/ 1 gp
> **Preparation:** 1 week
> **Description:** This plant has a single main stem with small fern like leaves, and small pink flowers growing from it. These flowers must be dried, powdered, and mixed into wine and then drunk to counter the effect of injected poisons. A successful application means that only half normal damage is taken from the poison. In addition to this use, the flower is often counted as a symbol of faith between lovers and is used to decorate and garnish foods at weddings. According to Greek mythology, this plant was used by the centaur, who wounded by Hercules with an arrow poisoned with the Hydra's blood, treated himself with it.
{.5eblock}

