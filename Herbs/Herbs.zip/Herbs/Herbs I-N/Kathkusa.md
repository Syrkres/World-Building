---
fileType: item
itemType: herb
name: Kathkusa
locale: Wasteland
climate: Polar
availability: Winter 30%
abilityCheck: Intelligence
uses: {Uses}
value: 50 gp/ 50 gp
preparation: none
---
>#  Kathkusa
>
> **Locale:** Wasteland
> **Climate:** Polar
> **Availability:** Winter 30%
> **Ability Check:** Intelligence
> **Uses:** 1
> **Value:** 50 gp/ 50 gp
> **Preparation:** none
> **Description:** This plant is found only in the most inhospitable regions. When a leaf of the plant is eaten, it will (if used successfully) raise a persons strength +2 (or 20 percentage points in the case of exceptional strength) for 1d10 rounds. However if the Intelligence check is failed by more than three, the person will collapse into unconsciousness for one hour.
{.5eblock}

