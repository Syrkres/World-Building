---
fileType: item
itemType: herb
name: Ironhard
locale: Hills
climate: Temperate
availability: Summer, Autumn 10%
abilityCheck: Intelligence -4
uses: {Uses}
value: 15 gp/ 15 gp
preparation: None
---
>#  Ironhard
>
> **Locale:** Hills
> **Climate:** Temperate
> **Availability:** Summer, Autumn 10%
> **Ability Check:** Intelligence -4
> **Uses:** 1
> **Value:** 15 gp/ 15 gp
> **Preparation:** None
> **Description:** This 2 foot high plant has dark blue leaves with a thick white hair growth on the underside. It grows all summer and the first half of autumn, and has many small yellow 6 leaved flowers. The plant has a milky white sap, which can be rubbed onto the skin, hardening it and granting a 1 bonus on armour-class for one hour.
{.5eblock}

