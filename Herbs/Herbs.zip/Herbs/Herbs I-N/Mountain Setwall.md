---
fileType: item
itemType: herb
name: Mountain_Setwall
locale: Mountains
climate: Temperate
availability: Always 40%
abilityCheck: Intelligence -7
uses: {Uses}
value: 1 gp/ 3 gp
preparation: 3 weeks
---
>#  Mountain Setwall
>
> **Locale:** Mountains
> **Climate:** Temperate
> **Availability:** Always 40%
> **Ability Check:** Intelligence -7
> **Uses:** 2
> **Value:** 1 gp/ 3 gp
> **Preparation:** 3 weeks
> **Description:**
{.5eblock}

