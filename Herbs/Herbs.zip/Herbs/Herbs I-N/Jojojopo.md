---
fileType: item
itemType: herb
name: Jojojopo
locale: Mountains
climate: Polar
availability: Autumn 60%
abilityCheck: Intelligence -5
uses: {Uses}
value: 9 sp/ 9 sp
preparation: none
---
>#  Jojojopo
>
> **Locale:** Mountains
> **Climate:** Polar
> **Availability:** Autumn 60%
> **Ability Check:** Intelligence -5
> **Uses:** 1
> **Value:** 9 sp/ 9 sp
> **Preparation:** none
> **Description:** The leaf of this herb, when applied to frostbite will cure 2d6 points of frostbite damage.
{.5eblock}

