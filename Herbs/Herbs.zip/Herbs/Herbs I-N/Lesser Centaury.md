---
fileType: item
itemType: herb
name: Lesser_Centaury
locale: Mountains
climate: Temperate, Cold
availability: Summer 25%
abilityCheck: Intelligence -3
uses: {Uses}
value: 5 gp/ 5 gp
preparation: none
---
>#  Lesser Centaury
>
> **Locale:** Mountains
> **Climate:** Temperate, Cold
> **Availability:** Summer 25%
> **Ability Check:** Intelligence -3
> **Uses:** 1
> **Value:** 5 gp/ 5 gp
> **Preparation:** none
> **Description:** This plant has rosy-pink flowers, which are splayed out like a five pointed star. These flowers if eaten within one day of being picked will cause the recipient to vomit up any ingested poison within their body. The person will remain very weak for 1d3 days, can only move with great difficulty and is totally able to perform any useful actions.
{.5eblock}

