---
fileType: item
itemType: herb
name: Makebate
locale: Desert
climate: Tropical, Subtropical
availability: Always 35%
abilityCheck: Intelligence -3
uses: {Uses}
value: 1 gp/2 gp
preparation: 2 weeks
---
>#  Makebate
>
> **Locale:** Desert
> **Climate:** Tropical, Subtropical
> **Availability:** Always 35%
> **Ability Check:** Intelligence -3
> **Uses:** 2
> **Value:** 1 gp/2 gp
> **Preparation:** 2 weeks
> **Description:** This herb will counteract the poison of scorpions if taken within 2 turns of the bite. Any damage, including death, already taken will remain.
{.5eblock}

