---
fileType: item
itemType: herb
name: Milkworte
locale: Rural
climate: Temperate
availability: Spring, Summer 95%
abilityCheck: Intelligence -16
uses: {Uses}
value: 4 gp/ 8 gp
preparation: 2 weeks
---
>#  Milkworte
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Spring, Summer 95%
> **Ability Check:** Intelligence -16
> **Uses:** 1
> **Value:** 4 gp/ 8 gp
> **Preparation:** 2 weeks
> **Description:** This herb protects from (for 1d4 days) and treats cholera (cures cholera in 1d4 days).
{.5eblock}

