---
fileType: item
itemType: herb
name: Kylathar
locale: Forest
climate: Subtropical
availability: Summer, Autumn 10%
abilityCheck: None
uses: {Uses}
value: 20 gp / 20 gp
preparation: None
---
>#  Kylathar
>
> **Locale:** Forest
> **Climate:** Subtropical
> **Availability:** Summer, Autumn 10%
> **Ability Check:** None
> **Uses:** 1
> **Value:** 20 gp / 20 gp
> **Preparation:** None
> **Description:** The Kylathar or Changeberry is a strange plant indeed. Anyone who eats the yellow, soft, plum sized fruits instantly has two random stats exchanged; Strength with Constitution, Wisdom with Dexterity; anything is possible (the GM should determine which statistics are exchanged). There is no saving throw, and no cure (no easy one anyway; if you as DM want one, make it up). Eating more of the berries will simply cause more stats to be randomly exchanged. Short of magical storage, the fruits will spoil and rot within 2 days after plucking. The bush itself grows about 2 metres high, with long, dusty green leaves, which are slightly sawed. The flowers grow in groups of 4 to 8, and are yellowish white with orange edges. The flowers grow in late spring, the fruits are ripe in autumn.
{.5eblock}

