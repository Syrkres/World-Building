---
fileType: item
itemType: herb
name: Laumspur
locale: Forest
climate: Temperate
availability: Spring 10%
abilityCheck: Intelligence -2
uses: {Uses}
value: 100 gp/ 500 gp (for potion)
preparation: 4 days (for potion)
---
>#  Laumspur
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Spring 10%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 100 gp/ 500 gp (for potion)
> **Preparation:** 4 days (for potion)
> **Description:** This is a green plant with small red flower, which are renowned for their healing properties. These flowers can be eaten fresh or dried for later use. If not dried they will become useless within 1 week. The flowers can also be brewed over a very low heat in fresh water to produce a `potion', which cane be drunk for its healing effect. When consumed, the herb will, on a successful herbalism check, heal 6 hp damage with fresh leaves, 4 hp using dry leaves, and 6 - 8 hp using the brew.
{.5eblock}

