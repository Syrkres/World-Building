---
fileType: item
itemType: herb
name: Marsh_Mallow
locale: Coastal
climate: Temperate
availability: Always 20%
abilityCheck: Intelligence -7
uses: {Uses}
value: 5 gp/ 8 gp
preparation: 1 day
---
>#  Marsh Mallow
>
> **Locale:** Coastal
> **Climate:** Temperate
> **Availability:** Always 20%
> **Ability Check:** Intelligence -7
> **Uses:** 3
> **Value:** 5 gp/ 8 gp
> **Preparation:** 1 day
> **Description:** This plant has a green fleshy stem and broad egg shaped leaves, both of which are covered with downy hairs. It has five petalled, pale pink flowers which sit at the base of the leaves. The root must be boiled and the resultant distillation applied to burns. If used successfully the herb will double the rate of healing for the burn.
{.5eblock}

