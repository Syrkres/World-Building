---
fileType: item
itemType: herb
name: Mandrake
locale: Forest
climate: Temperate
availability: Spring 40%
abilityCheck: Intelligence +1
uses: {Uses}
value: 3 gp/ 5 gp
preparation: 4 weeks
---
>#  Mandrake
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Spring 40%
> **Ability Check:** Intelligence +1
> **Uses:** 3
> **Value:** 3 gp/ 5 gp
> **Preparation:** 4 weeks
> **Description:** The root of this herb sends the recipient to sleep. The sleep will last five hours, during which time the person cannot be woken except by a neutralise poison spell or potion. The root is said to bear a resemblance to the naked male form, hence its name. The plant has several dark green leaves which are about 1 foot long. The purple flowers of the plant are bell shaped. The root of the plant must be boiled on the night of a full moon and left to sit for an entire month before use. According to Ancient Egyptian legend, the sun god, Ra, sent Mathor to earth to punish mankind. Mathor's slaughter was so intense, that Ra took pity on man, and forced Mathor to drink the blood of his victims mixed with Mandrake root. He fell asleep and when he awoke was unable to remember why he had come to earth, and so the slaughter was ended.
{.5eblock}

