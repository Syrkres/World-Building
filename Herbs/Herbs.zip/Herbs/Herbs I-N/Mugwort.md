---
fileType: item
itemType: herb
name: Mugwort
locale: Rural
climate: Temperate
availability: Summer 55%
abilityCheck: Intelligence -7
uses: {Uses}
value: 2 gp/ 4 gp
preparation: 2 weeks
---
>#  Mugwort
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Summer 55%
> **Ability Check:** Intelligence -7
> **Uses:** 2
> **Value:** 2 gp/ 4 gp
> **Preparation:** 2 weeks
> **Description:** The effects of this herb last for two hours. During this time the character can function at negative hit points, or beyond the point of exhaustion. Mugwort can grow to be taller than a man. It has a stiff and angular stem, reddish brown in colour. It has deeply incised smooth leaves which are dark green on top and silvery white underneath. It has small, yellow-green or yellow-red flowers arranged in long spikes at the top of the stem. THIS HERB IS HIGHLY ADDICTIVE. REPEATED USE IS VERY UNWISE.
{.5eblock}

