---
fileType: item
itemType: herb
name: Jaffray
locale: Desert
climate: Tropical
availability: Summer 10%
abilityCheck: Intelligence -2
uses: {Uses}
value: 10 gp/ 15 gp
preparation: 2 days
---
>#  Jaffray
>
> **Locale:** Desert
> **Climate:** Tropical
> **Availability:** Summer 10%
> **Ability Check:** Intelligence -2
> **Uses:** 2
> **Value:** 10 gp/ 15 gp
> **Preparation:** 2 days
> **Description:** A clove-like herb that is normally ground up and sprinkled into other dishes or drinks as flavouring, Jaffray also acts as a mild aphrodisiac, increasing sexual interest and general sensitivity to the surroundings. Face flushes, pupils dilate, breathing quickens, and skin becomes preternaturally sensitive. The herb has a mildly cinnamon-like flavour and its potency is not affected by being cooked. The herb is also sometimes used to counteract suspected poisoning, since it increases resistance to poison yet is so common as to be inoffensive if added to a meal. (Wisdom -2, Constitution +2, causes mild, pleasant sense of intoxication. Effects last 1d4 hours. Regular usage will build the user's tolerance to the drug, requiring greater amounts to achieve the same effects. Immunity is possible.)
{.5eblock}

