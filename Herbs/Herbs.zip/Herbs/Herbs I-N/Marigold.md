---
fileType: item
itemType: herb
name: Marigold
locale: Rural, Urban
climate: Temperate
availability: Spring, Summer 40%
abilityCheck: Intelligence -4
uses: {Uses}
value: 2 gp/ 10 gp
preparation: 2 weeks
---
>#  Marigold
>
> **Locale:** Rural, Urban
> **Climate:** Temperate
> **Availability:** Spring, Summer 40%
> **Ability Check:** Intelligence -4
> **Uses:** 4
> **Value:** 2 gp/ 10 gp
> **Preparation:** 2 weeks
> **Description:** Marigold can grow to a height of two feet and has rows of flat orange and yellow petals around a central disc. These flowers must be dried and then mixed with olive or other vegetable oil to produce a soothing balm which will soothe and clean small wounds, in order to prevent infection.
{.5eblock}

