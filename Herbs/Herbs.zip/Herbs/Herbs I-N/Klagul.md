---
fileType: item
itemType: herb
name: Klagul
locale: Grassland
climate: Temperate
availability: Summer 60%
abilityCheck: Intelligence -2
uses: {Uses}
value: 30 gp/ 50 gp
preparation: 1 day
---
>#  Klagul
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Summer 60%
> **Ability Check:** Intelligence -2
> **Uses:** 3
> **Value:** 30 gp/ 50 gp
> **Preparation:** 1 day
> **Description:** The buds of this plant must be boiled for a day and then eaten. After boiling they will keep for six weeks. When eaten, they will if successful give the recipient infravision for six hours.
{.5eblock}

