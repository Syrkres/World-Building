---
fileType: item
itemType: herb
name: Marjerome
locale: Grassland
climate: Temperate
availability: Always 35%
abilityCheck: Intelligence -2
uses: {Uses}
value: 2 gp/ 6 gp
preparation: 6 weeks
---
>#  Marjerome
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Always 35%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 2 gp/ 6 gp
> **Preparation:** 6 weeks
> **Description:** This herb removes the colour from the skin of a person who has had yellow jaundice. The herb has angular stems which grow to a height of 1 to 2 feet, which are reddish in colour and are covered in small hairs. It has ovate shaped leaves which surround the stem and grow smaller and smaller towards the top of the plant. It is topped by pale pink flowers.
{.5eblock}

