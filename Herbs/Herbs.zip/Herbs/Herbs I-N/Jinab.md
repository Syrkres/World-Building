---
fileType: item
itemType: herb
name: Jinab
locale: Rural
climate: Subtropical
availability: Always 10%
abilityCheck: Intelligence -4
uses: {Uses}
value: 5 gp/ 7 gp
preparation: 1 hour
---
>#  Jinab
>
> **Locale:** Rural
> **Climate:** Subtropical
> **Availability:** Always 10%
> **Ability Check:** Intelligence -4
> **Uses:** 2
> **Value:** 5 gp/ 7 gp
> **Preparation:** 1 hour
> **Description:** The dark chocolate brown bark of this small fast growing tree, may be eaten in order to allow a person to remain awake for one whole week, without the need for sleep. At the end of this period, they will collapse, absolutely exhausted for four days, and will capable of only half movement for a further week after that.
{.5eblock}

