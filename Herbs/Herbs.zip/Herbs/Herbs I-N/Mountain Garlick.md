---
fileType: item
itemType: herb
name: Mountain_Garlick
locale: Mountains
climate: Temperate, Cold
availability: Always 30%
abilityCheck: ?
uses: {Uses}
value: 8 gp/ 9 gp
preparation: 1 day
---
>#  Mountain Garlick
>
> **Locale:** Mountains
> **Climate:** Temperate, Cold
> **Availability:** Always 30%
> **Ability Check:** ?
> **Uses:** 2
> **Value:** 8 gp/ 9 gp
> **Preparation:** 1 day
> **Description:** This herb is said to repel evil spirits.
{.5eblock}

