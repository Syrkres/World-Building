---
fileType: item
itemType: herb
name: Larnurma
locale: Rural
climate: Temperate
availability: Spring 3%
abilityCheck: Intelligence -3
uses: {Uses}
value: 10 gp/ 100 gp (for oil)
preparation: 1 week (for oil)
---
>#  Larnurma
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Spring 3%
> **Ability Check:** Intelligence -3
> **Uses:** 3
> **Value:** 10 gp/ 100 gp (for oil)
> **Preparation:** 1 week (for oil)
> **Description:** This tree has round purple fruit, which are about the size and consistency of plums When eaten this fruit will heal 2 hp per fruit. These fruits cannot be dried and will rot within two weeks of picking. However the juice of three fruits can be mixed with olive (or other vegetable) oil, and left to stand for a week. This oil has an almost unlimited life. Rubbing this oil into the recipients skin will ease muscle pains, and also restore 1d4 hit points.
{.5eblock}

