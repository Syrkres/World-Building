---
fileType: item
itemType: herb
name: Kelventari
locale: Forest
climate: Temperate
availability: Always 50%
abilityCheck: Intelligence -6
uses: {Uses}
value: 19 gp/ 19 gp
preparation: none
---
>#  Kelventari
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Always 50%
> **Ability Check:** Intelligence -6
> **Uses:** 1
> **Value:** 19 gp/ 19 gp
> **Preparation:** none
> **Description:** If the crushed Kelventari berries are applied to a burn within one turn on its infliction it will heal 1d3 quarters of all damage caused by the burn, no matter how much damage was taken.
{.5eblock}

