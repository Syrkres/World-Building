---
fileType: item
itemType: herb
name: Megillos
locale: Mountains
climate: Cold
availability: Winter 75%
abilityCheck: Intelligence
uses: {Uses}
value: 1 gp/ 3 gp
preparation: none
---
>#  Megillos
>
> **Locale:** Mountains
> **Climate:** Cold
> **Availability:** Winter 75%
> **Ability Check:** Intelligence
> **Uses:** 1
> **Value:** 1 gp/ 3 gp
> **Preparation:** none
> **Description:** The leaves of this herb increases a character eyesight for 1 turn. They can see twice as far, and when in missile combat, all ranges are treated as if one less.
{.5eblock}

