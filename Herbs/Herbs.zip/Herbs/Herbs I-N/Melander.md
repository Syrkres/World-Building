---
fileType: item
itemType: herb
name: Melander
locale: Rivers
climate: Cold
availability: Winter 65%
abilityCheck: Intelligence
uses: {Uses}
value: 12 sp/ 20 sp
preparation: 1 day
---
>#  Melander
>
> **Locale:** Rivers
> **Climate:** Cold
> **Availability:** Winter 65%
> **Ability Check:** Intelligence
> **Uses:** 4
> **Value:** 12 sp/ 20 sp
> **Preparation:** 1 day
> **Description:** Melander is a moss that must be brewed in clear water. The resultant distillation must then be drunk. It will then add +1 to all saving throws vs disease for a period of 1d10 days.
{.5eblock}

