---
fileType: item
itemType: herb
name: Kilmakur
locale: Grassland
climate: Temperate
availability: Summer 45%
abilityCheck: Intelligence -3
uses: {Uses}
value: 65 gp/ 300 gp
preparation: 1 week
---
>#  Kilmakur
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Summer 45%
> **Ability Check:** Intelligence -3
> **Uses:** 1
> **Value:** 65 gp/ 300 gp
> **Preparation:** 1 week
> **Description:** The roots of this plant must be brewed over a low fire for one week, and the resulting distillation drunk. If used successfully, the recipient will gain a bonus of +2 to all saving throws versus fire based attacks for 1d10 hours.
{.5eblock}

