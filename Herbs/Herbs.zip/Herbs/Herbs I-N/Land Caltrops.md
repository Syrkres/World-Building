---
fileType: item
itemType: herb
name: Land_Caltrops
locale: Forest
climate: Tropical
availability: Summer 60%
abilityCheck: Intelligence -1
uses: {Uses}
value: 2 gp/ 5 gp
preparation: 2 weeks
---
>#  Land Caltrops
>
> **Locale:** Forest
> **Climate:** Tropical
> **Availability:** Summer 60%
> **Ability Check:** Intelligence -1
> **Uses:** 1
> **Value:** 2 gp/ 5 gp
> **Preparation:** 2 weeks
> **Description:** If applied to a snake bite within one turn, it will draw out the poison. Some very venomous snakes give bites that are incurable by this method, and so the herb has no effect against `instant death' poisons. It may (at the GMs discretion) provide protection against other, non- fatal animal poisons.)
{.5eblock}

