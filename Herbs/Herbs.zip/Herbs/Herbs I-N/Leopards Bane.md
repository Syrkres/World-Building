---
fileType: item
itemType: herb
name: Leopards_Bane
locale: Grassland
climate: Temperate
availability: Summer 25%
abilityCheck: Intelligence
uses: {Uses}
value: 5 gp/ 5 gp
preparation: none
---
>#  Leopard's Bane
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Summer 25%
> **Ability Check:** Intelligence
> **Uses:** 3
> **Value:** 5 gp/ 5 gp
> **Preparation:** none
> **Description:** This is a poison that kills animals (but not monsters) that eat it, but has no effect on humanoids, demi-humans or humans.
{.5eblock}

