---
fileType: item
itemType: herb
name: Mirenna
locale: Mountains
climate: Cold
availability: Winter 60%
abilityCheck: Intelligence -2
uses: {Uses}
value: 10 gp/ 10 gp
preparation: none
---
>#  Mirenna
>
> **Locale:** Mountains
> **Climate:** Cold
> **Availability:** Winter 60%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 10 gp/ 10 gp
> **Preparation:** none
> **Description:** The berries of Mirenna will heal 1d2 hp when eaten.
{.5eblock}

