---
fileType: item
itemType: herb
name: Bursthelas
locale: Grassland
climate: Temperate
availability: Summer 5%
abilityCheck: Intelligence
uses: {Uses}
value: 110 gp/ 1000 gp
preparation: 1 week
---
>#  Bursthelas
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Summer 5%
> **Ability Check:** Intelligence
> **Uses:** 2
> **Value:** 110 gp/ 1000 gp
> **Preparation:** 1 week
> **Description:** Bursthelas must be brewed for one week in fine red wine before it can be used. It must then be drunk within one month or spoil. A successful draft will heal any fractured bones within the body within one to three days.
{.5eblock}

