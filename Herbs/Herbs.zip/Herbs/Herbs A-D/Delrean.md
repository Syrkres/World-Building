---
fileType: item
itemType: herb
name: Delrean
locale: Forest
climate: Temperate
availability: Winter 80%
abilityCheck: -
uses: {Uses}
value: 3 sp/ 3 sp
preparation: 1 hour
---
>#  Delrean
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Winter 80%
> **Ability Check:** -
> **Uses:** 4
> **Value:** 3 sp/ 3 sp
> **Preparation:** 1 hour
> **Description:** The bark of Delrean should be boiled into a paste and then smeared on the skin. It will then repel any insect from coming near the recipient, but the foul stench will reduce their Charisma (Appearance) by 1d2. It is effective for 5d6 hours.
{.5eblock}

