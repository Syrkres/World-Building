---
fileType: item
itemType: herb
name: Degiik
locale: Coastal
climate: Tropical
availability: Summer 25%
abilityCheck: Intelligence -2
uses: {Uses}
value: 100 gp/ 100 gp
preparation: none
---
>#  Degiik
>
> **Locale:** Coastal
> **Climate:** Tropical
> **Availability:** Summer 25%
> **Ability Check:** Intelligence -2
> **Uses:** 3
> **Value:** 100 gp/ 100 gp
> **Preparation:** none
> **Description:** Degiik leaves must be given to someone at the point of death (at -10 hp and not losing any more hit points). They will keep the person alive for one day.
{.5eblock}

