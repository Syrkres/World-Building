---
fileType: item
itemType: herb
name: Dwarf_Mallow
locale: Swamp
climate: Temperate
availability: Spring 10%
abilityCheck: Intelligence -2
uses: {Uses}
value: 1 gp/ 3 gp
preparation: none
---
>#  Dwarf Mallow
>
> **Locale:** Swamp
> **Climate:** Temperate
> **Availability:** Spring 10%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 1 gp/ 3 gp
> **Preparation:** none
> **Description:** This small plant has a single primary stem from which other, shorter stems ending either with leaves or with small pick flowers. These flowers when crushed and mixed with honey and salt into a poultice will relieve the pain of bee stings on a successful application. In addition the crushed flower may be mixed with oil and smothered onto the body in which case, no bees will approach for 1d4 + 2 hours. At the GMs discretion, this effect may extend to other small insects.
{.5eblock}

