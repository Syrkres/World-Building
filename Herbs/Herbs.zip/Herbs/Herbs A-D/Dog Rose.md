---
fileType: item
itemType: herb
name: Dog_Rose
locale: Rural, Urban
climate: Temperate
availability: Summer, Autumn 70%
abilityCheck: Intelligence
uses: {Uses}
value: 1 sp/ 10 sp
preparation: 2 weeks
---
>#  Dog Rose
>
> **Locale:** Rural, Urban
> **Climate:** Temperate
> **Availability:** Summer, Autumn 70%
> **Ability Check:** Intelligence
> **Uses:** 10
> **Value:** 1 sp/ 10 sp
> **Preparation:** 2 weeks
> **Description:** The dog rose grows to about ten feet in height and has very sharp thorns. In spring and early summer it has pale pick flowers which turn into vivid orange seed pods at the end of summer. These pods must be dried and then eaten at the rate of one per three days to avoid scurvy in environments where this disease is common (ie, on long ocean voyages.) Certain ancient and medieval cultures believed that placing a dog rose in a coffin would prevent the body within from rising as undead.
{.5eblock}

