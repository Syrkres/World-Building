---
fileType: item
itemType: herb
name: Attanar
locale: Rivers
climate: Temperate
availability: Autumn, Winter 45%
abilityCheck: Intelligence -6
uses: {Uses}
value: 8 gp/ 8 gp
preparation: none
---
>#  Attanar
>
> **Locale:** Rivers
> **Climate:** Temperate
> **Availability:** Autumn, Winter 45%
> **Ability Check:** Intelligence -6
> **Uses:** 2
> **Value:** 8 gp/ 8 gp
> **Preparation:** none
> **Description:** Attanar is a moss, which when applied to the forehead of a stricken person, will cure fevers. It takes effect 2d6 hours after it is successfully administered.
{.5eblock}

