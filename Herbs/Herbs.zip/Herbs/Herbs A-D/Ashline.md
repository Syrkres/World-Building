---
fileType: item
itemType: herb
name: Ashline
locale: Mountains
climate: Temperate
availability: Winter, Spring 5%
abilityCheck: Intelligence -3
uses: {Uses}
value: 50 gp/ 500 gp
preparation: 1 week
---
>#  Ashline
>
> **Locale:** Mountains
> **Climate:** Temperate
> **Availability:** Winter, Spring 5%
> **Ability Check:** Intelligence -3
> **Uses:** 16
> **Value:** 50 gp/ 500 gp
> **Preparation:** 1 week
> **Description:** Ashline is a small red flower, with very pale green leaves. The entire plant must be mashed and boiled in fine red wine for one week and the resultant mixture mixed with olive oil. When this liquid is poured over a petrified person it will, on a successful roll, restore them to their normal state.
{.5eblock}

