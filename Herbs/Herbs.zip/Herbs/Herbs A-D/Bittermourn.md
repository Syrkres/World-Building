---
fileType: item
itemType: herb
name: Bittermourn
locale: All
climate: Polar
availability: Winter 5%
abilityCheck: Intelligence -14
uses: {Uses}
value: 1000 gp and up
preparation: 2 hours
---
>#  Bittermourn
>
> **Locale:** All
> **Climate:** Polar
> **Availability:** Winter 5%
> **Ability Check:** Intelligence -14
> **Uses:** 1
> **Value:** 1000 gp and up
> **Preparation:** 2 hours
> **Description:** A rare, colourless lichen that grows on rocks beneath year-round ice. When crushed and strained, it creates a clear gel at freezing temperatures that melts into liquid when warmer.  Imbibing a pint slows the aging process and grants a lifespan of twice normal length.
{.5eblock}

