---
fileType: item
itemType: herb
name: Athelas
locale: Forest
climate: Temperate
availability: Autumn 45%
abilityCheck: ?
uses: {Uses}
value: 200 gp/ 200 gp
preparation: none
---
>#  Athelas
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Autumn 45%
> **Ability Check:** ?
> **Uses:** 4
> **Value:** 200 gp/ 200 gp
> **Preparation:** none
> **Description:** Also known as "Kingsfoil". It appears as a vine with dark green leaves divided into four parts. According to legend, the leaves of Athelas when crushed by the hands of a King over the afflicted person are capable of curing anything.
{.5eblock}

