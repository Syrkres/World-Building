---
fileType: item
itemType: herb
name: Callin
locale: Jungle
climate: Tropical
availability: Autumn 30%
abilityCheck: Intelligence -2
uses: {Uses}
value: 5 gp/ 25 gp
preparation: 1 week
---
>#  Callin
>
> **Locale:** Jungle
> **Climate:** Tropical
> **Availability:** Autumn 30%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 5 gp/ 25 gp
> **Preparation:** 1 week
> **Description:** A dark nut that grows on the Callin tree in tropical jungles. When the husk is dried, ground and ingested, it thins the blood and strengthens internal organs, helping to prevent heart attacks. (If taken regularly, prevents heart attacks except under extreme duress. Addictive; causes nausea, dizziness and an increased chance of cardiac arrest if quit under unsupervised conditions after repeated use.)
{.5eblock}

