---
fileType: item
itemType: herb
name: Colewort
locale: Forest
climate: Temperate
availability: Spring, Summer 70%
abilityCheck: Intelligence -4
uses: {Uses}
value: 6 sp/ 6 sp
preparation: none
---
>#  Colewort
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Spring, Summer 70%
> **Ability Check:** Intelligence -4
> **Uses:** 1
> **Value:** 6 sp/ 6 sp
> **Preparation:** none
> **Description:** Colewort is a small plant with a single large glossy leaf, and small white flowers with four petals. Anyone who chews on the flowers before drinking will remain sober for the entire evening. Its effects protect only against alcohol, and not against any other drug or toxin.
{.5eblock}

