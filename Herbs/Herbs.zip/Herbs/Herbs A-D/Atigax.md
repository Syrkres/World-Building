---
fileType: item
itemType: herb
name: Atigax
locale: Grassland
climate: Temperate
availability: Winter 40%
abilityCheck: Intelligence
uses: {Uses}
value: 40 gp/ 70 gp
preparation: 1 day
---
>#  Atigax
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Winter 40%
> **Ability Check:** Intelligence
> **Uses:** 5
> **Value:** 40 gp/ 70 gp
> **Preparation:** 1 day
> **Description:** The roots of this plant must be brewed over a low fire for one day, and the resulting distillation drunk. If used successfully, sight will be protected from glare or blinding light for a period of nine hours. This herb can thus be used to limit the ill effects suffered by subterranean creatures (such as drow) in full sunlight.
{.5eblock}

