---
fileType: item
itemType: herb
name: Coltsfoot
locale: Mountains
climate: Temperate
availability: Spring, Summer 25%
abilityCheck: Intelligence -5
uses: {Uses}
value: 2 gp/ 4 gp
preparation: 1 hour
---
>#  Coltsfoot
>
> **Locale:** Mountains
> **Climate:** Temperate
> **Availability:** Spring, Summer 25%
> **Ability Check:** Intelligence -5
> **Uses:** 1
> **Value:** 2 gp/ 4 gp
> **Preparation:** 1 hour
> **Description:** The plant has a single golden yellow flower borne at the top of a six inch tall stem with long pinkish woolly scales. These flowers are crushed and mixed with honey, and applied as a poultice to infected wounds in a effort to draw out the infection. It does not cure any damage.
{.5eblock}

