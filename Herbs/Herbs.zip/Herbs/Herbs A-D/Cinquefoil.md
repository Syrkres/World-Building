---
fileType: item
itemType: herb
name: Cinquefoil
locale: Rural
climate: Temperate
availability: Summer 10%
abilityCheck: Intelligence -5
uses: {Uses}
value: 10 gp/ 15 gp
preparation: 1 hour
---
>#  Cinquefoil
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Summer 10%
> **Ability Check:** Intelligence -5
> **Uses:** 1
> **Value:** 10 gp/ 15 gp
> **Preparation:** 1 hour
> **Description:** This plant creeps along the ground on long slender stringlike stalks. It has five or seven part leaves, and small yellow flowers. The stalks must be boiled in white wine or vinegar and then drunk. The herb will then act as an aphrodisiac, and increase the recipients Charisma [Appearance] by 1 for 1d4 hours.
{.5eblock}

