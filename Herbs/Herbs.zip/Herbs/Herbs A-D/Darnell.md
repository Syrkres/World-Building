---
fileType: item
itemType: herb
name: Darnell
locale: Forest
climate: Temperate
availability: Autumn 40%
abilityCheck: Intelligence -2
uses: {Uses}
value: 3 gp/ 7 gp
preparation: 2 weeks
---
>#  Darnell
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Autumn 40%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 3 gp/ 7 gp
> **Preparation:** 2 weeks
> **Description:** These tiny yellow flowers will, if eaten, cause dimness of the sight for several hours. This dimness means that in full light the character will see as if on a moonlit night. This herb does effect those with infravision or ultravision.
{.5eblock}

