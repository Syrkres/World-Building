---
fileType: item
itemType: herb
name: Chervil
locale: Forest
climate: Temperate
availability: Always 10%
abilityCheck: Intelligence -5
uses: {Uses}
value: 10 gp/ 10 gp
preparation: none
---
>#  Chervil
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Always 10%
> **Ability Check:** Intelligence -5
> **Uses:** 1
> **Value:** 10 gp/ 10 gp
> **Preparation:** none
> **Description:** Chervil is used to dissolve blood clots, which can help to prevent complications caused by injury. The clots are dissolved within 1d3 turns.
{.5eblock}

