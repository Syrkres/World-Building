---
fileType: item
itemType: herb
name: Belramba
locale: Forest
climate: Temperate
availability: Summer 30%
abilityCheck: Intelligence -3
uses: {Uses}
value: 60 gp/ 180 gp
preparation: 3 days
---
>#  Belramba
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Summer 30%
> **Ability Check:** Intelligence -3
> **Uses:** 1
> **Value:** 60 gp/ 180 gp
> **Preparation:** 3 days
> **Description:** Belramba is a lichen. It must be brewed in water, and then drunk three days later. If used successfully, all nerve damage capable of healing naturally will be healed, at three times the normal rate.
{.5eblock}

