---
fileType: item
itemType: herb
name: Comfrey
locale: Rural
climate: Temperate
availability: Spring 50%
abilityCheck: Intelligence -5
uses: {Uses}
value: 4 gp/ 10 gp
preparation: 1 day
---
>#  Comfrey
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Spring 50%
> **Ability Check:** Intelligence -5
> **Uses:** 1
> **Value:** 4 gp/ 10 gp
> **Preparation:** 1 day
> **Description:** Comfrey grows to a height of up to 3 feet. It has stiff, angular and hollow stalks which are covered with rough hairs. It has pink, mauve white or cream flowers. Its thick black root is the portion used in Herbalism. It should be boiled and wrapped in a poultice which is then wrapped around a broken limb and increases the speed of healing by fifty percent. It can also be used in a bath by women in order to give the impression that they are virgins on their wedding nights.
{.5eblock}

