---
fileType: item
itemType: herb
name: Bastit
locale: All
climate: Temperate
availability: Always 20%
abilityCheck: Intelligence +2
uses: {Uses}
value: 3 sp/ 3 sp
preparation: none
---
>#  Bastit
>
> **Locale:** All
> **Climate:** Temperate
> **Availability:** Always 20%
> **Ability Check:** Intelligence +2
> **Uses:** 1
> **Value:** 3 sp/ 3 sp
> **Preparation:** none
> **Description:** A small succulent that, when crushed, tends to repel parasitic insects, including mosquitoes and the like. It has a pungent but not unpleasant odour. (Lasts 1d6 hours but can be washed or sweated off.  Easily noticed by tracking animals.)
{.5eblock}

