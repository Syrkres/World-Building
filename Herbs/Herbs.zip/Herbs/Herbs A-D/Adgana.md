---
fileType: item
itemType: herb
name: Adgana
locale: Rural
climate: Temperate
availability: Spring 10%
abilityCheck: Intelligence
uses: {Uses}
value: 10 gp/ 500 gp
preparation: 1 week
---
>#  Adgana
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Spring 10%
> **Ability Check:** Intelligence
> **Uses:** 1
> **Value:** 10 gp/ 500 gp
> **Preparation:** 1 week
> **Description:** The leaves of this plant must be dried. They may then be crushed and eaten. It's effects diminish with constant use. The first time and second time Adgana is used it adds 2 to the user's Strength, Dexterity and Constitution for 2d4+4 minutes. The third time it is used it adds 1 to Strength and Dexterity for the same amount of time, the 4th time +1 is added to Strength only, and after that no benefit is ever gained. In addition to this, the herb is also highly addictive.
{.5eblock}

