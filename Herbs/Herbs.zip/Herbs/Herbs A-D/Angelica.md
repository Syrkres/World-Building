---
fileType: item
itemType: herb
name: Angelica
locale: Mountains
climate: Temperate
availability: Summer 30%
abilityCheck: Intelligence -3
uses: {Uses}
value: 5 sp/ 1 gp
preparation: 1 hour
---
>#  Angelica
>
> **Locale:** Mountains
> **Climate:** Temperate
> **Availability:** Summer 30%
> **Ability Check:** Intelligence -3
> **Uses:** 2
> **Value:** 5 sp/ 1 gp
> **Preparation:** 1 hour
> **Description:** Angelica's root should be boiled in water for an hour and then drunk in order to relieve coughs. The plant can grow to a height of eight feet. It has a hollow stem and has large, broad pointed leaves at the base of the stem. It has a cluster of white or pink flowers at the top of the stem. The herbs does not in any way act as a cure for any disease causing a cough, it merely reduces the amount of coughing.
{.5eblock}

