---
fileType: item
itemType: herb
name: Black_Rose
locale: All
climate: Temperate
availability: Spring, Summer 5%
abilityCheck: Intelligence -2
uses: {Uses}
value: 100 gp/ 100 gp
preparation: none
---
>#  Black Rose
>
> **Locale:** All
> **Climate:** Temperate
> **Availability:** Spring, Summer 5%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 100 gp/ 100 gp
> **Preparation:** none
> **Description:** This rare rose is easily identified by its black, velvety flower and long white thorns. The thorns are hollow and absorb liquids at a rate of a pint every 5 minutes. The liquid is stored in the plant's fibrous roots. The black rose's roots are often used to draw poison from wounds or, placed under the tongue, to absorb alcohol and prevent intoxication. Sometimes victims are tied down and pierced with the thorns to cause prolonged and painful exsanguination.
{.5eblock}

