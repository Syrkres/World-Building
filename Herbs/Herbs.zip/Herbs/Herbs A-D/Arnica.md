---
fileType: item
itemType: herb
name: Arnica
locale: Mountains
climate: Temperate, Cold
availability: Summer 25%
abilityCheck: Intelligence - 6
uses: {Uses}
value: 1 gp/ 1 gp
preparation: none
---
>#  Arnica
>
> **Locale:** Mountains
> **Climate:** Temperate, Cold
> **Availability:** Summer 25%
> **Ability Check:** Intelligence - 6
> **Uses:** 1
> **Value:** 1 gp/ 1 gp
> **Preparation:** none
> **Description:** This plant grows to a height of 1 to 2 feet. It has a hairy stem on which its leaves are arranged in pairs. It has orange flowers. These flowers should be plucked and dried, and then boiled in a litre of beer. This should be applied to a compress which is wrapped around a bruise. A successful application will cause the bruise to fade within one day. The pollen of the flowers if inhaled will cause uncontrollable sneezing. A phial of arnica carried in a persons pocket is also reputed to help a person quit smoking.
{.5eblock}

