---
fileType: item
itemType: herb
name: Borage
locale: Forest
climate: Temperate
availability: Spring 30%
abilityCheck: Intelligence -3
uses: {Uses}
value: 1 gp/ 10 gp
preparation: 5 days
---
>#  Borage
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Spring 30%
> **Ability Check:** Intelligence -3
> **Uses:** 1
> **Value:** 1 gp/ 10 gp
> **Preparation:** 5 days
> **Description:** This plant has hollow, hairy cylindrical stalks which grow to a height of 1 to 2 feet. It has drooping flowers, red or blue in colour, which are shaped as a five pointed star at the top of the stem. The dried herb should be boiled in water and the infusion drunk. It is used to cure minor fevers such as those caused by chills, and influenza. It will relieve the fever in 1d3 hours.
{.5eblock}

