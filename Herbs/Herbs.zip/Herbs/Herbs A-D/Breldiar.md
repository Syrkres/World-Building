---
fileType: item
itemType: herb
name: Breldiar
locale: Volcanoes
climate:
availability: Spring 35%
abilityCheck: Intelligence -2
uses: {Uses}
value: 50 gp/ 50 gp
preparation: none
---
>#  Breldiar
>
> **Locale:** Volcanoes
> **Climate:**
> **Availability:** Spring 35%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 50 gp/ 50 gp
> **Preparation:** none
> **Description:** This flower, when eaten, alters the way a person judges distance for a period of one hour. While under the influence of the flower, a person can add a bonus of two to ranged combat attacks, while subtracting two from melee attacks.
{.5eblock}

