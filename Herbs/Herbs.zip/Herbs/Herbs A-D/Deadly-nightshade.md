---
fileType: item
itemType: herb
name: Deadly-nightshade
locale: Forest
climate: Temperate
availability: Summer 75%
abilityCheck: Intelligence +3
uses: {Uses}
value: 4 gp/ 8 gp
preparation: 1 week
---
>#  Deadly-nightshade
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Summer 75%
> **Ability Check:** Intelligence +3
> **Uses:** 4
> **Value:** 4 gp/ 8 gp
> **Preparation:** 1 week
> **Description:** This plant can grow up to five feet tall. It has soft green spreading leaves, and purple flowers and berries. The berries must be left to stand in water for a week and the distillation drunk. Deadly nightshade will put someone to sleep for 4d8 hours. They cannot be woken. A roll of 1 will kill them, a roll of 20 will render them insane.
{.5eblock}

