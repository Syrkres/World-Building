---
fileType: item
itemType: herb
name: Aloe
locale: Grassland
climate: Temperate
availability: Autumn, Winter 55%
abilityCheck: Intelligence
uses: {Uses}
value: 5 cp/ 5 cp
preparation: none
---
>#  Aloe
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Autumn, Winter 55%
> **Ability Check:** Intelligence
> **Uses:** 2
> **Value:** 5 cp/ 5 cp
> **Preparation:** none
> **Description:** The leaf of Aloe applied to a wound, will double the natural healing rate of burns and minor cuts.
{.5eblock}

