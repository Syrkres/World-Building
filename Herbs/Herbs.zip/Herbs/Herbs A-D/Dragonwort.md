---
fileType: item
itemType: herb
name: Dragonwort
locale: Mountains
climate: Cold
availability: Spring 25%
abilityCheck: Intelligence
uses: {Uses}
value: 100 gp/ 300 gp
preparation: 3 days
---
>#  Dragonwort
>
> **Locale:** Mountains
> **Climate:** Cold
> **Availability:** Spring 25%
> **Ability Check:** Intelligence
> **Uses:** 1
> **Value:** 100 gp/ 300 gp
> **Preparation:** 3 days
> **Description:** This plant has a gnarled, erect and cylindrical stem. It has wavy leaves, dark green on top, bluish green underneath. It has pink flowers that cluster in a spike at the top of the stem. The root of this herb should be boiled over a low heat for three days, and the infusion drunk by people with smallpox and the plague in order to effect a cure. The value of this herb increases greatly in times of plague.
{.5eblock}

