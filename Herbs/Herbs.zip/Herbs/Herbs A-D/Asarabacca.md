---
fileType: item
itemType: herb
name: Asarabacca
locale: Forest
climate: Temperate
availability: Spring 10%
abilityCheck: Intelligence -6
uses: {Uses}
value: 3 gp/ 7 gp
preparation: 1 day
---
>#  Asarabacca
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Spring 10%
> **Ability Check:** Intelligence -6
> **Uses:** 2
> **Value:** 3 gp/ 7 gp
> **Preparation:** 1 day
> **Description:** Asarabacca is a creeping vine with many small leaves each on their own small stalk. It also has small purple flowers. These flowers must be brewed up on a fire and left to stand. When administered successfully to someone, they must save vs poison or be rendered docile, and incapable of violence for 3d8 hours. The brew has a distinctive purple colour, and bitter taste, so to be given secretly in food, the food must be able to hide these attributes.
{.5eblock}

