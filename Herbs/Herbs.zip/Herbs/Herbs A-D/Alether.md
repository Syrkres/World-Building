---
fileType: item
itemType: herb
name: Alether
locale: Rural
climate: Temperate
availability: Spring, Summer 5%
abilityCheck: Intelligence -5
uses: {Uses}
value: 10 gp/ 100 gp (for potion)
preparation: 1 day (for potion)
---
>#  Alether
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Spring, Summer 5%
> **Ability Check:** Intelligence -5
> **Uses:** 1
> **Value:** 10 gp/ 100 gp (for potion)
> **Preparation:** 1 day (for potion)
> **Description:** Eating a handful of these orange berries will add +1 to both a characters chance to hit, and to their damage rolls for 2d6 minutes. The berries can be brewed in white wine to produce a drink that will add +2 to the recipients chance to hit, and temporarily give them 2d4 hp. This effect lasts for 2d12 minutes, and ends with the characters total collapse for 1d3 days unless they successfully save against poison. This brew will only be useful for one month after manufacture and then loses its potency.
{.5eblock}

