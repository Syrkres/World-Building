---
fileType: item
itemType: herb
name: Archangelica
locale: Swamp
climate: Temperate
availability: Summer 30%
abilityCheck: Intelligence -2
uses: {Uses}
value: 5 sp/ 5 sp
preparation: none
---
>#  Archangelica
>
> **Locale:** Swamp
> **Climate:** Temperate
> **Availability:** Summer 30%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 5 sp/ 5 sp
> **Preparation:** none
> **Description:** This white flowering plant has black seeds and roots with a sharp taste. The root, when brewed, makes a hot, peppery decoction that helps alleviate common colds, flu and congestions (doubles recovery time, adds +2 to Constitution rolls to prevent colds in bad weather).
{.5eblock}

