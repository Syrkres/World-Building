---
fileType: item
itemType: herb
name: Anserke
locale: Coastal
climate: Tropical
availability: Summer 30%
abilityCheck: Intelligence -4
uses: {Uses}
value: 75 gp/ 75 gp
preparation: none
---
>#  Anserke
>
> **Locale:** Coastal
> **Climate:** Tropical
> **Availability:** Summer 30%
> **Ability Check:** Intelligence -4
> **Uses:** 1
> **Value:** 75 gp/ 75 gp
> **Preparation:** none
> **Description:** The root must be applied to a bleeding wound. Within three rounds it will have stopped the bleeding. The recipient must not move for one turn or risk the wound reopening.
{.5eblock}

