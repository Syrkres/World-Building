---
fileType: item
itemType: herb
name: Dittany
locale: Rivers
climate: Temperate
availability: Summer, Autumn 55%
abilityCheck: Intelligence
uses: {Uses}
value: 1 gp/ 5 gp
preparation: 2 weeks
---
>#  Dittany
>
> **Locale:** Rivers
> **Climate:** Temperate
> **Availability:** Summer, Autumn 55%
> **Ability Check:** Intelligence
> **Uses:** 3
> **Value:** 1 gp/ 5 gp
> **Preparation:** 2 weeks
> **Description:** This herb grows six or eight inches high with square stalks and sort round leaves. The leaves must be dried for two weeks and then be boiled in ale or wine. It is then applied as a lotion. Dittany can be used to draw splinter and bone fragments from a wound. It is also an effective antiseptic for cleaning wounds, and can therefore prevent infections caused by dirty water etc.
{.5eblock}

