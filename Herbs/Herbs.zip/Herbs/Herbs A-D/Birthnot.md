---
fileType: item
itemType: herb
name: Birthnot
locale: Hills
climate: Temperate
availability: Always 30%
abilityCheck: Intelligence
uses: {Uses}
value: 2 cp/ 2 cp
preparation: 3 days
---
>#  Birthnot
>
> **Locale:** Hills
> **Climate:** Temperate
> **Availability:** Always 30%
> **Ability Check:** Intelligence
> **Uses:** 1
> **Value:** 2 cp/ 2 cp
> **Preparation:** 3 days
> **Description:** Birthnot is a dark-leaved, flowerless vine. The dried leaves can be used to create a contraceptive tea effective on most humans, demihumans and humanoids, male or female.  Must be ingested between 1 hour - 30 minutes before properties invoked. (70% effective; causes mild impotence in males 15% of the time.)
{.5eblock}

