---
fileType: item
itemType: herb
name: Base_Mullein
locale: Rural
climate: Temperate
availability: Always 90%
abilityCheck: Intelligence
uses: {Uses}
value: 10 sp/ 10 sp
preparation: none
---
>#  Base Mullein
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Always 90%
> **Ability Check:** Intelligence
> **Uses:** 1
> **Value:** 10 sp/ 10 sp
> **Preparation:** none
> **Description:** Base Mullein is very easily found due to the fact that its flower stalks often obtain a height of 8 feet or more. Its clear yellow flowers cover about 3 feet of the top of the stalk, and form a long funnel about an inch or two in diameter. If the leaves of this herb are applied to a burn within one hour, it will reduce the damage taken from the burn, by half.
{.5eblock}

