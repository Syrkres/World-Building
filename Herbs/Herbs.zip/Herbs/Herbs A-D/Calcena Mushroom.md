---
fileType: item
itemType: herb
name: Calcena_Mushroom
locale: Underworld
climate: Any
availability: Always 2%
abilityCheck: -
uses: {Uses}
value: 100 gp/ 1000 gp (for potion)
preparation: 2 week (for potion)
---
>#  Calcena Mushroom
>
> **Locale:** Underworld
> **Climate:** Any
> **Availability:** Always 2%
> **Ability Check:** -
> **Uses:** 1
> **Value:** 100 gp/ 1000 gp (for potion)
> **Preparation:** 2 week (for potion)
> **Description:** Anyone who breathes in the spoors of one of these pink mushrooms incurs a -3 penalty on all saves vs illusions for 2d12 hours. The mushroom may be brewed into a potion by brewing tea and leaving the mushroom to stand in the tea for 2 weeks. The resultant concoction when drunk is a powerful hallucinogen. Anyone under the influence of it will see whatever the GM wants them to see. This effect also lasts 2d12 hours.
{.5eblock}

