---
fileType: item
itemType: herb
name: Alkanet
locale: Rural
climate: Temperate
availability: Summer 30%
abilityCheck: Intelligence -4
uses: {Uses}
value: 2 gp/ 2 gp
preparation: none
---
>#  Alkanet
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Summer 30%
> **Ability Check:** Intelligence -4
> **Uses:** 1
> **Value:** 2 gp/ 2 gp
> **Preparation:** none
> **Description:** This plant has a thick red root, narrow hairy leaves, and small red or blue flowers. The root can be eaten directly upon being drawn out of the ground but will only keep for a week or so. The herb allows a +1 bonus to any saving throw vs ingested poisons for 1d8 hours after eating.
{.5eblock}

