---
fileType: item
itemType: herb
name: Arnuminas
locale: Grassland
climate: Temperate
availability: Autumn 70%
abilityCheck: Intelligence -1
uses: {Uses}
value: 6 gp/ 6 gp
preparation: none
---
>#  Arnuminas
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Autumn 70%
> **Ability Check:** Intelligence -1
> **Uses:** 5
> **Value:** 6 gp/ 6 gp
> **Preparation:** none
> **Description:** The leaf of this plant should be applied to the site of ligament, cartilage, or muscle damage. If used successfully, it will double the speed of healing of such damage.
{.5eblock}

