---
fileType: item
itemType: herb
name: Culkas
locale: Desert
climate: Tropical
availability: Always 40%
abilityCheck: Intelligence
uses: {Uses}
value: 35 gp/ 35 gp
preparation: none
---
>#  Culkas
>
> **Locale:** Desert
> **Climate:** Tropical
> **Availability:** Always 40%
> **Ability Check:** Intelligence
> **Uses:** 10
> **Value:** 35 gp/ 35 gp
> **Preparation:** none
> **Description:** Each application of Culkas will cure one square foot of sunburn.
{.5eblock}

