---
fileType: item
itemType: herb
name: Darsurion
locale: Mountains
climate: Cold
availability: Winter 50%
abilityCheck: Intelligence -6
uses: {Uses}
value: 3 sp/ 3 sp
preparation: none
---
>#  Darsurion
>
> **Locale:** Mountains
> **Climate:** Cold
> **Availability:** Winter 50%
> **Ability Check:** Intelligence -6
> **Uses:** 1
> **Value:** 3 sp/ 3 sp
> **Preparation:** none
> **Description:** The leaves of Darsurion when applied to a wound will heal 1 hp of damage if used within 3 rounds. The effect is not cumulative.
{.5eblock}

