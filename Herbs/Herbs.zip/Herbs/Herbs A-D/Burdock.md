---
fileType: item
itemType: herb
name: Burdock
locale: Rural
climate: Temperate
availability: Spring 35%
abilityCheck: Intelligence -6
uses: {Uses}
value: 10 gp/ 30 gp
preparation: 1 day
---
>#  Burdock
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Spring 35%
> **Ability Check:** Intelligence -6
> **Uses:** 1
> **Value:** 10 gp/ 30 gp
> **Preparation:** 1 day
> **Description:** This plant grows to about 3 feet tall. It has huge leaves with a whitish underside, and purple flours. Its root must be boiled in water and then the root eaten and the water drunk as a cure for syphilis. The person will be cured within a week.
{.5eblock}

