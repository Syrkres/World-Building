---
fileType: item
itemType: herb
name: Arfandas
locale: Rivers
climate: Cold
availability: Autumn, Winter 50%
abilityCheck: Intelligence -6
uses: {Uses}
value: 2 sp/ 3 sp
preparation: 1 day
---
>#  Arfandas
>
> **Locale:** Rivers
> **Climate:** Cold
> **Availability:** Autumn, Winter 50%
> **Ability Check:** Intelligence -6
> **Uses:** 4
> **Value:** 2 sp/ 3 sp
> **Preparation:** 1 day
> **Description:** If the stem of Arfandas is bound up in the dressing of a fracture, it will double the rate of healing for that fracture.
{.5eblock}

