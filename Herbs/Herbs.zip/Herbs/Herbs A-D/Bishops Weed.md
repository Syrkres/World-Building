---
fileType: item
itemType: herb
name: Bishops_Weed
locale: Rural
climate: Temperate
availability: Summer 45%
abilityCheck: Intelligence -6
uses: {Uses}
value: 4 gp/ 10 gp
preparation: 3 weeks
---
>#  Bishop's Weed
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Summer 45%
> **Ability Check:** Intelligence -6
> **Uses:** 3
> **Value:** 4 gp/ 10 gp
> **Preparation:** 3 weeks
> **Description:** Bishop's weed is a small plant with pale blue flowers, and small pale green leaves. This herb will protect people from Plague (+5 bonus to saves vs disease). It is drunk in wine, and is effective for one week. In plague years, its price increases rapidly.
{.5eblock}

