---
fileType: item
itemType: herb
name: Basil
locale: Rural
climate: Temperate
availability: Summer 30%
abilityCheck: Intelligence -3
uses: {Uses}
value: 3 sp/ 3 sp
preparation: none
---
>#  Basil
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Summer 30%
> **Ability Check:** Intelligence -3
> **Uses:** 1
> **Value:** 3 sp/ 3 sp
> **Preparation:** none
> **Description:** Basil must be used almost immediately on being picked. The leaves should be applied to the bite of a venomous creature, and it will then have the effect of drawing out the poison. It will give a bonus of +4 to the saving throw vs poison, or if the save has already been made and failed, it will allow a second saving throw at normal values. Any damage already sustained will remain. The herb has one upright stalk, and small white flowers.
{.5eblock}

