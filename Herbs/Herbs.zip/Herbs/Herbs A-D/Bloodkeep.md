---
fileType: item
itemType: herb
name: Bloodkeep
locale: Coastal
climate: Temperate
availability: Spring 20%
abilityCheck: Intelligence
uses: {Uses}
value: 4 sp/ 4 sp
preparation: none
---
>#  Bloodkeep
>
> **Locale:** Coastal
> **Climate:** Temperate
> **Availability:** Spring 20%
> **Ability Check:** Intelligence
> **Uses:** 1
> **Value:** 4 sp/ 4 sp
> **Preparation:** none
> **Description:** Tall stalks with jagged leaves and purple-red flowers, bloodkeep's fresh leaves can be bound to a wound to stop bleeding at once and quicken coagulation (apply within 2 rounds of injury to stop bleeding; character regains 20% - rounded down - of lost hit points at once).
{.5eblock}

