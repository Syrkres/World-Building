---
fileType: item
itemType: herb
name: Blackberry
locale: Rural
climate: Temperate
availability: Spring 65%
abilityCheck: Intelligence -2
uses: {Uses}
value: 1 gp/ 1 gp
preparation: none
---
>#  Blackberry
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Spring 65%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 1 gp/ 1 gp
> **Preparation:** none
> **Description:** The leaves of these small black berries should be crushed and applied to small wounds, where they can stop minor bleeding very quickly (within one round).
{.5eblock}

