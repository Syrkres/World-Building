---
fileType: item
itemType: herb
name: Arlan
locale: Grassland
climate: Cold
availability: Autumn 60%
abilityCheck: Intelligence -5
uses: {Uses}
value: 20 sp/ 20 sp
preparation: none
---
>#  Arlan
>
> **Locale:** Grassland
> **Climate:** Cold
> **Availability:** Autumn 60%
> **Ability Check:** Intelligence -5
> **Uses:** 1
> **Value:** 20 sp/ 20 sp
> **Preparation:** none
> **Description:** The leaf of Arlan when applied to a wound will heal 1 hp of damage if it is used within 5 rounds. Arlan will also speed a persons recovery from respiratory illness by five times.
{.5eblock}

