---
fileType: item
itemType: herb
name: All-heale
locale: Forest
climate: Temperate
availability: Autumn 75%
abilityCheck: Intelligence +1
uses: {Uses}
value: 2 gp/ 10 gp
preparation: 2 weeks
---
>#  All-heale
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Autumn 75%
> **Ability Check:** Intelligence +1
> **Uses:** 7
> **Value:** 2 gp/ 10 gp
> **Preparation:** 2 weeks
> **Description:** When All-heale is mixed in a pint of olive oil and applied to a wound, (one application per day), the recipient will heal even if still working as normal. With rest, the recipient will heal at three times the normal rate.
{.5eblock}

