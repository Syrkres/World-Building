---
fileType: item
itemType: herb
name: Bull-rush
locale: Swamp
climate: Temperate, Subtropical
availability: Always 55%
abilityCheck: Intelligence +3
uses: {Uses}
value: 2 sp/ 3 sp
preparation: 3 days
---
>#  Bull-rush
>
> **Locale:** Swamp
> **Climate:** Temperate, Subtropical
> **Availability:** Always 55%
> **Ability Check:** Intelligence +3
> **Uses:** 2
> **Value:** 2 sp/ 3 sp
> **Preparation:** 3 days
> **Description:** Bull-rushes are tall straight stemmed plants with many small flowers at the top of the stalk. These flowers must be ground into an ointment which is applied to a persons eyes or tongue. This herb will put someone to sleep for 3d12 hours. A roll of 1 on the ability check will put the person into a coma.
{.5eblock}

