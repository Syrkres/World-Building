---
fileType: item
itemType: herb
name: Amrans
locale: Rivers, Rural
climate: Temperate
availability: Spring 40%
abilityCheck: Intelligence -2
uses: {Uses}
value: 50 gp/ 50 gp
preparation: 3 days/ 1 week
---
>#  Amrans
>
> **Locale:** Rivers, Rural
> **Climate:** Temperate
> **Availability:** Spring 40%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 50 gp/ 50 gp
> **Preparation:** 3 days/ 1 week
> **Description:** The lilac flowers can be prepared into a potion that rapidly cures wounds (3d6 if properly prepared (for 1 week), 1d4 if poorly prepared (for 3 days)).
{.5eblock}

