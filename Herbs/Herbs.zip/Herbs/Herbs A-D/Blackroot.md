---
fileType: item
itemType: herb
name: Blackroot
locale: All
climate: Temperate
availability: Summer 30%
abilityCheck: Intelligence -2
uses: {Uses}
value: 4 gp/ 4 gp
preparation: none
---
>#  Blackroot
>
> **Locale:** All
> **Climate:** Temperate
> **Availability:** Summer 30%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 4 gp/ 4 gp
> **Preparation:** none
> **Description:** A tall plant with small, bell-shaped violet flowers and complex roots that are black on the outside and white on the inside. Blackroot's roots can be applied to fresh wounds in order to promote quick healing (applied immediately, gives 1d4 back to character at once).
{.5eblock}

