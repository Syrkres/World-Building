---
fileType: item
itemType: herb
name: Adders_Tongue
locale: Rural
climate: Temperate
availability: Spring 10%
abilityCheck: Intelligence -2
uses: {Uses}
value: 5 gp/ 15 gp
preparation: 3 days
---
>#  Adder's Tongue
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Spring 10%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 5 gp/ 15 gp
> **Preparation:** 3 days
> **Description:** The herb has one leaf which grows from a stalk about three inches from the ground. It's appearance gives it its name. The leaf must be boiled in olive oil and set in the sun for three days. At the end of that time the infusion can be used as a balm for wounds. In the event that the wound is infected the balm will draw out the infection within one day. However for that one day the damage caused by the infection will be twice as severe. If the wound is not infected the balm will increase the rate of healing by 1 hp for that day.
{.5eblock}

