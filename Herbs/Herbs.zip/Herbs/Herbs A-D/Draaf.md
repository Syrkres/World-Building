---
fileType: item
itemType: herb
name: Draaf
locale: Coastal
climate: Subtropical
availability: Spring 60%
abilityCheck: Intelligence -4
uses: {Uses}
value: 5 sp/ 5 sp
preparation: none
---
>#  Draaf
>
> **Locale:** Coastal
> **Climate:** Subtropical
> **Availability:** Spring 60%
> **Ability Check:** Intelligence -4
> **Uses:** 1
> **Value:** 5 sp/ 5 sp
> **Preparation:** none
> **Description:** The leaves of Draaf must be eaten in order to restore 1d3 hit points, as long as they are eaten within 10 minutes of the damage being inflicted.
{.5eblock}

