---
fileType: item
itemType: herb
name: Belan
locale: Coastal
climate: Tropical
availability: Summer 35%
abilityCheck: Intelligence -6
uses: {Uses}
value: 40 gp/ 40 gp
preparation: none
---
>#  Belan
>
> **Locale:** Coastal
> **Climate:** Tropical
> **Availability:** Summer 35%
> **Ability Check:** Intelligence -6
> **Uses:** 3
> **Value:** 40 gp/ 40 gp
> **Preparation:** none
> **Description:** The nut must be eaten to stop bleeding (including internal bleeding). Within two hours it will have stopped the bleeding. The recipient must not move for one additional hour or risk the bleeding restarting.
{.5eblock}

