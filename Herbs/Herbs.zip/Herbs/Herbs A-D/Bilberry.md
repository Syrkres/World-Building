---
fileType: item
itemType: herb
name: Bilberry
locale: Forest
climate: Temperate
availability: Spring 1%
abilityCheck: Intelligence -13
uses: {Uses}
value: 500 gp/ 3000 gp
preparation: 15 days
---
>#  Bilberry
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Spring 1%
> **Ability Check:** Intelligence -13
> **Uses:** 1
> **Value:** 500 gp/ 3000 gp
> **Preparation:** 15 days
> **Description:** Bilberries are small black berries. They must be mixed with pure alcohol and left to stand for fifteen days, at the end of which time they must be drunk. A successful application will give a human the same infravision ability as half elves, but a failed application may lead to the death (save penalty -4) of the person who drinks it, as if they had drunk a class J poison (Death/ 20 hit points, onset 1d4 minutes).
{.5eblock}

