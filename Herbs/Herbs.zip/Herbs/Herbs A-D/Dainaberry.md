---
fileType: item
itemType: herb
name: Dainaberry
locale: Rivers
climate: Temperate
availability: Autumn 20%
abilityCheck: Intelligence -3
uses: {Uses}
value: 2 gp/ 8 gp
preparation: None (or 3 weeks)
---
>#  Dainaberry
>
> **Locale:** Rivers
> **Climate:** Temperate
> **Availability:** Autumn 20%
> **Ability Check:** Intelligence -3
> **Uses:** 3d10
> **Value:** 2 gp/ 8 gp
> **Preparation:** None (or 3 weeks)
> **Description:**
{.5eblock}

