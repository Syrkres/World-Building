---
fileType: item
itemType: herb
name: Arpusar
locale: Rivers
climate: Cold
availability: Autumn 40%
abilityCheck: Intelligence -7
uses: {Uses}
value: 7 gp/ 30 gp
preparation: 1 week
---
>#  Arpusar
>
> **Locale:** Rivers
> **Climate:** Cold
> **Availability:** Autumn 40%
> **Ability Check:** Intelligence -7
> **Uses:** 2
> **Value:** 7 gp/ 30 gp
> **Preparation:** 1 week
> **Description:** The stalks of this plant must be brewed for one week in fresh water at the end of which time it may be drunk. If it is successful, it will heal any damage to a persons muscles that are capable of healing naturally within one day.
{.5eblock}

