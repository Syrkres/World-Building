---
fileType: item
itemType: herb
name: Arkasu
locale: Grassland
climate: Temperate
availability: Autumn 55%
abilityCheck: Intelligence -3
uses: {Uses}
value: 12 gp/ 12 gp
preparation: none
---
>#  Arkasu
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Autumn 55%
> **Ability Check:** Intelligence -3
> **Uses:** 3
> **Value:** 12 gp/ 12 gp
> **Preparation:** none
> **Description:** When the sap of the Arkasu plant is applied to wounds, it doubles the rate of healing. The effect is not cumulative.
{.5eblock}

