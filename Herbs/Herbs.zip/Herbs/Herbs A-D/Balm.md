---
fileType: item
itemType: herb
name: Balm
locale: Forest
climate: Subtropical
availability: Summer 20%
abilityCheck: Intelligence -4
uses: {Uses}
value: 3 gp/ 5 gp
preparation: 1 hour
---
>#  Balm
>
> **Locale:** Forest
> **Climate:** Subtropical
> **Availability:** Summer 20%
> **Ability Check:** Intelligence -4
> **Uses:** 4
> **Value:** 3 gp/ 5 gp
> **Preparation:** 1 hour
> **Description:** Balm is a plant about 2 to 3 feet tall with squarish stems. It has oval, serrated leaves. It has small flowers which can be any shade from white to blue, which form small clusters at the base of the leaves. The herb should be boiled and given to women suffering menstrual pains (hey, someone has gone to the trouble of writing "A Guide to AD&D Sex" so this might be useful!) It also reputedly has properties of bestowing longevity, and so could be used as an ingredient in "Potions of Longevity" and the like.
{.5eblock}

