---
fileType: item
itemType: herb
name: Cow_Parsnip
locale: Forest
climate: Temperate
availability: Always 45%
abilityCheck: Intelligence -6
uses: {Uses}
value: 3 gp/ 10 gp
preparation: 6 weeks
---
>#  Cow Parsnip
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Always 45%
> **Ability Check:** Intelligence -6
> **Uses:** 7
> **Value:** 3 gp/ 10 gp
> **Preparation:** 6 weeks
> **Description:** Cow parsnip has small leaves covered with tiny hairs. These hairs must be made into a salve. Cow parsnip will cure madness for a short period (a few hours). Repeated application over a two week period may (GMs discretion) cure insanity altogether.
{.5eblock}

