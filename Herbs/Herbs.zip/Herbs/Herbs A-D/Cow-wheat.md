---
fileType: item
itemType: herb
name: Cow-wheat
locale: Grassland
climate: Temperate
availability: Summer 50%
abilityCheck: Intelligence
uses: {Uses}
value: 2 gp/ 3 gp
preparation: 1 week
---
>#  Cow-wheat
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Summer 50%
> **Ability Check:** Intelligence
> **Uses:** 2
> **Value:** 2 gp/ 3 gp
> **Preparation:** 1 week
> **Description:** Cow wheat is a small straight stemmed yellow-green plant. Its pale yellow flowers produce a white powder when crushed, between two hands. If this powder is placed into food or drink it will cause a person to act as if drunk. For those who desire game mechanics to deal with drunkenness, please consult the Intoxication Table in the 1st Edition AD&D DMG, page 82. Each dose of this herb successfully administered will increase the level of drunkenness by one step.
{.5eblock}

