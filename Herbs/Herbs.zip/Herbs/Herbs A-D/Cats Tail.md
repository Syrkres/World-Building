---
fileType: item
itemType: herb
name: Cats_Tail
locale: Forest
climate: Temperate
availability: Summer 75%
abilityCheck: Intelligence -6
uses: {Uses}
value: 1 gp/ 3 gp
preparation: 1 week
---
>#  Cat's Tail
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Summer 75%
> **Ability Check:** Intelligence -6
> **Uses:** 1
> **Value:** 1 gp/ 3 gp
> **Preparation:** 1 week
> **Description:** Cat's tail is a small plant with long thin spear shaped leaves rising from its base, and a single long, thin, soft flower at the top of the stalk. This herb when made into a salve, will heal all damage to a person's heel.
{.5eblock}

