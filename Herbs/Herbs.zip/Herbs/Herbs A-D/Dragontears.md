---
fileType: item
itemType: herb
name: Dragontears
locale: Desert
climate: Temperate
availability: Spring 10%
abilityCheck: Intelligence -2
uses: {Uses}
value: 100 gp/ 100 gp
preparation: 2 weeks
---
>#  Dragontears
>
> **Locale:** Desert
> **Climate:** Temperate
> **Availability:** Spring 10%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 100 gp/ 100 gp
> **Preparation:** 2 weeks
> **Description:** This rare, small, translucent succulent grows primarily in the low desert. When crushed, it exudes a sweet, milky white substance with numbing properties. Properly prepared, dragontears promotes rapid healing and prevents scarring from wounds. Drinking dragontears can be fatal, as its numbing properties can cause choking or heart failure. (Cures 1d8 hp, always prevents scarring.)
{.5eblock}

