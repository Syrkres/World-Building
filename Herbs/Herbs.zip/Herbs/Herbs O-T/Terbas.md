---
fileType: item
itemType: herb
name: Terbas
locale: Forest
climate: Temperate
availability: Spring 75%
abilityCheck: Intelligence -5
uses: {Uses}
value: 2 gp/ 2 gp
preparation: none
---
>#  Terbas
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Spring 75%
> **Ability Check:** Intelligence -5
> **Uses:** 1
> **Value:** 2 gp/ 2 gp
> **Preparation:** none
> **Description:** The leaf of this plant must be applied to the site of nerve damage. If successful, the rate of healing for such damage will be doubled on each day of use.
{.5eblock}

