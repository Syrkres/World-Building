---
fileType: item
itemType: herb
name: Scented_Mayweed
locale: Forest
climate: Temperate
availability: Summer 40%
abilityCheck: Intelligence -3
uses: {Uses}
value: 8 gp/ 15 gp
preparation: 1 day
---
>#  Scented Mayweed
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Summer 40%
> **Ability Check:** Intelligence -3
> **Uses:** 1
> **Value:** 8 gp/ 15 gp
> **Preparation:** 1 day
> **Description:** Scented mayweed grows to a height of about 2 feet. It has erect and branching stems. It has small leaves, white flowers with a yellow centre. The flowers must be crushed, emitting a pungent odour and should then be applied to the eyes in order to heal damage to them caused by acid. If used within a day of the injury, they can prevent blindness.
{.5eblock}

