---
fileType: item
itemType: herb
name: Pallast_(compound)
locale: Swamp
climate: Temperate
availability: Summer 30%
abilityCheck: Intelligence -2
uses: {Uses}
value: 5 sp/ 1 gp
preparation: 2 hours
---
>#  Pallast (compound)
>
> **Locale:** Swamp
> **Climate:** Temperate
> **Availability:** Summer 30%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 5 sp/ 1 gp
> **Preparation:** 2 hours
> **Description:** "Pallast" is a compound made of the pale, papery bark from willows and the roots of marshmallows. When ground together and imbibed, pallast cures minor aches and pains, especially headaches and pain from abscessed teeth, sore muscles, and so forth. Pallast itself is a very bitter pale powder, and is usually served in a heavily sweetened tea. (Relieves minor pains but does not restore lost hit points.)
{.5eblock}

