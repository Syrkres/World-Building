---
fileType: item
itemType: herb
name: Spiderwort
locale: Special (see below)
climate: Temperate
availability: Spring, Summer 50%
abilityCheck: Intelligence
uses: {Uses}
value: 4 gp/ 10 gp
preparation: 2 weeks
---
>#  Spiderwort
>
> **Locale:** Special (see below)
> **Climate:** Temperate
> **Availability:** Spring, Summer 50%
> **Ability Check:** Intelligence
> **Uses:** 3
> **Value:** 4 gp/ 10 gp
> **Preparation:** 2 weeks
> **Description:** This herb will cure spider poison if applied within 2 rounds. Any damage already incurred, including death remains. This plant may be found anywhere in temperate regions where there is chalky soil.
{.5eblock}

