---
fileType: item
itemType: herb
name: Oiolosse
locale: Elven Forest
climate: Polar
availability: Winter 1%
abilityCheck: Intelligence -10
uses: {Uses}
value: 1200 gp/ 1200 gp
preparation: none
---
>#  Oiolosse
>
> **Locale:** Elven Forest
> **Climate:** Polar
> **Availability:** Winter 1%
> **Ability Check:** Intelligence -10
> **Uses:** 1
> **Value:** 1200 gp/ 1200 gp
> **Preparation:** none
> **Description:** This herb will restore an Elf to life if given within seven days of death.
{.5eblock}

