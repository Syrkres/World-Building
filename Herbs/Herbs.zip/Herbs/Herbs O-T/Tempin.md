---
fileType: item
itemType: herb
name: Tempin
locale: Forest
climate: Temperate
availability: Summer 20%
abilityCheck: Intelligence -2
uses: {Uses}
value: 5 gp/ 5 gp
preparation: none
---
>#  Tempin
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Summer 20%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 5 gp/ 5 gp
> **Preparation:** none
> **Description:** A bushy climbing vine with tubular yellow flowers, the leaves and flowers of tempin can be boiled and made into a poultice that will draw out poisons from bites and stings and allow the wound to heal cleanly and without complications. (When poultice is applied promptly, gives an additional +2 save vs. poison, once on any particular poison attack. Also gives back 1 extra hp/day for the first 2 days after poultice is applied.)
{.5eblock}

