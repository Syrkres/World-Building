---
fileType: item
itemType: herb
name: Orach
locale: Forest
climate: Temperate
availability: Summer 45%
abilityCheck: Intelligence -2
uses: {Uses}
value: 2 gp/ 10 gp
preparation: 6 weeks
---
>#  Orach
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Summer 45%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 2 gp/ 10 gp
> **Preparation:** 6 weeks
> **Description:** Orach grows to about 3 or 4 feet in height. It has a whitish stalk, pale green leaves and greenish-white flowers. The seeds must be gathered, bruised and left to stand in pure alcohol for six weeks. The mixture must then be drunk, one spoonful a day for a week. The herb will cure yellow jaundice. It leaves a yellow colour in the skin.
{.5eblock}

