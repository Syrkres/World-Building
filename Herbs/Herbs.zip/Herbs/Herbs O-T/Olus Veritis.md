---
fileType: item
itemType: herb
name: Olus_Veritis
locale: Rivers
climate: Temperate, Cold
availability: Winter 15%
abilityCheck: Intelligence -2
uses: {Uses}
value: 5 gp/ 10 gp
preparation: 1 hour
---
>#  Olus Veritis
>
> **Locale:** Rivers
> **Climate:** Temperate, Cold
> **Availability:** Winter 15%
> **Ability Check:** Intelligence -2
> **Uses:** 4
> **Value:** 5 gp/ 10 gp
> **Preparation:** 1 hour
> **Description:** Olus veritis is pale green in colour and grows right on the edge of rivers. The leaves are rough in texture, and have tiny thorns all along their edges. A leaf should be baked in an oven for one hour and then dragged across the skin of the recipient, cutting their flesh very slightly. The recipient, must save vs poison or be compelled to answer all questions, absolutely truthfully for the next 1d6 x 10 minutes. Up to three uses of the herb can be made in a 24 hour period. If any more than this are made the recipient will die within 3 hours of the third dose, or instantly if five or more doses are administered.
{.5eblock}

