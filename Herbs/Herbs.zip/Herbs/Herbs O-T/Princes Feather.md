---
fileType: item
itemType: herb
name: Princes_Feather
locale: Rural
climate: Temperate
availability: Summer, Autumn 45%
abilityCheck: Intelligence -6
uses: {Uses}
value: 1 gp/ 2 gp
preparation: 1 hour
---
>#  Prince's Feather
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Summer, Autumn 45%
> **Ability Check:** Intelligence -6
> **Uses:** 1
> **Value:** 1 gp/ 2 gp
> **Preparation:** 1 hour
> **Description:** This herb has red-green leaves and long pink flowers. The flowers must be beaten into powder and eaten by the recipient. If successful, the herb will halve the rate of internal bleeding within 1 turn.
{.5eblock}

