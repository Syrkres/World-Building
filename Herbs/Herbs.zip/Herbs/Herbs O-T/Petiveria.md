---
fileType: item
itemType: herb
name: Petiveria
locale: Rural
climate: Subtropical, Tropical
availability: Summer 20%
abilityCheck: Intelligence -3
uses: {Uses}
value: 1 gp/ 3 gp
preparation: 1 day
---
>#  Petiveria
>
> **Locale:** Rural
> **Climate:** Subtropical, Tropical
> **Availability:** Summer 20%
> **Ability Check:** Intelligence -3
> **Uses:** 1
> **Value:** 1 gp/ 3 gp
> **Preparation:** 1 day
> **Description:** This plant has a single stem with dark green, shiny leaves growing from it. It is topped by very thin, yellow flowers. The petals of these flowers should be tied into a poultice, where they will, on a successful application act to bring down swelling and bruise over the course of a one day period.
{.5eblock}

