---
fileType: item
itemType: herb
name: Spanish_Nut
locale: Forest
climate: Temperate, Subtropical
availability: Always 80%
abilityCheck: Intelligence -2
uses: {Uses}
value: 10 gp/ 100 gp
preparation: 25 weeks
---
>#  Spanish Nut
>
> **Locale:** Forest
> **Climate:** Temperate, Subtropical
> **Availability:** Always 80%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 10 gp/ 100 gp
> **Preparation:** 25 weeks
> **Description:** This herb is a powerful aphrodisiac. If successfully administered I would suggest that the GM or player roleplays the recipient accordingly. However if a method of using dice to simulate its effect is wanted, I suggest that anyone who attempts to seduce the recipient should have a bonus of 1d4 to their Charisma (Appearance) for a period of 2d10 turns.
{.5eblock}

