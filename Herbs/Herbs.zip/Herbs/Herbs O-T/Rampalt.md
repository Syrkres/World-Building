---
fileType: item
itemType: herb
name: Rampalt
locale: Forest
climate: Temperate
availability: Summer 20%
abilityCheck: Intelligence
uses: {Uses}
value: 5 cp/ 5 cp
preparation: 1 day
---
>#  Rampalt
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Summer 20%
> **Ability Check:** Intelligence
> **Uses:** 1
> **Value:** 5 cp/ 5 cp
> **Preparation:** 1 day
> **Description:** This dark-colored root grows on a plant distinguished by its waxy dark green leaves. When the root is boiled down, it turns into a thick, strong-smelling greyish liquid that cures congestion when boiled in water and inhaled. (Relieves stuffy head, opens sinuses, for as long as the steam is breathed + 2d6x10 rounds.)
{.5eblock}

