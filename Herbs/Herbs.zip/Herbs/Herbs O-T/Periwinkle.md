---
fileType: item
itemType: herb
name: Periwinkle
locale: Rural
climate: Temperate
availability: Spring 45%
abilityCheck: Intelligence -8
uses: {Uses}
value: 1 gp/ 10 gp
preparation: 1 hour
---
>#  Periwinkle
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Spring 45%
> **Ability Check:** Intelligence -8
> **Uses:** 1
> **Value:** 1 gp/ 10 gp
> **Preparation:** 1 hour
> **Description:** The plant is a creeping vine with dark, green shiny leaves and pale blue flowers. The flours must be crushed into a powder and administered orally. If used successfully the herb will stop all bleeding, both internal and external in one turn. The recipient must not move for one hour or risk reopening the wounds.
{.5eblock}

