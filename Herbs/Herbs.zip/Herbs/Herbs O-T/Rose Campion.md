---
fileType: item
itemType: herb
name: Rose_Campion
locale: Forest
climate: Temperate
availability: Summer 80%
abilityCheck: Intelligence -7
uses: {Uses}
value: 1 gp/ 3 gp
preparation: 3 weeks
---
>#  Rose Campion
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Summer 80%
> **Ability Check:** Intelligence -7
> **Uses:** 6
> **Value:** 1 gp/ 3 gp
> **Preparation:** 3 weeks
> **Description:** This herb will protect against scorpion stings for three days. It will protect against only one sting. It will protect against `instant death' venom.
{.5eblock}

