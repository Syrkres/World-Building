---
fileType: item
itemType: herb
name: Sweet_Trefoile
locale: Forest
climate: Temperate
availability: Spring, Summer 60%
abilityCheck: Intelligence -4
uses: {Uses}
value: 1 gp/ 3 gp
preparation: 2 weeks
---
>#  Sweet Trefoile
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Spring, Summer 60%
> **Ability Check:** Intelligence -4
> **Uses:** 6
> **Value:** 1 gp/ 3 gp
> **Preparation:** 2 weeks
> **Description:** This herb will halve falling damage if applied within one turn of the fall.
{.5eblock}

