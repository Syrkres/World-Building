---
fileType: item
itemType: herb
name: Ribwort_Plantain
locale: Urban
climate: Temperate, Subtropical
availability: Spring 30%
abilityCheck: Intelligence -3
uses: {Uses}
value: 1 gp/ 1 gp
preparation: none
---
>#  Ribwort Plantain
>
> **Locale:** Urban
> **Climate:** Temperate, Subtropical
> **Availability:** Spring 30%
> **Ability Check:** Intelligence -3
> **Uses:** 2
> **Value:** 1 gp/ 1 gp
> **Preparation:** none
> **Description:** This plant has a cluster of dark green leaves, with marked parallel veins at its base, a single stem topped by a cluster of tiny, pale orange flowers. The chopped leaves are applied to the flesh to reduce bruising. A successful application will remove slight bruises altogether within an hour, more severe bruises will take 1d4 days.
{.5eblock}

