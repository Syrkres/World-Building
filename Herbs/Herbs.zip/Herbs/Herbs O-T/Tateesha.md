---
fileType: item
itemType: herb
name: Tateesha
locale: Swamp
climate: Subtropical
availability: Always 20%
abilityCheck: Intelligence -5
uses: {Uses}
value: 1 sp/ 1 sp for nuts, 5 gp/ 10gp for silks
preparation: (none for nuts, 1 week for silks)
---
>#  Tateesha
>
> **Locale:** Swamp
> **Climate:** Subtropical
> **Availability:** Always 20%
> **Ability Check:** Intelligence -5
> **Uses:** 2
> **Value:** 1 sp/ 1 sp for nuts, 5 gp/ 10gp for silks
> **Preparation:** (none for nuts, 1 week for silks)
> **Description:** The tateen bush is a low lying shrub with long thin leaves and small brown nuts. These nuts may be chewed to provide a short lived feeling of euphoria, and are mildly addictive. They have the side effect of staining the teeth, making it easy to find a tateen addict. The flowers, called silks bloom only in spring, and if gathered and dried for one week form a powerful narcotic which may be smoked. For 2d10 minutes after smoking the persons insight is increased (+1 to Intelligence), but for 1d4 hours after this, a state of distortion ensues and the recipient Intelligence and Wisdom drop by 2 from their normal levels. Prolonged use causes the user to collapse into an almost dreamlike trance. THIS HERB IS HIGHLY ADDICTIVE. REPEATED USE IS VERY UNWISE.
{.5eblock}

