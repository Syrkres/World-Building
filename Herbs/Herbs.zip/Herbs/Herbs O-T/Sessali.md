---
fileType: item
itemType: herb
name: Sessali
locale: Coastal
climate: Subtropical
availability: Autumn, Spring, Summer 10%
abilityCheck: Intelligence -3
uses: {Uses}
value: 1 gp/ 4 gp
preparation: 2 hours
---
>#  Sessali
>
> **Locale:** Coastal
> **Climate:** Subtropical
> **Availability:** Autumn, Spring, Summer 10%
> **Ability Check:** Intelligence -3
> **Uses:** 7
> **Value:** 1 gp/ 4 gp
> **Preparation:** 2 hours
> **Description:** A rugged thorny plant found by the sea. The leaves must be boiled for two hours in salt water, and the resultant mix sweetened with honey. This mixture will act as a cure for certain types of ingested poisons (GMs discretion, as to which ones). The recipient must be made to drink one dose immediately the mixture is ready, and then a further dose every twelve hours for three days (7 doses in all). If the number of successful applications is four or more, the patient will recover.
{.5eblock}

