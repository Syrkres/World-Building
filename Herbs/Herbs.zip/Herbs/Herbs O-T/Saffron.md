---
fileType: item
itemType: herb
name: Saffron
locale: Forest
climate: Temperate
availability: Autumn, Winter 60%
abilityCheck: Intelligence
uses: {Uses}
value: 20 gp/ 100 gp
preparation: 1 week
---
>#  Saffron
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Autumn, Winter 60%
> **Ability Check:** Intelligence
> **Uses:** 2
> **Value:** 20 gp/ 100 gp
> **Preparation:** 1 week
> **Description:**
{.5eblock}

