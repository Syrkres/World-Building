---
fileType: item
itemType: herb
name: Pargen
locale: Jungle
climate: Tropical
availability: Summer 1%
abilityCheck: Intelligence -15
uses: {Uses}
value: 2000 gp/ 2000 gp
preparation: none
---
>#  Pargen
>
> **Locale:** Jungle
> **Climate:** Tropical
> **Availability:** Summer 1%
> **Ability Check:** Intelligence -15
> **Uses:** 1
> **Value:** 2000 gp/ 2000 gp
> **Preparation:** none
> **Description:** A single berry from the Pargen Tree will restore a person to life (-1 point of Constitution) if given within 4 days.
{.5eblock}

