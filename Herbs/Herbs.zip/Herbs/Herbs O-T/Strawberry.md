---
fileType: item
itemType: herb
name: Strawberry
locale: Rural
climate: Temperate
availability: Summer 40%
abilityCheck: Intelligence -12
uses: {Uses}
value: 2 gp/ 2gp
preparation: negligible
---
>#  Strawberry
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Summer 40%
> **Ability Check:** Intelligence -12
> **Uses:** 3
> **Value:** 2 gp/ 2gp
> **Preparation:** negligible
> **Description:** These small red berries grow on very small bushes with pale green rounded leaves. Five berries should be bound into a bandage, which should then be applied to a lepers sores. If the application is successful, that sore will deteriorate no further.
{.5eblock}

