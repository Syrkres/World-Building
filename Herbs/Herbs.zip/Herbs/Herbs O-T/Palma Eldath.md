---
fileType: item
itemType: herb
name: Palma_Eldath
locale: Mountains
climate: Cold, Polar
availability: Always 60%
abilityCheck: Intelligence -3
uses: {Uses}
value: 3 gp/ 3 gp
preparation: none
---
>#  Palma Eldath
>
> **Locale:** Mountains
> **Climate:** Cold, Polar
> **Availability:** Always 60%
> **Ability Check:** Intelligence -3
> **Uses:** 3
> **Value:** 3 gp/ 3 gp
> **Preparation:** none
> **Description:** This herb keeps a person warm for one night or one day, and prevents them suffering from exposure. This can mean the difference between life and death.
{.5eblock}

