---
fileType: item
itemType: herb
name: Thurl
locale: Forest
climate:
availability: Autumn 90%
abilityCheck: Intelligence
uses: {Uses}
value: 1 sp/ 2 sp
preparation: 1 day
---
>#  Thurl
>
> **Locale:** Forest
> **Climate:**
> **Availability:** Autumn 90%
> **Ability Check:** Intelligence
> **Uses:** 4
> **Value:** 1 sp/ 2 sp
> **Preparation:** 1 day
> **Description:** The clove of Thurl must be brewed for one whole day. When the mixture is drunk it will restore 1 hp of damage.
{.5eblock}

