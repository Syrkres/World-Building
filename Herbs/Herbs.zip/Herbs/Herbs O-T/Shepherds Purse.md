---
fileType: item
itemType: herb
name: Shepherds_Purse
locale: Grassland
climate: Temperate
availability: Always 85%
abilityCheck: Intelligence +2
uses: {Uses}
value: 5 gp/ 12 gp
preparation: 1 week
---
>#  Shepherd's Purse
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Always 85%
> **Ability Check:** Intelligence +2
> **Uses:** 4
> **Value:** 5 gp/ 12 gp
> **Preparation:** 1 week
> **Description:** This herb rarely grows to a height of more than one and a half feet. It has small greyish green leaves, growing smaller towards the summit of the plant. It has small four petalled dirty-white flowers at its peak. If applied to wounds it will stop their bleeding for one hour, and temporarily removes the need to bandage.
{.5eblock}

