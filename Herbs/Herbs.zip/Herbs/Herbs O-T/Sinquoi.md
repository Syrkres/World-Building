---
fileType: item
itemType: herb
name: Sinquoi
locale: Rural
climate: Subtropical
availability: Summer 15%
abilityCheck: Intelligence -2
uses: {Uses}
value: 2 gp/ 3 gp
preparation: 1 hour
---
>#  Sinquoi
>
> **Locale:** Rural
> **Climate:** Subtropical
> **Availability:** Summer 15%
> **Ability Check:** Intelligence -2
> **Uses:** 2
> **Value:** 2 gp/ 3 gp
> **Preparation:** 1 hour
> **Description:** The red leaves of this unusually twisted tree should be burned and the smoke inhaled. This will have the effect of `dilating' time (making it appear to pass slower.) For every minute experienced outside the influence of the herb, only thirty seconds will pass. A single dose is effective for 1d6 hours. Normally used by torturers to prolong agony, the leaves may also be used by  people who must think quickly. It does not increase the speed at which a person moves (Under it's influence all movement will seem sluggish), and does not impart any bonuses in combat for this reason, (you may see the blow coming more easily, but you will still be unable to avoid it.)
{.5eblock}

