---
fileType: item
itemType: herb
name: Sanicle
locale: Forest
climate: Temperate
availability: Summer, Autumn, Winter 90%
abilityCheck: Intelligence +2
uses: {Uses}
value: 5 gp/ 30 gp
preparation: 2 weeks
---
>#  Sanicle
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Summer, Autumn, Winter 90%
> **Ability Check:** Intelligence +2
> **Uses:** 4
> **Value:** 5 gp/ 30 gp
> **Preparation:** 2 weeks
> **Description:** Sanicle leaves should be crushed and left in white wine, the strained through a cloth and drunk. It has the effect of binding wounds so that they are not reopened by action. It is a small plant with glossy green leaves, with long leaf stalks which are divided into three or five lobes. It has small white or pink flowers which sit at the top of a slender stalk.
{.5eblock}

