---
fileType: item
itemType: herb
name: Snakespike
locale: Coastal
climate: Temperate
availability: Spring 15%
abilityCheck: Intelligence
uses: {Uses}
value: 5 gp/ 7 gp
preparation: 1 hour/ 3 hours
---
>#  Snakespike
>
> **Locale:** Coastal
> **Climate:** Temperate
> **Availability:** Spring 15%
> **Ability Check:** Intelligence
> **Uses:** 2
> **Value:** 5 gp/ 7 gp
> **Preparation:** 1 hour/ 3 hours
> **Description:** A thin stalk covered with yellow-green flowers. The leaves can be steeped in water to make a tea that, when imbibed 3 times a day, reduces inflammation and restores strength; when made into an ointment, snakespike soothes and promotes rapid healing. (Tea gives 1d3 hp/day instead of 1; ointment restores 1d2 hp immediately per application but can only be administered to the same character once a day.)
{.5eblock}

