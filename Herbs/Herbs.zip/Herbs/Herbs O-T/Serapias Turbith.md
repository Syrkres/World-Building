---
fileType: item
itemType: herb
name: Serapias_Turbith
locale: Grassland
climate: Temperate
availability: Spring, Summer 45%
abilityCheck: Intelligence -5
uses: {Uses}
value: 4 gp/ 7 gp
preparation: 4 weeks
---
>#  Serapias Turbith
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Spring, Summer 45%
> **Ability Check:** Intelligence -5
> **Uses:** 3
> **Value:** 4 gp/ 7 gp
> **Preparation:** 4 weeks
> **Description:** This herb will place the recipient into a deep sleep for one day. The recipient CANNOT be woken. At the end of the day, all wounds will be healed. It does not, of course, resurrect a dead person, or regenerate lost limbs.
{.5eblock}

