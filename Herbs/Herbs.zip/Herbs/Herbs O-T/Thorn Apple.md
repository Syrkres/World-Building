---
fileType: item
itemType: herb
name: Thorn_Apple
locale: Rural
climate: Temperate, Subtropical
availability: Spring, Summer 20%
abilityCheck: Intelligence
uses: {Uses}
value: 1 gp/ 1 gp
preparation: none
---
>#  Thorn Apple
>
> **Locale:** Rural
> **Climate:** Temperate, Subtropical
> **Availability:** Spring, Summer 20%
> **Ability Check:** Intelligence
> **Uses:** 4
> **Value:** 1 gp/ 1 gp
> **Preparation:** none
> **Description:** This is a small ground hugging plant. Its seeds are about a quarter of an inch in diameter, and are covered in small thorns. A single seed is very effective as a minor pain reliever. It will ease small pains, such as headaches or minor muscular pains for 3d4 hours. The pain relief is almost instantaneous.
{.5eblock}

