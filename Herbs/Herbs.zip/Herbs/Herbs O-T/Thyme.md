---
fileType: item
itemType: herb
name: Thyme
locale: Rural
climate: Temperate, Cold
availability: Spring 15%
abilityCheck: Intelligence -9
uses: {Uses}
value: 2 gp/ 5 gp
preparation: 2 weeks
---
>#  Thyme
>
> **Locale:** Rural
> **Climate:** Temperate, Cold
> **Availability:** Spring 15%
> **Ability Check:** Intelligence -9
> **Uses:** 3
> **Value:** 2 gp/ 5 gp
> **Preparation:** 2 weeks
> **Description:** Thyme can grow up to a foot in height. It has tiny dark green leaves, and is an evergreen. In spring it has many sweet scented mauve flowers. The smell is so strong that the herb is often smelt before it is seen. These flowers must be dried and then mixed with fresh, clear water. To produce an antiseptic lotion. This lotion should be applied to infected wounds. A successful application will destroy the infection, although any damage already sustained will remain.
{.5eblock}

