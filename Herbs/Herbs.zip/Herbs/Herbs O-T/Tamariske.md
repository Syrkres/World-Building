---
fileType: item
itemType: herb
name: Tamariske
locale: Rural
climate: Temperate
availability: Always 20%
abilityCheck: Intelligence
uses: {Uses}
value: 5 gp/ 7 gp
preparation: 2 weeks
---
>#  Tamariske
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Always 20%
> **Ability Check:** Intelligence
> **Uses:** 3
> **Value:** 5 gp/ 7 gp
> **Preparation:** 2 weeks
> **Description:** This herb will cleanse wounds, removing all infection. It does not cure lost hit points.
{.5eblock}

