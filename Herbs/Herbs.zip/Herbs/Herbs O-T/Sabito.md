---
fileType: item
itemType: herb
name: Sabito
locale: Coastal
climate: Tropical
availability: Summer 2%
abilityCheck: Intelligence -2
uses: {Uses}
value: 100 gp/ 500 gp
preparation: 1 week
---
>#  Sabito
>
> **Locale:** Coastal
> **Climate:** Tropical
> **Availability:** Summer 2%
> **Ability Check:** Intelligence -2
> **Uses:** 3
> **Value:** 100 gp/ 500 gp
> **Preparation:** 1 week
> **Description:** This plant has leaves which are bluish in tinge, and is found growing in the sands of coastal dunes. The root is dark blue in colour and may be made into small pills. Consuming one of these pills will allow the recipient to breathe underwater for 10 minutes, by allowing them to absorb the oxygen in the water directly into their skin through osmosis. Their skin has a translucent appearance for these ten minutes.
{.5eblock}

