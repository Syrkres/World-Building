---
fileType: item
itemType: herb
name: Tamarindes
locale: Forest
climate: Tropical
availability: Always 85%
abilityCheck: Intelligence
uses: {Uses}
value: 1 gp/ 2 gp
preparation: 4 weeks
---
>#  Tamarindes
>
> **Locale:** Forest
> **Climate:** Tropical
> **Availability:** Always 85%
> **Ability Check:** Intelligence
> **Uses:** 7
> **Value:** 1 gp/ 2 gp
> **Preparation:** 4 weeks
> **Description:** This herb will quench the thirst. However it does not replace the water in their system. A person can still die of thirst, they just won't feel thirsty. Because of this fact, its use can be dangerous.
{.5eblock}

