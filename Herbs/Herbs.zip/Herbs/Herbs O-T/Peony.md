---
fileType: item
itemType: herb
name: Peony
locale: Rural
climate: Temperate
availability: Spring 5%
abilityCheck: Intelligence -2
uses: {Uses}
value: 1 gp/ 2 gp
preparation: 1 hour
---
>#  Peony
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Spring 5%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 1 gp/ 2 gp
> **Preparation:** 1 hour
> **Description:** This plant with its delicate pink flowers may be boiled into a powerful healing draught, capable of stoping all bleeding, internal and external immediately. However a roll of 1 on the Herbalism check by the herbalist, will kill the recipient in 1d4 minutes, as they suffer a massive heart attack. The herb can be deliberately used as a poison by using five times the normal dosage.
{.5eblock}

