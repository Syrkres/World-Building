---
fileType: item
itemType: herb
name: Saracens_Confound
locale: Rural
climate: Temperate
availability: Summer 80%
abilityCheck: Intelligence +3
uses: {Uses}
value: 1 gp/ 20 gp
preparation: 11 weeks
---
>#  Saracen's Confound
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Summer 80%
> **Ability Check:** Intelligence +3
> **Uses:** 4
> **Value:** 1 gp/ 20 gp
> **Preparation:** 11 weeks
> **Description:** This herb cures fevers within 1d4-1 turns.
{.5eblock}

