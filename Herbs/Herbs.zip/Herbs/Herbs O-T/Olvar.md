---
fileType: item
itemType: herb
name: Olvar
locale: Coastal
climate: Polar
availability: Winter 30%
abilityCheck: Intelligence -8
uses: {Uses}
value: 300 gp/ 300 gp
preparation: none
---
>#  Olvar
>
> **Locale:** Coastal
> **Climate:** Polar
> **Availability:** Winter 30%
> **Ability Check:** Intelligence -8
> **Uses:** 1
> **Value:** 300 gp/ 300 gp
> **Preparation:** none
> **Description:** The flower of the Olvar bush must be given to a person on the point of death (at -10 hp, and not losing any more). It will then keep them alive for 2d10 days.
{.5eblock}

