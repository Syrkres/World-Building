---
fileType: item
itemType: herb
name: Pennyroyal
locale: Rural, Urban
climate: Temperate
availability: Spring 25%
abilityCheck: Intelligence -4
uses: {Uses}
value: 3 gp/ 3 gp
preparation: none
---
>#  Pennyroyal
>
> **Locale:** Rural, Urban
> **Climate:** Temperate
> **Availability:** Spring 25%
> **Ability Check:** Intelligence -4
> **Uses:** 1
> **Value:** 3 gp/ 3 gp
> **Preparation:** none
> **Description:** Pennyroyal is a low creeping herb with a squarish stem and small dark green leaves which grow in pairs. The flowers grow in round clusters which are mauve in hue. The leaves should be plucked and while fresh be thrown into a persons bath water. They may then have an aphrodisiac effect on anyone the recipient attempts to influence in the next 1d4 days (assume that 1 is added to the recipients Charisma for this period). In addition, if dried (takes two weeks), the leaves may be sprinkled among books, and will then act as an insect repellent. These make the leaves highly prized among mages and sages who will normally pay 12 gp for the dried leaves.
{.5eblock}

