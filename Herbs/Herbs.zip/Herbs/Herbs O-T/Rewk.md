---
fileType: item
itemType: herb
name: Rewk
locale: Rural
climate: Temperate
availability: Autumn 60%
abilityCheck: Intelligence -7
uses: {Uses}
value: 9 sp/ 1 gp
preparation: 1 day
---
>#  Rewk
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Autumn 60%
> **Ability Check:** Intelligence -7
> **Uses:** 4
> **Value:** 9 sp/ 1 gp
> **Preparation:** 1 day
> **Description:** The nodules of the stem of Rewk must be brewed in clear water for one whole day before drinking. It will then cure 1d3 points of damage.
{.5eblock}

