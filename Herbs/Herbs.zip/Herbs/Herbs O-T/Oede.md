---
fileType: item
itemType: herb
name: Oede
locale: Rural
climate: Temperate
availability: Spring 1%
abilityCheck: ?
uses: {Uses}
value: 1000 gp/ 10000 gp
preparation: 2 weeks (to dry)
---
>#  Oede
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Spring 1%
> **Ability Check:** ?
> **Uses:** 1
> **Value:** 1000 gp/ 10000 gp
> **Preparation:** 2 weeks (to dry)
> **Description:** One of the most valuable and prized of all plants, this bush has laves that are almost golden in colour. These leaves can be dried, but if they are not will last only two weeks. This means the drying process must be begun within an hour of the leaves being picked. These leaves can according to legend cure any disease. Whether or not the leaves have this power is up to the individual GM.
{.5eblock}

