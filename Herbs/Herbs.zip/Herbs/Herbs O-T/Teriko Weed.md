---
fileType: item
itemType: herb
name: Teriko_Weed
locale: Rural
climate: Subtropical
availability: Spring, Summer 5%
abilityCheck: Intelligence -3
uses: {Uses}
value: 2 gp/ 3 gp
preparation: 1 hour
---
>#  Teriko Weed
>
> **Locale:** Rural
> **Climate:** Subtropical
> **Availability:** Spring, Summer 5%
> **Ability Check:** Intelligence -3
> **Uses:** 3
> **Value:** 2 gp/ 3 gp
> **Preparation:** 1 hour
> **Description:** This small dark green weed is prized as a contraceptive. It must be boiled for one hour into an elixir, and drunk by the woman. A successful application will prevent 98% of pregnancies for a period of 1d3+1 weeks.
{.5eblock}

