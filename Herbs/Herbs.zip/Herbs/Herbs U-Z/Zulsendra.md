---
fileType: item
itemType: herb
name: Zulsendra
locale: Underworld
climate: Tropical
availability: Summer 30%
abilityCheck: Intelligence
uses: {Uses}
value: 70 gp/ 70 gp
preparation: none
---
>#  Zulsendra
>
> **Locale:** Underworld
> **Climate:** Tropical
> **Availability:** Summer 30%
> **Ability Check:** Intelligence
> **Uses:** 2
> **Value:** 70 gp/ 70 gp
> **Preparation:** none
> **Description:** When this mushroom is eaten, it doubles a persons rate of movement, and rate of attack for three rounds. At the end of that time the person must save versus poison or collapse in exhaustion for 1d6 turns.
{.5eblock}

