---
fileType: item
itemType: herb
name: Wolfsbane_(wholesome)
locale: Rural
climate: Temperate
availability: Summer 25%
abilityCheck: Intelligence - 7
uses: {Uses}
value: 5 gp/ 10 gp
preparation: 1 day
---
>#  Wolfsbane (wholesome)
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Summer 25%
> **Ability Check:** Intelligence - 7
> **Uses:** 2
> **Value:** 5 gp/ 10 gp
> **Preparation:** 1 day
> **Description:** This is a small plant, about 1 foot tall with pale, divided green leaves and hooded yellow flowers. The stem if rather hairy. The root must be boiled in water and then applied to a bite from a venomous creature within 5 rounds of the bite. If used successfully, the damage caused by the venom will be reduced by half.
{.5eblock}

