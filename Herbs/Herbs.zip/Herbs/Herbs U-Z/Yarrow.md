---
fileType: item
itemType: herb
name: Yarrow
locale: Rural
climate: Temperate
availability: Summer 30%
abilityCheck: Intelligence
uses: {Uses}
value: 10 gp/ 10 gp
preparation: none
---
>#  Yarrow
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Summer 30%
> **Ability Check:** Intelligence
> **Uses:** 3
> **Value:** 10 gp/ 10 gp
> **Preparation:** none
> **Description:** The small white flowers of this herb, which cluster at the top of its one to two feet tall straight stem, should be crushed and applied to wounds. If successfully used it will stop minor bleeding, and reduce major bleeding to the minor level. A second application can then be used to stop the minor bleeding. According to legend Achilles used yarrow to treat wounded Greek troops during the Trojan War.
{.5eblock}

