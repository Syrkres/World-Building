---
fileType: item
itemType: herb
name: Woodrose
locale: Rivers
climate: Temperate
availability: Summer 60%
abilityCheck: Intelligence
uses: {Uses}
value: 1 gp/ 1 gp
preparation: none
---
>#  Woodrose
>
> **Locale:** Rivers
> **Climate:** Temperate
> **Availability:** Summer 60%
> **Ability Check:** Intelligence
> **Uses:** 3
> **Value:** 1 gp/ 1 gp
> **Preparation:** none
> **Description:** If drunk in wine, this herb cause people to become very merry. Anyone who wishes to resist its effect can do so, if they save vs poison (+2 bonus).
{.5eblock}

