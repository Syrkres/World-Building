---
fileType: item
itemType: herb
name: Vinuk
locale: Grassland
climate: Temperate
availability: Summer 30%
abilityCheck: Intelligence
uses: {Uses}
value: 8 sp/ 8 sp
preparation: 1 hour
---
>#  Vinuk
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Summer 30%
> **Ability Check:** Intelligence
> **Uses:** 1
> **Value:** 8 sp/ 8 sp
> **Preparation:** 1 hour
> **Description:** If this herb is given to an unconscious person, it will immediately awaken the person. It will only wake up a person who is unconscious due to alcohol or fainting etc, not that caused by physical damage. And just because the person is conscious does not mean that they are coherent.
{.5eblock}

