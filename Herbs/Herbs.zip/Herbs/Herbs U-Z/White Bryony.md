---
fileType: item
itemType: herb
name: White_Bryony
locale: Forest
climate: Temperate
availability: Autumn 30%
abilityCheck: Intelligence -5
uses: {Uses}
value: 1 gp/ 2 gp
preparation: 1 hour
---
>#  White Bryony
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Autumn 30%
> **Ability Check:** Intelligence -5
> **Uses:** 1
> **Value:** 1 gp/ 2 gp
> **Preparation:** 1 hour
> **Description:** This climbing vine has greenish white star shaped flowers, each bearing five petals, and has green berries which turn red when ripe. It has a root, something like a huge turnip, and this root should be ground up and boiled in water and drunk as a cure for pneumonia.
{.5eblock}

