---
fileType: item
itemType: herb
name: Young_Lads_Love
locale: Forest
climate: Temperate, Subtropical
availability: Summer, Autumn 30%
abilityCheck: Intelligence -5
uses: {Uses}
value: 1 gp/ 1 gp
preparation: None
---
>#  Young Lad's Love
>
> **Locale:** Forest
> **Climate:** Temperate, Subtropical
> **Availability:** Summer, Autumn 30%
> **Ability Check:** Intelligence -5
> **Uses:** 5
> **Value:** 1 gp/ 1 gp
> **Preparation:** None
> **Description:** Young lad's love is a 3 to five foot tall shrub with many branches that resemble small trees. It has small yellow- white flowers, and green feathery leaves, which smell of lemon. These leaves turn a rich orange-brown in late autumn. The flowers should be crushed and placed into a poultice, to be used. A successful application will cure one small area of frostbite, such as a foot or hand, in 2d8 hours.
{.5eblock}

