---
fileType: item
itemType: herb
name: Wood_Sorrel
locale: Desert
climate: Tropical
availability: Summer, Autumn 80%
abilityCheck: Intelligence
uses: {Uses}
value: 2 gp/ 4 gp
preparation: 2 weeks
---
>#  Wood Sorrel
>
> **Locale:** Desert
> **Climate:** Tropical
> **Availability:** Summer, Autumn 80%
> **Ability Check:** Intelligence
> **Uses:** 2
> **Value:** 2 gp/ 4 gp
> **Preparation:** 2 weeks
> **Description:** This is a small plant with leaves in three parts, like a shamrock. The flowers are bell shaped and are white with a dash of blue. The leaves must be crushed and dried for two weeks before use. This herb keeps people cool. It is obviously invaluable in desert regions. It doubles the persons ability to endure heat effects, but does not counteract dehydration, etc.
{.5eblock}

