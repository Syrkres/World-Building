---
fileType: item
itemType: herb
name: Yaran
locale: Grassland
climate: Temperate
availability: Autumn 80%
abilityCheck: Intelligence
uses: {Uses}
value: 8 sp/ 8 sp
preparation: none
---
>#  Yaran
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Autumn 80%
> **Ability Check:** Intelligence
> **Uses:** 2
> **Value:** 8 sp/ 8 sp
> **Preparation:** none
> **Description:** The pollen of this flower must be inhaled. A successful roll means that a persons sense of smell and of taste are doubled for one hour. The herb must still be growing or have been cut in the last 10 minutes.
{.5eblock}

