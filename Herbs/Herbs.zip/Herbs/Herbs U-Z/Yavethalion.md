---
fileType: item
itemType: herb
name: Yavethalion
locale: Coastal
climate: Temperate
availability: Autumn 40%
abilityCheck: Intelligence
uses: {Uses}
value: 45 gp/ 45 gp
preparation: none
---
>#  Yavethalion
>
> **Locale:** Coastal
> **Climate:** Temperate
> **Availability:** Autumn 40%
> **Ability Check:** Intelligence
> **Uses:** 1
> **Value:** 45 gp/ 45 gp
> **Preparation:** none
> **Description:** When the fruit is eaten, it will restore 1d3 hp to the recipient. Yavethalion keeps for only two weeks.
{.5eblock}

