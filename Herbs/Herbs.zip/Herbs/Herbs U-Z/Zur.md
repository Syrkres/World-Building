---
fileType: item
itemType: herb
name: Zur
locale: Underworld
climate: Cold
availability: Winter 60%
abilityCheck: Intelligence
uses: {Uses}
value: 12 gp/  50 gp
preparation: 6 hours
---
>#  Zur
>
> **Locale:** Underworld
> **Climate:** Cold
> **Availability:** Winter 60%
> **Ability Check:** Intelligence
> **Uses:** 2
> **Value:** 12 gp/  50 gp
> **Preparation:** 6 hours
> **Description:** This fungus must be brewed for six hours. A successful roll means that a persons senses of smell and of hearing are doubled for one hour.
{.5eblock}
