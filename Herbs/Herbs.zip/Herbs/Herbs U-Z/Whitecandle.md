---
fileType: item
itemType: herb
name: Whitecandle
locale: Forest
climate: Temperate, Subtropical
availability: Autumn 30%
abilityCheck: Intelligence -2
uses: {Uses}
value: 5 gp/ 5 gp
preparation: 1 hour
---
>#  Whitecandle
>
> **Locale:** Forest
> **Climate:** Temperate, Subtropical
> **Availability:** Autumn 30%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 5 gp/ 5 gp
> **Preparation:** 1 hour
> **Description:** A tall, flowered plant with silvery-green leaves. When the flowers are mixed with water or wine and applied directly to a wound, they act as a painkiller. (Restores 1d4 immediately, but these points are lost as the effect wears off in 2 hours  Further applications before the previous one has worn off are ineffective.)
{.5eblock}

