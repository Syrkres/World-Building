---
fileType: item
itemType: herb
name: Willow-herb
locale: Forest
climate: Temperate
availability: Summer 60%
abilityCheck: Intelligence -2
uses: {Uses}
value: 5 gp/ 5 gp
preparation: none
---
>#  Willow-herb
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Summer 60%
> **Ability Check:** Intelligence -2
> **Uses:** 4
> **Value:** 5 gp/ 5 gp
> **Preparation:** none
> **Description:** The plant grows to about three feet in height. It has long hairy leaves and large purplish-pink flowers. The smoke of this herb will keep away snakes. One dose burns for about five minutes.
{.5eblock}

