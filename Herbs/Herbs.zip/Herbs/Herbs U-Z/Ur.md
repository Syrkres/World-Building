---
fileType: item
itemType: herb
name: Ur
locale: Grassland
climate: Temperate
availability: Winter 70%
abilityCheck: Intelligence
uses: {Uses}
value: 3 gp/ 3 gp
preparation: none
---
>#  Ur
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Winter 70%
> **Ability Check:** Intelligence
> **Uses:** 4
> **Value:** 3 gp/ 3 gp
> **Preparation:** none
> **Description:** Ur can be used as a substitute for one days food. It cannot be used for more than three days or a character will begin to suffer -2 to all statistics. When any statistic is less than 3 the character become comatose, when any statistic reaches 0 they die. A character will regain 1 statistic point per day with food and medical care, but will remain incapacitated until all statistics reach normal levels.
{.5eblock}

