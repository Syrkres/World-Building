---
fileType: item
itemType: herb
name: Wolfsbane
locale: Hills
climate: Temperate
availability: Summer, Autumn 10%
abilityCheck: Intelligence
uses: {Uses}
value: 20 gp each/ 40 gp for
preparation: None (2 days for pills)
---
>#  Wolfsbane
>
> **Locale:** Hills
> **Climate:** Temperate
> **Availability:** Summer, Autumn 10%
> **Ability Check:** Intelligence
> **Uses:** 3
> **Value:** 20 gp each/ 40 gp for
> **Preparation:** None (2 days for pills)
> **Description:** This small (15 cm) plant has black green leaves, sawed deeply several times, and three flower stalks with tiny white flowers and brown seed pods. The seeds are fine as dust, and are therefore usually worked into pills, although, in a pinch, it is possible to simply pluck a stalk and eat it whole. In both cases, the seeds have the effect of granting a +2 on a saving throw vs poison to avoid lycanthropy. The protection lasts for 2d4 x 10 minutes.
{.5eblock}

