---
fileType: item
itemType: herb
name: Winclamit
locale: Forest
climate: Temperate
availability: Spring 1%
abilityCheck: Intelligence
uses: {Uses}
value: 100 gp/ 100 gp
preparation: none
---
>#  Winclamit
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Spring 1%
> **Ability Check:** Intelligence
> **Uses:** 1
> **Value:** 100 gp/ 100 gp
> **Preparation:** none
> **Description:** Each Winclamit tree bears but one fruit per year. When this fruit is eaten it will restore 1d100 hp to the recipient. The fruit can be stored for up to 2 months in a dry sealed container.
{.5eblock}

