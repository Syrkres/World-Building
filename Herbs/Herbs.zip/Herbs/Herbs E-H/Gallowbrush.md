---
fileType: item
itemType: herb
name: Gallowbrush
locale: Rural
climate: Temperate
availability: Winter 5%
abilityCheck: Intelligence -3
uses: {Uses}
value: 10 gp/ 50 gp (for potion)
preparation: 1 day (for potion)
---
>#  Gallowbrush
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Winter 5%
> **Ability Check:** Intelligence -3
> **Uses:** 1
> **Value:** 10 gp/ 50 gp (for potion)
> **Preparation:** 1 day (for potion)
> **Description:** This briar is red in colour with bright crimson thorns. Any mammal pricked with these thorns must make a save vs poison with a +1 bonus or fall asleep for 1d4+2 x 10 minutes. Even if they save the victim still feels drowsy. The thorns can also be brewed into a drink when mixed with water. Anyone drinking this must save vs. poison with a -4 penalty or fall asleep for 1d6 hours.
{.5eblock}

