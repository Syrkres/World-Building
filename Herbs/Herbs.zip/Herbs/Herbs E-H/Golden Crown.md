---
fileType: item
itemType: herb
name: Golden_Crown
locale: Rural
climate: Subtropical
availability: Spring 10%
abilityCheck: Intelligence -3
uses: {Uses}
value: 1 gp/ 2 gp
preparation: 1 hour
---
>#  Golden Crown
>
> **Locale:** Rural
> **Climate:** Subtropical
> **Availability:** Spring 10%
> **Ability Check:** Intelligence -3
> **Uses:** 2
> **Value:** 1 gp/ 2 gp
> **Preparation:** 1 hour
> **Description:** The golden flowers of this small yellow-green plant may be made into a poultice that is used to stop bleeding. One successful application will normally stop minor bleeding, or staunch the flow of major bleeding until it only minor (a second application will stop the bleeding altogether). This herb is often used by midwives to staunch the flow of vaginal bleeding after birth.
{.5eblock}

