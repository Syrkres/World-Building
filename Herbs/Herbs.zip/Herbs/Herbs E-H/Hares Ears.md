---
fileType: item
itemType: herb
name: Hares_Ears
locale: Mountains
climate: Temperate
availability: Summer 55%
abilityCheck: Intelligence -6
uses: {Uses}
value: 2 gp/ 5 gp
preparation: 2 weeks
---
>#  Hare's Ears
>
> **Locale:** Mountains
> **Climate:** Temperate
> **Availability:** Summer 55%
> **Ability Check:** Intelligence -6
> **Uses:** 3
> **Value:** 2 gp/ 5 gp
> **Preparation:** 2 weeks
> **Description:** This herb cures skin diseases.
{.5eblock}

