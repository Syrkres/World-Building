---
fileType: item
itemType: herb
name: Gefnul
locale: Volcanoes
climate: Polar
availability: Summer 60%
abilityCheck: Intelligence -6
uses: {Uses}
value: 200 gp/ 500 gp
preparation: 1 day
---
>#  Gefnul
>
> **Locale:** Volcanoes
> **Climate:** Polar
> **Availability:** Summer 60%
> **Ability Check:** Intelligence -6
> **Uses:** 1
> **Value:** 200 gp/ 500 gp
> **Preparation:** 1 day
> **Description:** Gefnul will totally cure and heal the recipient if eaten within one week of harvesting. A roll of over the Herbalists intelligence will kill the recipient, a roll of twenty will kill the recipient beyond the ability of a raise dead spell to revive him.
{.5eblock}

