---
fileType: item
itemType: herb
name: Guardseye
locale: Grassland
climate: Cold
availability: Always 5%
abilityCheck: Intelligence -3
uses: {Uses}
value: 100 gp/ 100 gp
preparation: 20 minutes
---
>#  Guardseye
>
> **Locale:** Grassland
> **Climate:** Cold
> **Availability:** Always 5%
> **Ability Check:** Intelligence -3
> **Uses:** 1d4
> **Value:** 100 gp/ 100 gp
> **Preparation:** 20 minutes
> **Description:** This 40 cm high perennial has smooth, dark blue leaves and a woody stem. It has white, cuplike flowers, with purple flecks on the inside. In autumn, the plant dies except for a thick root than can be up to 50 cm long, but even dead, it does not shed its leaves. Thus the all year availability, for it is the leaves that are important. When cooked in water, the resulting tea will grant the drinker the ability to detect all life forms within 500 m. This includes hidden, invisible, phased, ethereal and similarly affected creatures. The effect last for fully 6 hours.
{.5eblock}

