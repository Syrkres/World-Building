---
fileType: item
itemType: herb
name: Ebur
locale: Coastal
climate: Temperate
availability: Spring 45%
abilityCheck: Intelligence -2
uses: {Uses}
value: 22 gp/ 22 gp
preparation: none
---
>#  Ebur
>
> **Locale:** Coastal
> **Climate:** Temperate
> **Availability:** Spring 45%
> **Ability Check:** Intelligence -2
> **Uses:** 5
> **Value:** 22 gp/ 22 gp
> **Preparation:** none
> **Description:** The flowers of Ebur must be eaten each day. If the treatment is successful the rate of healing for a sprain will be doubled for that day.
{.5eblock}

