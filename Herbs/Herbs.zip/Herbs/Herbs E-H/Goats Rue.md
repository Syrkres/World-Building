---
fileType: item
itemType: herb
name: Goats_Rue
locale: Forest
climate: Temperate
availability: Summer 60%
abilityCheck: Intelligence -10
uses: {Uses}
value: 6 gp/ 15 gp
preparation: 2 weeks
---
>#  Goat's Rue
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Summer 60%
> **Ability Check:** Intelligence -10
> **Uses:** 1
> **Value:** 6 gp/ 15 gp
> **Preparation:** 2 weeks
> **Description:** This herb will cure poison if ingested within one hour of the poisoning. Any damage already taken, including death, remains. Goat's Rue grows to about 3 feet tall. It has hollow branches and pale whitish blue flowers that hang down in spikes. The flowers must be dried before use.
{.5eblock}

