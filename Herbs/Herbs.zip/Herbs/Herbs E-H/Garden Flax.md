---
fileType: item
itemType: herb
name: Garden_Flax
locale: Forest
climate: Temperate
availability: Spring, Summer 55%
abilityCheck: Intelligence +3
uses: {Uses}
value: 3 gp/ 6 gp
preparation: 2 weeks
---
>#  Garden Flax
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Spring, Summer 55%
> **Ability Check:** Intelligence +3
> **Uses:** 5
> **Value:** 3 gp/ 6 gp
> **Preparation:** 2 weeks
> **Description:** The brown seeds of this herb (which has deep blue flowers) if chewed remove all pain from a characters wounds. It will also prevent a character from feeling anything. He could walk through a fire and feel no pain. There is a 10% chance per hour that a character moving normally will suffer 1d2 hp damage, while under the influence of this herb. This occurs because the character doe not notice minor bruises or scratches. It was widely believed in medieval times that if the seeds of this plant were strewn across a vampires path the vampire would be unable to proceed further, until it had counted every seed. At the GMs discretion this may be a use for this herb in FRP campaigns.
{.5eblock}

