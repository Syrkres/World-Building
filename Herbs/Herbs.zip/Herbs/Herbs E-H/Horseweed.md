---
fileType: item
itemType: herb
name: Horseweed
locale: Grassland
climate: Temperate
availability: Spring, Summer, Autumn 10%
abilityCheck: Intelligence -2
uses: {Uses}
value: 7 gp/ 7 gp
preparation: None
---
>#  Horseweed
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Spring, Summer, Autumn 10%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 7 gp/ 7 gp
> **Preparation:** None
> **Description:** This 25 cm high plant has many broad, double sawed leaves growing in a rosette. It grows large, yellow composite flowers, which will quickly grow hairy seeds that will fly far on the wind. The plant often has flowers and seed simultaneously. If a generous amount of the leaves is fed to a horse or similar creature, it will be able to travel all day without tiring, even if moving at a gallop.
{.5eblock}

