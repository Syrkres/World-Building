---
fileType: item
itemType: herb
name: Horehound
locale: Coastal
climate: Temperate
availability: Summer 90%
abilityCheck: Intelligence -2
uses: {Uses}
value: 1 gp/ 5 gp
preparation: 4 weeks
---
>#  Horehound
>
> **Locale:** Coastal
> **Climate:** Temperate
> **Availability:** Summer 90%
> **Ability Check:** Intelligence -2
> **Uses:** 3
> **Value:** 1 gp/ 5 gp
> **Preparation:** 4 weeks
> **Description:** This plant has angular greyish stems and grows to a height of three feet. It has oval shaped tooth edged, ash green leaves. It has small creamy white flowers which group at the base of the leaves. This herb will cause the recipient to vomit up any poison in their system. It is effective only against ingested poisons. The  person will be incapacitated by nausea for 1-3 days. In the case of an `instant death' poison, the person can be saved if the herb is successfully administered within one round, but they will be incapacitated for the full three day period.
{.5eblock}

