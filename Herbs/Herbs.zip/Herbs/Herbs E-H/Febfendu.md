---
fileType: item
itemType: herb
name: Febfendu
locale: Coastal, Rivers
climate: Cold
availability: Winter 5%
abilityCheck: Intelligence
uses: {Uses}
value: 90 gp/ 900 gp
preparation: 1 week
---
>#  Febfendu
>
> **Locale:** Coastal, Rivers
> **Climate:** Cold
> **Availability:** Winter 5%
> **Ability Check:** Intelligence
> **Uses:** 1
> **Value:** 90 gp/ 900 gp
> **Preparation:** 1 week
> **Description:** The roots of this plant must be brewed over a low fire for one week, and the resulting distillation drunk. If used successfully, hearing will be restored to the recipient.
{.5eblock}

