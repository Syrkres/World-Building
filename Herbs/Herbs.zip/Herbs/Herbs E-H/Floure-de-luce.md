---
fileType: item
itemType: herb
name: Floure-de-luce
locale: Grassland
climate: Temperate
availability: Always 60%
abilityCheck: Intelligence
uses: {Uses}
value: 3 gp/ 10 gp
preparation: 3 weeks
---
>#  Floure-de-luce
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Always 60%
> **Ability Check:** Intelligence
> **Uses:** 2
> **Value:** 3 gp/ 10 gp
> **Preparation:** 3 weeks
> **Description:** The Floure-De-Luce is also known as the Blue Flag. It has broad and flat leaves shaped rather like a sword. The flowers are purplish blue and the roots which tend to stretch themselves along the surface of the ground are reddish brown on the outside. The root must be mashed and boiled in water and left to stand for at least twenty days before drinking. This herb removes bruises from a body very quickly (within 1d4 hours).
{.5eblock}

