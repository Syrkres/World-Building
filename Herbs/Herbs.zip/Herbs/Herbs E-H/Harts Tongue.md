---
fileType: item
itemType: herb
name: Harts_Tongue
locale: Forest
climate: Temperate
availability: Always 10%
abilityCheck: Intelligence -2
uses: {Uses}
value: 2 gp/ 2 gp
preparation: none
---
>#  Hart's Tongue
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Always 10%
> **Ability Check:** Intelligence -2
> **Uses:** 1
> **Value:** 2 gp/ 2 gp
> **Preparation:** none
> **Description:** This fern resembles a deer's tongue, hence its name. When a single frond is eaten, it serves to immediately decrease the recipients libido for 2d4 days. For this reason it is often of value to those undertaking a vow of celibacy, or who must be away from their loved ones. It does not diminish performance in any way, merely desire.
{.5eblock}

