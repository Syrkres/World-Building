---
fileType: item
itemType: herb
name: Gylvir
locale: Coastal
climate: Temperate
availability: Autumn 10%
abilityCheck: Intelligence-2
uses: {Uses}
value: 100 gp/ 100 gp
preparation: none
---
>#  Gylvir
>
> **Locale:** Coastal
> **Climate:** Temperate
> **Availability:** Autumn 10%
> **Ability Check:** Intelligence-2
> **Uses:** 1
> **Value:** 100 gp/ 100 gp
> **Preparation:** none
> **Description:** This is an algae. When eaten it allows a person to breathe underwater (and only underwater!) for a period of four hours.
{.5eblock}

