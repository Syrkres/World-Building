---
fileType: item
itemType: herb
name: Hawkweed
locale: Forest
climate: Temperate
availability: Always 75%
abilityCheck: Intelligence
uses: {Uses}
value: 4 gp/ 6 gp
preparation: 2 weeks
---
>#  Hawkweed
>
> **Locale:** Forest
> **Climate:** Temperate
> **Availability:** Always 75%
> **Ability Check:** Intelligence
> **Uses:** 2
> **Value:** 4 gp/ 6 gp
> **Preparation:** 2 weeks
> **Description:** This herb increases a character eyesight for 1d4 turns. They can see twice as far, and when in missile combat, all ranges are treated as if one less. Hawkweed has oval leaves, covered with small hairs on the underside, and green on the top. These leaves surround the plant at the base of the stem, and small yellow flowers tinged with red at the tips.
{.5eblock}

