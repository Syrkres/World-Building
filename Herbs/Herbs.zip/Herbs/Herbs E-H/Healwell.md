---
fileType: item
itemType: herb
name: Healwell
locale: All
climate: Temperate
availability: Summer 30%
abilityCheck: Intelligence
uses: {Uses}
value: 1 sp/ 1 sp
preparation: none
---
>#  Healwell
>
> **Locale:** All
> **Climate:** Temperate
> **Availability:** Summer 30%
> **Ability Check:** Intelligence
> **Uses:** 1
> **Value:** 1 sp/ 1 sp
> **Preparation:** none
> **Description:** A common enough herb to make it into most gardens, healwell is a small flowering plant with bright yellow flowers. Its pale green leaves secrete an oil that can be rubbed on small injuries. (Cures 1 hp/oz of oil, 1 round/oz to apply; not useful on wounds over 2 hp.)
{.5eblock}

