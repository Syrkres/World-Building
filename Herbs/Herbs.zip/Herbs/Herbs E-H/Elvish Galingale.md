---
fileType: item
itemType: herb
name: Elvish_Galingale
locale: Forest
climate:
availability: Spring, Summer 35%
abilityCheck: Intelligence -4
uses: {Uses}
value: 1 gp/ 2 gp
preparation: 1 week
---
>#  Elvish Galingale
>
> **Locale:** Forest
> **Climate:**
> **Availability:** Spring, Summer 35%
> **Ability Check:** Intelligence -4
> **Uses:** 5
> **Value:** 1 gp/ 2 gp
> **Preparation:** 1 week
> **Description:** Elvish Galingale grows to about four feet in height. It has a triangular stem on which grows a tuft of grass like flowers. The roots are boiled and left to stand for a week and the resulting decoction is then drunk. This herb increases the flow of blood. This is very useful when a person is cold. However if a person is bleeding, either internally or externally, or is wounded it will double the speed of loss of blood. Its effect lasts 1d6+1 hours.
{.5eblock}

