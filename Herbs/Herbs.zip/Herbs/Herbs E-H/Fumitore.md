---
fileType: item
itemType: herb
name: Fumitore
locale: Coastal
climate: Cold, Temperate
availability: Spring, Summer 80%
abilityCheck: Intelligence
uses: {Uses}
value: 3 gp/ 6 gp
preparation: 2 weeks
---
>#  Fumitore
>
> **Locale:** Coastal
> **Climate:** Cold, Temperate
> **Availability:** Spring, Summer 80%
> **Ability Check:** Intelligence
> **Uses:** 1
> **Value:** 3 gp/ 6 gp
> **Preparation:** 2 weeks
> **Description:**
{.5eblock}

