---
fileType: item
itemType: herb
name: Elecampane
locale: Rural
climate: Temperate
availability: Winter, Spring 15%
abilityCheck: Intelligence
uses: {Uses}
value: 1 sp/ 1 sp
preparation: none
---
>#  Elecampane
>
> **Locale:** Rural
> **Climate:** Temperate
> **Availability:** Winter, Spring 15%
> **Ability Check:** Intelligence
> **Uses:** 1
> **Value:** 1 sp/ 1 sp
> **Preparation:** none
> **Description:** This plant has a thick root, with leaves that are white on the bottom and green on top, as well as showy yellow flowers. The root may be eaten in which case it will cause the recipient to vomit. This effect, while useful in removing ingested poisons from the system, will leave the recipient weak (- 1d4 to Constitution for 2d6 hours). For this reason it may be used as a mildly debilitating poison.
{.5eblock}

