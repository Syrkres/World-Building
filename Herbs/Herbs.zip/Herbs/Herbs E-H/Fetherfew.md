---
fileType: item
itemType: herb
name: Fetherfew
locale: Forest
climate: Temperate, Subtropical
availability: Summer 65%
abilityCheck: Intelligence +3
uses: {Uses}
value: 2 gp/ 4 gp
preparation: 3 weeks
---
>#  Fetherfew
>
> **Locale:** Forest
> **Climate:** Temperate, Subtropical
> **Availability:** Summer 65%
> **Ability Check:** Intelligence +3
> **Uses:** 3
> **Value:** 2 gp/ 4 gp
> **Preparation:** 3 weeks
> **Description:** This herb grows to about 18 inches in height. It has many small white flowers. The flowers must be dried and then boiled in white wine. The resulting mixture must be drunk. This herb will remove the effects of vertigo from a person for up to twelve hours. It does this by stabilising the persons inner ear.
{.5eblock}

