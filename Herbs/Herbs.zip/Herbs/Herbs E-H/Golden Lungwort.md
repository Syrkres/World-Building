---
fileType: item
itemType: herb
name: Golden_Lungwort
locale: Forest
climate: Temperate, Subtropical
availability: Summer 80%
abilityCheck: Intelligence -3
uses: {Uses}
value: 1 gp/ 2 gp
preparation: 1 week
---
>#  Golden Lungwort
>
> **Locale:** Forest
> **Climate:** Temperate, Subtropical
> **Availability:** Summer 80%
> **Ability Check:** Intelligence -3
> **Uses:** 6
> **Value:** 1 gp/ 2 gp
> **Preparation:** 1 week
> **Description:** Golden lungwort has large oval leaves, covered with small hairs, and small pale blotches. It grows to a height of about 1 foot, and has small bell shaped flowers with five petals which change colour from pink, to mauve to blue. Flowers of different colours are often found on the same plant. This herb heals the ears of all aches and pains.
{.5eblock}

