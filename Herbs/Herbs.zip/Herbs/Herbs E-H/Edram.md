---
fileType: item
itemType: herb
name: Edram
locale: Rivers
climate: Cold
availability: Winter 15%
abilityCheck: Intelligence -10
uses: {Uses}
value: 30 gp/ 30 gp
preparation: none
---
>#  Edram
>
> **Locale:** Rivers
> **Climate:** Cold
> **Availability:** Winter 15%
> **Ability Check:** Intelligence -10
> **Uses:** 4
> **Value:** 30 gp/ 30 gp
> **Preparation:** none
> **Description:** Edram is a moss which when eaten will cause bones to heal at one and a half times their normal rate.
{.5eblock}

