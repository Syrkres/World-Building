---
fileType: item
itemType: herb
name: Harfy
locale: Grassland
climate: Temperate
availability: Summer 10%
abilityCheck: Intelligence
uses: {Uses}
value: 150 gp/ 150 gp
preparation: 1 week
---
>#  Harfy
>
> **Locale:** Grassland
> **Climate:** Temperate
> **Availability:** Summer 10%
> **Ability Check:** Intelligence
> **Uses:** 1
> **Value:** 150 gp/ 150 gp
> **Preparation:** 1 week
> **Description:** The resin of this herb must be applied to a bleeding wound. It will immediately stop any bleeding.
{.5eblock}

