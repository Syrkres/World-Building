---
fileType: item
itemType: herb
name: Falsifal
locale: Swamp
climate: Temperate
availability: Spring 30%
abilityCheck: Intelligence -2
uses: {Uses}
value: 3 gp/ 3 gp
preparation: 1 hour or less
---
>#  Falsifal
>
> **Locale:** Swamp
> **Climate:** Temperate
> **Availability:** Spring 30%
> **Ability Check:** Intelligence -2
> **Uses:** 2
> **Value:** 3 gp/ 3 gp
> **Preparation:** 1 hour or less
> **Description:** A wide-leafed plant with large pink flowers and thick roots containing a slimy gel. When the root is pulped, mixed with water and used as a poultice, it is effective against fresh burns, aiding rapid healing. The root-gel can also be thinned and drunk as a thick tea to counter the effects of blood loss. (On burns, add 2 hp/day for each of the first 3 days of rest the character takes. Used to counter blood loss, victim regains 1d3 hp/day instead of 1.)
{.5eblock}

