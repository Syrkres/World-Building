---
fileType: item
itemType: herb
name: Eldaas
locale: Coastal
climate: Temperate
availability: Spring, Summer 5%
abilityCheck: Intelligence -1
uses: {Uses}
value: 2 gp/ 4 gp
preparation: 2 days
---
>#  Eldaas
>
> **Locale:** Coastal
> **Climate:** Temperate
> **Availability:** Spring, Summer 5%
> **Ability Check:** Intelligence -1
> **Uses:** 1
> **Value:** 2 gp/ 4 gp
> **Preparation:** 2 days
> **Description:** This tall, blue-flowered plant with spike-shaped leaves is the base for medicines against nausea, usually taken in the form of a bitter-smelling and -tasting herbal tea. Eldaas is used to counteract the nausea associated with hangovers, motion sickness, morning sickness, and more common illnesses. (Adds + 2 to saves versus Constitution for each level of potency the herb is brewed at, to a maximum of + 6 - however, at this strength eldaas can cause dry mouth and constipation. Lasts 1d6 hours regardless of potency level.)
{.5eblock}

