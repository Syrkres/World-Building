---
fileType: item
itemType: herb
name: Felmather
locale: Coastal
climate: Temperate
availability: Spring 30%
abilityCheck: Intelligence -7
uses: {Uses}
value: 10 gp/ 10 gp
preparation: none
---
>#  Felmather
>
> **Locale:** Coastal
> **Climate:** Temperate
> **Availability:** Spring 30%
> **Ability Check:** Intelligence -7
> **Uses:** 3
> **Value:** 10 gp/ 10 gp
> **Preparation:** none
> **Description:** The leaves of this plant should be placed under the tongue of a person in a coma. If successful, the person will awake in 1d6 hours. If a roll of 20 is made, the persons mind will be destroyed.
{.5eblock}

