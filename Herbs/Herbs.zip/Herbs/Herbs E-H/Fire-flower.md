---
fileType: item
itemType: herb
name: Fire-flower
locale: Mountains
climate: Subtropical, Tropical
availability: Summer 1%
abilityCheck: -
uses: {Uses}
value: 1000 gp/ 100000 gp
preparation: 10 years
---
>#  Fire-flower
>
> **Locale:** Mountains
> **Climate:** Subtropical, Tropical
> **Availability:** Summer 1%
> **Ability Check:** -
> **Uses:** 100
> **Value:** 1000 gp/ 100000 gp
> **Preparation:** 10 years
> **Description:** It is suggested that this herb be found in one location on an entire world, ideally in a Mountain range in a tropical or subtropical region (The Mountains of the Sun). This is a small bush which has one pale golden flower and small red berries with the appearance of a live coal. The flowers of the bush must be taken and crushed into a diamond vial, and left to cure for ten years. This is also the amount of time needed for a single flower to bloom. A single drop of this elixir will heal any illness or injury, but will not allow limbs or other appendages to grow back. This is an incredibly powerful herb, and is likely to only exist in the hands of powerful lords and kings.
{.5eblock}

