---
fileType: item
itemType: herb
name: Gariig
locale: Desert
climate: Tropical
availability: Summer 60%
abilityCheck: Intelligence -10
uses: {Uses}
value: 55 gp/ 70 gp
preparation: 1 day
---
>#  Gariig
>
> **Locale:** Desert
> **Climate:** Tropical
> **Availability:** Summer 60%
> **Ability Check:** Intelligence -10
> **Uses:** 1
> **Value:** 55 gp/ 70 gp
> **Preparation:** 1 day
> **Description:** Gariig is a small cactus. It will restore all hit points to a wounded person if eaten within two days of being harvested.
{.5eblock}

