---
fileType: npc
Art: humanBanner01.png
Name: Remi
Surname: Smith
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Human
Alignment: NE
Gender: Male
Sexuality: Straight 
Appearance: Extra short fat build, with green eyes and streaked red hair. Their face is gap-toothed and their speech is low-pitched 
Age: Mature Adult 
Condition: Fine 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation:
Importance: 3
Likes: 
    - Meditation 
    - Rivers 
    - Staying inside 
    - Mythology 
Dislikes: 
    - Traveling / Vacation 
    - Making flower crowns 
    - Fishing 
    - Wasting things 
Acquaintances: 
SpouseName: Haylee(Wife)
SpouseAge: Young Adult 
SpouseGender: Female
SpouseCondition: Impaired 
Parents: 
    - Zaylee(Mother) Elderly  Female who is Deceased
    - Luca(Father) Elderly  Male who is At death's door 
Children: 
    No Children
AssociatedGroup:
    - Town Clergy 
AssociatedReligion:
PersonalityTrait:
- Subtle  
- Sensitive  
SocialTrait:
- Dishonest  
- Stingy  
- Tolerant  
MentalTrait:
- Courageous  
PersonalGoals: Be forgiven. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[humanBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
