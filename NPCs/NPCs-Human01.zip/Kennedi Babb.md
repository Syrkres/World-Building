---
fileType: npc
Art: humanBanner01.png
Name: Kennedi
Surname: Babb
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Human
Alignment: CN
Gender: Female
Sexuality: Straight 
Appearance: Extra tall wide build, with white eyes and greasy auburn hair. Their face has a moustache and their speech is whiny 
Age: Ancient 
Condition: Dying 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation:
Importance: 7
Likes: 
    - Archery 
    - Drinking 
Dislikes: 
    - Gossip 
    - Learning 
    - Treasure hunting 
Acquaintances: 
SpouseName: Quentin(Husband)
SpouseAge: Elderly 
SpouseGender: Male
SpouseCondition: Fit 
Parents: 
    - Hadleigh(Mother) Elderly  Female who is Deceased
    - Marlon(Father) Ancient  Male who is Deceased
Children: 
    - Ariel(Child) Young Adult  Boy who is Deceased  
AssociatedGroup:
    - Artisans Guild 
AssociatedReligion:
PersonalityTrait:
- Overt  
SocialTrait:
- Forthcoming  
- Secretive  
- Honest  
MentalTrait:
- Superstitious  
- Cautious  
- Patient  
PersonalGoals: Find a job. 
Assigned: false
---
