---
fileType: npc
Art: halfbreedBanner01.png
Name: Branson
Surname: Vernon
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Orc
Alignment: LE
Gender: Male
Sexuality: Straight 
Appearance: Squat wide build, with blue eyes and wavy black hair. Their face has a patch over left eye and their speech is nervous 
Age: Adult 
Condition: Fine 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 19
Likes: 
    - Lightning 
    - Smoked Meat 
    - Cemeteries 
Dislikes: 
    - Falling leaves 
    - Falconry 
    - Manners 
Acquaintances: 
SpouseName: Reed(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Fit 
Parents: 
    - Ramsey(Mother) Ancient  Female who is Scraped up 
    - Stafford(Father) Elderly  Male who is Dead 
Children: 
    - Brady(Child) Young Adult  Girl who is Healthy  
    - Remington(Child) Teen  Boy who is Fine  
    - Langdon(Child) Infant  Girl who is Fit  
AssociatedGroup:
    - Entertainer Union 
AssociatedReligion:
PersonalityTrait:
- Funny  
- Savvy  
SocialTrait:
- Dishonest  
- Cruel  
MentalTrait:
- Skillful  
- Impatient  
- Patient  
PersonalGoals: Protect their business. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
