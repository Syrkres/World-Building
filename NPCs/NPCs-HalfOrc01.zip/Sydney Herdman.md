---
fileType: npc
Art: halfbreedBanner01.png
Name: Sydney
Surname: Herdman
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Orc
Alignment: CN
Gender: Male
Sexuality: Straight 
Appearance: Short average build, with green eyes and curly black hair. Their face has small scar on left cheek and their speech is whiny 
Age: Adult 
Condition: Healthy 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 3
Likes: 
    - Falconry 
    - Wind chimes 
    - Forests 
Dislikes: 
    - Going outside 
    - Patterned socks 
    - Kites 
    - Seashells 
Acquaintances: 
SpouseName: Clifford(Wife)
SpouseAge: Mature Adult 
SpouseGender: Female
SpouseCondition: Ailing 
Parents: 
    - Rowley(Mother) Adult  Female who is Dying 
    - Byron(Father) Elderly  Male who is Inured 
Children: 
    No Children
AssociatedGroup:
    - Artisans Guild 
AssociatedReligion:
PersonalityTrait:
- Overt  
- Incoherent  
SocialTrait:
- Unreliable  
- Trusting  
MentalTrait:
- Religious  
- Religious  
- Incompetent  
PersonalGoals: Have what others have. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
