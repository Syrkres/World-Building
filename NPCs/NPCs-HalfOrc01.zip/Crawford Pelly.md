---
fileType: npc
Art: halfbreedBanner01.png
Name: Crawford
Surname: Pelly
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Orc
Alignment: NG
Gender: Male
Sexuality: Straight 
Appearance: Extra tall wide build, with blue eyes and well groomed auburn hair. Their face has a patch over eye and their speech is slured 
Age: Ancient 
Condition: Nauseos 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 7
Likes: 
    - Manners 
Dislikes: 
    - Clay 
    - Bird watching 
    - Fireplaces 
    - Children 
Acquaintances: 
SpouseName: Blankley(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Ailing 
Parents: 
    - Bentley(Mother) Elderly  Female who is Impaired 
    - Tattersall(Father) Adult  Male who is Healthy as a horse 
Children: 
    - Lester(Child) Child  Girl who is Healthy  
AssociatedGroup:
    - Merchants Guild 
AssociatedReligion:
PersonalityTrait:
- Energetic  
SocialTrait:
- Dishonest  
- Dependable  
- Demanding  
MentalTrait:
- Incompetent  
- Complacent  
- Inattentive  
PersonalGoals: Conquer their fear. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
