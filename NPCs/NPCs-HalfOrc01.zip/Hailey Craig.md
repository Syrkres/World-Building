---
fileType: npc
Art: halfbreedBanner01.png
Name: Hailey
Surname: Craig
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Orc
Alignment: CG
Gender: Male
Sexuality: Straight 
Appearance: Extra tall wide build, with white eyes and short grey hair. Their face is chiseled and their speech is raspy 
Age: Adult 
Condition: Incapacitaed 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 2
Likes: 
    - Acting 
Dislikes: 
    - Farmer 
    - Wind chimes 
    - Cave exploring 
Acquaintances: 
SpouseName: Huxley(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Impaired 
Parents: 
    - Ainsworth(Mother) Elderly  Female who is Deceased
    - Marlowe(Father) Elderly  Male who is At death's door 
Children: 
    - Yardley(Child) Teen  Girl who is Healthy  
AssociatedGroup:
    - Artisans Guild 
AssociatedReligion:
PersonalityTrait:
- Incoherent  
- Funny  
SocialTrait:
- Lenient  
- Deferential  
MentalTrait:
- Uninventive  
- Impatient  
- Intelligent  
PersonalGoals: Live a quiet life. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
