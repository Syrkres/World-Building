---
fileType: npc
Art: halfbreedBanner01.png
Name: Hale
Surname: Entwistle
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Orc
Alignment: LE
Gender: Female
Sexuality: Straight 
Appearance: Short wide build, with brown eyes and thinning blond hair. Their face is an missing ear and their speech is whiny 
Age: Adult 
Condition: Maimed 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 1
Likes: 
    - Patterned socks 
    - Mess 
    - Climbing 
    - Smiles 
Dislikes: 
    - Manners 
    - Cooking 
Acquaintances: 
SpouseName: 
SpouseAge: 
SpouseGender: 
SpouseCondition: 
Parents: 
    - Bradford(Mother) Elderly  Female who is Sick 
    - England(Father) Adult  Male who is Dying 
Children: 
    - Alston(Child) Young Adult  Boy who is Healthy  
AssociatedGroup:
    - Syndicate 
AssociatedReligion:
PersonalityTrait:
- Listless  
- Overt  
SocialTrait:
- Talkative  
MentalTrait:
- Skeptical  
PersonalGoals: Live a quiet life. 
Assigned: false
---
