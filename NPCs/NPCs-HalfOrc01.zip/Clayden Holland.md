---
fileType: npc
Art: halfbreedBanner01.png
Name: Clayden
Surname: Holland
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Orc
Alignment: CE
Gender: Female
Sexuality: Straight 
Appearance: Short anorexic build, with hazel eyes and well groomed black hair. Their face has nose pierced and their speech is a guttural slur 
Age: Mature Adult 
Condition: Fine 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 9
Likes: 
    - Knick-knacks 
    - Animals 
    - Leopard 
Dislikes: 
    - Riddles 
    - Open windows 
Acquaintances: 
SpouseName: Wakefield(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Fit as a fiddle 
Parents: 
    - Ainsworth(Mother) Elderly  Female who is Sick 
    - Barlow(Father) Elderly  Male who is Indisposed 
Children: 
    - Tyndall(Child) Teen  Boy who is Not oneself  
    - Lindsay(Child) Child  Boy who is Healthy  
AssociatedGroup:
    - Mages Guild 
AssociatedReligion:
PersonalityTrait:
- Optimistic  
SocialTrait:
- Helpful  
MentalTrait:
- Emotional  
- Stupid  
- Intelligent  
PersonalGoals: Find a job. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
