---
fileType: npc
Art: halflingBanner01.png
Name: Nob
Surname: Smallburrow
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Halfling
Alignment: CG
Gender: Male
Sexuality: Straight 
Appearance: Normal anorexic build, with white eyes and thinning blond hair. Their face has stained teeth and their speech is nasal 
Age: Adult 
Condition: Fine 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 10
Likes: 
    - Going outside 
    - Cooking 
    - Drinking 
Dislikes: 
    - Climbing 
Acquaintances: 
SpouseName: Mirabella(Wife)
SpouseAge: Young Adult 
SpouseGender: Female
SpouseCondition: All Right 
Parents: 
    - Marigold(Mother) Adult  Female who is Deceased
    - Everard(Father) Adult  Male who is Deceased
Children: 
    - Diamond(Child) Child  Girl who is Healthy  
    - Bingo(Child) Young Adult  Boy who is Dead  
    - Grimalda(Child) Child  Girl who is Scraped up  
AssociatedGroup:
    - Town Clergy 
AssociatedReligion:
PersonalityTrait:
- Listless  
SocialTrait:
- Helpful  
- Forthcoming  
- Forthcoming  
MentalTrait:
- Adaptive  
- Cautious  
PersonalGoals: Be the best they can be. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
