---
fileType: npc
Art: elvenBanner01.png
Name: Almithara
Surname: Cramlurtlithar
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Elf
Alignment: CG
Gender: Male
Sexuality: Bisexual 
Appearance: Normal anorexic build, with green eyes and long blond hair. Their face has a patch over right eye and their speech is whispery 
Age: Adult 
Condition: Fit 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: 
PrimaryOccupationCategory: 
Occupation:
Importance: 7
Likes: 
    - Cemeteries 
Dislikes: 
    - Manners 
Acquaintances: 
SpouseName: Jassin(Husband)
SpouseAge: Elderly 
SpouseGender: Male
SpouseCondition: Fit as a fiddle 
Parents: 
    - Lydi'aleera(Mother) Elderly  Female who is Expired 
    - Ehrendil(Father) Elderly  Male who is Deceased
Children: 
    - Pollae(Child) Young Adult  Girl who is Healthy  
    - Volodar(Child) Young Adult  Boy who is Healthy  
AssociatedGroup:
    - Merchants Guild 
AssociatedReligion:
PersonalityTrait:
- Thick-skinned  
SocialTrait:
- Uncooperative  
- Deferential  
- Cruel  
MentalTrait:
- Patient  
PersonalGoals: Be somebody else. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
