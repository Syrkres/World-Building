---
fileType: npc
Art: halfbreedBanner01.png
Name: Altham
Surname: Stinson
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Elf
Alignment: CG
Gender: Male
Sexuality: Bisexual 
Appearance: Short thin build, with green eyes and frazzled grey hair. Their face has large scar on right cheek and their speech is breathless 
Age: Adult 
Condition: Well 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: 
PrimaryOccupationCategory: 
Occupation:
Importance: 2
Likes: 
    - Rivers 
Dislikes: 
    - Crafts 
    - Meditation 
    - Training pets to do tricks 
    - Crowds 
Acquaintances: 
SpouseName: Bradly(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Ill 
Parents: 
    - Royal(Mother) Adult  Female who is Fit as a fiddle 
    - Snowdon(Father) Elderly  Male who is Deceased
Children: 
    - Appleton(Child) Teen  Boy who is Ill  
    - Hampton(Child) Young Adult  Boy who is Fit  
AssociatedGroup:
    - Vanguard 
AssociatedReligion:
PersonalityTrait:
- Savvy  
- Funny  
SocialTrait:
- Tolerant  
- Impartial  
MentalTrait:
- Emotional  
- Courageous  
- Indecisive  
PersonalGoals: Avoid a person. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
