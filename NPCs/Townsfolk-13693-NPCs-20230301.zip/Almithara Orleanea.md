---
fileType: npc
Art: elvenBanner01.png
Name: Almithara
Surname: Orleanea
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Wood Elf
Alignment: CG
Gender: Female
Sexuality: Straight 
Appearance: Extra tall thin build, with hazel eyes and well groomed red hair. Their face has sideburns and their speech is breathless 
Age: Adult 
Condition: Healthy 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: 
PrimaryOccupationCategory: 
Occupation:
Importance: 4
Likes: 
    - Touching 
Dislikes: 
    - Laying on the floor 
    - Going outside 
    - Patterned socks 
Acquaintances: 
SpouseName: Teirist(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: All Right 
Parents: 
    - Alauthshaee(Mother) Elderly  Female who is Indisposed 
    - Nindrol(Father) Adult  Male who is Sick 
Children: 
    No Children
AssociatedGroup:
    - Craftsman Guild 
AssociatedReligion:
PersonalityTrait:
- Funny  
SocialTrait:
- Friendly  
- Helpful  
- Secretive  
MentalTrait:
- Adaptive  
- Intelligent  
PersonalGoals: Find a cure. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
