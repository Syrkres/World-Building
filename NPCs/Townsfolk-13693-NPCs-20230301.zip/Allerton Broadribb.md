---
fileType: npc
Art: halfbreedBanner01.png
Name: Allerton
Surname: Broadribb
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Orc
Alignment: CE
Gender: Male
Sexuality: Straight 
Appearance: Average athletic build, with hazel eyes and thinning red hair. Their face has no eyebrows and their speech is accented 
Age: Adult 
Condition: Ailing 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: 
PrimaryOccupationCategory: 
Occupation:
Importance: 10
Likes: 
    - Flower pressing 
    - Skiing 
    - Witchcraft 
    - Bannana 
Dislikes: 
    - Jumping in puddles 
    - Money 
Acquaintances: 
SpouseName: Rutherford(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Scraped up 
Parents: 
    - Barton(Mother) Ancient  Female who is Deceased
    - Brent(Father) Elderly  Male who is Deceased
Children: 
    - Bentley(Child) Infant  Girl who is Indisposed  
    - Atherton(Child) Teen  Boy who is Healthy as a horse  
AssociatedGroup:
    - Town Clergy 
AssociatedReligion:
PersonalityTrait:
- Subtle  
- Pessimistic  
SocialTrait:
- Honest  
MentalTrait:
- Decisive  
- Patient  
PersonalGoals: Have justice done. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
