---
fileType: npc
Art: halfbreedBanner01.png
Name: Alby
Surname: Cline
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Elf
Alignment: TN
Gender: Female
Sexuality: Straight 
Appearance: Extra tall lean build, with brown eyes and pony-tail white hair. Their face has small scar on left cheek and their speech is accented 
Age: Mature Adult 
Condition: Healthy 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: 
PrimaryOccupationCategory: 
Occupation:
Importance: 5
Likes: 
    - Urban exploring 
    - Laying on the floor 
    - Extravagant things 
    - Decorating 
Dislikes: 
    - Fast rides 
    - Jewelry 
Acquaintances: 
SpouseName: Yardley(Husband)
SpouseAge: Elderly 
SpouseGender: Male
SpouseCondition: Well 
Parents: 
    - Walcott(Mother) Elderly  Female who is Expired 
    - Gladstone(Father) Elderly  Male who is Dead 
Children: 
    - Cholmondeley(Child) Infant  Boy who is Well  
    - Pinkerton(Child) Infant  Girl who is All Right  
    - Bradly(Child) Teen  Boy who is Impaired  
AssociatedGroup:
    - Syndicate 
AssociatedReligion:
PersonalityTrait:
- Thick-skinned  
SocialTrait:
- Generous  
- Generous  
MentalTrait:
- Creative  
- Courageous  
- Incompetent  
PersonalGoals: Avoid a person. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
