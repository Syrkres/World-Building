---
fileType: npc
Art: halflingBanner01.png
Name: Alfrida
Surname: Brandybuck
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Halfling
Alignment: LE
Gender: Male
Sexuality: Straight 
Appearance: Extra short fat build, with blue eyes and streaked brown hair. Their face is an missing ear and their speech is nasal 
Age: Ancient 
Condition: Under the weather 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: 
PrimaryOccupationCategory: 
Occupation:
Importance: 7
Likes: 
    - Weapons 
    - Quilting 
Dislikes: 
    - Cemeteries 
    - Abandoned buildings 
    - Open meadows 
    - Card games 
Acquaintances: 
SpouseName: 
SpouseAge: 
SpouseGender: 
SpouseCondition: 
Parents: 
    - Bertha(Mother) Elderly  Female who is Ill 
    - Gormadoc(Father) Elderly  Male who is Deceased
Children: 
    - Goldilocks(Child) Infant  Girl who is Healthy  
    - Linda(Child) Infant  Girl who is Healthy  
AssociatedGroup:
    - Craftsman Guild 
AssociatedReligion:
PersonalityTrait:
- Listless  
SocialTrait:
- Loyal  
- Secretive  
MentalTrait:
- Complacent  
- Skillful  
- Cautious  
PersonalGoals: Retrieve a lost item. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
