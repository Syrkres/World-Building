---
fileType: npc
Art: halfbreedBanner01.png
Name: Ainsworth
Surname: Knight
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Orc
Alignment: CE
Gender: Female
Sexuality: Straight 
Appearance: Grand anorexic build, with brown eyes and strange hairstyle grey hair. Their face has large scar on right cheek and their speech is fast 
Age: Mature Adult 
Condition: Impaired 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: 
PrimaryOccupationCategory: 
Occupation:
Importance: 3
Likes: 
    - Philosophy 
    - Complaining 
    - Facial hair 
Dislikes: 
    - Crowds 
    - Scarecrows 
    - Hugs 
    - Bird watching 
Acquaintances: 
SpouseName: Carlisle(Wife)
SpouseAge: Young Adult 
SpouseGender: Female
SpouseCondition: Wounded 
Parents: 
    - Clapham(Mother) Elderly  Female who is Deceased
    - Hailey(Father) Elderly  Male who is Deceased
Children: 
    - Clayden(Child) Child  Girl who is Scraped up  
    - Chester(Child) Young Adult  Girl who is Healthy  
AssociatedGroup:
    - Mages Circle 
AssociatedReligion:
PersonalityTrait:
- Listless  
SocialTrait:
- Bossy  
- Honest  
- Suspicious  
MentalTrait:
- Intelligent  
- Superstitious  
PersonalGoals: Find inspiration. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
