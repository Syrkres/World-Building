---
fileType: npc
Art: humanBanner01.png
Name: Abel
Surname: Pinn
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Human
Alignment: LG
Gender: Male
Sexuality: Gay 
Appearance: Tall strong build, with white eyes and dreadlocks white hair. Their face has large scar and their speech is nervous 
Age: Adult 
Condition: Dead 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: 
PrimaryOccupationCategory: 
Occupation:
Importance: 7
Likes: 
    - Certain people 
    - Keys 
    - Being late 
    - Drinking 
Dislikes: 
    - Surprises 
    - Knife throwing 
    - Pranks 
    - Cemeteries 
Acquaintances: 
SpouseName: Raya(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Healthy 
Parents: 
    - Clara(Mother) Elderly  Female who is Deceased
    - Colter(Father) Adult  Male who is Deceased
Children: 
    No Children
AssociatedGroup:
    - Union 
AssociatedReligion:
PersonalityTrait:
- Enthusiastic  
- Repulsive  
SocialTrait:
- Bossy  
- Unfaithful  
- Friendly  
MentalTrait:
- Reckless  
- Analytical  
- Incompetent  
PersonalGoals: Avoid failure. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[humanBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
