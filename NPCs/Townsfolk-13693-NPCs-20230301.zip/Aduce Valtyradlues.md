---
fileType: npc
Art: elvenBanner01.png
Name: Aduce
Surname: Valtyradlues
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Elf
Alignment: LN
Gender: Female
Sexuality: Gay 
Appearance: Normal average build, with brown eyes and limp auburn hair. Their face has small scar and their speech is breathless 
Age: Young Adult 
Condition: All Right 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: 
PrimaryOccupationCategory: 
Occupation:
Importance: 2
Likes: 
    - Festivals 
Dislikes: 
    - The ocean 
    - Foraging 
    - Road trips 
Acquaintances: 
SpouseName: Tira'allara(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: All Right 
Parents: 
    - Hacathra(Mother) Ancient  Female who is Hurt 
    - Durlan(Father) Elderly  Male who is At death's door 
Children: 
    - Faelar(Child) Child  Boy who is Ailing  
    - Ioelena(Child) Infant  Girl who is Healthy  
AssociatedGroup:
    - Artisans Guild 
AssociatedReligion:
PersonalityTrait:
- Pessimistic  
SocialTrait:
- Friendly  
MentalTrait:
- Indecisive  
- Tenacious  
- Inattentive  
PersonalGoals: Explore the unexplored. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
