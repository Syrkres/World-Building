---
fileType: npc
Art: elvenBanner01.png
Name: Alloralla
Surname: Crultantlithar
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Elf
Alignment: LN
Gender: Female
Sexuality: Bisexual 
Appearance: Tall wide build, with white eyes and thinning auburn hair. Their face is pock-marked and their speech is squeaky 
Age: Ancient 
Condition: All Right 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: 
PrimaryOccupationCategory: 
Occupation:
Importance: 7
Likes: 
    - Kites 
    - Wasting things 
Dislikes: 
    - Climbing 
    - Blue 
Acquaintances: 
SpouseName: Juppar(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Fit 
Parents: 
    - Gwynnestri(Mother) Elderly  Female who is Sick 
    - Sythaeryn(Father) Adult  Male who is Expired 
Children: 
    - Ornthalas(Child) Teen  Boy who is Healthy  
    - Chin'nesstre(Child) Teen  Girl who is All Right  
AssociatedGroup:
    - Merchants Guild 
AssociatedReligion:
PersonalityTrait:
- Respectful  
- Smooth  
SocialTrait:
- Loyal  
MentalTrait:
- Uninventive  
- Adaptive  
PersonalGoals: Go on an adventure. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
