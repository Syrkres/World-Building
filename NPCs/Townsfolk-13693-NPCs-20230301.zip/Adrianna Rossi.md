---
fileType: npc
Art: humanBanner01.png
Name: Adrianna
Surname: Rossi
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Human
Alignment: CE
Gender: Male
Sexuality: Bisexual 
Appearance: Squat lean build, with brown eyes and strange hairstyle grey hair. Their face has large scar on left cheek and their speech is low-pitched 
Age: Mature Adult 
Condition: Healthy 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: 
PrimaryOccupationCategory: 
Occupation:
Importance: 7
Likes: 
    - Seashells 
    - Clay 
Dislikes: 
    - Farming 
    - Flower pressing 
Acquaintances: 
SpouseName: Damian(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Indisposed 
Parents: 
    - Lennon(Mother) Elderly  Female who is Expired 
    - Grey(Father) Elderly  Male who is Deceased 
Children: 
    No Children
AssociatedGroup:
    - Mages Circle 
AssociatedReligion:
PersonalityTrait:
- Optimistic  
- Funny  
SocialTrait:
- Selfish  
MentalTrait:
- Courageous  
- Independent  
- Analytical  
PersonalGoals: Retrieve a lost item. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[humanBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
