---
Art: halfbreedBanner01.png
Name: Blackwood
Surname: Dwyer
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Dragonborn
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Grand average build, with hazel eyes and strange hairstyle white hair. Their face has a goatee and their speech is slured 
Age: Adult 
Condition: Maimed 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Competition 
 - Manners 
Dislikes: 
 - Potatoes 
 - Surprises 
 - Picking fruits 
Acquaintances: 
PrimaryOccupation: Barber
PrimaryOccupationCategory: Specialty Service
Occupation:
 - Barber 
Importance: 7
SpouseName: Weld(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: All Right 
Parents: 
  - Leighton(Mother) Elderly  Female who is Fine 
  - Rutland(Father) Elderly  Male who is At death's door 
Children: 
    No Children
AssociatedGroup:
 - Vanguard 
AssociatedReligion:
PersonalityTrait:
- Wrathful  
SocialTrait:
- Demanding  
- Dishonest  
- Dishonest  
MentalTrait:
- Independent  
- Analytical  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
