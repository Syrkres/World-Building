---
Art: unknownBanner01.png
Name: Weld
Surname: Dinsdale
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Forest Gnome
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Short average build, with white eyes and short grey hair. Their face has a distinctive nose and their speech is low-pitched 
Age: Ancient 
Condition: Healthy 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Road trips 
 - Fitted clothing 
Dislikes: 
 - Surprises 
 - Fast rides 
 - Drama 
 - Sudden movements 
Acquaintances: 
PrimaryOccupation: Chicken Butcher
PrimaryOccupationCategory: Cook
Occupation:
 - Chicken Butcher 
Importance: 7
SpouseName: 
SpouseAge: 
SpouseGender: 
SpouseCondition: 
Parents: 
  - Browning(Mother) Adult  Female who is Deceased
  - Richmond(Father) Ancient  Male who is Healthy 
Children: 
  - Stanton(Child) Teen  Boy who is Hurt  
  - Bentley(Child) Young Adult  Boy who is Deceased  
  - Sutton(Child) Child  Girl who is Wounded  
AssociatedGroup:
 - Merchants Guild 
AssociatedReligion:
PersonalityTrait:
- Savvy  
SocialTrait:
- Trusting  
- Loyal  
MentalTrait:
- Perceptive  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[unknownBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
