---
Art: dwarvenBanner01.png
Name: Ovond
Surname: Morigak
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Hill Dwarf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Tall anorexic build, with blue eyes and wavy auburn hair. Their face has large scar across full face and their speech is fast 
Age: Adult 
Condition: Expired 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - BOOKTYPE 
 - Darts 
 - Riddles 
 - Tutoring 
Dislikes: 
 - Hills 
Acquaintances: 
PrimaryOccupation: Cartographor
PrimaryOccupationCategory: Professional Specialties
Occupation:
 - Cartographor 
Importance: 4
SpouseName: Fimala(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Healthy 
Parents: 
  - Dalgari(Mother) Elderly  Female who is Deceased
  - Rundri(Father) Elderly  Male who is Deceased
Children: 
  - Ovgin(Child) Teen  Boy who is Dying  
AssociatedGroup:
 - Vanguard 
AssociatedReligion:
PersonalityTrait:
- Mature  
- Pessimistic  
SocialTrait:
- Talkative  
- Impartial  
- Stingy  
MentalTrait:
- Incompetent  
- Reckless  
- Analytical  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[dwarvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
