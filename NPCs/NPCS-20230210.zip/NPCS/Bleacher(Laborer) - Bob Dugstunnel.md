---
Art: halflingBanner01.png
Name: Bob
Surname: Dugstunnel
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Stout Halfling
Alignment: chaotic
Gender: Female
Sexuality: Bisexual 
Appearance: Average weak build, with blue eyes and streaked blond hair. Their face has no eyebrows and their speech is raspy 
Age: Adult 
Condition: Well 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Gossip 
 - Searching for lost items 
Dislikes: 
 - Spear 
Acquaintances: 
PrimaryOccupation: Bleacher
PrimaryOccupationCategory: Laborer
Occupation:
 - Bleacher 
Importance: 4
SpouseName: Hilda(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: All Right 
Parents: 
  - Estella(Mother) Elderly  Female who is Under the weather 
  - Haiduc(Father) Elderly  Male who is Dying 
Children: 
  - Brutus(Child) Child  Boy who is All Right  
AssociatedGroup:
 - Union 
AssociatedReligion:
PersonalityTrait:
- Naive  
SocialTrait:
- Trusting  
- Peaceful  
- Demanding  
MentalTrait:
- Intelligent  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
