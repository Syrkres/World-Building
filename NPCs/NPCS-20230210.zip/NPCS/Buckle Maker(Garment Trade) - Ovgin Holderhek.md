---
Art: dwarvenBanner01.png
Name: Ovgin
Surname: Holderhek
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Hill Dwarf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Normal fat build, with brown eyes and pony-tail auburn hair. Their face is gap-toothed and their speech is raspy 
Age: Adult 
Condition: Healthy 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Orange 
 - Crafts 
 - The ocean 
 - Statues 
Dislikes: 
 - Alchemy 
Acquaintances: 
PrimaryOccupation: Buckle Maker
PrimaryOccupationCategory: Garment Trade
Occupation:
 - Buckle Maker 
Importance: 7
SpouseName: Storon(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Healthy 
Parents: 
  - Dwgari(Mother) Elderly  Female who is At death's door 
  - Gardri(Father) Elderly  Male who is Healthy 
Children: 
    No Children
AssociatedGroup:
 - Mercenary Guild 
AssociatedReligion:
PersonalityTrait:
- Enthusiastic  
- Polite  
SocialTrait:
- Forthcoming  
MentalTrait:
- Skillful  
- Decisive  
- Perceptive  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[dwarvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
