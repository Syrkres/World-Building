---
Art: unknownBanner01.png
Name: Upton
Surname: Monroe
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Forest Gnome
Alignment: chaotic
Gender: Male
Sexuality: Bisexual 
Appearance: Tall frail build, with green eyes and thinning grey hair. Their face is doe-eyed and their speech is with lisps 
Age: Adult 
Condition: Dead 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Organization 
 - Gossip 
 - Facial hair 
Dislikes: 
 - Certain people 
 - Getting lost 
 - Crafts 
 - Hills 
Acquaintances: 
PrimaryOccupation: Count
PrimaryOccupationCategory: Noble
Occupation:
 - Count 
Importance: 18
SpouseName: 
SpouseAge: 
SpouseGender: 
SpouseCondition: 
Parents: 
  - Windsor(Mother) Adult  Female who is Fine 
  - Kent(Father) Elderly  Male who is Deceased
Children: 
  - Tyndall(Child) Infant  Girl who is Healthy  
  - Webley(Child) Infant  Girl who is All Right  
  - Sherwood(Child) Child  Girl who is Healthy  
AssociatedGroup:
 - Town Clergy 
AssociatedReligion:
PersonalityTrait:
- Funny  
- Humorless  
SocialTrait:
- Stingy  
- Quite  
- Forthcoming  
MentalTrait:
- Independent  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[unknownBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
