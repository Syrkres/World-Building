---
Art: halfbreedBanner01.png
Name: Hayley
Surname: Cabrera
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Dragonborn
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Extra short fat build, with white eyes and frazzled brown hair. Their face has small scar on left cheek and their speech is crisp 
Age: Adult 
Condition: Fit 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Making clothes 
Dislikes: 
 - Throwing rocks 
Acquaintances: 
PrimaryOccupation: Bather
PrimaryOccupationCategory: Specialty Service
Occupation:
 - Bather 
Importance: 4
SpouseName: Barton(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Fit 
Parents: 
  - England(Mother) Elderly  Female who is Healthy 
  - Enfield(Father) Elderly  Male who is Dead 
Children: 
  - Eastaughffe(Child) Child  Boy who is Healthy  
  - Wallace(Child) Young Adult  Girl who is Under the weather  
  - Preston(Child) Young Adult  Girl who is Healthy  
AssociatedGroup:
 - Craftsman Guild 
AssociatedReligion:
PersonalityTrait:
- Respectful  
- Sensitive  
SocialTrait:
- Dishonest  
- Tolerant  
MentalTrait:
- Superstitious  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
