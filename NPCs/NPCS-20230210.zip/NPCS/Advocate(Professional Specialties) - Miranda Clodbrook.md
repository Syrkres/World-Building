---
Art: halflingBanner01.png
Name: Miranda
Surname: Clodbrook
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Lightfoot Halfling
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Grand average build, with red eyes and wiry white hair. Their face has sideburns and their speech is with lisps 
Age: Adult 
Condition: Healthy 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Simplicity 
Dislikes: 
 - Reading books 
 - Lockpicking 
 - Falconry 
 - People watching 
Acquaintances: 
PrimaryOccupation: Advocate
PrimaryOccupationCategory: Professional Specialties
Occupation:
 - Advocate 
Importance: 10
SpouseName: Bosco(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Inured 
Parents: 
  - Regina(Mother) Adult  Female who is Deceased
  - Hildibrand(Father) Elderly  Male who is Fit 
Children: 
  - Robur(Child) Teen  Boy who is Out of sorts  
  - Fatima(Child) Teen  Girl who is Well  
  - Bellisima(Child) Child  Girl who is At death's door  
AssociatedGroup:
 - Artisans Guild 
AssociatedReligion:
PersonalityTrait:
- Funny  
SocialTrait:
- Uncooperative  
- Unreliable  
MentalTrait:
- Cautious  
- Adaptive  
- Cowardly  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
