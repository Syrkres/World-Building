---
Art: dwarvenBanner01.png
Name: Morunn
Surname: Orcfoe
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Hill Dwarf
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Average anorexic build, with brown eyes and well groomed auburn hair. Their face has eyebrow pierced and their speech is breathless 
Age: Young Adult 
Condition: Inured 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Card games 
 - Lightning 
 - Hail 
Dislikes: 
 - Crafts 
 - Gardens 
Acquaintances: 
PrimaryOccupation: Barbarian
PrimaryOccupationCategory: Merc
Occupation:
 - Barbarian 
Importance: 2
SpouseName: Bilola(Wife)
SpouseAge: Mature Adult 
SpouseGender: Female
SpouseCondition: Under the weather 
Parents: 
  - Groia(Mother) Adult  Female who is Deceased
  - Gomri(Father) Ancient  Male who is Healthy 
Children: 
  - Habur(Child) Young Adult  Boy who is Healthy  
  - Bofund(Child) Teen  Boy who is Dying  
  - Dwinzad(Child) Young Adult  Boy who is Healthy  
AssociatedGroup:
 - Vanguard 
AssociatedReligion:
PersonalityTrait:
- Depressed  
- Mature  
SocialTrait:
- Trusting  
MentalTrait:
- Independent  
- Courageous  
- Reckless  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[dwarvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
