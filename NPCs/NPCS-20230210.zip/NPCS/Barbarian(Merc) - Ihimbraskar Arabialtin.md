---
Art: elvenBanner01.png
Name: Ihimbraskar
Surname: Arabialtin
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: High  Elf
Alignment: chaotic
Gender: Female
Sexuality: Bisexual 
Appearance: Tall weak build, with green eyes and pony-tail blond hair. Their face has a missing eye and their speech is husky 
Age: Adult 
Condition: Fine 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Rain 
 - Hills 
 - Heights 
Dislikes: 
 - Archery 
 - Sudden movements 
Acquaintances: 
PrimaryOccupation: Barbarian
PrimaryOccupationCategory: Merc
Occupation:
 - Barbarian 
Importance: 2
SpouseName: Braerindra(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Wounded 
Parents: 
  - Huquethae(Mother) Adult  Female who is Healthy 
  - Aduce(Father) Elderly  Male who is Deceased
Children: 
  - Z�Beryl(Child) Young Adult  Girl who is Fine  
  - Ehrendil(Child) Child  Boy who is Dead  
  - Keryth(Child) Child  Boy who is Healthy  
AssociatedGroup:
 - Mercenary Guild 
AssociatedReligion:
PersonalityTrait:
- Energetic  
SocialTrait:
- Helpful  
- Honest  
- Tolerant  
MentalTrait:
- Impatient  
- Cautious  
- Stupid  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
