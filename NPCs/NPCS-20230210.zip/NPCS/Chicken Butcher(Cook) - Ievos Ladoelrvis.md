---
Art: elvenBanner01.png
Name: Ievos
Surname: Ladoelrvis
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: High  Elf
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Extra short athletic build, with green eyes and strange hairstyle red hair. Their face has a missing left eye and their speech is low-pitched 
Age: Adult 
Condition: Fine 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Puzzles 
 - Jumping in puddles 
 - Beekeeping 
 - Mist / Fog 
Dislikes: 
 - Knife throwing 
 - Searching for lost items 
 - Animals 
 - Hawk 
Acquaintances: 
PrimaryOccupation: Chicken Butcher
PrimaryOccupationCategory: Cook
Occupation:
 - Chicken Butcher 
Importance: 7
SpouseName: Amlaruil(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Fit 
Parents: 
  - Gweyr(Mother) Elderly  Female who is Fit 
  - Kerym(Father) Elderly  Male who is Impaired 
Children: 
  - Reluraun(Child) Infant  Boy who is Healthy  
  - Dyffros(Child) Young Adult  Boy who is Ill  
AssociatedGroup:
 - Merchants Guild 
AssociatedReligion:
PersonalityTrait:
- Wrathful  
- Humorless  
SocialTrait:
- Stingy  
- Unfriendly  
MentalTrait:
- Emotional  
- Skeptical  
- Ambitious  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
