---
Art: unknownBanner01.png
Name: Southey
Surname: Waltho
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Forest Gnome
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Tall anorexic build, with hazel eyes and limp white hair. Their face has lip pierced and their speech is nervous 
Age: Adult 
Condition: Incapacitaed 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Beekeeping 
Dislikes: 
 - Sailing 
 - Fireworks 
 - Insects 
Acquaintances: 
PrimaryOccupation: Buckle Maker
PrimaryOccupationCategory: Garment Trade
Occupation:
 - Buckle Maker 
Importance: 7
SpouseName: Deighton(Wife)
SpouseAge: Mature Adult 
SpouseGender: Female
SpouseCondition: Nauseos 
Parents: 
  - Bristol(Mother) Elderly  Female who is Well 
  - Bradly(Father) Adult  Male who is Deceased
Children: 
  - Charlton(Child) Young Adult  Boy who is Healthy  
  - Anderton(Child) Teen  Girl who is Healthy  
  - Garrick(Child) Teen  Girl who is Fit as a fiddle  
AssociatedGroup:
 - Mercenary Guild 
AssociatedReligion:
PersonalityTrait:
- Pessimistic  
- Naive  
SocialTrait:
- Demanding  
- Forthcoming  
MentalTrait:
- Skeptical  
- Perceptive  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[unknownBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
