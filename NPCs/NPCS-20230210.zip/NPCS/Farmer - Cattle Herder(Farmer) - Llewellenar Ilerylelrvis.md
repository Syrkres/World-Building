---
Art: elvenBanner01.png
Name: Llewellenar
Surname: Ilerylelrvis
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Elf
Alignment: chaotic
Gender: Female
Sexuality: Asexual 
Appearance: Grand lean build, with white eyes and long black hair. Their face has large scar on left cheek and their speech is halting 
Age: Adult 
Condition: Indisposed 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Smithing 
 - Falconry 
 - Cooking 
Dislikes: 
 - Treasure hunting 
 - Bannana 
 - Smoked Meat 
Acquaintances: 
PrimaryOccupation: Farmer - Cattle Herder
PrimaryOccupationCategory: Farmer
Occupation:
 - Farmer - Cattle Herder 
Importance: 3
SpouseName: Caerthynna(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Fit 
Parents: 
  - Chin�nesstre(Mother) Elderly  Female who is Deceased
  - Thurdan(Father) Adult  Male who is Deceased
Children: 
    No Children
AssociatedGroup:
 - Town Clergy 
AssociatedReligion:
PersonalityTrait:
- Naive  
- Pessimistic  
SocialTrait:
- Suspicious  
- Selfless  
- Tolerant  
MentalTrait:
- Comformist  
- Impatient  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
