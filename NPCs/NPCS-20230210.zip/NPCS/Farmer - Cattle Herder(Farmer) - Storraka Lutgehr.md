---
Art: dwarvenBanner01.png
Name: Storraka
Surname: Lutgehr
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Hill Dwarf
Alignment: chaotic
Gender: Male
Sexuality: Bisexual 
Appearance: Average average build, with red eyes and wavy brown hair. Their face has small scar and their speech is loud 
Age: Adult 
Condition: Sick 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Open spaces 
 - Bird watching 
Dislikes: 
 - Lockpicking 
 - Glass blowing 
Acquaintances: 
PrimaryOccupation: Farmer - Cattle Herder
PrimaryOccupationCategory: Farmer
Occupation:
 - Farmer - Cattle Herder 
Importance: 3
SpouseName: Grukk(Husband)
SpouseAge: Young Adult 
SpouseGender: Male
SpouseCondition: Hurt 
Parents: 
  - Groia(Mother) Elderly  Female who is Deceased
  - Thinund(Father) Elderly  Male who is Deceased
Children: 
  - Baldria(Child) Teen  Girl who is Nauseos  
  - Gorri(Child) Child  Boy who is Dying  
  - Gomri(Child) Teen  Boy who is All Right  
AssociatedGroup:
 - Town Clergy 
AssociatedReligion:
PersonalityTrait:
- Energetic  
- Proud  
SocialTrait:
- Quite  
MentalTrait:
- Ambitious  
- Uninventive  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[dwarvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
