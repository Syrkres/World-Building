---
Art: elvenBanner01.png
Name: Gylledha
Surname: Ilwylwolylth
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: High  Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Tall frail build, with blue eyes and wavy auburn hair. Their face has large scar on left cheek and their speech is with lisps 
Age: Adult 
Condition: Unwell 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Camping 
Dislikes: 
 - Metalworking 
 - Mythology 
Acquaintances: 
PrimaryOccupation: Cleric
PrimaryOccupationCategory: Clergy
Occupation:
 - Cleric 
Importance: 9
SpouseName: Oslarelar(Husband)
SpouseAge: Mature Adult 
SpouseGender: Male
SpouseCondition: Ill 
Parents: 
  - Aelieyeeva(Mother) Elderly  Female who is Deceased
  - Glorandal(Father) Elderly  Male who is Deceased
Children: 
  - Velethuil(Child) Child  Boy who is Fine  
  - Ilyndrathyl(Child) Infant  Boy who is Well  
  - Darcassan(Child) Infant  Boy who is Fit  
AssociatedGroup:
 - Secret Order 
AssociatedReligion:
PersonalityTrait:
- Humorless  
SocialTrait:
- Helpful  
MentalTrait:
- Perceptive  
- Inattentive  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
