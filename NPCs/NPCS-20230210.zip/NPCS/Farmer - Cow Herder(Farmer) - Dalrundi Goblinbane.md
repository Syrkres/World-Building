---
Art: dwarvenBanner01.png
Name: Dalrundi
Surname: Goblinbane
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Hill Dwarf
Alignment: chaotic
Gender: Male
Sexuality: Bisexual 
Appearance: Extra tall strong build, with brown eyes and thinning auburn hair. Their face is squinty and their speech is halting 
Age: Adult 
Condition: Healthy 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Music 
 - Hydra 
 - Skiing 
Dislikes: 
 - Fitted clothing 
 - Getting lost 
 - Bear 
 - Cemeteries 
Acquaintances: 
PrimaryOccupation: Farmer - Cow Herder
PrimaryOccupationCategory: Farmer
Occupation:
 - Farmer - Cow Herder 
Importance: 3
SpouseName: Klkk(Husband)
SpouseAge: Young Adult 
SpouseGender: Male
SpouseCondition: Maimed 
Parents: 
  - Griundi(Mother) Elderly  Female who is Deceased
  - Thinil(Father) Elderly  Male who is Deceased
Children: 
  - Gorri(Child) Young Adult  Boy who is Fit  
  - Bulunni(Child) Infant  Girl who is Incapacitaed  
  - Balip(Child) Infant  Girl who is Not oneself  
AssociatedGroup:
 - Town Clergy 
AssociatedReligion:
PersonalityTrait:
- Dull  
SocialTrait:
- Suspicious  
- Bossy  
- Honest  
MentalTrait:
- Skillful  
- Tenacious  
- Intelligent  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[dwarvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
