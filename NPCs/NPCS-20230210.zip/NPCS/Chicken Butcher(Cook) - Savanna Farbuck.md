---
Art: halflingBanner01.png
Name: Savanna
Surname: Farbuck
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Lightfoot Halfling
Alignment: chaotic
Gender: Female
Sexuality: Bisexual 
Appearance: Extra tall wide build, with hazel eyes and very long white hair. Their face has a goatee and their speech is low-pitched 
Age: Adult 
Condition: Sick 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Mace 
 - Wind chimes 
 - Abandoned buildings 
Dislikes: 
 - Inactivity 
Acquaintances: 
PrimaryOccupation: Chicken Butcher
PrimaryOccupationCategory: Cook
Occupation:
 - Chicken Butcher 
Importance: 7
SpouseName: 
SpouseAge: 
SpouseGender: 
SpouseCondition: 
Parents: 
  - Linda(Mother) Elderly  Female who is Dead 
  - Reginard(Father) Elderly  Male who is Fine 
Children: 
  - Marco(Child) Teen  Boy who is Indisposed  
AssociatedGroup:
 - Merchants Guild 
AssociatedReligion:
PersonalityTrait:
- Depressed  
SocialTrait:
- Uncooperative  
- Loyal  
- Tolerant  
MentalTrait:
- Stupid  
- Independent  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
