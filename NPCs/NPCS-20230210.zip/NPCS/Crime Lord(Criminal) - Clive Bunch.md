---
Art: halfbreedBanner01.png
Name: Clive
Surname: Bunch
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Dragonborn
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Extra tall fat build, with green eyes and very long white hair. Their face has a missing right eye and their speech is fast 
Age: Mature Adult 
Condition: Well 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Gossip 
 - Cooking 
Dislikes: 
 - Touching 
Acquaintances: 
PrimaryOccupation: Crime Lord
PrimaryOccupationCategory: Criminal
Occupation:
 - Crime Lord 
Importance: 9
SpouseName: Ashton(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Scraped up 
Parents: 
  - Hallewell(Mother) Elderly  Female who is Deceased
  - Hailey(Father) Elderly  Male who is Well 
Children: 
    No Children
AssociatedGroup:
 - Syndicate 
AssociatedReligion:
PersonalityTrait:
- Humorless  
SocialTrait:
- Uncooperative  
- Dishonest  
- Lenient  
MentalTrait:
- Independent  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
