---
Art: halflingBanner01.png
Name: Asphodel
Surname: Gauktea
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Ghostwise Halfling
Alignment: chaotic
Gender: Male
Sexuality: Bisexual 
Appearance: Extra tall lean build, with white eyes and long grey hair. Their face is toothless and their speech is squeaky 
Age: Adult 
Condition: Unwell 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Meditation 
 - Art 
 - Closed spaces 
 - Baking 
Dislikes: 
 - Certain clothes & fashion styles 
 - Sailing 
 - Baking 
Acquaintances: 
PrimaryOccupation: Blacksmith
PrimaryOccupationCategory: Blacksmith
Occupation:
 - Blacksmith 
Importance: 7
SpouseName: Harding(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Healthy 
Parents: 
  - Malva(Mother) Elderly  Female who is Deceased
  - Holfast(Father) Elderly  Male who is Deceased
Children: 
  - Linda(Child) Child  Girl who is Not oneself  
AssociatedGroup:
 - Craftsman Guild 
AssociatedReligion:
PersonalityTrait:
- Funny  
SocialTrait:
- Uncooperative  
- Cruel  
MentalTrait:
- Decisive  
- Adaptive  
- Creative  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
