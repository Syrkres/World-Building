---
Art: dwarvenBanner01.png
Name: Bolia
Surname: Gorunn
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Hill Dwarf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Short thin build, with blue eyes and wavy blond hair. Their face has large scar and their speech is slow 
Age: Adult 
Condition: All Right 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Fox 
 - Parades 
 - Shopping 
 - Pirates 
Dislikes: 
 - Puzzles 
Acquaintances: 
PrimaryOccupation: Farmer - Goat Herder
PrimaryOccupationCategory: Farmer
Occupation:
 - Farmer - Goat Herder 
Importance: 3
SpouseName: Grunbur(Husband)
SpouseAge: Elderly 
SpouseGender: Male
SpouseCondition: At death's door 
Parents: 
  - Mungrima(Mother) Ancient  Female who is Deceased
  - Munil(Father) Elderly  Male who is Dying 
Children: 
  - Barkk(Child) Infant  Boy who is Maimed  
AssociatedGroup:
 - Town Clergy 
AssociatedReligion:
PersonalityTrait:
- Repulsive  
- Enthusiastic  
SocialTrait:
- Tolerant  
MentalTrait:
- Independent  
- Intelligent  
- Secular  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[dwarvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
