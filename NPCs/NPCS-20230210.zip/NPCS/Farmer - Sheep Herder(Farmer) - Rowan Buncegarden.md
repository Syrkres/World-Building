---
Art: halflingBanner01.png
Name: Rowan
Surname: Buncegarden
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Ghostwise Halfling
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Average frail build, with green eyes and greasy auburn hair. Their face has a broken nose and their speech is wheezy 
Age: Ancient 
Condition: Scraped up 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Decorating 
 - Competition 
 - Staying inside 
 - Knick-knacks 
Dislikes: 
 - Flail 
 - Mountains 
Acquaintances: 
PrimaryOccupation: Farmer - Sheep Herder
PrimaryOccupationCategory: Farmer
Occupation:
 - Farmer - Sheep Herder 
Importance: 3
SpouseName: Nicol(Husband)
SpouseAge: Mature Adult 
SpouseGender: Male
SpouseCondition: Healthy 
Parents: 
  - Maxima(Mother) Elderly  Female who is Fine 
  - Brutus(Father) Elderly  Male who is Fit 
Children: 
  - Nina(Child) Teen  Girl who is Scraped up  
  - Amethyst(Child) Teen  Girl who is Not oneself  
AssociatedGroup:
 - Town Clergy 
AssociatedReligion:
PersonalityTrait:
- Dull  
SocialTrait:
- Unfriendly  
- Dependable  
- Dishonest  
MentalTrait:
- Decisive  
- Cowardly  
- Inattentive  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
