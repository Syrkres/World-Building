---
Art: elvenBanner01.png
Name: Rhespen
Surname: Badenvaathem
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Wood Elf
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Tall strong build, with brown eyes and streaked red hair. Their face has eyebrow pierced and their speech is halting 
Age: Ancient 
Condition: Well 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Organization 
 - Clay 
 - Eldritch monsters 
Dislikes: 
 - Being alone 
Acquaintances: 
PrimaryOccupation: Beer Seller
PrimaryOccupationCategory: Cook
Occupation:
 - Beer Seller 
Importance: 4
SpouseName: Winterflower(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Fit 
Parents: 
  - Caerthynna(Mother) Elderly  Female who is Deceased
  - Cameron(Father) Elderly  Male who is Ailing 
Children: 
    No Children
AssociatedGroup:
 - Craftsman Guild 
AssociatedReligion:
PersonalityTrait:
- Incoherent  
- Sensitive  
SocialTrait:
- Unfaithful  
- Talkative  
MentalTrait:
- Secular  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[elvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
