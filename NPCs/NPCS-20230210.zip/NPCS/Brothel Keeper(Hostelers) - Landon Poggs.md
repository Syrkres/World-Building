---
Art: unknownBanner01.png
Name: Landon
Surname: Poggs
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Forest Gnome
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Grand anorexic build, with red eyes and thick brown hair. Their face has small scar on left cheek and their speech is with lisps 
Age: Mature Adult 
Condition: Impaired 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Children 
 - Foraging 
 - Small Lizard 
 - Birthdays 
Dislikes: 
 - Napping 
 - Map making 
 - Farmer 
Acquaintances: 
PrimaryOccupation: Brothel Keeper
PrimaryOccupationCategory: Hostelers
Occupation:
 - Brothel Keeper 
Importance: 5
SpouseName: Lancaster(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Healthy 
Parents: 
  - Breeden(Mother) Elderly  Female who is Deceased
  - Lindsay(Father) Elderly  Male who is Deceased
Children: 
    No Children
AssociatedGroup:
 - Mercenary Guild 
AssociatedReligion:
PersonalityTrait:
- Humble  
- Subtle  
SocialTrait:
- Loyal  
MentalTrait:
- Perceptive  
- Cautious  
- Superstitious  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[unknownBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
