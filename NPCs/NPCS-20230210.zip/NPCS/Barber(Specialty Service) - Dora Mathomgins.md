---
Art: halflingBanner01.png
Name: Dora
Surname: Mathomgins
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Lightfoot Halfling
Alignment: chaotic
Gender: Male
Sexuality: Gay 
Appearance: Extra tall thin build, with red eyes and dreadlocks white hair. Their face has a bushy eyebrows and their speech is low-pitched 
Age: Adult 
Condition: Healthy 
Kingdom: Realm of LoVara
Region: Central LoVara
Settlement: Teagan
UrbanArea: 
Location: Realm of LoVara(Central LoVara) / Teagan()
Likes: 
 - Philosophy 
Dislikes: 
 - Birthdays 
Acquaintances: 
PrimaryOccupation: Barber
PrimaryOccupationCategory: Specialty Service
Occupation:
 - Barber 
Importance: 7
SpouseName: Caradoc(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Healthy 
Parents: 
  - Asphodel(Mother) Adult  Female who is Healthy 
  - Wilimar(Father) Elderly  Male who is Out of sorts 
Children: 
  - Cara(Child) Infant  Girl who is Maimed  
  - Belladonna(Child) Child  Girl who is Well  
  - Jolly(Child) Young Adult  Boy who is Fine  
AssociatedGroup:
 - Vanguard 
AssociatedReligion:
PersonalityTrait:
- Repulsive  
- Sensitive  
SocialTrait:
- Helpful  
- Helpful  
MentalTrait:
- Cautious  
- Stupid  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
