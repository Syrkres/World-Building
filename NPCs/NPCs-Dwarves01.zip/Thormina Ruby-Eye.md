---
fileType: npc
Art: dwarvenBanner01.png
Name: Thormina
Surname: Ruby-Eye
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Dwarf
Alignment: CE
Gender: Male
Sexuality: Straight 
Appearance: Extra tall strong build, with brown eyes and very long brown hair. Their face has stained teeth and their speech is a guttural slur 
Age: Adult 
Condition: Healthy 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 1
Likes: 
    - Hunting 
    - Leather 
    - Statues 
    - Making flower crowns 
Dislikes: 
    - Skiing 
    - Chalk 
    - Picking fruits 
Acquaintances: 
SpouseName: Bilim(Husband)
SpouseAge: Ancient 
SpouseGender: Male
SpouseCondition: Sick 
Parents: 
    - Bilola(Mother) Adult  Female who is Deceased
    - Gomo(Father) Elderly  Male who is Inured 
Children: 
    - Garbari(Child) Young Adult  Girl who is Indisposed  
    - Norola(Child) Young Adult  Girl who is Fine  
AssociatedGroup:
    - Syndicate 
AssociatedReligion:
PersonalityTrait:
- Sensitive  
- Optimistic  
SocialTrait:
- Bossy  
- Cruel  
- Peaceful  
MentalTrait:
- Secular  
- Decisive  
- Ambitious  
PersonalGoals: Escape a bad situation. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[dwarvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
