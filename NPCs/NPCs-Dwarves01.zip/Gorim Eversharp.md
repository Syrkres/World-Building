---
fileType: npc
Art: dwarvenBanner01.png
Name: Gorim
Surname: Eversharp
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Dwarf
Alignment: CN
Gender: Male
Sexuality: Straight 
Appearance: Short frail build, with white eyes and thick black hair. Their face has large ears and their speech is low-pitched 
Age: Adult 
Condition: Healthy 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 7
Likes: 
    - Traveling / Vacation 
Dislikes: 
    - Archery 
    - Danger 
Acquaintances: 
SpouseName: 
SpouseAge: 
SpouseGender: 
SpouseCondition: 
Parents: 
    - Balip(Mother) Elderly  Female who is Dead 
    - Mungol(Father) Elderly  Male who is Deceased 
Children: 
    - Bofzad(Child) Teen  Boy who is Fit  
    - Durria(Child) Young Adult  Girl who is Dying  
    - Thrrund(Child) Teen  Boy who is Fine  
AssociatedGroup:
    - Merchants Guild 
AssociatedReligion:
PersonalityTrait:
- Gentle  
- Sensitive  
SocialTrait:
- Suspicious  
- Intolerant  
- Intolerant  
MentalTrait:
- Tenacious  
- Comformist  
- Stupid  
PersonalGoals: Start a family. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[dwarvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
