---
fileType: npc
Art: dwarvenBanner01.png
Name: Morkk
Surname: Trueanvil
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Dwarf
Alignment: TN
Gender: Male
Sexuality: Straight 
Appearance: Squat wide build, with hazel eyes and thinning red hair. Their face has a goatee and their speech is fast 
Age: Mature Adult 
Condition: All Right 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 9
Likes: 
    - Scarecrows 
    - Lockpicking 
Dislikes: 
    - Storytelling 
    - Sincerity 
    - Road trips 
    - Jumping in puddles 
Acquaintances: 
SpouseName: Ketgari(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Healthy 
Parents: 
    - Naltila(Mother) Ancient  Female who is Deceased
    - Ovund(Father) Elderly  Male who is Dying 
Children: 
    - Grozadi(Child) Young Adult  Girl who is Well  
    - Dimina(Child) Teen  Girl who is Healthy  
    - Dimtila(Child) Teen  Girl who is Healthy  
AssociatedGroup:
    - Secret Order 
AssociatedReligion:
PersonalityTrait:
- Naive  
SocialTrait:
- Generous  
- Unreliable  
MentalTrait:
- Adaptive  
- Courageous  
- Courageous  
PersonalGoals: Break an addiction. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[dwarvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
