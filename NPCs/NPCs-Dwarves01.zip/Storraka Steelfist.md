---
fileType: npc
Art: dwarvenBanner01.png
Name: Storraka
Surname: Steelfist
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Dwarf
Alignment: CG
Gender: Female
Sexuality: Bisexual 
Appearance: Average frail build, with white eyes and curly blond hair. Their face has large scar and their speech is breathless 
Age: Adult 
Condition: Wounded 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 1
Likes: 
    - Heights 
    - Gossip 
    - Birthdays 
Dislikes: 
    - Danger 
Acquaintances: 
SpouseName: Hertil(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Healthy 
Parents: 
    - Farili(Mother) Elderly  Female who is Dying 
    - Morkk(Father) Adult  Male who is Healthy as a horse 
Children: 
    - Thinbura(Child) Teen  Girl who is Ailing  
    - Dimina(Child) Teen  Girl who is Fit  
AssociatedGroup:
    - Syndicate 
AssociatedReligion:
PersonalityTrait:
- Humorless  
- Subtle  
SocialTrait:
- Suspicious  
- Secretive  
MentalTrait:
- Skillful  
PersonalGoals: Restart the world. 
Assigned: false
---
