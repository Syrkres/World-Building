---
fileType: npc
Art: dwarvenBanner01.png
Name: Bolgar
Surname: Goblinbane
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Dwarf
Alignment: LE
Gender: Male
Sexuality: Straight 
Appearance: Squat average build, with white eyes and very long white hair. Their face has a missing eye and their speech is raspy 
Age: Adult 
Condition: Fine 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 7
Likes: 
    - Loaf of Bread 
    - Quilting 
Dislikes: 
    - Gaming 
    - Pottery 
    - Woodworking 
    - Politics 
Acquaintances: 
SpouseName: Bela(Wife)
SpouseAge: Mature Adult 
SpouseGender: Female
SpouseCondition: Under the weather 
Parents: 
    - Runbari(Mother) Elderly  Female who is Dying 
    - Herzad(Father) Elderly  Male who is Scraped up 
Children: 
    No Children
AssociatedGroup:
    - Mages Circle 
AssociatedReligion:
PersonalityTrait:
- Respectful  
SocialTrait:
- Demanding  
- Peaceful  
MentalTrait:
- Emotional  
- Patient  
PersonalGoals: Go on an adventure. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[dwarvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
