---
fileType: npc
Art: dwarvenBanner01.png
Name: Drukka
Surname: Graybeard
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Dwarf
Alignment: CE
Gender: Female
Sexuality: Straight 
Appearance: Normal frail build, with hazel eyes and very long auburn hair. Their face has small scar on right cheek and their speech is fast 
Age: Adult 
Condition: Healthy 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 1
Likes: 
    - Birthdays 
    - Snow 
Dislikes: 
    - Abandoned buildings 
Acquaintances: 
SpouseName: Hargin(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Healthy as a horse 
Parents: 
    - Gilon(Mother) Elderly  Female who is Deceased
    - Dalkon(Father) Elderly  Male who is Deceased
Children: 
    - Nalbar(Child) Teen  Boy who is Healthy  
AssociatedGroup:
    - Thieves Guild 
AssociatedReligion:
PersonalityTrait:
- Gentle  
- Overt  
SocialTrait:
- Unfaithful  
MentalTrait:
- Reckless  
PersonalGoals: Find out the fate of a friend. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[dwarvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
