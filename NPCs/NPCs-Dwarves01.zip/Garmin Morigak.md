---
fileType: npc
Art: dwarvenBanner01.png
Name: Garmin
Surname: Morigak
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Dwarf
Alignment: LN
Gender: Male
Sexuality: Straight 
Appearance: Extra short strong build, with red eyes and well groomed black hair. Their face has a patch over left eye and their speech is slow 
Age: Adult 
Condition: Healthy 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 7
Likes: 
    - BOOKTYPE 
    - Meditation 
    - Festivals 
Dislikes: 
    - Smithing 
Acquaintances: 
SpouseName: Ketila(Wife)
SpouseAge: Mature Adult 
SpouseGender: Female
SpouseCondition: Unwell 
Parents: 
    - Bela(Mother) Elderly  Female who is Deceased
    - Ovond(Father) Adult  Male who is Deceased
Children: 
    - Drukon(Child) Infant  Boy who is Healthy  
    - Bofdria(Child) Infant  Girl who is Healthy  
    - Bolum(Child) Teen  Boy who is All Right  
AssociatedGroup:
    - Secret Order 
AssociatedReligion:
PersonalityTrait:
- Incoherent  
SocialTrait:
- Violent  
MentalTrait:
- Analytical  
- Cautious  
- Decisive  
PersonalGoals: Protect their business. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[dwarvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
