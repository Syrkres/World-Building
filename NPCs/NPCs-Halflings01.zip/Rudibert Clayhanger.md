---
fileType: npc
Art: halflingBanner01.png
Name: Rudibert
Surname: Clayhanger
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Halfling
Alignment: LE
Gender: Male
Sexuality: Bisexual 
Appearance: Average anorexic build, with green eyes and thick grey hair. Their face is grizzled and their speech is nasal 
Age: Adult 
Condition: Healthy 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 1
Likes: 
    - Chalk 
Dislikes: 
    - Rain 
    - Being early 
    - The moon 
Acquaintances: 
SpouseName: Mentha(Wife)
SpouseAge: Adult 
SpouseGender: Female
SpouseCondition: Expired 
Parents: 
    - Rose(Mother) Ancient  Female who is Dead 
    - Habaccuc(Father) Elderly  Male who is Scraped up 
Children: 
    - Gruffo(Child) Teen  Boy who is All Right  
    - Mentha(Child) Teen  Girl who is Deceased  
AssociatedGroup:
    - Secret Order 
AssociatedReligion:
PersonalityTrait:
- Smooth  
- Enthusiastic  
SocialTrait:
- Deferential  
MentalTrait:
- Tenacious  
- Reckless  
- Skillful  
PersonalGoals: Escape death. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
