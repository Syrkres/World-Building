---
fileType: npc
Art: halflingBanner01.png
Name: Prisca
Surname: Fairbairn
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Halfling
Alignment: CN
Gender: Male
Sexuality: Straight 
Appearance: Squat weak build, with white eyes and thick blond hair. Their face has a distinctive nose and their speech is wheezy 
Age: Adult 
Condition: Ailing 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 1
Likes: 
    - Witchcraft 
    - Sudden movements 
    - Searching for lost items 
Dislikes: 
    - Heights 
    - Sincerity 
    - Snow 
Acquaintances: 
SpouseName: Habaccuc(Husband)
SpouseAge: Young Adult 
SpouseGender: Male
SpouseCondition: Fit 
Parents: 
    - Jemima(Mother) Elderly  Female who is Sick 
    - Haiduc(Father) Elderly  Male who is Impaired 
Children: 
    No Children
AssociatedGroup:
    - Thieves Guild 
AssociatedReligion:
PersonalityTrait:
- Enthusiastic  
- Thick-skinned  
SocialTrait:
- Unfaithful  
- Generous  
MentalTrait:
- Ambitious  
PersonalGoals: Start a family. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
