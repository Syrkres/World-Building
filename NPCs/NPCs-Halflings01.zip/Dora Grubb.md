---
fileType: npc
Art: halflingBanner01.png
Name: Dora
Surname: Grubb
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Halfling
Alignment: TN
Gender: Male
Sexuality: Straight 
Appearance: Normal thin build, with red eyes and bald auburn hair. Their face is gap-toothed and their speech is squeaky 
Age: Adult 
Condition: Wounded 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 7
Likes: 
    - Leather 
    - Loud noises 
Dislikes: 
    - Festivals 
    - Crafts 
    - Jumping in puddles 
    - Farmer 
Acquaintances: 
SpouseName: 
SpouseAge: 
SpouseGender: 
SpouseCondition: 
Parents: 
    - Daisy(Mother) Elderly  Female who is Expired 
    - Jolly(Father) Elderly  Male who is Out of sorts 
Children: 
    - Caramella(Child) Teen  Girl who is Healthy  
AssociatedGroup:
    - Union 
AssociatedReligion:
PersonalityTrait:
- Savvy  
SocialTrait:
- Quite  
- Quite  
- Cruel  
MentalTrait:
- Stupid  
PersonalGoals: Create a work of art. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halflingBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
