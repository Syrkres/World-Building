---
fileType: npc
Art: halflingBanner01.png
Name: Goldilocks
Surname: Hayward
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Halfling
Alignment: CE
Gender: Male
Sexuality: Straight 
Appearance: Normal strong build, with green eyes and well groomed red hair. Their face has eyebrow pierced and their speech is slow 
Age: Mature Adult 
Condition: Healthy 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 7
Likes: 
    - Hand holding 
    - Jewelry 
    - Making clothes 
Dislikes: 
    - Weapons 
    - Being alone 
    - Going outside 
Acquaintances: 
SpouseName: 
SpouseAge: 
SpouseGender: 
SpouseCondition: 
Parents: 
    - Primrose(Mother) Elderly  Female who is Deceased 
    - Bodo(Father) Elderly  Male who is Expired 
Children: 
    No Children
AssociatedGroup:
    - Vanguard 
AssociatedReligion:
PersonalityTrait:
- Depressed  
- Dull  
SocialTrait:
- Stingy  
- Demanding  
MentalTrait:
- Ambitious  
PersonalGoals: Solve an ancient mystery. 
Assigned: false
---
