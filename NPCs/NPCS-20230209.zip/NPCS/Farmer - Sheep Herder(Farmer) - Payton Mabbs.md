---
Art: monsterBanner01.png
Name: Payton
Surname: Mabbs
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Cliffwalk Shifter
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Normal fat build, with hazel eyes and frazzled black hair. Their face has large ears and their speech is slured 
Age: Adult 
Condition: Sick 
Location: 
Likes: 
 - Children 
 - Staying inside 
 - Weapons 
Dislikes: 
 - Learning 
Acquaintances: 
PrimaryProfession: Farmer - Sheep Herder
PrimaryProfessionCategory: Farmer
Importance: 3
Occupation:
 - Farmer - Sheep Herder 
AssociatedGroup:
AssociatedReligion:
PersonalityTrait:
- Incoherent  
SocialTrait:
- Forthcoming  
- Friendly  
- Violent  
MentalTrait:
- Cowardly  
- Cautious  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[monsterBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.location)` |

# **`=this.PrimaryProfession` **<br><span style="font-size: medium">(`=this.PrimaryProfessionCategory`)</span>
> [!info|bg-c-purple]- Overview
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> TBD
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
