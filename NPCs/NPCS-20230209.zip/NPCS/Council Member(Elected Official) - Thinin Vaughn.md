---
Art: dwarvenBanner01.png
Name: Thinin
Surname: Vaughn
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Duergar
Alignment: chaotic
Gender: Female
Sexuality: Bisexual 
Appearance: Squat thin build, with red eyes and strange hairstyle grey hair. Their face has stained teeth and their speech is husky 
Age: Adult 
Condition: Dead 
Location: 
Likes: 
 - Woodworking 
 - Cleaning 
 - Clay 
 - Sincerity 
Dislikes: 
 - Mess 
 - Apple 
 - Clay 
Acquaintances: 
PrimaryProfession: Council Member
PrimaryProfessionCategory: Elected Official
Importance: 10
Occupation:
 - Council Member 
AssociatedGroup:
AssociatedReligion:
PersonalityTrait:
- Humorless  
- Thick-skinned  
SocialTrait:
- Cruel  
- Stingy  
MentalTrait:
- Emotional  
- Analytical  
- Inattentive  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[dwarvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.location)` |

# **`=this.PrimaryProfession` **<br><span style="font-size: medium">(`=this.PrimaryProfessionCategory`)</span>
> [!info|bg-c-purple]- Overview
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> TBD
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
