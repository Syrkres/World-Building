---
Art: planerBanner01.png
Name: Lindsay
Surname: Trist
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Water Genasi
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Extra short anorexic build, with white eyes and frazzled blond hair. Their face has small scar and their speech is slow 
Age: Adult 
Condition: Healthy 
Location: 
Likes: 
 - Weapons 
Dislikes: 
 - Beekeeping 
 - Drinking 
Acquaintances: 
PrimaryProfession: Farmer - Pig Herder
PrimaryProfessionCategory: Farmer
Importance: 3
Occupation:
 - Farmer - Pig Herder 
AssociatedGroup:
AssociatedReligion:
PersonalityTrait:
- Polite  
- Thick-skinned  
SocialTrait:
- Impartial  
- Lenient  
- Stingy  
MentalTrait:
- Analytical  
- Perceptive  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[planerBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.location)` |

# **`=this.PrimaryProfession` **<br><span style="font-size: medium">(`=this.PrimaryProfessionCategory`)</span>
> [!info|bg-c-purple]- Overview
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> TBD
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
