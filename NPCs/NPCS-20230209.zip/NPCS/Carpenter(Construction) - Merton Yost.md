---
Art: humanBanner01.png
Name: Merton
Surname: Yost
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Nephalia Human
Alignment: chaotic
Gender: Female
Sexuality: Bisexual 
Appearance: Grand wide build, with brown eyes and thinning red hair. Their face is grizzled and their speech is iwth lisps 
Age: Adult 
Condition: Hurt 
Location: 
Likes: 
 - Treasure hunting 
Dislikes: 
 - Leather 
 - Gossip 
 - Competition 
 - Falling leaves 
Acquaintances: 
PrimaryProfession: Carpenter
PrimaryProfessionCategory: Construction
Importance: 7
Occupation:
 - Carpenter 
AssociatedGroup:
AssociatedReligion:
PersonalityTrait:
- Thick-skinned  
- Thick-skinned  
SocialTrait:
- Selfish  
- Unfaithful  
MentalTrait:
- Indecisive  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[humanBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.location)` |

# **`=this.PrimaryProfession` **<br><span style="font-size: medium">(`=this.PrimaryProfessionCategory`)</span>
> [!info|bg-c-purple]- Overview
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> TBD
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
