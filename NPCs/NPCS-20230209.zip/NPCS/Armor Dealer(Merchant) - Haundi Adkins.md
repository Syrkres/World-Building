---
Art: dwarvenBanner01.png
Name: Haundi
Surname: Adkins
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Duergar
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Extra short athletic build, with brown eyes and streaked black hair. Their face is toothless and their speech is squeaky 
Age: Mature Adult 
Condition: Dying 
Location: 
Likes: 
 - Shopping 
Dislikes: 
 - Patterned socks 
 - Facial hair 
 - The sun 
Acquaintances: 
PrimaryProfession: Armor Dealer
PrimaryProfessionCategory: Merchant
Importance: 4
Occupation:
 - Armor Dealer 
AssociatedGroup:
AssociatedReligion:
PersonalityTrait:
- Energetic  
SocialTrait:
- Selfless  
- Peaceful  
MentalTrait:
- Cautious  
- Ambitious  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[dwarvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.location)` |

# **`=this.PrimaryProfession` **<br><span style="font-size: medium">(`=this.PrimaryProfessionCategory`)</span>
> [!info|bg-c-purple]- Overview
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> TBD
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
