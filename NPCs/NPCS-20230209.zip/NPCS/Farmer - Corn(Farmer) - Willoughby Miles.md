---
Art: humanBanner01.png
Name: Willoughby
Surname: Miles
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Kessig Human
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Extra tall lean build, with green eyes and very long red hair. Their face has a patch over right eye and their speech is iwth lisps 
Age: Young Adult 
Condition: Healthy 
Location: 
Likes: 
 - Traveling / Vacation 
 - Philosophy 
 - Juggling 
 - Dance 
Dislikes: 
 - Wind chimes 
 - Bannana 
 - Insects 
Acquaintances: 
PrimaryProfession: Farmer - Corn
PrimaryProfessionCategory: Farmer
Importance: 3
Occupation:
 - Farmer - Corn 
AssociatedGroup:
AssociatedReligion:
PersonalityTrait:
- Gentle  
- Thick-skinned  
SocialTrait:
- Loyal  
- Peaceful  
- Trusting  
MentalTrait:
- Courageous  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[humanBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.location)` |

# **`=this.PrimaryProfession` **<br><span style="font-size: medium">(`=this.PrimaryProfessionCategory`)</span>
> [!info|bg-c-purple]- Overview
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> TBD
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
