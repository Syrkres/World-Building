---
Art: monsterBanner01.png
Name: Ashton
Surname: Harrison
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Tuktuk Tribe Goblin
Alignment: chaotic
Gender: Female
Sexuality: Straight 
Appearance: Grand athletic build, with green eyes and long brown hair. Their face is pierced and their speech is raspy 
Age: Young Adult 
Condition: Healthy 
Location: 
Likes: 
 - Glass blowing 
 - Soap carving 
 - Scarecrows 
 - Buttons 
Dislikes: 
 - Acting 
 - Simplicity 
 - Map making 
Acquaintances: 
PrimaryProfession: Baron
PrimaryProfessionCategory: Noble
Importance: 16
Occupation:
 - Baron 
AssociatedGroup:
AssociatedReligion:
PersonalityTrait:
- Mature  
- Listless  
SocialTrait:
- Helpful  
- Forthcoming  
- Intolerant  
MentalTrait:
- Courageous  
- Patient  
- Independent  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[monsterBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.location)` |

# **`=this.PrimaryProfession` **<br><span style="font-size: medium">(`=this.PrimaryProfessionCategory`)</span>
> [!info|bg-c-purple]- Overview
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> TBD
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
