---
Art: unknownBanner01.png
Name: Garfield
Surname: Bell
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Forest Gnome
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Extra tall strong build, with blue eyes and wavy red hair. Their face has a patch over left eye and their speech is nervous 
Age: Adult 
Condition: Sick 
Location: 
Likes: 
 - Sudden movements 
Dislikes: 
 - Certain people 
 - Treasure hunting 
 - Loud noises 
 - Smoked Meat 
Acquaintances: 
PrimaryProfession: Elected Official
PrimaryProfessionCategory: Elected Official
Importance: 10
Occupation:
 - Elected Official 
AssociatedGroup:
AssociatedReligion:
PersonalityTrait:
- Humorless  
- Overt  
SocialTrait:
- Bossy  
MentalTrait:
- Indecisive  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[unknownBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.location)` |

# **`=this.PrimaryProfession` **<br><span style="font-size: medium">(`=this.PrimaryProfessionCategory`)</span>
> [!info|bg-c-purple]- Overview
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> TBD
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
