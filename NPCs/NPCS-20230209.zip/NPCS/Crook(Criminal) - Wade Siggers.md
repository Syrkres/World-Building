---
Art: undeadBanner01.png
Name: Wade
Surname: Siggers
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Vampire
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Grand lean build, with blue eyes and greasy black hair. Their face has a missing eye and their speech is low-pitched 
Age: Young Adult 
Condition: Healthy 
Location: 
Likes: 
 - Smithing 
 - Hand holding 
 - Open spaces 
Dislikes: 
 - Pirates 
 - Money 
 - Fishing 
 - Weapons 
Acquaintances: 
PrimaryProfession: Crook
PrimaryProfessionCategory: Criminal
Importance: 1
Occupation:
 - Crook 
AssociatedGroup:
AssociatedReligion:
PersonalityTrait:
- Overt  
SocialTrait:
- Dependable  
- Suspicious  
- Demanding  
MentalTrait:
- Courageous  
- Ambitious  
- Superstitious  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[undeadBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.location)` |

# **`=this.PrimaryProfession` **<br><span style="font-size: medium">(`=this.PrimaryProfessionCategory`)</span>
> [!info|bg-c-purple]- Overview
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> TBD
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
