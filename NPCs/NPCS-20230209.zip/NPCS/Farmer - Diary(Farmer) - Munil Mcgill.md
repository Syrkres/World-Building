---
Art: dwarvenBanner01.png
Name: Munil
Surname: Mcgill
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Hill Dwarf
Alignment: chaotic
Gender: Female
Sexuality: Bisexual 
Appearance: Tall average build, with hazel eyes and well groomed black hair. Their face has nose pierced and their speech is slured 
Age: Mature Adult 
Condition: Healthy 
Location: 
Likes: 
 - Acting 
 - Archery 
 - Loud noises 
 - Forests 
Dislikes: 
 - Loud noises 
 - Hail 
Acquaintances: 
PrimaryProfession: Farmer - Diary
PrimaryProfessionCategory: Farmer
Importance: 3
Occupation:
 - Farmer - Diary 
AssociatedGroup:
AssociatedReligion:
PersonalityTrait:
- Eccentric  
SocialTrait:
- Helpful  
- Peaceful  
MentalTrait:
- Secular  
- Impatient  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[dwarvenBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.location)` |

# **`=this.PrimaryProfession` **<br><span style="font-size: medium">(`=this.PrimaryProfessionCategory`)</span>
> [!info|bg-c-purple]- Overview
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> TBD
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
