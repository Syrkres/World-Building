---
Art: unknownBanner01.png
Name: Altham
Surname: Mcintosh
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Forest Gnome
Alignment: chaotic
Gender: Male
Sexuality: Straight 
Appearance: Squat wide build, with hazel eyes and bald white hair. Their face has large ears and their speech is breathless 
Age: Adult 
Condition: Healthy 
Location: 
Likes: 
 - Cooking 
 - Smithing 
 - Beekeeping 
 - Sudden movements 
Dislikes: 
 - Soap carving 
 - Pranks 
 - Alchemy 
Acquaintances: 
PrimaryProfession: Duke
PrimaryProfessionCategory: Noble
Importance: 19
Occupation:
 - Duke 
AssociatedGroup:
AssociatedReligion:
PersonalityTrait:
- Pessimistic  
SocialTrait:
- Dependable  
MentalTrait:
- Reckless  
- Reckless  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[unknownBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.location)` |

# **`=this.PrimaryProfession` **<br><span style="font-size: medium">(`=this.PrimaryProfessionCategory`)</span>
> [!info|bg-c-purple]- Overview
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> TBD
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
