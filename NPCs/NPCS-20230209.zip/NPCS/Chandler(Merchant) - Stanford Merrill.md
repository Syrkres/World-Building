---
Art: unknownBanner01.png
Name: Stanford
Surname: Merrill
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Deep Gnome
Alignment: chaotic
Gender: Female
Sexuality: Bisexual 
Appearance: Short weak build, with red eyes and messy blond hair. Their face is an missing ear and their speech is accented 
Age: Mature Adult 
Condition: Sick 
Location: 
Likes: 
 - Treasure hunting 
 - Mountains 
Dislikes: 
 - Chalk 
 - Silver 
Acquaintances: 
PrimaryProfession: Chandler
PrimaryProfessionCategory: Merchant
Importance: 7
Occupation:
 - Chandler 
AssociatedGroup:
AssociatedReligion:
PersonalityTrait:
- Dull  
- Optimistic  
SocialTrait:
- Talkative  
MentalTrait:
- Courageous  
- Tenacious  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[unknownBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.location)` |

# **`=this.PrimaryProfession` **<br><span style="font-size: medium">(`=this.PrimaryProfessionCategory`)</span>
> [!info|bg-c-purple]- Overview
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> TBD
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
