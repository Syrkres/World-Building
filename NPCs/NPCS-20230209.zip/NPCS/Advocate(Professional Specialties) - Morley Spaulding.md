---
Art: undeadBanner01.png
Name: Morley
Surname: Spaulding
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Revenant
Alignment: chaotic
Gender: Female
Sexuality: Gay 
Appearance: Squat anorexic build, with brown eyes and braided blond hair. Their face has a missing eye and their speech is whiny 
Age: Adult 
Condition: Sick 
Location: 
Likes: 
 - Fast rides 
 - Bird watching 
 - Gossip 
 - Cherry 
Dislikes: 
 - Mess 
 - Flashing lights 
 - Cemeteries 
Acquaintances: 
PrimaryProfession: Advocate
PrimaryProfessionCategory: Professional Specialties
Importance: 10
Occupation:
 - Advocate 
AssociatedGroup:
AssociatedReligion:
PersonalityTrait:
- Listless  
- Humble  
SocialTrait:
- Dishonest  
- Stingy  
- Talkative  
MentalTrait:
- Skillful  
- Stupid  
WhichParty: 
Party1Standing: 
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[undeadBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.location)` |

# **`=this.PrimaryProfession` **<br><span style="font-size: medium">(`=this.PrimaryProfessionCategory`)</span>
> [!info|bg-c-purple]- Overview
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> TBD
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> TBD
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
