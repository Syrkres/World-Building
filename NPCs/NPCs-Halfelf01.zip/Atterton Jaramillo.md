---
fileType: npc
Art: halfbreedBanner01.png
Name: Atterton
Surname: Jaramillo
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Elf
Alignment: CE
Gender: Male
Sexuality: Straight 
Appearance: Short athletic build, with hazel eyes and curly white hair. Their face has a distinctive nose and their speech is low-pitched 
Age: Ancient 
Condition: Out of sorts 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 9
Likes: 
    - Falconry 
    - Jewelry 
    - Leather 
Dislikes: 
    - Going outside 
    - Urban exploring 
Acquaintances: 
SpouseName: Westbrook(Wife)
SpouseAge: Mature Adult 
SpouseGender: Female
SpouseCondition: Healthy 
Parents: 
    - Hartford(Mother) Adult  Female who is Deceased
    - Blankley(Father) Elderly  Male who is Deceased
Children: 
    - Browning(Child) Child  Boy who is Healthy  
    - Mitchell(Child) Child  Boy who is Healthy  
    - Wallace(Child) Child  Girl who is At death's door  
AssociatedGroup:
    - Artisans Guild 
AssociatedReligion:
PersonalityTrait:
- Pessimistic  
- Repulsive  
SocialTrait:
- Impartial  
- Dependable  
MentalTrait:
- Impatient  
- Tenacious  
- Courageous  
PersonalGoals: Remain hidden. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
