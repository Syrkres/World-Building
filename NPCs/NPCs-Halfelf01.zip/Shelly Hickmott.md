---
fileType: npc
Art: halfbreedBanner01.png
Name: Shelly
Surname: Hickmott
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Elf
Alignment: LG
Gender: Female
Sexuality: Straight 
Appearance: Short weak build, with brown eyes and pony-tail grey hair. Their face has a moustache and their speech is nasal 
Age: Mature Adult 
Condition: Inured 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 7
Likes: 
    - Fairy tales 
Dislikes: 
    - Horse riding 
    - Rivers 
    - Gossip 
    - Mess 
Acquaintances: 
SpouseName: Yorke(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: All Right 
Parents: 
    - Pinkerton(Mother) Elderly  Female who is At death's door 
    - Windsor(Father) Elderly  Male who is Deceased
Children: 
    - Huckabee(Child) Infant  Girl who is Healthy as a horse  
    - Brent(Child) Teen  Boy who is All Right  
    - Tyndall(Child) Child  Girl who is Healthy  
AssociatedGroup:
    - Artisans Guild 
AssociatedReligion:
PersonalityTrait:
- Respectful  
- Humorless  
SocialTrait:
- Intolerant  
- Peaceful  
- Unfriendly  
MentalTrait:
- Indecisive  
- Analytical  
PersonalGoals: Go on an adventure. 
Assigned: false
---


> [!infobox]
> # `=this.name` `=this.Surname`
> **Pronounced:**  "`=this.Pronounced`"
> ![[halfbreedBanner01.png|cover hm-sm]]
> ###### Bio
>  |
> ---|---|
> **Race** | `=this.race` |
> **Sex** | `=this.gender` |
> **Age** | `=this.age` |
> **Sexuality** | `=this.sexuality` |
> **Alignment** | `=this.alignment` |
> **Condition** | `=this.condition` |
> ###### Info
>  |
> ---|---|
> **Alias(es)** | `=this.alias` |
> **Occupation(s)** | `=this.occupation` |
> **Group(s)** | `=link(this.AssociatedGroup)` |
> **Religion(s)** | `=link(this.AssociatedReligion)` |
> **Current Location** | `=link(this.Kingdom)` `=link(this.Region)` / `=link(this.Settlement)` |

# **`=this.PrimaryOccupation` **<br><span style="font-size: medium">(`=this.PrimaryOccupationCategory`)</span>
> [!info|bg-c-purple]- Appearance
`=this.Appearance`

> [!column] Traits
>> [!metadata|text-Center bg-c-gray] Personality
>> `=this.PersonalityTrait`
>
>> [!metadata|text-Center bg-c-gray] Social
>> `=this.SocialTrait`
>
>> [!metadata|text-Center bg-c-gray] Mental
>> `=this.MentalTrait`
>
>> [!metadata|text-Center bg-c-gray] Likes/Dislikes
>> **Likes:** `=this.Likes`
>>
>> **Dislikes:** `=this.Dislikes`

> [!column|dataview] Goals
>> [!metadata|text-Center bg-c-yellow]- Personal
>> `=this.PersonalGoals`
>
>> [!metadata|text-Center bg-c-yellow]- Professional
>> TBD
>

## Acquaintances
> [!column|dataview] Acquaintances
>> [!metadata|text-Center bg-c-green]- Friends & Family
>> **Spouse:** `=this.SpouseName ` `=this.SpouseAge` `=this.SpouseGender ` `=this.SpouseCondition `
>> **Children:** `=this.children`
>> **Parents:** `=this.parents`
>
>> [!metadata|text-Center bg-c-red]- Rivals
>> TBD
>

## History
TBD

## DM Notes
### Plot Hooks


### Hidden Details


### General Notes
