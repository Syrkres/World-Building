---
fileType: npc
Art: halfbreedBanner01.png
Name: Crawford
Surname: Belsey
Pronounced: 
Alias: 
NoteIcon: Character
Type:
    - NPC
Race: Half-Elf
Alignment: CE
Gender: Female
Sexuality: Straight 
Appearance: Extra tall frail build, with hazel eyes and braided brown hair. Their face has a patch over right eye and their speech is low-pitched 
Age: Adult 
Condition: Well 
kingdom: 
region: 
settlementName: 
wardName: 
Location: () / ()
PrimaryOccupation: No-Profession
PrimaryOccupationCategory: No-Category
Occupation: No-Profession
Importance: 2
Likes: 
    - Drama 
    - Repairing items 
    - Pirates 
    - Riddles 
Dislikes: 
    - Juggling 
    - Sudden movements 
    - Throwing rocks 
    - Weapons 
Acquaintances: 
SpouseName: Walcott(Husband)
SpouseAge: Adult 
SpouseGender: Male
SpouseCondition: Ailing 
Parents: 
    - Addington(Mother) Elderly  Female who is Deceased
    - Churchill(Father) Elderly  Male who is Deceased
Children: 
    - Garrick(Child) Young Adult  Boy who is Impaired  
    - Quinton(Child) Infant  Boy who is Inured  
AssociatedGroup:
    - Syndicate 
AssociatedReligion:
PersonalityTrait:
- Respectful  
SocialTrait:
- Stingy  
- Impartial  
- Generous  
MentalTrait:
- Cautious  
- Superstitious  
- Patient  
PersonalGoals: Make a sacrifice for the greater good. 
Assigned: false
---
