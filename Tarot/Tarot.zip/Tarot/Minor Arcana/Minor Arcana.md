# Minor Arcana

```dataview
table without id file.link as "Card", synopsis as "Signifies"
from ""
where fileType="Tarot" and tarotType="Minor" 
sort  suite
```