# Major Arcana

```dataview
table without id file.link as "Major Card"
from ""
where fileType="Tarot" and tarotType="Major"
```