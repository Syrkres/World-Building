---
fileType: Cosmos
cosmosName: Eldanoth
cosmosType: Demon Lord
---
# Eldanoth, The Silent Death
Demon Lord of Murder  
Augmented Gloom 10th level Assassin, 10th level Blackguard (_Chaotic, Evil, Extraplanar_)  

Hit Dice: 25d8 plus 10d6 (Assassin) plus 10d10 (Blackguard) plus 450 (810 hp)  
**Initiative:** +22 (+18 Dex, +4 Improved Initiative)  
**Speed:** 40 ft.  
**AC:** 46 (+18 Dex, +12 insight, +6 profane), 46 touch, 46 flat-footed  
**Face/Reach:** 5 ft./5 ft.  
**Base Attack:** +35/+45  
**Attacks:** _Eldanoth’s Dagger_ +59 melee or +45 melee touch or +53 ranged touch  
**Full Attack:** _Eldanoth’s Dagger_ +59/+54/+49/+45 (1d4 plus +15 plus +2d6 unholy plus +1 (vile) plus 1 negative level/17-20/x2 plus +2 (vile) plus 2 negative levels) melee or unarmed strike +45 (1d4 plus +10 plus +1 (vile) plus poison (Fort save DC 32 or 1d8 Con primary damage, 2d8 Con secondary damage)) or +45 melee touch or +53 ranged touch  
**Special Attacks:** Death attack (Fort save DC 46), Fear gaze, Homicidal Incitement, Ravaged Form (Finger Serpents), sneak attack +24d6, spells, spell-like abilities, vile smite 3/day (+12 atk, +20 vile damage), rebuke undead 15/day  
**Special Qualities:** Blindsight 60 ft., Demon Lord qualities, immunities (poison, electricity), improved uncanny dodge, Master of Murder, opportunist, quiescence, Ravaged Forms, resistances (fire, cold, acid) 10, rebuke/command undead 15/day, spell-like abilities, SR 47, DR 20/good, silver and bludgeoning  
**Saves:** Fort +35, Ref +49, Will +38  
**Abilities:** Str 30, Dex 46, Con 30, Int 29, Wis 26, Cha 34  
**Skills:** Balance +16, Bluff +38, Climb +30 (+34 with rope), Diplomacy +15, Disable Device +14, Escape Artist +30 (+34 escape bindings), Gather Information +30, Hide +46, Knowledge (the planes) +18, Intimidate +52, Jump +32, Listen +48, Move Silently +66, Open Lock +20, Sense Motive +23, Sleight of Hand +14, Spot +35, Survival +35 (+37 extraplanar), Tumble +20, Use Magic Device +48, Use Rope +13 (+17 bindings)  
**Feats:** Cleave, Dodge, Improved Critical (dagger), Improved Initiative, Improved Sunder, Power Attack, Weapon Finesse, Weapon Focus (dagger), Vile Natural Attack (B)  
**Epic Feats:** Great Smiting, Improved Aura of Despair, Sneak Attack of Opportunity, Undead Mastery, Unholy Strike, Vile Smite, Zone of Animation, Widen Aura of Despair  
**Climate/Terrain:** The Murder Palace (Layer 387 in the Abyss)  
**Organization:** Solitary  
**Challenge Rating:** 39  
**Treasure:** _Eldanoth's Dagger_, a _+5 souldrinking, vile, dagger of returning_, triple standard  
**Alignment:** Chaotic Evil  
**Advancement:** N/A  

Eldanoth is a former vassal of the Demiurge of Undeath, Orcus. A lord of criminals and inspirer of criminal behavior, despite his own power, he fears the vengeance of his former master.  

Centuries ago was born a Gloom unique among his kind. Known throughout the planes as some of the most competent assassins throughout the planes; they nevertheless had a single rule-they killed for hire although the life of anyone in the way of a target was equally forfeit. In comparison, this particular Gloom simply loved killing, and would kill without payment or without anything even remotely approximating an assignment.  

A psychotic outcast, this particular Gloom was hunted throughout the planes, but was always able to remain one step ahead of the members of it’s own species that attempted to slaughter it, eliminating the creature that refused to merely be a mercenary and instead embraced the giving of death for the sheer enjoyment of it.  

Eventually, a long-forgotten minion of Orcus discovered this creature after it had killed the being that Orcus had assigned him to kill, but before he could kill the creature himself he found himself being pulled back to Thanatos. With no other course of action it could see, the failing vassal placed the Gloom in temporal stasis and brought it back to Orcus.  

When Orcus found out about the failure of the minion, he exploded in rage. Then, he made sure that the minion also exploded. Even while the chunks of gore were still dripping off of the Gloom’s body, Orcus had decided what to do with him.  

_Eldanoth_, you shall be the only one....Orcus whispered. _Annihilate your kind or end up like him._  

And so Eldanoth went about his tasking, killing off the rest of his entire race of assassins and waging a silent war in the darkness. His permanent rictus grin of a smile is said to have grown a little bit larger across his eyeless face as his own kind, never common, were hunted to near extinction through his own efforts. The name that Orcus gave him, Eldanoth, spread across the planes, along with a trail of mass homicides and mountains of corpses.  

For hundreds of years afterwards, as a result, Eldanoth brought silent, bloody death to all foes of the Demiurge of Undeath.  

Eldanoth became a power in his own right during the period of time in which his former master, Orcus, had been killed by Kiaransalee. Well aware of the fact that in a battle between him and Kiaransalee he would be no match, he seized upon the opportunity, personally slew those servitors that he knew to be more loyal to Orcus than they would be to himself and betray him in turn, and fled from Thanatos before Kiaransalee could catch up with him during the period while she was busy consolidating her power. Shortly afterwards, he set himself up as the Lord of The Murder Palace, the layer he currently controls as best as it can be said that anyone controls it.  

Since Orcus’ return to undeath, however, Eldanoth knows that the vengeance of The Goat will eventually come. To try and stay the claw of his former master, he has become a Demon Lord for hire, offering his services as an elite assassin in exchange for spells and artifacts that he hopes will prevent Orcus from finding him and doing unspeakable things to his body both before and after death. As such, he has repeatedly done jobs for both Lolth (using several of her thralls as intermediaries to conceal her own involvement) and Graz’zt and may eventually accept Lolth’s offer of ‘relocation’ to an alternate Material Plane, where he could wreak as much havok as he wanted. This, in turn, would further ensnare him with Lolth...which, of course, is precisely what she wants. Whether either of them will actually help Eldanoth when Orcus decides to take revenge is, not surprisingly, very much in doubt.  

Eldanoth has additionally, using astral projection to reach other planes, initiated murder-cults on various worlds, hoping that in this way he could gain more power for himself and increase the number of slaves and undead which serve him. At this particular tasking he has been successful, and should he manage to become a Demon Prince he will bring even more death than he already has across existence.  

Eldanoth is approximately six feet tall, clothed in a black, rubbery robe from his neck down to his feet, leaving little exposed except for the bony nearly-skeletonized hands on his arms. His head is an elongated and nightmarish thing, eyeless and with a oversized gash of a mouth too long for his face filled with needle-sharp fangs in an eternally fixed smile. His telepathic voice is a smooth, sibilant whisper, the voice of death itself sliding as smoothly and seamlessly into your mind as his dagger slices into flesh, and the only time he speaks is to utter blasphemous words to all that is not a mirror of his own relentless evil.  

Eldanoth’s demesne is a realm that drives all who enter it into a paranoid, bloodthirsty living nightmare, a sunless city where the barred windows and doors are incapable of protecting individuals from the most dangerous feature of this realm-namely, each other. The screams of the dying and the eternal clangor of murders and crimes too horrible to mention echo through the realm, while rotting corpses pile up in the streets filled with shambling undead, victims of the murderous impulses of the residents, as everyone present is too frightened to attempt to dispose of any of them.  

**Combat:** Eldanoth is typically accompanied by a small army of skeletons, zombies, and mummies, the animated remains of the creatures that he has killed previously. He will always send his undead in advance of him while he creates darkness and uses _shadow walk_ in order to sneak up behind opponents and stab them to death. If facing a group, he will use his spells in order to break up groups, and particularly relishes using Homicidal Incitement on good-aligned characters. If overmatched he will use _time stop_, summon a Balor, and then teleport away.  

**Ravaged Form-Emaciated (Ex):** Eldanoth is skeletally thin when he is seen underneath his robes...which he almost never is. As a result, Eldanoth has –2 Str, +2 Int, and adds bludgeoning to his DR list.  

**Ravaged Form-Finger Serpents (Ex):** Eldanoth’s fingers are tiny, living serpents whose size belies the fact that they are capable of injecting a potent venom into any wound that Eldanoth inflicts. Creatures hit by Eldanoth’s unarmed strikes must make a Fort save DC 32 or else take an initial 1d8 Con damage and secondary 2d8 Con damage from the potent venom constantly secreted by them.  

**Ravaged Form-Magical Power (Sp):** Once a day, Eldanoth may choose to appear to all creatures around him in a 30 foot radius as a physical incarnation of every creature that they have killed or let die...particularly if such death was wrongful in nature. (Treat as a _weird_ spell cast at 31th level).  

**Ravaged Form-Magical Power (Sp):** Once a day, Eldanoth may use _astral projection_ as the spell.  

**Spell-like abilities (Sp):** at will: _blasphemy, create undead, deeper darkness, detect law, detect good, greater dispel magic, harm, invisibility_ (greater), _shadow walk, spider climb, serpents of theggeron, unhallow, unholy aura, unholy blight, wall of force, wrack._ 6/day: _brain spider, destruction, greater teleport._ 3/day: _implosion, true strike_ 1/day: _discern location, hold person_ (mass), _shapechange._ 1/week: _plague of nightmares, ruin, time stop._ Cast at 31st level. Saving throw DC’s 22+spell level. The saving throws are Charisma-based.  

**Summon Demons (Sp):** Eldanoth is capable of summoning Demons, although he prefers not to out of the fear that they may be spies for The Goat. Typically he will summon several succubi (of which he can bring forth 5 at once), for their ability to distract foes with their stunning appearance while he approaches and kills them, or 2 glabrezu. If desperate and in need for some destruction to cover his escape, he will call a Balor instead. Eldanoth may summon up to 30 HD once a day.  

**Demon Lord Qualities (Ex):** Eldanoth is immune to electricity and poison; he possesses cold, fire, and acid resistance 10\. Eldanoth may engage in telepathic communication with any creature within 100 feet. Eldanoth constantly detects good and detects magic as a 21st level Sorcerer; he possesses immunity to polymorphing, petrification, or any other attack to alter his form.  

**Aura of Despair (Su):** Eldanoth radiates a malign aura that causes all within 10 feet of him to take a –4 penalty on all saving throws.  

**Blackguard Spells/day (Sp) (1st-4th level): 4/4/4/3.** Eldanoth casts his Blackguard spells at 28th level. Saving throws against Eldanoth’s Blackguard spells is DC 18 + spell level. The saving throw DC’s are Wisdom-based.  

**Command Undead (Su):** Eldanoth may command and rebuke undead as an 8th level cleric.  

**Fear Gaze (Su):** Viewing Eldanoth’s face inspires terror. Creatures that meet his hideous, eyeless gaze must succeed at a Will save (DC 44) or suffer the effects of a _fear_ spell as cast by a 20th-level caster. The DC is Charisma-based.  

**Quiescence (Su):** Eldanoth is constantly silent, as per the _silence_ spell, although the area does not extend beyond him. This quality gives Eldanoth a +20 racial bonus on Move Silently checks (it is still possible for him to create noise, such as by bumping into something that scrapes on the floor or by sounding a chime). He can lower this effect at will.  

**Assassin Spells/day (Sp) (1st-4th level): 5/5/5/5 Spells known:** 1st level: _angry ache, disguise self, jump, feather fall_. 2nd level: _cat’s grace, pass without trace, undetectable alignment_. 3rd level: _deep slumber, magic circle against good, misdirection, nondetection_. 4th level: _dimension door, clairaudience/clairvoyance, freedom of movement, poison_. Eldanoth casts his Assassin spells at 28th level. The saving throws against Eldanoth’s Assassin spells are DC 19 + spell level. The DC is Intelligence-based.  

**Homicidal Incitement (Su):** Twelve times a day, Eldanoth may telepathically command any creature that he sees to kill the one individual that they despise the most. Potential victims must make a Will save DC 44\. Victims that fail the saving throw become completely obsessed with murdering this one individual and are constantly burdened with the knowledge of where this individual is (treat as a _discern location_ spell cast at 45th level). They will do nothing but hunt down the individual that they most despise and any day that they fail to hunt down the individual that they hate the most, they take 4d6 vile damage and are nauseated until they take up the search for this single individual again. Should they succeed in killing their target, they become permanently dominated by Eldanoth, his living weapons for spreading chaos and death throughout existence.  

The subtle viciousness of Eldanoth’s Homicidal Incitement is that it invariably tells it’s victims exactly what the worst part of their minds want to hear-that the person that they most despise is so worthless that unrestrained butchery is the best they deserve. For this reason, it has been the cause of many previously good individuals going astray and ending up in the Abyss, as their formerly holy quests turn into nothing but bloodstained personal vendettas, and their focus changes from slaying evil beings because of their misdeeds, to slaying them just for the personal satisfaction of seeing something die.  

Individuals can be liberated from Eldanoth’s control by having a _wish_ or _miracle_ cast on them by a 21st level caster or higher, followed by an _atonement_ spell. 