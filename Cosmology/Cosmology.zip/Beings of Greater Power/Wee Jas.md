---
fileType: Cosmos
cosmosName: Wee Jas
cosmosType: Intermediate Deity
---
# Wee Jas
The Witch Godess, The Ruby Sorceress, The Stern Lady, Death’s Guardian  
**Intermediate Deity**
Symbol: Red skull wreathed in flame  
**Home Plane:** Archeron  
**Alignment:** Lawful Neutral  
**Portfolio:** Death, Magic, Vanity, Law  
**Cleric Alignments:** LE, LG, LN  
**Domains:** Death, Law, Magic  
**Favored Weapon:** Dagger  

Wizard 25/Cleric 25/Mystic Theurge 10  
Medium-Size Outsider  
Divine Rank: 15  
**Hit Dice:** 25D4 (wizard) + 25d8 (cleric) + 10d4 (mysT) +480 (880 hp)  
**Initiative:** +16 (+12 Dex, +4 improved initiative)  
**Speed:** 60 ft.  
**AC:** 81 (+12 Dex, +15 divine, +30 natural, +14 deflection)  
**Base Attack/Grapple:** +30/+53  
**Attacks:** _Discretion_ +67 melee, +53 melee touch or +57 ranged touch  
**Full Attack:** _Discretion_ +67/+62 (1d4+18 +3d6 lawful 17-20/x2 +6d6 lawful) melee, +53 melee touch or +57 ranged touch  
**Face/Reach:** 5 ft. by 5ft./5 ft.  
**Special Attacks:** domain powers, salient divine abilities, spell-like abilities  
**Special Qualities:** Divine Immunities, DR 25/epic and silver, Godly Communication, Godly Realm, SR 77, Divine Aura (1500’ DC 39), Immune to fire and cold, Resistance to acid 20, summon familiar, rebuke undead 25/day (1d20+33, +4 synergy; 2d6+39).  
**Saves:** Fort +49, Ref +53, Will +65  
**Abilities:** Str 26, Dex 35, Con 26, Int 54, Wis 47, Cha 39.  
**Skills*:** Appraise +68 (31 ranks, +4 related to craft), Bluff +61 (32 ranks), Concentration +84 (63 ranks), Craft (papermaking) +100 (63 ranks), Craft (bookbinding) +100 (63 ranks), Decipher Script +87 (50 ranks), Diplomacy +81 (44 ranks, +8 synergy), Disguise +61 (32 ranks, +4 to act in character), Escape Artist +59 (32 ranks), Gather Information +68 (31 ranks), Heal +77 (44 ranks), Intimidate +65 (32 ranks, +4 synergy), Knowledge (arcana) +100 (63 ranks), Knowledge (history) +95 (58 ranks), Knowledge (religion) +100 (63 ranks), Knowledge (the planes) +95 (58 ranks), Knowledge (undead) +82 (45 ranks), Listen +65 (32 ranks), Move Silently +60 (31 ranks), Profession (herbalist) +94 (63 ranks), Profession (scribe) +94 (63 ranks), Search +68 (31 ranks), Sense Motive +70 (37 ranks), Spellcraft +104 (63 ranks, +4 synergy), Spot +65 (32 ranks). _*always rolls 20 on checks_  
**Feats:** Brew Potion, Craft Rod, Craft Staff, Craft Wand, Craft Wondrous Item, Empower Spell, Enlarge Spell, Extend Spell, Extra Turning (x2), Forge Ring, Greater Spell Penetration, Heighten Spell, Improved Initiative, Maximize Spell, Reach Spell, Scribe Scroll (b), Silent Spell, Spell Penetration, Still Spell, Twin Spell, Weapon Finesse (dagger).  
**Epic Feats:** Enhance Spell, Epic Spell Penetration, Improved Heighten Spell, Improved Metamagic (x2), Intensify Spell, Multispell.  
**Divine Immunities:** Ability Damage, ability drain, cold, death effects, disease, disintegration, energy drain, fire, mind-affecting effects, paralysis, poison, sleep, stunning, transmutation, imprisonment, banishment.  
**Salient Divine Abilities:** Alter Form, Arcane Mastery, Automatic Metamagic (quicken cleric spells), Automatic Metamagic (quicken wizard spells), Clearsight, Craft Artifact, Divine Dodge, Divine Shield, Divine Spell Focus (necromancy), Divine Spellcasting, Energy Storm (negative energy), Energy Strom (positive energy), Hand of Death, Instant Counterspell, Know Death, Life and Death (no rest time), See Magic, Spontaneous Wizard Spells.  
**Domain Powers:** 15/day _death touch_ (roll 25d6; if subject touched does not have as many hp’s, it dies), Cast Law spells at +1 caster level.  
**Spell-Like Abilities:** Wes Jas uses these abilities as a 75th level caster except for the Law domain which she casts as a 76th level caster. The save DC’s for these spells are 49 +spell level (64 +spell level for necromantic spells). _at will_ **1st –** _cause fear, nystul’s magic aura, protection from chaos;_ **2nd –** _calm emotions, death knell, identify;_ **3rd –** _animate dead, dispel magic, magic circle against chaos;_ **4th –** _death ward, imbue with spell ability, order’s wrath;_ **5th –** _dispel chaos, slay living, spell resistance;_ **6th –** _antimagic field, create undead, hold monster;_ **7th –** _destruction, dictum, spell turning;_ **8th –** _create greater undead, protection from spells, shield of law;_ **9th –** _mordenkainen’s disjunction, *summon monster IX, wail of the banshee. *cast as a law spell only_  
**Cleric Spells per Day:** (6/11/11/10/10/10/9/8/8/8/4/3/3/3/3/2/2/2/2; Caster Level 50th/51st for Law spells; DC 47 +spell level/DC 62 +spell level for necromantic spells)  
**Wizard Spell per Day** (4/10/10/9/9/9/9/8/8/8/5/4/4/4/4/3/3/3/3/2/2/2/2; Caster Level 50th/51st for law spells; DC 54 +spell level/DC 69 +spell level for necromantic spells)  
**Challenge Rating:** 58  
**Possessions:** Wes Jas carries _Discretion_ a _+10 lawful power ghost touch keen dagger_.  

**Other Divine Powers**  

**Alter Reality**  
Wee Jas can use wish with regard to her portfolio, save for the replication of other spells. This ability costs the deity no XP, and requires a standard action to implement.  
Wee Jas has full access to the abilities described in the Alter Size SDA.  
Wee Jas may create an avatar as described in the Avatar SDA.  

Wee Jas also gains the following benefits:  
Wee Jas adds her Intelligence modifier (+22) or Wisdom modifier (+18) again for determining spell DC’s.  

Wee Jas may also do the following up to 15/day: add her Charisma modifier (+14) to her spellcaster levels for purpose of determining damage, range, SR checks, # of targets, etc.  

**Senses:** Wee Jas can see, hear, touch, and smell at a distance of fifteen miles. As a standard action, Wee Jas can perceive anything within fifteen miles of her servants or worshippers, holy sites, objects, or any location where one of her titles or name was spoken in the last hour. He can extend her senses up to 10 locations at once.  

**Portfolio Sense:** Wee Jas senses any death the instant it happens and retains the sensations for fifteen weeks after the event occurs.  

**Automatic Action:** Wee Jas can use Alchemy, Craft (papermaking), Craft (bookbinding), Knowledge (arcana), Knowledge (history), Knowledge (religion), Knowledge (the planes), Knowledge (undead), Profession (herbalist), Profession (scribe), or Spellcraft as a free action if the DC for the task is 25 or lower. She can perform up to ten such free actions in a round.  

**Create Magic Items:**Wee Jas can create any magic item of any kind so long as the item’s value does not exceed 200,000 gp  

* * *

A great creation of [DiceFreaks](http://community.dicefreaks.com/) and copied here for reference.
