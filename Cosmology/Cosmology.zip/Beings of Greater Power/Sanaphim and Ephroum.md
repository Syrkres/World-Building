---
fileType: Cosmos
cosmosName: Senaphim and Ephroum
cosmosType: Demon Atrocity
---
# Senaphim and Ephroum (CR 33)  
**Demonic Atrocity**  
CE Large Outsider (Chaotic, Evil, Extraplanar, Fallen)  
**Init** +20; **Senses** Listen +50, Spot -, blindsight 60 ft., darkvision 60 ft., lowlight vision  
**Aura** chaotic evil, aura of loss DC 32, magic circle against good; **Languages** Speaks via telepathy  
_____________________________________________________________  

**AC** 42, touch 21, flat-footed 34 (-1 size, +8 Dexterity, +21 natural, +4 profane), Dodge, Mobility  
**hp** 672 (42d8+336), regeneration (15/epic and good); **DR** 20/epic and cold iron and good  
**Immune** acid and poison  
**Resist** cold 25, electricity 25, fire 25; **SR** 53  
**Fort** +31 (+35 vs petrification), **Ref** +31, **Will** +36  
_____________________________________________________________  

**Speed** 110 ft. (22 squares)  
**Melee** Phthave +50/+45/+40/+35 melee (6d6+24 + 3d6 + 1 negative level + 1 Con + 1 vile/19-20/x2 + 6d6 + 2 negative levels + 1 Con + 1 vile)  
**Melee** 4 slams +44 melee (2d8+12 + 1 vile)  
**Space** 10 ft.;**Reach** 10 ft.  
**Base Atk** +32; **Grp** +48  
**Atk Options** Cleave, energy drain 2, Power Attack, soul blast, Vile Natural Attack  
**Special Actions** Magic circle against good  
_____________________________________________________________  

**[Arcane] Spells Prepared** (CL 32nd)  
9th (1/day)—  
8th (2/day)—  
7th (4/day)—  
6th (5/day)—  
5th (5/day)—  
4th (5/day)—  
3rd (6/day)—  
2nd (7/day)—  
1st (7/day)—  
0th (6/day)—  

**Spells** Senaphim and Ephroum cast arcane spells as 30th-level sorcerers (caster level as a 37th-level sorcerer)  

**Spell-Like Abilities** (CL 37th)  
Always active – _detect good_  
At will – _animate objects, bestow curse, cause fear, contagion, continual flame, death knell, dimensional anchor, greater dispel magic, imprisonment, invisibility (self only), polymorph (self only), resist energy, speak with dead, summon monster VII, unholy blight, waves of fatigue_  
3/day – _blade barrier, disintegrate, earthquake, harm, mass charm monster, permanency, waves of exhausation_  
1/day – _destruction, power word blind, power word kill, power word stun, prismatic spray, wish_  
_____________________________________________________________  

**Abilities** Str 35, Dex 27, Con 27, Int 29, Wis 24, Cha 33  
**SQ** Change shape, cursed, darkvision 60 ft., divine spell resistance 20, lowlight vision, rebuke undead, siphon spell power, soul agility, soul endurance, soul enhancement, soul power, soul radiance, soul slave, soul strength, steal spell-like ability, telepathy 100 ft., teleport  
**Feats** Alertness, Dark Speech, Dodge, Cleave, Improved Initiative, Iron Will, Malign Spell Focus, Mobility, Power Attack, Spell Focus (Evil), Vile Natural Attack, Weapon Focus (slam)  
**Epic Feats** Epic Devotion (good), Epic Will, Superior Initiative  
**Skills** Appraise +13 (+20 potions and elixirs), Balance +22, Bluff +34, Climb +29, Concentration +51, Craft (alchemy) +33, Craft (gem cutting) +33, Diplomacy +34, Disguise +33 (+37 when acting in character), Escape Artist +22, Gather Information +33, Hide +29, Intimidate +57, Jump +31, Knowledge (arcana) +48, Knowledge (the Planes) +42, Knowledge (religion) +48, Listen +50, Move Silently +31, Perform (oratory) +15, Search +34, Sense Motive +37, Spellcraft +31, Tumble +33  
**Possessions** Phthave _+6 unholy power marrowcrushing vile greatsword_ _____________________________________________________________  

**Organization** Solitary  
**Environment** The Infinite Layers of the Abyss  
_____________________________________________________________  

**Ravage - Ability Boost (Aborrent):** Senaphim and Ephroum have increased their Charisma ability scores by +4.  

**Ravage - Aura of Loss (Su/Vile):** As per the sorrowsworn demon’s ability of the same name. Will save DC 32.  

**Ravage - Blindsight (Vile):** Senaphim and Ephroum gain blindsight out to 60 ft.  

**Ravage - Breath Weapon (Vile):** Senaphim and Ephroum may unleash a gout of unholy energy in the form of a jet of life-leeching ash, dealing 14d10 points of damage.  

**Ravage - Improved Movement Speed (Vile):** Senaphim and Ephroum are exceptionally fast, making their base land speed 110 ft.  

**Ravage - Profane Bonus to AC (Vile):** Senaphim and Ephroum gain a +4 profane bonus to AC.  

**Ravage - Ranged Energy Attack (Vile):** Senaphim and Ephroum may unleash a missile of wailing spirits, dealing 10d10 points of unholy damage.  

**Warp - Regeneration:** Senaphim and Ephroum possess regeneration 15/epic and good.  

**Ravage - Stupefying Gaze (Su/Vile):** As per the ethergaunt's ability of the same name. Will save DC 32.  

**Ravage - Whispers of Loss (Su/Vile):** As per the sorrowsworn demon’s ability of the same name. Will save DC 32.  

**Phthave** A gift from Asha, this greatsword of modest appearance has a black lily leaf forming the cross guard while the unadorned black blade seemingly drinks in the light. Phthave strikes as a Gargantuan greatsword, dealing a base damage of 6d6\. Phthave cannot be disarmed by any means.  

* * *

A great creation of [DiceFreaks](http://community.dicefreaks.com/) and copied here for reference.



**Appearance:**  
Out of the haze appears a solitary figure. It would appear normal were it not for the unsettling undulating motion of its ambulation. Its joints contort at odd angles, in spite of this, it appears to move quickly, already covering an incredible distance. A whispering, soothing and sinister, always there, impossible to ignore accompanies it. It stops in front of you, cocking its head to one side in a bird-like fashion.  

The figure is utterly naked, though its gender cannot be discerned. Its flaky skin continuously molts as it stares with eyes that leak black pus. Despite this, it appears to study your body language, noting any hostility or lack of. The figure is clothed in filth, and large gaping, gangrenous wounds dot its body at irregular intervals.  

It raises its arms in supplication, increasing the volumes of its whispering. It snaps its head back, a jarring crack felt in every part of your body. It swivels its head towards you again, staring at you with blank, lifeless eyes. Something is wrong. The whispering stops. You scream endlessly, uncontrollably, beating your chest in impotence as the beating of your hearts slows and then finally stops. The last thing you see are not one but two figures, joined at the hips, standing on two pairs of legs, seeming to hold each other.  

**History:**  
The once glorious Senaphim and Ephroum were once mighty servants of Kshathra Vairya. Once. No more. The tale of their fall is a sad one, a study in despair and misplaced intention. They were once truly beautiful, a brother and sister ophanim pair that loved each other as dearly as they loved any other. It was this love, this singular passion that would prove to be their undoing.  

Senaphim and Ephroum were once patrons of sibling love and the bond between brothers and sisters. Theirs was often an easy task, as few siblings intentionally harmed the other. The few who did were more often than not manipulated by fiends and were not blameless. This was to be expected, the hearts and minds of mortals were as puppets to the sinister puppeteers that controlled them.  

Evil was a blemish, a stain upon a perfect ideal. Sin would be wiped from the Cosmos, and they would be the ones who would administer the light from on high. Their love for each other empowered them, enveloped them and harmonised them. They were as one. Their desire and need for each other eventually lead to the consummation of that love. They became one. And so sin crept into the heart and mind of Senaphim and Ephroum.  

They now put themselves first and the plight of others a distant second. They would steal away from their duties and consummate their love over and over. Again and again. Their passion was unquenchable, their love inexhaustable. Their charges mattered little, and many siblings fell away into the darkness, turning on each other, doing harm to the other, even sometimes murdering the other.  

It is unknown how they concealed their corrupted natures, but since the number of betrayals committed by siblings on and to the other stayed quite low, their evil hid itself quite well. It was their natures that drew them to the camp of Eblis, Beelzebul and Belial. Mortals did not deserve their protection, being so much uglier than they, so much more unintelligent than they, so much inferior in every single way.  

It was the _Great Fall_ that revealed their true natures, their real selves. They delighted in torture and mayhem and especially prized angelic targets above all else, appreciating the celestial resilience. They would often consummate their love afterwards. So shocking was their evil that they were one of the first to be cast down, not into the Hells, but into the Abyss.  

Disgusted and outraged at what had transpired, Kshathra Vairya fused them into twin halves of a whole. They still had separate upper bodies but were fused at the groin and only had one pair of legs.  

**Nature:**  
Senaphim and Ephroum possess a manical need for causing grief and suffering to siblings. The more physically violent the act the better. Once stalwart defenders of brotherly or sisterly love, their hatred for such love now knows no bounds. Their fury at what the Heavens did to them flares hotter than any sun. They would make the Heavens pay, they would make everyone pay.  

**Organisation:**  
Senaphim and Ephroum welcome any chance to taint or destroy the love between siblings. They do not care who comes to them, nor who willingly become their servants nor do they care how such acts come about, so long as the desired result is achieved.  

**Relations to other Powers:**  
Solitary and loners by nature, the still beautiful Senaphim and Ephroum still gather their fair share of interest. Graz'zt in particular would like for the two to become members of his harem. The fallen ophanim have not yet acceded to Graz'zt's invitations. They have limited interactions with the other Abyssal powers but view all celestial forces with intense hatred.  
