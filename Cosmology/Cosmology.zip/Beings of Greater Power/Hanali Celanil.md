---
fileType: Cosmos
cosmosName: Hanali Celanil
cosmosType: Intermediate Deity
---
# Hanali Celanil
The High One, Patron of Mages, Lord of Spells  
**Intermediate power** - Elven Deity  
**Symbol:** Golden horned,blue eyed unicorns head facing left  
**Home Plane:**  

**Alignment:** CG  
**Portfolio:** Love, romance, beauty, fine art and artists  
**Worshippers:** Lawful good, neutral good, chaotic good, lawful neutral, neutral, chaotic neutral  
**Cleric Alignments:** CG, CN, NG  

**Domains:** Chaos, charm, domination, good, elf ,magic, protection  
**Favored Weapon:** A shining heart (dagger)  

**Gender:** Female  

**Relationships:** One of the triune goddesses that make up Correllon’s consort Angarraddh.  

**Titles** The Heart of Gold, Winsome Rose, Archer of Love, Kiss of Romance, Lady Goldheart  

**Allies:** Eilistraee, Cyrrollallee, Isis, Llura, Lurue, Milil, Sharess, Sheela Peryroyal, Sune, Tymora  

**Enemies:** Bane, Cyric, Shar, Talona the deities of Fury (Auril, Malar, Talos and Umberlee), the drow pantheon (except Eilistraee)  

Enchanter 20/Cleric 20  
Medium-size outsider (Chaos, Good)  
**Divine Rank:** 15  
**Hit Dice:** 20d8+120 (outsider) + 20d4+120 (Enc) + 20d8+120 (Clr) (760 hp)  
**Initiative:** +15 (+11 Dex, +4 Improved Initiative)  
**Speed:** 60 ft.  
**AC:** 79 (+11 Dex, +15 divine, +28 deflection, +15 natural)  
**Attacks:** +5 keen, defending, dispelling, spell storing shining heart +72/+67/+62/+57 melee or +72 ranged; or spell +62 melee touch or +66 ranged touch.  
**Damage:** +5 keen, defending, dispelling, spell storing shining heart 1d4+12/15-20; or by spell.  
**Face/Reach:** 5 ft. by 5 ft./5 ft.  
**Special Attacks:** Domain powers, salient divine abilities, spell-like abilities, turn undead 22/day.  
**Special Qualities:** Gold elf racial abilities, divine aura (1,500 ft., DC 40), divine immunities, DR 50/+4, familiars (cats), fire resistance 35, godly realm (10 miles Outer Plane, 1,500 ft. Material Plane), plane shift at will, remote communication 15 miles, spontaneous casting of divine spells, SR 47, teleport without error at will, understand, speak and read all languages and speak directly to all beings within 15 miles.  
**Saves:** Fort +53, Ref +58, Will +57  
**Abilities:** Str 24, Dex 33, Con 22, Int 35, Wis 31, Cha 40  
**Skills:** Alchemy +67, Appraise +67, Bluff +74, Concentration +61, Craft (calligraphy) +67, Craft (painting) +67, Craft (pottery) +67, Craft (weaving) +67, Decipher Script +67, Diplomacy +74, Forgery +67, Gather Information +72, Heal +67, Innuendo +65, Intimidate +74, Knowledge (arcana) +67, Knowledge (history) +67, Knowledge (nobility and royalty) +67, Knowledge (religion) +67, Listen +65, Perform +70, Profession (herbalist) +65, Profession (jeweller) +67, Scry +67, Search +67, Sense Motive +65, Spellcraft +67, Spot +65.  
**Feats:** Alluring, Brew Potion, Combat Casting, Craft Magic Arms and Armour, Craft Rod, Craft Staff, Craft Wand, Craft Wondrous Item, Dodge, Eschew Materials, Expertise, Extra Turning, Forge Ring, Greater Spell Focus (Enchantment), Improved Critical (shining heart), Improved Initiative, Persuasive, Point Blank Shot, Reach Spell, Sacred Spell, Scribe Scroll, Spell Focus (Enchantment), Subdual Substitution, Superior Expertise, Trustworthy, Weapon Finesse (shining heart), Weapon Focus (shining heart).  

**Divine Immunities:** Ability damage, ability drain, acid, cold, death effects, disease, disintegration, electricity, energy drain, mind-affecting effects, paralysis, poison, sleep, stunning, transmutation, imprisonment, banishment.  
Salient Divine Abilities: Alter Form, Alter Reality, Alter Size, Area Divine Shield, Avatar, Craft Artefact, Create Greater Object, Create Object, Divine Blessing (Charisma), Divine Inspiration (love and desire), Divine Shield, Divine Spell Focus (Enchantment), Divine Splendour, Extra Domain (Chaos), Extra Domain (Good), Extra Domain (Protection), Master Crafter, Possess Mortal.  
*Even though normally only allowed to deities of rank 16 or higher, Hanali has access to this salient divine ability due to the fact she competes with Sune, from whom she has ‘mimicked’ this power.  
**Domain Powers:** Cast chaos spells at +1 caster level; 15/day increase Charisma by four; cast good spells at +1 caster level; use spell completion or spell trigger devices as Enc30; 15/day protective ward.  

**Spell-like Abilities:** Hanali uses these abilities as a 25th-level caster, except for chaos spells, which she uses as a 26th-level caster. The save DC’s are 40 + spell level. aid, animate objects, antimagic field, antipathy, blade barrier, calm emotions, cat’s grace, chaos hammer, charm monster, charm person, cloak of chaos, commune with nature, demand, dispel evil, dispel law, dispel magic, dominate monster, emotion, find the path, geas/quest holy aura, holy smite, holy word, identify, imbue with spell ability, insanity, liveoak, magic circle against evil, magic circle against law, mind blank, Mordenkainen’s disjunction, Nystul’s undetectable aura, prismatic sphere, protection from elements, protection from evil, protection from law, protection from spells, repulsion, sanctuary, shatter, shield other,, snare, spell immunity, spell resistance, spell turning, suggestion, summon monster IX (as chaos or good spell only), sunburst, tree stride, true strike, word of chaos.  

**Cleric Spells/day:** 6/9/9/8/8/8/7/6/6/6; base DC 20 + spell level, 35 + spell level for Enchantment spells, +2 if mind-affecting, language dependent spell.  

**Enchanter Spells/day:** 4/7/7/7/7/6/6/6/6/5; base DC 22 + spell level, 37 + spell level if Enchantment spells, +2 if mind-affecting, language dependent spell.  

**Possessions:** Hanali prefers not to attack; she is essentially a non-violent goddess. If she must, she’d rather use subdually substituted spells or her perfect beauty to incapacitate or, if necessary, kill, her foes. If very sorely pressed, she conjures shining hearts of pure gold out of thin air, which function as +5 keen, defending, dispelling, spell storing daggers each. She attacks with them as easily as she hurls them.  

Caster level 25th; Weight 1 lb.  

**Other Divine Powers**  
As an intermediate goddess, Hanali Celanil automatically receives a 20 on any check. She treats a 1 on an attack roll or saving throw normally and not as an automatic failure and is immortal.  
Senses: Hanali can see, hear, touch and smell at a distance of fifteen miles. As a standard action, she can perceive anything within fifteen miles of her worshippers, holy sites, objects or any location where one of her titles or name was spoken in the last hour. She can extend her senses to up to ten locations simultaneously. She can block the sensing powers of deities of up to her rank at two such remote locations at once for 15 hours.  
Portfolio Sense: Hanali is automatically aware when an elf is in love or creates something beautiful, especially if magical.  
Automatic Actions: Hanali can use Craft, Diplomacy, Heal, Knowledge, or Spellcraft if the DC for the check is 25 or less. She can perform up to ten such actions per round.  
Create Magic Items: Being the elven goddess of love, magic and artistry, be it magical or not, Hanali can create any magic item – but prefers magical items that are aesthetically pleasing, work with Charisma (such as a circlet of persuasion) or with love (such as a potion of love) – as long as the item’s price does not exceed 200,000gp.  

**Avatars**  
When encountered, Hanali appears as a beautiful gold elven maiden scantily clad in a short, white and golden dress or gown. Always barefooted, she wears gold anklets and toe rings.  
**Avatar of Hanali:** As Hanali except as follows; divine rank 7; AC 63; Atk +65/+60/+55/+50 melee or +65 ranged (1d4+12/15-20, +5 keen, defending, dispelling, spell storing shining heart); or spell +55 melee touch or +59 ranged touch; SQ Divine aura (700 ft., DC 32), DR 42/+4, fire resistance 27, SR 39; SV Fort +46, Ref +51, Will +50; all skill modifiers are reduced by seven.  
**Salient Divine Abilities:** Alter Size, Craft Artefact, Divine Inspiration (love and desire), Divine Shield, Divine Spell Focus (Enchantment), Extra Domain (Chaos), Extra Domain (Good), Extra Domain (Protection), Master Crafter.  
**Spell-like abilities:** Caster level 17th, saving throw DC 32 + spell level.  

Hanali Celanil (HAN-uh-lee SELL-uh-nihl) is the elven goddess of love, romance, and beauty. Lady Goldheart is a being of timeless beauty and benign nature, and forgiving of minor transgressions. She embodies romance, beauty, love, and joy in elven spirits, her only flaws being her own mild vanity and flighty nature.  

Hanali is revered especially by gold elves and moon elves. Her followers also include elven artisans (particularly sculptors), performers (particularly bards and dancers), and nobles. Those wishing for luck in love, or to enhance their own beauty, often look to Hanali for help. Lady Goldheart is also widely revered by half-elves born of joyous unions, in honour of the love that brought their parents together. She delights in rewarding her followers with the bliss of unexpected love and affection.  

She has a crystal fountain of immense size, Evergold, which she shares with the human goddess Sune, as well as the demipower Sharess and other goddesses nor from Faerune pantheon. She keeps watch over her followers by scrying in the placid waters, and draughts from it are given to her senior priests as philtres of love.  

Hanali is both an aspect of Angharradh and one of the three elven goddesses--the other two being Aerdrie Faenya and Sehanine Moonbow--who collectively form the Triune Goddess. She has had romances with most of the male Seldarine, but remains on good terms with them all, except Fenmarel. Some believe being spurned by Hanali drove the Lone Wolf into Lolth’s arms, and though allies they are distant.  

She is allied with the other goddesses of love and beauty like Sune, though there is some friendly rivalry as to which race is the most beautiful. Lady Goldheart actively opposes the efforts of those powers who would destroy beauty and love (such as Lolth and Talos) or who nurture bitterness and heartache (such as Shar).  

Hanali's priests preside over marriages and rites of passage ceremonies for young Elves. They must cultivate fine gardens, amass personal (or temple-based) collections of gems, crystal sculptures and the like. They must always be finely dressed and must always give shelter and succour to young lovers. They meditate and pray when the moon rises highest in the sky.


