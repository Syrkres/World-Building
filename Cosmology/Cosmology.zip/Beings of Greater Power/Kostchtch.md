---
fileType: Cosmos
cosmosName: Kostchtch
cosmosType: Demon Lord
---
# Kostchtch
Demon Lord of The Ice Wastes
Demon Lord Barbarian 15, Fighter 10 CR 47; Huge Outsider (Demon);  
HD 20d8+200 and 15d12+150 and 10d10+100; hp 890;  
Init +5; Spd 70 ft.;  
AC 41, touch 20, flat-footed 40;  
Atk +48/+43/+38/+33 melee (2d6+30+1d6 (cold)+2d6 (unholy)+stun (1 round, Fortitude DC 21)/19-20/x3+2d10 (cold)+2d6 (unholy)+1d6+stun (3 rounds, Fortitude DC 21), Waste, a +6 large icy burst, unholy warhammer), or +22/+17/+12/+7 ranged (ranged attack or spell);  
Face/Reach 10 ft. by 10 ft./15 ft.;  
SA spell-like abilities, call tanar’ri, Cruel Cold; SQ Cold-subtype, Demon Lord traits, Touch of Ice, Ravaged Form, fast movement, greater rage (+8 Strength, Constitution, +4 Will save bonus, -2 AC), uncanny dodge (Dexterity bonus to AC, can’t be flanked, +2 save against traps), DR 25/+5 or 2/ , SR 59; AL CE;  
SV Fort +35, Ref +21, Will +22; Str 47, Dex 13, Con 31, Int 19, Wis 17, Chr 18\. 20’ tall  

**Skills and Feats:** Balance +6, Bluff +15, Climb +38, Craft (weaponsmith) +27, Diplomacy +15, Hide -2, Intimidate +36, Jump +28, Knowledge (The Abyss) +31, Knowledge (Arcana) +32, Knowledge (Outer Planes) +13, Knowledge (Religion) +24, Listen +16, Ride (dragon) +8, Sense Motive +12, Spellcraft +10, Swim +31, Wilderness Lore +20\. Cleave, Combat Reflexes, Dodge, Epic Weapon Focus (warhammer), Epic Weapon Specialization (warhammer), Great Cleave, Improved Bullrush, Improved Critical (warhammer), Improved Initiative, Instantaneous Rage, Intimidating Rage, Mighty Rage, Overwhelming Critical (warhammer), Penetrate Damage Reduction, Power Attack, Quick Draw, Quicken Spell-like Ability, Spellcasting Harrier, Sunder, Vile Natural Strike, Weapon Focus (warhammer), Weapon Specialization (warhammer).  

**Demon Lord Traits:** Immune to electricity and poison; acid and fire resistance 20; telepathic communication with any creature within 100 feet; Kostchtchie constantly detects good and detects magic as a 21st level Sorcerer; he possesses immunity to polymorphing, petrification, or any other attack to alter his form.  

**Spell-Like Abilities:** At will – _bane, bestow curse, blasphemy, chaos hammer, command, deeper darkness, detect law, dispel good, fear, greater dispelling, hold person, magic circle against good, telekinesis, teleport without error, unhallow, unholy aura, unholy blight, wind walk_; 6/day – _control winds, poison_; 3/day – _darkness, destruction_; 1/day – _contagion, desecrate, harm, horrid wilting, symbol_ (any); 1/week – _ruin, storm of vengeance_. These abilities are as spells cast by a 26th level sorcerer (save DC 14 + spell level).  

**Ravaged Form – Muscular Arms (Ex):** Kostchtchie’s arms are abnormally massive, granting him a +2 Strength bonus (included in totals).  

**Ravaged Form – Freezing Body (Ex):** Freezing vapor surrounds Kostchtchie. All beings within 5 feet of the Demon Lord of the Ice Wastes suffer 4d6 points of cold damage.  

**Summon Tanar’ri (Sp):** Once per day, Kostchtchie may summon Demons. For whatever reason, Kostchtchie only summons two types of Demons, the bestial Bar’lgura (of which he may call 5) or the skeletal Babau (of which he may call 4). It is unknown if Kostchtchie has the ability to summon other types of Demons, but not out of the question. Still, the Demon Lord of The Ice Wastes rarely finds the need to summon these servants since he’s usually more than capable of pummeling most adversaries into the frozen ground. Additionally, Kostchtchie is often in the company of powerful, evil creatures (see “Servants” below).  

**Cold Subtype:** Like the Frost Giants that sometimes pay homage to him, Kostchtchie revels in freezing temperatures. The Demon Lord of the Ice Wastes is immune to cold, but takes double damage from fire except on a successful save.  

**Cruel Cold (Ex):** As a Demon Lord venerated by a growing minority of Frost Giants, Kostchtchie has mastered many spell-like effects associated with winter and ice. 3/day as a standard action, Kostchtchie may cast the following spells: _chill metal, chill touch, cold orb, cone of cold, control weather_ (winter effects only), _flesh to ice_ (functions as flesh to stone), _ice burst, ice knife, ice storm, Otiluke’s freezing sphere, sleet storm, wall of ice_. All spells function as if cast by a 26th level caster and the DCs for each is 18 + spell level (functioning as if Kostchtchie possessed some manner of spell focus). Once per day (but as part of his three day limit) Kostchtchie may cast each spell as if it were Maximized or Quickened.  

**Touch of Ice (Ex):** The Demon Lord of The Ice Wastes may place the frost or icy burst ability on any weapon as if he had the necessary spellcasting ability and associated prerequisites. While in his hands, the weapon maintains the ability; in the hands of another, the bonus lasts for 24 hours.  

**Waste:** Said to have been forged by Kostchtchie in the bleakest, coldest depths of the Ice Wastes, this large warhammer is a dreaded weapon, feared by Demons and mortals alike. Imaginatively referred to as “Waste,” Kostchtchie’s warhammer was wrought from cold iron, appearing like a huge, coarsely formed block of grayish ice on the end of a frozen stick. Scattered across the handle, and surrounding the front end of the mallet are inlays of nickel and silver. In the hands of any but Kostchtchie (or one without the Demon Lord’s permission), Waste simply melts away, returning immediately to its master, who can then effortlessly track down (and probably kill) anyone foolish enough to touch his possessions over the course of the next three days.  

**Possessions:** Kostchtchie always carries Waste, and almost always wears an amulet of the planes, +8 bracers of armor, and a +5 ring of protection.  

**Servants:** On the occasions that Kostchtchie ventures beyond The Abyss, he is often (75%) in the company of 4 Leucrotta of the largest size (advanced to 18 HD). These terrible beasts obey every command Kostchtchie issues. Almost as often (50%), Kostchtchie is accompanied by 1d4+1 Frost Giants, one of whom is always a 5th level Adept in Kostchtchie’s service. Finally, when he expects significant resistance or when he hopes to impress his giants, the Demon Lord of The Ice Wastes often brings (25%) Te’Garpmesticel, an ancient white dragon of tremendous size.  

Frost Giants, having never been known for great intelligence, have nevertheless been relatively loyal, religious beings. The vast majority worship the god Thrym, a being dedicated to the destruction of a particular pantheon of gods from some far away world. It is perhaps due to this distraction that the Demon Lord of The Ice Wastes, Kostchtchie, has managed to slowly draw the attention of Frost Giants across Creation.  

Kostchtchie’s background is unknown. Some believe that he is the offspring of a Demonic-Frost Giant tryst, while others claim that he is lost child of Thrym himself. Regardless of the truth, it is known that Kostchtchie is a brutal, wretched monster of a Demon Lord, and one whose power is growing. Unlike most Demon Lords, Kostchtchie has regular forays into the Prime Material plane without the need for mortal assistance, allowing him to appear before his Frost Giant servants when he so desires. This mobility has afforded him a great deal attention, so much that, once again unlike other Demon Lords, Kostchtchie rules an entire layer of The Abyss, the so-called Ice Wastes. His might is such that even stronger Demon Princes and Demiurge that once commanded Kostchtchie’s obedience, would sooner deal with weaker Demon Lords. Still, this new found and slowly growing power has not come without a price, for Kostchtchie is generally hated by all the other Demon Lords and Princes and eventually their fear of him may erode enough for some brief unity in The Abyss. Additionally, Kostchtchie is beginning to grow anxious over the possibility that one day Thrym might notice him and decide to crush him for his audacity. To this end, the Demon Lord of the Ice Wastes is intensifying his efforts to become a full-fledged god or, barring that, an extremely powerful Demon Prince or Demiurge.  

In combat, Kostchtchie tends to open up with a Quickened version of one of his Cruel Cold spells, typically ice storm, before closing in for melee. Kostchtchie is not interested in fair or long fights, and seeks the quickest solution to eradicate his enemies, which he’s found to be smashing them into a bloody, freezing pulps with Waste. If he sees that his foes are resistant to brute force, Kostchtchie suspects that they are simply immune to his power alone and immediately summons Demons and orders any of his attendees to join him in battle. Kostchtchie will then adjust the temperature, cast desecrate, and then pummel his foes with more Cruel Cold spells (regardless of whether or not his “allies” will be harmed or not) before resorting to his spell-like abilities. Throughout battles, Kostchtchie tends to track down those most susceptible to physical injury (like Wizards, Sorcerers, and Rogues), while calling on Demons to deal with martial combatants. As soon as he perceives the battle going against him, Kostchtchie flees.  

Kostchtchie appears as a tremendous giant-like monstrosity with a low, brooding voice that seems to barely hold back vulgar curses and insults. Completely devoid of any hair, save the bushy, yellow mass crawling over his slitted, yellow eyes, his blocky body is sometimes a pale yellow, other times an icy, dull blue. His head and arms are abnormally large, the former shaped like an ill-formed hunk of ice, the latter bulging with muscles. In contrast, Kostchtchie’s legs are ridiculously thin and bandied, allowing him an odd, rolling gait. Indeed, in some ways, he resembled a giant, malformed child. A child of tremendous power and evil.  

* * *

A great creation of [DiceFreaks](http://community.dicefreaks.com/) and copied here for reference.
