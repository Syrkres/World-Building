---
fileType: Cosmos
cosmosName: Merrshaulk the Serpent Lord
cosmosType: Intermediate Deity
---
# Merrshaulk the Serpent Lord
*(Master of the Pit, the Serpent Lord, the Sleeping Serpent, the Maker of Venom)*
**Intermediate Deity**
**Symbol:** Cobra head
**Home Plane:** Abyss, 74th Layer/Smaragd (The Nest of Serpents)
**Alignmnet:** Chaotic Evil
**Portfolio:** Poison, venom, somnolence, yuan-ti, reptiles, ruins, corruption
**Domains:** 
**Superior:** None
**Allies:** Pyremius, Ramenos, Sessâ€™innek
**Foes:** Jazirian, Meyanok, Quetzalcoatl, Shekinester, Sseth, Tlaloc
**Worshiper Alignments:** LE, NE, CE

While still powerful, the Serpent Lord Merrshaulk (mair-SHAWK) is in slow decline, rarely rousing himself from his torpor. He is a malevolent power of insidious corruption and destruction, working from the inside to destroy or dominate the works of others. His favored followers, the yuan-ti, look to him as an all-powerful creator, although his true role in their creation is disputed.

It is said in yuan-ti lore that Merrshaulk was once the creator and divine patron of a great empire that spanned or colonized many worlds when humanity was still a young, uncivilized, brutal race. The serpent folk used humans as slaves and histachii stock, but they eventually rose up in rebellion, shattering the empire with a host of divine aid, for it was only with a legion of other deities that the might of Merrshaulk could be challenged. This rebellion shattered the empire, forcing the yuan-ti out of their great cities and into hiding; in some cases the serpent folk were able to return to the ruins of their great cities, but with their slaves escaped, their ability to create the vast armies of old was no more. The yuan-ti hold that they are simply biding their time and rebuilding their forces, and Merrshaulkâ€™s inactive state is one of patience and waiting.

The myths of many other creatures disagree with the tales told by yuan-ti. The couatl, whose mythic traditions are more detailed than almost any other, hold that Merrshaulk was an aspect of an ancient World Serpent archetype, but his imperfection soporific state have led to a long, slow separation from the creative force of this World Serpent, and as an inferior cast-off of a vibrant creative entity, he and his creations are in a remorseless decline into extinction. They hold that the one true creative effort of the Master of the Pit was in corrupting humanity with the essence of ophidian creatures, and even this wasnâ€™t a true creative effort, for he simply altered what already existed. Correct or not, repeating such opinions in front of yuan-ti is likely to result in furious and violent denials. An old and fragmentary text from the Outer Planes describes yet another scenario. This text describes an ancient human snake cult that worshipped a serpentine tanarâ€™ri named Schâ€™theraqpasstt. This worship elevated him to true godhood, but he was not satisfied with simply being a divine power and hatched a plan to merge his essence with the whole of the Outer Planes. His plan worked, after a fashion; his mind and divine essence merged with the layer of the Abyss he held sway over, resulting in the layer now known as the Mind of Evil. The rest of his essence remained in a much diminished material demonic form with a broken mind. This scheme was a disaster for his mortal followers, who suddenly found the magic they relied upon non-existent, and their enemies quickly capitalized on this new weakness to destroy the empires and cities built by the serpent folk. The text has little further to say on the matter, but if it truly recounts the origins of the yuan-ti, it is likely that Merrshaulk slew the demonic form of Schâ€™theraqpasstt, and usurped the patronage of the yuan-ti. It is possible the tale refers to unrelated serpent-human hybrids, however. Finally, there are tales that the yuan-ti, or at least their early forbearers, required the histachii for breeding purposes, and it was only through them that new full yuan-ti could be created; most sages dismiss this as apocryphal, however.

Given his current somnolent state, Merrshaulkâ€™s interactions with other deities are few and far between. He maintains a weak alliance with Pyremius, the Suel deity of poison and fire, on the contingency that the Blazing Killer not seek out followers among the yuan-ti. The Master of the Pit fostered this alliance to battle the influence the deities Meyanok and Tlaloc assert over many yuan-ti on the world of Oerth. Merrshaulkâ€™s soporific state has precluded any direct action on this front, however. He also maintains a loose agreement with the ascended demon lord Sessâ€™innek, who despite claiming dominion over all reptiles avoids seeking followers among the yuan-ti so as not to anger the still-powerful Serpent Lord. Should Sessâ€™innek continue to gain power, he may seek to further expand into those serpent folk, however. Merrshaulk also appears to have some sort of agreement with Ramenos, who shares Smaragd with the Serpent Lord, although the precise nature of these agreement or alliance is unknown. In his rare times of activity, Merrshaulk continues to oppose his ancient foes of Jazirian and Quetzalcoatl, both of whom stand against the evil ways of the Master of the Pit and seek to reform evil serpent creatures, as well as the Naga Queen, Shekinester. The Three-Faced Queen has long been concerned Merrshaulk has designs on her spirit naga children, and in her Empowerer and Preserver aspects, she stands against the harm caused by his yuan-ti. He has relatively recently cultivated an animosity towards the dwarven power Thard Harr, for his jungle dwarven followers often come into conflict with the yuan-ti who worship Merrshaulk. Finally he plans to take action against upstart Torilian serpent power Sseth, for he has usurped his position as the deity of yuan-ti on that world, even going so far as to respond to prayers in Merrshaulkâ€™s name. That the pair both have realms on the same plane is strong indictment against the Master of the Pitâ€™s ability to maintain hold over his worshipers.

Few things can rouse Merrshaulk from his torpor within the deep serpent-filled caverns android pits that make up his realm on Smaragd. Powerful priests can occasionally invoke an appearance of an avatar with lengthy rituals and large sacrifices; in such cases he will dispense wisdom or some magical boon to the priest or his people. He is not a hostile or aggressive power to his followers, but he is lethargic and prefers to avoid confrontation, so a priest summoning him to fight with them may be disappointed by his lack of action. He very rarely sends an avatar to the Prime Material plane for any other reason, but the discovery of a powerful artifact related to serpents might rouse his interest enough, especially if it was discovered or held by yuan-ti.

Merrshaulkâ€™s Avatar (Mage 30, Cleric 30, Fighter 25)
Merrshaulk appears as a yuan-ti abomination of gargantuan proportions. His scales are dark green on his back and yellow on his belly, with thin evenly spaced bands of yellow down the length of his body. He has stubby human-like arms, and the head of a human with sun-darkened skin and yellow eyes with slitted pupils; his hair is short and black. He draws his spells from the spheres of all, animal, chaos, charm, combat, divination, healing, necromantic, plant, protection, summoning, and sun, and from all schools save abjuration and necromancy.

AC âˆ’2; MV 15; HP 175; THAC0 âˆ’4; #AT 7/2
Dmg 1d8+11 (long sword +3, +6 Str, +2 spec. bonus in long swords)
MR 60%; SZ G (40 feet long)
Str 18/00, Dex 16, Con 17, Int 18, Wis 15, Cha 17
Spells P: 11/10/9/9/9/9/8, W: 7/7/7/7/7/7/7/6/6
Saves PPDM 2; RSW 3; PP 4; BW 4; Sp 4

Special Att/Def: Merrshaulk uses a pair of long swords +3, known as the Viperâ€™s Fangs, when engaging in melee; he suffers no offhand penalty for using both weapons. He can forgo one attack per round with each blade to envenom them by licking; any creature struck by an envenom end blade suffers an additional 2d8 points of acidic damage, with a successful saving throw versus poison halving the damage. Once per turn, he can spit a globule of his acidic poison that splashes with a 5-foot radius up to 40 feet away. All within the area of effect suffer 2d8 points of damage, with a save versus poison allowed for half damage.

The Master of the Pit can levitate himself at a rate of 30 feet per round, and six times per day he can cast sticks to snakes; he always chooses to make transformed snakes poisonous. Twice per day he can cast a double-strength hypnotic pattern that inflicts a âˆ’4 penalty on victimsâ€™ saving throws. He can charm all normal, giant, and monstrous snakes he sees at will, including nagas and serpentine humanoids such as yuan-ti and ophidians.

Merrshaulk is immune to all poisons and illusion/phantasm spells, as well as weapons of less than +2 enchantment. No normal, giant, or monstrous serpent of semi-intelligence or less will attack him unless magically compelled. He is especially vulnerable to sleep effects, suffering a âˆ’4 penalty to any such spells that breach his magic resistance.

## Other Manifestations
Merrshaulk is rarely roused enough to take notice of the plight of his followers, and is not known to manifest his power to aid them unless called upon directly. Even then, the likelihood of a response is very low; when he does respond, his aid will usually be simple and brief, such as a serpentine hiss or the sound of a rattlesnakeâ€™s tail as a warning of danger. If the follower calling for aid is especially powerful or important, the Master of the Pit may send forth up to a dozen poisonous or constrictor snakes to aid the supplicant, or transform local plant life into a serpent vine.

Merrshaulk is served primarily by normal and giant snakes of all kinds, as well as aeserpents, chromatic dragons (including brown and yellow dragons), hannya, hebi-no-onna, heways, hydras, incarnates of sloth, lamia nobles, mariliths, marl, medusas and maedar, ophidians, tanarâ€™ri (least and lesser), and yuan-ti histachii. He displays his favor through the discovery of banded agates and similar layered stones that mimic the banding patterns of certain snakes, citrine, heliodor, and topaz gemstones with an inclusion that makes the pieces appear as a serpentâ€™s eye, serpentine stones, and snake-like formations of natural rock outcroppings. He displays his displeasure through the discovery of dead snakes, especially those obviously slain by mongooses and similar creatures or prey they slew them from the inside.

## The Church
Clergy: Clerics, specialty priests
Clergyâ€™s Align.: LE, NE, CE
Turn Undead: C: No, SP: No
Cmnd. Undead: C: Yes, SP: No

All clerics and specialty priests of Merrshaulk receive religion (yuan-ti) as a bonus nonweapon proficiency.

Merrshaulkâ€™s clergy maintains few relations with outside faiths. They sometimes have temporary or even longer-term alliances with cults of other evil deities if they believe it holds mutual benefit, but these are always situational; on community of yuan-ti might have a close alliance with a lizard man cult of Sessâ€™innek while a community in another land is waging a bitter territorial war with a cult of the Emperor Lizard. The only constant is their hatred for yuan-ti who worship other powers; these Merrshaulkâ€™s priesthood slays as soon as they can, and with fanatical zeal. They do adopt the other communityâ€™s histachii and young, provided they are young enough to educate in the faith of the Master of the Pit.

Temples built in honor of Merrshaulk are typically squat affairs of volcanic rock with extensive labyrinthine underground complexes. They are highly decorated, with elongated or repeating serpent designs along the tops and bottoms of walls and doorways, often painted with blues, greens, browns, and golds. The walls are further decorated with grotesque imagery of snakes and yuan-ti killing, torturing, and devouring humans; such artwork is usually painted or carved on the walls, although sometimes bronze plates with etchings or cast sculpture are noted to the walls. Temples almost never have windows, and it is rare for there to be more than one obvious entrance. Columns are only used to hold up the ceiling in the grand worship chamber, and such pillars either appears as normal cylinders with a serpent spiraling around it, or as a pair of intertwined coiled serpents; in both cases the heads are the column capitals. Stairs are never found in the temples, with their functionality replaced by straight and spiraling ramps, and in some cases poles. Implements of torture can be frequently found within the walls, and many side chambers are devoted to that purpose. The central worship hall has a large flat altar stained with blood and the black liquid of the histachii brew. Behind the altar rises an enormous icon of Merrshaulk, either as a serpent or yuan-ti abomination with arms and a human head.

Novices in the service of Merrshaulk are known as Hatchlings. Full priests of the Master of the Pit are known as Venomous Lords. Specialty priests are known as hypnophids. In ascending order of rank, the titles used by the Merrshaulkan clergy are Thread Lord, Garter Lord, Boa Lord, Anaconda Lord, Python Lord, Asp Lord, Adder Lord, Krait Lord, Viper Lord, and Cobra Lord. High ranking priests have their own unique titles that often mirror the lower titles with the King superlative instead of Lord, but they may devise or be granted other unique titles as well; collectively they are known as Masters/Mistresses of Serpents. The organized clergy of Merrshaulk consists entirely of yuan-ti, with abominations making up over half the clergy (55%), trailed by half-breeds (30%) and purebloods (15%). All high-ranking priests are abominations. Outside of the organized clergy exist some minor cults of the Master of the Pit among humans, ophidians, and other races, but these are but shadows of the yuan-ti priesthood. Among yuan-ti, specialty priests (90%) vastly outnumber clerics (10%); these numbers are reversed for human and ophidian cults. Regardless of race, males (65%) are found with greater frequency than females (35%).

Dogma: Perfection is found in the form of a serpent, for the simple form is elegant death incarnate. With patience and calm all goals can be achieved; frenetic activity is a waste of energy and a hallmark of those that should be prey. Squeeze what you will from the world, and circle about your goals and keep what you desire tight within your coils. That which was lost and destroyed can be rebuilt, but in its right time; until then the tumbled stones serve as places from which to ambush the unwary. Be it slow or quick, venom is a powerful gift from the Serpent Lord, and shows the superiority of his servants.

Day-to-Day Activities: Despotically ruling their communities is the primary activity of yuan-ti priests of Merrshaulk. Members of the clergy oversee all major elements of their society, but are most concerned with training and leading the martial forces in raids on human settlements, and are expected to be experts on ambush tactics. They also handle the conversion and training of histachii, distribution of food and loot from raids, and general administration. Members of the priesthood devise the defenses and traps that protect their lands and temples, and pride themselves on ingenious trap design. They enjoy torture, and many attempt to devise new methods of inflicting pain on captives. Hunting is also a favored pastime of the priesthood, with most members getting a thrill out of slowly stalking sentient prey. Finally, pureblood priests are often deployed as spies, to better raid nearby human settlements.

Important Ceremonies/Holy Days: The Night of Venom is a holy ceremony held every ten years, in which large numbers of humans are converted to histachii en masse. Typically held on the last full moon before the winter solstice, yuan-ti are very active in the months and year leading to this event trying to capture as many humans as possible for the ceremony. The number of captives varies by the size of the community, but normally there are 10—40 humans fed the histachii brew. The ceremony begins with a great exhortation to Merrshaulk by the high priest, followed by a long night of conversions and feasting. Those humans who die from the brew instead of becoming histachii are burned as a sacrifice to the Master of the Pit, with prayers and thanks by junior priests. At the completion of the ceremony, the yuan-ti rigorously train their new histachii, for they enter a period of lethargy during the winter following the ceremony.

Major Centers of Worship: Few major temples of the Master of the Pit are known, due to the secretive nature of his cult and the aggressive destruction they suffer from various good-aligned forces. Rumors often place temples within the ruins of once-great cities deep within the densest jungles, and occasionally even beneath the greater cities within tropical and subtropical zones, but rarely can these be confirmed. Some say this is due to infiltration of society by purebloods, with covert assassinations eliminating those with knowledge of the secret yuan-ti holy sites before they can be shared with others.

## Affiliated Orders: Merrshaulk's priesthood sponsors no martial or monastic orders.

Priestly Vestments: Robes woven to look like snake scales, in the colors of common snake types are common among the clergy with human bodies; abominations and those with non-human bodies wear nothing. High priests wear robes of shed snakeskin, specially preserved so that they are not fragile or brittle. The holy symbol of the priesthood is an amulet in the shape of a cobraâ€™s head with hood flared, typically of gold, brass, or bronze.

Adventuring Garb: Yuan-ti clergy of Merrshaulk wear little besides their holy symbol and harnesses or belts for equipment, unless they have human bodies. In such cases, as well as for human worshipers, they favor scale armor. Any worshiper with human hands tends to favor long swords, scimitars, and two-handed swords, as well as bows, if allowed to use them. While it is not uncommon for them to make use of poisons in traps, they rarely envenom their weapons.

Specialty Priests (Hypnophids)
Requirements: Dexterity 12, Wisdom 14
Prime Req.: Dexterity, Wisdom
Alignment: CE
Weapons: Any
Armor: None (up to scale for those with human bodies)
Major Spheres: All, animal, charm, divination, healing (reversed forms favored), necromantic (reversed only), plant, summoning
Minor Spheres: Chaos, combat, protection, sun (reversed only)
Magical Items: Same as clerics
Req. Profs: Set snares
Bonus Profs: Hunting

Hypnophids may be yuan-ti (abominations, half-breeds, or purebloods), ophidians, or humans.
Yuan-ti hypnophids are allowed to multiclass as hypnophid/psionicists, although this is very rare.
Hypnophids are immune to normal poisons, including injected, ingested, and contact poisons. This does not extend to harmful gasses, such as those produced by the stinking cloud and cloudkill spells or green dragon breath.
Hypnophids can cast hypnotism (as the 1st-level wizard spell) once per day.
At 3rd level, hypnophids can cast sleep (as the 1st-level wizard spell) or hypnotic pattern (as the 2nd-level wizard spell) once per day.
At 5th level, hypnophids can cast sticks to snakes (as the 4th-level priest spell) once per day; the snakes formed by this spell are always poisonous.
At 7th level, hypnophids can cast poison (as the reverse of the 4th-level priest spell neutralize poison) once per day.
At 10th level, hypnophids can cast animal summoning II (as the 5th-level priest spell) once per day.
At 12th level, hypnophids can shapechange as a druid into any normal or giant snake, including amphisbaena and boalisks, but not intelligent varieties like heways.
Merrshaulkan Spells
In addition to the spells listed below, priests of the Serpent Lord can cast the 3rd-level spell camouflage, detailed in the entry for Laogzed above, the 4th-level priest spell histachii brew, detailed in Powers and Pantheons in the entry for Sseth, and the 5th-level spell moltings detailed in the entry for Laogzed above.

1st Level
Climbing Serpent (Pr 1; Alteration)
Sphere: Animal
Range: Touch
Components: V
Duration: 3 rds. + 1 rd./level
Casting Time: 4
Area of Effect: Creature touched
Saving Throw: Neg.

This spell, similar to the wizard spell spider climb, allows a serpentine creature to slither up sheer surfaces and walls, and cling to ceilings. For the duration of the spell, the underside of the serpent adheres to surfaces as desired, although this force is not great enough to prevent the serpent from lifting its head to strike in combat, nor does it slow normal movement over floors or prevent other creatures from physically moving the affected serpent. While under this spell, a creature is able to easily scale walls and even hang upside down from the ceiling; on such surfaces the creatureâ€™s normal movement rate is halved. A creature that is encumbered has their movement rate on such surfaces quartered for the duration.

2nd Level
Serpent Tail (Pr 2; Alteration)
Sphere: Animal
Range: Touch
Components: V
Duration: 1 rd. + 1 rd./level
Casting Time: 5
Area of Effect: 1 creature
Saving Throw: 1/2

This spell transforms the ordinary tail of any reptilian creature into the form of a snake, complete with fanged head. A serpent tail provides an additional attack. Unless the creature already could threaten with its tail, however, it suffers a âˆ’2 penalty to its THAC0 when attacking with the serpent tail. The bite of the snake head causes 1d6 hit points of damage and injects a venom that burns like acid in the victimâ€™s veins. On the round after being wounded, the poisoned creature must save vs. poison or suffer 1 hit point of damage for each Hit Die of the attacking creature. A successful saving throw vs. poison indicates that the victim suffers only half damage.

The snake head can do nothing more than hiss and bite. Magic cast upon it affects the host creature and vice versa. It does not suffer additional damage on top of the hostâ€™s hit points; any attacks directed against it inflict damage on the host.

5th Level
Greater Serpent Tail (Pr 5; Alteration)
Sphere: Animal
Range: Touch
Components: V
Duration: 3 rds. + 1 rd./level
Casting Time: 8
Area of Effect: 1 creature
Saving Throw: 1/2

This spell is an improved version of the 2nd level spell serpent tail. Like that spell, it transforms the tail of a single reptilian creature into a venomous serpent. However, upon completion of this spell, the serpent tail separates from its host, and attacks the nearest foe with the hostâ€™s THAC0. It can move no more than 60 feet from its host, and has a movement rate of 6. It has the same natural Armor Class as its host, and can suffer up to 3 hit points of damage per Hit Die of the host creature it separated from. For example, a 9 HD yuan-ti abomination would create a remote serpent tail with AC 0 and 27 hit points. Saving throws, system shock checks, and all other such checks are as the host creature. Despite losing its tail, the host creature suffers no ill effects, such as poor balance, due to the magic of this spell.

The bite of the serpent tail causes 1d8 points of damage and injects a venom that burns like acid in the victimâ€™s veins. On the round after being wounded, the poisoned creature must save vs. poison or suffer 2 points of damage for each Hit Die of the host creature. A successful saving throw vs. poison indicates that the victim suffers only half damage.

At the expiration of the spell, or at any point earlier as desired by the host, the snake returns and re-attaches itself, returning to its original form. If the serpent tail is brought to 0 hit points or less, it will immediately return to its host and re-attach; in this case, the host suffers half the damage the serpent tail has suffered, which may slay the host from the shock if this damage brings its hit points below 0. If physically prevented from re-attaching for one full turn, the serpent tail will shrivel up and begin rotting; in this case, the host suffers as much damage as the serpent tail had hit points, and further, one point per Hit Die is permanently lost; in the case of creatures that can naturally regenerate their tail, this loss only lasts until the tail is regrown. A regenerate or similar spell will also regrow the tail and restore these permanently lost hit points. The serpent tail can be affected by all spells that the host can.