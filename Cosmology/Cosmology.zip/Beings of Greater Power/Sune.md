---
fileType: Cosmos
cosmosName: Sune
cosmosType: Greater Deity
---
# Sune
_Firehair, Lady Firehair, the Fairest_  
Greater Goddess  
Symbol: Face of a red-haired, ivory-skinned beautiful woman  
**Home Plane**: Brightwater  
**Alignment**: Chaotic Good  
**Portfolio**: Beauty, love, passion  
**Worshipers**: Lovers, artists, half-elves, adventurers  
**Cleric Alignments**: CG, CN, LG (paladins only), NG  
**Domains**: Chaos, Charm, Good, Pleasure, Protection  
**Favored Weapon**: _Silken Sash_ (a whip)  

Sune  
Bard 40/ Heartwarder 10/ Exemplar 10  
Medium Outsider (chaotic, good, extraplanar)  
Divine Rank: 16  
**Hit Dice**: 40d6+320 (Brd) plus 10d4+80 (Hrt) plus 10d6+80 (Exm) (820 hp)  
**Initiative**: +25 (+13 Dex, +12 Int)  
**Speed**: 60 ft.  
**Armor Class**: 91 (+21 deflection, +13 Dex, +31 natural armor, +16 divine) touch 60, flat-footed 78  
**Base Attack Bonus/Grapple**: +35/+56  
**Attack***: _Silken Sash_ +71 melee (1d3 +12 nonlethal/x2 plus 1d6+2 Str damage) *Always receives a 20 on attack rolls; roll die to check for critcal hit. (15 nonlethal/30 nonlethal plus 8 points of Str damage); or spell +56 melee touch (without _Silken Sash_); or spell +71 melee touch (with _Silken Sash_) ; or spell +64 ranged touch  
**Full Attack***: _Silken Sash_ +71/+66/+61 (1d3 +12 nonlethal/19-20/x2 plus 1d6+2 Str damage) *Always receives a 20 on attack rolls; roll die to check for critcal hit. (15 nonlethal/30 nonlethal plus 8 points of Str damage)  
**Space/Reach**: 5 ft/5 ft (15 ft with _Silken Sash_)  
**Special Attacks**: Domain powers, salient divine abilities, spells, spell-like abilities  
**Special Qualities**: Divine aura (16 miles, DC 47), divine immunities, DR 30/epic and cold iron, fast healing 36, cold resistance 21, SR 78, godly realm (100 miles on the outer planes, 1600 ft on the Material plane), _planeshift_ and _greater teleport_ at will, remote communication, speak, and read all languages and speak directly to all beings within 16 miles, bardic knowledge +54, bardic music 40/day (inspire excellence, countersong, inspire courage +15, inspire competence, _fascinate, suggestion, mass suggestion_, inspire greatness, inspire heroics, _song of freedom_), heart of passion, lend talent, lips of rapture 21/day, perfect self, persuasive performance, skill artistry (Craft [painting], Craft [sculpture], Perform [dance], Perform [sing]), skill mastery (Appraise, Bluff, Concentration, Craft [painting], Craft [sculpture], Diplomacy, Gather Information, Heal, Knowledge [arcana], Knolwegde [nature], Knowledge [the planes], Knowledge [religion], Perform [dance], Perform [sing], Sense Motive, Spellcraft), sustaining presence, voice of a siren, tears of Evergold  
**Saves**: Fort +71, Ref +73, Will +58* (*+69 again mind-affecting effects)  
**Ability Scores**: Str 20, Dex 37, Con 27, Int 34, Wis 31, Cha 52  
**Skills**: Appraise +75, Balance +30, Bluff +116, Climb +25, Concentration +100, Craft (calligraphy) +60, Craft (painting) +95, Craft (sculpture) +95, Diplomacy +135, Gather Information +105, Heal +80, Hide +30, Intimidate +50, Jump +25, Knowledge (arcana) +75, Knowledge (history) +45, Knowledge (nature) +75, Knowledge (the planes) +75, Knowledge (religion) +85, Listen +70, Move Silently +30, Perform (dance) +108, Perform (poetry) +60, Perform (sing) +108, Profession (herbalist) +50, Sense Motive +101, Spellcraft +95, Spot +70, Swim +25, Tumble +30  
**Feats**: Alluring, Disguise Spell, Dodge, Exotic Weapon Proficiency (whip), Expeditious Metamagic (x2), Extend Spell, Force of Personality, Greater Spell Focus (Enchantment), Heighten Spell, Lyric Spell, Mobility, Negotiator, Nymph’s Kiss, Persuasive, Quicken Spell, Skill Focus (Diplomacy), Spell Focus (Enchantment), Trustworthy, Words of Creation  
**Epic Feats**: Eloquent Spell, Epic Inspiration (x3), Epic Skill Focus (Bluff), Epic Skill Focus (Diplomacy), Epic Skill Focus (Sense Motive), Improved Heighten Spell, Inspire Excellence, Spell Knowledge (x2)  
**Environment**: Brightwater  
**Organization**: Unique  
**Challenge Rating**: 62  
**Treasure**: _Silken Sash_  
**Alignment**: Chaotic Good  
**Advancement**: N/A  
**Level Adjustment**: N/A  

**Alter Reality**: As a deity, Sune exerts a considerable measure of control over reality itself, and her presences can command the very essence of the world around her. This ability takes shape in a number of ways.  

Sune may use _wish_ in relation to anything connected to beauty, love, or passion, save for the replication of other spells. This ability costs her no XP, and requires a standard action to implement. She also has full access to the Alter Size SDA and the Avatar SDA with no need to actually take them.  

**Divine Immunities**: As a greater goddess, Sune is immune to transmutation, energy drain, ability drain, ability damage, mind-affecting effects, disease, poison, stunning, sleep, paralysis, death effects, disintegration, banishment, imprisonment, turning or rebuking, and fire and acid effects, regardless of the divine rank of the attacker.  

**Divine Power**: Deities are living embodiments of power, and ancient divine magics flow through their veins. As such, mortal items are of virtually no use to them, being so much weaker than their own innate powers. Gods gain no benefit from a deflection, enhancement, resistance, insight, sacred or profane bonus that is less than their divine rank. Note that this only applies to bonuses that affect the god itself; weaponry and armor is unaffected by this.  

**Domain Powers**: Cast good and chaos spells at +1 caster level; boost Charisma by 4 points for one minute 16/day; protective ward (+16 resistance to one save) 16/day  

**Heart of Passion**: Sune evinces such passionate belief in whatever she does or says that she can sway the thoughts of the most rigid critic. This ability translates into a +2 bonus on all Charisma-based skill checks.  

**Lips of Rapture**: Sune’s kiss confers a state of bliss upon its recipient, conferring a +2 morale bonus on attack, weapon damage, checks, and saves. Moreover, it temporarily suspends the effects of exhaustion, fatigue, and nausea. An enraptured recipient receives a +2 bonus against enchantment spells and effects. This ability lasts 5 rounds, and can be used 21 times a day. The one downside to the Lady Firehair’s kiss is that it also has the effect of a daze spell upon the recipient (the normal saving throw applies) as if cast by a 50th level sorceress.  

**Other Divine Powers**  
- As a greater goddess, Sune automatically receives the best possible result on any die roll she makes (including attack rolls, damage rolls, and saves). She is immortal.  
- **Senses**: Sune can hear, touch, and smell at a distance of sixteen miles. As a standard action, she can perceive anything within sixteen miles of her worshipers, holy sites, objects, or any location where one of her titles or name was spoken in the last hour. She can extend her senses to up to twenty locations at once. She can block the sensing power of deities of her rank or lower at up to twenty remote locations at once for up to sixteen hours.  
- **Portfolio Sense**: Sune senses the creation or destruction of any beautiful creature or object sixteen tendays before it happens and creation the sensation for sixteen tendays after the even occurs. She is likewise aware of all creature’s passionate desires or romantic loves.  
- **Automatic Actions**: Sune can use Concentration, Craft (calligraphy), Craft (painting), Craft (sculpting), Diplomacy, Perform (dance), Perform (poetry), or Perform (sing) as a free action if the DC for the task is 30 or lower. She can perform up to twenty such free actions each round.  
- **Create Magic Items**: Sune can create any kind of magic item that affects appearance or emotion  

**Tears of Evergold**: As a full-round action, Sune can cry tears drawn from Evergold, a sacred pool that enhances beauty that Sune shares with the elven goddess Hanali Celanil. If these tears are collected, they are equivalent to the effects of an _elixir of love_ and serve as the holy water for Lady Firehair’s faithful. Sune can use this ability once a tenday, and while it costs her no gold to do so, calling upon the power of the pool requires her to spend 6 XP, just as if she had made the potion with the Brew Potion feat.  

**Voice of a Siren**: Sune’s voice is so enticing that she weakens the ability of opponents to resist her spells. She gains the Greater Spell Focus (enchantment) and Spell Penetration feats, but they only apply to spells with a verbal component (and are not altered with the Silent Spell feat).  

**Salient Divine Abilities**: Area Divine Shield, Aura of Passion*, Automatic Metamagic (Disguise Spell), Automatic Metamagic (Eloquent Spell), Call Creatures (fey), Clearsight, Create Object, Create Greater Object, Divine Bard, Divine Beauty*, Divine Blessing (Charisma), Divine Fast Healing, Divine Inspiration (love and desire), Divine Shield, Divine Spellcasting, Divine Spell Focus (Enchantment), Empower Inspiration (love and desire)*, Extra Domain (Chaos), Gift of Life, Irresistible Performance, Voice of the Siren Queen*  
*Unique SDA  

**Aura of Passion** (unique SDA): An aura of emotion surrounds the Fairest, instantly causing any creature in her presence to adore and desire her. As a result, any creature who comes within 1600 ft of Sune who can see her or sense her in some other way must make a Will Save (DC 47) or feel love and desire towards her, as per her Divine Inspiration (love and desire) ability. This does not count against her uses of the ability per day. This save must be made every round unless the save DC is exceeded by 10 or more, in which case the person becomes immune to the effect for 24 hours, though this does not make them immune to her Divine Inspiration (love and desire) ability. Further, heterosexual males, homosexual females, and bisexuals and animals of either gender within the area must make a Will Save (DC 47) to even attempt to cause harm to come to the Lady Firehair, though it is rare that even evil creatures try this. Similarly, if the save is made, the being is fully able to assault Sune, though this would be a most unwise course of action.  

**Divine Beauty** (unique SDA): Sune is the most beauteous entity in all of Abier-Toril, and perhaps outshines even some of the goddesses of love and carnality of other worlds. As such, the mere sight of her unclad can cause such longing ache within a mortal's heart as to kill him or her. Sune can choose to suppress this ability if so she chooses, and, in fact, she only rarely uses this power. However, its effects, when released, are devastating. While the ability is active, all within 160 ft. must make a Fortitude save (DC 47) or die. If the save is made, the mortal is immune to the ability for 24 hours, though he is stunned for 16 rounds.  

**Empowered Inspiration** (unique SDA): As the rawest expression of love, passion, and desire known to Toril, Sune’s ability to inspire such emotions in others is unmatched. Only Shar is immune to her Divine Inspiration (love and desire) salient divine ability, and the Will Save DC for her power is 63.  

**Voice of the Siren Queen** (unique SDA): Sune has the ability to meld arcane and divine magic with her voice, allowing her to select spells from the cleric and sorcerer spell lists for her spell known as a bard and cast them, though, like her normal bard spells, these spells cannot be silenced, nor prepared with metamagic ahead of time.  

**Spells(4/10/9/9/9/9/8/4/4/4/4/4/4/4/3/3/3/3/2/2/2/2)**: Sune casts spells as a 50th level bard, and the save DC for her spells is equal to 32+spell level, or 39+spell level for enchantment spells  

**Spells Known**: Cantrips- _dancing lights, guidance, light, lullaby, mending, prestidigitation_; 1st- _bless, divine favor, harmony, hypnotism, shield_; 2nd- _align weapon, enthrall, shield other, suggestion, touch of idocy_; 3rd-_bestow curse, charm monster, deep slumber, good hope, water walk_; 4th- _break enchantment, celebration, death ward, hold monster, rainbow pattern, restoration_; 5th- _baleful polymorph, dream, feeblemind, greater dispel magic, greater heroism, improved blink, mass suggestion, true seeing_; 6th- _geas, heal, irresistible dance, mass charm monster_  

**Spell-like Abilities**: Sune uses her spell-like abilities as a 76th level caster, except for chaotic and good spell, which she casts as a 77th level caster; The save DC against her spell-like abilities is 48+spell level, or 55+ spell level for Enchantment spells. At will- _aid, animate objects, antimagic field, blade barrier, celestial blood, chaos hammer, charm monster, charm person, cloak of chaos, demand, dispel evil, dispel law, dominate monster, ease pain, empyreal ecstasy, geas/quest, good hope, heart’s ease, holy aura, holy smite, holy word, insanity, magic circle against evil, magic circle against law, mass eagle’s splendor, mind blank, prismatic sphere, protection from elements, protection from evil, protection from law, remove fatigue, remove fear, repulsion, sanctuary, shatter, shield other, spell immunity, spell resistance, spread of contentment, sublime revelry, suggestion, summon monster IX_ (cast only as a good or chaotic spell), _Sune’s caress, word of chaos_  

**Possessions**: Sune typically wears a diaphanous robe of purest white (if that) held at the middle by her _Silken Sash_. Sune generally does not draw her weapon save in the direst of times, preferring it’s defensive powers to be brought to bear rather than having to strike out. It functions as a _+7 blessed whip of enfeebling_ when used as a weapon, and may also be used to make melee touch attacks, such as that required by the _heal_ spell. However, when worn, it halves all damage dealt by melee and ranged attacks to the wearer. The stats above assume that the _Silken Sash_ is used as a weapon, rather than worn.  

-----------------------------------------------------------------------------------------------------------------------------------------------------  
