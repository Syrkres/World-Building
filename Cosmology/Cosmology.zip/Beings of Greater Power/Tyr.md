---
fileType: Cosmos
cosmosName: Tyr
cosmosType: Greater Deity
---
# Tyr
_The Even-Handed, the Maimed God, the Just God_  
**Greater Deity**  
**Symbol:** Balanced scales resting on a warhammer  
**Home Plane:** House of the Triad  
**Portfolio:** Justice  
**Worshipers:** Paladins, judges, magistrates, lawyers, police, the oppressed  
**Cleric Alignments:** LG, LN, NG  
**Domains:** Good, Knowledge, Inquisition, Law, Retribution, War, Wrath  
**Favored Weapon:** "_Justicar_” (long sword)  

Tyr  
Paladin of Honor 30/Cleric 20/Justicar 10  
Medium Outsider (good, lawful)  
Divine Rank: 18  
**Hit Dice:** 30d10 (paladin) +10d8 (justicar) +20d8 (cleric) plus 600 (1,140 hp)  
**Initiative:** +11 (+7 Dex +4 Improved Initiative)  
**Speed:** 60 ft. (12 squares)  
**Armor Class:** 81 (+7 Dex, +18 divine, +33 natural, +13 deflection), touch 48, flat-footed 74  
**Base Attack/Grapple:** +40/+53  
**Attack*:** Justicar +88 melee (1d8+41 +3d6 axiomatic and 1 negative level +3d6 holy and 1 negative level/17-20, always inflicts maximum damage 49 points, 18 axiomatic, and 18 holy); or spell +71 melee touch or +65 ranged touch. *always receives a 20 on attack rolls; roll die for critical check  
**Full Attack:*** Justicar +88/+83/+78/+73 melee (1d8+41 +3d6 axiomatic and 1 negative level +3d6 holy and 1 negative level/17-20, always inflicts maximum damage 49 points, 18 axiomatic, and 18 holy); or by spell. *always receives a 20 on attack rolls; roll die for critical check  
**Space/Reach:** 5 ft./5 ft.  
**Special Attacks:** Domain powers, salient divine abilities, spell-like abilities, spells, smite evil 6/day, cure disease 9/week, deadly touch, turn undead 16/day  
**Special Qualities:** Divine aura (18 miles, DC 41), divine immunities, DR 30/epic and silver, electricity resistance 24, godly realm (100 miles outer plane, 1,800 ft. Material Plane), greater teleport at will, plane shift at will, remote communication, SR 80, speak, and read all languages and speak directly to all beings within 18 miles,  
**Saves:*** Fort +73, Ref +64, Will +76 *always receives 20 on saves  
**Abilities:** Str 36, Dex 24, Con 30, Int 37, Wis 48, Cha 36  
**Skills:*** Concentration +91, Diplomacy +102, Handle Animal+46, Heal +90, Knowledge (arcana) +84,Knowledge (history) +84, Knowledge (local) +87, Knowledge (nobility) +71, Knowledge (the planes) +94, Knowledge (religion)+94, Listen +58, Profession (judge) +110,  
Ride+42, Search +57, Sense Motive +70, Spellcraft +98, Spot +63  
**Feats:** Cleave, Combat Reflexes, Empower Spell, Great Cleave, Power Attack, Quicken Spell, Still Spell, Weapon Focus (long sword) (B)  
**Epic Feats:** Automatic Quicken Spell(x3), Chain Spell, Devastating Critical (long sword), Enhance Spell, Epic Spellcasting, Epic Weapon Focus (long sword)(B), Great Smiting(B), Improved Critical (long sword), Improved Initiative, Improved Sunder, Intensify Spell, Maximize Spell, Overwhelming Critical (long sword), Planar Turning(B), Purify Spell, Twin Spell  
**Environment:** House of the Triad  
**Organization:** Unique  
**Challenge Rating:** 62  
**Treasure:** _Justicar_  
**Alignment:** Lawful Good  
**Advancement**: --  
**Level Adjustment:** --  

**-Detect Evil (Sp):** At will, Tyr can _detect evil_  
**-Smite Evil (Su):** Six times per day, Tyr can smite an evil enemy. He gains a +13 bonus to hit, and inflicts +150 damage.  
**-Smite Anarchy (Su):** Thrice per day, Tyr can smite a chaotic enemy. He gains a +13 bonus to hit, and inflicts +20 damage.  
**-Lay on Hands (Su):** Tyr may use his touch to heal up to 390 points of damage to an ally, he may also instead 390 points of damage to an undead creature.  
**-Aura of Courage (Su):** The Just God is immune to fear and radiates an aura of courage, giving a +8 bonus on morale saves for all allies within 100 feet..  
**-Turn Undead (Su):** Sixteen times per day, Tyr may turn undead as a 47th level cleric  
**-Cure Disease (Sp):** Nine times per week, he may inflict disease with his touch per the _cure disease_ spell  
**Bureaucratic Knowledge (Ex)** Tyr receives a +10 bonus on his Knowledge and Gather Information checks whenever they are related to laws or legal proceedings. He also gains the bonus on any Charisma based skill to argue legal matters.  
**Maimed God’s Boon (Su):** Tyr receives a +13 bonus on all saving throws against spells with the chaotic descriptor or against spell-like or supernatural abilities of chaotic outsiders.  
**Order’s Calm (Su):** Once per day with a touch, Tyr may negate the following effects: _heroism, rage, symbol of insanity_, any fear effect, or a barbarian’s rage ability. The target receives a Will save (DC: 28 ) to avoid the effect  
**Aura of Absolute Law(Su):** Tyr is surrounded by a constant _dispel chaos_ effect at all times. Driving a chaotic outsider back to its home plane or dispelling a chaotic enchantment spell temporarily discharges and ends the effect, but Tyr may reactivate it as a free action on his next turn.  
**- Divine Immunities:** Ability damage, ability drain, cold, death effects, disease, disintegration, energy drain, fire, mind-affecting effects, paralysis, poison, sleep, stunning, transmutation, imprisonment, banishment.  
**- Divine Power:** Tyr is a living embodiment of power, and ancient divine magic flows through his veins. As such, mortal items are of virtually no use to his, being so much weaker than his own innate powers. Tyr gains no benefit from a deflection, enhancement, resistance, insight, sacred or profane bonus that is less than +18\. Note that this only applies to bonuses that affect Tyr himself; weaponry and armor is unaffected by this.  
**- Salient Divine Abilities**: Area Divine Shield, Call Creature (lawful celestials), Control Creatures (lawful celestials), Create Object, Create Greater Object, Divine Blast, Divine Creation, Divine Paladin, Divine Shield, Divine Skill Focus (judge), Divine Spellcasting, Divine Weapon Focus (long sword), Divine Weapon Specialization (long sword), Extra Domain (War), Extra Domain (Wrath), Judge the Divine, Know Secrets, Mass Divine Blast, Lay Quest, Overlord (lawful celestials), Possess Mortal, Power of Truth  
**- Alter Reality:** Tyr can use the _wish_ spell with regard to his portfolio, save for the replication of other spells. This ability costs Tyr no XP, and requires a standard action to implement. As a free action 18/day, for one round at a time, Tyr may add +13 to his weapon damage, he may instead add +13 to his caster level.  
**-Domain Powers:** Cast good and law spells at +1 caster level, +4 bonus on dispel checks. Once per day if struck in combat may inflict maximum damage to his attacker on the next hit. Once per day Tyr may make an attack of opportunity against any enemy that strikes him in melee combat.  
**- Spell-Like Abilities:** Tyr uses these abilities as a 78th level caster, except for good and law spells, which he uses as a 79th level caster. The save DCs are 51 + spell level. _affliction, aid, banishment, bear’s endurance, blade barrier, calm emotions, detect chaos, detect lies, detect thoughts, dictum, discern location, dispel chaos, dispel evil, divine power, doom, energize potion, fire shield, flame strike, geas/quest, greater sword and hammer, hold monster, holy aura, holy smite, holy word, imprisonment, last judgment, magic circle against chaos, magic circle against evil, magic vestment, magic weapon, mark of justice, order’s wrath, power word blind, power word stun, power word kill, protection from chaos, protection from evil, radiant shield, righteous might, righteous smite, shield of faith, shield of law, speak with dead, spell turning, spiritual weapon, storm of vengeance, summon monster IX, sword and hammer, true seeing, vengeance halo, zone of truth_  

**Judge the Divine (unique SDA):** Tyr is considered the judge and to an extent guide of the other gods. While within Cynosure and holding the gathering of Greater Powers, his will is usually accepted. To these ends he receives a bonus of +28 (10+his divine rank) to the following skills within Cynosure-Diplomacy, Intimidate, Knowledge (any), Profession (judge), Sense Motive, and Spot.  

**- Spells:** As a 30th level cleric and 15th level paladin of honor, 31st and 16th for law or good spells.  

**- Cleric Spells/Day (Levels 0-19 ):** 6/10/10/10/9/9/9/9/7/7/4/4/3/3/3/3/2/2/2/2; base DC = 30 + spell level, or 31+spell level for law spells  

**-Paladin Spells/Day (Levels 1-19):** 9/9/9/8/5/5/5/5/4/4/4/4/3/3/3/3/2/2/2/2; base DC: 30 + spell level, or 31+spell level for law spells  

**- Possessions**: Tyr carries _Justicar_, a _+10 axiomatic power holy power vorpal long sword_; it also has all the powers of an _holy devastator_ and a _mace of ruin_. Anyone struck by Justicar must speak the truth for the next 18 hours. (Will save DC: 65) (Caster Level: 25th, Weight: 6 lb.). Tyr also wears an adamantine band around his right wrist. It acts as a _ring of adamant law_ and _virtuous good._  

**Other Divine Powers**  
- As a greater deity, Tyr automatically receives the best possible result on any die roll she makes (including attack rolls, damage, checks, and saves). He is immortal.  
**- Senses:** Tyr can see (using normal vision or low-light vision), hear, touch, and smell at a distance of eighteen miles. As a standard action, she can perceive anything within eighteen miles of his worshipers, holy sites, objects, or any location where one of his titles or name was spoken in the last hour. He can extend his senses to up to twenty locations at once. He can block the sensing power of deities of his rank or lower at up to two remote locations at once for 18 hours.  
**- Portfolio Sense:** Tyr senses any injustice eighteen tendays before it happens and retains the sensation for eighteen tendays after the event occurs.  
**- Automatic Actions:** Tyr can use Knowledge (arcane), Knowledge (history), Knowledge (local), Knowledge (nobility), Knowledge (planes), Knowledge (religion), or Profession (judge) as a free action if the DC for the task is 30 or lower. He can perform up to twenty such free actions each round.  
**- Create Magic Items:** Tyr can create any kind of magical arms or armor or any magic item that confers the ability to cut through illusions and lies.  

* * *

A great creation of [DiceFreaks](http://community.dicefreaks.com/) and copied here for reference.
