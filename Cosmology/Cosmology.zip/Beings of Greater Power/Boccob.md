---
fileType: Cosmos
cosmosName: Boccob
cosmosType: Greater Deity
---
# Boccob
_The Uncaring, Lord of All Magicks, Archmage of the Deities_  
**Greater Deity**  
**Symbol:** An eye balanced on a pedestal inside a pentagon  
**Home Plane:** The Divided Unity of Concordant Opposition  
**Alignment:** Neutral  
**Portfolio:** Magic, arcane knowledge, foresight, balance  
**Worshippers:** Arcanists, philosophers, sages  
**Cleric Alignments:** CN, LN, N, NE, NG  
**Domains:** Balance, Knowledge, Magic, Spell, Trickery  
**Favored Weapon:** _Staff of the Archmagi_ (Quarterstaff)  

**Wizard 10/Loremaster 40/Archmage 10**  
**Medium-size Outsider**  
**Divine Rank:** 17  
**Hit Dice:** 10d4 + 40d4 + 10d4 + 603 (843 hp)  
**Initiative:** +11 (Dex)  
**Speed:** 60 ft. (12 squares)  
**AC:** 85 (+9 deflection, +11 Dex, +17 divine, +1 dodge, +5 luck, +32 natural), touch 53, flat-footed 74  
**Base Attack/Grapple:** 50/73  
**Attacks:** _Staff of the archmagi_ 83 melee (6+13); or _arcane fire_ 79 ranged touch (100 + 10/spell level); or spell 73 melee touch, or 79 ranged touch.  
**Full Attack:** _Staff of the archmagi_ 83/78 melee (6+13); or _arcane fire_ 79/74 ranged touch (100 + 10/spell level); or spell 73/68 melee touch, or 79/74 ranged touch.  
**Space/Reach:** 5 ft. x 5 ft./5 ft.  
**Special Abilities:** Alter reality, arcane fire, greater lore, lore ∞, mastery of counterspelling, mastery of elements, mastery of shaping, spell-like abilities, true lore.  
**Special Qualities:** Backlash resistance 17, divine immunities, DR 30/epic and mithral, secrets, sonic resistance 22, spell power +1, SR 119.  
**Saves:** Fort 74, Ref 75, Will 84.  
**Abilities:** Str 21, Dex 33, Con 30, Int 61, Wis 39, Cha 28.  
**Skills:** Bluff 92, Concentration 93, Craft (alchemy) 108, Craft (bookbinding) 108, Craft (gemcutting) 108, Decipher Script 108, Diplomacy 92, Gather Information 92, Heal 97, Intimidate 92, Knowledge (arcana) 127, Knowledge (architecture and engineering) 108, Knowledge (dungeoneering) 108, Knowledge (geography) 108, Knowledge (history) 108, Knowledge (nature) 108, Knowledge (nobility and royalty) 108, Knowledge (the planes) 108, Knowledge (religion) 108, Profession (apothecary) 97, Profession (herbalist) 97, Search 108, Sense Motive 97, Spellcraft 139, Use Magic Device 109.  
**Feats:** Attune Gem, Augment Spell, Brew Potion, Craft Construct, Craft Magic Arms and Armor, Craft Rod, Craft Staff, Craft Wand, Craft Wondrous Item, Empower Spell, Energy Admixture (sonic), Forge Ring, Greater Spell Focus (all), Greater Spell Penetration, Heighten Spell, Quicken Spell, Scribe Scroll, Skill Focus (knowledge [arcana], spellcraft), Spell Focus (all), Spell Mastery (all), Spell Penetration, Spellcasting Prodigy (wizard), Twin Spell.  
**Epic Feats:** Advanced Metamagic, Augmented Alchemy, Enhance Spell x2, Epic Counterspell, Epic Spell Focus (all) (![cool.gif](http://miniworld.com/boards/style_emoticons/<#EMO_DIR#>/cool.gif), Epic Spell Penetration, Epic Spellcasting, Improved Heighten Spell, Intensify Spell, Master Staff, Multispell x4.  
**Salient Divine Abilities:** Arcane Mastery, Automatic Metamagic (empower spell, quicken spell), Craft Artifact, Create Object, Create Greater Object, Disc of Concordant Opposition, Divine Archmage, Divine Creation, Divine Spell Focus (all), Divine Spellcasting, Energy Storm (negative, positive), Extra Domain (Balance), Increased Spell Resistance x2, Iridescent Avatar, Lord of All Magicks, See Magic, Spontaneous Wizard Spells, Sunder & Disjoin (DC 28 ), True Knowledge.  
**Environment:** The Library of Lore  
**Organization:** Unique  
**Challenge Rating:** 61  
**Treasure:** Listed items.  
**Alignment:** Neutral  
**Advancement:** --  

Boccob the Uncaring seems not to care whether any worship or serve him, and sages have postulated that his power is linked directly to the strength of magic on Oerth. Nevertheless, the Archmage has a small number of worshippers spread throughout the Flanaess, with a handful of adherents in most major cities and some towns and villages. Boccob is primarily revered by sages, but he is also entreated for omens by seers and diviners and those who seek new magicks often ask his aid. The Archmage of the Gods is venerated by most of the human races of the Flanaess, outside of enclaves of pure Suel stock where the faith of Wee Jas is typically preeminent. Some believe he was the first human wizard of Oerth countless millennia ago.  

Boccob neither seeks nor avoids confrontation. He desires balance above alignment and knowledge above all. He is concerned with magical research and creation, manipulation of the “flux,” nexus points, and other manifestations of magic.  

The Lord of All Magicks is both gifted and cursed by his ability to foresee the future, for in it he sees the eventual disappearance of magic from Oerth, and the death of everything he holds dear. His appellation as the Uncaring is somewhat of a misnomer, as Boccob is actively battling to save Oerth from its creeping doom. The Archmage cares intensely about the weakening of the fabric of magic, and nearly all of his power is focused on delaying and reversing magic's apparently inexorable decline.  

Consumed by his self-appointed task of preserving magic, Boccob has little time for day-to-day events in the Flanaess. The Lord of All Magicks almost never leaves his realm, preferring to send his demipower servant, Zagyg the Mad. For his part, the Mad Archmage serves Boccob most carefully, but out of his own will and a desire to retain enlightened neutrality and uncertain humor everywhere. Boccob suspects, but cannot prove, that Tharizdun is behind magic's slow waning, and thus actively contributes to the Dark God's long-standing imprisonment. Boccob's relationship with Wee Jas is characterized by a healthy rivalry: where the Suel goddess of magic is primarily concerned with magic as a force in and of itself and mysticism, Boccob cares more for the manipulation of magic and magical artifice. Boccob's relationships with other gods such as Istus, Lendor, Cyndor, Delleb, and Zuoken are of mutual respect, but little warmth or interaction. For the most part, Boccob is a reclusive, driven scholar with little tolerance for extremism in any form and little interest in anything save magic.  

Boccob appears as wizened old man with silver hair and bright, intense eyes. He is clad in rich purple robes with shimmering gold runes stitched into the cloth, which appear to constantly shift and change. He always leans upon a long silver staff topped by a transparent crystal that seems to slowly and imperceptibly alter its shape and facets.  

**Alter Reality:** Boccob can use _wish_ with regard to his portfolio, save for the replication of other spells. This ability costs him no XP, and requires a standard action to implement. Boccob can alter his size as per the Alter Size salient divine ability in _Deities & Demigods_. He can likewise create avatars as per the Avatar salient divine ability from with no need to actually take it. Boccob adds once again his Intelligence modifier to determine spell saving throw DCs. 17/day, Boccob can add his Charisma modifier (+9) to his effective spellcaster level. This effects spell capability (damage, range, # of targets, etc), but not his actual number of spells per day.  

**Arcane Fire (Su):** Boccob can channel arcane spell energy into arcane fire, manifesting it as a bolt of raw magical energy. The bolt is a ranged touch attack with a range of 800 feet that breaks through barriers as a _divine blast_ and deals 100 points of damage plus 10 per level of the spell used to create the effect (maximum 350 damage from a 25th-level spell slot).  

**Arcane Shield (Su):** Boccob can channel arcane spell energy into a barrier that absorbs incoming attacks. The shield can absorb up to 10 points of damage per level of the spell used to create the effect before it collapses (maximum 250 damage from a 25th-level spell). The damage can be from any source, including a _divine blast_ attack. Boccob can adjust the shield so that it does not block damage that he ignores anyway. Boccob can only have one arcane shield at a time.  

**Domain Powers:** Boccob uses scrolls, wands, and other devices with spell completion or spell trigger activation as a 68th-level wizard. 17 times per day, he can add his Wisdom modifier (+14) to His Armor Class for 60 rounds (6 minutes). Boccob casts divination spells at +1 caster level.  

**Greater Lore (Ex):** At will, Boccob can understand a magic item as with the _identify_ spell.  

**Mastery of Counterspelling:** When Boccob counters a spell, not only is the spell negated, but Boccob's spell still casts normally, targeting the opposing caster. If the spell cannot affect the opposing caster, it is merely countered. Alternately, he can choose to turn the spell back upon the caster as if it were fully affected by a _spell turning_ spell, or simply negate the spell normally.  

**Mastery of Elements:** Boccob can alter an arcane spell when cast so it utilizes a different element from the one it normally uses. This ability can alter a spell with acid, cold, fire, electricity, or sonic descriptor.  

**Mastery of Shaping:** Boccob can alter area and effect spells that use burst, cone, cylinder, emanation, or spread shapes. He can create spaces within the spell’s area or effect that are not subject to the spell. The minimum dimension for these spaces is a 5 ft. cube. He can also change the shape of the spell itself. The new area must be chosen from the following list: cylinder (10-foot radius, 30 feet high), 40-foot cone, four 10-foot cubes, or a ball (20-foot radius spread). cylinder (10-foot radius, 30 feet high), 40-foot cone, four 10-foot cubes, or a ball (20-foot radius spread). Finally, he can increase the spell's area, range, or duration by 50 %. The spell works normally in all respects except for its shape.  

**Spell-Like Abilities:** At will—_antimagic field, anyspell, banishment, break enchantment, calm emotions, clairaudience/clairvoyance, clarity of mind, confusion, detect secret doors, detect thoughts, discern location, disguise self, dismissal, dispel magic, divination, false vision, find the path, foresight, greater anyspell, greater teleport, identify, imbue with spell-like ability, invisibility, legend lore, limited wish, mage armor, magic aura, mass sanctuary, mislead, Mordenkainen’s disjunction, nondetection, planeshift, polymorph any object, protection from spells, Rary’s mnemonic enhancer, screen, silence, spell resistance, spell turning, time stop, true seeing, weighed in the balance, word of balance_. Caster level 77th; save DC 46 + spell level.  

**True Lore (Ex):** Once per day, Boccob can use his knowledge to gain the effect of a _legend lore_ spell or an _analyze dweomer_ spell.  

**Backlash Resistance (Su):** Boccob has damage reduction 17 against backlash damage from casting epic spells. Each time he casts an epic spell with a backlash, that damage is reduced by 17 points (minimum 0). If the backlash damage continues for more than 1 round, the reduction is 17 points each round. Due to the fact that Boccob always rolls the best possible result, this effectively allwos him to ignore up to 17 dice of backlash damage.  

**Divine Immunities:** Ability damage, ability drain, banishment, cold, death effects, disease, disintegration, energy drain, fire, imprisonment, mind-affecting effects, paralysis, poison, sleep, stunning, transmutation, and turning.  

**Secrets (Ex):** Applicable knowledge, dodge trick, instant mastery, more newfound arcana, newfound arcana, secret health, secret knowledge of avoidance, secrets of inner strength, the lore of true stamina, weapon trick.  

**Disc of Concordant Opposition (SDA):** Boccob can weave positive and negative energy into a disc of pure destructive force with a radius of 170 feet. Anything in the area takes 204 points of either positive or negative energy damage (depending on which type of energy is more effective against the target). If a target is immune to both positive and negative energy, it still takes 34 points of divine energy damage. This effect does not automatically bypass spell resistance.  

**Divine Archmage (SDA):** Boccob possesses double the normal maximum number of archmage levels, and can select epic high arcana freely. He adds his divine rank to his ranks in Knowledge (arcana) to determine his number of epic spells per day, and gains backlash resistance equal to his rank. He has mastered the following high arcana: arcane fire, arcane shield, greater arcane fire, greater arcane shield, mastery of counterspelling, mastery of elements, mastery of shaping, spell power +1, true mastery of counterspelling, true mastery of shaping.  

**Iridescent Avatar (SDA):** Boccob can manifest a cloud of faintly-glowing purple energy in any location he can sense. This cloud can envelop any creature or object of Huge size or smaller in an effect similar to _fairy fire_. Every ten rounds, enveloped objects, including magic items, are affected as if by an _Azundel’s purification_ spell. Likewise, spellcasters that are enveloped by the energy receive the benefits of a _Rary’s mnemonic enhancer_ spell augmented to 16th level. Boccob can manifest up to twenty iridescent avatars at once.  

**Lord of All Magicks (SDA):** All of Boccob’s school-related feats and powers (such as Spell Focus) apply to all schools of magic. He gains the Greater Spell Focus and Epic Spell Focus feats as bonus feats. He can cast spells from any spell list (arcane or divine) as if they were wizard spells. Finally, he adds his divine rank as a bonus to all Knowledge (arcana), Spellcraft, and Use Magic Device checks.  

**Wizard Spells Per Day:** 15/16/16/14/14/14/14/13/13/13/10/9/9/9/9/8/8/8/8/7/7/7/7/6/6/6\. 71st caster level (72nd on Divination spells). 81st caster level to penetrate spell resistance and on dispel checks. Base DC = 57 + spell level. 8 epic wizard spells, up to Spellcraft DC 179 (204 with _moment of prescience_). Can cast arcane and divine spells from any spell list as wizard spells.  

Boccob's non-epic metamagic feats may be applied twice to the same spell (if applicable), and have level increases as follows: Augment Spell (varies), Empower Spell (automatic), Energy Admixture (sonic) (+4), Heighten Spell (varies), Qui