---
fileType: Cosmos
cosmosName: Alvarez
cosmosType: Demon Lord
---
# Alvarez
Demon Lord of Torture, Inquisitor of the Abyss  
Medium Outsider (Chaotic, Evil, Extraplanar)  

Hit Dice: 12d8 (outsider) plus 15d6 (assassin) plus 18d8 (cleric) plus 450 (780 hp)  
**Initiative:** +12 (+4 Dex, +8 Superior Initiative)  
**Speed:** 50 ft.  
**AC:** 45 (+4 Dex, +19 natural, +6 profane +6 armor), touch 21, flat-footed 45  
**Face/Reach:** 5 ft./5 ft.  
**Base Attack:** +30/+37  
**Attacks:** _Justified Suspicion_ melee +45 or 2 claws +37 or melee touch +37 or ranged touch +34  
**Full Attack:** _Justified Suspicion_ melee +45/+40/+35/+30 (1d8 plus +2d6 (unholy) plus +12 plus 1 Con (wounding)/19-20/x2) or 2 claws +37 (1d4 plus +7) or melee touch +37 or ranged touch +34  
**Special Attacks:** death attack (Fort DC 32), Ensure Loyalty, sneak attack +6d6, spells, spell-like abilities, Summon Demons, Touch of Agony, rebuke undead 13/day  
**Special Qualities:** darkvision 60 ft., Demon Lord qualities, DR 20/good and adamantine, hide in plain sight, immunities (fire, electricity, poison), improved uncanny dodge, poison use, resistances (acid, cold, fire) 20, SR 41, uncanny dodge  
**Saves:** Fort +36, Ref +32, Will +32  
**Abilities:** Str 25, Dex 18, Con 30, Int 24, Wis 28, Cha 30  
**Skills:** Bluff +45, Concentration +40, Craft (armorsmithing) +22, Craft (weaponsmithing) +21, Decipher Script +25, Diplomacy +43 (+51 against evil creatures), Gather Information +42, Knowledge (arcana) +37, Knowledge (religion) +47, Knowledge (the planes) +37, Intimidate +70 (+77 against evil creatures), Listen +32, Open Lock +19, Search +19, Sense Motive +57, Sleight of Hand +33, Speak Languages (Abyssal, Celestial, Common, Draconic, Infernal), Spellcraft +27 (+31 spells on scrolls), Spot +32, Use Magic Device +35 (+41 scrolls), Use Rope +29  
**Feats:** Craft Magic Arms and Armor, Empower Spell, Enlarge Spell, Eschew Material Components, Evil Brand, Extend Spell, Improved Critical (longsword), Improved Initiative, Weapon Focus (longsword), Vile Natural Attack (B), Willing Deformity (clawed hands)  
**Epic Feats:** Blinding Speed, Bonus Domain (Evil), Epic Weapon Focus (longsword), Superior Initiative, Vile Deathstrike  
**Climate/Terrain:** Torturous Truth (Layer 57 of the Abyss)  
**Organization:** Solitary (Unique) or Patrol (Duke Alvarez plus 2 Balors plus 2-8 Glabrezu)  
**Challenge Rating:** 33  
**Treasure:** _Justified Suspicion_, _bracers +6_  
**Alignment:** Chaotic Evil  
**Advancement:** N/A  

In his mortal life, the man that would come to be known as Alvarez was once an inquisitor for a religion on an obscure Prime Material Plane. However, as he aged he grew increasingly mentally unstable even as his power to hunt down individuals that he considered to be guilty of ‘heresy’ increased. There was no individual in his entire realm that did not fear his wrath, as both his insanity and power grew until eventually he ruled an entire continent with an iron-fisted and paranoid theocracy in which neighbor feared neighbor and the more ambitious of his servants made their careers through turning in their own families and friends. In this manner they earned his respect for their sacrifices...although even they knew better than to attract his attentions for too long, lest he come to suspect them.  

To this day nobody knows who started the revolution against the insanity and mass purges that marked Alvarez’s reign. The one point of agreement by all historians of the event is that it had to have come from outside his realm, as he had been too successful at annihilating and torturing anyone capable of such a revolt within his own kingdom. Some rumors say that it was one of the Defenders of Freedom themselves that was responsible. Eventually a revolution overthrew Alvarez, and he was slain. However, although the religion that he ostensibly served was lawful in nature, the chaos and insanity within his own mind was so powerful that his undying soul was dragged into the Abyss.  

Once in the Abyss, the sheer evil within the vestiges of his personality resulted in his rapid descent as a demon, until after being a demon for what may have only been several millenia a truly bizarre event, even for the Abyss, occured. The nature of the Abyss itself blessed him and resurrected him with a mockery of his original form, as well as with some of his original capabilities. At this point, he renamed himself Alvarez, the self-styled Inquisitor of the Abyss. It is unknown as to whether this was his ‘real’ name or not, as on the original world where he came from it was expunged from all records due to the horror and dread that it invoked in everyone who fought against the terrors that he brought.  

Shortly afterwards, he set about a task that would be an impossibility, but which made perfect sense to his fractured mind; to purge the Abyss itself of anything and anyone that negotiates with Law, as such behavior is an insult to the purity of Chaos. In order to accomplish this end he has assembled an army of thousands of Demons and other beings that he has convinced using his unfortunately powerful skills at persuasion through torment in order to follow him in a quest to ravage the entire Abyss.  

Alvarez’s behavior has earned him the well-deserved emnity of scores of different other Demon Lords due to his depredations that have laid waste to their armies. However, their own chaotic natures have prevented them from cooperating effectively so far in order to form a common alliance against Alvarez’s slaughter.  

Far more serious opposition to Alvarez’s activities has come from the forces of Perdition, as well as the Demiurge Graz’zt.  

In the case of the former, the Perditions have many reasons beyond the general hatred of chaos to want Alvarez killed. The religion that Alvarez was an inquisitor for was actually in the process of being corrupted by the Perditions themselves to the point where they could co-opt it entirely into being a supportive cult for their own ends. In fact, although Alvarez was never aware of it until well after his death, Alvarez spent most of his mortal life as an unwitting servant of the Duke of Secrets, Surgat, until the chaos within him made him an unsuitable pawn. With the insanity of Alvarez being rapidly followed by the demise of the empire held together through his pogroms, the religion lost all credibility and therefore became no longer suitable for their purposes. Further incensing Surgat, many of Alvarez’s victims have actually been real agents of The Snitch’s, causing no small amount of frustration to his plans and forcing him to resort to certain contingencies, as well as making the possibility of a comparatively direct conflict between them quite likely in the future.  

Simoultaneously, Alvarez’s prowess at inflicting pain has also aroused the interest of the Lords of the Fourth Perdition, Fierana and Belial. Although both of them would incinerate Alvarez with no hesitation should he attempt to impede their plans, secretly neither of them would like for his unique ‘talents’ to go to waste and have been concocting plans in order to turn Alvarez back to the path of Law, where he could join them as one of their most competent torturers after a sufficiently millenia-long and painful period of re-education.  

In the case of the latter, Alvarez additionally loathes the Demiurge of Shadows, Graz’zt. As far as Alvarez is concerned, the idea of all evil, unified under a single ruler is utterly ridiculous. In Alvarez’s twisted views, that which is not chaotic evil in nature must be exterminated, or temporarily tolerated until sufficient power can be acquired in order to slaughter it. While Graz’zt is far beyond Alvarez’s reach in terms of his sheer power, he is also curious as to how Alvarez has risen in power so quickly and whether some other force is behind such a rapid increase. So far, his suspicions have been unconfirmed.  

Alvarez appears as a male human dressed in elaborate and, unusually for the Abyss, immaculately clean clothing. His hair is oily blue-black and slicked backwards to his skull, and his eyes are a solid, blazing orange without pupil or iris-which is one of the only features that betray his true nature besides his gaunt, clawed hands. He constantly sings religious hymns whose lyrics have been modified to praise the unending chaos and evil of the Abyss even while he is fighting. He only shows a tight-lipped smile when he is doing what he considers to be his job-namely ‘cleansing’ an Abyss that is filled with so many failures to his high ideals.  

Alvarez rules Torturous Truth (Layer 57 of the Abyss), a wasteland filled entirely with an array of torture equipment and execution systems so diverse that it is rumored to be the equivalent of Thuldanin for such horrid devices and that one example of all such equipment ever invented eventually arrives here. More demons would visit it for their own ‘enjoyment’ except for the fact that they are very well aware of the fact that to do so would risk the tortures of Alvarez during one of his more paranoid fits. Alvarez and his armies patrol Torturous Truth relentlessly for any sign of intruders, and only the fact that Alvarez allows certain individuals to be released as examples of his power after being broken and tortured until their insanity is a pale reflection of his own permits the gathering of any information about the layer.  

Alvarez’s main fortress in Torturous Truth is the Hanging Citadel. It named as such not because it hangs, but because of the preponderance of living things that have been hanged in it, each in a unique and agonizing position of Alvarez’s own devising so as to keep victims alive and in pain for as long as possible. The ‘streets’ (such as they can be said to exist) are each named in accordance with a different method of execution.  

Alvarez is always armed with _Justified Suspicion_, which is an unholy, wounding, cold iron +5 longsword with the words “Through Pain Truth Shall Be Found” etched in the blade in Abyssal. He also typically wears a pair of +6 bracers.  

**Combat:** Alvarez is notoriously unpredictable in terms of whether he enters combat or not. Unfortunately for his opponents, Alvarez is often less interested in killing them outright than ‘making examples out of them’ and instead prefers to keep them alive for extended periods, whether because he enjoys it, he needs to heal himself, or because it is time for another motivational session. In comparison, his ministrations towards beings that are good and lawful are often far worse than physical death, as he will keep fallen opponents alive while using _love’s pain_ on them repeatedly, slaughtering their entire families and friends while explaining, patiently, exactly what he is doing to them. Generally creatures that have some idea of who or what Alvarez is and have no chance of escape are advised to ‘confess’ quickly, because doing so means that he will get bored with them and grant a relatively quick death.  

Should Alvarez choose not to enter combat immediately, it is generally because he instead desires that the beings he has confronted send messages to other demons or Demon Lords in the Abyss that their judgement is impending. To refuse Alvarez implies, to him, that one is likely to be cooperating with Law. After all, according to his deranged mind, only one who served Law would reject serving him. (Never mind the fact that telling another Demon Lord that they are about to be attacked by Alvarez tends to be a near-suicidal proposition-he does not accept this as a defense in any case). Should someone accept duty from Alvarez, he will use divinations to keep track of them and often spares their lives should they survive the tasking that he has assigned them.  

Alvarez will always kill outright any Demon that he suspects to be negotiating with ‘law’ in any form. Should one manage to escape from his attempts to slaughter them at first, he will go to great lengths to hunt them down later.  

**Ravaged Form-Humanoid:** Alvarez’s transformation to the status of a Demon Lord has returned to him some vestige of his original, human form, although the insanity and evil within his being becomes rapidly evident upon any conversation.  

**Ravaged Form-Magical Power:** Once a day Alvarez may cast the spell _eternity of torture_ (cast at 51st level; saving throw DC 29)  

**Summon Demons (Sp):** Alvarez may summon up to 30 HD worth of Demons once a day. Typically he will summon several Babau simoultaneously, although if faced with difficult opposition he will call a Balor and a Marilith, or several Vrock instead.  

**Demon Lord Qualities (Ex):** Alvarez is immune to electricity and poison; he possesses cold and acid resistance 10\. Alvarez may engage in telepathic communication with any creature within 100 feet. Alvarez constantly detects good and detects magic as a 21st level Sorcerer; he possesses immunity to polymorphing, petrification, or any other attack to alter his form. Alvarez additionally possesses fast healing 10 unless struck by a cold iron or holy weapon of at least +3 enchantment.  

**Spell-like abilities (Sp):** At will: _blasphemy, chaos hammer, chain lightning, confusion, detect law, disintegrate, dispel magic, dread word, enervation, greater dispel magic, mirror image, reverse gravity, sadism, greater teleport_ (self plus 50 pounds of objects only), _telekinesis, unhallow, unholy aura, unholy blight, wall of deadly chains._ 6/day: _destruction, temporal stasis, word of chaos._ 3/day: _implosion._ 1/day: _legend lore, mindrape, power word_ (stun), _soul shackles._ 1/week: _imprisonment, planeshift, ruin._ Cast at 51st level. Saving throw DC’s are DC 20 + spell level. The saving throw DC’s are Charisma-based.  

**Assassin Spells (Sp) (1st-4th level): 6/6/6/5** 1st level: _black bag, death grimace, feather fall, jump, sleep, true strike_ 2nd level: _alter self, cat’s grace, darkness, fox’s cunning, pass without trace, spider climb._ 3rd level: _deeper darkness, deep slumber, false life, magic circle against good, misdirection, nondetection_ 4th level: _dimension door, invisibility_ (greater), _locate creature, modify memory, poison._ Alvarez casts his Assassin spells at 24th level. Saving throws against his spells are DC 17 + spell level. The saving throw DC’s are Intelligence-based.  

**Clerical Spells (Sp) (0th-9th level): 6/8+1/7+1/7+1/6+1/6+1/4+1/4+1/3+1/**