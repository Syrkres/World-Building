---
fileType: Cosmos
cosmosName: Rehab
cosmosType: Demon Prince
---
# Rahab (Vepar, Sorath, Dagon)  
The Demon Prince of the Lightless Depths, the Deep One, the Lord of the Deeps, Mariner's Bane, the Bringer of Storms  
**Symbol**: A single round eye with no iris or pupil.  

**Gargantuan Outsider (Chaotic, Evil, Extraplanar)**  
**Hit Dice:** 39d8 (outsider) plus 20d4 (sorcerer) plus 10d6 (ur-priest) plus 6d6 (fiend of corruption) plus 600 (1088 hp)  
**Initiative:** +14 (+6 Dex +8 Superior Initiative)  
**Speed:** 60 ft., swim 110 ft.  
**AC:** 55 (-4 size, +6 Dex +23 natural +9 profane, +11 deflection), touch 32, flat-footed 49  
**Base Attack:** +57/+90  
**Attacks:** +71 melee primary oral tentacle and +69 melee 3 secondary oral tentacles or +67 melee primary arm/leg tentacle and +65 melee 9 secondary arm/leg tentacles or melee touch +64 or ranged touch +59  
**Full Attack:** +71 melee primary oral tentacle (2d6 plus +15 plus +1 (vile)) and +69 melee 3 secondary oral tentacles (2d6 plus +7 plus +1 (vile)) or +67 melee primary arm/leg tentacle (2d6 plus +11 plus +1 (vile)) and +65 melee 9 secondary arm/leg tentacles (2d6 plus +5 plus +1 (vile)) or melee touch +64 or ranged touch +59  
**Face/Reach:** 40 ft. by 40 ft./40 ft.  
**Special Attacks:** Absorb Souls, Abyssal Fury, Bounty of the Sea, Breath Weapon, Call Demons, Fiend’s Favor, geas 1/day, Horrid Form, mark of justice 1/day, Ravaged Forms (Poisonous Slime), soul bargain, spells, spell-like abilities, steal spell-like ability, suggestion 3/day, temptation  
**Special Qualities:** Break Summoning, Corrupting Presence, DR 25/cold iron and good, Demon Prince Qualities, Divine Interloper, divine spell resistance, fast healing 15/+3 cold iron or good, Fiendish Graft, fire vulnerability, grant wish 1/day, immunity to electricity, acid, and poison, immunity to water, major creation 3/day, mind shielding, Ravaged Forms (Alternate Form, Chromatophores, Enormous Eye, Tauric), resistances (fire, cold) 20, siphon spell power, SR 55, water mastery.  
**Saves:** Fort +47 Ref +45 Will +50  
**Abilities:** Str 33, Dex 22, Con 26, Int 23, Wis 32, Cha 33  
**Skills:** Bluff +69, Concentration +59, Diplomacy +51, Disguise +36, Escape Artist +36, Hide +31, Intimidate +89, Listen +26, Knowledge (arcana) +56, Knowledge (nature) +26, Knowledge (religion) +81, Knowledge (the planes) +61, Move Silently +36, Sense Motive +46, Speak Languages (Abyssal, Aquan, Celestial, Common, Infernal), Spellcraft +49, Spot +34, Survival +56 (+62 extraplanar, +60 find/follow tracks), Swim +89  
**Feats:** Combat Reflexes, Corrupt Spell-like Ability (B), Dark Speech, Empower Spell, Empower Spell-like Ability, Eschew Material Components (B), Heighten Spell, Improved Grapple, Improved Initiative, Malign Spell Focus, Multiattack, Quicken Spell, Still Spell, Vile Natural Attack (B), Violate Spell (polar ray), Weapon Focus (tentacles)  
**Epic Feats:** Automatic Quicken Spell(x3), Automatic Still Spell(x3), Epic Weapon Focus (tentacles), Expeditious Metamagic, Ignore Material Components, Improved Metamagic, Multispell, Superior Initiative, Vile Deathstrike  
**Climate/Terrain:** The Lightless Depths (Layer 871 of the Abyss)  
**Organization:** Solitary (Unique)  
**Challenge Rating:** 47  
**Treasure:** Quadruple Standard  
**Alignment:** Chaotic Evil  
**Advancement:** N/A  

One of the most dreadful of the horrors of the Abyss, Rahab, the Demon Prince of the Lightless Depths, is a tentacled monstrosity that desires nothing less than the domination of all seas. One of the oldest demons in existance, the primordial horror that is Rahab is a creature of slime, darkness, and insanity that only the strongest of wills can stand to look upon without losing their mind.  

Rahab's realm is the 873rd layer of the Abyss: the Lightless Depths. A water-filled realm, the Depths are literally without light: anyone without darkvision can see absolutely nothing in this layer. Here, Rahab swims through the black abyss, devouring the souls of those foolish or insane enough to call him their master. Unlike most other Demon Princes, Rahab shares his realm with several other powerful beings, including a number of myrmyxicuses. At one time he fought for his layer with dread King of the Deep, a demonic entity once beholden to the will of the now-dead goddess Takhisis, but the King was slain by heroes on the world of Krynn, and now Rahab's dominion over the Depths is unquestioned. It is likely that various other unique demons call the Depths home as well. These lesser horrors generally leave Rahab alone, and flee before his might when he approaches.  

Like many fiends, Rahab is known by many names. Some of his followers speak of him as Vepar and others as Sorath. Some cultists know him as Dagon, but that name rightfully belongs to one of Hell's devils.  

Because their "portfolios" overlap in regards to the slimy dwellers of the deep, Rahab is a sworn enemy of both the Demiurge Demogorgon and the dread Hadean god Panzuriel, but because of Rahab's relative weakness, clashes between their forces tend to be rare. Among the other powers he has made an enemy of are Sekolah of the sahuagin; Blibdoolpoolp of the kuo-toa; Eadro of the merfolk and locathah; Deep Sashelas of the elves; the Elemental Prince Ben-Hadar; and the human gods Aegir, Umberlee, and Poseidon. Of these, Poseidon is by far his deadliest rival: the Sea Father has sworn an oath to rid his oceans of Rahab's evil influence. It is common for Poseidon to recruit powerful heroes to brave the Lightless Depths and spy on his cultists' doings in the hopes that some headway might be made in his war against the demon. The Duke of Hell known as Dagon loathes Rahab as well for allowing the demon's followers to know him as Dagon.  

Unsurprisingly, Rahab has virtually no friends. The only ally he has is Olhydra, the Princess of Evil Water. Because of the distance between their realms, however, and Olhydra's fickle nature, he has not found her a very reliable ally.  

The goals of Rahab are the destruction of good sea life (such as aquatic elves) and the domination of neutral and evil denizens of the oceans. He has many worshippers among the creatures of slime and muck that dwell on the seabed: koprus, anguiliians, kuo-toas, ixitxachitls, rogue sahuagin, and even some renegade merfolk pay Rahab homage. All of these races have their own unique, foul rites that they perform in Rahab's name.  

Rahab has a fairly widespread following of human cultists on the Prime Material Plane. Many a coastal fishing town has found itself at the mercy of a poor harvest and turned to Rahab-worship in hopes of rectifying the situation. Indeed, Rahab frequently rewards his worshippers with greater catches of fish and harvests of grain, as well as gifts of gold. Such cultists make a common practice of summoning their demonic master to their plane of existance and offering a living sacrifice - indeed, Rahab actually encourages his followers to summon him. Such conjurations give him an opportunity to spread his corruption, transforming his worshippers into maddened inhuman reflections of their old selves, creatures of slime as hideous as their master. Such summonings typically involve a blood sacrifice and the destruction of a small golden pyramid inscribed on each face with his unholy symbol.  

Rahab is truly hideous. Only vaguely humanoid in shape, the Demon Prince of the Lightless Depths is a gargantuan cephalopoid monster. He looks something like a bloated, rubbery octopus, with a head like a human skull, a single cyclopean eye with no pupil set in its center. In place of a mouth, Rahab has a mass of ten-foot-long tentacles that dangle writhing from his head. Rahab has two huge tentacle-arms like those of an octopus that branch at each of their midpoints into ten squirming appendages. From his 'waist' depend twenty or more tentacles. His overall color is a dark green-brown, but Rahab can change his color to suit his whim. In addition to this hideous form, he can also change at will into a handsome merman some twenty feet from head to tail, with dark green skin and green-brown scales; he adopts this shape when summoned to the Prime by his human followers.  

**Combat**  
**Ravaged Form-Alternate Form:** At will, Rahab may shift forms into a a handsome merman some twenty feet from head to tail, with dark green skin and green-brown scales. The statistics for this form have been included in the block above.  

**Ravaged Form-Chromatophores:** Rahab may freely change the color of his rubbery exterior to better match his surroundings, or even blend into them perfectly, allowing him to simulate an invisibility spell in this manner although this effect cannot be dispelled.Rahab additionally recieves a +10 bonus on all Hide checks as long as he is underwater.  

**Ravaged Form-Enormous Eye:** Rahab’s enormous single eye enables him to see well in the incredible depths in which he is home; as a result, Rahab has 120 ft. darkvision and a +4 bonus to all Spot checks.  

**Ravaged Form-Oral Tentacles:** The four tentacles located below Rahab’s enormous eye and concealing his mouth are stronger than the rest of his tentacles, and as a result, have a +8 Str bonus; this has been taken into account in terms of his attack statistics.  

**Ravaged Form-Poisonous Slime:** Rahab’s entire body exudes toxic slime; as a result, creatures which touch Rahab or have the slime injected into their wounds must make a Fort save DC 55 or else take 1d10 initial Con damage and a second 1d10 Con damage one minute later.  

**Ravaged Form-Tauric:** Rahab’s torso trails off into 20 different 30-40 foot long tentacles. As a result, this provides him with a 100-foot speed bonus to his swim speed, and he may attack opponents with up to 5 of these additionally tentacles at a time in any given direction.  

**Ravaged Form-Tough Skinned:** Rahab’s slippery exterior grants him a +3 bonus to his natural AC.  

**Spell-like abilities:** at will: black tentacles, blasphemy, chain lightning, cloudkill, cone of cold, control water, deeper darkness, desecrate, destruction, detect good, detect law, dream, drown, greater dispel magic, fear, harm, mirror sending, read magic, shrivelling, suggestion, suggestion (mass), telekinesis, teleport without error (self plus 50 pounds), tongues, tongue tendrils, unhallow, unholy aura, unholy blight, wall of ice. 6/day: bestow curse, control weather, implosion, word of chaos. 3/day: power word (stun), symbol of death, summon monster IX (aquatic/water-based monsters only). 1/day: crushing hand, entice gift, ruin, trap the soul. 1/week: astral projection, greater ruin, slow. Rahab casts his spell-like abilities at 81st level. Saving throws against Rahab’s spell-like abilities is DC 21 + spell level. The saving throw DC’s are Charisma-based.  

**Abyssal Fury (Ex):** Rahab’s physical presence is so disgusting that is causes lesser creatures to succumb to his hate and need to spread destruction and terror. All creatures within 60 feet of Rahab must succeed in a Will save 58\. Those who succumb to Rahab’s gross presence suffer one of the two following effects:  

_Fright:_ Affected beings become shaken and suffer a -2 morale penalty on attack rolls, saves, and checks. The merest glance or gesture by Dagon makes them frightened, and they flee as quickly as they can, although they can choose the path of their flight.  

_Madness:_ The grotesque evil incarnate in Rahab’s being drives lesser beings insane per the insanity spell. The being remains stuck in a state of madness for one day for every point by which she failed the saving throw, after which time the victim is allowed another save. The madness exists until the victim successfully saves or the appropriate spells are cast by a 21st level being to purge the insanity effect.  
Rahab can make his servants, “worshippers,” beings of Chaotic Evil alignment, or a mixture of all three types immune to this effect as a free action. This immunity lasts one day or until Rahab dismisses it. However, Rahab cannot determine which effect takes place; there is a 50% chance each time Abyssal Fury is used that one or the other effect will impact near by victims.  

**Call Demons (Sp):** Two times a day Rahab may call up to 50 HD of Demons to aid it. When in an aquatic environment (which is virtually all of the time) he will call Myrmyxicuses and Advanced Wastriliths, which serve him out quickly out of the sheer terror that he also invokes in them due to his appearance. If he has been angered by something that dwells on land, he will call Balors instead and tell them to destroy the source of his ire, and then leave.  

**Corrupting Presence (Su):** Rahab’s presence is so heinous that it may corrupt an entire area with but a thought. Once per day as a standard action, Rahab may unhallow an area with a radius equal to 2625 feet centered around it. Rahab can apply the following spells to the unhallow effect (some of which are not listed as part of the unhallow spell in the Player’s Handbook): bane, bestow curse, contagion, deeper darkness, dispel magic, silence. In most situations, Rahab will select dispel magic.  

The forces of righteousness disgust Rahab, who finds goodness repellent enough to give it pause. As a result, Rahab avoids hallowed ground. If Rahab finds it necessary to enter a hallowed site, it must make a Will DC save equal to 40 + the divine rank of the represented god + the god’s Charisma modifier; Rahab cannot use it’s spell resistance to overcome this effect. If Rahab succeeds in entering the hallowed area, the area immediately becomes unhallowed. Once Rahab breaches holy ground, the god in question is immediately alerted to his presence and will often (DM’s discretion) send a proxy or an avatar to deal with the intrusion.  

**Demon Prince Qualities (Ex):** Rahab is immune to electricity and poison; he possesses cold and fire resistance 20\. Rahab may engage in telepathic communication with any creature within 100 feet. Rahab constantly detects good, detects magic, and true sees as a 31st level Sorcerer; he possesses immunity to polymorphing, petrification, or any other attack to alter his form. Rahab is not subject to energy drain, ability drain, or ability damage; he is also immune to mind-affecting effects. Rahab additionally possesses fast healing 15 unless struck by a cold iron or holy weapon of at least +3 enhancement.