---
fileType: Cosmos
cosmosName: Sulitiko
cosmosType: Demon Atrocity
---
# Sulitiko
**Sulitiko** (CR 26)  
**Demonic Atrocity**  
CE Medium Outsider Type (chaotic, evil, extra-planar)  
**Init** +9; **Senses** Listen +29, Spot +28, darkvision 60ft.  
**Languages** abyssal, celestial, common (Cheng-Ku), draconic, infernal, planar tradespeak, undercommon (Cheng-Ku)  
_____________________________________________________________  

**AC** 38, touch 19, flat-footed 28 (+9 dexterity, +19 natural armour)  
**hp** 464 (32 outsider), fast heal 20; **DR** 15/cold iron and good  
**Immune** immunity to electricity, fire, and poison  
**Resist** acid 10, cold 10 ; **SR** 34 (CR+8)  
**Fort** +30, **Ref** +29, **Will** +31  
_____________________________________________________________  

**Speed** 40 ft. (8 squares), fly 60 ft. (perfect)  
**Melee** Warfan +39/+34/+29/+24 (1d6+7) x4  
**Melee** Kiss +41 touch (3 negative levels)  
**Ranged** +41 touch  
**Base Atk** +32; **Grp** +39  
**Atk Options** energy drain, positive energy touch  
**Special Actions** assume identity, trusted advisor  
_____________________________________________________________  

**Spell-like Abilities** (CL 26th)  

At will – blasphemy (DC 32), charm monster (DC 29), deathwatch, dominate monster (DC 34), greater dispel magic, greater restoration, greater teleport, heal (DC 31), insanity (DC 32), power word stun, prismatic wall (DC 33), prismatic spray (DC 32), searing light, telekinesis (DC 30), unholy aura (DC 33)  
3/day – _maximised_ prismatic sphere (DC 34), true resurrection  
1/day – fire storm (DC 33), implosion (DC 34), summon descendants  
_____________________________________________________________  

**Abilities** Str 24, Dex 28, Con 30, Int 24, Wis 32, Cha 40  
**SQ** false alignment, positive energy bleed, tainted blood,  
**Feats (7)** Deceitful, exotic weapon proficiency (War Fan), leadership, negotiator, skill focus (Bluff), skill focus (Diplomacy)  
**Epic Feats (4)** epic leadership (54), epic skill focus (bluff), epic skill focus (diplomacy), legendary commander  
**Skills** Bluff +69, concentration +26, diplomacy +81, disguise +51 (or +55 when observed), escape artist +20, gather information +36 (or +38 on Cheng-Ku), hide +19, intimidate +41, knowledge (the Planes) +42, knowledge (local-{Cheng-Ku}) +25, knowledge (nobility and royalty) +42, knowledge (arcana) +42, listen +29, perform (acting) +50, perform (oratory) +36, ride +11, search +22, sense motive +46, spot +28.  
**Possessions** warfan, elaborate nobles robes  
_____________________________________________________________  

**Organization** Solitary, or with followers (see Epic Leadership feat)  
**Environment** On the Spirit World of the world of Cheng-Ku, or the 1074th Layer of the Abyss, the Realm of 10,000 Nascent Sorrows  
_____________________________________________________________  

**Ravage - Assume Identity (Su/Vile):** Sulitiko may assume the shape of a victim it has energy drained to death as a standard action. When in its assumed identity Sulitiko possesses the form, physical statistics (Str, Dex, and Con), Type (and any Subtypes), racial extraordinary abilities, and natural attacks of its victim, note this form ages at the same rate of the victim. Only the act of changing form is supernatural, the assumed form itself can not be dispelled or suppressed. Sulitiko can choose to have her assumed identity appear to be her true form with respect to True Seeing and similar effects. Sulitiko may choose whether her natural or assumed form appears to be 'true' as a free action.  

**Ravage – Energy Drain (Su/Abhorrent):** Any creature kissed by Sulitiko suffers 3 negative levels.  

**Ravage - False Alignment (Ex/Vile):** Sulitiko has the ability to emulate any alignment with respect to detection spells, item use, and feat/class requirements. This facade can be pierced by effects with a 37th or greater caster level. If pierced, she looses the use of feat/class abilities dependant on her simulated alignment for one year.  

**Ravage – Fast Healing (Ex/Vile):** Sulitiko is infused with positive energy, and has gained fast heal 20.  

**Ravage - Positive Energy Bleed (Su/Vile):** By her very nature Sulitiko frays the planar boundaries that separate the Positive Energy Plane from the plane on which she is currently located. This causes the leaking of positive energy into the immediate locality, but due to the nature of the leakage, this positive energy is polluted with anarchic and unholy energies as well. The effect of this leakage is greatest close to Sulitiko, such that the area within 50 feet of her gains the minor positive-dominant trait with respect to chaotic and evil creatures. Further away from her the leakage is less, but still noticeable, within a three mile radius the health of people, and their crops and livestock, is noticeably improved (+1 saves vs. disease), but due to the taint on this positive energy within the same distance mutations seem to be more common and tempers shorter, indeed 1% of creatures born within this radius gain the anarchic or fiendish template.  

**Ravage – Spell-like Abilities (Sp/2xVile):** Sulitiko has gained additional 54 levels of spell-like abilities.  

**Ravage - Trusted Advisor (Ex/Su/Vile):** Over the course of 20 hours spent in one-on-one contact with a target (which need not be continuous), Sulitiko may apply a permanent charm effect to the target, provided the fiend succeeds at converting the targets attitude to "helpful" by the end of the process using the diplomacy skill. The process itself is supernatural but the permanent charm effect is extraordinary.  

**Warp – Brilliant Energy Wings (Su):** Sulitiko's bat wings have been transmuted into light, similar to the appearance of brilliant energy weapons, making her flight a supernatural rather than extraordinary ability, with speed fly 60 ft. (perfect) rather than 90 ft. (good).  

**Warp – Positive Energy Touch (Su):** Sulitiko has lost her slams and normal magical weapons, and instead any wielded weapon gains the undead-bane property, as it is infused with positive energy, and either the anarchic or unholy property, whichever would be most advantageous against the current foe.  

**Warp - Size Reduction (Ex):** Sulitiko is smaller than most demons of power, appearing as a winged human woman of less than average height. She transfers the ability bonuses she would have received due to her large size, +8 strength and +4 constitution, to charisma and wisdom respectively. Apart from this, she suffers all the bonuses and penalties of reducing in size from large to medium.  

**Warp – Summon Descendants (Sp):** Rather than summoning lesser demons, Sulitiko instead summons her own tiefling, and half-fiend descendants. She may summon 4d10 1st level tieflings, 1d4 12th level tieflings, or 1 18th level half-fiend.  

**Warp - Tainted Blood (Su):** Using her control of the energies of birth and procreation, Sulitiko has altered the form that her half-fiend and tiefling descendants take, such that they show no outward physical sign of their abyssal heritage i.e. lose the wings and claws, and gains an equivalent supernatural fly ability and a lesser version of the False Alignment ravage, which can only hide alignment by one step. This replaces the fires which would usually course over her form, and the destruction which would normally accompany her death.  

This is Sulitiko as her house was destroyed by her machinations:  


**Appearance:**  

In her true form Sulitiko appears as a short, beautiful winged woman with long black hair, usually elaborately coiffured, who is gracefully entering early middle age. Her wings are formed from solid light, and as such their features are indistinct, being either feathered or bat-like. She personally avoids combat, preferring to talk her way out of trouble and then flee to plan an elaborate and painful demise for those who inconvenienced her, or to have her cohort and followers remove threats.  

**History:**  

Sulitiko was once nothing more than a common succubus who was summoned and bound by a powerful Thaumaturgist to bring down one of her enemies, a mighty daimyo of the Chrysanthemum Empire. Her true nature masked by the Shaman's magic, she was bound to seduce the daimyo, marry him, and then serve him and his house faithfully and loyally until the day that the Shaman attacked, and then betray him from within. Sulitiko did as she was commanded, and within a year was firmly ensconced within the daimyo's estates as a favoured young wife. Fate, however, intervened and the Thaumaturgist was slain by a war part of the daimyo's samurai, after warnings from his ancestor spirits alerted him to the existence of a threat but not its true nature. Realising the nature of her predicament, bound to obedient service and unable to directly harm her husband or the empire he faithfully served, Sulitiko conceived of a subtle plan to bring him and it down. To this end allowed herself to become pregnant with the first of an eventual 7 half-fiend daughters whose nature was suppressed by the remnants of the same spell which protected her, which she then proceeded to marry off to the scions of the most powerful clans in the empire. As Sulitiko planned, this infusion of fiendish blood into its greatest noble houses brought increasing strife and degeneracy to the empire, as the chaotic and evil tendencies of her grandchildren and great-grandchildren rose to the fore as they matured as the heirs of their respective houses. The fiendish taint spread rapidly (in fiendish terms) throughout the bloodlines of the empire, for despite their wicked nature the abyssal blood brought power, which in the increasingly dangerous and unstable empire was steadily more necessary for survival, and by the apparent death of Sulitiko, along with all who bore the name of her house, 83 years after her calling, during one of the perennial clan wars was present in 15 of the 17 of the surviving great families. Freed from her bondage by the destruction of the house she was bound to, she initially declined to return to the Abyss, instead she stayed close to the Material Plane in the Spirit Realm, where she answered petitions in the guise of an ancestor spirit, and tended the chaos she had caused. Within fifty years the central order of the empire had disintegrated, many of the major cities had been repeatedly sacked, and all had been transformed from bastions of culture and civilization to wicked dens of poverty and degradation, ruled by rapacious warlords as the capitals of around 25 virtually independent fiefdoms. Using the energies emanating from this shattered empire as a launch pad Sulitiko has ascended to the status of Demon Lord, and seeks to climb higher still by exporting this process to other lands and other worlds, and by completing the corruption of those few ancestor spirits that incorporated the souls of dead tiefling family members and the associated Abyssal taint, and so still answer their degenerate families' calls.  

**Nature:**  

As a being whose power comes directly from the act of bringing new creatures into the world, no matter that they are tainted with the foul energies of the Abyss, Sulitiko is aspected towards the Positive Energy Plane and her powers reflect this, such as her possession of healing powers, which is unusual for a demon. As a result of this alignment with respect to the energy planes, Sulitiko is hostile to undead, and orders those who serve her to go out of their way to destroy them, as their very presence pollutes the material plane with negative energy - causing the already low fertility of humanoid/demonic couplings to reduce even further - eroding her attempts to spread her own particular brand of corruption.  

**Organisation:**  

Infinitely more subtle than the run of the mill demon, Sulitiko recognises the need for others to help accomplish her ends. To this end she has set up a network of minions to aid in her breeding/infiltration projects, and given her own physical weakness relative to others of her status, to act as bodyguards. Disdaining most demons as too crass and unruly to work with, Sulitiko's network is primarily composed of her own descendants, and a few succubae whom she has 'convinced' to work with her.  

Sulitiko's cohort is effective level 32, a CE Maquis Half-Fiend Human Outsider 8/Fighter 2/Blackguard 26, with the Blackguard ability to command undead replaced by the ability to turn them. She is based in two locations, which are linked by a portal, the area of the Spirit World corresponding to the destroyed capital of the Chrysanthemum Empire, and the 1074th Layer of the Abyss, the Realm of 10,000 Nascent Sorrows, where most of her followers reside.  

**Relations to other Powers:**  

As a proponent of degradation rather than wanton destruction, Sulitiko views most of the mighty of the Abyss as obsolete, relics of a rapidly receding past, for she understands that only a tiny proportion of those souls drawn there truly desired the destruction of all, most only sought to satiate themselves by any means necessary, and as so are intrinsically opposed to attempts to destroy all that they desire. Sulitiko believes that this means that if any of the destruction orientated Princes come close to success, they will cease to be aligned to the power they draw upon or the uncounted souls they have absorbed, and will be torn apart under the strain. She also believes that this severe incompatibility between the goals of most of the Princes and the souls they draw from will provide the power she needs to fuel her advancement, and that things can only get better as the multiverse changes, and the Princes remain stuck in a mindset formed in the earliest epoch of creation, in opposition to the very virtue they should embody, change.  

By restricting her operation to regions of the prime where the spirits have not coalesced into gods, Sulitiko initially evaded the notice of the powers of the heavens, but now she has become sufficiently confident to expand her operations, it is only a matter of time before she draws the wrong (or right) kind of attention.  

