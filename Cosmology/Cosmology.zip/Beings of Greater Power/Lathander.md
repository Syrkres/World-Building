---
fileType: Cosmos
cosmosName: Lathander
cosmosType: Greater Deity
---
# Lathander - The Morninglord
_The Morninglord_  
Greater Deity  
Symbol: Sunrise made of rose, red, and yellow gems  
**Home Plane**: House of Nature (Elysium)  
**Portfoilo:** Athletics, birth, creativity, dawn, renewal, self-perfection, spring, vitality, youth  
**Worshipers**: Aristocrats, artists, athletes, merchants, monks (Sun Soul), the young  
**Cleric Alignment**: CG, LG, NG  
**Domains**: Glory, Good, Nobility, Protection, Renewal, Strength, Sun  
**Favored Weapon**: _“Dawnspeaker”_ (light or heavy mace)  

Lathander  
Sentinel 20/Cleric 40  
Medium Outsider (good)  
Divine Rank: 17  
**Hit Dice**: 20d10 (sentinel) + 40d8 (cleric) plus 720 (1,240 hp)  
**Initiative**: +14 (+10 Dex +4 Improved Initiative)  
**Speed**: 60 ft. (12 squares)  
**Armor Class**: 84 (+10 Dex, +17 divine, +32 natural, +15 deflection), touch 51, flat-footed 74  
**Base Attack/Grapple**: +40/+69  
**Attack***: _Dawnspeaker_ +92 melee (1d8+22 +3d6 fire +3d6 holy and 1 negative level, always inflicts maximum damage 30 points, 18 fire, and 18 holy); or spell +81 melee touch or +67 ranged touch. *always receives a 20 on attack rolls; roll die for critical check  
**Full Attack**:* _Dawnspeaker_ +92/+87/+82/+87 melee (1d8+22 +3d6 fire +3d6 holy and 1 negative level, always inflicts maximum damage 30 points, 18 fire, and 18 holy); or spell +81 melee touch or +67 ranged touch. *always receives a 20 on attack rolls; roll die for critical check  
**Space/Reach**: 5 ft./5 ft.  
**Special Attacks**: Domain powers, salient divine abilities, spell-like abilities, spells, turn undead 18/day, smite evil 10/day, turn evil outsiders 18/day  
**Special Qualities**: Divine aura (17 miles, DC 43), divine immunities, DR 30/epic and mithril, acid resistance 23, godly realm (100 miles outer plane, 1,700 ft. Material Plane), greater teleport at will, plane shift at will, remote communication, SR 79, speak, and read all languages and speak directly to all beings within 17 miles, dispel evil 4/week, aura of good, aura of courage, resist fiendish lure, celestial fortitude, detect evil, fast healing 37  
**Saves**:* Fort +76, Ref +68, Will +76 *always receives 20 on saves  
**Abilities**: Str 35, Dex 30, Con 34, Int 26, Wis 47, Cha 40  
**Skills**:* Appraise +35, Concentration +92, Diplomacy +103, Handle Animal +43, Heal +99, Intimidate +43, Knowlege (arcana) +55, Knowledge (history) +55, Knowledge (nobilty) +65, Knowledge (religion) +97, Knowledge (the planes) +55, Listen +58, Perform +64, Ride +40, Search +32, Sense Motive +68, Spellcraft +90, Spot +58, Survival +40  
**Feats**: Consecrate Spell, Empower Spell, Improved Initiative, Quicken Spell, Power Attack, Purify Spell, Weapon Focus (heavy mace)  
**Epic Feats**: Automatic Quicken Spell(x3), Chain Spell, Cleave, Epic Spellcasting, Great Smite, Heighten Spell, Improved Critical (heavy mace), Multispell(x3), Overwhelming Critical (heavy mace), Twin Spell  
**Environment**: House of Nature  
**Organization**: Unique  
**Challenge Rating**: 61  
**Treasure**: _Dawnspeaker_  
**Alignment**: Neutral Good  
**Advancement**: --  
**Level Adjustment**: --  

- _Detect Evil (Sp)_: At will, Lathander can _detect evil_.  
- **Smite Evil (Su)**: Ten times per day, Lathander can smite an evil enemy. He gains a +15 bonus to hit, and inflicts +80 damage.  
- **Lay on Hands (Su)**: Lathander can use his touch to heal up to 300 hit points of damage  
- **Aura of Courage (Su)**: All good creatures in 100ft of Lathander receive a +8 morale bonus to save vs. fear  
- **Turn Undead (Su)**: Eighteen times per day, Lathander can turn undead as at 57th level ability  
- **Turn Evil Outsider (Su)**: Eighteen times per day, Lathander can turn an evil outsider at 57th level ability  
- _Dispel Evil (Sp)_: Four times per week, Lathander can dispel evil as the spell.  
- **Resist Fiendish Lure**: Lathander has a +4 sacred bonus to all saving throws to resist the mind-affecting attacks of evil outsiders.  
- **Celestial Fortitude**: Lathander receives a +2 sacred bonus on all Fortitude saves against evil outsiders and evil spells. If he makes a successful save on an attack the normally does partial damage with a save, he instead takes no damage or effect.  
- **Divine Immunities**: Ability damage, ability drain, cold, death effects, disease, disintegration, energy drain, fire, mind-affecting effects, paralysis, poison, sleep, stunning, transmutation, imprisonment, banishment.  
- **Divine Power**: Lathander is a living embodiment of power, and ancient divine magic flows through his veins. As such, mortal items are of virtually no use to his, being so much weaker than his own innate powers. Lathander gains no benefit from a deflection, enhancement, resistance, insight, sacred or profane bonus that is less than +17\. Note that this only applies to bonuses that affect Lathander himself; weaponry and armor is unaffected by this.  
- **Salient Divine Abilities**: Banestrike (undead), Call Creatures (celestials), Divine Blast, Divine Fast Healing, Divine Inspiration (hope), Divine Radiance, Divine Paladin, Divine Shield, Divine Spellcasting, Enemy of Darkness (unique SDA), Extra Domain (Glory), Extra Domain (Protection), Extra Domain (Strength), Gift of Life, Life and Death, Mass Divine Blast, Mass Life and Death, Power of Nature, Rejuvenation, Sunder and Disjoin, Wrath of the Dawn (unique SDA)  
- **Alter Reality**: Lathander can use the _wish_ spell with regard to his portfolio, save for the replication of other spells. This ability costs Lathander no XP, and requires a standard action to implement. Lathander adds once again his Strength modifier to attack rolls and his Wis modifier to his spellcasting DC. As a free action 17/day, for one round at a time, Lathander may add +15 to his weapon damage or +15 to his caster level  
-**Domain Powers**: Cast good spells at +1 caster level, generate a protective ward 1/day, feat of strength +17 1/day, if reduced to 0hp, heals 1d8+15 1/day, speak for 1 round to give +1 morale bonus to allies and lasts for 15 rounds, turn undead with +2 bonus on checks and +1d6 turning damage  
- **Spell-Like Abilities**: Lathander uses these abilities as a 77th level caster, except for good spells, which he uses as a 78th level caster. The save DCs are 52 + spell level. aid, antimagic field,atonement, bigby’s clenching fist, bigby’s crushing hand, bigby’s grasping hand, blade barrier, blinding glory, bolt of glory, bull’s strength, celestial brillance, charm person, crown of flame, crown of glory, demand, discern lies, dispel evil, disrupt undead, divine favor, endure elements, enlarge person, enthrall, fire seeds, fire shield, flame strike, freedom, geas/quest, glorious raiment, greater command, greater restoration, greater shield of lathander, heat metal, hero’s feast, holy aura, holy smite, holy word, lesser restoration, magic circle against evil, magic vestment, mind blank, polymorph any object, prismatic sphere, protection from energy, protection from evil, reincarnate, remove disease, repulsion, righteous might, rosemantle, sanctuary, searing light, shield of lathander, shield other, spell immunity, spell resistance, stoneskin, storm of vengeance, sunbeam, sunburst, sunrise, summon monster IX, undeath’s eternal foe  

**Enemy of Darkness (unique SDA)**: Lathander is the ultimate enemy of all that is evil. His levels stack when he is determining his level to turn undead or outsiders and all his turn attempts are considered greater turnings. He can also automatically destroy any evil outsider or undead as a free action. He can do this as often as desired but it does count against the number of free actions allowed. Those with Divine Ranks require Lathander to spend a number of turn attempts equal to their DvR, they also receive a saving throw DC: 55 to resist being destroy. On a successful save they instead take 17d6 points of divine damage.  

**Wrath of the Dawn (unique SDA)**: Lathander can create light equal to full sunlight within seventeen miles in diameter for up to seventeen hours. (he must then wait until the next day to do so again). Within this radius he dispels all magical darkness instantly. All undead within this radius are instantly destroyed unless they make a Fort save DC: 55, on a successful save they still take 17d8 points of divine damage, those vulnerable to sunlight take 17d12 points of damage. Only those with more divine ranks then Lathander are immune to this power. His power over the sun also makes any fire based spells of Lathander more damaging, they are always considered intensified.  

- **Spells**: As a 40th level cleric and 10th level sentinel.  

- **Cleric Spells/Day (Levels 0-18 )**: 6/10/10/9/9/9/8/7/7/7/4/3/3/3/3/2/2/2/2; base DC = 47 + spell level  

-**Sentinel Spells/Day (Levels 1-18)**: 8/8/7/7/5/5/4/4/4/4/3/3/3/3/2/2/2/2; base DC: 47+spell level  

- **Possessions**: Lathander carries _Dawnspeaker_ a _+10 silver fiery blast holy burst mighty disrupting undead dread, outsider (evil) dread heavy mace_. It can also be commanded to become a _brilliant energy_ weapon as a free action (Caster Level: 40th, Weight: 5 lb.)  

**Other Divine Powers**  
- As a greater deity, Lathander automatically receives the best possible result on any die roll she makes (including attack rolls, damage, checks, and saves). He is immortal.  
- **Senses**: Lathander can see (using normal vision or low-light vision), hear, touch, and smell at a distance of seventeen miles. As a standard action, he can perceive anything within seventeen miles of his worshipers, holy sites, objects, or any location where one of his titles or name was spoken in the last hour. He can extend his senses to up to twenty locations at once. He can block the sensing power of deities of his rank or lower at up to two remote locations at once for 17 hours.  
- **Portfolio Sense**: Lathander senses any birth seventeen tendays before it happens and retains the sensation for seventeen tendays after the event occurs. He is similarly aware of everything that happens within an hour of each dawn. (This awareness is extended to the period within 3 hours of each dawn in the spring, when Lathander’s power waxes strong)  
- **Automatic Actions**: Lathander can use Knowledge (arcane), Knowledge (history), Knowledge (nobility), Knowledge (Planes), Knowledge (religion) as a free action if the DC for the task is 30 or lower. He can perform up to 20 such free actions each round.  
- **Create Magic Items**: Lathander can create any kind of item that confers magical healing, such as a _staff of healing_.  

* * *

A great creation of [DiceFreaks](http://community.dicefreaks.com/) and copied here for reference.
