---
fileType: Cosmos
cosmosName: Red Knight
cosmosType: Demigod
---
# Red Knight
_Lady of Strategy, Grandmaster of the Lanceboard_  
**Demigod**
Symbol: Red knight chess piece with stars for eyes  
**Home Plane:** Warrior’s Rest  
**Alignment:** Lawful Neutral  
**Portfolio:** Strategy, planning, tactics  
**Worshipers:** Fighters, gamemasters, monks, strategists, tacticians  
**Cleric Alignments:** LE, LG, LN  
**Domains:** Law, Nobility, Planning, War  
**Favored Weapon:** “Checkmate” (longsword)  

**Red Knight**  
**Marshal 20/Tactical Solider 10/Legendary Tactician 10**  
**Medium Outsider (lawful)**  
Divine Rank: 5  
**Hit Dice:** 20d8(marshal)+10d10(tactical)+10d8(legendary)+520 (860 hp)  
**Initiative:** +6 (+6 Dex)  
**Speed:** 60 ft.  
**Armor Class:** 66 (+1 Dex, +5 divine, +20 natural, +10 deflection, +6 shield, +14 armor), touch 26, flat-footed 65  
**Base Att/Grapple:** +32/+43  
**Attack:** _Checkmate_ +51 melee (1d8+23+3d6 law/17-20); or spell +38 melee touch or +33 ranged touch.  
**Full Attack:** _Checkmate_ +51/+46/+41/+36 melee (1d8+23+3d6 law/17-20); or by spell.  
**Space/Reach:** 5 ft./5 ft.  
**Special Attacks:** domain powers, salient divine abilities, spell-like abilities, flanker, offensive strike, delayed cleave, unbalancing blow, reciprocal strike, rout enemies  
**Special Qualities:** divine immunities, DR 15/epic and adamantine, fire resistance 10, spontaneous casting of divine spells, understand, speak, and read all languages and speak directly to all beings within 5 miles, remote communication, godly realm, greater teleport at will, SR 57, divine aura (50 ft, DC 25), Auras, Grant Move Action 5/day, defensive shield, interpose, leadership bonus+5, inspire courage (+4 4/day), direct troops, rally troops, hard march, battle standard, strategic retreat, the forlorn hope  
**Saves:** Fort +42, Ref +26, Will +34.  
**Abilities:** Str 33, Dex 22, Con 36, Int 34, Wis 28, Cha 30.  
**Skills:** Bluff +58, Climb +31, Concentration +53, Diplomacy +71, Handle Animal +30, Intimidate, +54, Jump +31, Knowledge (geography) +37, Knowledge (history) +70, Knowledge (nobility) +42, Knowledge (religion) +37, Listen +34, Profession (general) +57, Ride +31, Search +27, Sense Motive +57, Spot +39, Survival +34, Swim +31  
**Feats:** Cleave, Combat Reflexes, Extend Spell (![cool.gif](http://miniworld.com/boards/style_emoticons/<#EMO_DIR#>/cool.gif), Formation Expert, Great Cleave, Greater Weapon Focus (long sword), Improved Bull Rush, Leadership, Power Attack, Shock Trooper, Sidestep(![cool.gif](http://miniworld.com/boards/style_emoticons/<#EMO_DIR#>/cool.gif), Skill Focus (diplomacy)(![cool.gif](http://miniworld.com/boards/style_emoticons/<#EMO_DIR#>/cool.gif), Weapon Focus (long sword (![cool.gif](http://miniworld.com/boards/style_emoticons/<#EMO_DIR#>/cool.gif)  
**Epic Feats:** Devastating Critical (long sword), Epic Leadership, Epic Skill Focus (history), Epic Weapon Focus (long sword), Improved Critical (long sword), Legendary Commander, Overwhelming Critical (long sword)  
**Environment:** Warrior’s Rest  
**Organization:** Unique  
**Challenge Rating:** 35  
**Treasure:** _Checkmate_ (+4 axiomatic power longsword), +4 exceptional deflection heavy steel shield, +6 full plate  
**Alignment:** Lawful Neutral  
**Advancement:** --  
**Level Adjustment:** --  

**-Major Auras (Ex):** Red Knight can project a major aura to affect everyone within 60 feet, all major auras grant a +4 bonus and she can project one at a time. She knows the auras of Hardy Soldiers, Motivate Ardor, Motivate Urgency, Resilient Troops, and Motivate Attack  
**-Minor Auras (Ex):** Red Knight can project a minor aura in addition to her major aura. Her minor aura lets all allies within 60 feet add a +13 bonus to rolls. She knows the auras of Art of War, Master of Tactics, Master of Opportunity, Accurate Strike, Over The Top, Watchful Eye, Demand Fortitude, and Force of Will  
**-Flanker (Ex):** Red Knight can designate any adjustment square as the square from which flanking against an ally is determined.  
**-Interpose (Ex):** Thrice per day when an enemy makes a successful attack against an ally, Red Knight may take the damage as if she had been hit instead.  
**-Defensive Shield (Ex):** When fighting defensively Red Knight provides up to two adjacent allies with a +2 dodge bonus to armor class.  
**-Offensive Strike (Ex):** Red Knight can lower all her defensives and make a attacks with +4 bonus to attack and damage rolls for one round. During this time any successful hits are automatic threats and all saving throws automatically fail.  
**-Delayed Cleave (Ex):** If the last creature hit by Red Knight in melee combat is killed by someone else that still threatens the creatures area, Red Knight may make a cleave attack as an attack of opportunity.  
**-Unbalancing Blow (Ex):** Red Knight can use a full round action to in addition to causing normal damage, unbalances it so the creature provokes an attack of opportunity from all creatures threatening it.  
**-Reciprocal Strike (Ex):** Thrice per day Red Knight can make an attack of opportunity against any enemy that strikes an ally and inflicts damage.  
**-Inspire Courage (Su):** Four times per day Red Knight can give all allies able to hear her speak a +4 bonus to save against charm and fear effects, and a +4 bonus on attack and damage rolls. This effect lasts as long as she speaks and five rounds after.  
**-Direct Troops (Su):** Red Knight can bestow a +2 competence bonus on either attacks or skill checks to all allies within 30 feet. This bonus lasts for 13 rounds  
**-Rally Troops (Su):** Red Knights presence grants all allies within 30 feet a second saving throw against fear and charm effects that they have already succumbed to. Even if they fail a second saving throw effects are less severe. Panicked characters are frightened, frightened characters are only shaken, and shaken characters are unaffected.  
**-Hard March (Su):** Red Knight can exhort her troops to move faster. Anyone traveling with her gains a +4 morale bonus to Constitution checks require for making a forced march or any other tasks requiring extended exertion.  
**-Rout Enemies (Su):** She can exhort her troops into pressing the attack on fleeing foes. All allies within 30 feet of Red Knight gain a +1 morale bonus on attack and damge rolls on any attacks of opportunity against a fleeing enemy.  
**-Battle Standard (Su):** As long as Red Knights standard is within 30 feet of her, all allies within 300 feet gain the effects of both her, inspire _courage_ and _rally troops_ abilities. These effects remain as long as the standard does not fall or is captured. If the standard is fallen or captured they instead suffer a –1 morale penalty on attack and damage rolls until it is recovered.  
**-Strategic Retreat (Su):** While retreating all allies within 30 feet of Red Knight gain a morale bonus to their AC or +10 against any attacks of opportunity taken against them.  
**-The Forlorn Hope (Su):** Any allies within 30 feet of Red Knight will continue to fight while disabled or dying without penalty. They fight until –10 hit points. If they stop fighting they must make an immediate Fortitude save (DC: 15+1 per hit point below zero) or die on the spot.  
**- Divine Immunities:** ability damage, ability drain, acid, cold, death effects, disease, disintegration, electricity, energy drain, mind-affecting effects, paralysis, poison, sleep, stunning, and transmutation  
**- Salient Divine Abilities:** Battlesense, Divine Blast, Divine Shield, Divine Inspiration (courage), Irresistible Blows, Sunder and Disjoin  
**- Alter Reality:** Red Knight can use the _limited wish_ spell with regard to her portfolio, save for the replication of other spells. This ability costs Red Knight no XP, and requires a standard action to implement.  
**- Domain Powers:** Cast law spells at +1 caster level; free weapon focus (long sword); inspire allies for 10/rounds once a day; free extend spell feat  
**- Spell-Like Abilities:** Red Knight uses these abilities as a 45th-level caster, except for law spells, which she uses as a 46th-level caster. The save DCs are 35 + spell level. augury, blade barrier,calm emotions, clairaudience/clairvoyance, deathwatch, demand, detect scrying, dictum, discern lies, discern location, dispel chaos, divine favor, divine power, enthrall, flame strike, geas/quest, greater command, greater scrying, heroes’ feast, hold monster, imbue with spell ability, magic circle against chaos, magic vestment, magic weapon, order’s wrath, power word blind, power word kill, power word stun, protection from chaos, repulsion, shield of law, storm of vengeance, summon monster IX, time stop  

**- Possessions:** Red Knight carries _Checkmate_, a +4 long sword with the axiomatic power special abilitie (Caster Level: 25th; Weight: 6 lbs.), she also carries a exceptional arrow deflection spell turning glassteeled ruby shield+4 (Caster Level: 25th; Weight: 15lbs), and wears +6 full plate armor (Caster Level: 25th, Weight: 50lbs)  

**Other Divine Powers**  
- As a demipower deity, Red Knight treats a 1 on an attack roll or saving throw normally and not as an automatic failure. She is immortal.  
**- Senses:** Red Knight can hear, touch, and smell at a distance of five miles. As a standard action, she can perceive anything within five miles of her worshipers, holy sites, objects, or any location where one of her titles or name was spoken in the last hour. She can extended her senses to up to two locations at once. She can block the sensing power of deities of her rank or lower at up to two remote locations at once for up to five hours.  
**- Portfolio Sense:** Red Knight is aware of any battle involving any sort of planning of tactics, she is also aware of any games of strategy being played that involve one thousand or more people.  
**- Automatic Actions:** Red Knight can use Bluff, Diplomacy, Knowledge (history), Profession (general), or Sense Motive as a free action if the DC for the task is 15 or lower. She can perform up to five such free actions each round.  
**- Create Magic Items:** Red Knight can create any type of weapon, armor or item that improves allies combat abilities as long as the item’s market price does not exceed 4,500 gp.  

* * *

A great creation of [DiceFreaks](http://community.dicefreaks.com/) and copied here for reference.
