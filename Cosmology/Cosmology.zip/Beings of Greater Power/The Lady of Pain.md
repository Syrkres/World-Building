---
fileType: Cosmos
cosmosName: The Lady of Pain
cosmosType: Overgod
---
# The Lady of Pain

The archmage teleports into a shadowed corner of the room, glancing warily about.  

"I have the information you were wondering about", he says, "- for one-hundred thousand gold." Sensing your hesitance - or incredulity - he lowers his voice and states, "It wasn't easy to come by, you know. Years of study provided only scant clues, even for The One Named in Whispers." The young man draws his hood over his head and brushes aside a few strands of blonde hair.  

When you nod in agreement (if you do not, proceed instead to page 39_), he takes the_ bag of holding, inspects the contents, then secrets it away. Reaching into the folds of his black velvet robes, he produces a small, bound scroll - all that for a single page?  

"Oh, it's all there", the mage assures, as if hearing your thought. "Interesting notes, to be sure! But if you believe this will provide you with any advantage over Her... well, surely nothing is **invincible**, right?" He smirks.  

"I'm returning to the City. If you mean to follow me, I suggest you leave that behind."  

Phaedros disappears.  

# The Lady of Pain
**Her Serenity, Her Dread Majesty**  
**Overgod**  
**Realm:** Sigil, the City of Doors.  
**Alignment:** Neutral.  
**Portfolio:** Sigil, balance, pain.  
**Cleric Alignments:** None.  
**Domains:** None.  

**Medium Outsider (extraplanar, overdeity)**  
**Divine Rank:** 29  
**HD:** 150d8+2900+10500 (14,600 hp)  
**Initiative:** +43, always first (+35 Dex, +8 Superior Initiative, Supreme Initiative)  
**Speed:** 1450 ft., burrow 1450 ft., swim 1450 ft., fly 2900 ft. (perfect)  
**Armor Class:** 253 (+35 Dex, +36 deflection, +58 divine, +35 insight, +79 natural), touch 174, flat footed 218\. *The Lady is not hit on an automatic 20 if the attack would not hit her AC.  
**Base Attack/Grapple:** 150/263  
**Attack:** Flay 271 melee touch or 271 ranged touch (290 ft. range) (269 damage plus 30 bleeding damage per round/15-20/x5 plus 24 damage plus death [DC 120]); or spell 263 melee touch or 263 ranged touch.  
**Full Attack:** 29 flays 271 melee touch or 271 ranged touch (290 ft. range) (269 damage plus 30 bleeding damage per round/15-20/x5 plus 24 damage plus death [DC 120]); or spell 263 melee touch or 263 ranged touch.  
**Face/Reach:** 5 ft./5 ft.  
**Special Attacks:** Salient divine abilities, spells.  
**Special Qualities:** Divine aura (290 mile radius, DC 150), divine immunities, DR 58/--, fast healing 29, godly communication, godly realm (29,000 miles), improved evasion, improved mettle of will, improved mettle, regeneration 70, spell-like abilities, SR 179.  
**Saves:** Fort 190, Ref 190, Will 190.  
**Abilities:** Str 80, Dex 80, Con 80, Int 80, Wis 80, Cha 82.  
**Skills:** The Lady recieves a result of 273 on all skill checks, or 274 on Cha-based skill checks. She gains a +16 synergy bonus whenever applicable.  
**Feats:** Blind-Fight, Cleave, Combat Expertise, Dodge, Eschew Materials, Fly-by Attack, Great Cleave, Greater Weapon Focus (flay), Greater Weapon Specialization (flay), Heighten Spell, Improved Combat Expertise, Improved Critical (flay), Improved Disarm, Improved Heighten Spell, Improved Initiative, Mobility, Power Attack, Power Critical (flay), Spell Focus (all) (b) Weapon Focus (flay), Weapon Specialization (flay).  
**Epic Feats:** Devastating Critical (flay), Epic Dodge, Epic Spellcasting, Epic Weapon Focus (flay), Epic Weapon Specialization (flay), Ignore Material Components, Multispell (x4), Overwhelming Critical (flay), Penetrate Damage Reduction (adamantine, cold iron, evil, good, mithril, silver), Spectral Strike, Spell Stowaway (_heal_, _mass heal_, _time stop_), Spellcasting Harrier (-75), Superior Initiative.  
**Salient Divine Abilities:** Alter Reality (b), Alter Size (b), Annihilating Strike (Fort DC 138, or destroy 58,000 cubic feet of nonliving matter), Arcane Knowledge, Area Divine Shield (as a 580 square ft. barrier, or a sphere or hemisphere with a 58 ft. radius), Automatic Metamagic (intensify, silent, still, and quicken sorcerer spells), Avatar (none) (b), City of Doors*, Divine Celerity (58 minutes/day), Divine Blast (75/day, 1560 damage), Divine Dodge (79%), Divine Shield (73/day, 580 points), Divine Spellcasting, Divine Splendor (Fort DC 150, or 464 damage), Divine Weapon Focus (flay), Divine Weapon Specialization (flay), Energy Storm (positive or negative energy, 580 ft. radius, 58 damage/round), Extra Energy Immunity (acid, sonic), Flay*, Free Move, Frightful Presence (Will DC 140), Hand of Death (Fort DC 140), Irresistible Blows (flay), Know Death, Know Secrets, Lay Curse (Will DC 140), Lay Quest, Life and Death (Fort DC 150, or 464 damage), Mass Divine Blast (up to 290 targets, no two of which can be more than 58 miles apart; or in a 5800 ft. cone, a 2900 ft. burst or spread, or a cylinder with a 2900 ft. radius and a 580 ft. height), Mass Life and Death (Fort DC 150, or 464 damage), Maze*, Power of Truth (Will DC 140), Rejuvenation, See Magic, Sunder and Disjoin (DC 91), Supreme Initiative, True Knowledge, Wound Enemy (x5).  
*Unique salient divine abilities, described below.  
**Environment**: Sigil, the City of Doors.  
**Organization:** Solitary (unique); or with attendees (1d4 dabus).  
**Challenge Rating:** 208  
**Treasure:** None.  
**Alignment:** Neutral.  
**Advancement:** N/A  

The Lady of Pain appears as a tall, robed woman with a headdress of blades sprouting from around her serene, emotionless face. She always floats just off the ground and in complete silence. The Lady understands and can speak all languages, but never does so (communicating only through her dabus servants). The Lady does not accept worshippers or grant spells.  

- **City of Doors (Unique Salient Divine Ability):** The Lady of Pain has complete control over access to the city of Sigil, from all planes. In general, the only way to enter or leave the city is through portals. The Lady designates the locations where portals appear, where they lead, and the types of keys required to activate them. She may open, close, move, or otherwise change the function of any portal within Sigil as a free action (and perform up to 50 such actions per round). In addition, she may deny entrance to any creature with a lower divine rank than her. She does not permit any creatures of divine or quasidivine status to enter Sigil.  
- **Divine Immunities:** Ability damage, ability drain, acid, banishment, _binding_, cold, death effects, _dimensional anchor_, disease, disintegration, _dismissal_, electricity, energy drain, fire, _imprisonment_, mind-affecting effects, paralysis, poison, _repulsion_, _sleep_, _soul bind_, stunning, _temporal stasis_, _trap the soul_, turning or rebuking, transmutation.  
- **Flay (Unique Salient Divine Ability):** The Lady of Pain's natural attacks have a 18-20 base threat range and a x5 critical modifier. Any being slain by this attack cannot be ressurected unless the Lady wills it. The Lady's flay attack appears as her shadow reaching out towards the target, causing its body to errupt with countless slashes, wounds, and gouges, flaying the skin from their bones. (Her divine blast generally takes the same appearance).  
- **Maze (Unique Salient Divine Ability):** As a free action, up to 50 times per round, the Lady can banish a creature into a small demiplane of her creation (this effect can be resisted with a DC 150 Will save). Appearing much like the streets of her city, but endless and twisted in upon themselves, no two beings are ever sent to the same maze. These mazes are virtually impossible to escape from - it is believed that each has an exit, but such knowledge does little but infuriate those helplessly trapped within.  
- **Spell Like Abilities:** At will- _greater teleport, planeshift_. Caster Level 208th.  
- **Virtual Levels:** The Lady of Pain may cast spells as a 150th level sorcerer with knowledge of all spells. She may cast up to 16 epic spells/day, up to DC 289.  
_Spells Per Day (Levels 0-30):_ 6/15/15/15/14/14/14/14/13/13/8/8/7/7/7/7/6/6/6/6/5/5/5/5/4/4/4/4/3/3/3/3/2/2/2/2; save DC 47 + level.  

**Other Divine Powers:**  

- **Senses:** The Lady of Pain can see, hear, touch, and smell at a distance of 29 thousand miles. As a standard action, the Lady can perceive anything in a 290 mile radius. She can extend her senses to up to 50 locations at once. She may block the sensing power of deities of her rank or lower in up to 50 locations at once for 29 hours.  
- **Automatic Action:** The Lady of Pain can use any skill as a free action if the DC for the task is 50 or lower. She may use any skills that require movement, as long as she does not move more than her movement in the round. She can perform up to 50 such free actions each round.  
- **Create Magic Items:** The Lady of Pain can create any type of item.  

* * *

A great creation of [DiceFreaks](http://community.dicefreaks.com/) and copied here for reference.
