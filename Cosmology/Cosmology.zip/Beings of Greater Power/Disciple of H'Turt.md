---
fileType: Cosmos
cosmosName: H'Turt
cosmosType: Demon Lord
---
# H’Turt - Slaad Lord of Deception and Trickery
Large Outsider (Chaotic)Hit Dice: 56d8+448 (700 hp)  
**Initiative:** +8 (Dex, Improved Initiative)  
**Speed:** 30 ft  
**AC:** 36 (-1 size, +4 Dex, +21 natural)  
**Attacks:** 2 claws +71 melee, bite +66 melee  
**Damage:** Claw 3d8+10 plus sneak attack, bite 2d12+5 plus sneak attack  
**Face/Reach:** 5 ft by 5 ft/10 ft  
**Special Attacks:** Spell-like abilities, psionics, transmutation, summon slaad  
**Special Qualities:** Fast healing 15, damage reduction 30/magic, SR 28, chaotic radiation, plane shift, resistances, telepathy  
**Saves:** Fort +37, Ref +36, Will +39  
**Abilities:** Str 30, Dex 19, Con 28, Int 26, Wis 27, Cha 30  
**Skills:** Bluff +67, Climb +54, Concentration +58, Diplomacy +60, Disguise +58, Escape Artist +45, Gather Information +58, Intimidate +58, Survival +49, Knowledge (arcana) +52, Knowledge (planes) +52, Knowledge (religion) +52, Listen +54, Move Silently +46, Search +50, Sense Motive +52, Spellcraft +52, Spot +54, Tumble +50  
**Feats:** Cleave, Combat Casting, Dodge, Great Cleave, Enlarge Spell, Expertise, Improved Disarm, Improved Initiative, Improved Feint, Silver Tongue, Iron Will, Lightning Reflexes, Maximize Spell, Mobility, Power Attack, Quicken Spell  

**Climate/Terrain:** Any land and underground  
**Organization:** Solitary or troupe (2-8 red slaad and 2-6 blue slaad)  
**Challenge Rating:** 30  
**Treasure:** Double standard coins and gems; triple standard items  
**Alignment:** Always chaotic neutral  
**Advancement:** ---  

H’Turt is a charming, stylish slaad lord who appears as a lean, 9 foot tall slaad with light brown skin highlighted with black patches at the extremities in his natural form (he seldom appears in this form when amongst other races). H’Turt sports an unusual long mane of dark black hair, and is usually clad in ornate silk robes. He is the epitome of trickery and lies, and as one of the youngest slaad lords, he revels in his powers. He roams the planes, mischievously sowing tales of deception, taking a perverse pleasure in enliving the drab existence of others. Most of the elder slaad lords, leave H’Turt alone to his own devices. He likes this just fine, and takes advantage of the solitude to indulge himself in whimsical mischief.  
H’Turt has a sizeable entourage of lesser slaadi, surrounding him in his gallery in Limbo. They serve as his agents, spreading deception and trickery at his bidding.  
COMBATH’Turt makes use of magic and magic items as much as possible before entering melee. He enjoys taunting his opponents as he bluffs them into opening their defenses.  

**Spell-Like Abilities:** astral projection, charm person, charm monster, cloudkill, color spray, confusion, darkness, detect thoughts, detect magic, dominate person, dominate monster, light, fear, flame strike, major image, mass charm, mass suggestion, rainbow pattern, solid fog, suggestion, wind walk; 3/day - symbol (any); 2/day - prismatic spray, prismatic wall. These abilities are as the spells cast by a 20th-level sorcerer (save DC 21 + spell level).  

**Psionics (Sp):** At will - astral projection, charm monster, deeper darkness, detect evil, detect law, dimensional anchor, dispel good, levitate, and protection from law. These abilities are as the spells cast by a 20th-level sorcerer (save DC 21 + spell level).  

**Alternate Form (Su):** H’Turt can alter his body to match any creature he desires (as the shape change) spell at will in order to further his lies.  

**Lord of Deception (Ex):** H’Turt adds his intelligence modifier as well as his charisma modifier to all Bluff checks. He can also feint in combat as a free action (H’Turt can make inflict an additional 14d6 in sneak attack damage when a target is denied their dexterity bonus).  

**Plane Shift (Sp):** H’Turt can enter any of the Outer planes, the Inner planes, or the Material plane. This ability transports H’Turt and up to six other creatures provided they all link hands. It is otherwise similar to the spell of the same name.  

**Summon Slaad (Sp):** Three times per day H’Turt can automatically summon: one gray slaad; two green slaadi; 6-8 red slaadi; or 5-6 blue slaadi.  

**Telepathy (Su):** H’Turt can communicate telepathically with any creature within 100 feet that has a language.  

**Resistances (Ex):** H’Turt has acid, cold, electricity, fire, and sonic resistance 20.  
Additionally, H’Turt is immune to all illusion spells and mind-affecting enchantment spells and effects.

## Disciple of H’Turt
The disciple of H’Turt is a deceiver, troublemaker and charming rascal. He is more likely to spin a false tale than openly challenge a foe to direct combat. She uses deceit and trickery to sow mischief and spread chaos with an artistic touch. His abilities make him an astute prevaricator and sneaky combatant, and his agile tongue can influence anything from human lords to slaadi.  

Rogues and bards commonly become disciples of H’Turt. Clerics who worship H’Turt (the Slaad Lord of Deception, Seduction and Mischief) occasionally adopt this class.  

The considerable personal charm of a disciple of H’Turt often attracts followers or cohorts, but a disciple seldom leads more than a handful of followers at a time, as that requires more organization than a disciple can muster.  

Hit Die: d6  

Alignment: Any chaotic  
Skills: Bluff 10 ranks, Diplomacy 4 ranks, Gather Information 4 ranks  
Feat: Slaad Brother  
Special: Must make friendly contact with a slaad servitor of H’Turt.  

Class Skills: Appraise (Wis), Balance (Dex), Bluff (Cha), Climb (Str), Decipher Script (Int), Diplomacy (Cha), Disable Device (Int), Disguise (Cha), Escape Artist (Dex), Gather Information (Cha), Hide (Dex), Intimidate (Cha), Jump (Str), Knowledge (the Planes) (Int), Listen (Wis), Move Silently (Dex), Open Lock (Dex), Sleight of Hand (Dex), Profession (Wis), Ride (Dex), Search (Int), Sense Motive (Wis), Spot (Wis), Use Magic Device (Cha).  

Skill points at Each Level: 6 + Int modifier  

Weapon and Armor Proficiency: Disciples of H’Turt are proficient with all simple and martial weapons, all light armors, but no shields.  

LevelBABFort SaveRef SaveWill SaveSpecial  
1+0+0+2+2Tongue of H’Turt  
2+1+0+3+3Sneak Attack +1d6  
3+2+1+3+3Suggestion  
4+3+1+4+4Summon Blue Slaad  
5+3+1+4+4Sneak Attack +2d6  
6+4+2+5+5Frog Plague  
7+5+2+5+5Beguiling Nature  
8+6+2+6+6Sneak Attack +3d6  
9+7+3+6+6Summon Green Slaad  
10+8+3+7+7King of Lies  

Tongue of H’Turt (Ex): A disciple of H’Turt can speak with eloquence and believability, even when telling bold-faced lies, by using her cunning as well as her charm. When making Bluff checks, a disciple of H’Turt adds her Intelligence modifier as well as her charisma modifier to determine her check result.  

Sneak Attack (Ex): If a disciple of H’Turt of 2nd level or higher can catch an opponent when he is unable to defend himself effectively from his attack, she can strike a vital spot for extra damage. Basically, any time the disciple’s target would be denied his dexterity bonus to AC (whether he actually has a dexterity bonus or not), the disciple’s attack deals +1d6 points of damage. This extra damage increases by +1d6 points every third level afterward (+2d6 at 5th level, +3d6 at 8th level). Should the disciple score a critical hit with a sneak attack this extra damage is not multiplied. If a disciple of H’Turt get a sneak attack bonus from another source (such as rogue levels), the bonuses to damage stack.  
It takes precision and penetration to hit a vital spot, so ranged attacks can only count as sneak attacks if the target is 30 feet away or less. With a sap or an unarmed strike, a disciple of H’Turt can make a sneak attack that deals subdual damage instead of normal damage. She cannot use a weapon that deals normal damage to deal subdual damage in a sneak attack, not even with the usual -4 penalty, because she must make optimal use of her weapon in order to execute the sneak attack.  
A disciple of H’Turt can only sneak attack a living creature with a discernible anatomy – undead, constructs, oozes, plants, and incorporeal creature lack vital areas to attack. Additionally, any creature immune to critical hits is similarly immune to sneak attacks. Also, the disciple must be able to see the target well enough to pick out a vital spot and must be able to reach a vital spot. The disciple cannot sneak attack while striking at a creature with concealment or by striking the limbs of a creature whose vitals are beyond reach.  

Suggestion (Sp): Once per day, a 3rd level disciple of H’Turt can produce an effect identical to that of a suggestion spell. The DC to resist the disciple’s entreaties is 10 + disciple’s class level + disciple’s charisma modifier.  

Summon Blue Slaad (Sp): A 4th level disciple of H’Turt can summon 1 blue slaad once per day. This functions as a summon monster spell cast by a caster of 10 + the disciple’s class level.  

Poison Frog Plague (Sp): Once per day, a 6th level disciple of H’Turt can produce an effect identical to that of a insect plague spell cast by a caster of 10 + the disciple’s class level. The swarm summoned always consists of poisonous tree frogs.  

Beguiling Nature (Sp): Every other day, a 7th level disciple of H’Turt can produce an effect identical to the mass charm spell, with a Will save DC of 10 + disciple’s class level + disciple’s charisma modifier.  

Summon Green Slaad (Sp): A 9th level disciple of H’Turt can summon 1 green slaad once per day. This functions as a summon monster spell cast by a caster of 10 + the disciple’s class level.  

King of Lies (Ex): A 10th level disciple of H’Turt gains a +4 inherent bonus to Charisma.


