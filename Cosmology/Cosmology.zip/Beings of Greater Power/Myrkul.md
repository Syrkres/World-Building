---
fileType: Cosmos
cosmosName: Myrkul
cosmosType: Greater Deity 
obsidianUIMode: preview
---
# Myrkul
_Lord of Bones, Old Lord Skull the Reaper, Lord of the Dead_  
Greater Deity (DvR 17, deceased)  

**Portfolio:** The dead, wasting, decay, corruption, parasites, old age, exhaustion, dusk, autumn  
**Aliases:** N’asr (Anauroch, among the Bedine)  
**Divine Realm:** Bone Castle, Oinos, Gray Wastes (now the Crystal Spire, ruled by Kelemover)  
**Superior:** None  
Allies: Bane, Bhaal (deceased), Shar  
**Enemies:** Chauntea, Cyric, Lathander, Kelemover, Midnight, Mielikki  
**Worshippers Alignments:** LN, N, CN, LE, NE, CE  
**Symbol:** A white human skull face-on against a black field or a reaching white skeletal hand in white on a black field. In recent years, either symbol usually shown on an Inverted black shield with a continuous border of white, stylized human fingerbones)  

Myrkul (MER-kul), one of the Dark Gods, was the god of the dead, as opposed to the god of death, which was the province of Bhaal. His portfolio, and his home in Hades, the Bone Castle, were both usurped by Cyric after the Lord of Bones was destroyed atop Blackstaff Tower in Waterdeep during the Time of Troubles by Midnight. Later Myrkul’s portfolio passed to Kelemvor when Cyric was driven from the City of Strife by an alliance of gods and denizens.  

Myrkul had a cold, malignant intelligence, and spoke in a high whisper. He was always alert, never slept, and was never surprised. He was never known to lose his temper or be anything other than coldly amused when a mortal succeeded in avoiding his directives or chosen fates. His influence in Faerûn was imposed through fear, and he was a master of making mortals terrified of him through his words and deeds. At times, just to remain unpredictable, he seemed almost kind and caring. His cowled skull head was known in nightmares all over Faerûn, and he was the one deity that almost all human mortals could picture clearly. Myrkul took care that all mortals thought of him often—he was even known to materialize beside open graves, scythe in hand, just to gaze around at gathering mourners for a few silent seconds before fading away, in order to remind everyone that he was waiting for them all.  

Myrkul’s influence on the Realms was manifested through a variety of servitor creatures. He sent “Deaths” (identical to the minor death associated with the Skull card of a deck of many things), skeletons (all types, from crawling claws to blazing bones and crypt things), zombies (all sorts), and a wide range of other undead horrors to work his will. Myrkul unleashed armies of night riders astride gaunts against the still-living on more than one occasion.  

Myrkul sent bats, black panthers or leopards, hell hounds, nightmares, deepest red roses (that looked black and crumbled into dust when touched), jet, obsidian, onyx, ravens, and crows to show his favor or disfavor and to aid the faithful or harass his enemies.  

[[Tome of Myrkul]]

Medium Undead (Augmented, Extraplanar, Human)  
Ftr 4/Clr 6/Wiz 10/Mystic Theruge 10/Master of Shrouds 20  
Divine Rank 0  
**Hit Dice:** 50d12+500 (1100 hp)  
**Initiative:** +4 (+4 Dex, +4 Improved Initiative)  
**Speed:** 60 ft  
**AC:** 50 (+8 natural, +4 Dex, +10 deflection, +13 _studded leather +10_, +5 profane); flat-footed 49, touch 29  
**BAB/Grapple:** +31/+31  
**Attack:** _Reaper’s smile_ +47 melee (2d6+15 plus 2d6 unholy plus 2 negative levels/18-20/x4); or _bonefire_ +39 melee touch (3d6 cold or 3d6 and 1 Con drain/x2); or by spell melee touch +39 or ranged touch +35  
**Full Attack:** _Reaper’s smile_ +47/+42/+37/+32 melee (2d6+15 plus 2d6 unholy plus 2 negative levels/18-20/x4); or _bonefire_ +39/+34/+29/+24 melee touch (3d6 cold or 3d6 and 1 Con drain/x2); or by spell melee touch +39 or ranged touch +35  
**Face/Reach:** 5 ft./5 ft.  
**Special Attacks:** _bonefire_, domain powers, gravelight, hand of myrkul, spell-like abilities, spells  
**Special Qualities:** enhanced summoning, liche traits, divine immunities, DR 20/epic and bludgeoning, improved summoning, knowledge of the damned, regeneration 10, rebuke undead 17/day, SR 58, turning immunity  
**Saves:** Fort +27(34), Ref +25(31), Will +41(48)  
**Abilities:** Str 26, Dex 18, Con —, Int 34, Wis 40, Cha 31  
**Skills:** Concentration +60, Intimidate +60, Knowledge (arcana) +65, Knowledge (religion) +65, Spellcraft +81, 458 skill points  
**Feats:** Augment Summoning, Dark Speech, Empower Spell, Extraordinary Concentration, Extra Turning, Fell Animate, Fell Drain, Improved Critical (scythe), Improved Initiative, Greater Spell Focus (necromancy), Quicken Spell, Scribe Scroll, Spell Focus (conjuration), Spell Focus (necromancy), Weapon Focus (scythe)  
**Epic Feats:** Epic Spellcasting (divine), Epic Spellcasting (arcane), Epic Skill Focus (Spellcraft), Improved Metamagic, Improved Spell Capacity (13th) (cleric), Improved Spell Capacity (10th) (wizard), Multispell, Spectral Strike, Undead Mastery  
**Enviroment:** Any  
**Organization:** Unique.  
**Treasure:** _reaper’s smile, ring of resistance +7, studded leather +10_. 5005/7875k  
**Challenge Rating:** 46  
**Alignment:** Neutral Evil  

Myrkul appears as a skeleton clad in a billowing black cowled robe and wielding a scythe. He had scaly, wrinkled skin covered with knobby lesions and black, cracked lips. His eyes gleamed with a cold, evil light and were so sunken that his face looked like a skull. His chest and torso were bare bones, and he had four bony arms, not the usual two. Below the waist his bones were covered by withered sinews and wasted flesh.  

**COMBAT**  
**Liche Qualities:** Myrkul has been reborn as unique form of undead. Similar yet distinctly different from a traditional lich, Myrkul refers to himself as a liche. This state gives Myrkul the following traits and qualities:  
—+4 Str, +10 Int, +10 Wis, +6 Cha  
—DR 20/epic and bludgeoning.  
—Immune to cold, fire, polymorph (though Myrkul can use polymorph effects on himself), and mind-affecting attacks.  
—Myrkul gains bonus hit points equal to his Charisma bonus times his hit dice.  
—Regeneration 10\. Myrkul’s regeneration can be overcome by epic good silver weapons or spells with the Good descriptor.  
—Spell resistance score of 12 + his CR  
—_Turn Immunity_: Myrkul can not be rebuked, turned, controlled or destroyed by clerical turning.  
—_Divine Rank 0_: Myrkul possesses a divine rank of 0 and all attendant benefits.  

**Bonefire (Su):** Myrkul can create and control a sickly whitish-yellow raidiance known as _bonefire_. Myrkul can use his mastery of this strange necromantic force to produce any of the following effects:  
—Myrkul can make a touch attack inflict 3d6 points of cold OR fire damage, whichever is more harmful to the target, and 1 point of Constitution drain.  
—Myrkul may channel arcane and/or divine spell energy into a ray of coruscating _bonefire_. The ray requires a ranged touch attack to hit, has a range of 2000 feet, and inflicts 5d10 + 1d10 points of cold (or fire) damage per level of the spell used to create the effect and 5 points of Constitution Drain.  

_Note_: Creatures immune or resistant to cold and/or fire still suffer the Con drain, even if they reduce the cold/fire damage to 0.  

**Cleric Spells Per Day:** 4/9/9/8/8/8/7/6/6/6 3/3/2/2/2 or 701 spell points. Myrkul has access to the Death and Knowledge domains. Caster level 36th, 46th when casting spells from the Necromancy school. Save DCs are 24 + spell level.  

_Epic Spells Per Day_: 5\. Myrkul knows _anticipation, whispers of the hungry dead_. Caster level 36th, 46th when casting necromancy spells. Save DCs are 35 + modifiers (if any).  

**Divine Immunities:** Ability damage, ability drain, disintegration, energy drain, mind-affecting effects, and transmutation.  

**Domain Powers**  
_Death_: Once per day Myrkul can make a touch attack against a living creature. On a successful strike he rolls 26d6 and if the total is greater than or equal to the touched creature’s current hp, it dies. This is a death effect.  
_Knowledge_: Myrkul casts all divination spells at +1 caster level.  

**Enhanced Summoning (Ex):** Any creature Myrkul summons using his summon undead class ability receives +4HD, as if gained through advancement, even if that would normally advanced the creature beyond its listed maximum advancement.  

_**Epic Summon Undead (Sp):**_ Thrice per day Myrkul can summon incorporeal undead creatures or nightshades. Myrkul can summon four creatures with a CR of 14 or less, two CR 16 creatures, or one CR 18 creature with a single use of this ability.  

**Gravelight (Su):** Myrkul can unleash a cone of dark energy 50 feet in length up to five times per day. Any living creature caught in the area of effect must make a Fortitude save (DC 48, includes a +3 racial bonus) or die. A successful Fortitude save results in 5d10 points of damage from the residual necromantic forces. Any creatures slain outright or by this abilities secondary damage arise as lesser shadowraths one minute later.  

**Hand of Myrkul (Su):** Once per day Myrkul can surround his hands with eye-wrenching black flames. For the next four rounds Myrkul can make a touch attack once per round as a standard action. Any creature Myrkul touches takes 5d10 points of damage and must make a successful Fortitude save (DC 48, includes a +3 racial bonus) or be slain. The slain creatures arises 1d4 rounds later as a greater shadowrath under Myrkul’s control.  

**Immortality:** Myrkul is naturally immortal and cannot die from natural causes. Myrkul does not age, and does not need to eat, sleep, or breathe. Myrkul is not subject to death from massive damage. The only way for Myrkul to die is through special circumstances. If slain through physical or magical combat Myrkul’s form dissolves into dust and blows away. His spirit returns to the Crown of Horns and remains in a state of slumber for 50 years before reawakening. Once he has reawakened Myrkul must undergo the same process of moving from host to host, draining life force, until he finally has enough to seize control of a host and reform his body.  

**Improved Summoning (Ex):** Creatures summoned by Myrkul’s summon undead class ability are treated as if under the effects of a desecrate spell, granting them +2 hp per hit die and +2 profane bonus to attack rolls, damage, and saving throws. A summon creature however does not benefit from the desecrate spell’s reduction of turning ability.  

**Knowledge of the Damned (Ex):** Myrkul may make a special lore check with a +62 bonus equal to see whether he knows some relevant information about necromancers, undead creatures, legendary items or unholy places.  

A successful lore check will not reveal the powers of a magic item but may give a hint as to its general function. The lich may not take 10 or take 20 on this check; this sort of knowledge is essentially random.  

Code:  
DC Type of Knowledge  
10 How to distinguish between a zombie and a ghoul.  
20 The life and unlife of a powerful or legendary undead creature.  
30 The powers of an obscure type of undead, such as a deathbringer or famine spirit.  

Myrkul may attempt to research the True Name of a particularly noteworthy undead creature; this require a check against a DC of 10 + twice the being's HD.  

Finally Myrkul uses the sum of all his caster levels when determing his effective caster level of any necromancy spell he casts and may “lose” any prepared spell in order to cast any necromancy spell of the same spell level or lower at will.  

**Phantom Memory (Ex):** Myrkul benefits from a continuous nondetection spell as if cast by a 50th level sorcerer. This ability is even capable of confounding the sensory abilities of deities, requiring a deity make a rank check against a DC of 43 to successfully sense Myrkul using any spell, spell-like ability, supernatural ability, or salient divine ability.  

**Rebuke Undead:** Myrkul may rebuke or command undead as a 50th level cleric up to 17 times per day. In conjunction with his Undead Mastery feat Myrkul can control up to 500HD of undead.  

**Spell-like Abilities:** At will—_animate dead, contagion_ (DC 33), create undead, _enervation_, withering palm; 3/day—_create greater undead_, _destruction_ or _resurrection_, _foresight_. Caster level 50th. Myrkul’s lingering divine power grants his spell-like abilities a base save DC of 20 + spell level + Charisma modifier.  

_**Summon Undead (Sp):**_ Myrkul can summon 1 or more incoporeal undead up to 13 times per day. Myrkul can summon 1 dread wraith, 2 greater shadows, 4 spectres, 4 wraiths, or 4 shadows. This ability is otherwise identical to a summon monster spell.  

**Wizard Spells Per Day:** 4/4+1/4+1/4+1/4+1/4+1/4+1/4+1/4+1/4+1 2+1 or 431 spell points. Myrkul has access to the Death and Knowledge domains. Myrkul is a Necromancy specialist with a forbidden school of Illusion. Caster level 20th, 46th when casting spells from the Necromancy school. Save DCs are 21 + spell level.  

_Epic Spells Per Day_: 5\. Myrkul knows superb dispelling (no backlash, +45 check, DC 79), supreme ablating (Alratan). Caster level 20th, 46th when casting necromancy spells. Save DCs are 32 + modifiers (if any).  

**EQUIPMENT**  
**Reaper’s Smile:** This _cold iron unholy scythe +7_ is a terrible weapon, inflicting 2 negative levels (DC 35 to remove) on every successful strike. _Reaper’s smile_ strikes as a Large weapon and its threat range is increased by +1 after all other modifiers have been applied. (2840k)  

* * *

A great creation of [DiceFreaks](http://community.dicefreaks.com/) and copied here for reference.

* * *