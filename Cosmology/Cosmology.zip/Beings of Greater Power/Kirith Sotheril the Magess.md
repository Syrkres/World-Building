---
fileType: Cosmos
cosmosName: Kirith Sotheril the Magess
cosmosType: Lessor Deity
---
# Kirith Sotheril the Magess
*The Prismatic Sorcererss, The Piercer of Veils, The Enchanting Lady*
**Lesser Deity of Elysium**
**Symbol:** Rainbow-striped sphere  
**Home Plane:** Elysium  (Formerly known as Arborea), Olympus/Arvandor (Tethridar)  
**Alignment:** Neutral Good
**Portfolio:** Divination magic, enchantment magic, piercing illusions, revealing truth, radiance magic  
**Cleric Alignments:** Chaotic Good, Neutral Good, Lawful Good
**Domains:**           
**Divine Rank:**  9
**Superior:**  Corellon Larethian  
**Allies:** Alathrien Druanna, Azuth, Boccob, Corellon Larethian, Mystra, Savras, Tethrin Veraldé, Titania, the Seldarine, the Seelie Court  
**Foes:** Cyric, Eshebala, Gzemnid, Leira (dead), Mask, the Queen of Air and Darkness, Syrul, the drow pantheon (except Eilistraee)  
**Worshiper Alignment:** LG, NG, CG, LN, N, CN

The Magess, Kirith Sotheril (KEER-ith so-THAIR-il), is steward of the subtler magics of divination and enchantment among the elven pantheon. She is known as the Scintillating Lady, whose brilliance cuts through the veils of illusion and obfuscation to reveal truth. She takes her duties very seriously, but still always bears an enchanting smile for those who wish the elven peoples no harm.

One of the younger generation of elven powers, myth portrays the Magess as child of various divine couplings, most often Labelas Enorath and Hanali Celanil, but never is she seen as daughter of either Corellon Larethian or Sehanine Moonbow. In her youth, Kirith showed great aptitude for magic, and received training from Corellon himself, who then granted her dominion over divination and enchantment magics. Much of the mythic stories that involve Kirith revolve around the adventures of her and the other young powers, Tethrin Veraldé, Araleth Letheranil, Naralis Analor, and Melira Taralen, either all together or in subgroups. Many of these myths carry messages about the folly of youth and the importance of wisdom in actions; these myths always stress that good intentions and nobility of these young powers, however. One such myth is important to the illustration of Kirith’s powers and insight. In this tale, the young elven deities are off on another adventure to ruin the plans of an evil power, typically Lolth or the Queen of Air and Darkness. This villainous deity has learned of their plans, however, and weaves illusions to deceive the group, succeeding for a time. But Kirith eventually realizes the ruse, and saves her companions by cutting through the illusions, blinds their treacherous foe with a dazzling display of colored lights, and covers their escape by turning the evil power’s minions with charming magics. There are times when her magic is not enough, however, and in these tales, it is the elder powers of the pantheon who must step in and aid or save the brash youngsters.

Kirith Sotheril is on good terms with the other members of Seldarine, although there is some tension between her and Sehanine Moonbow due to the closeness of their portfolios. However, the pair are friendly, and any conflict is eventually resolved through amicable discussion, and Corellon has never felt the need to mediate their disputes. As she shares a realm with Tethrin Veraldé, it is widely believed the two powers are romantically involved, although neither deity answers queries about the matter from priests or sages. Until recently, their realm was located on a layer of Elysium, but since the Time of Troubles in Realmspace it has returned to Arvandor. Common belief holds that this is for greater protection against threats to the elven gods, but some sages speculate it was a commandment from Corellon Larethian in order to reinforce the united nature of the pantheon. Finally, Kirith works with other members of the pantheon as needed to enchant objects or divine hidden information as need, and in this latter role she works closely with Alathrien Druanna to discover information about creatures before the Rune Mistress summons them.

Outside of the elven pantheon, the Magess has strong working relations with other deities of magic, working especially close with those who oppose powers who seek to do harm through deceptions and illusions. Kirith reserves most of her attention for the Queen of Air and Darkness, who poses a direct threat to the elven peoples and their lands, as well as their closest allies. She is ever watchful for the illusions the Queen works and directs her followers to be especially vigilant for secret cults within elven communities. Close behind the Witch-Queen is the evil Vixen Queen, Eshebala, whom the Magess believes misuses the power of charms and enchantments in her quest to dominate others. Prior to the Time of Troubles on the world of Toril, Kirith was a staunch foe of the Lady of the Mists, Leira. With that power’s passing, she has spread her attention elsewhere, but the rise of Cyric and Mask to fill the role Leira once served has begun to draw her focus back once again. Finally, while she doesn’t actively oppose Baravar Cloakshadow and the kenku god Quorlinn, she is deeply suspicious of both, and questions the alliances some of her fellow elven powers have made with them.

While Kirith takes an active interest in activities on the Prime Material Plane, she rarely sends her avatars except to work great magic or assist one of the other members of the Seldarine. She prefers to work through her priests and other agents, and she sends frequent omens to her followers. She is also quite responsive to entreaties and divinations from elves and allies, although that does not mean she conveys any and all information at her disposal.

**Kirith’s Avatar (Diviner 29, Enchanter 25, Cleric 16)**  
Kirith appears as an enchanting elven woman with long braided blonde hair and eyes of evershifting hue, from hazel to green to blue to violet and back again. She wears a shimmering, gossamer robe striped with all the shades of a rainbow. She draws her spells from all spheres and schools but favors those from the schools of divination and enchantment/charm, as well as those that create colorful magical effects.

AC −2; MV 15; HP 117; THAC0 10; #AT 1  
Dmg 1d4+4 (_dagger +4_)  
MR 70%; SZ M (5 feet tall)  
Str 14, Dex 20, Con 16, Int 23, Wis 21, Cha 23  
Spells P: 10/10/10/8/5/3/1, W: 9/9/9/9/9/8/8/8/8*  
Saves PPDM 4; RSW 3; PP 5; BW 7; Sp 4  
* Numbers assume one extra divination and enchantment/charm spell per spell level.

**Special Att/Def:** If forced to engage in melee, Kirith wields _Veilcutter_, a pearlescent _dagger +4_ that automatically dispels all non-divine illusions and obscuring mist magic with a single slash. This blade also eliminates any combat penalties due to spells or magical powers such as _invisibility_ or _mirror image_. However, the Magess prefers to avoid combat entirely if possible, using her magic to protect herself and others or dissuade foes from continuing their aggression.

Kirith can make a _suggestion_ to any creatures who look her in the eyes from less than 10 feet away, unless a saving throw versus spell with a −2 penalty is successful. This is automatic if a creature is surprised or attacking her directly from the front, unless it is explicitly stated they are not looking her in the eyes. Once per day Kirith can create a _prismatic sphere_ that moves with her; this power and all prismatic spells she casts never affect allied elves in any way. She automatically _detects magic_ within a 180-foot radius, and instantly knows the details, powers, and command words of all spells and magical items within that area, excepting those that are protected by lead lining or other magical and nonmagical protections against detecting and identifying magic. She is always under the effects of a priestly _true seeing_ spell.

The Magess is immune to magical weapons of less than +2 enchantment. She is unaffected by mind-controlling or affecting spells and psionics, prismatic spells (including _chromatic orb_ and _color spray_), and divination spells other than _true seeing_ never reveal her location or information about her unless she chooses to allow it.

**Other Manifestations**  
Kirith manifests as brilliant multicolored radiances, visible either to just one creature or all creatures, which may guide them towards a certain goal, or warn them off from a hidden danger. In addition, she can cause _prismatic spheres_ and _walls_ to manifest to protect a follower, either as the full spell or as a single layer. Finally, she has been known to grant followers a repeatable use of _color spray_ or _prismatic spray_, for up to one week.

The Seldarine call on agathinons, asuras, and ancient treants as their preferred servants, but Kirith primarily calls upon cats of all sorts, as well as aasimar, aasimon (especially lights), baelnorns, electrum dragons, radiance fundamentals, radiance mephits, radiance quasi-elementals, spellhaunts, and wizshades. She expresses her favor through the discovery of gems, stones, and flowers in all pure colors of the rainbow, but especially rubies, jacinths, topazes, emeralds, aquamarines, sapphires, amethysts, and rainbow tourmalines. The Magess shows her displeasure through bright, dazzling flashes of light from someplace where no light should come, that momentarily blinds a creature that has earned her ire.

**The Church**  
Clergy:                      Clerics, specialty priests, diviners, enchanters  
Clergy’s Align.:      LG, NG, CG, LN, N  
Turn Undead:           C: Yes, SP: No, Div: No, Enc: No  
Cmnd. Undead:         C: No, SP: No, Div: No, Enc: No

All clerics (including multiclassed half-elven cleric/mages) and specialty priests of Kirith receive religion (elf) and reading/writing (elvish) as bonus nonweapon proficiencies.

The church of Kirith Sotheril has maintained its current size with relative stability throughout recent eras. It remains somewhat obscure outside of magical circles, for her faith infrequently touches the lives of the common elf. The church is often associated with magical colleges in elven cities and works closely with officials dedicated to seeking the truth. Further, they are often crucial elements of large-scale magical creations within elven society. There exists a certain rivalry between the faithful of the Magess and those who follow Sehanine, as both lay claim to subtle magical schools that at times overlap and compete. This rivalry never becomes outright hostile, however. Finally, while virtually unknown outside of elven communities and nations, there still exists antagonism between the Kirithian church and those churches dedicated to prevarication and lies.

Temples dedicated to the Magess are rare, with those in existence typically serving as schools for wizardry. Such structures often differ little from their secular siblings, except they often are named in honor of a famous member of the clergy and have dazzling stained glass windows in the public sections of the building. Atop the highest point is always places a glass sphere of swirled rainbow hues. The altar chamber is designed to be large and circular, centered on a completely still mirror-like pool of water. The roof of the chamber is decorated with exquisite stained-glass panels that catch the noon sun’s light, creating a dazzling array of rainbow hues throughout the chamber. The altar itself rests a short distance from the pool opposite the entrance to the chamber; the construction varies with local materials but is always pearlescent or colorful. On top rests a small brazier for burning incense or offerings. Far more common in elven communities are shrines, found within unaffiliated magical schools and temples of Corellon Larethian. These shrines hold a small brazier and a mirror or a still pool of water, while above them rests a rainbow-swirled glass sphere that often holds a pale magical light inside.

Novices of the Magess are known as the Obscured, while full priests are True Seers. In ascending order of rank, titles used by the Kirithian priesthood are Red Lumen, Orange Lumen, Yellow Lumen, Green Lumen, Cyan Lumen, Blue Lumen, Violet Lumen, White Lumen, and Prismatic Lumen. High-ranking priests have unique individual titles. Specialty priests are known as zivorns. The clergy consists of high elves (50%), grey elves (34%), half-elves of various ancestries (12%), sylvan elves (3%), and other elven races (1%). The priesthood of the Magess is slowly becoming dominated by specialty priests (42%) while the number of clerics (including multiclassed half-elven cleric/mages; 38%) is slowly dwindling; the remainder includes a steady split of diviners (10%) and enchanters (10%). Kirith’s church includes slightly more females (56%) than males (44%).

**Dogma:** The gift of magic is a powerful tool to reveal truth. It can cut through the mists of deception and obfuscation to show reality. Imbue objects with enchantments to protect the lands of the elves and use charms to turn antagonistic forces into supportive forces.

**Day-to-Day Activities:** Followers of the Magess often function as educators and trainers for those who wish to learn magic. When not acting in such capacities, they often perform divinations for those who desire to learn the truth of some event, or they enchant places or things to aid their community.  Finally, a small number work within elven military forces to create magical weapons and armor or determine the success of battle plans.

**Important Ceremonies/Holy Days:** Like the priesthood of Sehanine, the Kirithian clergy holds the day of the full moon sacred. Unlike the Sehanite church, however, followers of the Magess hold their libations under the noon-day sun in a ceremony known as the Enchanting Light of Truth. During such ceremonies, members of the clergy set up prisms and kaleidoscopes to catch the sun’s light, and then offer prayers and burn written offerings that include truths. It is said that offering up something as true that a follower knows is false, or could easily disprove, is a major transgression against the faith. For this reason, members of the clergy are encouraged to use these events as a sort of confessional; while they do not absolve wrongdoing, the clergy hold that Kirith looks fondly upon those who confess even minor acts of wrongdoing and then set out to right them. In addition, this act of confessing is carried over to elves in love, with some followers using the ceremonies as an opportunity to declare their feelings for another. Finally, it is also said that Kirith smiles upon sacrifices of newly discovered truthful information and truthful opinions; as such, researchers often sacrifice copies of their discoveries and other followers sacrifice literary and poetic descriptions of their opinions of the world around them.

While no other wide-spread holy days are recognized by the church, local clergy often sanctify a handful of days based on relevant events within a community. Such events typically include major omens from the Magess and the finalization of great magical enchantments, especially mythals. Such events rarely hold significance to Kirithian clergy outside a particular nation or city and surrounding region.

**Major Centers of Worship:** Ancient elven cities with mythals almost always had at least a small temple dedicated to Kirith Sotheril; the most famous of these, the Hall of Prism’s Light, now lies ruined within the city of Myth Drannor on the world of Toril. It is believed by the clergy throughout the rest of the region that it contained a storehouse of divination magic and items created to aid the city, and they hold this vault has never been breached.

While small colleges and shrines dot the cities on the island of Evermeet, the largest extant temple on Toril is the College of Enchanting Truth, a magical school with dozens of students in the city of Evereska. The colorful campus is overseen by Scintillatrix Mearatha (NG ef P11), who enjoys dazzling her students and faculty alike with prismatic displays.

Finally, small valleys and glens are considered sacred to Kirith. Many such locations within elven lands have small, hidden shrines dedicated to the Magess, and once per year clergy are expected to visit the nearest location on the day of the new moon to perform the Enchanting Light of Truth ceremony. Whether the entire clergy performs this act as a group, or members choose the date individually varies by local tradition.

**Affiliated Orders:** The Seekers of Truth is an organization loosely affiliated with the church of the Magess. It contains mostly fighters and mages, but a significant minority are priests or diviners in the service of Kirith. This organization seeks to reveal the truth behind criminal incidents, and often hunts them down as well. Further, it takes a special interest in finding lost objects or persons.

**Priestly Vestments:** The Kirithian clergy wear hooded and fringed multicolored striped robes in muted or pastel shades of the spectrum. The fringe of these robes are always in a bright, primary shade of their rank color, and a stole is added to this robe striped in the normal shades of the rainbow and terminating in the priest’s rank color. The holy symbol used by the clergy is a small glass sphere swirled with every color of the rainbow, and held in a silver setting like a cat’s paw on a pendant.

**Adventuring Garb:** Followers of the Magess prefer light or no armor and sturdy traveler’s robes when not conducting ceremonies. They equip themselves with fairly simple weapons such as staves daggers, maces, and the like, and priests are often mistaken for wizards. Only clerics who serve in the elven military ever utilize heavier armors, and these are rarely bulkier than mail.

**Specialty Priests (Zivorns)**  
Requirements:          Intelligence 12, Wisdom 13  
Prime Req.:                Intelligence, Wisdom  
Alignment:                NG  
Weapons:                   Club, dagger, dart, knife, mace, quarterstaff, short sword, sling  
Armor:                       None  
Major Spheres:         All, charm, creation, divination, elemental, guardian, healing, numbers, protection, thought  
Minor Spheres:         Necromantic, sun  
Magical Items:         Same as clerics and wizards  
Req. Profs:                Spellcraft  
Bonus Profs:             Artistic ability or dancing or singing

-   While most zivorns are high or grey elves, elves and half-elves of every subrace are called to be specialty priests of Kirith’s clergy.
-   Zivorns are not allowed to multiclass.
-   Zivorns can select nonweapon proficiencies from the wizard group without penalty.
-   Zivorns receive a +2 on saving throws vs. divination or enchantment/charm magic of any sort.
-   Zivorns may cast wizard spells from either the divination school or the enchantment/charm school as defined in the Limited Wizard Spellcasting section of “Appendix 1: Demihuman Priests” in _Demihuman Deities_. At 1st level, each zivorn must choose one or the other, and the choice of study is irrevocable thereafter.
-   Zivorns can cast _armor_ or _shield_ (as the 1st-level wizard spells) once per day.
-   At 3rd level, zivorns can cast _detect charm_ (as the 2nd-level priest spell) once per day. They can cast it an additional time for very three additional levels achieved (twice at 6th, three times at 9th, etc.).
-   At 5th level, zivorns can cast _call upon faith_ (as the 1st-level priest spell) or _detect illusion_ (as the 3rd-level priest spell) once per day.
-   At 7th level, zivorns can cast _divination enhancement_ or _magic mirror_ (as the 4th-level wizard spells) once per day.
-   At 10th level, zivorns can cast _true seeing_ or _undead ward_ (as the 5th-level priest spells) once per day.
-   At 12th level, zivorns can cast _legend lore_ (as the 6th-level wizard spell) or _steal enchantment_ (as the 7th-level wizard spell) once per day.
-   At 14th level, zivorns can cast _prismatic spray_ (as the 7th-level wizard spell) or _prismatic sphere_ (as the 9th-level wizard spell) once per week.

**Kirithian Spells**  
**3rd Level**  
**Charm Diviner** (Pr 3; Enchantment/Charm)  
Sphere:                    Charm  
Range:                     0  
Components:           V, S, M  
Duration:                 1 hr./level  
Casting Time:          2 rds.  
Area of Effect:         The caster  
Saving Throw:        Special

With this spell, a priest can set up a _contingency_-like effect that offers some protection from scrying and similar types of divination. For the duration of the _charm diviner_ spell, any attempt by a non-allied individual to remotely view the priest, directly or indirectly, causes the viewer to make a saving throw versus spells at a −2 penalty or be _charmed_ as if by a charm person spell. The caster of the charm diviner spell is aware of the scrying attempt, but not of the success or failure of the charm. Further, a creature charmed by this spell will feel guilty for scrying on the priest, and abort further attempts and not reveal what they learned to other individuals. If they are in close proximity to the priest, the scryer will attempt to make amends for invasion of privacy, often offering some service to their new friend.

The casting priest can choose to increase the power of the charm diviner spell by subsequently casting another charm-related spell in the round immediately following. Spells such as charm person or mammal and mental domination, as well as the wizard spells charm monster and domination if those are available to the priest, can be cast to replace the basic charm person effect. Charm undead can never be used with this spell, however. The individual scrying a priest can be charmed regardless of the method, including spells, magic items, and psionics.

The material component for this spell is a polished silver hand mirror worth at least 200 gp.

**Identify Charmer** (Pr 3; Divination)  
Sphere:                    Divination  
Range:                     30 yds.  
Components:           V, S, M  
Duration:                 Special  
Casting Time:          6  
Area of Effect:         1 charm effect  
Saving Throw:        None

With this spell, the priest can learn the identity of an individual who cast a _charm_ spell (_charm person_, _charm monster_, _domination_, etc.). For every six levels the priest has attained, they can learn an additional piece of information about the caster of a particular charm spell or effect. They may learn the name, gain a mental picture of the caster, rank or title, precise direction and general distance to the caster, or nearest major landmark (castle, town, mountain, etc.) to the caster. For example, if the companion of an 11th-level priest has been _charmed_, the priest could cast _identify charmer_ and learn that the one who cast the charm is named Veltooth the Grey, and the landmark they are closest to is the village of Sarath Hill.

Multiple castings of this spell on the same charm effect will always return the same results, even if a different priest were to cast _identify charmer_. This spell can be used on expired or broken charms, so long as the charm has been broken for no more than one day per level of the caster.

The material component is a pinch of talcum powder.

**5th Level**  
**Twist Charm** (Pr 5; Alteration, Enchantment/Charm)  
Sphere:                    Charm  
Range:                     30 yds.  
Components:           V, S, M  
Duration:                 Special  
Casting Time:          8  
Area of Effect:         1 charmed creature  
Saving Throw:        Special

By means of this spell, the caster can twist an existing _charm_ spell (_charm person_, _charm monster_, _dominate_, etc.) to return on the original caster. In effect, the caster of the charm becomes themselves charmed by their intended victim. This spell is initially cast on a charmed creature, and it first grants a new saving throw against the original _charm_ spell with a +2 bonus, and any additional bonuses they have, including their Wisdom adjustment. If the save is successful, the initial _charm_ is broken, regardless of the further outcome of the _twist charm_ spell.

If that saving throw is successful, the caster of the twisted charm must make a saving throw versus spell with a −2 penalty. If this saving throw is failed, the caster is charmed by their original victim; the charm is either a _charm person_ or _charm monster_, as applicable. Magic resistance applies before this save, including elven and half-elven resistance to charming. The caster of the original charm is unaware of any change until they attempt to exert influence over their victim, at which point the twisted charming becomes apparent. In the case of a _domination_ or similar spell, the caster is unaware that the _domination_ is broken until they attempt to exert telepathic control; in this case their victim is allowed to issue one single telepathic order before the twisted _domination_ becomes a simple _charm_ spell. This spell has no effect on psionic influence or control.

The material component for this spell is pair of wires, one gold and one silver, braided about each other and twisted into a loop, soaked in a special solution of herbs and dissolved minerals for one week. Altogether, this process costs 100 gp.

**Kirith Sotheril ([PDF Version](https://blog.aulddragon.com/wp-content/uploads/2022/03/KirithSotheril.zip))**  
**(The Magess, the Scintillating Lady, the Prismatic Sorceress, the Piercer of Veils, the Enchanting Lady)**  

*The next member of the younger generation of elven deities originally published in Dragon Magazine #155 (and updated in #236), Kirith Sotheril specializes in the subtle magics of divination and enchantment magic, and represents the piercing of illusions and lies to reveal the truth. She is seen as a bright, enchanting lady who favors scintillating colors and magical lights as well.**
