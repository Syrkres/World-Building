---
fileType: Cosmos
cosmosName: Kamerel
cosmosType: Extraplanar
---
# Kamerel
_It was easy, actually. We were unhappy here, in the objective world, which teemed with those who would pry, poke, and prod into our existence. Unacceptable. In Reflection, we kamerel could remain hidden. It was the place everyone looked, therefore the place no one would look. In Reflection, they saw themselves—never looking for us. Since they believed reflection held nothing unique, they never pried within. The irony, of course, lies in the fact that reflection cannot exist without someone looking at it—at least, that's what we who dwell within that reflection have led you to believe._ 
 
 ~Tales from the Infinite Staircase  

Medium Outsider (Exemplar, Extraplanar)  
**Divine Rank:** 0  
**Hit Dice:** 40d8 + 400 (720 hp)  
**Initiative:** +14 (Dex)  
**Speed:** 80 ft. (16 squares)  
**Armor Class:** 64 (+14 Dex, +20 insight, +20 natural), touch 44, flat-footed 50  
**Base Attack/Grapple:** +40/+47  
**Attack:** Shard short sword +64 melee (1d6+15/crit 15-20 and _wounding_)  
**Full Attack:** Shard short sword +64/+59/+54/+49 melee (1d6 + 15/crit 15-20 and _wounding_), or shard short sword +62/+57/+52/+47 melee (1d6 + 15/crit 15-20 and _wounding_) and shard short sword +62/+57/+52/+47 melee (1d6+12/crit 15-20 and _wounding_)  
**Space/Reach:** 5 ft./5 ft.  
**Special Abilities:** Mirror jump, mirror sight, shard spray, spell-like abilities, wizard spells  
**Special Qualities:** Blindsight 500 ft., DR 15/epic, electricity immunity, exemplar traits, exile, fast healing 20, mirrored skin, reflectionless, shard weapon specialty, SR 42  
**Saves:** Fort +32, Ref +36, Will +33  
**Abilities:** Str 24, Dex 39, Con 30, Int 38, Wis 32, Cha 28  
**Skills:** Balance +57, Climb +50, Concentration +53, Craft (alchemy) +57, Craft (glassblowing) +57, Craft (mirrors) +57, Craft (bookbinding) +57, Heal +54, Hide +57, Knowledge (arcana) +57, Knowledge (history) +57, Knowledge (local [Mirror]) +57, Knowledge (nature) +57, Knowledge (the planes) +57, Knowledge (religion) +57, Listen +54, Move Silently +57, Search +57, Sense Motive +54, Spellcraft +57, Spot +54, Survival +54, Tumble +57, Use Magic Device +52  
**Feats:** Chain Spell, Craft Wondrous Item, Exotic Weapon Proficiency (shard), Fortify Spell, Improved Critical (shard), Improved Two-Weapon Defense, Language Primeval, Quicken Spell, Transdimensional Spell, Twin Spell, Two-Weapon Defense, Weapon Finesse, Weapon Focus (shard)  
**Epic Feats:** Epic Weapon Focus (shard), Multispell, Two-Weapon Rend  
**Environment:** The Plane of Mirrors, or the Divided Unity of Concordant Opposition  
**Organization:** Solitary or band (1d4 + 2)  
**Challenge Rating:** 30  
**Treasure:** No coins, double goods, standard items  
**Alignment:** Special (see Unaligned, below)  
**Advancement:** 41-80 HD (Medium)  

_Before you stands what appears to be a living mirror. Humanoid in shape and roughly 5 1/2 feet tall, it looks at you with all-too-human eyes out of an otherwise featureless face. Its long white hair is pulled back, and loose grey robes hang from its shoulders. Motionless, it seems to be studying you and your companions. Then, as you take another step towards it, jagged silvery swords fall out of its sleeves into its hands, and it assumes a defensive posture._  

(Flavor text to come.)  

For the purpose of resolving kamerel special abilities, a mirror can be any reflective surface. Actual mirrors or other perfectly reflective surfaces cause the abilities to function normally. A kamerel can also use other sorts of highly reflective surfaces as well, such as a polished steel shield, a still pool of water, or shiny metal. There is a 30% chance that the surface is reflective enough for the kamerel’s ability to function. If this roll fails, the kamerel cannot attempt to use the same surface again for 24 hours.  

A kamerel’s natural weapons are treated as epic for the purpose of overcoming damage reduction.  

**Exemplar Traits:** Immune to polymorphing, petrification, and other form-altering attacks; immune to electricity; not subject to energy drain, ability damage, ability drain, or death from massive damage; immune to mind-affecting effects; cold resistance 20, fire resistance 20; _nondetection_; _true seeing_ at will; blindsight 500 ft.; telepathy out to 1,000 ft. Kamerel gain Language Primeval as a bonus feat.  

**Exile:** The form that kamerel currently possess is symptomatic of their exile. During the ages when the rilmani are in hiding and the kamerel rule the Concordant Opposition, they typically possess grayish-white skin and pale green or blue hair. Though their racial interest in the Plane of Mirrors does not change, many kamerel possess unique special abilities that are unrelated to it. Instead of the mirror jump, mirror sight, and shard spray abilities, a kamerel may gain a unique special ability, and instead of the mirrored skin quality, she may gain a unique special quality. Both of these should be roughly on par with salient divine abilities available to demigods.  

**Mirror Jump (Sp):** Kamerel can move through mirrored and reflective surfaces at will. This effect is similar to _shadow walk_, but a kamerel travels along the Plane of Mirrors. As a standard action, the kamerel must touch a mirror or highly reflective surface. The kamerel then exits from another mirror on the same plane (her choice).  

If the kamerel wishes to travel to a different plane, or if she does not wish to exit at all, she remains on the Plane of Mirrors until she finds a suitable exit. This is the equivalent of a 1st-level Conjuration (transportation) spell.  

**Mirror Sight (Sp):** Kamerel can use mirrors for a special type of _scrying_. Looking into a mirror, a kamerel can see through it to view a reflection in another mirror. She can choose to see one of three types of reflection:  
o The reflection of another mirror she is familiar with.  
o The reflection of a person she knows (assuming the person is near a mirror).  
o The reflection of a place she knows well (assuming the place is reflected in a mirror).  
The kamerel only receives visual information through this ability. However, she can choose to transmit information both ways—so that a person reflected in the remote mirror can view whatever appears the mirror the kamerel is using. Contact lasts 29 rounds. This is the equivalent of a 1st-level divination spell.  

**Mirrored Skin (Ex):** A kamerel skin resembles a suit of mirrors, and confers a few unique protections. It deflects all rays, lines, cones, and even _magic missile_ spells. There is a 30% chance of reflecting any such effect back at the caster; otherwise, it is merely negated. Check for reflection before rolling to overcome the kamerel’s spell resistance.  

In addition, any spell that fails to penetrate the kamerel’s spell resistance bounces back at the caster. The caster becomes either the spell’s target or the point of origin for the spell, as appropriate. Finally, kamerel are immune to gaze attacks, and such are reflected back to their origins.  

However, there is one significant drawback to this defense: kamerel are extremely vulnerable to sonic-based attacks. A kamerel takes half again as much (+50%) damage as normal from sonic attacks, regardless of whether a saving throw is allowed, or if the save is a success or a failure.  

**Reflectionless (Ex):** Kamerel do not have reflections in mirrors (though their clothing and any equipment they are carrying besides their shard weapons might). They never create a duplicate upon entering the Plane of Mirrors.  

**Shard Spray (Su):** As a standard action, a kamerel can release a spray of mirror-like shards from her hands that can flay flesh and cause massive lacerations. The spray is a 30-foot cone and it deals 20d8 points of damage.  

In addition, a wound resulting from a kamerel’s shard spray attack bleeds for an additional 8 points of damage per round thereafter. Multiple wounds from such attacks result in cumulative bleeding loss (two wounds for 16 points of damage, and so on). The bleeding can be stopped only by a successful Heal check (DC 20) or the application of any Conjuration (healing) spell of at least 5th level.  

**Shard Weapon Specialty:** All kamerel receive a bonus Exotic Weapon Proficiency feat with at least one shard weapon. In addition, when wielding shard weapons they are considered to possess the Perfect Two-Weapon Fighting feat.  

**Unaligned (Ex):** Kamerel are representatives of neutrality in all things, and as such, do not possess an alignment. A kamerel is thus immune to all effects based upon alignment, such as a _holy word_ spell or the penalties imposed by strongly-aligned planes. The only exceptions to this are effects that specifically target true neutral creatures (effects that target neutral creatures in general are not sufficient). A kamerel qualifies for classes and feats as if they were of neutral alignment. Should her alignment shift away from true neutral, a kamerel loses the benefits of this ability.  

**Wizard Spells Per Day:** 8/8/8/7/7/7/7/6/6/6\. 30th caster level. Base DC = 24 + spell level. Kamerel have developed a unique technique whereby they can prepare multiple low-level spells in higher-level slots. The total level of the spells so prepared cannot exceed the level of the spell slot minus 1.  

**Typical Wizard Spells Prepared:** (Forthcoming).  

<div class="quotetop">QUOTE</div>

<div class="quotemain">**SHARD WEAPONS**  
Kamerel employ swords and daggers that are made out of the substance of the Plane of Mirrors. They resemble shards of a broken mirror that have been set into shiny hilts. Despite their fragile appearance, shard weapons are incredibly tough, deadly, and razor-sharp. Shard weapons leave terrible wounds that bleed incessantly.  

Shard weapons are typically _+8 keen wounding weapons_, and penetrate damage reduction as both cold iron and silver. In the hands of someone without the appropriate Exotic Weapon Proficiency, the weapon is awkward (–4 penalty on wielder’s attack rolls) and contributes only its enhancement bonus, not the keen or wounding abilities, on any attacks made with it.</div>

* * *

A great creation of [DiceFreaks](http://community.dicefreaks.com/) and copied here for reference.
