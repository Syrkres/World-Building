# Cosmology - Beings of Greater Power

[[Cosmology Overview]]

```dataview
table without id file.link as "Name", planeType as "Type", planeAlignment as "Alignment"
where fileType="plane"
sort planeType
```

## Dieties
```dataview
table without id file.link as "Name", cosmosType as "Type"
where fileType="Cosmos"
and contains(cosmosType, "Deity") = true
sort file.link
```

## Demons
```dataview
table without id file.link as "Name", cosmosType as "Type"
where fileType="Cosmos"
and contains(cosmosType, "Demon") = true
sort file.link
```