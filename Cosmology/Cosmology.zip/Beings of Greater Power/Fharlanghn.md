---
fileType: Cosmos
cosmosName: Fharlanghn
cosmosType: Intermediate Deity
---
# Fharlanghn, The Traveler, The patron of travelers
*The Dweller on the Horizon*
**Intermediate Deity** 
**Symbol:**  a disk with a curved line representing the horizon, and an upturned crescent above that.
**Home Plane:** Oerth (Material _Plane_)
**Portfolio:** Roads, travel, distance.
**Worshipers:** Bards, other wandering adventurers and merchants favor Fharlanghn
**Cleric Alignments:**  N
**Domains:** Celerity, Luck, Protection, Travel, Weather.
**Favoured Weapon:**  Quarterstaff

## Cleric Training
"The road is the best teacher," say the worshipers of Fharlanghn. A higher-level cleric takes a half-dozen or so recruits on a long journey, where they'll help fellow travelers, see the wider world, and take part in any number of misadventures. The only way to flunk out of Fharlanghn's training is to ask when the journey will be over—those faithful to Fharlanghn know that the journey never ends.

### Quests
Any quest involving long journeys can involve Fharlanghn as well. His followers often guard caravans, explore mysterious islands, and maintain a series of portals between worlds.

### Prayers
Fharlanghn teaches through short anecdotes, many of which feature a wise old man traveling with a foolish young man. There are more than a hundred stories that involve the two of them crossing a river, for example.

## Temples
Fharlanghn doesn't have many large temples, but wayside shrines to him are common. At major crossroads and port cities, shrines to Fharlanghn provide fast horses and sturdy sailing ships.

### Rites
Because his followers are often on the move, Fharlanghn's rites are often short and to the point. Many Fharlanghn worshipers rely the ceremonies of allied deities for such things as marriages and funerals.

### Herald and Allies
Fharlanghn uses 17 HD ghaele eladrins as his heralds. Allies are Medium elementals (any), Large elementals (any), and elder arrowhawks.

**Relics:** Boots of the unending journey, rapier of unerring direction.


