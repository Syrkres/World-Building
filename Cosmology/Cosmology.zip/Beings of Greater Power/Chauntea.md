---
fileType: Cosmos
cosmosName: Chauntea
cosmosType: Greater Deity
---
**Chauntea**  
_The Great Mother, the Grain Goddess, Earthmother_  
**Greater Deity**  
**Symbol:** Blooming rose on a sunburst wreath of golden grain  
**Home Plane:** House of Nature (Elysium)  
**Alignment:** Neutral good  
**Portfolio:** Agriculture, plants cultivated by humans, farmers, gardeners, summer  
**Worshipers:** Peasants and indentured servants, druids, farmers, gardeners  
**Cleric Alignment:** CG, LG, NG  
**Domains:** Animal, Earth, Good, Plant, Protection, Renewal  
**Favored Weapon:** "A shock of grain" (scythe)  
  
**Chauntea**  
**Druid 44/Sentinel of Nature 10/Ranger 15**  
**Medium Outsider (Good)**  
**Divine Rank:** 19  
**Hit Dice:** 59d8+10d4+1,035 (1,547 hp)  
**Initiative:** +7 (+7 Dex)  
**Speed:** 60 ft. (12 squares)  
**Armor Class:** 84 (+7 Dex, +19 divine, +34 natural, +15 deflection), touch 51, flat-footed 78  
**Base Attack/Grapple:** +40/+66  
**Attack:** _Shock of grain_ +76 (1d8+17 plus 3d6 holy and 1 negative level/19-20)  
**Full Attack:** _Shock of grain_ +76/+71/+66 (1d8+17 plus 3d6 holy and 1 negative level/19-20)  
**Space/Reach:** 5 ft./5 ft.  
**Special Attacks:** Domain powers, salient divine abilities, spell-like abilities, spells  
**Special Qualities:** A thousand faces, camouflage, cavalry of dire beasts, divine aura (19 miles, DC 45), divine immunities, DR 30/epic and cold iron, godly realm (100 miles Outer Plane, 1,900 ft. Material Plane), _greater teleport_ at will, _plane shift_ at will, remote communication, nature sense, nature's veil, nature-friendly spells, resistance to to electricity 24, resistance to acid and sonic 10, resist nature's lure, quickened _call lighting_ 1/day, quickened _lighting storm_ 1/day, SR 85, trackless step, understand, speak and read all languages and speak directly to all beings within 17 miles, ursinal's touch, swift tracker, wild empathy +74, wild shape, woodland stride  
**Saves:** Fort +70, Ref +56, Will +77  
**Abilities:** Str 24, Dex 24, Con 40, Int 24, Wis 55, Cha 40  
**Skills:** Concentration +106, Decipher Script +54, Diplomacy +94, Handle Animal +94, Heal +113, Hide +46, Knowledge (arcana) +61, Knowledge (geography) +69, Knowledge (nature) +98, Knowledge (religion) +78, Listen +88, Move Silently +46, Profession (farmer) +90, Ride +52, Search +56, Spellcraft +102, Spot +103, Survival +103  
**Feats:** Consecrate Spell, Endurance(b), Heighten Spell, Improved Precise Shot(b), Multishot(b), Point Blank Shot(b), Reach Spell, Sacred Vow, Twin spell, Track(b), Vow of Obedience, Words of Creation  
**Epic Feats:** Automatic Quicken Spell (x3), Automatic Silent Spell(x3), Automatic Still Spell (x3), Chain Spell, Epic Spellcasting(b), Improved Elemental Wild Shape(b), Improved Metamagic (x2)(b), Magical Beast Wild Shape (b), Multispell (x3), Plant Wild Shape (b), Purify Spell, Quicken Spell, Silent Spell, Still Spell  
**Salient Divine Abilities:** Alter Form, Area Divine Shield, Call Creatures (elementals), Call Creatures (fey), Control Creatures (elementals), Control Creatures (fey), Divine Blast, Divine Druid, Divine Earth Mastery, Divine Shield, Divine Spellcasting, Extra Domain (Protection), Extra Domain (Renewal), Overlord (elementals), Overlord (fey), Gift of Life, Life and Death, Mass Life and Death, Mind of the Beast, Possess Mortal, Power of Nature, Shapechange, The Earthmother, True Shapechange  
**Environment:** House of Nature  
**Organization:** Solitary (unique)  
**Challenge Rating:** 61  
**Treasure:** None  
**Alignment:** Neutral good  
**Advancement:** --  
**Level Adjustment:** --  
  
  
- **Alter Reality:** Chauntea can use the _wish_ spell with regard to her portfolio, save for the replication of other spells. This ability costs Chauntea no XP, and requires a standard action to implement.  
- **Cavalry of Dire Beasts (Sp):** Chauntea can call up to 1d6 dire beasts (of her choosing) with maximum hit points to aid her in battle. The dire beasts appear instantly and remain until the battle has ended, at which point they disperse into the wild.  
- **Divine Immunities:** Ability damage, ability drain, cold, death effects, disease, disintegration, electricity, energy drain, fire, mind-affecting effects, paralysis, poison, sleep, stunning, transmutation, imprisonment, banishment.  
- **Domain Powers:** Cast good spells at +1 caster level; generate a protective ward 1/day; if reduced to 0 hp, heals 1d8+15 1/day; _speak with animals_ 1/day; turn or destroy air creatures or rebuke earth creatures 18/day; rebuke or command plant creatures 18/day.  
- **Nature's Veil (Su):** As a free action, Chauntea can attempt to hide outdoors. She must be within 10 feet of natural surroundings. She gains a +10 insight bonus on her Hide checks.  
- **Nature-Friendly Spells (Su):** Any energy based spells Chauntea casts deal nonlethal damage against animals and plants if she so desires.  
- **Quickened _Call Lightning_ (Sp):** Once per day, Chauntea can cast a quickened _call lighting_ spell (CL 69th).  
- **Quickened _Lighting Storm_ (Sp):** Chauntea can cast a quickened _lightning storm_ once per day (CL 69th).  
- **Spell-Like Abilities:** Chauntea uses these abilities as a 88th-level caster, except for good spells, which she uses as a 89th-level caster. The save DCs are 54 + spell level - _aid, animal shapes, animate plants, antilife shell, antimagic field, atonement, barkskin, blade barrier, calm animal, charm person, command plants, commune with nature, control plants, dispel evil, dominate animal, earthquake, elemental swarm, entangle, freedom, greater restoration, heroes feast, hold animal, holyu aura, holy smite, holy word, iron body, lesser restoration, magic circle against evil, magic stone, plant growth, polymorph any object, prismatic sphere, protection from energy, protection from evil, reincarnate, remove disease, repel wood, repulsion, sanctuary, shapechange, shield other, soften earth and stone, spell immunity, spell resistance, spike stones, stone shape, stoneskin, summon monster IX, summon nature's ally IV, summon nature's ally VIII, wall of stone, wall of thorns_.  
- **Spells:** As a 54th-level druid and a 7th-level ranger.  
- **Druid Spells/Day (Levels 0-22):** 6/11/11/10/10/10/9/8/8/8/5/4/4/4/4/3/3/3/3/2/2/2/2; base DC = 30 + spell level.  
- **Ranger Spells/Day (Levels 1-22):** 9/9/8/6/6/5/5/5/5/5/5/4/4/4/4/3/3/3/3/2/2/2/2; base DC = 30 + spell level.  
- **The Earthmother (unique salient divine ability):** Chauntea is the mother of the earth and indeed the world of Toril itself. With her touch she can banish disease and barrenness, as well as bestow instant life and fertility (as per _remove disease_ and _true resurrection_ as an 89th-level caster). She cannot be harmed by any plant or fungus or attack by earth or water. (She also extends her protection from any plant to Lathander). With her touch she can transform foes who attack her into shambling mounds or treants unless they make a Fort save (DC 85).  
- **Ursinal's Touch (Su):** With her touch Chauntea can heal up to 1,547 hit points of damage each day. This functions identical to a paladin's lay on hands ability.  
- **Possessions:** Chauntea carries a _+10 defending keen holy burst shock of grain_. By waving the grain over the earth or a pool of water, she can summon nineteen primal earth or water elementals with maximum hit points once per day. (_Caster Level:_ 40th; _Weight:_ 5 lb).  
  
**Other Divine Powers**  
- As a greater deity, Chauntea automatically receives the best possible result on any die roll she makes (including attack rolls, damage, checks, and saves). She is immortal.  
- **Senses:** Chauntea can see (using normal vision or low-light vision), hear, touch, and smell at a distance of nineteen miles. As a standard action, she can perceive anything within nineteen miles of her worshipers, holy sites, objects, or any location where one of her titles or name was spoken in the last hour. She can extend her senses to up to twenty locations at once. She can block the sensing power of deities of her rank or lower at up to two remote locations at once for 19 hours.  
- **Portfolio Sense:** Chauntea senses anything that affects agriculture nineteen tendays before it happens and retains the sensation for nineteen tendays after the event occurs. Any plant in a tilled field can be the focus for Chauntea's remote sense and remote communication.  
- **Automatic Actions:** Chauntea can use Knowledge (arcana), Knowledge (geography), Knowledge (nature) or Knowledge (religiion) as a free action if the DC for the task is 30 or lower. He can perform up to 20 such free actions each round.  
- **Create Magic Items:** Chauntea can create any magic item that summons or controls elementals, animals or plants, or that affects earth, such as a staff of earth and stone