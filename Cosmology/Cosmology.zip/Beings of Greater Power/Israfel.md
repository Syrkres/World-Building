---
fileType: Cosmos
cosmosName: Israfel
cosmosType: Demon Atrocity
---
# Israfel, the Silent (CR 34)
Demon Atrocity  
CE (NE tendencies) Large Outsider (Chaotic, Evil, Extraplanar, Fallen)  
**Init** +15; **Senses** Listen +51, Spot +51, darkvision 60 ft. low-light vision  
**Aura** chaotic evil, aura of silence (Mastery of Silence); **Languages** None (Speaks only by telepathy)  
_____________________________________________________________  

**AC** 39, touch 20, flat-footed 32 (-1 Size, +7 Dex, +19 natural, +4 Profane)  
**hp** 584 (42d8+336-48), regeneration (10/good ); **DR** 20/cold iron, epic and good  
**Immune** electricity, poison, mind-affecting effects  
**Resist** acid 25, cold 25, fire 25; **SR** 36 (CR +12)  
**Fort** +31, **Ref** +30, **Will** +29  
_____________________________________________________________  

**Speed** 90ft. (18 squares)  
**Melee** _Angel’s Doom_ +62/+57/+52/+47 (3d6+26 +3d6 (unholy) plus 1 negative level (unholy)/17-20 +1d6 +6d6 (unholy) plus 2 negative levels (unholy) plus death (Fort save DC 44))  
**Melee** +54 touch  
**Ranged** Unholy energy +48 (10d10 unholy damage)  
**Ranged** +48 touch  
**Space** 10ft.; **Reach** 10ft.  
**Base Atk** +42; **Grp** +59  
**Atk Options** Cleave, Great Cleave, Improved Combat Expertise, Power Attack, Robilar’s Gambit, Slashing Flurry  
**Special Actions** Gaze of Dread, Mastery of Silence aura, smite good 7/day, veangeance  
_____________________________________________________________  

**Sorcerer Spells Known** (CL 38th)  
9th (7/day)— _Black Blade of Disaster*, Dominate Monster, Mass Hold Monster_  
8th (8/day)— _Blackfire*, Horrid wilting, Superior Invisibility_*  
7th (8/day)— _Evil glare*, Plane Shift, Final Rebuke_*  
6th (8/day)— _Aura of Terror*, Disintegrate, True Seeing_  
5th (8/day)— _Cloudkill, Mind Fog, Telekinesis, Wrack_*  
4th (9/day)— _Black Tentacles, Dimensional anchor, Phantasmal killer, Wall of fire_  
3rd (9/day)— _Displacement, Fireball, Fly, Haste_  
2nd (9/day)— _Bear’s Endurance, Bull’s Strength, Darkness, Locate Object, Wraithstrike_*  
1st (9/day)— _Comprehend languages, Identify, Mage Armor, Shield, True Strike_  
0th (6/day)— _Acid Splash, Arcane Mark, Dancing lights, Detect magic, Flare, Ghost sound, Mage Hand, Resistance, Touch of fatigue_  

**Spell-like Abilities** (CL 42th)  
**Always active (reactivate as a free action) –** _detect good_  
**At Will –** _blade barrier_ (DC 28), _bestow curse_(DC 26), _contagion_ (DC 26), _continual flame_(DC 24), _death knell_ (DC 24), _dispel magic_, _fear_ (DC 26), _flame strike_ (DC 27), _greater invisibility_ (self only), _greater teleport_ (self plus 50 pounds only), _slay living_ (DC 27), _speak with dead_ (DC 25), _unholy blight_ (DC 26), _waves of fatigue_ (DC 27)  
**3/day –** _destruction_ (DC 29), _earthquake_, _mass charm monster_ (DC 30), _shapechange_, _waves of exhaustion_ (DC 29)  
*Spells from Spell Compendium  
_____________________________________________________________  

**Abilities** Str 36, Dex 24, Con 27, Int 25, Wis 22, Cha 35  
**SQ** Cursed, favored enemies, +4 bonus against petrification, Mastery of Silence  
**Feats** Cleave, Combat Expertise, Combat Reflexes, Great Cleave, Heighten Spell, Improved Combat Expertise, Improved Critical (greatsword), Improved Initiative, Melee Weapon Mastery (slashing)*, Power Attack, Robilar’s Gambit*, Slashing Flurry*, Spell Penetration, Weapon Focus (greatsword), Weapon Specialization (greatsword), Violate Spell  
*Feats from Player’s Handbook 2 (for Improved Combat Expertise, Complete Warrior)  
**Epic Feats** Devastating Critical, Great Smiting, Overwhelming Critical, Superior Initiative  
**Skills** Balance +32, Bluff +38, Concentration +53, Knowledge (arcana) +52, Knowledge (religion) +27, Knowledge (the planes) +47, Diplomacy +37 (+35 with good creatures),  
Escape Artist +52, Hide +43, Intimidate +64, Jump +33, Listen +51, Move Silently +52, Sense Motive +46, Search +46, Spellcraft +58, Spot +51, Tumble +54  
**Possessions** _Angel’s Doom_  
_____________________________________________________________  

**Organization** Solitary  
**Environment** Infinite Layers of the Abyss  
_____________________________________________________________  

**_Magic Circle against Good_ **_(Su):_ A magic _circle against good_ always surrounds Israfel (caster level 42th). The defensive benefits of the magic circle have not been included in his statistics block.  

**Regeneration:** Israfel takes lethal damage from good-aligned weapons and from spells and effects with the good descriptor.  

**Ravage - Bonus Feats (Commonx2):** Israfel picked two non-epic bonus feats.  

**Ravage – Favored Enemy (Ex/Abhorrent):** All beings celestial are the sworn enemies of Israfel. However, he has specialized in killing many other enemies as well.  
+12 bonus against Outsider (Good)  
+4 bonus against Outsider (Lawful)  
+4 bonus against Outsider (Chaotic)  
+4 bonus against Dragons  
+4 bonus against Undead  
+3 bonus against Humanoid (human)  
+2 bonus against Outsider (Evil)  

**Ravage – Fighter Feats (Abhorrent):** Israfel has 31 virtual fighter levels for purposes of picking fighter-only feats. Also, he gained 2 fighter feats.  

**Ravage – Gaze of Dread (Su/Vile):** The gaze of Israfel is deadly. It’s a gaze attack that kills anyone that fails a Fortitude save (DC 43). The range of it is 30 feet.  

**Ravage – Ignore Immunity to Critical Hits (Vile):** Israfel has a 50% chance to overcome any immunity to critical hits its victim might possess.  

**Ravage – Immunity (Vile):** Israfel is immune to mind-affecting effects.  

**Ravage - Improved Movement Speed (Vile):** Israfel is incredibly fast, making his base land speed 90 feet.  

**Ravage – Mastery of Silence (Su/Vile):** Once a master of music and sounds, now the mute angel mastered the lack of it.  
Israfel can’t utter a word, but still he can cast spells. All spells and spell-like abilities cast by him are considered as affected by the Silent Spell feat. Nevertheless, he may not cast spells with the Sonic descriptor. Israfel also can’t make breath weapon attacks.  
Additionally Israfel can radiate an aura of silence, if he will. As a swift action, he can radiante an aura with 60 feet radius. All withing this aura suffer the effects of a _silence_ spell. No spell with a vocal component can be cast within the aura, and there is no save. The aura can be dispelled, but Israfel can reform it as a swift action.  

**Ravage – Profane Bonus to AC (Su/Vile):** Israfel benefits from a +4 profane bonus to AC.  

**Ravage – Ranged Energy Attacks (Su/Vile):** Israfel can unleash a missile of unholy energy, in the form of haunted skulls. This attack deals 10d10 unholy damage.  

**Ravage –Smite Good (Su/Abhorrent):** Israfel can use the smite good ability as a 31st level blackguard, 7 times a day. This attack adds +12 to the attack roll and +62 to the damage.  




**Appearance**  
Once a great, beautiful planetar, Israfel is now a depressing creature to behold. His tall, muscular and bald humanoid body is his only resemblance of what he once was. Two of the four wings he once had were cut out completely from his back, and the other two were brutally hacked, leaving only the remnants of his once great and beautiful feathered white wings. The mouth that once sang the most beautiful songs ever heard in the Heavens is now stitched shut by a black thick cord, justifying his title. Israfel’s face forever bears an expression of pure hatred and vengeance. However, the trait that mostly indicates his fall is the two huge bull-like horns that he bears in his forehead, along with the dark rune sword he wields, stained with the blood of countless angels. The skin of the fallen is of a sick pale white.  

**History**  
Centuries ago, there was an angel of great beauty, who sung like no other in the Heavens. His songs could only be matched by those of an angel that few remembered of, known as Triel. This angel was Israfel, the Kerub of Music.  
Israfel was a general of the Defenders of Freedom, and fought against the hordes of evil, always singing inspiring and beautiful songs. The incredible ability to lead the forces of freedom, along with his majestic voice drew the attention of Tifereth, the Defender of Beauty. Israfel and Tifereth became close allies, forming a bond between them.  
Nevertheless, Israfel continued his martial battle against evil forces. One day, after a defeat against the devils in the battlefield, he was captured by the Order of the Fly, and taken to meet Beelzebub himself. The Arch-Duke of Pride had architected this meeting for long, as he sought to bring down the one whose songs were a match of the ones he sung before his fall. The eloquent Lord of Flies managed to influence the Kerub as he wanted. He made him believe that his singing almost reached perfection, but his master would never allow him to achieve it, as she was envious of him. Israfel denied it, but Beelzebub knew what he had done, and the seed of Evil was set. The Kerub was imprisoned for years, but then he managed to escape, as Beelzebub wanted. He returned to Tifereth, but the words of the Lord of Lies echoed within his head.  
At first, he was convinced that they were just lies, and ignored them, but more and more he started to believe them. After some years, Israfel was absolutely convinced of the envy of the Defender of Beauty, as she believed that there was no such thing as “perfection”. At this moment, his fall began.  
Israfel was overcome with pride and arrogance. The Kerub believed that only Tifereth blocked his path to perfection, and decided to betray her. Once again, he met Beelzebub, but this time Israfel sought him. This was exactly what the Lord of Flies planned and predicted. Israfel told the fallen that he would sell him a great secret of the Defender of Beauty, one that would allow the Order of the Fly to expand even within the domains of the Defenders of Freedom. In exchange, he wanted the perfection that Beelzebub promised. Fortunately, the plan was discovered before it could be concretized. The Heavens punishment on Israfel was harsh, as he was charged of high treason. In addition to forever forgetting the secret he was about to tell, his lips were stitched shut forever, making him silent forever. Never again he would sing.  
The fallen was imprisoned for years, until he managed to flee from his prison, falling into the Abyss. Filled with hatred, he was thirst for vengeance, and swore revenge to the Heavens. He wouldn’t rest until the day he would punish those who stripped him from his greatest talent.  
Israfel chooses no means for achieving his revenge. So, he embraced the dark powers of the Abyss in order to gain the power he needs to fulfill his revenge.  
Since his fall, he wanders the Abyss, always seeking opportunities to increase his power. In other occasions he battles the hated angels in the battlefield. Occasionally, he travels to the Prime to do some sort of evil that would affect somehow the Heavens. More than once he has impregnated some of those mortals dear to Tifereth, only to harm her somehow.  
The dark sword Israfel wields is an ancient artifact he encountered somewhere in the Abyss. It was created with the single purpose of destroying angels, and named Angel’s Doom by its current wielder. The runes that cover the sword are made of angelic blood, and it’s said that the blade is made of the bones of a solar. The sword is somehow bonded to Israfel, and it never leaves him for too long, making it impossible to disarm him.  

Nature  
Israfel is fueled only by hatred. He will do anything to destroy those who stripped him from heavenly voice. The Silent is a loner, but he may form alliances, if they can assist him in achieving his goal. Nevertheless, he would betray anyone if it is more interesting for him.  
Many times, he has worked with demons, eventually leading armies against the armies of the Heavens. Nevertheless, he considers them no more than tools for his goals.  
To Israfel, he and his vengeance matter. This selfish but focused aspect makes him less chaotic than he was before. Also, this makes him utterly blind to anything that is not his ultimate goal. It can be argued that he could reach the Demon Lord status, but his disinterest in the struggle for power in the Abyss limits him.  
Whenever he sees useful, he uses his manipulation powers to influence others to do something for him, as he is still very charismatic, and cares nothing about others.  

**Organization**  
Despite the ephemeral alliances with Demon Lords or Princes in the Abyss, Israfel is a loner in his quest for vengeance. Sometimes when battling angels, he becomes a spontaneous leader among demons in the battlefield, but mostly this is unintentional.  

**Relations to other powers**  
Within the Infinite Layers, Israfel has no sworn enemies, if that can be said in a violent plane such as the Abyss. Since he cares very little about the internal fights of the demons, he has not made any major enmity. The ones who did stand in his way were destroyed. He also has no true allies, but many demonic powers are interested in manipulating his power, one of them being Graz’zt. The Dark Prince attempted to approach him many times but Israfel is cunning enough not to get himself too much involved with the demon.  
The existence of Israfel was long-forgotten in the Heavens, but recently he became a power to be taken in consideration by the forces of Good. Tifereth, the Defender of Beauty, was betrayed by him and bears something of a grudge. Israfel, on the other hand, hates her deeply, and blames her and her envy for his fall and loss.  
Israfel has no feelings for the other fallen. He feels that they fell for petty reasons and is at best indifferent about them. However, he feels that he was manipulated by Beelzebub and seeks revenge on him, regardless of the fact that it was him that “opened his eyes” to the truth. In fact, his utter hatred of all, and especially for his damned existence, leads Israfel to despise almost everything.  
