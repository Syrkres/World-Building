---
fileType: Cosmos
cosmosName: Larloch
cosmosType: Archlich
---
# Larloch the Shadow King, the Last True Arcanist
**Wizard 17/Archmage 5/Arcane Lord19/Variator 5**  

**Medium Undead (archlich, augmented human)**  
**Hit Dice:** 46d12 + 598 (966 hp)  
**Initiative:** +7 (Dex)  
**Speed:** 30 ft.  
**AC:** 62 (+12 armor, +13 deflection, +7 Dexterity, +5 insight, +5 luck, +5 natural, +5 profane), touch 45, flat-footed 55  
**Base Attack/Grapple:** +23/+28  
**Attack:** +38 melee touch (5d8 + 13 Will half DC 54 + curses Will negates DC 54); or _arcane fire_ +40 ranged touch (5d6 + 1d6/spell level); or spell +38 melee touch or +40 ranged touch.  
**Full Attack:** +38/+33 melee touch (5d8 + 13 Will half DC 54 + curses Will negates DC 54); or _arcane fire_ +40/+35 ranged touch (5d6 + 1d6/spell level); or spell +38/+33 melee touch or +40/+35 ranged touch.  
**Space/Reach:** 5 ft. x 5 ft./5 ft.  
**Special Abilities:** _Arcane fire_, arcane mastery, _arcane shield_, curses, expanded spell power 3/day, gauge weakness 2/day, mastery of elements, mastery of shaping, metamagic effect, nether lore, recall spell 6/day, seize concentration, snatch spell, spellpool.  
**Special Qualities:** Arcane reach (60 ft.), backlash resistance 15, DR 25/epic and bludgeoning, fear aura, immunities, mind-link, phylactery, recognize spell, silver vulnerability, spell reflection, turn immunity, undead qualities.  
**Saves:** Fort +29, Ref +36, Will +43.  
**Abilities:** Str 20, Dex 24, Con —, Int 46, Wis 26, Cha 36  
**Skills:** Appraise +52 (+54 all craftable items), Bluff +47, Concentration +59, Craft (alchemy) +77, Craft (blacksmithing) +52, Craft (bookbinding) +52, Craft (calligraphy) +52, Craft (gemcutting) +52, Craft (metalworking) +52, Craft (trapmaking) +52, Craft (weaving) +52, Decipher Script +77, Diplomacy +53, Forgery +52, Hide +41, Intimidate +49, Knowledge (arcana) +77, Knowledge (architecture and engineering) +77, Knowledge (dungeoneering) +52, Knowledge (geography) +52, Knowledge (history) +77 (+81 Netheril), Knowledge (local [Netheril]) +77, Knowledge (nature) +52, Knowledge (nobility and royalty) +52 (+58 Netheril), Knowledge (the planes) +77, Knowledge (religion) +52, Listen +42, Move Silently +41, Ride +41, Search +52 (+58 vs. secret doors and compartments), Sense Motive +67, Slight of Hand +49, Spellcraft +148 (+160 to decipher scrolls), Spot +42, Use Magic Device +48 (+50 on scrolls).  
**Feats:** Arcane Manipulation, Arcane Mastery, Augment Spell, Chain Spell, Craft Construct, Craft Rod, Craft Wondrous Item, Greater Spell Focus (variation), Quicken Spell, Scribe Scroll, Skill Focus (spellcraft), Spell Focus (necromancy, transmutation, variation), Spellcasting Prodigy (wizard), Split Ray, Transdimensional Spell, Twin Spell.  
**Epic Feats:** Craft Epic Rod, Craft Epic Wondrous Item, Epic Arcane Manipulation, Epic Skill Focus (spellcraft), Epic Spell Artisan, Epic Spellcasting, Extra High Arcana (true mastery of elements, true mastery of shaping), Improved Metamagic x3, Improved Spell Capacity (10th, 11th, 12th), Multispell x2, Persistent Spell.  
**Salient Abilities:** Arcane Fire, Arcane Shield, Fear Aura, Greater Arcane Fire, Greater Arcane Shield, Improved Fear Aura, Improved Snatch Spell, Seize Concentration, Snatch Spell, Turn Immunity.  
**Climate/Terrain:** The Warlock's Crypt  
**Organization:** Solitary, or with study group (2d4 nec20/acm3 alumnus liches and 1d4 wiz24/acm4/var3 magister liches)  
**Challenge Rating:** 41  
**Treasure:** Ten times standard.  
**Alignment:** Lawful Evil  
**Advancement:** By character class.  

Larloch is said to be the last surviving Netherese arcanist-king, who ruled over his flying city for centuries and abandoned it before Karsus' Folly. Now a lich and one of the oldest non-draconic beings in Faerûn, Larloch has amassed an arsenal of spells, magic items, and servants. The Shadow King, as he is known in the Sword Coast, now rules the Warlock's Crypt (which is actually a corruption of Larloch's name) and its inhabitants—liches (many from Netheril), vampires, wights, and lesser undead.  

Larloch's sole driving motivation seems to be the accumulation of arcane lore. Though his control and understanding of magic is far beyond the ability of most spellcasters to even _comprehend,_ he remains unsatisfied. The author of such masterworks as _Precession and Binary Inversion_ and the great _Book of Inversion and Duplex_, his mastery of metamagic is unequaled even by many gods, and he has personally crafted many an artifact. Larloch remembers well the days of the Netherese Imperium, when mortal men rose in power until they challenged the gods, and wonders were worked that are still the stuff of legends thousands of years later. _He_ was one of those wonder-workers, and the secrets of the mightiest archmages in history yet live on in his mind, and in the thousands of tomes and grimoires he has collected over the centuries (including the original manuscripts of Kirasect's _Necrofolio_, Ralmevik's _Codex of Deviation Theory_, and Morianton's _Investigations and Observations_). But Larloch wants more, and it seems he will not rest until he has learned even the deepest secrets of arcane magic. Though some might say that this is an impossible task, that it would take forever to achieve, Larloch is unconcerned—he has time.  

An important focus of his research has been the reconstruction of the foundation of all Netherese magic—the Nether Scrolls. Though their creation is beyond even his vast power, he has spent many centuries patiently searching for and gathering as many of the originals as he could. His collection totals seventeen scrolls in all, including the complete _arcanis fundare_—the chapter focused on the nature of magic itself. Though the Netherese believed that this chapter contained only the most basic knowledge, and existed only to prepare a reader for more advanced material in the succeeding chapters, like all the scrolls it changes to match the knowledge of its reader. From the _arcanis fundare_ Larloch has drawn great insights into metamagic and epic spellcasting, and the nature of the Weave itself. This set of scrolls has formed the core of his arcane research, and even after over a millennium of study he continues to glean new revelations on the manipulation of magic. Having secured this chapter in its entirety, Larloch is less concerned with the others, though he plans to eventually secure a complete set.  

Having survived the cataclysm that resulted from the death of Mystryl, Larloch values the goddess of magic—and the Weave she protects—very highly. Probably the only thing that could draw him out of his studies would be an imminent threat to Mystra or the Weave. When the first Chosen of Mystra appeared, Larloch took note and spent many years observing and studying them very closely. When he was sure he understood correctly their purpose on Toril, he decided to never cross paths or interfere with them in any way. This should be considered in context, though. Larloch realizes that the destruction or malfunction of the Weave would mean the end of his research and the destruction of all he has accomplished in the last few millennia. He also receives many boons from Mystra—in exchange for disseminating many of his new discoveries, Mystra grants him great freedom in the research of mighty spells and the creation of powerful artifacts. In some ways the magic he works rivals that of ancient Netheril itself. (Note that two of the ten scrolls in his _arcanis fundare_ were recieved directly from the Lady of Mysteries herself as a reward for completing an important task; they did not come from either of the original sets, though—Mystra crafted them personally.)  

Larloch is completely secure in his knowledge and power, and feels no need to compete with anyone. When invaders threaten, he destroys them without remorse. When visitors come peacefully, he often allows them to leave, provided they render him some service that advances his studies—often the acquisition of some artifact or tome that he requires. At least sixteen powerful Red Wizards have tried to kill him and take his power, but all failed. Zulkir Szass Tam, on the other hand, approached him peacefully in negotiations and received two powerful artifacts from his hand. In the end, though, Larloch wants nothing more than to be left alone, to study and experiment in peace.  

Had Larloch desired to conquer Faerûn, he probably could have—or at the very least taken control of a sizeable piece. But he does not. Ruling nations does not interest him in the slightest—he had his fill of that in Netheril, and chose to step down some time before its destruction. He is, however, interested in creating and controlling a network of portals linking many planes and crystal spheres. Like all of his endeavors, this network would be used to advance his research, as the portals would be designed to relieve their users of powerful magic items, and record any arcane secrets contained in their minds. Though the portals themselves are simple enough to create (Larloch has personally visited more planes than almost anyone on Toril), the special enchantments are still proving problematic, even after various centuries of research. Never one to give up, Larloch plans to continue working on this problem until he perfects the process.  

Larloch's form has succumbed to the ravages of time. His flesh is completely gone, leaving only white bone draped in fine garments. His empty eye sockets glow with pinpoints of red light, and over two-dozen _ioun stones_ drift around his head.  

**Combat**  

If pressed in combat or bored with a situation, Larloch prefers to disappear, either with _greater teleport_, _etherealness,_ or a custom spell that allows him to walk through walls. Hidden within his tower are chambers that possess the major negative energy trait (so as to rapidly heal undead bodies), and he spends much of his time in such places. If forced to fight (or in the mood to do so), he enjoys using a rapid arsenal of _time stop_ and quickened twinned spells to overwhelm opponents before they even have the chance to react. He often ignores enemy spellcasters, relying on his spell reflection to take care of them while he focuses on other opponents. With the armory of items he carries with him, it is extremely doubtful that he could ever be caught unawares, and even if he were suddenly overwhelmed by attacks, he is protected by a _chain contingency_ spell that teleports him to one of his safe rooms, completely recovers his hit points, and cures him of ailments as the _greater restoration_ and _break enchantment_ spells, which activates if he loses more than half of his hit points. As a being over two thousand years old, Larloch has thought of ways to deal with almost any situation, and with his supragenius intellect he can compose near-perfect plans at will about situations for which he had not prepared.  

Larloch speaks speaks a wide range of ancient a Larloch the Shadow King


_The dusty corridors of Warlock’s Keep led everywhere and yet nowhere, but Szass Tam knew where he was going. Walking through seemingly solid walls, Thay’s Zulkir of Necromancy felt his body magically whisked away to deeper and darker chambers of the Keep. The lich glanced around the halls as he walked‚ noting the many traps that would have destroyed a mortal form that walked these halls._

_“Larloch!” Szass called out, entering an ancient library. “I bring part of the payment that I promised you. Show yourself.”_

_“Ashrath,” intoned a rumbling voice some distance away. The library slowly illuminated itself in a flickering red glow, casting a fiery light across the assembled tomes. “I’ve been expecting you, Tam,” the voice intoned. “But you’re still three weeks late with payment.”_

_Szass Tam walked toward the sound of the voice, rounding the end of a bookshelf and strolling nonchalantly toward an ornate golden throne pushed into a corner. Larloch, the ancient lich who hailed from Netheril, sat amidst a clutter of books and braziers._

_The Shadow King’s body was in stark contrast to that of Tam. While the Zulkir of Necromancy strove to maintain his human appearance, Larloch was nothing more than a collection of bones partially covered in fine garments. The Netheril lich’s bones were bright white in color, and trails of emerald energy traveled across his form. More than two dozen ioun stones circled his skull, and globes of red light gazed up at Szass Tam as he approached._

_“As I expected, we ran into some Harper resistance,” Tam replied, taking a seat opposite the Shadow King. “They weren’t going to give up the mantle without a fight.”_

_“If they had any inkling of its power‚ they wouldn’t have given it up in death‚ either‚” Larloch grumbled. With a wave of his hand‚ the entire collection of books that lay before him scattered back to their appropriate shelf. His skeletal hand then reached toward Tam. “The mantle?” he asked._

_Szass reached into a pouch and pulled from its magical confines a metal vest enveloped in a violet glow. Larloch’s red eyes shimmered briefly for a moment, determining the magic surrounding the mantle to be a form of preservation spell. He then took the vest from Szass and laid it on the table. A moment later‚ Larloch glanced up at Szass Tam. “Why are you still here‚ Tam?” questioned the ancient lich. “This part of your payment is completed.”_

_“The search for this ancient magic has raised my curiosity,” the Zulkir replied. “I wish to know more about what Netheril really was.”_

_A long moment of silence descended over the two undead creatures, their gazes locked on one another. If Szass would have had a heart, it would have been racing. Finally, Larloch replied._

_“You are both vain and impetuous,” the Shadow King replied. “All who have visited me in the past have been destroyed, regardless of their allegiance.” _

_“That’s because the others who came before me were inept,” said Szass. “True,” replied Larloch. “You have not failed me,” he intoned. “Not yet.”_

_Another long moment of silence filled the library. Years could have passed for all either of the undead cared. Time was meaningless. Finally, without warning or preamble, Larloch, the Shadow King, revealed the secret past of Netheril._

_~ Netheril: Empire of Magic  _
