---
fileType: Cosmos
cosmosName: Set
cosmosType: Greater Deity
---
# Set
_Lord of Evil, Defiler of the Dead, Lord of Carrion, Father of Jackals, Outcast of the Gods, King of Malice, Brother of Serpents_  
**Greater Deity**  
**Symbol:** Coiled Cobra  
**Home Plane:** The Black Pyramid, Ankhwugat (Stygia, Fifth of the Nine Hells of Perdition)  
**Alignment:** Lawful Evil  
**Aliases:** Sutekh  
**Superior:** None  
**Allies:** Sebek, Tiamat  
**Foes:** Anhur, Apep, Asmodeus (possibly), Hathor, Horus, Isis, Prince Leviathan, Merodach, Merrshaulk, Nephthys, Orcus, Osiris, Thoth  
**Servants:** Nekrotheptis Skorpios (Proxy, Deceased), Omikrostis (Proxy)  
**Servitor Creatures:** bezekira, flame snakes (lesser, ordinary, and greater), hell hounds, jackal lords, minions of Set, nightmares, risen dead, venomous serpents (all types, particularly fiendish), yuan-ti  
**Manifestations:** rattlesnake rattles, jackal skulls, hissing noises in the wind, tracks of serpents in sand or dust, serpent shadows, appearances of mummies, the Set hieroglyph appearing in sand formations  
**Signs of Favor:** rattlesnake rattles, jackal skulls, the Set hieroglyph appearing in sand formations  
**Worshipers:** Reptilian creatures, assassins, jealous mortals  
**Cleric Alignments:** NE, LE, CE  
**Speciality Priests:** Yes (Nighthunters)  
**Holy Days:** Deconsecrations  
**Portfolio:** treachery, the desert, storms, drought, venomous reptiles  
**Domains:** Air, Darkness, Evil, Hatred, Law, Scalykind, Trickery  
**Favored Weapon:** _Spear of Darkness_, an unholy spear  

Set  
Fighter 17/Rogue 13/Sorcerer 20/Assassin 10  
Medium Outsider (_Lawful, Evil, Extraplanar_)  
Divine Rank: 16  
**Hit Dice:** 17d10 (fighter) plus 13d6 (rogue) plus 10d6 (assassin) plus 20d4 (sorcerer) plus 900 (1291 hp)  
**Initiative:** +22 (+14 Dex, +8 Superior Initiative)  
**Speed:** 60 ft., fly 240 ft. (perfect)  
**Armor Class:** 88 (+31 natural, +14 Dex, +16 divine, +17 deflection), touch 56, flat-footed 88  
**Base Attack/Grapple:** +39/+71  
**Attack: *** +86 _Spear of Darkness_ or bite +71 and 2 claws +66 or melee touch +71 or ranged touch +69  
* always rolls 20  
**Full Attack: *** +86/+86/+81/+76/+71 _Spear of Darkness_ (1d6 plus +3d6 (unholy power) plus 1 negative level (Fort save DC 23 to remove) plus +60/19-20/x3 plus +2d6 (overwhelming critical) plus +9d6 (unholy) plus 3 negative levels (Fort save DC 23 to remove) and Fort save DC 56 or die) or bite +71 (1d4 plus +16 and Fort save DC 53 or die) and 2 claws +66 (1d4 plus +8) or melee touch +71 or ranged touch +69 *  
* _The Spear of Darkness_ always deals 66 normal damage, 18 unholy, and 1 negative level, Set’s bite always does 20 normal damage, and Set’s claws always do 12 points of damage. Check for criticals.  
**Space/Reach:** 5 ft./5 ft.  
**Special Attacks:** crippling strike, death attack (Fort save DC 44 or die), domain powers, salient divine abilities, sneak attack +15d6 (always does 90 points of damage for two rounds), spells, spell-like abilities  
**Special Qualities:** Divine aura (16 miles, DC 38), divine immunities, DR 35/epic and golden and wielded by a mortal that has read _The Book of Smiting Set *_, evasion, godly realm (100 miles outer plane, 1600 ft. Material Plane), _greater teleport_ at will, hide in plain sight, improved evasion, improved uncanny dodge, _plane shift_ at will, remote communication, resistance (cold) 36, speak, and read all languages and speak directly to all beings with 16 miles, SR 78, trapfinding, trap sense +4, uncanny dodge  
**Saves:** Fort +63 Ref +62 Will +54 *always rolls a 20  
**Abilities:** Str 42 Dex 38 Con 40 Int 38 Wis 34 Cha 44  
**Skills:** Balance +61, Bluff +96, Concentration +51, Decipher Script +48, Diplomacy +136, Disguise +85 (+91 observed in character), Escape Artist +56, Gather Information +60, Handle Animal +41, Hide +83, Intimidate +102, Jump +62, Knowledge (arcana) +80, Knowledge (architecture and engineering) +35, Knowledge (geography) +36, Knowledge (nature) +52, Knowledge (nobility and royalty) +45, Knowledge (religion) +60, Knowledge (the planes) +53, Listen +52, Move Silently +73, Search +60 (+62 find secret doors/hidden compartments), Sense Motive +91, Sleight of Hand +62, Spellcraft +97 (+103 spells on scrolls), Spot +65, Survival +38 (+40 aboveground environments, avoid getting lost, extraplanar), Tumble +61, Use Magic Device +63 (+71 scrolls), Use Rope +32 (+36 bindings) * always rolls 20 on skill checks  
**Feats:** Arcane Preparation, Blind Fight, Cleave, Combat Expertise, Corrupt Spell, Dark Speech, Death Blow, Deft Strike, Dodge, Empower Spell, Eschew Material Components, Great Cleave, Greater Weapon Focus (longspear), Greater Weapon Specialization (longspear), Heighten Spell, Improved Critical, Improved Initiative, Mobile Spellcasting, Power Attack, Twin Spell, Two-Handed Mastery, Weapon Focus (spear), Weapon Specialization (spear)  
**Epic Feats:** Devastating Critical (longspear), Epic Reflexes, Epic Spellcasting, Ignore Material Components, Improved Heighten Spell, Intensify Spell, Overwhelming Critical (longspear), Superior Initiative  
**Environment:** The Black Pyramid, Ankhwugat (Stygia, Fifth Hell of Perdition)  
**Organization:** Set and Retinue (4-6 Fully Advanced Greater Flame Snakes), or Set and Courtiers (2 Ancient Dead, 4-6 Minions of Set)  
**Challenge Rating:** 62  
**Treasure:** _Spear of Darkness_  
**Alignment:** Lawful Evil  
**Advancement:** --  
**Level Adjustment:** --  

**Alter Reality (Su):** Set exerts a considerable measure of control over reality itself, and his presence can command the very essence of the world around him. This warping of reality manifested in a number of ways. Set can use _wish_ when doing so could help him to express his loathing and resentment for the rest of his former pantheon, promote his own worship by tearing down his rivals, or promote ordered evil under his scaled fists through betrayal. Note that in the situation where Set and another deity both try to Alter Reality in opposition to each other, an opposed rank check may be necessary to determine how reality is actually altered.  
- Set can use alter reality to cast any _inflict_ spell at will as a standard action; Set can apply metamagic feats to the spells if desired, but doing so requires him to forego using alter reality for 1 round for each level the feat would normally add to the equivalent spell.  
- As a free action, Set can assume any size from Fine to Colossal. Set can also change the size of up to 100 pounds of objects he touches. This ability allows Set to assume any proportions from the size of a grain of sand up to as much as 1,600 feet tall. A radical change in size can have great impact on Set’s combat ability. Set's Strength, Armor Class, attack bonus, and damage dealt with weapons changes according to the size the deity assumes. Set's Strength score can never be reduced to less than 1 through this ability. Also note that use of this divine ability does not affect all of Set's characteristics.  
**- Divine Immunities:** Ability damage, ability drain, _banishment, binding,_ death effects, _dimensional anchor,_ disease, _disintegration, dismissal,_ electricity, energy drain, fire, _imprisonment,_ mind-affecting effects, paralysis, poison, _repulsion,_ sleep, _soul bind,_ stunning, _temporal stasis,_ transmutation, _trap the soul,_ and turning and rebuking.  
**Divine Power:** Set is a living embodiment of power, and ancient divine magics flow through his veins. As such, mortal items are of virtually no use to him, being so much weaker than his own innate powers. Set gains no benefit from a deflection, enhancement, resistance, insight, sacred or profane bonus that is less than +16\. Note that this only applies to bonuses that affect Set himself; weaponry and armor is unaffected by this.  
**Domain Powers:** rebukes earth elementals and commands air elementals 20/day; gains Blind-Fight as a free feat; casts evil and lawful spells at +1 caster level; gains a +2 bonus on attacks, saves and AC v. 1 opponent for 1 minute 16/day; rebukes reptiles 20/day; treats Bluff, Disguise, and Hide as class skills.  
**Salient Divine Abilities:** Alter Form, Automatic Metamagic (Corrupt Spell), Divine Air Mastery, Divine Blast (20/day, 16 miles long, 33d12 points of damage) *, Divine Dodge (66% miss chance), Divine Skill Focus (Diplomacy), Divine Sneak Attack, Divine Spellcasting, Divine Weapon Focus (spear), Divine Weapon Specialization (spear), Eldritch Knowledge, Extra Domain (Evil), Extra Domain (Hatred), Hand of Death (Fort save DC 53 or die, 16d8 points of damage), Increased Damage Reduction, Lay Curse (16/day, Will save DC 53), Lord of Serpents (Unique Salient Divine Ability), Night Magic (Unique Salient Divine Ability), Power of Nature (16 mile radius, up to 16 minutes after concentration ends), Shapechange, Supreme Damage Reduction  
* always does 396 divine damage  
** always does 128 points of damage  
**Spell-like abilities (Sp):** at will: _air walk, animal growth, animal shapes, animal trance, antipathy, bestow curse, black tentacles, blasphemy, chain lightning, confusion, control winds, control weather, create undead, damning darkness, darkvision, darkbolt, deeper darkness, desecrate, disguise self, disjunction, dispel good, doom, elemental swarm_ (air only), _eyebite, false vision, forbiddance, gaseous form, greater magic fang, invisibility, magic circle against good, magic fang, mislead, nondetection, obscuring mist, poison, polymorph any object, protection from good, righteous might, screen, scare, screen, shadow walk, shapechange, song of discord, summon monster IX_ (lawful and evil spell only), _time stop, unholy blight, unholy aura, utterdark, vipergout, wail of the banshee, wall of force, whirlwind, wind wall._ Cast at 76th level, except for lawful and evil spells which are cast at 77th level. The save DC’s are 53 + spell level and are Charisma-based.  
**Possessions:** _Spear of Darkness_  

**Assassin Spells (Sp) (1st-4th level) 7/7/6/6:** Set casts his Assassin spells at 13th level and at 29th level for the purposes of spell penetration.  

**Assassin Spells Known:** 1st level: _critical strike, sniper’s shot, stupor, true strike._ 2nd level: _illusory script, pass without trace, undetectable alignment, wraithstrike._ 3rd level: _deep slumber, false life, misdirection, nondetection._ 4th level: _cursed blade, dimension door, greater invisibility, sniper’s eye._  

**Lord of Serpents (Unique Salient Divine Ability):** Besides Merrshaulk, Set is one of the beings that has the most sway among reptiles of all sorts, magical and mundane. This influence belonged to Set before he defeated Apep as Sutekh, and extends to the present despite his exile from the Ennead and descent to Perdition as the Outcast of the Gods. Set’s powers not only allow him to command reptiles, but also extend to his taking on some of their traits in the following manners:  

_Distendible Jaw:_ As a full round action, Set may both unhinge and elongate his jaws massively, enabling him to swallow whole any creature of that is of the same size category as himself or one size larger (although if Set opts for the latter choice, he must take 1 full round for 4 HD of the creature that he is devouring). A being that is completely swallowed by Set in this manner is unrecoverable by mortal magic, and even using means such as forbidden magic or salient divine abilities, beings must succeed on a rank check in order to try and resurrect a being devoured by the Defiler of the Dead. Set will often execute servitors that have failed him previously by devouring them slowly in order to demonstrate to the survivors the consequences of potential incompetence.  

_Reptilian:_ Set may bite and claw his opponents in his most natural form. When he chooses to do so, his bite is considered to be a primary attack, and his claws are considered to be a secondary attack.  

_Serpent’s Eyes:_ Beings that meet Set’s eyes, which are amber in what is believed to be his true form, find themselves transfixed by them and must make a Will save DC 53 or else be unable to move unless Set commands them to do so. Furthermore, a being that is transfixed by Set’s gaze additionally takes a –8 penalty to all saving throws and skill checks that are intended to help them discern Set’s malign intentions or resist his enchantments. The effects of the Serpent’s Eyes are only reversible through the casting of _break enchantment, miracle,_ or _wish_ by a 31st level or higher caster.  

_Venomous:_ Set’s canines are hollow, and connect to a set of venom glands contained within his jaws. As a result, the bite of Set is utterly lethal, and anyone bitten by Set must make a Fort save DC 53 or else die instantly as a result. Set may also choose to cause his hands and scales to secrete an extremely potent venom as well, dealing 2d8 points of Con damage to any being that is injured by his claws or attempts to grapple him. Set’s venoms may affect divine beings as well upon a successful rank check.  

Furthermore, Set may choose to spit his venom at his opponents as a standard action. He may either choose to release it as a concentrated stream, hitting opponents up to 60 feet away with it, or he may instead spray it in a cone, hitting everything that is 20 feet in front of him. Set’s venom does not linger if it does not hit a living being and becomes nontoxic within 1 round after landing on an inert surface. While Set may bite his victims at any time in order to inject venom, he must wait 1d4 rounds between either spraying venom or spitting it.  

**Night Magic (Unique Salient Divine Ability):** The power of Set is at it’s greatest in darkness, and it is through darkness that Set as Sutekh defeated his first, great opponent, Apep. Although Set’s jealousy has twisted his own power into the service of boundless ambition, jealousy, and evil, he still retains some of this power in the following ways:  

First, all spells-like abilities that Set uses that create or manipulate darkness are Quickened as long as he casts them during the night.  

Set additionally receives a +8 profane bonus the saving throws of his Illusionary and Necromantic spells if he is casting them at night. Night, for the purpos