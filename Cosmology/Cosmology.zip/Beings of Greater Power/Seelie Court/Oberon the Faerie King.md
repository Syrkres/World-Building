---
fileType: Cosmos
cosmosName: Oberon the Faerie King
cosmosType: Lessor Deity
---
# Oberon the Faerie King
(The Faerie King, Lord of Beasts)
**Lesser Deity**, Seelie Court
**Symbol:** White stag
**Home Plane**:   [[The Feywild]], Wanders/the Seelie Court (the Wildwood)
**Alignment**: Neutral Good  
**Portfolio:** Nature, wild places, animals, defense, hunting
**Aliases:** Alberich
**Domains:**
**Superior:** Titania
**Allies:** Angharradh, Balador, Corellon Larethian, Ehlonna, Erevan Ilesere, Erik, Ferrix, Lurue, Mielikki, Obad-Hai, Rillifane Rallathil, Shiallia, Silvanus, Sehanine Moonbow, Solonor Thelandira, the centaur pantheon, the Seelie Court, the Seldarine, various animal lords
**Foes:** Daragor, Erythnul, Malar, Moander (dead), the Queen of Air and Darkness, Shar, Talos, the orc and goblinoid pantheons
**Worshiper Alignment:** LG, NG, CG, LN, N, CN

Oberon the Faerie King is a god of male faerie warriors and hunters, and patron of wild places and the beasts who live there. He is consort to Titania, but is not fond of the politics of the Seelie Court and prefers to stay away when possible. He is a tireless defender of the sylvan races, and is more than willing to take the fight to the Court’s foes.



As consort to Titania, Oberon (OH-burr-on) is the Faerie King, but he is far more comfortable in the wilderness than he is in dealing with courtly politics. He is a warrior and hunter with few peers among the sylvan deities, and it is his knowledge of wildlife that has earned him the title Lord of Beasts. He is a tireless defender of sylvan lands, and takes the lead in the rare times the faerie realms go to war.

Sylvan myths do not portray an origin for Oberon or Titania, although all myths consider him secondarily to the Faerie Queen; in this they are held by scholars to view them as archetypal powers similar to Annam and Io. Further, the secondary status has led many sages to believe that Titania may have created Oberon as an early companion, although this is likely impossible to prove. Whatever the case, faerie myth speaks often of the marriage of the royal couple and their anniversaries, and these events are frequently backdrops or incidental events even in outside mythology. To some extent, the wedding itself is seen as a perpetually recent event despite its likely ancient status. This may be in part due to the fact that the couple celebrates their golden jubilee every fifty years, although it could also be a quirk of the agelessness of the deities themselves.

This timeless nature of the marriage between Oberon and Titania does not indicate that the pair never has their troubles or disputes. In fact, quarrels between the two are almost as commonly depicted as the marriage and anniversaries. These tales often disrupt the lives of creatures on the Prime Material Plane, causing everything from endless winter to crop failures to the extinguishing of love among married mortals. Despite the problems caused by their quarrels in these tales, both the King and Queen are too stubborn to admit error or attempt to make up with the other and rash vows about rare or impossible events needing to come to pass before the quarrel can be ended are quite common. Despite this, the tales make it clear that both Titania and Oberon are deeply in love, as quite often each works in secret to ensure whatever event is necessary to end the spat comes to pass, and the tales always end with great fanfare and celebration as the couple reunite in marital bliss. The nature of these tales varies considerably; comedic and heroic tales are most common, but some take distinct tragedy or dark drama turns before their happy ends.

Of the myths about Oberon alone, most often portray him helping noble mortals achieve some goal, especially if they aid faerie folk inadvertently or with no greed in their hearts. The tales are a mixture of secret aid that appears as serendipitous good fortune, or open aid where he appears to a mortal that interests him with gifts of magic and advice. Outside of faerie myth, these tales often involve great cultural heroes, while faerie myth tends to use these to remind listeners on how to evaluate and reward the larger humanoids who often come into their sylvan realms. A smaller number of Oberon's myths portray him as confronting or outwitting bestial deities such as Malar or Daragor who represent opposing forces to Oberon's portfolios.

The Faerie King prefers to spend much of his time away from the Seelie Court itself, for he dislikes the politics and intrigues that even faerie nobles engage in. Sages often speculate that as a warrior and the Lord of Beasts, he does not feel his wisdom and intelligence match his consort's skills, thus keeping him away; when questioned on this, faeries never dignify it with a response, however. While away from the Court, Oberon tends to roam the wild lands of Arvandor and the Beastlands, engaging in stag hunting in which his prey is magically subdued rather than slain. Even when he can be found at Court he tends to stay within the Wildwood, a primeval sylvan land which is quite dangerous to the uninvited due to the large number of beasts that can be found there.

Oberon is a very active power; his avatars are frequent visitors to the Prime Material Plane, both to engage in non-lethal stag hunting and to defend faerie lands from incursions by monstrous beasts and rapacious humanoids. He is unafraid of physical combat and rarely relies on trickery or illusion; he trusts in his strength and skill, and quickly takes the fight to any threats he detects.

Oberon's Avatar (Ranger 28, Druid 22, Bard 18)
Oberon appears as a muscular male faerie of large size, but lacking wings. His cloak is made of green leaves stitched onto brown leather, which he wears over subdued garments of green and brown. He draws his spells from the spheres of all, animal, combat, elemental, healing, plant, protection, sun, time, travelers, wards, and weather. Despite having the abilities of an 18th-level bard, he has no access to the bardic spellcasting ability.

AC ˆ’4; MV 15, Sw 12; HP 174; THAC0 ˆ’7; #AT 2
Dmg 1d6+7 (longsword +3, +4 Str), 1d6+10 (longbow +3 and arrows +3, +4 Str)
MR 50%; SZ M (4½ feet tall)
Str 18/76, Dex 19, Con 17, Int 18, Wis 18, Cha 19
Spells P: 11/11/10/10/9/6/3
Saves PPDM 2; RSW 5; PP 4; BW 4; Sp 6

Special Att/Def: Oberon wields a faerie-sized long sword +3 named Eckisax. This blade can cast light or continual light at will, and once per day it can project a sunray. The Lord of Beasts also uses a faerie-sized longbow +3 named Stagshot, which has triple the normal range, which can enchant any arrow fired from it as an arrow +3. Further, Oberon carries a quiver that always holds 20 arrows enchanted to only deal temporary subdual damage, as well as a number of arrows of slaying; he is known to have them for bugbears, goblins, hobgoblins, and orcs, and is rumored to have many others. He carries the Staff of Birnam, a gift from Emmantiensien that can be used as a changestaff (with double hit points) once per day. Finally, he often carries the Cup of Huon, a golden goblet that can create food and wine of a particularly delicious sort capable of feeding a group of twelve humans three times per day.

Three times per day the Faerie King can cast animal summoning I, II, and III, as well as animal growth, call woodland beings (up to 40 HD), conjure animals, and creeping doom. Like all of the other members of the Inner Court he can cast charm person, detect charm, detect magic, detect invisibility, ESP, faerie fire, forget, know alignment, plant growth, speak with animals, and obscurement at will and six times per day he can cast goodberry. In addition, he is able to pass without trace automatically, and move silently and hide in undergrowth (as hide in shadows) in such areas with a 95% success rate.

Oberon is immune to caused wounds, poison, paralyzation, disease, death magic, polymorph attacks, and magical weapons below +1 enchantment. Even if magically compelled, no sentient non-evil plants, non-evil faerie creatures, or normal woodland animals will attack him. However, outside of a sylvan environment, his magic resistance is halved and he suffers a +4 penalty to his Armor Class.

Other Manifestations
Oberon rarely manifests his power, favoring a personal appearance or the appearance of a proxy or other agent. When he does manifest his power, it typically takes the form of an emerald nimbus that surrounds an arrow in flight, enchanting it to deal double damage, deal non-lethal damage, or operating as a relevant arrow of slaying. Less often, this emerald radiance will affect a whole quiver of arrows or a bow for up to one turn, granting all arrows in the quiver or fired from the bow one of the above effects. Finally, he may enchant a well-crafted cup or similar vessel to create food and water once per day, for up to a week at a time.

As a member of the Seelie Court, Oberon is served primarily by aasimon, asuras, and eladrins (especially coures), but he also calls upon normal and giant animals of all sorts, aasimar, alaghi, amber dragons, feystags, guardinals, hybsils, kercpa, ratatosk, sunflies, sylvan elves, voadkyn, warden beasts, and white stags. He displays his favor through the discovery of emeralds, green alexandrite, jade, and peridots, a single green leaf that floats in the air without ever falling while watched, and a small mammal that approaches fearlessly to be petted. He expresses his disfavor through the disembodied braying of a donkey, a green leaf that hovers in the air before rapidly shriveling and falling to earth, and a sudden unsettling quiet in the wilderness when there should be natural sounds.

The Church
Clergy:                      Clerics, specialty priests, druids, rangers, fighters
Clergy's Align.:      NG, CG, N, CN
Turn Undead:           C: Yes, SP: No, D: No, R: No, F: No
Cmnd. Undead:         C: No, SP: No, D: No, R: No, F: No

All clerics, specialty priests, and druids of Oberon receive religion (Seelie Court) as a bonus nonweapon proficiency. Members of Oberon's clergy, including rangers and fighters, are required to take the hunting proficiency, and they gain a +2 bonus when making checks for this proficiency.

While his priesthood is not well known outside of faerie and sylvan societies, Oberon's priests are often feared or admired by those unaware of their affiliations. Those who follow the King of the Faeries are earnest defenders of the deep woodland homes of sylvan folk, often leading bands that can strike fear even in battle hardened humanoid raiding parties for their fierceness and tenacity. They coordinate with the priesthoods of Damh and Eachthighern, as well as unaffiliated rangers and druids, in order to better protect their homelands. They are among the most serious and straightforward of faerie-kind, although this still means they are incredibly flighty and mischievous by human standards.

Oberon's clergy build no temples, preferring to worship him in wild places surrounded by animal life. Watering holes and game trails are especially favored, with the priests making their prayers in the tree boughs above. Shrines devoted to Oberon are extremely rare and consist of a pair of cast-off antlers from a stag or deer and little else. These shrines are simple enough to evade notice from most raiders and despoilers who enter a woodland.

Novices in the service of Oberon are known as Woodland Rovers, while full priests are known as Hunters of the Greenwood. The priesthood maintains no hierarchy and does not use formal titles, although priests often create titles of their own. Specialty priests are known as goodfellows. The Faerie King's clergy has a significantly larger number of males (78%) than females (22%). Most members of the Oberonian clergy are specialty priests (72%), with rangers (12%), clerics (7%), druids (6%), and fighters (3%) filling out the rest. Sprites (45%) and pixies (39%) are the most common members of Oberon's priesthood, with the remainder consisting of buckawns (6%), grigs (4%), satyrs and korred (3%), other faerie and sylvan races (including centaurs, frost sprites, gorse faeries, leprechauns, voadkyn, etc., 2%), and humans and demihumans (mostly forest gnomes and sylvan elves, 1%).

Dogma: The hunt is a thrilling and vital part of life, but it must never be cruel. Hunt for food, but never kill for enjoyment; preserve the lives of the beasts that are hunted if food is not needed. Live in harmony with the beasts, take only what is needed, and the animals will aid you when needed. The tools and skills necessary to make a good hunter can also be used to defend and protect faerie homes; use them to eliminate dark forces that threaten the faerie woodlands.

Day-to-Day Activities: The Faerie King's clergy tend to be restless wanderers within their woodland homes. They hunt, scout, and keep an eye on the fringes to ensure any dangers are spotted as soon as possible. When threats are discovered, they organize appropriate resistance to the threats, even leading bands of warriors into battle if necessary. While they are not strictly militaristic, they do favor eliminating threats with weapons and combat to tricking dangerous creatures into leaving, as they worry such tactics only serve to put off the danger to a later date.

Important Ceremonies/Holy Days: The sole religious event that the Faerie King's clergy observe is the Golden Jubilee of Titania and Oberon, observed every fifty years. This is an event celebrated throughout sylvan and faerie society, rather than a ceremony conducted by Oberon's clergy, however. As such, members of the priesthood can be found wherever they choose to celebrate, including the roving Seelie Court itself.

Major Centers of Worship: Oberon's clergy do not construct temples, but they do view deep and wild woodlands as sacred. Such woodlands are untouched by even the civilization of elves, and untraveled by humans and demihumans, and filled with wild animal life. In these lands the Faerie King's priesthood considers the very act of living to be a worshipful act.

Affiliated Orders: While there are some groups of hunters, rangers, or druids who consider Oberon their patron, his clergy sponsors none of them directly.

Priestly Vestments: Oberon's clergy wears a cloak embroidered to appear as live green leaves over brown and green rustic garb when acting in their sacred roles, although the specific types of clothing varies to an individual priest's tastes. The holy symbol used by the priesthood is a small silver pair of stag antlers worn on a delicate chain around the neck.

Adventuring Garb: The Faerie King's priesthood utilizes the best armor and weapons available to their race when expecting battle. Otherwise they wear comfortable clothing of browns and greens suitable for traveling and hunting.

Specialty Priests (Goodfellows)
Requirements:          Strength 11, Dexterity 13, Wisdom 10
Prime Req.:                Strength, Wisdom
Alignment:                NG, N
Weapons:                   Any
Armor:                       Any
Major Spheres:         All, animal, combat, guardian, healing, plant, protection, sun, travelers, weather
Minor Spheres:         Divination, summoning
Magical Items:         Same as druids and fighters
Req. Profs:                Bow (any), hunting
Bonus Profs:             Tracking

While most goodfellows are sprites or pixies, any sylvan race capable of becoming priests may join the ranks, including voadkyn, as well as forest gnomes and sylvan elves.
Goodfellows are not allowed to multiclass.
Goodfellows may select nonweapon proficiencies from the warrior group without penalty.
Goodfellows gain a +1 bonus to hit with all bows (except crossbows). This is on top of any other bonuses received by race.
Goodfellows can cast pass without trace (as the 1st-level priest spell) once per day for every three levels attained.
At 3rd-level, goodfellows can cast arrow of subduing or speak with animals (as the 2nd-level priest spell) once per day.
At 5th level, goodfellows can temporarily enchant a cup or similar container to imbue any liquid poured into with the powers of a potion of healing; they may do this once per week for every three levels gained beyond 5th level (twice per week at 8th level, three times per week at 11th level, etc.). The container maintains its enchantment for one week or until used, whichever comes first. The container must be made of a valuable substance (silver, gold, etc.) but can otherwise be of any value, shape, or size; most goodfellows have a vessel that they keep specifically for this purpose. Poisons or acid poured into the cup while it is enchanted are neutralized and harmless when they are converted into a potion of healing.
At 7th level, goodfellows can cast animal summoning I or protection from evil, 10€² radius (as the 4th-level priest spells) once per day.
At 9th level, goodfellows can cast animal summoning II (as the 5th-level priest spell) or hold monster (as the 5th-level wizard spell) once per day.
At 13th level, goodfellows can cast animal summoning III or wall of thorns (as the 6th-level priest spells) once per day.
Oberonian Spells
In addition to the spells listed below, priests of the Faerie King can cast the 1st-level priest spell animal animosity, a Rillifane Rallathil spell detailed in Priest's Spell Compendium Vol.I and the 2nd-level priest spell stalk, detailed in Faiths and Avatars in the entry for Mielikki.

2nd Level
Arrow of Subduing (Pr 2; Conjuration/Summoning)
Sphere:                    Charm
Range:                     180 yds.
Components:           V, S, M
Duration:                 Special
Casting Time:          5
Area of Effect:         1 target
Saving Throw:        None

This spell creates a magical arrow with a blunt tip that streaks towards its target as if fired from a bow by a fighter of the same level as the priest. No modifiers for range, nonproficiency, or specialization are applied. The arrow gains no attack damage bonuses, but when it hits, it deals 1d8 points of nonlethal damage, plus one point per level of the caster. If the attack roll succeeds by 5 or more, double damage dice are rolled (i.e. 2d8, +1/level). If a target is reduced to zero or lower hit points from this attack, it falls unconscious for 2d4 rounds; this can be dispelled at will by the caster.

The material component for this spell is a poppy flower.

Hunter's Mark (Pr 2; Enchantment/Charm)
Sphere:                    Animal
Range:                     30 yds.
Components:           V, S, M
Duration:                 1 rd./level
Casting Time:          5
Area of Effect:         1 creature
Saving Throw:        None

By means of this spell, the caster invisibly marks a single target so that missiles are drawn towards their heart. For the duration, all missile attacks gain a +2 attack bonus against a creature affected by hunter's mark and an affected creature counts as one size larger for determining who is struck when missile wielders are firing into melee. In addition small physical missiles (arrows, bolts, sling stones, etc., but not boulders or siege weapons) always deal at least half their maximum damage (rounded up) if they hit. For example, a flight arrow that strikes a creature under the effect of a hunter's mark will deal no less than 3 points damage, and a dart would deal no less than 2 points of damage. Enchanted missiles gain this benefit, but those created by spells or magic items (magic missile, Melf's acid arrow, etc.) do not.

The material components for this spell are the priest's holy symbol and a small wooden disc painted with brightly-colored concentric circles.

4th Level
Wrath of the Wild (Pr 4; Alteration)
Sphere:                    Plant
Range:                     80 yds.
Components:           V, M
Duration:                 1 turn
Casting Time:          7
Area of Effect:         40-ft. cube
Saving Throw:        Special

A more powerful version of entangle, this spell causes the entangling grasses, vines, branches, and the like to grow thorns and razor sharp edges. The grasses, weeds, bushes, and even trees wrap, twist and entwine about the creatures, holding them fast for the duration of the spell. Any creature entangled suffers 1d10 points of damage per round while within the area of effect; this damage is reduced by one point for every Armor Class granted solely from armor or armor-like magic (such as bracers of defense, rings of protection, etc.), to a minimum of 0 damage. For example, a warrior with chain mail +1 and a shield suffers 1d10ˆ’6 damage each round, to a minimum of 0, from the magical armor but not the shield. The spell stoneskin offers complete protection from the damage (counting as an attack each turn), while spells such as armor and barkskin can decrease damage based on their Armor Class bonuses; spells like shield and protection from edged weapons offer no protection, however. No saving throw is allowed to avoid the damage. In all other respects, this spell operates exactly as the entangle spell, including allowing a saving throw versus spell to escape the area at 10 feet per round.

The material components for this spell are the priest's holy symbol and a thorn-covered plant stem.