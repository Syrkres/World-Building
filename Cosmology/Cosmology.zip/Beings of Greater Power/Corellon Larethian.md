---
fileType: Cosmos
cosmosName: Corellon Larethian
cosmosType: Greater Elven Deity
---
#  Corellon Larethian
_Creator of the Elves, The Protector, Protector and Preserver of Life, Ruler of All Elves, First of the Seldarine, Coronal of Arvandor_  
**Greater Elven Deity**  
**Symbol:** Silver crescent moon  
**Home Plane:** Olympus, 1st Layer of Arborea (Arvandor)  
**Alignment:** Chaotic good  
**Portfolio:** Arts, bards, crafts, elves, magic, music, poetry, warriors, war  
**Worshipers:** Arcane archers, artisans, artists, bards, fighters, elves, good leaders, half-elves, rangers, poets, sorcerers, warriors, wizards  
**Cleric Alignments:** CG, CN, NG  
**Domains:** Community, Chaos, Elf, Good, Magic, Protection, War  
**Favored Weapon:** "Sahandrian" (longsword)  

CORELLON LARETHIAN  
Fighter 25, Wizard 25, Bladesinger 15, Archmage 4  
Medium Outsider (Chaotic, Good)  
**Divine Rank:** 19  
**Hit Dice:** 25d10+200 (Ftr) plus 25d4+200 (Wiz) plus 15d8+120 (Bsg) plus 4d4+32 (Acm) (1038 hp)  
**Initiative:** +27, always first (+19 Dex, +8 Superior Initiative, Supreme Initiative)  
**Speed:** 60 ft. (12 squares)  
**Armor Class:** 120 (+24 Dex, +19 divine, +34 natural, +18 deflection, +15 dodge), touch 86, flat-footed 96  
**Base Att/Grapple:** +45/+75  
**Attack*:** _Sahandrian_ +119 melee (1d8+46 plus 2 Dex damage/15-20 plus _hold_ [Fort DC 62]) or _Kalwynrian_ +115 ranged (1d8+27 plus +3d6 anarchic/19-20/x3 plus +6d6 anarchic); or spell +75 melee touch or +86 ranged touch. *Always receives a 20 on attack rolls; roll die to check for critical hit.  
**Full Attack*:** _Sahandrian_ +117/+117/+117/+117/+117/+112/+107/+102 melee (1d8+46 plus 2 Dex damage/15-20 plus _hold_ [Fort DC 62]) or _Kalwynrian_ +113/+113/+113/+113/+113/+108/+103/+98 ranged (1d8+27 plus +3d6 anarchic/19-20/x3 plus +6d6 anarchic); or by spell. *Always deals maximum damage (longsword 54 points, longbow 35 points).  
**Space/Reach:** 5 ft./5 ft.  
**Special Attacks:** Domain powers, salient divine abilities, spell-like abilities, spells.  
**Special Qualities:** Arcane reach, bladesong, divine aura (19 miles, DC 45), divine immunities, DR 30/epic and cold iron, elf traits, familiar (cats), fire resistance 24, godly realm, greater spellsong, _greater teleport_ at will, mastery of counterspelling, mastery of elements, mastery of shaping, _plane shift_ at will, remote communication, song of celerity, song of fury, SR 85, understand, speak, and read all languages and speak directly to all beings within 19 miles.  
**Saves*:** Fort +63, Ref +68, Will +62\. *Always recieves a 20 on saves.  
**Abilities:** Str 32, Dex 48, Con 26, Int 43, Wis 36, Cha 47.  
**Skills*:** Alchemy +52, Appraise +42 (+50 bows, weapons, woodwork), Balance +85, Bluff +39, Climb +77 (+79 rope), Concentration +94, Craft (bowmaking) +113, Craft (weaponsmithing) +113, Craft (woodworking) +113, Diplomacy +69, Disguise +42 (+44 acting), Escape Artist +40 (+42 ropes), Handle Animal +84, Hide +48, Intimidate +76, Jump +83, Knowledge (arcana) +104, Knowledge (history) +67, Knowledge (nature) +78, Knowledge (nobility and royalty) +74, Knowledge (religion) +87, Knowledge (the planes) +67, Listen +43, Move Silently +46, Perform (dance) +57, Perform (sing) +44, Ride (horse) +81, Search +44, Sense Motive +35, Spellcraft +125, Spot +43, Survival +55 (+57 tracking, +59 planar, +59 natural), Swim +67, Tumble +81, Use Rope +48 (+50 bindings) *Always receives a 20 on checks.  
**Feats:** Arcane Strike, Combat Casting, Combat Expertise, Combat Reflexes, Craft Staff, Craft Wand, Craft Wondrous Item, Delay Spell, Dodge, Empower Spell, Eschew Materials, Far Shot, Greater Spell Penetration, Heighten Spell, Improved Combat Expertise, Improved Disarm, Improved Initiative, Mobility, Point Blank Shot, Power Attack, Quick Draw, Rapid Shot, Ranged Pin, Scribe Scroll, Silent Spell, Spell Penetration, Spring Attack, Still Spell, Track, Twin Spell, Widen Spell, Whirlwind Attack  
**Epic Feats:** Dire Charge, Epic Skill Focus (Spellcraft), Epic Spellcasting, Epic Spell Penetration, Epic Weapon Focus (composite longbow), Epic Weapon Specialization (composite longbow), Epic Weapon Focus (longsword), Epic Weapon Specialization (longsword), Improved Heighten Spell, Multispell (x3), Superior Initiative  
**Environment:** Arvandor  
**Organization:** Unique  
**Challenge Rating:** 67  
**Treasure:** _Sahandrian_, _Kalwynrian_, _Wand of the Coronal_, _talisman of pure good_  
**Alignment:** Chaotic good  
**Advancement:** --  
**Level Adjustment:** --  

- **Bladesong:** When wielding a longsword in one hand (and nothing in the other), Corellon gains a dodge bonus to AC equal to his bladesinger class levels.  
- **Song of Celerity:** When wielding a longsword in one hand (and nothing in the other) and using the full attack action, Corellon can cast one wizard spell up to 4th-level each round as a free action.  
- **Greater Spellsong:** Corellon ignores arcane spell failure when wearing light armor.  
- **Song of Fury:** When wielding a longsword in one hand (and nothing in the other) and using the full attack action, Corellon can make on extra attack in a round at his highest base attack, but this attack and each other attack made that round suffer a -2 penalty. This penalty applies for 1 round, so it affects attacks of opportunity Corellon might make before his next action.  
- **Arcane Reach (Su):** Corellon can use spells with a range of touch on a target up to 30 feet away. Corellon must make a ranged touch attack.  
- **Mastery of Counterspelling:** When Corellon counterspells a spell, it is turned back upon the caster as if it were fully affected by a spell turning spell. If the spell cannot be affected by spell turning, then it is merely counterspelled.  
- **Mastery of Elements:** Corellon can alter an arcane spell when cast so that it utilizes a different element from the one it normally uses. This ability can only alter a spell with the acid, cold, fire, electricity, or sonic descriptor. The spell's casting time is unaffected. Corellon decides whether to alter the spell's energy type and chooses the new energy type when he begins casting.  
- **Mastery of Shaping:** Corellon can alter area and effect spells that use one of the following shapes: burst, cone, cylinder, emanation, or spread. The alteration consists of creating spaces within the spell's area or effect that are not subject to the spell. The minimum dimension for these spaces is a 5-foot cube. Furthermore, any shapeable spells have a minimum dimension of 5 feet instead of 10 feet.  
- **Elf Traits:** +2 racial bonus on Will saves against enchantment spells of effects; low-light vision; entitled to a Search check when within 5 feet of a secret or concealed door as thought actively looking for it; martial weapon proficiency with the shortbow, longbow, longsword, and rapier.  
- **Alter Reality:** Corellon can use the _wish_ spell with regard to his portfolio, save for the replication of other spells. This ability costs Corellon no XP, and requires a standard action to implement. Corellon adds once again his Dexterity modifier to modify his attack rolls with weapons, and he adds once again his Intelligence modifier to determine spell saving throw DCs. 19/day (as a free action), for one round at a time, Corellon may add +18 to all damage rolls, or +18 to his effective spellcaster level.  
- **Divine Immunities:** Ability damage, ability drain, acid, cold, death effects, disease, disintegration, electricity, energy drain, mind-affecting effects, paralysis, poison, _sleep_, stunning, transmutation, _imprisonment_, _banishment_.  
- **Divine Power:** Corellon is a living embodiment of power, and ancient divine magics flow through his veins. As such, mortal items are of virtually no use to him, being so much weaker than his own innate powers. Corellon gains no benefit from a deflection, enhancement, resistance, insight, sacred or profane bonus that is less than +19\. Note that this only applies to bonuses that affect Corellon himself; weaponry and armor is unaffected by this.  
- **Domain Powers:** Cast chaos spells at +1 caster level; cast good spells at +1 caster level; 1/day cast _calm emotions_; 19/day protective ward (touched subject gains +10 resistance bonus on next saving throw, maximum duration 1 hour).  
- **Salient Divine Abilities:** Annihilating Strike (Fort DC 40, or destroy up to 19,000 cubic feet of nonliving matter), Arcane Mastery, Area Divine Shield, Automatic Metamagic (quicken wizard spells), Control Creatures (elves), Craft Artifact, Create Greater Object, Create Object, Divine Archery, Divine Blast (21/day, up to 19 miles, 444 points of damage), Divine Creation, Divine Dodge (69%), Divine Shield (11/day, stops 190 points of damage), Divine Spellcasting, Divine Weapon Focus (longsword), Divine Weapon Mastery, Divine Weapon Specialization (longsword), Extra Domain (Community), Extra Domain (Chaos), Instant Counterspell, Longsword Finesse*, Overlord, Spontaneous Wizard Spells, Supreme Initiative.  
*Unique ability, described below.  
- **Spell-Like Abilities:** Corellon uses these abilities as a 88th-level caster, except for chaos spells and good spells, which he uses as a 89th-level caster. The save DCs are 57 + spell level. At will - _aid, animate objects, antimagic field, antipathy, blade barrier, bless, cat's grace, chaos hammer, cloak of chaos, commune with nature, dispel evil, dispel law, dispel magic, divine power, find the path, flame strike, heroes' feast, holy aura, holy smite, holy word, identify, imbue with spell ability, liveoak, magic circle against evil, magic circle against law, magic vestment, magic weapon, mass heal, Mordenkainen's disjunction, Mordenkainen's magnificent mansion, mind blank, Nystul's magic aura, power word blind, power word kill, power word stun, prayer, prismatic sphere, protection from elements, protection from evil, protection from law, protection from spells, Rary's telepathic bond, refuge, repulsion, sanctuary, shatter, shield other, snare, spell immunity, spell resistance, spell turning, spirtual weapon, status, summon monster IX (as chaos or good spell only), sunburst, tongues, tree stride, true strike, word of chaos._  
- **Spells:** As 37th level wizard (55th with alter reality), +62 vs. spell resistance (+80 with alter reality). Corellon may cast 6 epic spells per day, up to DC 145.  
- **Wizard Spells/Day (Levels 0-16):** 4/9/8/8/8/7/6/5/6/6/3/3/3/2/2/2/2; base DC = 43 + spell level.  
- ***Longsword Finesse (unique salient divine ability):** Corellon can apply his Dexterity bonus to attacks he makes with any longsword that he can wield in one hand.  
- **Possessions:** Corellon carries _Sahandrian_, a _+10 extremespeed ultrakeen longsword_. Forged from a star, the great glittering blade deals 100 points of divine damage each round to anyone - aside from a member of the Seldarine - that dares to hold or wield it (double damage against goblinoids and orcs). _Sahandrian_ strikes with such precision that it can sever the muscles of those it strikes, dealing 2 points of Dexterity damage per hit (and forcing a DC 62 Fort save against a _hold monster_ effect on a critical hit). (_Caster Level:_ 69th; _Weight:_ 6 lbs.) Corellon also carries _Kalwynrian_, a _+10 anarchic power extremespeed mighty composite longbow_. Its Strength bonus adjusts to match Corellon's, and he carries a quiver with an infinite supply of arrows. (_Caster Level:_ 69th; _Weight:_ 3 lbs.) In addition, Corellon's crescent moon amulet acts as a _talisman of pure good_, and he carries a slender wand with all the powers of a _staff of frost_, _staff of power_, and a _staff of the magi_, with unlimited charges. His sky-blue cloak would act as a _cloak of epic charisma +12_ if bestowed on a mortal, and his dazzling battle gauntlets allow one to make an extra attack with each full attack action (as though with a _speed_ weapon).  

**Other Divine Powers**  
- As a greater deity, Corellon automatically receives the best possible result on any die roll he makes (including attack rolls, damage, checks, and saves). He is immortal.  
- **Senses:** Corellon can see (using normal vision or low-light vision), hear, touch, and smell at a distance of ninteen miles. As a standard action, he can perceive anything within ninteen miles of his worshipers, holy sites, objects, or any location where one of his titles or name was spoken in the last hour. He can extend his senses to up to twenty locations at once. He can block the sensing power of deities of his rank or lower at up to two remote locations at once for 19 hours.  
- **Portfolio Sense:** Corellon senses anything that affects elven welfare nineteen weeks before it happens and retains the sensation for nineteen weeks after the event occurs. He is similarly aware whenever elves engage in arts or crafts, cast spells, or make war.  
- **Automatic Actions:** Corellon can use Craft (bowmaking), Craft (weaponsmithing), Craft (woodworking), Knowledge (arcana), or Spellcraft as a free action if the DC for the task is 30 or lower. He can perform up to twenty such free actions each round.  
- **Create Magic Items:** Corellon can create any light or medium armor, any simple or martial weapon, any wand or staff, and any item related to woodcraft or stealth, such as a _cloak of elvenkind_.  

**Avatars**  
- Corellon's avatars usually appear as an androgynous male elf of truly unearthly beauty and grace, although he can assume the form of either sex. His avatar always radiates an impression of litheness and swiftness, and is possessed of incredible speed and reflex.  
- Corellon frequently sends avatars to wander and patrol elven lands and borders in disguise, often taking the form of other sylvan creatures such as centaurs, dryads, pixies, or treants. He also keeps discreet watch over elven crafters, priests, and leaders. Though his martial might is swift and terrible, the soft-spoken Creator of the Elves is ever humble and always open to learning something new, one of his sources of might.  

Avatar of Corellon Larethian  
Fighter 10, Wizard 10, Bladesinger 10, Archmage 4  
Medium Outsider (Chaotic, Good)  
**Divine Rank:** 0  
**Hit Dice:** 10d10+50 (Ftr) plus 10d4+50 (Wiz) plus 10d8+50 (Bsg) plus 4d4+20 (Acm) (406 hp)  
**Initiative:** +24 (+16 Dex, +8 Superior Initiative)  
**Speed:** 60 ft. (12 squares)  
**Armor Class:**