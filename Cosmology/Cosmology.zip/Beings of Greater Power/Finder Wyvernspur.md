---
fileType: Cosmos
cosmosName: Finder Wyvernspur
cosmosType: Demigod
---
**Finder Wyvernspur**  
_The Nameless Bard_  
**Demigod**  
**Symbol:** White harp on gray circle  
**Home Plane:** Gates of the Moon  
**Alignment:** Chaotic neutral  
**Portfolio:** Cycle of life, transformation of art, saurials  
**Worshipers:** Artists, bards, saurials  
**Cleric Alignments:** CE, CG, CN  
**Domains:** Chaos, Charm, Renewal, Scalykind  
**Favored Weapon:** "Sword of Songs" (bastard sword)  
  
**Finder Wyvernspur**  
**Bard 25/Ranger 10/Harper Agent 5**  
**Medium Outsider (Chaotic)**  
**Divine Rank:** 4  
**Hit Dice:** 30d6+10d8+360 (620 hp)  
**Initiative:** +16 (+12 Dex, +4 Improved Initiative)  
**Speed:** 60 ft. (12 squares)  
**Armor Class:** 63 (+12 Dex, +4 divine, +19 natural, +12 deflection, +1 luck, +5 armor), touch 39, flat-footed 51  
**Base Att/Grapple:** +25/+38  
**Attack:** _Sword of Songs_ +45 melee (1d10+24 plus 3d6 sonic/19-20)  
**Full Attack:** _Sword of Songs_ +45/+40/+35/+30 melee (1d10+24 plus 3d6 sonic/19-20)  
**Space/Reach:** 5 ft./5 ft.  
**Special Attacks:** Domain powers, favored enemies (aberrations +4, outsiders [evil] +4, dragons+2), salient divine abilities, spell-like abilities, spells  
**Special Qualities:** Bardic knowledge +46, bardic music, Deneir's eye, divine aura (40 ft., DC 26), divine immunities, DR 15/epic and cold iron, evasion, godly realm (400 ft. Outer Plane, 400 ft. Material Plane), _greater teleport_ at will, Lliira's heart, Lurue's voice, Mystra's boon, remote communication, resistance to electricity 9, spontaneous casting of divine spells, SR 56, swift tracker, Tymora's smile, understand, speak, and read all languages and speak directly to all beings within 4 miles, woodland stride  
**Saves:** Fort +29, Ref +36, Will +33  
**Abilities:** Str 28, Dex 34, Con 28, Int 34, Wis 28, Cha 35  
**Skills:** Bluff +46, Concentration +34, Craft (art) +51, Decipher Script +36, Diplomacy +56, Gather Information +41, Heal +31, Hide +31, Intimidate +40, Knowledge (arcana) +44, Knowledge (geography) +36, Knowledge (history) +44, Knowledge (nature) +36, Knowledge (the planes) +21, Listen +43, Move Silently +36, Perform (any) +59, Search +36, Sense Motive +45, Sleight of Hand +35, Spot +35, Spellcraft +53, Survival +35, Tumble +31  
**Feats:** Cleave, Combat Reflexes, Combat Expertise, Endurance (b), Extend Spell, Luck of Heroes, Manyshot (b), Negotiator, Point Blank Shot (b), Power Attack, Quicken Spell, Weapon Focus (bastard sword)  
**Epic Feats:** Combat Insight, Deafening Song, Epic Spellcasting, Epic Prowess, Epic Will, Hindering Song (b), Improved Initiative, Rapid Inspiration  
**Salient Divine Abilities:** Divine Bard, Divine Recall (art), Divine Recall (saurial history), Divine Spellcasting, Irresistible Performance  
**Environment:** Gates of the Moon  
**Organization:** Solitary (unique)  
**Challenge Rating:** 36  
**Treasure:** _Sword of Songs_  
**Alignment:** Chaotic neutral  
**Advancement:** --  
**Level Adjustment:** --  
  
  
- **Alter Reality:** Finder can use the _limited wish_ spell with regard to his portfolio, save for the replication of other spells. This ability costs Finder no XP, and requires a standard action to implement.  
- **Bardic Music (Su):** Finder possesses the full range of bardic music abilities, including coutersong, fascinate, inspire courage, suggestion, inspire greatness, song of freedom, inspire heroics, and mass suggestion. For those with range he can use them up to seven miles in distance as well as affecting even creatures that are immune to mind-affecting effects (though they receive a +10 bonus on their Will saves). All effects of Finder's bardic music are doubled, including number of targets, bonuses, etc. His inspiration abilities last for ten times the normal length, and he may use his countersong ability as a free action.  
- **Deneir’s Eye (Su):** Finder receives a +3 sacred bonus on saving throws against glyphs, runes, and symbols.  
- **Divine Immunities:** Ability damage, ability drain, acid, cold, death effects, disease, disintegration, energy drain, mind-affecting effects, paralysis, poison, sleep, stunning, and transmutation  
- **Domain Powers:** If Finder falls below 0 hp, he regains 1d8+12 hit points. He may command reptiles as a 4th-level cleric 15/day, or boost his Charisma by 4 points 1/day for 1 minute as a free action. He casts chaos spells at +1 caster level.  
- **Lliira's Heart (Su):** The Nameless Bard has a +2 sacred bonus on saves against compulsion and fear effects.  
- **Lurue's Voice (Sp):** Three times per day, Finder may use _speak with animals_.  
- **Mystra's Boon (Su):** Finder receives a +2 sacred bonus on all saving throws against spells.  
- **Spell-Like Abilities:** Finder uses these abilities as a 44th-level caster, except for Chaos spells, which he uses as a 45th-level caster. The save DCs are 36 + spell level - _animal growth, animal shape, animal trance, animate objects, atonement, calm emotions, chaos hammer, charm person, charm person, cloak of chaos, demand, dispel law, dominate monster, eyebite, freedom, geas/quest, greater magic fang, greater restoration, heroes’ feast, insanity, lesser restoration, magic circle against law, poison, polymorph any object, protection from law, reincarnate, remove disease, shapechange, shatter, suggestion, summon monster IX, vipergout, word of chaos_.  
**Spells:** As 29th-level bard and a 5th-level ranger.  
**Bard Spells/Day (Levels 0-12th):** 4/7/7/7/7/6/6/3/3/2/2/2/2; base save DC 23 + spell level; 0 - _detect crossroads, detect magic, ghost harp, ghost sounds, read magic, songbird_; 1st - _amplify, Balagarn's iron horn, cure light wounds, feather fall, magic mouth_; 2nd - _blur, cure moderate wounds, hold person, mirror image, reflective disguise_; 3rd - _analyze portal, cure serious wounds, dispel magic, major image, wounding whispers_; 4th - _cure critical wounds, detect scrying, dimension door, greater invisibility, war cry_; 5th - _greater dispel magic, mass suggestion, mind fog, revenance, song of discord_; 6th - _greater scrying, greater shout, project image, veil_.  
- **Ranger Spells/Day:** 4/3; base save DC = 19 + spell level.  
- **Tymora's Smile (Su):** Once per day, Finder can choose to gain a +2 luck bonus on any saving throw. He can even add this after the die is rolled.  
- **Possessions:** Finder carries _Sword of Songs_, a _+6 sonic blast dancing bastard sword_. The _Sword of Songs_ is able to sing any spell the Finder knows (in his voice) as a free action each round. (_Caster Level:_ 25th; _Weight:_ 8 lb). He also carries the _Saurial Heart_, a powerful gem that grants Finder a +5 armor bonus and resistance bonus to all saving throws. It also allows him to summon a group of ten 10th-level saurial warriors to his aid. (_Caster Level:_ 25th; _Weight:_ 1 lb).  
  
**Other Divine Powers**  
- As a demipower, Finder treats a 1 on an attack roll or saving throw normally and not as an automatic failure. He is immortal.  
- **Senses:** Finder can hear, touch, and smell at a distance of four miles. As a standard action, he can perceive anything within three miles of his worshipers, holy sites, objects, or any location where one of his titles or name was spoken in the last hour. He can extended her senses to up to two locations at once. He can block the sensing power of deities of his rank or lower at up to two remote locations at once for up to three hours.  
- **Portfolio Sense:** Finder is aware of any event that effects saurial well-being or modification of art that involves one thousand or more people.  
- **Automatic Actions:** Finder can use Craft (art), Knowledge (any), or Perform as a free action if the DC for the task is 15 or lower. He can perform up to five such free actions each round.  
- **Create Magic Items:** Finder can create any type of magic item that aids tracking or any sort of a rangers abilities, this includes magic weapons and light armor as long as the item’s market price does not exceed 4,500 gp.