---
fileType: Cosmos
cosmosName: Pelor
cosmosType: Greater Deity
---
# Pelor
_The Shining One_
**Greater Deity **
**Symbol:** Sun Face  
**Home Plane:** Elysium  
**Alignment:** Neutral Good  

**Portfolio:** Sun, light, strength, healing  
**Cleric Alignments:** CG, LG, NG  
**Domains:** Good, Healing, Strength, Sun  
**Favored Weapon:** Mace  

**Cleric 30/Fighter 20/Druid 10  
Medium-Size Outsider  
Divine Rank:** 17  
**Hit Dice:** 30d8 (cleric) + 20d10 (fighter) + 10d8 (druid) + 780, (1,300 hp)  
**Initiative:** +16 (+12 Dex, +4 Improved Initiative)  

**Speed:** 60 ft.  
**AC:** 98 (+12 Dex, +17 divine, +42 natural, +17 deflection)  
**Base Attack/Grapple:** +35/+69  
**Attacks*:** +10 _mighty disruption fiery blast_ heavy mace +84 (1d8+30, 19-20/x20). _*Always receives a 20 on attack rolls; roll die to check for critical hit. Maximum damage with mace (mace 38 + 18 fire)_  

**Full Attack*:** +10 _mighty disruption fiery blast_ heavy mace +84/+79/+74 (1d8+30, 19-20/x20). _*Always receives a 20 on attack rolls; roll die to check for critical hit. Maximum damage with mace (mace 38 + 18 fire)._  
**Face/Reach:** 5 ft. by 5ft./5 ft.  
**Special Attacks:** turn undead (32/day, +2 synergy), domain powers, salient divine abilities, spell-like abilities  

**Special Qualities:** Divine Immunities, DR 25/epic and silver and unholy, Fire Immunity, Fast Healing 37, Godly Communication, Godly Realm, SR 79, divine aura (1700’ DC 44), animal companion, nature’s sense, resist nature’s lure, trackless step, wild empathy (+44), wild shape (large) 4/day, woodland stride.  
**Saves*:** Fort +62, Ref +55, Will +74 _*Always receives a 20 on saves._  
**Abilities:** Str 46, Dex 34, Con 36, Int 40, Wis 61, Cha 44.  

**Skills *:** Concentration +83 (53), Craft (glassmaking) +81 (49), Craft (metalworking) +81 (49), Diplomacy +73 (39), Handle Animal +67 (33), Heal +97 (55), Knowledge (arcana) +80 (48), Knowledge (nature) +68 (36), Knowledge (religion) +80 (48), Knowledge (undead) +54 (22), Listen +91 (49), Perform +59 (25), Profession (farmer) +94 (52), Profession (herbalist) +95 (53), Profession (sailor) +95 (53), Ride (horse) +60 (31), Search +54 (22), Sense Motive +64 (22), Spellcraft +84 (52), Spot +78 (36), Survival +79 (37). _*Always receives a 20 on checks_.  
**Feats:** Cleave (B), Combat Expertise (B), Dodge, Empower Spell, Extra Turning x3, Great Cleave, Improved Critical (heavy mace), Improved Initiative, Mobility (B), Mounted Combat (B), Power Attack (B), Ride-by Attack (B), Spirited Charge (B), Spring Attack (B), Weapon Focus (heavy mace), Weapon Specialization (heavy mace), Whirlwind Attack (B).  
**Epic Feats:** *Divine Might, *Divine Vengeance, Enhance Spell, Epic Spellcasting, *Heighten Spell, Improved Heighten, Improved Metamagic, Intensify Spell, *Maximize Spell, *Natural Spell, Planar Turning, Positive Energy Aura, *Reach Spell, *Twin Spell. _*feats taken in epic slots_  

**Divine Immunities:** Ability Damage, ability drain, acid, cold, death effects, disease, disintegration, electricity, energy drain, mind-affecting effects, paralysis, poison, sleep, stunning, transmutation, imprisonment, banishment.  
**Salient Divine Abilities:** Area Divine Shield, Automatic Meta-magic (quicken spell), Call Creatures (eagles of all sorts), Create Greater Object, Create Object, Divine Blast, Divine Creation, Divine Fast Healing, Divine Radiance, Divine Shield, Divine Spellcasting, Divine Storm, Divine Weapon Focus (heavy mace), Extra Domain (strength), Extra Energy Immunity (fire), Gift of Life, Increased Damage Reduction, Life and Death, Mass Divine Blast, Mass Life and Death, Rejuvenation, Supreme Initiative.  
**Domain Powers:** Cast good spells at +1 caster level; cast healing spells at +1 caster level; 17/day feat of strength (+30 enhancement to Str for 1 round); 17/day greater turing.  
**Spell-Like Abilities:** _At will_ - Good, Healing, Strength, and Sun domain spells (caster level 27th, DC 44 + spell level), _teleport, greater_ (1700 lbs) and _plane shift_ (1700 lbs) (caster level 20th)  

**Cleric Spells/Day:** (6/12+1/11+1/11+1/11+1/11+1/9+1/9+1/9+1/9+1/5/5/5/5/4/4/4/4/3/3/3/3/2/2; caster level 47th, DC 61 + spell level)  
**Druid Spells/Day:** (6/11/10/9/9/8; caster level 27th, DC 35 + spell level)  
**Possessions:** +10 _mighty disruption fiery blast_ heavy mace  

**Other Divine Powers**  

**Alter Reality**  
Pelor can use wish with regard to any action that involves the sun, light, a act of strength, or healing; he cannot duplicate spells though. It is a standard action for Pelor to alter reality in this fashion.  
Pelor has full access to the abilities described in the Alter Size SDA.  
Pelor may create an avatar as described in the Avatar SDA.  

Pelor also gains the following benefits:  
Pelor adds his Wisdom modifier (+25) again for determining cleric spell DC’s.  

Pelor may also do the following up to 17/day: add his Charisma modifier (+17) to his cleric spellcaster levels for purpose of determining damage, range, SR checks, # of targets, etc.  

**Senses:** Pelor can see, hear, touch, and smell at a distance of seventeen miles. As a standard action, Pelor can perceive anything within seventeen miles of his servants or worshippers, holy sites, objects, or any location where one of his titles or name was spoken in the last hour. He can extend his senses up to 20 locations at once.  

**Portfolio Sense:** Pelor can sense any dusk or dawn. He knows when any light is lit, he is likewise aware of any healing. He notes this 17 weeks before they happen and retains them for 17 weeks thereafter.  

**Automatic Action:** Pelor can use any Strength-related skill as a free action if the DC for the task is 30 or lower. He may use any one of his craft, knowledge, or profession skills as a free action if the DC for the task is 30 or lower. He cannot do anything as a free-action if his task is part of a move action. He can perform up to 20 such free actions each round.  

**Magic Items:** Pelor can create any item that sheds light or flame as a flaming burst weapon. He can also create items that heal injures or restores life.  

* * *

A great creation of [DiceFreaks](http://community.dicefreaks.com/) and copied here for reference.  

