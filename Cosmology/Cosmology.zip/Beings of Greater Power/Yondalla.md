---
fileType: Cosmos
cosmosName: Yondalla
cosmosType: Greater Deity
---
# Yondalla
_The Protector and Provider, The Nuturing Matriarch, The Blessed One_  
**Greater Halfling Deity**  
**Symbol:** Shield bearing cornucopia (horn of plenty)  
**Home Plane:** Venya, the Pearly Heaven, the 3rd layer of Mount Celestia (the Green Fields)  
**Alignment:** Lawful good  
**Portfolio:** Bounty, children, community, creation, diplomacy, family, fertility, halflings, harmony, leadership, prosperity, protection, security, the cycle of life, tradition, wisdom  
**Worshipers:** Children, explorers, halflings, leaders, paladins, parents, pioneers  
**Cleric Alignments:** LG, NG, LN  
**Domains:** Community, Creation, Family, Good, Halfling, Law, Protection  
**Favored Weapon:** "Hornblade" (short sword)  

**YONDALLA  
Paladin 20, Cleric 24, Sorcerer 20  
Small Outsider (Good)**  
**Divine Rank:** 18  
**Hit Dice:** 20d10+200 (Pal) plus 24d8+240 (Clr) plus 20d4+200 (Sor) (1,112 hp)  
**Initiative:** +21, always first (+13 Dex, +8 Superior Initiative, Supreme Initiative)  
**Speed:** 50 ft. (8 squares)  
**Armor Class:** 99 (+1 size, +13 Dex, +18 divine, +33 natural, +14 deflection, +10 shield), touch 56, flat-footed 86  
**Base Att/Grapple:** +42/+68  
**Attack:** _Hornblade_ +95 melee (1d6+17/19-20 plus decapitation); or spell +68 melee touch or +73 ranged touch. *Always receives a 20 on attack rolls; roll die to check for critical hit.  
**Full Attack:** _Hornblade_ +95/+90/+85/+80 melee (1d6+17/19-20 plus decapitation); or by spell. *Always does maximum damage (short sword 23 points)  
**Space/Reach:** 5 ft./5 ft.  
**Special Attacks:** Domain powers, salient divine abilities, smite evil (+14 attack, +40 damage) 5/day, spell-like abilities, turn undead/outsiders 20/day.  
**Special Qualities:** Aura of courage, aura of good, _detect evil_ at will, divine aura (18 miles, DC 42), divine grace, divine immunities, DR 30/epic and cold iron, familiar (bears), fast healing 38, fire resistance 23, godly realm (100 miles outer plane, 1800 ft. material plane), _greater teleport_ at will, lay on hands (280 points/day), remote communication, _plane shift_ at will, remove disease 5/week, special mount, spontaneous casting of divine spells, SR 102, understand, speak, and read all languages and speak directly to all beings within 18 miles.  
**Saves:** Fort +79, Ref +72, Will +80\. *Always receives a 20 on saves.  
**Abilities:** Str 26, Dex 37, Con 30, Int 30, Wis 40, Cha 38.  
**Skills:** Appraise +28 (+34 leather, +34 metal, +34 wood), Bluff +67, Concentration +75, Climb +28, Craft (leatherworking) +82, Craft (metalworking) +82, Craft (woodworking) +82, Diplomacy +100, Disguise +32 (+36 acting), Handle Animal +57, Heal +63, Hide +35, Intimidate +41, Jump +33, Knowledge (arcana) +73, Knowledge (nature) +48, Knowledge (religion) +88, Listen +65, Move Silently +33, Profession (farmer) +83, Ride (horse) +60, Search +43, Sense Motive +63, Spellcraft +81, Spot +48, Survival +33 (+35 natural, +35 tracking) *Always receives a 20 on checks.  
**Feats:** Alertness, Combat Expertise, Combat Reflexes, Divine Vengeance, Dodge, Eschew Materials, Extra Turning, Heighten Spell, Improved Combat Expertise, Improved Critical (short sword), Improved Disarm, Improved Initiative, Improved Trip, Mobility, Sacred Spell, Spring Attack, Track, Weapon Finesse, Whirlwind Attack.  
**Epic Feats:** Epic Spellcasting, Great Smiting, Improved Heighten Spell, Planar Turning, Superior Initiative.  
**Environment:** The Green Fields  
**Organization:** Unique  
**Challenge Rating:** 64  
**Treasure:** _Hornblade_, _Cornucopia_  
**Alignment:** Neutral good  
**Advancement:** --  
**Level Adjustment:** --  

- **Divine Immunities:** Ability damage, ability drain, acid, death effects, disease, disintegration, electricity, energy drain, fire, mind-affecting effects, paralysis, poison, _sleep_, stunning, transmutation, imprisonment, banishment.  
- **Divine Power:** Yondalla is a living embodiment of power, and ancient divine magics flow through her veins. As such, mortal items are of virtually no use to her, being so much weaker than her own innate powers. Yondalla gains no benefit from a deflection, enhancement, resistance, insight, sacred or profane bonus that is less than +18\. Note that this only applies to bonuses that affect Yondalla herself; weaponry and armor is unaffected by this.  
- **Salient Divine Abilities:** Area Divine Shield, Battlesense, Blessing of Yondalla*, Command Plants, Control Creatures (halflings), Create Greater Object, Create Object, Curse of Yondalla*, Divine Blast (17/day, 384 damage), Divine Creation, Divine Dodge (68%), Divine Fast Healing, Divine Shield (13/day, 180 points), Divine Spellcasting, Extra Domain (Community), Extra Domain (Family), Gift of Life, Increased Spell Resistance, Overlord, Shield Mastery*, Speak with Creatures (animals), Speak with Creatures (plants), Supreme Initiative.  
*Unique ability, described below.  
- **Alter Reality:** Yondalla can use the _wish_ spell with regard to her portfolio, save for the replication of other spells. This ability costs Yondalla no XP, and requires a standard action to implement. Yondalla adds once again her Dexterity modifier to her melee attacks, and her Wisdom or Charisma modifier to determine her spell saving throw DCs. 18/day, for 1 round at a time, she may add +14 to all damage rolls, or to her effective spellcaster level.  
- **Domain Powers:** 1/day, add +14 to all Climb, Jump, Move Silently, and Hide checks for 10 minutes as a free action; cast good spells at +1 caster level; 1/day, cast _calm emotions_; cast creation spells, good spells, and law spells at +1 caster level; protect 14 creatures within 10 feet (self may be included) with a +2 dodge bonus to AC for 24 rounds as a free action; 24/day _protective ward_ (touched subject gains +15 resistance bonus on next saving throw, maximum duration 1 hour).  
- **Spell-Like Abilities:** Yondalla uses these abilities as a 82nd-level caster, except for creation spells and good spells, which she uses as a 83rd-level caster. The save DCs are 52 + spell level. At will - _aid, antimagic field, blade barrier, bless, calm emotions, cat's grace, create food and water, create water, dictum, dispel chaos, dispel evil, foresight, freedom of movement, helping hand, heroes' feast, hold monster, holy aura, holy smite, holy word, imbue with spell ability, magic circle against chaos, magic circle against evil, magic stone, magic vestment, major creation, mass heal, mind blank, minor creation, minor image, Mordenkainen's faithful hound, Mordenkainen's magnificient mansion, move earth, order's wrath, pavilion of grandeur, permanent image, prayer, prismatic sphere, protection from chaos, protection from elements, protection from evil, protection from spells, Rary's telepathic bond, refuge, repulsion, sanctuary, shadow walk, shield of law, shield other, spell immunity, spell resistance, status, summon monster IX_ (as good or law spell only)_, tongues, true creation, word of recall_.  
- **Spells:** As a 24th level cleric (38th with alter reality), +42 vs. SR (+56 with alter reality); a 10th level paladin (24th with alter reality), +28 vs. SR (+42 with alter reality); and as a 20th level sorcerer (34th with alter reality), +38 vs. SR (+52 with alter reality). Yondalla may cast up to 4 arcane and up to 6 divine epic spells per day, up to DC 101.  
- **Cleric Spells/Day (Levels 0-15):** 6/9/9/9/8/8/7/7/6/6/3/3/2/2/2/2; base DC = 41 + spell level.  
- **Paladin Spells/Day (Levels 0-15):** 7/7/7/6/4/4/4/3/3/3/3/2/2/2/2; base DC = 41 + spell level.  
- **Sorcerer Spells Known (Levels 0-14):** 6/10/10/9/9/9/9/8/8/8/3/2/2/2/2; base DC = 39 + spell level: 0 - _arcane mark, detect magic, detect poison, ghost sound, light, mage hand, mending, prestidigation, read magic_; 1st - _alarm, detect secret doors, expeditious retreat, grease, obscuring mist_; 2nd - _arcane lock, detect thoughts, glitterdust, see invisibility, summon swarm_; 3rd - _displacement, fly, halt undead, sleet storm_; 4th - _confusion, Leomund's secure shelter, Otiluke's resilient sphere, solid fog_; 5th - _animal growth, dismissal, Bigby's interposing hand, wall of force_; 6th - _analyze dweomer, Bigby's forceful hand, greater heroism_; 7th - _banishment, Bigby's grasping hand, spell turning_; 8th - _antipathy, Bigby's clenched fist, mind blank_; 9th - _Bigby's crushing hand, Mordenkainen's disjunction, time stop_.  
- ***Blessing of Yondalla (unique salient divine ability):** As a provider, Yondalla is a goddess of fertility and growing things, of birth and youth. She can make barren places and creatures fertile, and increase the growing rate of plants and animals, almost as she chooses. She may affect anything within her senses with this power (unwilling creatures recieve a DC 56 Will save to resist), but she uses such powers sparingly and almost never confers such benefits on other demihumans or upon humans, for fear of giving offense to their gods.  
- ***Curse of Yondalla (unique salient divine ability):** Yondalla does not use this ability lightly, reserving it for creatures who have greatly offended her - for example, by destroying a halfling community or killing innocent and defenseless halflings, such as the aged or very young. As a standard action, with a wave of her hand, she may target any creature within 100 ft. If the creature fails a Will save (DC 56), it begins growing younger, slowly at first and then rapidly, until it is once again an infant. This process takes 10 rounds, during which time the creature is stunned, and unable to attack, cast spells, or perform any other offensive actions. The infant has no memory of its previous life. Commonly, a halfling community then raises the infant to respect halflings and the ways of Yondalla. An infant of a species inherently unsafe for such folk to raise (such as a troll or dragon) is placed with a foster parent of a species able to properly raise it in a positive moral and ethical fashion.  
- An undead creature that fails its saving throw is simply destroyed. An extraplanar creature or outsider that fails its saving throw is merely cast back to its home plane and unable to return to the Prime Material Plane for 100 years. A creature that makes its saving throw takes half its remaining hit points in damage.  
- ***Shield Mastery (unique salient divine ability):** Yondalla ignores the arcane spell failure chance and armor check penalty for carrying any type of shield.  
- **Possessions:** Yondalla carries _Hornblade_, a _+9 defending vorpal short sword_ that glows silver when it strikes. Undead and evil outsiders take double damage. (_Caster Level:_ 64th; _Weight:_ 2 lbs.) She also carries _Cornucopia_, a _+9 infinite and exceptional arrow deflection small wooden shield_ emblazoned with her symbol. Any creature within 18 ft. of the shield feels refreshed, and needs not eat, drink, or sleep (though they must rest normally to prepare spells) while nearby it or for 18 days thereafter. (_Caster Level:_ 64th; _Weight:_ 5 lbs.)  

**Other Divine Powers**  
- As a greater deity, Yondalla automatically receives the best possible result on any die roll she makes (including attack rolls, damage, checks, and saves). She is immortal.  
- **Senses:** Yondalla can see, hear, touch, and smell at a distance of eighteen miles. Yondalla sees equally well in full daylight, twilight, moonlight, or starlight, but she cannot see in total darkness. As a standard action, she can perceive anything within eighteen miles of her worshipers, holy sites, objects, or any location where one of her titles or name was spoken in the last hour. She can extend her senses to up to twenty locations at once. She can block the sensing power of deities of her rank or lower at up to two remote locations at once for 18 hours.  
- **Portfolio Sense:** Yondalla senses anything that affects halfling welfare eighteen weeks before it happens and retains the senstation for eighteen weeks after the event occurs. She is similiarly aware of the birth of any halfling.  
- **Automatic Actions:** Yondalla can use Craft (leatherworking), Craft (metalworking), Craft (woodworking), Knowledge (arcana), or Knowledge (nature) as a free action if the DC for the task is 30 or lower. She can perform twenty such free actions each round.  
- **Create Magic Items:** Yondalla can create armor and magical protection devices, such as _bracers of armor_, a _ring of protection_, or a _cloak of resistance_.  

**Avatars**  
- Yondalla sends her avatars to wander halfling lands, keeping an eye out for trouble, and aiding with agriculture and other community activities. They may appear as other sorts of halflings, but usually like her - a strong, proud, vibrantly attractive female halfling, determined of bearing, with long golden hair, a skirt of forest green, a corn yellow and earth brown tunic, and a stout wooden shield.  

* * *

A great creation of [DiceFreaks](http://community.dicefreaks.com/) and copied here for reference.  
