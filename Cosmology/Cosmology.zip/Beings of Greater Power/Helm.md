---
fileType: Cosmos
cosmosName: Helm
cosmosType: Intermediate Deity
---
# Helm
_The Watcher, the Vigilant One_  
**Intermediate Deity**
Symbol: Staring eye with blue pupil on an upright war gauntlet  
**Home Plane**: House of the Triad  
**Alignment:** Lawful neutral  
**Portfolio**: Guardians, protectors, protection  
**Worshipers**: Explorers, fighters, guards, mercenaries, paladins  
**Cleric Alignments**: LE, LG, LN  
**Domains**: Law, Planning, Protection, Strength  
**Favored Weapon**: _"Ever Watchful"_ (bastard sword)  

Helm  
Fighter 30/Devoted Defender 10/Guardian Paramount 20  
Medium Outsider (Lawful)  
Divine Rank: 11  
**Hit Dice**: 30d10 (fighter) plus 10d12 (defender) plus 20d10 (guardian) plus 900+150 (1,670 hp)  
**Initiative**: +16 (+8 Dex, +8 Superior Initiative)  
**Speed**: 60 ft. (12 squares)  
**Armor Class**: 82 (+1 Dex, +11 divine, +26 natural, +11 deflection, +5 dodge, +18 armor), touch 38, flat-footed 76.  
**Base Att/Grapple**: +40/+68  
**Attack**: _Ever Watchful_ +82 melee touch (1d10+43+3d6 law and 1 negative level+2d6 holy/19-20/x2); or spell +66 melee touch or +56 ranged touch.  
**Full Attack**: _Ever Watchful_ +82/+77/+72/+67 melee touch (1d10+43+3d6 law and 1 negative level+2d6 holy/19-20/x2); or spell +66 melee touch or +56 ranged touch.  
**Space/Reach**: 5 ft./5 ft.  
**Special Attacks**: Salient divine abilities, spell-like abilities.  
**Special Qualities**: Divine aura (1100 ft., DC 32), divine immunities, DR 30/epic and adamantine, fire resistance 18, godly realm (10 miles Outer Plane, 1100 ft. Material Plane), greater teleport at will, plane shift at will, remote communication 11 miles, SR 73, understand, speak, and read all languages and speak directly to all beings within 11 miles, harm’s way, defensive strike, defensive attack, uncanny dodge enabler, evasive preceptor, adjust probability, protective aura, call back, fast healing 15, evasion, improved uncanny dodge.  
**Saves**: Fort +66, Ref +55, Will +58  
**Abilities**: Str 45, Dex 27, Con 40, Int 24, Wis 40, Cha 32  
**Skills**: Bluff +37, Climb +43, Concentration +36, Diplomacy +61, Gather Information +32, Heal +58, Intimidate +76, Jump +58, Knowledge (history) +34, Knowledge (the planes) +34, Knowledge (religion) +38, Listen +125, Search +58, Sense Motive +65, Spot +125, Survival +43, Swim +43.  
**Feats**: Alertness, Cleave (b), Combat Expertise (b), Combat Reflexes (b), Great Cleave(b), Great Fortitude, Greater Weapon Focus (bastard sword) (b), Greater Weapon Specialization (bastard sword) (b), Improved Combat Expertise, Improved Critical (bastard sword) (b), Improved Initiative (b), Iron Will, Lightning Reflexes, Power Attack (b), Skill Focus (listen), Skill Focus (spot), Weapon Focus (bastard sword) (b), Weapon Specialization (bastard sword) (b).  
**Epic Feats**: Armed Deflection (b), Blinding Speed, Devastating Critical (b), Dire Charge, Epic Combat Expertise, Epic Fortitude (b), Epic Reflexes (b), Epic Skill Focus (Listen) (b), Epic Skill Focus (Spot) (b), Epic Toughness (x5), Epic Weapon Focus (bastard sword) (b), Epic Weapon Specialization (bastard sword) (b), Epic Will (b), Fast Healing (x5), Improved Combat Reflexes (b), Overwhelming Critical (bastard sword) (b), Reflect Arrow, Spellcasting Harrier (b), Superior Initiative.  
**Salient Divine Abilities**: Annihilating Strike, Area Divine Shield, Battlesense, Clearsight, Divine Blast, Divine Shield, Divine Skill Focus (Listen), Divine Skill Focus (Spot), Indomitable Strength, Irresistible Blows, Power of Truth, Ring of Shields*, The Great Guard*, The Unsleeping Eye*.  
* Unique salient abilities; see below.  
**Environment:** House of the Triad  
**Organization**: Solitary (unique)  
**Challenge Rating**: 52  
**Treasure**: _Ever Watchful, +10 full plate_  
**Alignment**: Lawful neutral  
**Advancement**: --  
**Level Adjustment**: --  

- **Harm’s Way (Ex)**: Helm may place himself in the path of danger in order to protect his charge. Anytime Helm is within 5 feet of his charge, and they suffer an attack. Helm may switch places with the charge and receive the attack in their place. He must declare this before the attack roll is made. He selects his charge when initiative is rolled for combat and may not change them for the duration.  
- **Defensive Strike (Ex)**: Helm may make an attack of opportunity against any enemy who attacks his charge. He receives a +4 bonus on his attack.  
- **Deflect Attack (Ex)**: Helm may attempt to parry an attack against his charge when within five feet of them. Once per round when his charge would be hit with a melee attack he may make a Reflex saving throw (DC: 20+magic bonus of any attacking weapon). He gains a +4 bonus on this roll. If he succeeds he deflects the blow as a free action.  
- **Uncanny Dodge Enabler (Ex)**: Helm can extend his improved uncanny dodge ability to any one creature he designates within five feet. He can do this up to nine times per day.  
- **Evasive Preceptor (Ex)**: Helm can extend his evasion ability to any one creature he designates within five feet. He can do this up to seven times per day.  
- **Protective Aura (Sp)**: Helm can create a _shield other_ effect six times per day. Any wounds transferred to Helm are considered subdual damage, not normal damage.  
- **Adjust Probability (Ex)**: Seven times per day, Helm can affect probability. Helm can force a reroll of one attack roll, check, or saving throw that another creature within 25 feet-friend of enemy-just made. The use of this ability takes place outside of normal initiative order, and Helm can use it even after the first roll has already been made.  
- **Call Back (Sp)**: Three times per day, Helm can call a creature he has used any of his guardian paramount abilities on previously back to life as per the true resurrection spell.  
- **Divine Immunities**: Ability damage, ability drain, acid, cold, death effects, disease, disintegration, electricity, energy drain, mind-affecting effects, paralysis, poison, sleep, stunning, transmutation, imprisonment, banishment.  
- **Alter Reality**: Helm can use the _wish_ spell with regard to his portfolio, save for the replication of other spells. This ability costs Helm no XP, and requires a standard action to implement.  
- **Domain Powers**: Cast law spells at +1 caster level; feat of strength 1/day (gain a +11 enhancement bonus to Strength for one round), protective ward 1/day, bonus feat of Extend Spell  
- **Spell-Like Abilities**: Helm uses these abilities as a 71st-level caster, except for law spells, which he uses as a 72nd -level caster. The save DCs are 42 + spell level. antimagic field, augury, bigby’s clenched fist, bigby’s crushing first, bigby’s grasping hand, bull’s strength, calm emotions, clairaudience/clairvoyance, deathwatch, detect scrying, dictum, discern location, dispel chaos, enlarge person, greater scrying, heroes’ feat, hold monster, imbue with spell ability, magic circle against chaos, magic vestment, mind blank, order’s wrath, protection from chaos, protection from energy, prismatic sphere, repulsion, righteous might, sanctuary, shield other, shield of law, spell immunity, spell resistance, stoneskin, summon monster IX, time stop.  

- ***The Great Guard (unique salient divine ability)**: Helm is adept at detecting danger to himself or his charges, as well as avoiding it. He possesses the evasion and improved uncanny dodge abilities, even when wearing heavy armor. He is impossible to surprise in combat and to sneak attacks. He cannot be knocked down or overthrown; standing firm against all explosions, forces, earthquakes, and eruptions. He also sees through all illusions.  

- ***The Unsleeping Eye (unique salient divine ability)**: Helm can unleash a 100-foot-long cone of cold by raising the visor of his helm. It inflicts 15d6 damage. He can also choose to emit a greater dispel magic or disintegrate cone of identical dimensions. The save DC for these are 42+spell level.  

- ***Ring of Shields (unique salient divine ability)**: Helm can surround himself with a ring of floating shields. These reflect back all magic, psionic, breath weapon, and gaze attacks 100% at their source if he wishes. While the ring of shields is up Helm is unable to take any offensive actions or cast any spells. If a shield is destroyed, it explodes in a 100 foot long cone of cold (20 ft diameter) that inflicts half cold and half divine damage at the being that destroyed it. The shields have a hardness of 40, armor rating of 50, 198 hp, and move at Fl 60 (perfect).  

- **Possessions**: Helm wields _Ever Watchful_, a _+10 cold iron axiomatic power holy bastard sword of ruin_. (Caster Levels: 71st; Weight: 8 lb.). The blade glows when Helm is in danger and also allows him to pull ethereal, astral, or other inaccessible enemies fully into the plane with Helm and allow them to be attacked normally. He wears +_10 heavy fortification heavy full plate_ that has seen many a battle. (Caster Level: 73rd; Weight: 40 lb.)  

**Other Divine Powers**  
- As an intermediate deity, Helm automatically recieves a die roll of 20 on any check. He treats a 1 on an attack roll or saving throw normally and not as an automatic failure. He is immortal.  
- **Senses**: Helm can see (using normal vision or darkvision), hear, touch, and smell at a distance of 11 miles. As a standard action, he can perceive anything within 11 miles of his worshippers, holy sites, objects, or any location where one of his titles or name was spoken in the last hour. He can extend his senses to up to ten locations at once. He can block the sensing power of deities of his rank or lower at up to two remote locations at once for 11 hours.  
- **Portfolio Sense**: Helm can sense any theft the instant it happens and retains the sensation for eleven tendays after the event occurs. He is likewise aware of anyone in immediate need of protection  
- **Automatic Actions**: Helm can use Listen, Spot, or Search as a free action if the DC for the task is 25 or lower. He may not use any skills that require movement. He can perform up to 10 such free actions each round.  
- **Create Magic Items**: Helm can any kind of magic item that serves a defensive purpose, as long as the item’s market price does not exceed 200,000 gp.  

* * *

A great creation of [DiceFreaks](http://community.dicefreaks.com/) and copied here for reference.
