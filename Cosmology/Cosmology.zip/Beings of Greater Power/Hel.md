---
fileType: Cosmos
cosmosName: Hel
cosmosType: Intermediate Deity
---
# Hel
_Daughter of Loki, Queen of the Wretched Dead_  
**Intermediate Deity**  
**Symbol:** A woman’s head rotting on the left side  
**Home Plane:** Helheim (Niflheim, Second Gloom of the Grey Wastes of Despair)  
**Alignment:** Neutral evil  
**Portfolio:** Dishonorable death  
**Worshipers:** Frost giants, cold-using clerics/mages  
**Cleric Alignments:** NE, CE  
**Domains:** Cold, Evil, Death  
**Favored Weapon:** “Frigid Grasp of the Grave” (unarmed strike)  

**Cleric 30/Necromancer 20/Pale Master 10**  
**Medium Outsider (evil, extraplanar)**  
**Divine Rank:** 15  
**Hit Dice:** 30d8 (cleric) plus 20d4 (necromancer) plus 10d4 (pale master) plus 780 (1140 hp)  
**Initiative:** +21 (+13 Dex, +8 Superior Initiative)  
**Speed:** 60 ft.  
**Armor Class:** 80 (+30 natural, +15 divine, +13 Dex, +12 deflection), touch 50, flat-footed 66  
**Base Attack/Grapple:** +35/+47  
**Attack:** +66 _“Frigid Grasp of the Grave”_ or melee touch +62 or ranged touch +63  
**Full Attack:** +66/+61/+56/+51 _“Frigid Grasp of the Grave”_ (1d4 plus +1d6 (wounding) plus +3d6 (cold) plus +12/20/x2 plus +6d6 (cold)) or melee touch +62 or ranged touch +63  
**Space/Reach:** 5 ft./5 ft.  
**Special Attacks:** animate dead 1/day (animate 58 HD, control 116 HD), control undead, salient divine abilities, spells, spell-like abilities, turn undead/outsiders 15/day, undead graft (paralyzing touch, weakening touch, degenerative touch, destructive touch, deathless master’s touch)  
**Special Qualities:** darkvision 60 ft., deathless mastery, deathless vigor, divine aura (1500 feet, DC 34), divine immunities, DR 25/epic and mithril, godly realm (10 miles outer plane, 1500 ft. Material Plane), greater teleport at will, plane shift at will, remote communication, resistance (acid) 19, speak, and read all languages and speak directly to all beings with 15 miles, SR 77, tough as bone, undead armor affinity, undead cohort, undead graft  
**Saves:** Fort +60 Ref +55 Will +62  
**Abilities:** Str 34 Dex 37 Con 36 Int 38 Wis 40 Cha 35  
**Skills:** Appraise +34 (+38 alchemical preparations, sculpture, ships), Bluff +57, Concentration +83, Craft (alchemy) +64, Craft (sculpting) +64, Craft (shipbuilding) +69, Decipher Script +69, Diplomacy +85 (+100 Giants), Disguise +57 (+59 observed in character), Hide +61, Intimidate +61 (+76 Giants), Knowledge (arcana) +92, Knowledge (architecture and engineering) +59, Knowledge (history) +69, Knowledge (nature) +81, Knowledge (the planes) +84, Knowledge (religion) +95, Listen +70, Move Silently +68, Profession (mortician) +70, Search +49 (+53 find hidden doors/secret compartments), Sense Motive +60, Spot +60, Spellcraft +98, Survival +43 (+45 find/follow tracks, +47 aboveground, +49 extraplanar)  
**Feats:** Corrupt Spell, Empower Spell, Energy Admixture (cold), Energy Substitution (cold), Enlarge Spell (B), Eschew Material Components, Extend Spell (B), Fell Drain, Greater Spell Focus (necromancy) (B), Heighten Spell (B), Improved Initiative, Maximize Spell, Quicken Spell (B), Scribe Scroll (B), Skill Focus (Knowledge-religion), Still Spell, Weapon Focus (unarmed strike)  
**Epic Feats:** Enhance Spell, Epic Spellcasting (B), Expeditious Metamagic, Ignore Material Components (B), Improved Heighten Spell, Improved Metamagic(x2), Multispell, Negative Energy Burst, Superior Initiative, Undead Mastery, Zone of Animation (B)  
**Environment:** Helheim (Niflheim, Second Gloom of the Grey Wastes of Despair)  
**Organization:** Hel and Cohort or Hel and Honor Guard (2-4 Corpse Frost Giant Barbarians)  
**Challenge Rating:** 56  
**Treasure:** _Adamant Ring_  
**Alignment:** Neutral Evil  
**Advancement:** --  
**Level Adjustment:** –  

**Alter Reality:**  
- Hel can use the _wish_ spell with regard to her portfolio, save for the replication of other spells. This ability costs Hel no XP, and requires a standard action to implement.  
- 15/day Hel may add +15 to her effective caster level.  
- Hel may alter her size between Tiny and Gargantuan.  
**- Divine Immunities:** Ability damage, ability drain, cold, death effects, disease, disintegration, energy drain, fire, mind-affecting effects, paralysis, poison, sleep, stunning, transmutation, imprisonment, banishment.  
**- Divine Power:** Hel is a living embodiment of power, and ancient divine magic flows through her veins. As such, mortal items are of virtually no use to her, being so much weaker than her own innate powers. Hel gains no benefit from a deflection, enhancement, resistance, insight, sacred or profane bonus that is less than +15\. Note that this only applies to bonuses that affect Hel herself; weaponry and armor is unaffected by this.  
**-Domain Powers:** Rebukes fire creatures/commands cold creatures 15/day; casts evil spells at +1 level; may make a death touch 1/day that kills beings with fewer than 30d6 hp  
**- Salient Divine Abilities:** Automatic Metamagic (energy substitution-cold), Automatic Metamagic (Quicken Spell), Automatic Metamagic (Still Spell), Divine Inspiration (dread), Divine Spellcasting, Energy Burst (15d8 points of cold damage), Energy Storm (cold, 15 points of cold damage/15 points of unholy damage, 150 ft.), Epic Weapon Focus (unarmed strike), Frigid Grasp of the Grave (Unique Salient Divine Ability), Frightful Presence (reveal rotting half of head, Will save DC 37), Hand of Death (Fort save 47), Hel’s Arm (Unique Salient Divine Ability), Lay Curse (Will save DC 37), Life Drain (150 ft. radius, 10 ft. high, Will save DC 37), Power of Nature (15 mile radius), Supreme Initiative, Undead Mastery, Whispers of the Dead (Unique Salient Divine Ability), Wound Enemy  
**- Spell-Like Abilities:** At will: animate dead, blasphemy, cause fear, chill touch, chill metal, cone of cold, control weather, create undead, create greater undead, death knell, death ward, desecrate, destruction, dispel good, magic circle against good, ice storm, obedient avalanche, polar ray, protection from good, slay living, sleet storm, summon monster IX (evil monsters only), _wail of the banshee, wall of ice, unholy aura, unholy blight._ Hel uses these abilities as a 75th level caster, except for evil spells, which she uses as a 76th-level caster. The save DCs are 48 + spell level.  

**Arm of Hel (Unique Salient Divine Ability):** Any spell that channels positive or negative energy to either inflict or cure that is cast at Hel is instead absorbed harmlessly by her necrotic left arm. For every ten points of damage absorbed by her dead arm in this manner, she may add 1 point of damage per level to any _inflict_ spell that she in turn casts within the next 12 rounds.  

**Frigid Grasp of the Grave (Unique Salient Divine Ability):** As a result, Hel may repeatedly strike with her own chill arms as if with a weapon, giving her the ability to make successive strikes although at a –5 penalty. Her unarmed strikes additionally do 3d6 points of cold damage.  

Additionally, should Hel successfully grapple a being, they take 7d6 points of cold damage each round that she is in physical contact with their body. Should a target of Hel’s be reduced to 0 hit points they must make a Fort save DC 55 or else freeze solid in place as the spell _flesh to ice_. Creatures frozen solid in this manner may only be brought back to life through the casting of _ice to flesh_ by a good-aligned deity of higher divine rank than Hel.  

**Whispers of the Unquiet Dead (Unique Salient Divine Ability):** Hel may fill an area in a 150 foot radius around her with the whispers of the dissatisfied dead, forever unable to escape from her realm. All within hearing must make a Will save DC 47 or else be driven permanently insane from the experience as the spell _insanity_. Hel may unleash the Whispers of the Unquiet Dead 15/day, and each use of her Whispers lasts for 15 rounds.  

**-Possessions:** Hel wears the _Adamant Ring_, which is believed to have been a gift to her from her father, Loki, in the intervening time after she was cast into Niflheim and before Loki himself was imprisoned by the rest of the Aesir. The _Adamant Ring_ is a white double band of adamantine formed into a complex knot, with the beginning and the end of the knot being designed in the shape of a serpent’s head devouring it’s own tail as a symbol of her brother, Jormungandr. The _Adamant Ring_ functions as a _ring of spell turning_ against all divine spells cast by clerics of the Aesir and provides her with a +15 profane bonus to all Diplomacy and Intimidate checks when dealing with Giants from her own pantheon. This bonus has been included in her statistics. The _Adamant Ring_ is a minor Artifact.  

**Other Divine Powers:**  
- As an intermediate deity, Hel may take 10 on any check, provided she needs to make a check at all. She is immortal.  
**- Senses**: Hel can see (using normal vision or low-light vision), hear, touch, and smell at a distance of 15 miles. As a standard action, she can perceive anything within 15 miles of her worshipers, holy sites, objects, or any location where one of her titles or name was spoken in the last hour. She can extend his senses to up to five locations at once. She can block the sensing power of deities of her rank or lower at up to two remote locations at once for 8 hours.  
**- Portfolio Sense**: Hel senses the death of any mortal in a manner that shall bring them to her halls of the dead 15 weeks in the past.  
**- Automatic Actions:** Hel can use any skill related to her portfolio, such as Knowledge (religion) to identify undead as a free action if the DC for the task is 25 or lower. She can perform up to ten such free actions each round.  
**- Create Magic Items:** Hel can create any kind of magic item worth less than 200,000 gp if it can be used to control or summon the dead, or can be used to spread the chill of the grave among the living.  

**Clerical Spells (0th-15th level) (Sp): Spells/day: 6/9+1/9+1/9+1/8+1/8+1/7+1/7+1/6+1/6+1/3/3/2/2/2/2** Hel casts her spells at 30th level. Saving throws against Hel’s clerical spells is DC 25 + spell level. The saving throw DC’s are Wisdom-based. Hel may cast 8 epic spells/day with a maximal Spellcraft DC of 108\. Hel may additionally rebuke undead 15/day, and command 300 HD of undead creatures. Hel’s rebuking roll is 1d20 plus +20, and her roll to dispel turning is 2d6 plus +44.  

_Typical Clerical Spells Chosen:_ 0th level: _create water, inflict minor wounds, no light(x2), read magic, mending_. 1st level: _curse water, deathwatch(x2), doom, inflict light wounds(x3), obscuring mist(x2), cause fear *_. 2nd level: _augury, inflict moderate wounds, sap strength, shatter_, extended _sorrow(x2), undetectable alignment, wave of grief(x2), death knell *_. 3rd level: _bestow curse(x2), blindness/deafness, eyes of the zombie(x4)_, extended _wither limb, wrack, animate dead *_. 4th level: _discern lies, divine power, dimensional anchor, divination_, empowered _love’s pain(x2), sending_, extended _vile lance, ice storm *_. 5th level: enlarged _consumptive field, forbidden speech_, extended _imbue with spell ability_, fell drain _inflict critical wounds(x2)_, maximized _inflict light wounds(x2)_ (mass), _true seeing, slay living *_. 6th level: _banishment, forbiddance, greater dispel magic(x2), harm_, fell drain _inflict moderate wounds_ (mass), maximized _inflict moderate wounds_, (mass), _create undead *_. 7th level: heightened _dimensional anchor_, enlarged _harm(x2), inflict serious wounds(x3)_ (mass), _wretched blight, destruction *_. 8th level: _antimagic field, dimensional lock, earthquake_, extended _energy ebb_, extended _ethereal jaunt,_ maximized _inflict serious wounds_ (mass), _polar ray *_. 9th level: enlarged _antimagic field, astral projection,_ extended _evil weather, gate_, maximized _inflict critical wounds_ (mass), _soul bind, wail of the banshee *_. 10th level: heightened _harm_, heightened _imprison soul_, 11th level: heightened _wail of the banshee_ 12th level: empowered, maximized _energy drain(x2)_. 13th level: enlarged, fell drain, maximized _inflict critical wounds(x2)_ (mass). 14th level: heightened _wail of the banshee(x2)_. 15th level: extended, heightened (to 14th level) _energy ebb_, heightened _imprison soul_. epic spells known: animus blizzard, demise unseen, epic counterspell, momento mori, servants of the void, soul scry, superb dispelling, word of death  

* Domain Spell.  

**Necromancer Spells (0th-14th level) (Sp): 4/8/8/7/7/7/7/6/6/6/3/2/2/2/2** Hel casts her Necromantic spells at 29th level. Saving throws against Hel’s Necromantic spells is DC 24 + spell level. The saving throw DC’s are Intelligence-based. Hel’s prohibited school is Enchantment, and all of Hel’s spells are cold-substituted, quickened, and stilled.  

**Typical Necromantic Spells Chosen:** 0th level: _mage hand(x2), ray of frost, touch of fatigue_. 1st level: _bestow wounds(x2), chill touch(x2), ray of enfeeblement, true strike(x2), unseen servant_. 2nd level: _mirror image, resist energy(x2), sap strength, spectral hand(x3), wither limb_. 3rd level: _clairaudience/clairvoyance, curse of the putrid husk, fireball, haste, slow, vampiric touch(x2)_. 4th level: _enervation(x2)_, fell drain _lightning bolt(x2), phantasmal killer, psychic poison, wall of ice_. 5th level: corrupted _ice storm, mirage arcana, night’s caress,_ extended _solid fog, soul shackles, telekinesis, wall of force_. 6th level: fell drain _cone of cold(x2), freezing sphere, greater dispel magic(x2)_, corrupted, energy-admixted _lightning bolt_, corrupted, enhanced _lightning bolt_. 7th level: enlarged _acid fog_, corrupted _chain lightning, energy ebb_, empowered _fireball_ (delayed blast), _project image, scrying_ (greater). 8th level: cold-admixted _chain lightning_, extended _energy ebb, evil weather_, heightened _eyebite, maze, trap the soul_. 9th level: _disjunction_, corrupted _horrid wilting, imprisonment_, empowered _polar ray, wail of the banshee, wish._ 10th level: empowered _energy drain_, enhanced _horrid wilting_, extended _time stop_. 11th