---
fileType: Cosmos
cosmosName: Tempus
cosmosType: Greater Deity
---
**Tempus**  
_Lord of Battles, Foehammer_  
**Greater Deity**  
**Symbol:** A blazing silver sword on a blood-red shield  
**Home Plane:** Warrior's Rest  
**Alignment:** Chaotic neutral  
**Portfolio:** War, battle, warriors  
**Worshipers:** Warriors, fighters, barbarians, rangers, half-orcs  
**Cleric Alignments:** CE, CG, CN  
**Domains:** Chaos, Protection, Strength, War  
**Favored Weapon:** "Battle Prowess" (battleaxe)  
  
**Tempus**  
**Fighter 30/Barbarian 10/Legendary Dreadnought 20**  
**Medium Outsider (Chaotic)**  
**Divine Rank:** 17  
**Hit Dice:** 30d10+30d12+1,020 (1,848 hp)  
**Initiative:** +11 (+7 Dex, +4 Improved Initiative)  
**Speed:** 100 ft. (12 squares)  
**Armor Class:** 90 (+1 Dex, +17 divine, +32 natural, +12 deflection, +18 armor), touch 40, flat-footed 89  
**Base Attack/Grapple:** +67/+92  
**Attack:** _Battle Prowess_ +133 melee (1d8+57 plus 3d6 chaotic and 1 negative level/18-20)  
**Full Attack:** _Battle Prowess_ +133/+133/+133/+133/+128/+123/+117 melee (1d8+57 plus 3d6 chaotic and 1 negative level/18-20)  
**Space/Reach:** 5 ft./5 ft.  
**Special Attacks:** Domain powers, rage 3/day, salient divine abilities, spell-like abilities, spells  
**Special Qualities:** Divine aura (17 miles, DC 39), divine immunities, DR 30/epic and adamantine or darkwood created on a forge on the largest wheel of Mechanus, DR 9/-, fast healing 42, godly realm (100 miles Outer Plane, 1,700 ft. Material Plane), _greater teleport_ at will, improved uncanny dodge, _plane shift_ at will, remote communication, resistance to fire 43, SR 79, trap sense +3, understand, speak, and read all languages and speak directly to all beings within 17 miles, unmovable 4/day, unstoppable 4/day  
**Saves:** Fort +68, Ref +51, Will +53  
**Abilities:** Str 60, Dex 25, Con 49, Int 25, Wis 29, Cha 34  
**Skills:** Bluff +50, Climb +93, Craft (armorsmithing) +54, Craft (weaponsmithing) +54, Diplomacy +51, Handle Animal +59, Intimidate +94, Jump +93, Listen +52, Ride +64, Search +39 Spot +57, Survival +77, Swim +77  
**Feats:** Cleave (b), Combat Brute, Combat Expertise (b), Combat Reflexes (b), Deflect Arrows, Dodge(b), Great Cleave (b), Greater Weapon Focus, Greater Weapon Specialization, Improved Initiative (b), Improved Sunder (b), Improved Unarmed Strike, Mobility (b), Mounted Combat, Power Attack (b), Ride-By Attack, Spring Attack (b), Trample, Whirlwind Attack (b)  
**Epic Feats:** Devastating Critical (b), Dire Charge, Epic Prowess, Epic Speed, Epic Sunder, Epic Weapon Focus (b), Epic Weapon Specialization (b), Fast Healing, Improved Bull Rush, Improved Whirlwind (b), Infinite Deflection, Legendary Rider, Overwhelming Critical (b), Point Blank Shot, Quick Draw, Rapid Shot, Reflect Arrows, Run, Spellcasting Harrier, Spirited Charge, Storm of Throws  
**Salient Divine Abilities:** Annihilating Strike, Area Divine Shield, Banestrike (giants), Battlesense, Clearsight 17 ft, Divine Battle Mastery, Divine Blast, Divine Fast Healing, Divine Inspiration (rage), Divine Shield, Divine Weapon Focus (all), Divine Weapon Mastery, Divine Weapon Specialization (all), Indomitable Strength, Increased Damage Reduction, Increased Energy Resistance (fire), Irresistible Blows, Know Death, Lord of Battle, Mass Divine Blast, Sunder and Disjoin, Supreme Damage Reduction, Wave of Chaos  
**Environment:** Warrior's Rest  
**Organization:** Solitary (unique)  
**Challenge Rating:** 61  
**Treasure:** _Battle Prowess_, _+10 heavy fortification negating full plate_  
**Alignment:** Chaotic neutral  
**Advancement:** --  
**Level Adjustment:** --  
  
  
- **Alter Reality:** Tempus can use the _wish_ spell with regard to his portfolio, save for the replication of other spells. This ability costs Tempus no XP, and requires a standard action to implement. Tempus adds once against his Strength modifier to his bonus to attack rolls.  
- **Divine Immunities:** Ability damage, ability drain, acid, cold, death effects, disease, disintegration, electricity, energy drain, mind-affecting effects, paralysis, poison, sleep, stunning, transmutation, imprisonment, banishment.  
- **Domain Powers:** Feat of strength 1/day (+77 enhancement bonus to Strength for one round); protective ward 1/day.  
- **Lord of Battle (unique salient divine ability):** Tempus is master of all forms of combat and weapons. He applies his weapon-based feats to all weapons.  
- **Rage:** The following changes are in effect while Tempus rages: AC 89; 1,968 hp; Atk +135 (1d8+55 plus 3d6 chaotic/18-20); SV Fort +68, Ref +51, Will +55; Str 62, Con 47. All Strength-based skills increase by +2. Tempus can use his rage 3/day, and it lasts for 20 rounds at a time.  
- **Spell-Like Abilities:** Tempus uses these abilities as a 77th-level caster, except for chaos spells, which he uses as a 78th-level caster. The save DCs are 49 + spell level - _antimagic field, animate object, Bigby's clenched fist, Bigby's crushing hand, Bigby's grasping hand, blade barrier, bull's strength, chaos hammer, cloak of chaos, dispel law, divine power, enlarge person, flame strike, magic circle against law, magic vestment, magic weapon, mind blank, power word blind, power word kill, power word stun, prismastic sphere, protection from energy, protection from law, repulsion, righteous might, sanctuary, shatter, shield other, spell immunity, spell resistance, spiritual weapon, stoneskin, summon monster IX, word of chaos_.  
- **Unmovable (Ex):** Four times per day Tempus can apply a +20 bonus to a grapple check to avoid being grabbed with the improved grab ability, a strength check to avoid a bull rush, trip attempt, or similar effect, a strength check against any effect that would move him either physically or magically, or any one saving throw. He can also use this ability to gain a saving throw any effect that would move him and does not normally give a save, he still gains a +20 bonus in any case.  
- **Unstoppable (Ex):** Four times per day Tempus can become unstoppable, he gains a +20 bonus on his Strength check to break or burst a door or item. He can also attempt to break a _wall of force_ (DC 32). He can instead apply +20 to a single attack roll.  
- **Possessions:** Tempus carries _Battle Prowess_, a _+7 anarchic blast extreme speed battleaxe_. (_Caster Level:_ 25th; _Weight:_ 7 lb). He wears _heavy fortification negating full plate +10_.  
  
**Other Divine Powers**  
- As a greater deity, Tempus automatically receives the best possible result on any die roll he makes (including attack rolls, damage, checks, and saves). He is immortal.  
- **Senses:** Tempus can see (using normal vision or low-light vision), hear, touch, and smell at a distance of seventeen miles. As a standard action, he can perceive anything within seventeen miles of his worshipers, holy sites, objects, or any location where one of her titles or name was spoken in the last hour. He can extend her senses to up to twenty locations at once. He can block the sensing power of deities of her rank or lower at up to two remote locations at once for 17 hours.  
- **Portfolio Sense:** Tempus senses any battle seventeen tendays before it happens and retains the sensation for seventeen tendays after the event occurs. He is likewise aware of any act of violence in the Realms and the death of any warrior, whether such passing occur in combat or not.  
- **Automatic Actions:** Tempus can use Craft (armorsmithing), Craft (weaponsmithing), or Intimidate as a free action if the DC for the task is 30 or lower. He can perform up to twenty such free actions each round.  
- **Create Magic Items:** Tempus can create any kind of magic item that deals damage or provides protection.