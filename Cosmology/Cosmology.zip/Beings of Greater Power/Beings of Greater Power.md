---
fileType: cosmology
---
# Beings of Greater Power


| Divine Rank | Classification of Beings |
|:---:|:---|
| **0** | Quasi-Powers  |
|**1-5** |Demipowers  |
|**6-10** |Lesser Powers  |
|**11-15** |Intermediate Powers  |
|  **16-20** |Greater Powers   |
|  **21-25** |Elder Ones (includes Elder Gods such as Ao)   |
|  **26-30** |Old Ones (includes entities such as the Overlord of Hell)   |
|  **31-35** |First Ones (includes entities such as the Circle of Law)   |
|  **36-40** |The Primordium (the proto-cosmos)   |
|  **41-45** |The Others (the Xural)   |
|  **46-50** |The Alpha-Omega (previous casters of The Godspell, current casters of The Godspell, and the Singularity from whence all came)|
{style="td:nth-child(1): 250px"}

## Deities
```dataview
table without id file.link as "Name", cosmosType as "Type"
where fileType="Cosmos"
and contains(cosmosType, "Deity") = true
sort cosmosType
```

## Demons
```dataview
table without id file.link as "Name", cosmosType as "Type"
where fileType="Cosmos"
and contains(cosmosType, "Demon") = true
sort cosmosType
```


## Devils
```dataview
table without id file.link as "Name", cosmosType as "Type"
where fileType="Cosmos"
and contains(cosmosType, "Devil") = true
sort cosmosType
```



## Other
```dataview
table without id file.link as "Name", cosmosType as "Type"
where fileType="Cosmos"
and contains(cosmosType, "Demon") = false 
and contains(cosmosType, "Deity") = false 
and contains(cosmosType, "Devil") = false 
sort cosmosType
```