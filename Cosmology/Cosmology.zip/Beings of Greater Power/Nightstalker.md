---
fileType: Cosmos
cosmosName: Nightstalker
cosmosType: Extraplaner
---
# Nightcrawler (CR 22)  
**CE Medium Outsider [Chaotic, Evil, Extraplanar]**  
**Init** +16; **Senses** Listen ++33, Spot +33, darkvision 60ft  
**Aura** chaotic evil; **Languages** common, abyssal, infernal, diabolical,  

**AC** 37, touch 22, flat-footed 35 (10 +12 (dex), +15 (natural) )  
**hp** 220 (24d8 +120), fast heal 10 ; **DR** 20/+2  
**Immune** electricity and poison  
**Resist** acid 20, cold 20, fire 20; **SR** 30 (original SR + CR increase)  
**Fort** +19, **Ref** +26, **Will** +17  

**Speed** 30ft. (6 squares), fly 60ft good (12 squares)  
**Melee** +37/+31/+27/+21/+37/+31/+27/+21 (+1 wounding returning dagger (1d4 +5 +1 Con + poison 19-20/x2))  
**Ranged** +37/+37 (+1 wounding returning dagger (1d4 +5 +1 Con + poison 19-20/x2))  
**Space** 5ft.; **Reach** 5ft.  
**Base Atk** +24; **Grp** +29  
**Atk Options** sneak attack +8d6, poison (Fort DC 27, 1d6 Con injury, secondary 1d6 con), sudden strike +9d6, spell-like abilities  
**Special Actions** telepathy 100ft, evasion, uncanny dodge, blink, dimension door, poison, spell-like abilities  

**Spell-like Abilities** (CL 18th) At will: _fiendish quickening, true seeing, planeshift, scrying, cursed blade, nondetection, anticipate teleportation, bands of steel, wracking touch, deeper darkness, desecrate, detect good, detect law, greater dispelling, improved invisibility (self only), read magic, suggestion, teleport without error (self with 50 pounds of objects only), tongues (self only), unhallow_ 1/day: _superior invisibility_  

**Abilities** Str 21, Dex 34, Con 20, Int 17, Wis 16, Cha 16  
**SQ** darkvision 60ft, telepathy 100ft, evasion, uncanny dodge, sneak attack +8d6, sudden strike +9d6, spell-like abilities.  
**Feats** two weapon fighting, improved two weapon fighting, improved initiative, weapon finesse (dagger), greater two weapon fighting, quick draw, spectral skirmisher, combat reflexes  
**Epic Feats** perfect two weapon fighting  
**Skills** Bluff +23, Disable Device +27, Diplomacy +23, Hide +40, Intimidate +23, Knowledge (local) +23, Listen +33, Move Silently +40, Search +23, Sense Motive +23, Spot +33, Tumble +23.  
**Possessions** _+1 returning dagger of wounding x3_, 20,000 in assorted gems.  

**Organization** Nightcrawlers  
**Environment** Abyss, Any  
**Advancement** By character class or HD  

**Warp – Blink (Su):** Nightstalker can use _blink_ as the spell (caster level 8th), and can evoke or end the effect as a free action. He loses his Enhanced Detection (Su) ability.  

**Warp – Dimension Door (du);** Nightstalker can teleport, as _dimension door_ (caster level 8th), once per round as a free action. The ability affects only Nightstalker, which never appears within a solid object and can act immediately after teleporting. He loses his _Summon Tana’ri_ (Sp) ability.  

**Ravage – Constitution Boost (Ex/Abhorrent):** Nightstalker gains +4 increase to her Constitution score.  

**Ravage – Fast Healing (Ex/Abhorrent):** Nightstalker gains fast healing 30.  

**Ravage – Spell-like Abilities (Sp/Abhorrent):** Nightstalker has the following spell-like abilities after taking this ravage three times: At will: _fiendish quickening, true seeing, planeshift, scrying, cursed blade, nondetection, anticipate teleportation, bands of steel, wracking touch._ 1/day: _superior invisibility_  

**Ravage – Class Feature (Ex/Abhorrent):** Nightstalker has the sudden strike ability equivalent of a level 18th Ninja. +9d6.  

* * *

A great creation of [DiceFreaks](http://community.dicefreaks.com/) and copied here for reference.


**Appearance:**  
The size and frame of this creature fully resembles a kelvezu, but its skin colour is a midnight blue rather than the reddish hue that normal kelvezus have. They disappear suddenly, as if blinking away from view, and leaves nothing behind but a faint tang of brimstone and sulphur.  

**History:**  
The search for the perfect assassin never ends, and in the Abyss, even the feared Kelvezu is not enough to serve the needs true assassination. Ordered by an unknown power, a demon well-versed in transmutation and genetics requested for a group of kelvezu for experimentation, and a consignment of the interesting blink dogs to be delivered to his little laboratory.  

Breeding a crossbreed of kelvezu and blink dog together was never the intention, but merely to procure the specific parts of the blink dog to apply it into a kelvezu and a direct infusion of Abyssal magic to make it natural, the demon succeeded, and was the first victim to the most successful result of that little experiment.  

Freeing his brethren, they escaped to a planar metropolis to hide themselves, and got down to finding out what happened to them when they lie low enough. Mortified by the changes in them, yet somewhat pleased with what happened, the strongest of the kelvezu, took the name Nightstalker for his own, and the small group named themselves the Nightcrawlers, set out to eke an existence in that planar metropolis by being assassins for hire.  

**Nature:**  
As the product of artificial and mystical evolution, Nightstalker is still very much a kelvezu at heart. As time goes by, his fellowship has earned some degree of fear and notoriety amongst the circles of their profession. Despite these achievements, they are still aware that whoever ordered their creation might still be looking for them, and they are also curious as to which power in the Abyss would need their services, hence the attempt to balance caution and curiosity constantly.  

Yet despite their demonic nature, the possibly unintended mingling of a blink dog’s loyal nature into the psyche of the nightcrawlers has turned them to a very cohesive and rather tight knit group, to mess with one would be to deal with the rest.  

**Organisation:**  
The Nightcrawlers are a tight knit group despite their demonic nature, their shared experience and unique identity carries a sense of bonding that overrides their demonic nature, yet to assume that they are less than true demons would be a fatal mistake, the pack mentality that they subconsciously share is a valuable trait. They are targeted for permanent employment by some organizations and the infamous Garotte has been observed to make some moves against this group.  

**Relations to other Powers:**  
The nightcrawlers have no relations to other powers.  