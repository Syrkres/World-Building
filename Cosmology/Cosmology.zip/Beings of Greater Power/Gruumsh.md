---
fileType: Cosmos
cosmosName: Gruumsh
cosmosType: Greater Deity
---
# Gruumsh
_He Who Never Sleeps, the One-Eyed God, He Who Watches_  
**Greater Orc Deity**  
**Symbol:** Empty eyesocket or unblinking eye  
**Home Plane:** Nishrek, Archeron  
**Alignment:** Chaotic evil  
**Portfolio:** Orcs, conquest, survival, strength, territory, war  
**Worshipers:** Fighters, half-orcs, orcs  
**Cleric Alignments:** CE, CN, NE  
**Domains:** Cavern, Chaos, Domination, Evil, Hatred, Orc, Strength, War  
**Favored Weapon:** "The Bloodspear" [longspear] (longspear or shortspear)  

GRUUMSH  
Barbarian 35, Fighter 30  
Medium Outsider (Chaotic, Evil)  
**Divine Rank:** 19  
**Hit Dice:** 35d12+765 (Brb) plus 30d10+630 (Ftr) (2115 hp)  
**Initiative:** +11 (+7 Dex, +4 Improved Initiative)  
**Speed:** 40 ft. (8 squares) (full plate armor, base speed 70 ft.)  
**Armor Class:** 94 (+1 Dex, +19 divine, +34 natural, +12 deflection, +18 armor), touch 42, flat-footed 93  
**Base Att/Grapple:** +43/+111  
**Attack:** _Bloodspear_ +127 melee touch (1d8+71/19-20/x3); or _Everburning Torch_ +86 melee (3d6 fire plus nausea); or spell +86 melee touch or +69 ranged touch. *Always receives a 20 on attack rolls; roll die to check for critical hit.  
**Full Attack:** _Bloodspear_ +127/+122/+117/+112 melee touch (1d8+71/19-20/x3); or _Bloodspear_ +123/+118/+113/+108 melee touch (1d8+59/19-20/x3) and _Everburning Torch_ +78 melee (3d6 fire plus nausea); or by spell. *Always does maximum damage (longspear 79 points, or longspear 67 points and torch 18 points).  
**Space/Reach:** 5 ft./5 ft. (10 ft. with longspear)  
**Special Attacks:** Domain powers, salient divine abilities, spell-like abilities.  
**Special Qualities:** Orc traits, divine aura (19 miles, DC 41), divine immunities, DR 35/epic and mithral and slashing (9/--), fast movement, fire immunity, godly realm, _greater teleport_ at will, indomitable will, _plane shift_ at will, remote communication, trap sense +11, uncanny dodge (cannot be flanked), understand, speak, and read all languages and speak directly to all beings within 19 miles, SR 83.  
**Saves:** Fort +80, Ref +58, Will +61\. *Always receives a 20 on saves.  
**Abilities:** Str 58, Dex 25, Con 53, Int 23, Wis 30, Cha 35.  
**Skills:** Appraise +25 (+29 armors, +27 metal, +27 stone, +29 weapons), Bluff +41, Concentration +50, Climb +83, Craft (armorsmithing) +55, Craft (metalworking) +40, Craft (stoneworking) +40, Craft (weaponsmithing) +55, Diplomacy +35, Disguise +31 (+35 acting), Intimidate +88, Jump +83, Knowledge (arcana) +35, Knowledge (history) +30, Knowledge (religion) +30, Listen +76, Ride +21, Search +55, Sense Motive +44, Spellcraft +37, Spot +61, Survival +74, Swim +78\. *Always receives a 20 on checks.  
**Feats:** Alertness, Blind-Fight, Cleave, Combat Reflexes, Craft Magic Arms and Armor, Dodge, Endurance, Expertise, Great Cleave, Great Fortitude, Improved Bull Rush, Improved Combat Expertise, Improved Critical (longspear), Improved Disarm, Improved Initiative, Improved Overrun, Improved Sunder, Improved Trip, Mobility, Power Attack, Power Critical (longspear), Quick Draw, Run, Spring Attack, Track, Weapon Focus (longspear), Weapon Specialization (longspear), Whirlwind Attack.  
**Epic Feats:** Craft Epic Magic Arms and Armor, Devastating Critical (longspear), Dire Charge, Epic Fortitude, Epic Reflexes, Epic Toughness, Epic Weapon Focus (longspear), Epic Weapon Specialization (longspear), Epic Will, Incite Rage, Overwhelming Critical (longspear), Spellcasting Harrier, Terrifying Rage, Thundering Rage.  
**Environment:** Archeron  
**Organization:** Unique  
**Challenge Rating:** 65  
**Treasure:** _Bloodspear_, _Black Plate of Gruumsh_, _Everwatchful Torch_  
**Alignment:** Chaotic evil  
**Advancement:** --  
**Level Adjustment:** --  

- **Orc Traits:** Darkvision, -1 penalty on attack rolls in bright light.  
- **Divine Immunities:** Ability damage, ability drain, acid, cold, death effects, disease, disintegration, electricity, energy drain, mind-affecting effects, paralysis, poison, sleep, stunning, transmutation, imprisonment, banishment.  
- **Divine Power:** Gruumsh is a living embodiment of power, and ancient divine magics flow through his veins. As such, mortal items are of virtually no use to him, being so much weaker than his own innate powers. Gruumsh gains no benefit from a deflection, enhancement, resistance, insight, sacred or profane bonus that is less than +19\. Note that this only applies to bonuses that affect Gruumsh himself; weaponry and armor is unaffected by this.  
- **Salient Divine Abilities:** Alter Form, Annihilating Strike (DC 53, or destroy up to 19,000 cubic feet of nonliving matter), Banestrike (dwarves), Banestrike (elves), Battlesense, Control Creatures (orcs), Divine Battle Mastery, Divine Blast (12/day, 372 damage), Divine Rage (19/day), Divine Shield (24/day, 190 points), Divine Weapon Focus (longspear), Divine Weapon Specialization (longspear), Extra Domain (Cavern), Extra Domain (Domination), Extra Domain (Hatred), Extra Energy Immunity (fire), Frightful Prescence (DC 41), Hand of Death, Increased Damage Reduction, Indomitable Strength, Irresistable Blows (longspear), Mass Divine Blast, Overlord, Wound Enemy.  
- **Alter Reality:** Gruumsh can use the _wish_ spell with regard to his portfolio, save for the replication of other spells. This ability costs Gruumsh no XP, and requires a standard action to implement. Gruumsh adds once again his Strength modifier to modify his attack rolls with weapons. As a free action 19/day, for one round at a time, Gruumsh may add +12 to all damage rolls.  
- **Domain Powers:** Cast chaos spells at +1 caster level; cast evil spells at +1 caster level; feat of strength 1/day (gain a +19 enhancement bonus to Strength for one round); stonecunning; 1/day as a free action, gain +2 on attack rolls, saving throws, and Armor Class against a selected opponent for 1 minute; smite 1/day (+19 damage, +4 to attack roll if the target is a dwarf or elf).  
- **Spell-Like Abilities:** Gruumsh uses these abilities as a 84th-level caster, except for chaos spells and evil spells, which he uses as a 85th-level caster. The save DCs are 51 + spell level. _animate objects, antipathy, bestow curse, Bigby's clenched fist, Bigby's crushing hand, Bigby's grasping hand, blade barrier, blasphemy, bull's strength, cause fear, chaos hammer, cloak of chaos, command, create undead, darkness, desecrate, detect secret doors, dispel good, dispel law, divine power, dominate person, doom, earthquake, enlarge person, enthrall, eyebite, find the path, flame strike, forbiddance, geas/quest, greater command, imprisonment, Leomund's secure shelter, magic circle against good, magic circle against law, magic vestment, magic weapon, mass suggestion, maw of stone, meld into stone, monstrous thrall, passwall, power word blind, power word kill, power word stun, prayer, produce flame, protection from good, protection from law, prying eyes, righteous might, scare, shatter, song of discord, spell immunity, spiritual weapon, suggestion, summon monster IX_ (as chaos or evil spell only), _stoneskin, true domination, unholy aura, unholy blight, wail of the banshee, word of chaos_.  
- **Divine Rage:** The following changes are in effect as long as Gruumsh rages: HP 2440; AC 89; Atk _Bloodspear_ +132/+132/+127/+122/+117 melee touch (1d8+78/19-20/x3); or _Bloodspear_ +128/+128/+123/+118/+113 melee touch (1d8+64/19-20/x3) and _Everburning Torch_ +83 melee (3d6 fire plus nausea); SR 93; SV Fort +85, Will +66; Str 68, Con 63; Climb +88, Jump +88, Swim +83\. Gruumsh may enter this rage after being struck by a weapon 19/day, and for up to an hour at a time.  
- ***Fog of War (unique salient divine ability):** As a free action, Gruumsh can generate a cloud of acrid black smoke that rises from his body in a 30 ft. spread, 10 feet high. Its effects are otherwise similiar to a _cloudkill_ spell. The save DC against this effect is 56.  
- **Possessions:** Gruumsh carries _Bloodspear_, a _+10 cold iron chaotic power unholy power spear_ that deals damage as a longspear. _Bloodspear_ can assume any size from halfspear to longspear or more. This increases Gruumsh's reach by 5 feet in his Medium form, and a culmulative 5 feet for every size category he takes above that (for example, in Medium form Gruumsh has a reach of 10 feet; in Colossal form, Gruumsh has a reach of 50 feet). Because of _Bloodspear_'s variable length, Gruumsh can attack foes that are adjacent to him, and use it in one hand without penalty if he wishes to. Any creature struck by _Bloodspear_ must make a Fortitude save (DC 66) or be paralyzed for 2d4 rounds. This can even affect creatures that are normally immune to paralysis, provided they are of lower divine rank than Gruumsh. (_Caster Level_: 65th; _Weight_ 9 lb.) Gruumsh wears the _Black Plate of Gruumsh_, a suit of _+10 moderate fortification spiked full plate_ that imposes a -4 morale penalty to all saving throws upon all enemies within 100 feet (_Caster Level_: 65th; _Weight_ 50 lb.) He occassionally carries the _Everwatchful Torch_ as well, the flame of which cannot be extinguished. The light of the torch can be seen as far away as 19 miles if Gruumsh wills it, and it grants a +2 morale bonus on all attack rolls and damage rolls made by all other orcs who can see it. Each round, any creature within 20 ft. of the torch must make a Fortitude save (DC 54) or become nauseated for 1 round by the acrid smoke it produces. As a free action, Gruumsh can use the torch to generate a cloud of acrid black smoke that rises from the torch in a 30 ft. spread, 10 feet high. Its effects are otherwise similiar to a _cloudkill_ spell. The save DC against this effect is 56\. Those struck directly by the torch take 3d6 points of fire damage, and must save against the nausea effect (this time lasting 1d4 rounds) with a -4 circumstance penalty. (_Caster Level_: 65th; _Weight_ 5 lb.)  

**Other Divine Powers**  
- As a greater deity, Gruumsh automatically receives the best possible result on any die roll he makes (including attack rolls, damage, checks, and saves). He is immortal.  
- **Senses:** Gruumsh can see (using normal vision or darkvision), hear, touch, and smell at a distance of nineteen miles. As a standard action, he can perceive anything within nineteen miles of his worshipers, holy sites, objects, or any location where one of his titles or name was spoken in the last hour. He can extend his senses to up to twenty locations at once. He can block the sensing power of deities of his rank or lower at up to two remote locations at once for 19 hours.  
- **Portfolio Sense:** Gruumsh senses anything that affects orc welfare ninteen weeks before it happens and retains the sensation for ninteen weeks after the event occurs. He is similarly aware whenever orcs engage in combat, make war, or gain or lose territory.  
- **Automatic Actions:** Gruumsh can use Craft (armorsmithing), Craft (metalworking), Craft (stoneworking), or Craft (weaponsmithing) as a free action if the DC for the task is 30 or lower. He also can break an object as a free action if its break DC is 30 or lower. He can perform up to twenty such free actions each round.  
- **Create Magic Items:** Gruumsh can create any types of magic weapons and armor.  

**Avatars**  
- Gruumsh's avatars are always hulking male orcs clad in black full plate armor. Sometimes they have a single unblinking central eye, and sometimes they have an empty left eye socket. Gruumsh usually doesn't dispatch his avatars anywhere unless he suspects machinations against the orcs by Corellon Larethian or another meddling deity.  

* * *

A great creation of [DiceFreaks](http://community.dicefreaks.com/) and copied here for reference.


_In the beginning all the gods met and drew lots for the parts of the world in which their representative races would dwell. The human gods drew the lot that allowed humans to dwell where they pleased, in any environment. The elven gods drew the green forests, the dwarven deities drew the high mountains, the gnomish gods the rocky, sunlit hills, and the halfling gods picked the lot that gave them the fields and meadows. Then the assembled gods turned to the orcish gods and laughed loud and long. "All the lots are taken!" they said tauntingly. "Where will your people dwell, One-Eye? There is no place left!"_  

_There was silence upon the world then, as Gruumsh One-Eye lifted his great iron spear and stretched it over the world. The shaft blotted the sun over a great part of the lands as he spoke: "No! You lie! You have rigged the drawing of the lots, hoping to cheat me and my followers. But One-Eye never sleeps; One-Eye sees all. There is a place for orcs to dwell . . . here!", he bellowed, and his spear pierced the mountains, opening mighty rifts and chasms. "And here!", and the spearhead split the hills and made them shake and covered them in dust. "And here!", and the black spear gouged the meadows and made them bare._  

_"There!" roared He-Who-Watches triumphantly, and his voice carried to the ends of the world. "There is where the orcs shall dwell! There they will survive, and multiply, and grow stronger, and a day will come when they cover the world, and they will slay all of your collective peoples! Orcs shall inherit the world you sought to cheat me of!"_  