---
fileType: Cosmos
cosmosName: Aspernor-dius
cosmosType: Demon Atrocity
---
# Aspernor-dius CR 30  
**Demon Atrocity**  
**Outsider 30 / Defiant 10****  
_CE Gargantuan Outsider (chaos, evil, extraplanar)_  
**Init** +6 (+2 Dex, +4 Improved Initiative) ; **Senses** darkvision 60ft., Listen +58, Spot +58, _true seeing_  
**Aura** Divine Interference  
**Languages** All known languages  
____________________________________________________________  
**AC** 52, touch 17, flat-footed 50 (-4 size, +5 def, +2 dex, +35 natural, +4 profane)  
**hp** 598 (40d8 + 640 - 222), regeneration (5/Epic and Axiomatic); **DR** 20/epic, good and cold iron  
**Immune** ability drain, death effects, electricity, poison  
**Resist** acid 25, cold 25, fire 25.; **SR** 39 (55 against divine spells) (CR +8)  
**Fort** +38, **Ref** +24, **Will** +31 (+9 to saving throws against divine spells)  
__________________________________________________________  
**Speed** 60 ft., Fly 90 ft. (good)  
**Melee** _Blasphemy_ melee +55/+50/+45/+40 (4d8+27/x3 + _geas_) and 2 pincers +50 melee (4d8+18) and bite +47 melee (2d6+9 + drain of the divine) and gore +47 (2d6+9)  
**Space** 20 ft.; **Reach** 20 ft.  
**Base Atk** +35 ; **Grp** +65  
**Atk Options** cleave, improved grab, spell-like abilities, summon demon, power attack  
**Special Actions** aligned Touch, alternate form, corrupted wish, divine cancellation, divine prevention, improved combat expertise, renounce faith.  
**Spell-like Abilities** (CL 30th)  
At will — _chaos hammer_ (DC 23), _confusion_ (DC 23), _fireball_ (DC 22), _greater dispel magic_, _greater invisibility_, _haste_, _magic circle against good_, _mirror image_, _misdirection_, _reverse gravity_ (DC 26), _greater teleport_ (self plus 50 pounds of objects only), _plane shift_, _unholy blight_ (DC 23)  
3/day— _mass hold monster_ (DC 28), _maximized meteor swarm_ (DC 28), _mindrape_* (DC 28), _power word stun_.  
_____________________________________________________________  
**Abilities** Str 46, Dex 15, Con 42, Int 24, Wis 24, Cha 29  
**SQ** Divine Damage Immunity, Divine Disavowal, Divine Interference, Divine Resistance, Divine Retribution, telepathy 100ft.  
**Feats** Cleave, Combat Expertise, Combat Reflexes, Improved Combat Expertise, Improved Initiative, Improved Natural, Attack (Pincer), Multiattack, Persuasive, Power Attack, Quicken Spell-like Ability (_power word, stun_), Weapon Focus (Pincer)  
**Epic Feats** Epic Reputation, Epic Skill Focus (bluff), Polygot, Spellcasting Harrier  
**Skills** Bluff +68, Concentration +46, Diplomacy +18, Disguise +52 (+56 acting), Gather Information +43, Intimidate +29, Knowledge (arcana) +40, Knowledge (history) +17, Knowledge (nature) +17, Knowledge (the planes) +50, Knowledge (religion) +50, Listen +58, Search +36, Sense Motive +50, Spellcraft +44, Spot +58  
**Possessions** _Blasphemy_  
_____________________________________________________________  
**_Blasphemy:_** Blasphemy is an 25ft long greataxe and the blade that is fastened to the hilt is completely black and has several arcane runes inscribed on it. The hilt itself is made out of the same dark material as the blade, however it is covered by the skin of dead worshippers and feels warm if you would hold it.  
Blasphemy is a _+6 gargantuan defending adamantine greataxe_. If a critical hit is made with this weapon, the subject is targeted by a _intensified Geas_ spell. Everyday from now on the subject is unable to pray for spells from its god and only a cleric with at least 31 levels can break the _geas_ Even creatures normally immune to critical hits are subjected to this effect, but a person who are immune to mind-affecting effects are not subjected to this spell. Also if the greataxe is carried by a creature with Defiant levels they receive a +5 deflection bonus to their AC.  
If a person touches or tries to use Blasphemy without Aspernor-dius approval, the person in question will feel a strong hatred towards all divine users and normal worshippers. The person needs to make an Will DC 25 and every hour thereafter with a +1 for each hour that has passed, if they fail their save they will try and kill every god worshipping person in their prescence. If no person are to be found in the near vicinity, the holder of this weapon will seek out a god lover and kill it to satisfy their bloodlust. Also a good-aligned creature takes three-negative level holding Blasphemy  

**Aligned Strike (Su):** Aspernor-dius can with a touch, align a weapon or natural weapons so that it is treated as of a specific alignment for the purpose of overcoming damage reduction. Aspernor-dius can choose any alignment (chaotic, evil, good or lawful), even if that alignment opposes his own. He may not use this ability on any weapon that already has an alignment. He can use this ability twice per day. The aligned strike lasts ten minutes.  

**Divine Cancellation:** Aspernor-dius has learned how to counterspell divine spells without casting a spell. He must ready an action to counterspell (as normal), but need not identify the spell with Spellcraft. Treat this ability as if Aspernor-dius were using _dispel magic_ to counter the spell, at a caster level of 40\. Aspernor-dius can use this ability ten times a day.  

**Divine Damage Immunity (Su):** Aspernor-dius is immune to damage from divine power, such as dealt by a _flame strike_ spell. He is also immune to holy damage, such as that dealt by a weapon with the holy special ability. Holy weapons still bypass his damage reduction - only the holy damage itself is ignored.  

**Divine Disavowal (Su):** Aspernor-dius receives spell resistance 55 against divine spells. Aspernor-dius cannot voluntarily lower this spell resistance  

**Divine Interference (Su):** Aspernor-dius spurn divine beings so much that he generates a field that interferes with all divine spellcasting. Any spellcaster within 30 ft of Aspernor-dius must succeed on a Concentration check DC 25 + spell level in order to successfully cast a divine spell. If the check fails, the spell fails and is lost. Aspernor-dius cannot choose to suppress this ability.  

**Divine Prevention (Su):** Once per day, Aspernor-dius can use a standard action to bestow a temporary spell resistance 55 upon a single target. The spell resistance affects only the next divine spell targeted at the subject, even a beneficial spell such as _bless_ or _cure light wounds_. If the target has not used the spell resistance within 24 hours, it fades. Aspernor-dius must make a successful touch attack if the target is unwilling.  

**Divine Resistance (Ex):** Aspernor-dius adds +9 to his saving throws against divine spells  

**Divine Retribution (Su):** If Aspernor-dius successfully counters a divine spell, the defiant may cause the spell to rebound at the original caster instead of causing it to fail. This ability can be used only against divine spells that target Aspernor-dius.



_The strange man had talked with voice and reasoning beyond anything I ever had heard before, any argument that Torm indeed was a righteous god, was countered by something so persuasive that I couldn’t resistagreeing with him. In my whole life I have worshipped divine Torm without any question; his goodness and protection have sheltered me from any harm. I have saved children from the hands of monsters; evil dragons have fallen before my sword and the king himself have praised me for my courage. But no longer do I sit under Lord Torms divine hand; now I have seen the true nature of this human that imposes himself as a god. I’ve done unspeakable things the recent five hours and I’m glad I did it. My own crusade against the church has only begun and the fire rages in my heart, nothing will stop me from achieving revenge._  

Chris Telor, Fallen Paladin of Torm  

**Appearance:**  
Aspernor-dius is a gargantuan glabrezu, the demon corruptors of the Abyss. He is exceptionally tall with his 50 feet in height; colossal pincers can be seen at the end of his huge muscled arms. From his back sprouts two gargantuan wings, when he spreads them out before you it looks like a solar eclipse. His face is something that could be mistaken from a gnolls except that his fangs are both longer and sharper; he has two giant horns upon his head and his eyes blazes with a dark red glow.  
Upon first seeing him, you think that he has huge armor plates covering his shoulders. However upon a closer look you see that they are instead his bone that protects him from normal weapons. In his smaller hands can a truly fearsome weapon be seen, a gargantuan greataxe made from the nigh-indestructible metal known as adamantine.  

**History:**  
Where does is all start then, the corrupter couldn’t possible have been in existence as one of the very first demons could he? Well the answer is no, once he was an ordinary glabrezu among millions of others. However what set him apart from the rest of the glabrezus was that he possessed a somewhat sharper mind and a keen ability to corrupt the heart of mortals. In the beginning he started out in primes where the time was still young and many races hadn’t advanced far in civilization, it didn’t bring him much power from corrupting these souls as he couldn’t take on so many at a time. Over the centuries he grew stronger and his taint started to spread out to the more populous prime material planes and there he could corrupt smaller religions, at that point he was starting to make a name for himself in the abyss.  
His so far complete success in corrupting the weak-minded mortals made him so powerful that he could nearly rival balors in pure might; Aspernor-dius understood that his transformation was at hand and became obsessed with the last souls he needed to ascend him into the most mighty and strong race of the tanar’ri, the flaming balor. He grew too confident this time and tried to corrupt a whole church full of faithful clerics and paladins; his success was almost complete when the high priestess in prolonged battle managed to banish him back into the Abyss. After this failure the seed of hatred against the power which clerics true to their gods had on him.  
A full century went by before he could access the mortal planes once again, during those years he bid his time and even though he never evolved into a balor due to his inner self feeling unworthy, he had become their equal in everything, his prowess in combat even surpassed them on many levels. At the point in time when he was finally able to freely walk the primes again he had established contact with a fallen planetar called Carreau, this was indeed the same Carreau that would later become the duke of apostasy. They two didn’t trust each other for a bit, but they recognised the value of working together for a common goal, which in this case was bringing down an upstart demigod. For fifty years they worked together, starting out small to corrupt the lower priests and working their way up. In the end the whole religion was in doubt towards their divine patron and no prayers were performed, no rituals for his glory and in the end he was forgotten. This was greatest work of Aspernor-dius in his life and it made him come in contact with the non-believing Athars, he stepped into their organization but under another name. From then he has learned that if you believe strongly enough that the gods power actually can’t affect you, they won’t. His current goal is to weaken a demigods power to the point where he can actually kill him and show everyone that the gods aren’t all powerful, that they bleed like everyone else.  

**Nature:**  
Aspernor-dius nature doesn’t differ much from an ordinary glabrezu, except his strong contempt against beings who worships gods and the gods themselves. He does all in his power to corrupt the worshippers into understanding that the gods are not omnipotent and only uses mortal beings to further their own ends. Normally he turns into the same race as his next victim are, and he twist words and tell lies about how wrong they are by worshipping gods. With the vile and twisted words inside their heads, they often want to have revenge upon their god and do everything in their power to work against the special god in question.  
If Aspernor-dius fails to convince a worshipping mortal about the true agenda of the gods then he will kill it and drag it down into the abyss. However Aspernor-dius isn’t only after the god worshippers, his very nature makes him wanting to corrupt the whole mortal coil. But he takes the greatest pleasure in ruining the lives of clerics and paladins.  

**Organization:**  
Even though Aspernor-dius doesn’t like to rely upon underlings he still has his connections with the Athar organization. Of course none or very few Athar knows about Aspernor-dius true nature and if he wants something accomplished that he can’t do by his own, he will call in other Athars to further his own agenda which in most cases overlaps with the Athars.  

**Relations to other Powers:**  
Aspernor-dius relations to any deity are at best neutral and at worst an all open war against the relatively weaker deities which more than often includes quasi- and demigods. The Corrupter of The Divine is very careful when it comes to spending time in places where he might stumble upon a lesser or greater gods, as he most probably would be destroyed on the spot. However most of the higher ranking gods doesn’t bother with Aspernor-dius as he isn’t a threat to the power stations, but once in every century when Aspernor-dius is able to turn a truly favoured servant of some greater gods, a proxy always comes after him. However so far none have been able to defeat him and he continues spreading poison in the faithful hearts.  

Among the cosmic power, he has no true archenemy. As one might assume, is that as an abyssal demon, all the good forces in the universe seeks to eradicate his existence for good. In the abyss everyone is at constant war, so in there he won’t find anything else than more enemies. He has a “kindred” soul in Carreau, a duke of Hell. Even though their agendas are very similar they don’t come to terms very often due to their evil nature, the fallen planetars old view against horrors from the abyss and that Carreau now holds dukehood in Hell.  
