# Fraz Urb 'Luu, Demirge, Demon Price of Illusion
Demiurge of Deception, Demon Prince of Illusion  
Huge Outsider (_Abomination, Chaotic, Evil, Extraplanar_)  
Symbol: Nothing  

Hit Dice: 40d8 (outsider) plus 26d4 (shaper) plus 26d4 (wizard) plus 1104 (1632 hp)  
**Initiative:** +17 (+9 Dex, +8 Superior Initiative)  
**Speed:** 110 ft., fly 220 ft. (perfect)  
**AC:** 78 (-2 size, +9 Dex, +37 natural, +9 profane, +15 deflection), touch 41, flat-footed 69  
**Base Attack:** +66/+90  
**Attacks:** fists +83/+83 and bite +81 and 2 wings +81 and tail slam +81 or +93 _Rod of Fraz ‘Urb Luu_ or +83 melee touch +74 ranged touch  
**Full Attack:** fists +83/+83 (8d6 plus +18 plus 1 (vile) plus Will save DC 71 or 1d6 Wis) and bite +81 (6d8 plus +9 plus +1 (vile)) and 2 wings +81 (3d6 plus +9 plus +1 (vile)) and tail slam +81 (6d8 plus +9 plus +1 (vile)) or +83 melee touch or +74 ranged touch or _Rod of Fraz ‘Urb Luu_, a +8 disjunctive, chaotic power, unholy power gargantuan mithril quarterstaff +91/+86/+81/+76 (2d6 plus +26 plus 3d6 (chaotic) plus 3d6 (unholy) plus 1 negative level/19-20/x2 plus 6d6 (chaotic) plus 6d6 (unholy) plus 2 negative levels)*  
**Face/Reach:** 15 ft/15 ft.  
**Special Attacks:** Abyssal Vehemence, Battle of Wits, Call Demons, Call Antitheses, Deceptive Disappearance, Entropic Wave, Existential Crisis, psionics, Ravaged Forms (Constricting Tail, Lucidity Damage, Window Into The Twisted Soul), spell-like abilities, spells, Ultimate Ventriloquist  
**Special Qualities:** Cosmic Corruption, Decadent Divinity, Demiurge qualities, Demon God, Prince of Illusions, Ravaged Forms, SR 70  
**Saves:** Fort +60, Ref +57, Will +59  
**Abilities:** Str 46, Dex 28, Con 34, Int 38, Wis 32, Cha 40  
**Skills:** Bluff +95, Concentration +95, Craft (jeweler, weaponsmithing) +50, Decipher Script +95, Diplomacy +50, Disguise +50, Forgery +46, Gather Information +52, Intimidate +50, Knowledge (architecture and engineering) +50, Knowledge (local-Abyssal planes) +60, Knowledge (psionics) +95, Knowledge (spellcraft) +95, Knowledge (the planes) +95, Listen +46, Perform (riddle) +46, Profession (puzzlemaking) +70, Psicraft +105, Search +46 (+52 find secret doors), Sense Motive +46, Speak Languages (Abyssal, common, draconic, gnome, infernal), Spellcraft +105, Spot +46, Survival +46 (+54 extraplanar), Use Magic Device +46 (+54 use scrolls), Use Psionic Device +46  
**Feats:** Corrupt Spell-like Ability (B), Craft Magic Arms and Armor (B), Craft Universal Item, Empower Power (B), Empower Spell (B), Enlarge Power (B), Enlarge Spell, Eschew Material Components, Extend Spell, Expanded Knowledge (Bend Reality, Divert Teleport, Energy Missile), Greater Spell Focus (Illusion), Greater Power Penetration (B), Greater Spell Penetration, Heighten Spell (B), Improved Initiative, Improved Natural Attack (fists), Multiattack, Persistent Spell, Power Penetration (B), Quicken Power, Quicken Spell, Repeat Spell (B), Spell Penetration, Spell Focus (Illusion), Silent Spell, Twin Power (B), Vile Natural Attack (B)  
**Epic Feats:** Automatic Quicken Spell(x4), Craft Epic Magic Arms and Armor (B), Epic Manifesting (B), Epic Psionic Focus(x2), Ignore Material Components (B), Multispell, Multipower, Improved Metapsionics (B), Improved Spell Capacity (10th) (B), Improved Spell Capacity (11th), Improved Spell Capacity (12th), Superior Initiative  
**Climate/Terrain:** Layer 122 of the Abyss (Hollow’s Heart)  
**Organization:** Solitary (Unique) or Troupe  
**Challenge Rating:** 62  
**Treasure:** Quintuple Standard  
**Alignment:** Chaotic Evil  
**Advancement:** N/A  

* Fraz ‘Urb Luu does not currently possess his Rod, but it is included for completeness’ sake in his damage and attack pattern.  

Fraz Urb ‘Luu is the Demiurge that unifies without a trace of order, and uses nothing as his symbol. Wielding illusions and mental prowess, he claims deception to be his alone, and punishes all who use it in his presence without submitting to him.  

The first alleged instance of an attack by Fraz Urb ‘Luu was on a long-forgotten layer of the Abyss. Surrounding a pit lined with rock that had liquified and then resolidified into obsidian was a set of Nalfeshnee. Half of them seemed to have died in terror, with the rest utterly convinced that they were each other’s worst enemies and fighting to the death accordingly. Even more unusual was the fact that all of them appeared to have been engaged in some form of ritual. Only exceptionally rare and unforged texts have this information, and it is still somewhat speculative, as nobody has found the plane where this event was recorded since then.  

Since that ancient event, Fraz ‘Urb Luu has been on a nearly uninterrupted rampage across the entire Abyss, slaughtering all in which he found a trace of order by his standards, or which tried to challenge what he considered to be his mastery of illusions. Considering that Fraz ‘Urb Luu is also completely insane, this turned out to be the rest of the Abyss.  

For tens, if not hundreds, of millenia, Fraz Urb ‘Luu proved to be one of the most annoying and destructive forces in an Abyss filled with slavering destruction. The only solace afforded to the other Abyssal Lords was that in Fraz Urb Luu’s campaigns against them, he had actually managed to inflict even more destruction on the forces of Perdition in the process.  

Then, the unthinkable happened: Fraz Urb ‘Luu was actually defeated in a riddle contest by an archmage worshipper of Boccob, Zagyg Yragerne, and contained in an artifact in The Mortal Coil. Furthermore, his Rod was broken apart and scattered across the planes in order to make his return that much harder. When the news of his defeat reached the Abyss, there was a nigh-celebratory atmosphere even among the forces of the other Demiurge, much less all of the Demon Princes and Demon Lords that had been set against each other through his trickery. For centuries, he remained trapped in his prison with the only remaining power that he could use being his Battle of Wits. Even with that he brought death to many who underestimated the booming voice from the statue.  

Eventually, he found two heroes that he managed to trick into unwittingly aiding him. The result was that he has been released from his prison, enslaved his unfortunate liberators, and has already returned to the Abyss, where he is attracting demonic servitors and regaining his strength. It is only a matter of time before his booming voice is heard over an Abyssal battlefield, and the depths of those foul planes get that much worse as a result.  

None are looking forward to that day.  

Fraz ‘Urb Luu is near-universally despised in the Abyss. Even the other Demiurge that have benefitted accidentally from his ravages (such as Merodach and Demogorgon) utterly hate him and will commit significant resources and efforts to frustrating any effort that Fraz ‘Urb Luu makes to do anything or killing him outright if the opportunity presents itself. Most Demon Princes and Demon Lords that are aware of his powers, either through reputation or learning the hard way, will slay beings out of hand that mentions Fraz ‘Urb Luu within their own kingdoms.  

For poorly understood reasons, Fraz ‘Urb Luu’s few allies often seem to have stronger tendencies towards pure evil. He is often closely associated with the Demon Prince of Confusion, Bulumuz, who is one of the Abyssal Lords that he is the most likely to call upon in order to cover his escape in a situation that he has either grown bored with, particularly if the Demon Prince’s chaotic persona is ascendant at the time. Simoultaneously, Fraz ‘Urb Luu has one exceptionally powerful ally outside of the Abyss entirely; the ambitious Nether Master Bubonix. In fact, their relationship is such that several beings suspect that the first place where Fraz ‘Urb Luu went after his liberation was the Grey Wastes, and from there, to Carceri where Bubonix is believed to have aided him with Yugoloth mercenaries in advance of his successful conquest of a new layer of the Abyss.  

Unfortunately, as many individuals have found out in their final moments, Fraz ‘Urb Luu is probably the Demiurge that is the easiest to bring to the Prime Material Planes due to his peculiar combination of psionic and magical powers and abilities to impersonate other creatures. In fact, he virtually revels in chances to come to the Prime Material Planes and takes special pleasure in the trail of warped, half-real landscapes, utter confusion, and multiple infuriated Abyssal Lords that he often leaves behind. For some reason that nobody quite understands, he particularly despises gnome illusionists and will often laugh uproariously (damaging much of the landscape in the process) while they run around on fire dying.  

Fraz Urb ‘Luu’s original plane before his incarceration in Castle Greyhawk was a subtly hideous layer known as Hollow’s Heart. When first viewed, it was an idyllic utopia reminescent of the Upper Planes in all of their glory, with trees that rained sweet honey and rivers of clear water. In fact, Fraz Urb Luu’s realm was a blasted wasteland where it rained maggots and the water was streams of offal. The only feature of the realm whose appearance was even close to the reality (as well as the giveaway of it’s true ruler) was Fraz Urb Luu’s castle, a towering statue of himself.  

The plane also had one other distinguishing feature; it sucked the magic out of magical items, an effect that only artifacts (and Fraz Urb ‘Luu) were immune to.  

During Fraz Urb ‘Luu’s imprisonment, rival Demiurge and enraged Demon Princes took the opportunity to invade his old realm. Part of the reason for this was to attempt to find any items of power that he might have left behind, but part of the reason was just to have the satisfaction of destroying something that he had built because he was despised so much.  

Fraz Urb ‘Luu is a towering humanoid monstrosity with short blue hair approximately 25 feet tall, with vast black bat wings jutting out of his shoulders. His face has a bestial cast, similar to that of a gorilla or another species of large ape, and his ears are long and ragged with a gnawed-on appearance. His eyes are horrific wonders to behold, as they are multifaceted like an insect’s are, except each facet is a leering reflection of the worst aspects of the unfortunate, and soon to be deceased, individual who gazes into them. Fraz ‘Urb Luu’s voice booms and echoes across the landscape, and when he does refer to himself, it is always in the third person.  

**Combat:** Fighting Fraz Urb ‘Luu, even for other Demiurge (much less Demon Princes) is an aggravating proposition that has caused several servants of the other Demiurge to defect from their own masters rather than even attempt it. Half the time individuals think that they are fighting him, they are fighting someone else entirely (and only find out after the illusions have been dispelled); conversely, half the time they think that they are fighting someone else, they are actually fighting Fraz Urb ‘Luu. By the time the battle is over, the only thing that the surviving combatants if any exist agree upon is that they have absolutely no idea what just happened. Among some of Fraz Urb ‘Luu’s more infamous stunts are:  

Sending a Demon Prince he thought was ‘too lawful’ to Avernus-because he thought he’d fit in better there.  

Convincing an entire army for the better part of a day that they were actually on Acheron-and then mass deluding them into thinking that a cube had crashed into them.  

Dealing with Fraz Urb ‘Luu in a place where he has had a chance to prepare himself is even worse. He tends to build enormous, illusory castles where certain passageways or bridges require believing in illusions in order to pass, along with other illusions that people must disbelieve in order to survive (often simoultaneously). In any event, Fraz ‘Urb Luu always opens combat with time stop, buying him time to erect layers of multiple illusions. For these reasons, the more quick-witted Abyssal minions started nicknaming him the Demiurge of Frustration.  

Afterwards, Fraz ‘Urb Luu will always use his bizarre illusionary and psionic powers before actually entering into melee combat, attempting to kill opponents with lethal delusions or scatter them. Anyone that fails to believe Fraz ‘Urb Luu’s illusions infuriates him, causing him to enter physical combat shortly afterwards and bludgeon them to death. A second significant problem with combatting Fraz ‘Urb Luu (particularly for spellcasters) is that he is an expert at ‘interweaving’ his illusionary spells with real versions of the same spells, as well as psionic powers, making it difficult to attempt to counterspell against him.  

With the loss of the Rod of Fraz Urb ‘Luu (one of the few magical items that could survive the effects of his home layer in the Abyss), he has been forced to improvise in terms of his choice of weapons. As a result, he will instead petrify a foe and pick them up for use as a club, or alternately, throw them at the rest of his enemies should he choose to use a weapon at all.  

**Ravaged Form-Booming Voice:** The voice of Fraz ‘Urb Luu is a weapon in it’s own right, doing 4d10 points of sonic damage to everything within 10 feet of him whenever he speaks.  

**Ravaged Form-Constricting Tail:** Fraz 'Urb Luu may choose to constrict beings that he has already hit with his tail, resulting in 2d8+18 points of damage per round that they are unable to escape from it's grasp.  

**Ravaged Form-Divine Power: Divine Illusionary Focus:** All of Fraz ‘Urb Luu’s spells from the school of Illusion have a +5 bonus to their save DC (+8 in the Abyss).  

**Ravaged Form-Humanoid:** Fraz ‘Urb Luu is roughly humanoid in form, although he has strongly bestial features at the same time.  

**Ravaged Form-Immense Size:** Fraz ‘Urb Luu is a Huge creature, hulking 20 feet tall, and gaining all of the associated benefits and penalties of his particular size category.  

**Ravaged Form-Lucidity Damage:** The touch of Fraz ‘Urb Luu destroys the ability of his victims to distinguish between reality and untruth. Any victim hit by his powerful fists must make a Will save DC 71 or else take 1d6 Wisdom damage and a –7 penalty to all saves against Fraz ‘Urb Luu’s illusions for the rest of that particular day. Beings that successfully save against Fraz ‘Urb Luu’s touch cannot be affected by it for the rest of that particular day.  

**Ravaged Form-Master of Trickery:** Fraz 'Urb Luu has perfected his ability to delude other creatures to the point. As a result, he may bluff as a rogue of equivalent hit die.  

**Ravaged Form-Muscular Legs:** Fraz ‘Urb luu’s powerful legs propel him at an accelerated speed, giving him a 10 foot speed bonus.  

**Ravaged Form-Magical Power:** Three times a day Fraz ‘Urb Luu may _dominate monster_ as the 9th level spell.  

**Ravaged Form-Magical Power:** Three times a day Fraz 'Urb Luu may alter his environs with _planar perimarch_ as the 9th level spell.  

**Ravaged Form-Epic Magical Power:** Once a day Fraz ‘Urb Luu may use the spell _eidolon_, making one duplicate of himself that lasts for 8 hours. He does not need to make a spellcraft check in order to make a copy of himself.  

**Ravaged Form-Window Into The Twisted Soul:** Any creature of nonevil alignment that meets Fraz ‘Urb Luu’s bizarre gaze must make a Will save DC 71\. If they are of good alignment, should they fail the save they are affected by a _morality undone_ spell cast at 92nd level.  

**Spell-like abilities (Sp):** At will: _animate dead, blasphemy, charm person, create undead, darkness, deeper darkness, desecrate, destruction, detect chaos, detect law, detect magic, dimensional anchor, disguise self, disintegrate, displacement, fireball_ (delayed blast), _flesh to stone, greater dispel magic, greater shadow conjuration, harm, hold person, magic circle against good, magic circle against law, minor image, mirage arcana, mislead, nether trail, persistent image, phantasmal killer, polymorph, project image, read magic, reality blind, reality maelstrom, screen, scrying, silent image, suggestion, symbol of death, telekinesis, teleport_ (greater, self plus 1000 pounds), _unhallow, unholy aura, unholy blight, wall of force, weird._ 6/day: _clenched fist, implosion, prismatic wall, time stop, touch of idiocy._ 3/day: _power word_ (kill), _power word_ (stun), _ruin._ 1/day: _astral projection, blur, gate, greater ruin, nailed to the sky_ 1/week: _ethereal jaunt, false sending, psychic poison, spell worm._ Cast at 98th level, except for Illusion spells which are cast at 99th level. Fraz ‘Urb Luu casts all spells from the domain of Illusion at will. These spells are included in the list above. Saving throws against Fraz ‘Urb Luu’s spell-like abilities are DC 25 + spell level. The save DC’s are Charisma-based.  

**Call Antitheses:** When Fraz-Urb ‘Luu is in combat against any enemy that is not Chaotic Evil in alignment, he may open a portal to the Mirror Plane and summon the Chaotic Evil version of his opponent. He may do this three times a day for up to 90 HD and the opponent or opponents involved must possess no divine rank. This does not necessarily mean that the antithetical version of the individual may be loyal to Fraz-Urb ‘Luu whatsoever; for this reason, Fraz-Urb ‘Luu tends to use this as almost a last resort.  

**Call Demons:** Three times a day Fraz Urb ‘Luu may call up to 90 HD of Demons. Typical choices for Fraz Urb ‘Luu are Balors and Glabrezu, although out of all of the Demiurge Fraz ‘Urb Luu is the most likely to make totally random and bizarre choices, particularly when he is trying to impersonate one of the other Demiurge or a Demon Prince (which he does quite often). Fraz Urb ‘Luu will never call Nalfeshnee, as he considers them to be ‘boring’ and is likely to attack any Nalfeshnee he sees first for his own private reasons.  

**Deceptive Disappearance:** Once a day Fraz-Urb ‘Luu may call any Demon Prince or Demon Lord under 90 HD that he has previously met or he knows the name of if they are outside their personal redoubt or home layer. If he has previously met them, then the Will save DC for the unfortunate victim is 72; otherwise the Will DC is 67; should they fail then they are simoultaneously called to Fraz ‘Urb Luu’s current location and convinced that the people facing Fraz ‘Urb Luu have summoned it. The instant that the victim appears, everyone except Fraz Urb ‘Luu that sees the Demon Prince or Lord appear must make a Will save DC 67\. If observers fail the second check, then they have been convinced that the being that Fraz Urb ‘Luu has summoned is him instead, and forget that the real Fraz Urb ‘Luu is there, buying him time to escape.  

Not surprisingly, this has not endeared Fraz-Urb ‘Luu to the other Demiurge, much less the Abyssal Lords that have fallen victim to this trick, as usually when they are outside their personal redoubts they are leading their armies into battle or engaged in taskings of similar personal import to them.  

**Abyssal Vehemence (Ex):** Fraz Urb ‘Luu’s physical presence is so disgusting that it causes lesser creatures to succumb to his hate and need to spread destruction and terror. All creatures within 600 feet of Fraz Urb ‘Luu must succeed in a Will save 70\. Those who succumb to Fraz Urb ‘Luu’s gross presence suffer one of the two following effects:  

_Fright:_ Affected beings become shaken and suffer a –2 morale penalty on attack rolls, saves, and checks. The merest glance or gesture by Fraz Urb ‘Luu makes them frightened, and they flee as quickly as they can, although they can choose the path of their flight.  

_Madness:_ The grotesque evil incarnate in his being drives lesser beings insane per the insanity spell. The being remains stuck in a state of madness for one day for every point by which she failed the saving throw, after which time the victim is allowed another save. The madness exists until the victim successfully saves or the appropriate spells are cast by a 31st level being to purge the insanity effect.  
Fraz Urb ‘Luu can make his servants, “worshippers,” beings of Chaotic Evil alignment, or a mixture of all three types immune to this effect as a free action. This immunity lasts one day or until Fraz Urb ‘Luu dismisses it. However, Fraz Urb ‘Luu cannot determine which effect takes place; there is a 50% chance each time Abyssal Vehemence is used that one or the other effect will impact near by victims.  

**Cosmic Corruption (Su):** So heinous is Fraz Urb ‘Luu’s presence that he may corrupt an entire area with but a thought. Once per day as a standard action, Fraz Urb ‘Luu may unhallow an area equal to 3150 feet. Fraz Urb ‘Luu can apply the following spells to the unhallow effect (some of which are not listed as part of the unhallow spell in the Player’s Handbook): _bane, bestow curse, contagion, deeper darkness, dispel magic, silence._ In most situations, Fraz Urb ‘Luu will select _bestow curse_ and choose to lower either Intelligence or Wisdom. In fact, Fraz Urb ‘Luu makes a point of trying to curse a new area every single day.  

The forces of righteousness disgust Fraz Urb ‘Luu, who finds goodness and holiness repellent enough to give him pause. As a result, Fraz Urb ‘Luu avoids hallowed ground. If Fraz Urb ‘Luu finds it necessary to enter a hallowed site, he must make a Will DC save equal to 30 + the divine rank of the represented god + the god’s Charisma modifier; Fraz Urb ‘Luu cannot use him spell resistance to overcome this effect. If Fraz Urb ‘Luu succeeds in entering the hallowed area, the area immediately becomes unhallowed. Once Fraz Urb ‘Luu breacshes holy ground, the god in question is immediately alerted to her presence and will almost always (DM’s discretion) arrive in person to deal with him.  

**Demiurge Qualities (Ex):** Fraz Urb ‘Luu is immune to electricity and poison; he possesses acid resistance 10, cold resistance 20, and fire resistance 20\. Fraz Urb ‘Luu can engage in telepathic communication with any creature within 100 feet; Fraz Urb ‘Luu constantly detects good, detects magic, and sees invisibility as a 31st level Sorcerer; he possesses immunity to polymorphing, petrification, or any other attack to alter her form. Fraz Urb ‘Luu is not subject to energy drain, ability drain, or ability damage; he is also immune to mind-affecting effects.  
Fraz Urb ‘Luu can sense anything within one mile around the mentioning of his name, titles, or an item of importance to her. This power is barred from places associated with gods of goodness or the personal redoubts of Demiurges.  
Fraz Urb ‘Luu is immortal and cannot die from natural causes; he does not age, and does not need to eat, sleep, or breathe.  

**Demon God (Su):** What few Clerics of Fraz-Urb ‘Luu exist prefer to pretend that they are Clerics of some other, lesser Abyssal Lord instead. The required test for becoming one of his Clerics is being able to pierce the dense net of untruths surrounding the entire subject of becoming a Cleric of Fraz-‘Urb Luu and successfully identifying another Demon that does, in fact, worship him.  

Worshippers of Fraz-Urb ‘Luu pretend to have no goals whatsoever, but their real goal is to destroy all illusionists that do not pay homage to their lord. This is not because they have the slightest problem with using such spells themselves as much as in their minds (and in the mind of their lord), since Fraz Urb ‘Luu is the unquestioned master of Deception, for any other liar to exist that doesn’t serve him is merely a pointless redundancy. Clerics of Fraz Urb 'Luu may be granted spells from the Domains of Chaos, Evil, Mind, and Illusion. As befitting their lord, his Clerics do not even call themselves such, and instead are a random but powerful array of creatures that simply follow him around, create chaos and destruction, and hope this pleases him (which it usually does).  

**Divine Decadence (Ex):** Although not a god, Fraz ‘Urb Luu possesses power that rivals that of true divine beings. Fraz ‘Urb Luu possesses a virtual divine rank of 11 as described in the “Virtual Divine Ranks and Cosmic Entities Defined” article. Furthermore, while anywhere in the Abyss, Fraz Urb ‘Luu functions as if he had a Virtual Divine Rank of 16.  

**Entropic Wave (Su):** Fraz Urb ‘Luu can unleash an explosion of corrupt, destructive, Abyssal power in the form of a wave that extends from his person. Fraz Urb ‘Luu may use his Entropic Wave 10/day, dealing 18d12 points of damage. Fraz Urb ‘Luu’s Entropic Wave explodes in a radius of 100 feet; victims caught in the wave may attempt a Reflex save DC 68 for half damage. Fraz ‘Urb Luu’s Entropic Wave appears as a slight shimmering of the air which victims only notice when it smacks into them. Entropic Wave ignores mortal magic like anti-magic field, but may only remove one layer of prismatics per blast. Walls of force are not affected by Entropic Wave.  

**Wizard Spells (Sp): 8/7/7/7/7/6/6/6/6/3/2/2.** Fraz Urb ‘Luu casts spells as a 56th level Wizard and at 60th level for the purpose of defeating spell resistance. The saving throws against Fraz Urb ‘Luu’s spells are DC 24 + the level of the spell. The saving throws against Fraz Urb Luu’s Illusions are DC 31 + spell level on the Prime Material Planes and DC 34 + spell level while Fraz Urb ‘Luu is in the Abyss. All of Fraz Urb ‘Luu’s spells are quickened.  

**Psionic Powers (Sp):** Fraz ‘Urb Luu manifests powers as a 56th level Shaper, knows 48 powers and may use 483 power points in a single day. Fraz ‘Urb Luu may additionally manifest 10 epic powers per day with a maximal Psicraft DC of 115\. Fraz ‘Urb Luu may choose to expend his psionic focus and manifest as a 60th level Shaper. The saving throws against Fraz ‘Urb Luu’s powers are DC 24 + power level + relevant augmentation. The saving throws DC’s are Intelligence-based.  

**Battle of Wits (Su):** Fraz-Urb ‘Luu may challenge an individual that confronts him to a battle of wits. The rewards if they succeed are as great as if they fail. (This should be roleplayed, but failing that, Fraz-Urb ‘Luu may roll his Perform check (riddles) against the willpower of his victim, or the reverse in the next round).  

Should the individual involved succeed in besting him then they may make one request of him which he is bound to keep or ask him one question which he must answer to the best of his considerable abilities. Strangely, this is the only vaguely ‘lawful’ aspect about Fraz ‘Urb Luu. He does keep his word if he has been successfully outwitted although this has only happened twice in his entire history.  

If Fraz-Urb ‘Luu catches them in a lie, however, then his challenger must make a Fort save DC 60\. Should they fail then horrific blue flames wreath their body, burning away their untruth and doing 7d8 vile damage and 8d8 fire damage/turn until extinguished or until the victim is dead. Victims who are killed in a Battle of Wits become Shapeless Servants permanently enslaved to Fraz-Urb ‘Luu (treat as Terror Ghosts with the Memories of a Burning Death Salient Ability but incapable of making Lavawights and under both permanent _improved invisibility_ and _nondetection_ spells as a Sorcerer of equivalent HD). The flames produced in this manner may be dispelled through the casting of _control flame_ by a caster of 31st level or higher.  

**Existential Crisis (Su):** Seven times a day, Fraz ‘Urb Luu may use his mind to rend the nature of reality itself and may make 15 aspects of existence around him into illusions. Unattended physical objects, features of the landscape, and magical items recieve no save against this effect; living creatures recieve a Fort save DC 68\. Each use of this power is capable of converting 1000 cubic feet per aspect of inanimate matter into it’s illusionary equivalent. If an individual who has been turned into an illusion disbelieves in themselves, they must make a Will save DC 72 or else completely disappear from existence and be unrecoverable except by a deity with the Mass Life and Death salient divine ability. Beings that have been turned into illusions can be brought back into existence using a very carefully worded wish.  

**Prince of Illusions (Sp):** Fraz Urb ‘Luu is a master of illusions and trickery, rivaled by certain greater gods. As such, this has granted him the following powers:  

_Landscape of the Mind:_ All illusions that Fraz Urb ‘Luu calls into existence are persistent or extended with no additional need for a higher spell slot at his choosing. Furthermore, Fraz Urb ‘Luu may make any illusionary spell that he casts permanent seventeen times a day with no XP cost. Similarly, he may dismiss any illusion that he has previously made permanent as a quickened action.  

_Alter Illusions:_ Fraz ‘Urb Luu may alter the properties of any illusion that he has already called into existence as long as it is within sensory range of him. If an illusionary spell has been cast by someone else, he may attempt to seize control of it and alter it’s characteristics of it’s choosing on a caster level check. Should Fraz ‘Urb Luu alter a living being that has been turned into an illusion using his Existential Crisis power, then they suffer the effects of a _baleful polymorph_ spell.  

Any individual that does not pay homage to Fraz ‘Urb Luu that attempts to use an illusionary spell within a 1600 foot radius around him must make a Fort save DC 60 or else risk having the untruth burnt out of them as if they had entered in a Battle of Wits with him. Should Fraz ‘Urb Luu be displeased with one of his own followers, he has little hesitation about subjecting them to the ravages of this power as well.  

**Ultimate Ventriloquist (Su):** 17 times a day, Fraz ‘Urb Luu may throw his voice up to 300 feet away from him. Once his voice has been thrown to that particular location, Fraz ‘Urb Luu may designate it to remain there for up to 8 rounds. During each of those rounds, he may cast spells with verbal components through the location where his voice is currently located. While Fraz ‘Urb Luu’s voice is located elsewhere, he may not cast any spell with a verbal component unless it can be prepared silenced where his body is located, although he may still manifest powers normally.  

Alternately, Fraz ‘Urb Luu may choose to steal the voice of someone else. When this occurs, they must make a Will save DC 71 or else become permanently unable to speak and may not cast any spell unless it can be prepared stilled. Fraz ‘Urb Luu may then choose to speak at will in that voice for the rest of that day or use the rest of his ultimate ventriloquist Abyssal Blessing in conjunction with it.  

Victims that have had their voices stolen may have them returned through a casting of _wish_ by a deity with access to the Trickery or Illusion Domains or by a 31st level caster.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *