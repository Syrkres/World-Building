# The Geography of Faerie

**The Geography of Faerie**  
Faerie is a place of nature unbound. Its inhabitants are aloof and apart from the “lesser” squabbling that happens in the wider cosmos. The fey of Faerie represent facets of nature, and can be of any alignment. “Faerie” refers to two of the three layers that make up the Prime Material Plane, which the fey refer to as the Tree of Life. The top layer is the Mortal Coil. Faerie constitutes the bottom two layers, Annwn (“anoon”) and Ladinion. Though, some have mistakenly called it a separate plane or a specific world within the Mortal Coil.  

**FAERIE TRAITS**  
Annwn and Ladinion share the following traits.  

* **Light Gravity:** Characters suffer a -2 circumstance penalty on attacks and Balance, Ride, Swim, and Tumble checks; they gain a +2 circumstance bonus on Climb and Jump checks. All weights are halved. Weapon ranges double. Damage dice from falling is reduced from d6 to d4.  
* **Infinite Size:** At the very least, the layers of Faerie are each as large as the Mortal Coil.  
* **Alterable Morphic.**  
* **No Elemental or Energy Traits:** Sections of each layer may have the minor positive-dominant or minor negative-dominant trait, but Faerie as a whole does not.  
* **Mildly Neutral-Aligned:** Of the two layers, only Annwn has this property (see below).  
* **Enhanced Magic:** The layers of Faerie are highly magical, and all arcane and nature-based divine (druid, ranger, etc) spells cast there are maximized, empowered, and extended (as if prepared with the appropriate feats). The fair folk do not care much for the pious of any faith, so other divine magic is unaffected.  

Ladinion has the following additional traits:  

* **No Alignment Traits:** Alignment has no place in the primal natural order.  
* **Entrapping:** At the conclusion of every day spent in Ladinion, any non-native must make a Will saving throw (DC 10 + number of consecutive days spent in Ladinion). Failure indicates that the visitor has fallen under the control of the layer, unable and unwilling to leave of his own volition. Memories of any previous life fade into nothingness, and it takes a _wish_ or _miracle_ to return such a character to normal. But travelers who have accepted no food, drink, or other gifts from the natives of Faerie during their visit need not make the saving throw.  

**FAERIE LINKS**  
Portals are typically the only way to get to or from Annwn and Ladinion. Not even magic such as _plane shift_ or _gate_ will suffice; only _wish_, _miracle_, similar transportation effects, and effects which explicitly bypass this restriction will work. Annwn contain portals to Ladinion, the Mortal Coil, the Land of Dreams (Ethereal Plane), the Demiplane of Shadow (Plane of Shadow), and the Endless Boundary (Astral Plane). A portal in the Land of Dreams appears as a curtain of shimmering brass. Links to the Demiplane of Shadow are quite rare. Links to the Endless Boundary are almost unheard of and closely guarded - in the Endless Boundary, they appear as color pools of turquoise. Ladinion contains portals to Annwn alone. Because most parts of Faerie do not connect to transitive planes, spells which use those planes do not function in those parts (including spells of the calling, shadow, summoning, and teleportation subschools).  

Portals between Annwn and Ladinion, the Mortal Coil, and the Demiplane of Shadow usually function much like soft planar boundaries rather than clear, instantaneous portals, but are considered portals nonetheless. For instance, a woman may wander into a fog bank on the Mortal Coil and wander out to discover that she is in Annwn.  

Most of Faerie's portals only function sometimes - some only work during a certain phase of the moon, others during a certain season, others a certain time of day, and a few only function during certain cosmological convergences which may occur as frequently as every year or as rarely as millennia apart. The most common frequencies are: daily at twilight, every month during the three nights of the full moon, and every year on the night of one or the other solstice. Many a portal also requires that the traveler approach it in a special manner.  

Faerie exists in a sort of temporal eddy, which interferes with travel magic and may distort the amount of time a traveler has spent there when he leaves. The rate of distortion varies from portal to portal, but is constant for each portal. Travel by means other than a portal produces a random time distortion depending on the layer the traveler departs from (roll on the table below) unless the means are specifically designed to work in Faerie (such as a spirit shaman's _spirit journey_ ability or a phooka's wild ride ability).  

**Random Time Distortion by Layer of Departure**  
---------Distortion----------  
---Roll d%--- Distortion Faerie Mortal  
Annwn Ladinion Strength Time Time  
---------------------------------------------------------  
01 01-03 Very Strong 1d100 years = 1 round  
02-03 04-10 Strong 1d12d20 days = 1 round  
04-07 11-20 Moderate 1 day = 1d8+2 rounds  
08-15 - Mild 1 day = 3d20 minutes  
16-20 - Faint 1 day = 1d20+1 hours  
21-30 - None 1 day = 1 day  
31-45 - Faint 1 day = 1d6 days  
46-70 - Mild 1 day = 1d4 weeks  
71-85 21-70 Moderate 1 hour = 2d2d4-1 days  
84-98 71-95 Strong 1 round = 1d6d10 hours  
99-00 96-00 Very Strong 1 round = 3d2 days  

Time lost or gained this way has its full effect on the traveler's age. For example, if a human goes to Faerie for two weeks and then returns through a portal with a time dilation of 1 day=1 year, he finds that he is 14 years older and that it is 14 years later than he left. If a child goes to Faerie, spends twenty years there and grows up, then returns through a portal with a time dilation of 1 year=1 second, she finds herself a child again when she arrives home, where it is virtually as if she had never left. Visitors to Faerie have been known to spend a short while there and then return home only to crumble to dust from the weight of years. Natives of Faerie may resist this distortion with a Will save (DC depends on the strength of the time distortion, as shown on the table below). A very few portals exist which do not cause time to catch up with the traveler, so that they may arrive in distant times without aging a bit; these portals are carefully guarded and regulated. Any fey, as well as any mortal with the knack (from a feat or other source), can determine the strength of a portal and whether it accelerates or decelerates time with a Knowledge (nature) check against DC 20.  

**Will Save DC to Resist Time Distortion**  
----Distortion----  
Faerie Mortal Will Distortion  
Time Time DC Strength  
-------------------------------------  
1 year = 1 round 25 Very Strong  
1 day = 1 round 20 Strong  
1 day = 1 minute 15 Moderate  
1 day = 1 hour 10 Mild  
1 day = 1 day 5* Faint  
1 day = 1 week 10 Mild  
1 day = 1 month 15 Moderate  
1 day = 1 year 20 Strong  
1 day = 100 years 25 Very Strong  

* A time distortion of exactly 1 day=1 day is not a time distortion and so does not require a saving throw.  

A portal which falls between two entries uses the smaller of the two distortion strengths (and DCs). A Faerie native does not know the nature or strength of a portal until it enters unless it has the help of a guide or has attained a certain understanding of that particular portal from a guide or personal experience.  

_Note:_ See Chapter 2 of the _Manual of the Planes_ for information on portals and planar boundaries.  

**ANNWN**  
In Annwn, the geography mirrors that of the coexistent Mortal Coil. Distance is constant between the two. A portal from the Mortal Coil to Annwn always goes to the same place. For the most part, Annwn seems like a strange reflection of the Mortal Coil.  

**Avalon**  
Also known as the Isle of Apples, this is the home of fey gentry who rule in Annwn alongside the infamous Mortal Coil land of Logres. It is ruled by Morgan le Fay, who inherited the place from Avallach.  

**The Badlands**  
The places in the Mortal Coil that are empty space are instead extreme natural environments (such as a tundra 200 degrees below zero or a desert that is 300 degrees) in Annwn. These expanses are known as the Badlands. One gets to the Badlands from the planetary regions of Annwn by choosing a random direction and walking that way for a time - in a short time, one is at the edge of the Badlands and can possibly traverse them to regions of Annwn coexistent with different mortal coils.  

**Court of the Undying Season:** The Harbingers of the Undying Season have their stronghold in a freezing tundra region of the Badlands. This is the only part of Faerie which contains a significant population of undead.  

**The Shadow World**  
The region of Annwn matching the mortal coil of Cerillia is known to mortals as the Shadow World. It has been powerfully tainted by the death of an evil goddess, and so has been largely disconnected from the rest of Faerie by the Two Queens. Strangely, the entire region has a faint connection to the Land of Dreams (Ethereal Plane); in fact, the region acts in some ways as Cerillia's BOrder Ethereal and connects (unreliably) directly to the Deep Ethereal.  

**LADINION**  
Ladinion is the layer of Faerie further removed from the Mortal Coil. Nature here is more primal, powerful, and pure. It is more malleable than Annwn; it shifts around relative to Annwn at varying paces in different areas (at the whims of powerful fey, as well as on its own). Some parts of its geography are relatively stable, however. The Planar Cartographic Society has assigned an arbitrary "north", toward a massive frostfell region in the same general direction from most known entrances into Ladinion, for the simple purpose of having a reference point.  

**Encante**  
This vast city of the encantados consists entirely of palaces constructed from costly crystal. The city's inhabitants are almost exclusively transient, as the encantandos usually hate to stay in one place for long.  

**The Garden of the Hesperides**  
This small realm is where dryads rule supreme. It is guarded Ladon, a draconic child of Gaia and an ally of the fey. The garden lies in the far west of Ladinion. There place is plentiful with oak trees, but also many other plants.  

The most famous feature are blessed apple trees which bear golden fruit. These golden Apples of Joy greatly extend the lifespans of any being who eats of them, and allow the resident dryads (along with their trees) to live many thousands of years. These apples were planted from a sprig given as a gift to the fey by Gaia and Hera as a sign of goodwill.  

**Hyperborea**  
Located to the northeast of Ladinion, this is a land of eternal sunshine. It is a Seelie stronghold, and has the minor positive-dominant trait.  

**Paradwys**  
The Lifeline of the Tree of Life, the core of the cycle of souls, the Primal Nexus, Paradwys is an unmatched paragon of natural power and majesty. It can be thought of as the arbitrary center of Ladinion, and is not hard to reach from any part of the layer. From far away, it appears like a towering natural force; from the desert it appears as a stationary mushroom-shaped sandstorm, from the forest it seems to be an impossibly high arch in the canopy, and from a mountain range it appears to be a distant but absurdly massive peak.  

Within Paradwys, all the breadth of natural landscapes converge on the primal sea called Cwm Glas and the very core of the cycle of souls. At the center is Sídhe Mór, an island emerging from Cwm Glas very near a coastal marsh. Surrounding Cwm Glas is a variety of terrain types. In clockwise order, starting with the aforementioned marsh, they are marsh, forest, hills, mountains (with sizable caves underneath), deserts, and plains. The plains are divided from the marsh by a broad river called Afon Bhlu, fed by Cwm Glas.  

Almost any part of Ladinion can be reached from Paradwys, if you know the way and leave in the appropriate direction, as can many parts of the Mortal Coil. For instance, to reach a mountainous region you must depart from the mountainous part of Paradwys. Likewise, the terrain you come from determines which part of Paradwys you arrive in. Many of the stars in the region's night sky are actually mortal coils. It's possible to reach such a coil by flying toward the matching star; after a certain length of time, the traveler finds himself in the sky above that world (only some of the stars function this way). Traveling this way straight from Ladinion to the Mortal Coil is dangerous, however, and always includes a powerful time distortion (moderate or stronger, with a moderate forward distortion being most common). These stars function as portals only when they are visible.  

Paradwys is inhabited by the most magnifacent and rare of natural life, including mu spores, elder treants, prismasauruses and other epic magical beasts, dire animals, nesting populations of devastation vermin, and many others. Fey are less numerous here than in most of Ladinion, leaving its tending primarily to the soul shepherds, though birds of paradwys appear in unusually large numbers. The homes of both soul shepherd orders (the Sowers and the Harvesters) can be found here, in the cosmic realms of Nachtan Mac Namá and Ankou. Nachtan's Sowers reside on the plain at the head of the river, Ankou's Harvesters at the edge between forest and hills.  

**Cwm Glas:** The water of this lake is mildly and variously salty, capable of supporting every sort of natural marine life imaginable. Near the lowest point in the water's depths is a secret portal to the Court of the Undying Season in Annwn, known only to Yan-An-Od and his most trusted servants.  

**Sídhe Mór:** The very heart of Paradwys, Sídhe Mór is a massive faerie mound rising from the edge of Cwm Glas. Here, concentric helices of dead and unborn souls spiral in and out of the earth. The unborn souls are collected by the Sowers for distribution; the dead are guided in by the Harvesters. Sídhe Mór is guarded and tended by a secretive Fairy Queen by the name of Danriga who interacts with other fey only rarely.  

**The Celestial Sphere:** High overhead in Paradwys, the sun remains stationary above Sídhe Mór. At night, it turns into the moon without setting; in fact, half of the sphere is solar and the other half lunar. Unlike a typical celestial body, this sphere is only about 100 miles above the ground and about 1 mile in diameter. It has its own objective directional gravity extending 200 ft. from the surface, has solid ground, and is not dangerous to approach. If the cycle of souls below shifts strongly in one direction (such as if a world is destroyed and there is a resultant influx of dead souls), the diurnal cycle of the celestial sphere may become temporarily imbalanced.  

The sun houses the cosmic realm of Yi, Lord of the Sun; the moon houses Chang'e, Lady of the Moon. Together, they are said to guard the way to the enigmatic Watcher of the Currents.  

**The Headwaters of Time:** The power of time and nature is obviously present in Paradwys. In fact, the place is strongly linked to the so-called Headwaters of Time, where the temporal eddy that includes the entirety of Faerie is said to have its source. Some believe the lake called Cwm Glas to be these headwaters, but the more likely candidate is high above, in or beyond the sun/moon. Additionally, all Paradwys is covered in a subtle time wrinkle, which grows more powerful as one approaches Sídhe Mór at the center. The precise effects are detailed below (details forthcoming).  

**The Lifeline of the Tree of Life:** The most magical manifestation of nature's power is the ley energy saturating the area. Paradwys is the most powerful ley node in the Material Plane. The consequences of this immense energy include the area's time wrinkle and storms of supreme fertility and decay that whirl across the landscape (stats in progress).  

**Thule**  
This island, found farther northwest than any other recorded locale, is surrounded by a freezing-cold ocean. Here it is perpetually twilight. There are rumored to be regions on the island where land, sea, and sky blur together in a strange soupy fog.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.
