# Great Mother, Patron of Beholderkind
_Gargantuan Aberration (Chaotic, Evil, Extraplanar)_  
**VDvR:** 13  
**Domains:** Chaos, Death, Evil and Strength  

**Hit Dice:** 60d8+660 (1140 hp)  
**Initiative:**  
**Speed:** fly 60 ft. (good)  
**AC:** 79 (+13 cosmic, +15 deflection, +10 Dexterity, +35 natural, -4 size) touch 44, flat-footed 69  
**Base Attack/Grapple:** +45/+67  
**Attack:** Eye rays +55 ranged touch  
**Full Attack:** 3 eye rays +55 ranged touch and bite +46 melee (6d6+10)  
**Space/Reach:** 40 ft. /40 ft.  
**Special Attacks:** Mega eye rays, spell-like abilities, spells, supreme antimagic cone  
**Special Qualities:** Patron Qualities, all around vision, darkvision 60 ft., DR 30/epic and mithril, DR 20/good, fast healing 22, immune to cold and fire, resistance to acid 20 and electricity 20, SR 57  
**Saves:** Fort +43, Ref +37, Will +50  
**Abilities:** Str 30, Dex 32, Con 33, Int 45, Wis 35, Cha 40  
**Skills:** Bite me  
**Feats:** Ability Focus (Eye rays), Combat Reflexes, Corrupt Spell, Corrupt Spell-like Ability, Dark Speech, Empower Spell, Extend Spell, Flyby Attack, Great Fortitude, Improved Initiative, Iron Will, Maximize Spell, Power Attack, Twin Spell, Violate Spell, Violate Spell-like Ability, Weapon Focus (eye rays)  
**Epic Feats:** Enhance Spell, Epic Fortitude, Epic Weapon Focus (eye rays), Epic Will  
**Climate/Terrain:** The 6th layer of the Abyss  
**Organization:** Solitary (Unique)  
**Challenge Rating:** 42  
**Treasure:** Triple Standard  
**Alignment:** Chaotic Evil  

**Patron Qualities:** Great Mother possesses the following qualities  
• Watchful Eye: Great Mother can sense anything within one mile around the mentioning of her name, titles, any object or shrine devoted to her, or something which triggers her Patron Omniscience ability, for up to one hour after the event. This power is barred from places associated with beings with divine ranks or virtual divine ranks of higher than the Great Mother  
• Divine Rank 0: As a cosmic entity, Great Mother gains a degree of might unknown to common beholders. She is immune to polymorphing, petrification, or any other attack that alters her form. She is not subject to energy drain, ability drain, or ability damage. She is immune to mind-affecting effects. These immunities are bypassed by creatures of divine or virtual divine rank higher than her own. She is immortal and cannot die from natural causes. Great Mother does not age, and she does not need to eat, sleep, or breathe. The only way for her to die is through special circumstances.  
• For the purpose of gate and similar spells, Great Mother is a unique creature.  

**Ocular Avatar:** Great Mother can target her eye rays through any eyeball located in her realm. Abyssal Eyes and other willing monsters recieve no save, those who do attempt to save must succeed on a DC 55 Fortitude save to resist. (It is a standard action to fire an eye ray through an unwilling creature) Success indicates Great Mother fails to fire her rays through the creature, but the creature takes 5d6 points of vile damage. Failure indicates that not only does the Great Mother fire her ray through the creature, the creature suffers the effects of a _seething eyebane_ spell and takes 20d6 points of vile damage. Creatures slain from this damage rise in 1d4 rounds as eyebane zombies.  
**Behold the Divine (Su):** Great Mother possesses the cleric casting ability of a 45th level cleric. The focus for her spells is her eyestalks. She may cast one spell of each level, once a round in lieu of making an eye ray attack with that stalk. If she uses all of her stalks at once, she may cast an epic spell. **There was more to this, regarding metamagic but I seem to have lost my correspondance with Bane. Please reenlighten me**  
**Cosmic Divinity (Ex):** Although not a godess, Great Mother possesses power that clearly rivals that of true deities. Worshipped as a goddess by all beholderkind, Great Mother is sometimes worshiped by other mortals as well. She possesses VDvR 13 as described in the “Virtual Divine Ranks and Cosmic Entities Defined” article. She also possesses a "cosmic realm" which is identical to a divine realm of a deity. The 6th layer of the Abyss is Great Mother's cosmic realm, which she can affect as an intermediate god.  

Great Mother has the capacity to grant and withold spells to clerics, much as a god does. She only grants spells to beholderkind, seeing all other creatures as worthy only of death or subjugation..  

Great Mother possesses the feat of strength and death touch granted powers. She can use them each once a day as a 60th level cleric. She also casts chaotic and evil spells at +1 caster level.  

**Mega Eye Rays (Su):** Each of Great Mother's ten eye rays resembles a spell cast by a 60th level caster. Each ray has a range of 450 feet, and a DC of 57\. Each ray can be fired 3 times each round. Where applicable, the maximum level based cap is ten levels higher, as if Enhance Spell metamagic had been applied. The ten rays include:  
_Dominate monster:_ As the spell, Will save negates  
_Disjunction:_ As the spell, Will save partial.  
_Disintigrate:_As the spell, Fortitude partial. 60d6 points of damage to those who fail the save, 5d6 to those who succeed.  
_Fear:_ As the spell, but targets one creature only. Will save negates.  
_Finger of Death:_ As the spell, Fortitude partial. Death to those who fail, 3d6+35 points of damage to those who don't.  
_Flesh to Stone:_ As the spell, Fortitude negates.  
_Harm:_ As the spell, Will save half. 250 points of damage, cannot reduce target's hit points to less than 1.  
_Sleep:_ As the spell, Will save negates. Can affect a creature of any HD.  
_Hold Monster:_ As the spell, Will save negates.  
_Telekinesis:_ As the spell, Will save negates. Effects based on level have a maximum of 25th level, not 15th. Great Mother's Charisma modifier (+15) is used for combat manuevers.  

**Patron Omniscience:** Great Mother can sense any event that affects a beholder. Her senses extend into the past for 13 weeks. When she senses an event, she merely knows that the event is occurring and where it is. She receives no sensory information about the event although she may use her Watchful Eye to perceive the event if it is occuring in the present.  

**Supreme Antimagic Cone (Su):** As the supreme beholder, Great Mother's central eye is far more potant at eliminating magic than her children's. First, the area of the cone of antimagic is 450 feet. Second, the cone affects all psionics and supernatural abilities even if such abilities are different than magic. Third, those within the cone must succeed at a Will save DC 55 or lose 1 spell, 1 use of a limited use spell-like ability, or 20 pp every round. Finally, if the Great Mother gives up her use of her central eye (including sight) for a week, she may create a permanent dead magic area in a 450 foot cone.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *