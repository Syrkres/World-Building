# Zephyr
Large Fey (Air)  
**Hit Dice:** 12d6+60 (102 hp)  
**Initiative:** +9  
**Speed:** 80 ft., fly 80 ft. (average)  
**Armor Class:** 25 (-1 size, +9 Dex, +7 natural), touch 18, flat-footed 16  
**Base Attack/Grapple:** +6/+16  
**Attack:** Hoof +16 melee (1d6+6)  
**Full Attack:** 2 hooves +16 melee (1d6+6) and bite +10 melee (1d8+3)  
**Space/Reach:** 10 ft./5 ft.  
**Special Attacks:** Breath weapon, control winds  
**Special Qualities:** Air walk, cloak of wind, damage reduction 10/cold iron, immunity to electricity, low-light vision, scent, wind mastery, wind walk  
**Saves:** Fort +10, Ref +17, Will +14  
**Abilities:** Str 23, Dex 28, Con 22, Int 13, Wis 22, Cha 23  
**Skills:** Balance +11, Intimidate +21, Jump +28, Knowledge (nature) +18, Listen +21, Sense Motive +21, Spot +21, Survival +21 (+23 in aboveground natural environments), Tumble +24  
**Feats:** Dodge (B), Flyby Attack, Improved Flyby Attack, Mobility, Weapon Finesse, Weapon Focus (hoof)  
**Environment:** Any land  
**Organization:** Solitary, pair, or herd (4-20 with 1d3 noncombatant young)  
**Challenge Rating:** 12  
**Treasure:** None  
**Alignment:** Often neutral  
**Advancement:** 13-24 HD (Large); 25-36 HD (Huge)  
**Level Adjustment:** +8  

_The wind, just a breeze moments ago, suddenly grows into a howling gale. A pale shape blows by at blinding speed. It slows and settles to the ground before you, and you can clearly see it: a powerful white stallion with intelligent eyes._  

A zephyr is a creature of the winds, and each one associates with a particular type of wind. Examples include hot sandstorm winds, cool spring breezes, and warm autumn gales. Zephyrs like to wander from place to place, usually adjusting the local weather to suite their preferences. Some (those inclined toward law) try to make sure that areas get an amount of their type of wind that is most appropriate for the preservation of nature in the area. Others (those inclined toward chaos) simply go where their hearts take them, trusting that their instincts will take them where they ought to be.  

Zephyrs only form large groups when they mate, and they mate only rarely. When a pair has mated, they remain together until a colt is produced and matures. As soon as the two become a pair, any zephyr which happens upon them will join them to protect them and their young. The group disbands entirely, including the central family, as soon as the colt reaches maturity. Sometimes a herd will contain more than one mated pair; in this case, the group will not disburse until all colts produced reach maturity. It is extremely rare for a herd to last multiple generations.  

Zephyrs have strong sex drives; they are known for their rare but powerful lust. Every decade or so, a zephyr will enter heat and often becomes involved with mortals or other fey if it cannot locate another zephyr.  

Zephyrs avoid the politics of the Two Courts for much of the time, but usually align with one court or another based upon the sort of wind it represents: for example, those associated with firestorms and gales usually empathize with the Unseelie and those of spring showers or gentle breezes often associate with the Seelie. Zephyrs comprise the single most prominent member race in the Court of Winds, on the other hand. Zephyrs are also sometimes the leaders of small local fey courts in the Mortal Coil. They are often revered and feared by mortals.  

Zephyrs are among the most common types of fey to be drawn away from nature to the Elemental Realities. They are impressed and attracted to the intimate connection of air elementals to air and wind, but they are also repulsed by the inorganic sterility of elementals. Zephyrs, like all fey, can mate with any mortals or fey - unlike other fey, however, zephyrs can also mate with most air elemental creatures such as arrowhawks and genies, and can even procreate with air elementals when they are in cloud form.  

A zephyr looks like a light-colored stallion whose hair seems to blow in the wind even when there isn’t any. The specific nature of the horse varies with the type of wind it is associated with. For example, a spring breeze zephyr is typically lean and tinged green, while a gale zephyr is usually tinged grey and powerfully built.  

Zephyrs speak Sylvan and Auran.  

**COMBAT**  
A lone zephyr that is attacked will generally retaliate fiercely. A zephyr begins combat by activating its cloak of winds at maximum strength and then using control winds to create a cyclone around its position out to maximum range. Once it is protected by powerful winds, the zephyr will begin to make flyby attacks and rain down on its enemies with its breath weapon. If a zephyr is severely weakened, it will begin to wind walk and use its cloak of winds to accelerate its flight (tornado-force winds will blow the zephyr away at 1,750 feet per round, hurricane-force winds will blow at 750 feet per round, and windstorm-force winds will blow at 500 feet per round).  

If a zephyr herd is attacked, the parents will keep the young in between them, and will create a downdraft to blow enemies coming from all directions away from them. The rest of the herd will address enemies directly, attempting to blow transgressors far away, or, failing that, kill them quickly with breath weapons.  

**Air Walk (Su):** A zephyr can always choose to walk on air as if with _air walk_ (caster level 20th).  

**Breath Weapon (Su):** 60-foot cone, once every 1d4 rounds, effect varies, save DC 24\. The save DC is Constitution based, and includes a +2 racial bonus. Each zephyr has only one breath weapon, which is dependent upon the sort of wind the zephyr associates with. Any duration or damage is Hit Dice-based.  

_Blasting (gale):_ Tornado-force winds blow away from the zephyr for 1 round. Fortitude negates.  
_Calming (summer breeze):_ Unconscious for 12 minutes. Will negates.  
_Cold (blizzard):_ 12d6 points of cold damage. Reflex half.  
_Cutting (sandstorm):_ 12d6 points of slashing damage from flaying grit. Reflex half.  
_Deluge (heavy rain, sleet):_ Blast of water deals 12d4 points of bludgeoning damage. Reflex half. Water effectively bull rushes all creatures in the area away from the zephyr using the zephyr’s statistics. Fire creatures suffer 50% more damage from this effect.  
_Dust (sirocco, sandstorm):_ 12d4 points of desiccation damage. Fortitude half.  
_Electric (thunderstorm):_ 12d6 points of electricity damage. Reflex half.  
_Howling (thunderstorm, gale):_ 12d4 points of sonic damage. Reflex half.  
_Searing (firestorm):_ 12d6 points of fire damage. Reflex half.  

**Control Winds (Su):** A zephyr can replicate the effects of a _control winds_ spell (DC 22, caster level 12th) as a move action. The effect ceases immediately if the zephyr loses consciousness. The save DC is Charisma-based.  

**Cloak of Wind (Su):** A zephyr exerts considerable control over the wind directly around its body, affecting a 5-foot radius sphere. Within this sphere, the zephyr can alter the behavior of wind as a free action, replicating the effects of _control winds_ (DC 24, caster level 12th). The wind inside the cloak is unaffected by other winds the zephyr may have caused or manipulated. These effects cease if the zephyr loses consciousness. The save DC is Charisma-based, and includes a +2 racial bonus.  

A zephyr flies by commanding the wind very near its body to propel and support it. If the zephyr is knocked unconscious, winds automatically slow its fall as if with feather fall. A zephyr cannot run while flying.  

**Wind Mastery (Ex):** Airborne creatures take a -1 penalty on attacks and damage rolls against a zephyr. A zephyr automatically succeeds on saving throws to resist the effects of high wind. A zephyr is not blown around by wind even while air walking or wind walking unless it chooses to be.  

**Wind Walk (Su):** A zephyr constantly benefits from an effect similar to a _wind walk_ spell (caster level 20th), having the ability to assume a cloudlike form. The zephyr takes only a move action, rather than 5 rounds, to shift to or from mist form. While in mist form, the zephyr can’t use its natural armor bonus, hoof attacks, or land speed. It is 80% likely to be mistaken for a cloud or similar substance if it is the right color. It gains damage reduction 10/magic and immunity to poison and critical hits. It is subject to being blown around by wind (at a speed equal to that of the wind; multiply a speed in mph by 10 to get the distance the wind walking zephyr is blown in a round) unless it chooses not to. It may use this ability in conjunction with controlling the wind for great tactical effect. It gains two new fly speeds: 10 ft. (perfect) and 300 ft. (poor). It loses most supernatural abilities (such as its damage reduction and breath weapon), but retains its cloak of winds and its ability to control winds. If a zephyr loses consciousness while wind walking, it reverts to its physical form.  

A zephyr can affect up to one other creature with this ability by touching that creature while shifting to mist form, but the creature loses the effect the instant it ceases to touch the zephyr and cannot end the effect without ceasing to touch the zephyr. The effect also ends for the recipient if it ends for the zephyr, though the reverse is not true. A touched creature may resist the effect with a Will save (DC 22). The save DC is Charisma-based.  

**Tempest Stampede** (Mob of Zephyrs)  
Gargantuan Fey (Air, Mob of Large fey)  
**Hit Dice:** 30d6+180 (285 hp)  
**Initiative:** +0  
**Speed:** 70 ft., fly 70 ft. (average)  
**Armor Class:** 22 (-4 size, +9 Dex, +7 natural), touch 15, flat-footed 13  
**Base Attack/Grapple:** +15/+33  
**Attack:** Mob (5d6)  
**Full Attack:** Mob (5d6)  
**Space/Reach:** 20 ft./0 ft.  
**Special Attacks:** Expert grappler, trample 2d6+9  
**Special Qualities:** Air walk, cloak of wind, damage reduction 10/cold iron, immunity to electricity, low-light vision, mob anatomy, scent, wind mastery  
**Saves:** Fort +15, Ref +26, Will +17  
**Abilities:** Str 23, Dex 28, Con 22, Int 10, Wis 10, Cha 10  
**Skills:** Balance +11, Intimidate +15, Jump +28, Knowledge (nature) +17, Listen +15, Sense Motive +15, Spot +15, Survival +15 (+17 in aboveground natural environments), Tumble +24  
**Feats:** Dodge (B), Flyby Attack, Improved Bull Rush (B), Improved Flyby Attack, Improved Overrun (B), Mobility, Weapon Finesse, Weapon Focus (hoof)  
**Environment:** Any land  
**Organization:** Herd (1-2 with 2 zephyrs and 1d3 noncombatant young)  
**Challenge Rating:** 14  
**Treasure:** None  
**Alignment:** Often neutral  
**Advancement:** None  
**Level Adjustment:** –  

_You quickly recognize what at first sounds like thunder as the pounding of hooves. However, the sound is coming from above, not below. Soon, a storm wind whips down from the clouds overhead and a funnel shape descends with it. Then, the cloud is ripped away by the wind, revealing a swirling mass of equine features. It is a flying stampede, a dozen furious horses descending toward you in the howling winds of a tornado._  

A tempest stampede forms only to defend zephyr young and only if those defenders are outraged, such as if they see the young hurt.  

Zephyrs speak Sylvan and Auran.  

**COMBAT**  
If a zephyr herd is attacked, the parents will keep the young in between them, and will create a downdraft to blow enemies coming from all directions away from them.  

**Air Walk (Su):** A zephyr can always choose to walk on air as if with _air walk_ (caster level 20th).  

**Cloak of Wind (Su):** The cloak of winds of all of the zephyrs in a tempest stampede merge together into a single great cyclonic vortex 15 feet in diameter. Within this sphere, the wind is a circling pattern of tornado force, replicating the effects of _control winds_ (DC 27, caster level 30th). These effects cease if the tempest stampede dispurses. The save DC is Charisma-based, and includes a +2 racial bonus.  

A zephyr flies by commanding the wind very near its body to propel and support it. If the zephyr is knocked unconscious, winds automatically slow its fall as if with _feather fall_. A zephyr cannot run while flying.  

**Expert Grappler (Ex):** A mob can maintain a grapple without penalty and still make attacks against other targets. A mob is never considered flat-footed while grappling.  

**Mob Anatomy (Ex):** A mob has no clear front or back and no discernible anatomy, so it is not subject to critical hits or sneak attacks. A mob cannot be flanked, tripped, grappled, or bull rushed.  

A tempest stampede is made up of twelve zephyrs, which can be targeted normally by individually targeted spells and effects. For each member of the mob that is killed, disabled, or otherwise incapacitated, the tempest stampede suffers two negative levels. Because these negative levels do not result from negative energy, they cannot be prevented and cannot be removed by normal means, though they also cannot result in actual level loss. A mob takes half-again as much damage (+50%) from spells and effects that affect an area, such as splash weapons and _fireball_ or _cone of cold_ spells.  

If a mob is dispersed by damage, 30% of the members end up dead, 30% end up at 0 hit points, and 40% escape relatively unscathed.  

**Trample (Ex):** Reflex half DC 31\. The save DC is Strength-based.  

**Wind Mastery (Ex):** Airborne creatures take a -1 penalty on attacks and damage rolls against a zephyr. A zephyr automatically succeeds on saving throws to resist the effects of high wind. A zephyr is not blown around by wind even while air walking or wind walking unless it chooses to be.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *