# Fharlanghn, The Traveller
Dweller on the Horizon
Intermediate Deity

Fharlanghn is the god of travel and distance. While his younger brother Célestian strolls among the stars, this tireless traveler prefers to travel the four corners of the world. He is a well-known deity on the world of Oerth and it is said that he wanders that world in person.  
  
Fharlanghn reigns on the roads and offers security, good fortune and favorable weather to travelers who pray. As such, he is also considered by many to be the god of quests that require a long journey.

## Worshipers, Clergy & Temples

Fharlanghn is the patron of all those who travel long distances, whether on the surface or in the depths of the Underdark. His symbol is often seen in inns and stables across the continent of Oerik (the largest continent on Oerth). His followers include adventurers, merchants, vagabonds and travelers of all sorts.

### Clerics

Clerics of the Dweller on the Horizon travel to exotic lands, bless caravans, scout for armies, and record their experiences for others to learn from. They act as translators and diplomats, and help in the construction of roads, bridges, and hard-wearing shoes. They wander frequently, and seldom it is that one would encounter the same group of priests ministering at the same shrine.  
  
Because the road is the best teacher, initiates are trained in the ways of Fharlanghn by being taken on long trips. They are dismissed if they ask when the journey will be over, because to the faithful of Fharlanghn, the journey never really ends. Clerics of Fharlanghn are found throughout the world on various journeys, but are most active in the Central and Southwestern Flanaess.  
  
As long as they can, the Walkers travel the world in search of new sensations. They are adventurous and rarely shy away from danger, but they are not careless. They are affable, open-minded people, but they will defend themselves vigorously if they are molested. For them, imprisonment is worse than death and slavery is an abomination. They fight those who prevent the free movement of people and have no mercy on the slavers.  
  
The clergy are separated in two. The _Green Walkers_ (recognizable by their green robes) constitute the lifeblood of the clergy and are always wandering, offering their services to those they meet on the roads. The _Brown Walkers_ (dressed in a brown robes) are more sedentary, generally by obligation, no longer having the physical condition necessary to travel. The latter represent only about 10% of the clergy but are the oldest and have more responsibilities. They take care of the chapels and often hold a craft workshop, a stall or an inn.

### Vestments

Clerics tend to have their vestments constructed of durable material well suited to traveling. The Journeymen are particularly choosy regarding their boots or shoes, as they must be comfortable on long, walking treks. Traveling clerics tend to wear green robes, while those managing the temples wear brown. The temple colors are yellow, black and silver. Fharlanghn's favored weapon is the quarterstaff.  
  

### Hierarchy

Due to the church's interest in traveling and adventuring, advancement within the church occurs by gaining experience or conversion of followers during one's travels. Titles, from low-ranking to high, include: _Journeyman_, _Quester_, _Worlder_, _High Worlder_. A Worlder must have traveled at least 10,000 miles on foot or mount. A High Worlder must have traveled at least 50,000 miles, with at least 10,000 of that at sea.  
  
Matters of faith and doctrine are reached at rare and brief councils of the High Worlders (high-ranking priests), convened at Zhanehmish. The most traveled High Worlder wields the greatest influence over the calling of such councils and the resulting rulings, but all High Worlders who attend theoretically have an equal voice in the process.  
  

### Temples

The cult has never sought to erect a large temple to the glory of Fharlanghn because every road, path, country lane, are all testimonies of his majesty.  
  
Roadside shrines and sanctuaries to Fharlanghn can be found throughout the world, so that the faithful can pay homage to him without having to turn from their path. His symbol is often visible in the inns and stables that line the roads of Flannesse. Many cities, villages, and towns, including Greyhawk, have churches to the Dweller on the Horizon. Every road and trail is sacred to him, and instead of traveling to specific destinations, wandering itself is a sacrament for Fharlanghn's pilgrims.  
  

### Rituals

Religious services preferably take place outdoors, when the sun appears, or on the contrary on the point of disappearing, on the horizon. They are rather brief and stick to the essentials, not getting lost in complex rites and vain digressions. Prayers are essentially anecdotes, the narration of which is intended to serve as a lesson. Many of them involve an elderly man traveling with a young fool. The latter wanting, for example, to cross a river outside a ford or take the road while being badly fitted.  
  
Fharlanghn's faithful prefer to rely on the priests of other clergy to bless births and officiate at marriages and burials. On the other hand, they will not fail to ask the priests of Fharlanghn to bless them, as well as their mount and their carriage, before setting off, or even to bless a road structure, an inn or stable, whose construction has just been completed. They will also come to thank Fharlanghn, with a prayer and an offering, on the return from a long journey, a fruitful journey or a perilous adventure.  
  
**Eternal Pilgrimage**: This pilgrimage is made to celebrate the simple pleasure of traveling. It has no prescribed destination, route or even length. It lasts as long as the pilgrim feels is appropriate. The pilgrim must only travel by walking, and may not visit the same location more than once a day. They offer company to lonely travelers and always share their fires with strangers. Before starting this pilgrimage, the individual must first prepared his body and mind for a year, by walking at least two hours every day.  
  
It is not uncommon for pilgrims, recognizable by their gray dress and their highly decorated walking stick, to travel in groups of half a dozen and be led by a priest from Fharlanghn.  
  
Bandits who would take advantage of the pilgrims' friendly reputation to pose as one of them usually vanish, only bloodstained robes hanging from nooses by the side of the road remaining as evidence of the vengeance of the faithful.  
  
A holy day for Fharlanghn is the first day of spring, called the _Journey's First Step_, and it marks the beginning of friendlier travel weather. Worshipers give each other small gifts, usually a pair of shoes or a walking staff. Clerics lead a brief walk, usually a mile or so, around the town or city, attempting to see things in a new light or point out something new.  
  

### Orders

_The Guardians of the Road_ are fanatical worshipers of Fharlanghn who give away all their belongings and take to traveling full-time. They also seek to protect the secret of Journey's End.  
  
The _Striders of Fharlanghn_ are a neutrally-aligned organization dedicated to the destruction of the Cagewrights.

## Dogma

You have to travel and discover new things. Always be ready to go, because the world can change overnight and you may suddenly need a new home or new perspectives. To find inspiration, turn to the horizon; the end of the world is home to new peoples, new cultures, new enchantments and new routes to take. Any road, street or path is a precious gift from Fharlanghn.  
  
Open-mindedness is key. When you go from one place to another, you have to be open to all lifestyles, all cultures and all currents of thought. Those who embark on the road cannot allow themselves to be obtuse, at the risk of seeing all the roads close in front of them. Of course, we may not approve of all the routes, but we must grant them the courtesy of a minimum of consideration for their existence.  
  
Each quest follows a path, and the only way to complete the task at hand is to follow that path until its ultimate end. Of course, the more important the quest, the more winding the road and the more the secondary roads will be far from the real goal. Going right on these paths will be the key to success.