# Azuth Lord of Spells
The High One, Patron of Mages, Lord of Spells  
**Lesser Deity  
Symbol:** Human left hand pointed upward and outlined in blue fire  
**Home Plane:** Dweomerheart  

**Alignment:** LN  
**Portfolio:** Wizards, mages, spellcasters in general, monks (Shining Hand)  
**Worshippers:** Monks (Shining Hand), philosophers, sages, sorcerers, wizards  
**Cleric Alignments:** LE, LG, LN  

**Domains:** Illusion, Knowledge, Magic, Law, Spell  
**Favored Weapon:** “The Old Staff” (quarter staff)  

**Wizard 35/ Arcane Devotee 5/ Archmage 5/ Loremaster 10  
Divine Rank:** 10  

**Medium Outsider (Extraplanar, Lawful)  
Hit Dice:** 35d4+ 5d4+ 5d4+ 10d4+ 275 (515 hp)  
**Initiative:** +13  
**Speed:** 60 ft.  
**Armor Class:** 74 (+9 Dex, +25 natural, +8 armor , +11 deflection, +10 divine, +1 dodge), touch 41, flat-footed 64  

**Base Attack/Grapple:** +28/+35  
**Attack:** Old Staff +51 (1d8+16 and special)  
**Full Attack:** Old Staff +51/+46 (1d8+16 and special)  
**Space/Reach:** 5 ft./5 ft.  

**Special Attacks:** Domain Powers, high arcana (arcane fire), salient divine abilities, spell-like abilities, spells  
**Special Qualities:** DR 20/epic and mithral, divine aura (DC 31), divine immunities, divine shroud, enlarge spell 12/day, fire resistance 20, godly realm, greater lore, greater teleport and planeshift at will, high arcana (mastery of counter spelling, mastery of elements, mastery of shaping, spell power), lore (+31 on the check), remote communication, sacred defense +2, secrets (applicable knowledge, dodge trick, lore of true stamina, secret knowledge of avoidance, secrets of inner strength), SR 72, spontaneous divine spells, speak read and understand all languages and speak directly to all beings within 5 miles, true lore  
**Saves:** Fort +40, Ref +44, Will +51  
**Abilities:** Str 24, Dex 28, Con 20, Int 53, Wis 30, Cha 33  
**Skills:** Appraise +38, Bluff +40, Concentration +65, Craft (alchemy) +79, Decipher Script +76, Diplomacy +42, Gather Info +45, Intimidate +40, Knowledge (arcana) +89, Knowledge (architecture and engineering) +79, Knowledge (geography) +79, Knowledge (history) +79, Knowledge (local) +79, Knowledge (nature) +79, Knowledge (nobility and royalty) +78, Knowledge (planes) +79, Knowledge (religion) +79, Listen +39, Search +51, Sense Motive +39, Spellcraft +81, Spot +39, Use Magic Device +46  

**Feats:** Brew Potion , Combat Casting {b}, Craft (magic arms and armor, rod, staff, wand, wondrous item), Create Portal, Empower Spell {b}, Eschew Materials, Extend Spell, Forge Ring, Greater Spell Penetration, Heighten Spell {b}, Improved Counterspell, Improved Initiative, Maximize Spell {b}, Quicken Spell {b}, Reactive Counterspell, Scribe Scroll {b}, Spellcasting Prodigy, Spell Girding {b}, Spell Penetration, Twin Spell  
**Epic Feats:** Enhance Spell {b}, Epic Spellcasting, Ignore Material Components {b}, Intensify Spell {b}, Multispell x3 {b}  
**Environment:** Warm plains  
**Organization:** Solitary (unique)  

**Challenge [Rating:** 50  
**Treasure:** See below  
**Alignment:** LN  

**Domain Powers:** Casts divination, illusion, and law spells at +1 caster level, treats all knowledge skills as class skills, uses magic items as a 65th level wizard, has a +2 bonus on concentration and spellcraft checks  
**Salient Divine Abilities:** Arcane Mastery, Automatic Metamagic (quicken spell-like abilities), Automatic Metamagic (twin spell-like abilities), Automatic Metamagic (twin wizard spells), Control Creatures (10/creatures per day that can cast spells or use spell-like abilities, will save DC 31), Craft Artifact, Divine Blast (14/day, 21d12 damage), Divine Spellcasting, Extra Domain (Illusion), High Magister*, Instant Counterspell, See Magic.  
*Unique SDA described below.  
**High Magister [unique salient divine ability]:** The Lord of Spells fills a role as a deity of magic similar to the role mortal Magisters play. As such, he receives similar (and more powerful) benefits of his position. They are as follows:  

Firstly, Azuth is immune to the following spells and effects that duplicate them, even if the caster has a higher DvR: _bestow curse, chill touch, detect thoughts, disintegrate, finger of death, hold monster, horrid wilting, vampiric touch,_ and _wish._  

Second, he can step through any magical barrier as if it did not exist. This does not destroy the barrier, the he simply passes through it.  

Third, he has the benefits of the Greater and Epic Spell Focus feats for every spell he casts. He can prepare and cast clerical spells granted specifically by him (such as _Azuth’s Exalted Triad_ or _Azuth’s Spell Shield_) through his wizard spell slots as though they were arcane spells.  

Lastly, he has a +10 bonus on any saving throw versus spells, and a +10 bonus on Knowledge (arcana) and Spellcraft checks.  
**Spell-like Abilities:** At will— _antimagic field, anyspell, break enchantment, calm emotions, clairaudience/clairvoyance, detect secret doors, detect thoughts, dictum, discern location, dispel chaos, dispel magic, displacement, divination, find the path, foresight, greater anyspell, hold monster, identify, imbue with spell ability, legend lore, limited wish, mage armor, mage's disjunction, magic aura, magic circle against chaos, minor image, mislead, mnemonic enhancer, order's wrath, persistent image, phantasmal killer, project image, protection from chaos, protection from spells, screen, shield of law, silence, silent image, spell resistance, spell turning, summon monster IX (law only), true seeing, weird._ Caster level 65th (76th for divination, illusion, and law spells). Save DC 58 + spell level.  
**Spells:** Azuth casts spells as a 55th level wizard.  

_Wizard spells/day_ (levels 0-22): 4/10/10/9/9/9/8/7/7/7/5/4/4/4/4/3/3/3/3/2/2/2/2\. Save DC 57+ spell level. Caster level 56th. Casts divination, illusion, and law spells at 57th caster level.  

When wearing his ring (see below), his spells per day change as follows:  

(levels 0-22): 4/14/14/13/13/13/12/11/11/11/6/5/5/5/5/4/4/4/4/3/3/3/3.  

**Possessions:** Azuth wields _Old Staff_, a staff of great power. This weapon functions as a _+6 quarterstaff_ in combat. One end of the staff affects those who are struck by it as a _Mordenkainen's Disjunction_ spell, DC 51\. The other end drains 1d4 spells from a spellcaster's mind (or unused spell slots, for those who spontaneously cast their spells) upon striking.  

The Old Staff can release a cloud of magical missiles, these follow the rules for _magic missile_ except as follows: Each missile deals 1d4+10 points of damage. 10 missiles are released per charge drained from the staff.  

The Old Staff can produce a highly metamagicked version of either _lightning bolt_, _cone of cold_ or _fireball._ Both spells deal 20d6 points of each type of energy damage. (Acid, cold, electricity, fire and sonic) The ball version of the spell covers a 40' radius, the bolt version covers a 10' wide line, the cone version covers a 120' cone. The DC for either version is 51\. This power drains 4 charges from the staff.  

The Old Staff can also cast of all the standard spells as listed under the _staff of power_'s description in the DMG. The saving throw for any spell is 51.  

The Old Staff holds 100 charges, and these are replenished daily. The Old Staff can be broken as a Staff of Power for a retributive strike, with damage and radius doubled. (DC 51 for half) The Old Staff reforms itself in 1d10 years after being broken in such a manner. The Old Staff is a Major Artifact. It can only be destroyed by declaring a retributive strike upon Mystra (or the current Mistress of the Weave) that suceeds in slaying her.  

Azuth also wields a wand with the properties of a _Staff of the Magi_. This is enchanted with the Everdancing property, so it can be released to cast its spells on its own. By expending 4 additional charges, the wand can cast a spell as a quickened action. When the wand is reduced to below 30 charges, it automatically lowers its SR 23 to absorb incoming spells. The wand will never absorb spells if it has more than 30 charges. The wand's spells have a DC of 35+spell level. The wand has an AC of 40 if an attempted Sunder is performed. (+4 size, +10 dex, +10 natural, +6 deflection) It has a hardness of 25 and 100hp.  

He also wears the _Ring of All Spells_ (which acts as a _ring of epic wizardry_ except that it doubles spells per day for all levels the wearer can cast), and _The Robe of the High Mage_ (which provides a +8 armor bonus and acts as a _rod of epic absorption_).  

**Other Divine Powers**  
As a lesser deity, Azuth may take 10 on any check and he treats a 1 on an attack roll or saving throw normally and not as an automatic failure. He is immortal.  
**Alter Reality:** Azuth can, as a standard action, use _limited wish_ with regards to his portfolio, though he cannot duplicate spells. He can _alter size_ to sizes between tiny and gargantuan. He adds once again his relevant ability modifier to DCs when casting spells. 10/day he can add +11 to his caster level for one round.  
**Senses:** Azuth can hear, touch, and smell at a distance of ten miles. As a standard action, he can perceive anything within ten miles of his worshipers, holy sites, objects, or any location where one of his titles or name was spoken in the last hour. He can extended his senses to up to two locations at once. He can block the sensing power of deities of his rank or lower at up to five remote locations at once for up to ten hours.  

**Portfolio Sense:** Azuth senses the discovery, transcription, and casting of every spell in Faerun as long as it affects at least five hundred people.  
**Automatic Actions:** Azuth can use any Knowledge skill or Spellcraft as a free action so long as the DC for the task is 20 or lower. He can perform up to five such free actions each round.  
**Create Magic Items:** Azuth can create any type of magic item as its cost is less than or equal to 30,000 gp.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.  

* * *