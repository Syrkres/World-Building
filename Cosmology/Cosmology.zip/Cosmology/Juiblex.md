# Juiblex - Demon Prince of Ooze
Demon Prince of Ooze, The Faceless Lord  
Huge Outsider (_Chaotic, Evil, Extraplanar_)  

Hit Dice: 60d8 (outsider) plus 10d12 (legendary dreadnaught) plus 1004 (1604 hp)  
**Initiative:** +19 (+11 Dex, +8 Superior Initiative)  
**Speed:** 100 ft., swim 100 ft., climb 100 ft., burrow 100 ft., run 500 ft.  
**AC:** 65 (-2 size, +11 Dex, +25 natural, +9 profane, +12 deflection), touch 42, flat-footed 54  
**Base Attack:** +65/+90  
**Attacks:** 6 pseudopods +83 or slam +80 or ranged touch +76 or melee touch +80  
**Full Attack:** primary pseudopod +83 (3d6 plus +17 plus 3d6 (acid) plus 1 (vile)/19-20) and 5 secondary pseudopods +83 (3d6 plus +8 plus 3d6 (acid) plus 1 (vile)/19-20) or slam +80 (2d6 plus +17 plus +3d6 (acid) plus 1 (vile)) or ranged touch +76 or melee touch +80  
**Face/Reach:** 10 ft. by 10 ft.  
**Special Attacks:** Abyssal Fury, Call Demons, Curse of the Faceless, Fission, Gelatinous Conversion, Maw of Dissolution, Ravaged Forms (Acidic Body, Ooze Touch, Spit Ooze)  
**Special Qualities:** Blindsight 60 ft., Corrupting Presence, DR 25/cold iron and good and DR 6/-, Demon Prince Qualities, immunity to electricity, acid, and poison, Ravaged Forms (Amorphous, Slime Trail), regeneration 14/+3 cold iron or good, resistances (fire, cold) 20, shrug off punishment, SR 55, unmovable, unstoppable, thick skinned  
**Saves:** Fort +50, Ref +49, Will +48  
**Abilities:** Str 44, Dex 32, Con 38, Int 23, Wis 22, Cha 34  
**Skills:** Bluff +31, Climb +64, Concentration +33, Hide +26, Intimidate +70, Knowledge (arcana) +30, Knowledge (the planes) +30, Knowledge (dungeoneering) +30, Listen +38, Move Silently +30, Search +30, Sense Motive +30, Spellcraft +34, Spot +38, Survival +30 (+34 extraplanar, +34 underground)  
**Feats:** Combat Reflexes, Corrupt Spell-like Ability (/cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, Empower Spell-like Ability (_disintegrate_), Great Cleave, Improved Bull Rush, Improved Critical (pseudopods), Improved Initiative, Improved Multiattack, Improved Natural Attack (pseudopods), Improved Overrun, Multiattack, Power Attack, Run, Vile Natural Strike (/cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, Violate Spell-like Ability, Weapon Focus (pseudopods)  
**Epic Feats:** Blinding Speed, Dire Charge, Epic Speed, Epic Weapon Focus (pseudopods), Improved Combat Reflexes, Penetrate Damage Reduction (mithral), Penetrate Damage Reduction (adamantine), Spellcasting Harrier, Superior Initiative  
**Climate/Terrain:** The Slime Pits (Layer 222 of the Abyss) or Any Land and Underground  
**Organization:** Solitary or troupe (Juiblex and 4-8 Oozes/Jellies of various types)  
**Challenge Rating:** 47  
**Treasure:** Quadruple Standard  
**Alignment:** Chaotic Evil  
**Advancement:** N/A  

Juiblex The Faceless. Often referred to derisively, Juiblex is an ancient and formless foulness that many other creatures in the Abyss, as well as outside the Abyss, underestimate...at least at first.  

One persistent rumor for Juiblex’s origins is that he is a failed attempt by one of the other Demiurge to create a Paragon Balor; an attempt that failed so badly that Juiblex, instead of becoming a Paragon, became the complete opposite of such ‘perfection’-a being so imperfect, so flawed, that it was, if anything, more ‘unfinished’ than the Slaad to the point where it could barely maintain a physical form, yet infused with the same horrific evil as the being it should have ended up as. Nobody has ever asked Juiblex or the most likely Demiurge to be responsible their opinions on this theory, for rather obvious reasons.  

A second rumor is that Juiblex is some form of younger sibling of the even more destructive and bizarre Demiurge Zuggytmoy, Demon Queen of Parasites. This rumor has as evidence for it’s contention that Juiblex is often very closely associated with her, to the point where they share the same layer of the Abyss.  

Juiblex’s only ally in the Abyss is Zuggytmoy. Both of them have wrought destruction across the planes for tens, if not hundreds, of thousands of years, and they are so closely associated that they are practically synonymous in the minds of those individuals that are not more familiar with both of them. In terms of the rest of the Abyssal Lords, they tend to give Juiblex a generally wide berth because as far as they can tell, Juiblex has nothing that they want, and even if he did have something they wanted, it would generally have dissolved in his maw so quickly as to not make the trouble of trying to get it from him ‘worth it’. Beings that take emnity to Juiblex generally discover rapidly that the Formless Lord is far more formidable than his revolting appearance and general lack of complex actions at first belie.  

Beyond Juiblex’s mortal worshippers, various other creatures also find themselves paying homage to the Faceless Lord, either willingly or less willingly. A sizable percentage of Aboleths and Ropers worship it, bringing Juiblex into constant conflict with their normal patrons. The raw destructive power of Juiblex, however, has so far proved more than sufficient to stop either of the servitors of his rivals from interrupting his claims.  

Juiblex is too oblivious of anything except his constant need to dissolve the landscape, cause pain and suffering to beings considerably less formless than itself, and spawn ooze to be particularly ambitious. The period of Zuggytmoy’s forced incarceration in the Temple of Elemental Evil just meant, to it, that there was more land for it to patrol, and more oozes to create. It was during this period that the Alkiliths first came into existence; if Juiblex did manage to create them, or whether they are the creations of one of his more insane servants (or if they are transformed versions of his more insane servants) also remains unknown. If Juiblex resents the return of Zuggytmoy to The Slime Pits, there seem to be little or no indications of such resentment in it’s behavior.  

Juiblex currently resides in an area of The Slime Pits (Layer 222 of the Abyss) known as the Amoebic Sea, a vast and fetid subterranean expanse made of nothing but various species of ooze, slime, and even more bizarre creatures through which Juiblex swims and gurgles, accompanied by an uncountable array of lesser creatures created or warped into it’s hideous image.  

Juiblex looks like a large puddle of stinking slime and black oil approximately 10 feet in radius and three feet tall. When it chooses to rear itself up into full height, it is a revolting 12 foot tall column constantly splattering bits of itself around and dripping onto the ground, with six pseudopods that it uses alternately as limbs to smash opponents or to run upon. To observe it in motion is to observe the indescribable as often it shifts between having limbs and oozing across the ground simoultaneously.  

**Combat:** To be attacked by Juiblex is a horrifying experience because of the fact that it is the antithesis of expectations. It is incredibly fast, ever shifting it’s body and closing the distance with it’s enemies which it then pummels to death or even worse, simply dissolves into it’s mass. Juiblex will always open combat by increasing it’s already amazing speed, followed by a dire charge or greater teleport in order to close the distance, followed by engulfing it’s prey.  

**Ravaged form-Acidic body:** Regardless of what Juiblex may look like at any given moment, his flesh is extremely destructive to matter and constantly exudes acidic vapors that cause 4d8 acid damage/round to everything within 10 feet of it. Juiblex’s touch is additionally acidic, doing 3d6 acid damage with each contact or hit. This stacks with the damage from whichever slime, ooze, or jelly he is currently appearing as (see below). It is immune to any form of acid-based attack.  

**Ravaged Form-Amorphous:** Juiblex has no permanent anatomical features to speak of, nor any type of ‘musculature’. At the same time, Juiblex may squeeze himself through any opening or aperture larger than one foot in radius or width, although doing so halves his speed.  

**Ravaged Form-Ooze Touch:** Juiblex may change it’s appearance into that of any other form of ooze, jelly, or slime as a free action. When it does this, it inflicts the damage that would be caused by that particular form of ooze, jelly, or slime, as well as gains any additional properties of that particular type (ie, if Juiblex decided to become a flesh jelly, it would gain the absorb attack property in addition to it’s own).  

**Ravaged form-Ooze traits:** Juiblex is immune to all mind-affecting effects. He is blind, but has blindsight within 60 feet and is additionally immune to gaze attacks, visual effects, illusions, and other attack forms that rely on sight. He is immune to sleep effects, paralysis, polymorph, and stunning. Juiblex is not subject to critical hits or flanking.  

**Ravaged Form-Slime Trail:** The trail of slime and goo is capable of causing destruction long after the passage of the Faceless Lord. This has two different effects:  

The trail left behind attracts and compels oozes and similar lifeforms into following their prince. As such, any ooze or jelly with fewer than 35 HD that crosses Juiblex’s path begins to follow him, and if within 500 feet, may be commanded by him.  

Any solid land that Juiblex walks or oozes over is instantly turned into corrosive mud. Forever incapable of supporting normal plant life, non-ooze creatures in direct contact with this vile substance take 1d6 acid damage/turn. Juiblex’s destructive effects upon the landscape can only be reversed by _transmute mud to rock_ cast by a 21st level caster or higher, followed by a _consecrate_ spell.  

**Ravaged form-Spit ooze:** 6 times a day and once every 1d4 rounds, Juiblex may spit a line of green, viscous, ooze at it’s opponents, doing 30d10 damage (Ref save DC 49 for half, treat as a line of acid).  

**Spell-like abilities (Sp):** at will: _blasphemy, contagion, deeper darkness, destruction, detect law, dimensional anchor, disintegrate, dominate monster, greater dispel magic, greater teleport, harm, inflict critical wounds, insanity, power word stun, ray of enfeeblement, seething eyebane, stone to flesh, telekinesis, transmute rock to mud, unhallow, unholy aura, unholy blight, wall of ooze_. 6/day: _bestow curse, horrid wilting, implosion, rotting curse of ur-festra._ 3/day: _power word, kill._ 1/day: _death by thorns, ruin, spell worm._ 1/week: _gate, greater ruin, phase door._ Juiblex casts spells as a 76th level Sorcerer. The saving throws against Juiblex’s spells are DC 22+the level of the spell. The saving throws are Charisma-based.  

**Call Demons (Sp):** Two times a day Juiblex may call up to 50 HD of Demons to aid it. The predominant choices are hezrou and alkiliths, which worship him as their creator, although he has no hesitations about calling Balors if facing significant opposition.  

**Fission (Sp):** Juiblex may bud pieces of itself off which grow at a vastly accelerated rate into oozes of whichever type he desires. He may do this two times a day and create up to 50 HD of additional oozes, jellies, and cubes in this manner. Common choices are flesh jellies, gelatinous cubes, and black puddings.  

**Abyssal Fury (Ex):** Juiblex’s physical presence is so disgusting that is causes lesser creatures to succumb to his hate and need to spread destruction and terror. All creatures within 60 feet of Juiblex must succeed in a Will save 57\. Those who succumb to Juiblex’s gross presence suffer one of the two following effects:  

_Fright:_ Affected beings become shaken and suffer a –2 morale penalty on attack rolls, saves, and checks. The merest glance or gesture by Juiblex makes them frightened, and they flee as quickly as they can, although they can choose the path of their flight.  

_Madness:_ The grotesque evil incarnate in Juiblex’s being drives lesser beings insane per the insanity spell. The being remains stuck in a state of madness for one day for every point by which she failed the saving throw, after which time the victim is allowed another save. The madness exists until the victim successfully saves or the appropriate spells are cast by a 21st level being to purge the insanity effect.  
Juiblex can make his servants, “worshippers,” beings of Chaotic Evil alignment, or a mixture of all three types immune to this effect as a free action. This immunity lasts one day or until Juiblex dismisses it. However, Juiblex cannot determine which effect takes place; there is a 50% chance each time Abyssal Fury is used that one or the other effect will impact near by victims.  

Demigods and higher ranked divine beings are immune to Juiblex’s Abyssal Fury.  

**Corrupting Presence (Su):** Juiblex’s presence is so heinous that it may corrupt an entire area with but a thought. Once per day as a standard action, Juiblex may unhallow an area with a radius equal to 2450 feet centered around it. Juiblex can apply the following spells to the unhallow effect (some of which are not listed as part of the unhallow spell in the Player’s Handbook): bane, bestow curse, contagion, deeper darkness, dispel magic, silence. In most situations, Juiblex will select dispel magic.  

The forces of righteousness disgust Juiblex, who finds goodness repellent enough to give it pause. As a result, Juiblex avoids hallowed ground. If Juiblex finds it necessary to enter a hallowed site, it must make a Will DC save equal to 40 + the divine rank of the represented god + the god’s Charisma modifier; Juiblex cannot use it’s spell resistance to overcome this effect. If Juiblex succeeds in entering the hallowed area, the area immediately becomes unhallowed. Once Juiblex breaches holy ground, the god in question is immediately alerted to his presence and will often (DM’s discretion) send a proxy or an avatar to deal with the intrusion.  

**Demon Prince Qualities (Ex):** Juiblex is immune to electricity and poison; he possesses cold and fire resistance 20\. Juiblex may engage in telepathic communication with any creature within 100 feet. Juiblex constantly detects good, detects magic, and true sees as a 31st level Sorcerer; he possesses immunity to polymorphing, petrification, or any other attack to alter his form. Juiblex is not subject to energy drain, ability drain, or ability damage; he is also immune to mind-affecting effects. Juiblex additionally possesses regeneration 14 unless struck by a cold iron or holy weapon of at least +3 enhancement.  

Juiblex can sense anything within one mile around the mentioning of his name, titles, or an item of importance to him. This power is barred from places associated with gods of goodness, the personal redoubts of Demiurges or any being that possesses divine rank or virtual divine rank.  

Juiblex is immortal and cannot die from natural causes; it does not age, and does not need to eat, sleep, or breathe.  

**Divine Interloper (Ex):** As disgusting as it might be for many to believe, Juiblex does actually have mortal, non-Demonic worshippers. They share little in the way of common denominators except for the fact that somewhere in their lives, their minds became unhinged to the point where oozes and slimes became more attractive company than anything else, and from that crack in the wall of their sanity, Juiblex managed to sneak in as he would slither through such cracks in real life Juiblex’s worshippers are known through titles such as Thralls of Juiblex or Faceless Servants, and he may grant them spells from the domains of Chaos, Evil, and Water. Cults of Juiblex worshippers please their Prince by offering sacrifices to him through oozes and jellies infused with a bit of his ancient evil. Far more appalling is their practice of kidnapping individuals that they think would make good ‘recruits’, and after casting sufficient spells on them to ensure they survive the glorious transformation (from their perspective), immersing them in the same ooze until they break down from the horror of the experience.  

**Shrug off Punishment (Ex):** Juiblex gains an extra 24 hit points.  

**Thick Skinned (Ex):** Juiblex has an additional damage reduction of 6/-.  

**Unmovable (Ex):** Twice a day, Juiblex can concentrate his power, making him unmovable. This power grants it a +20 bonus on any one of the following:  

A grapple check made to avoid being grabbed with the improved grab ability.  
A Strength check to avoid the effects of a bull rush, trip attempt, or similar effect.  
A Strength check against any effect that would move the character either physically or magically.  
Any one saving throw. If an effect that would move the character either physically or magically does not normally allow a saving throw, the legendary dreadnought can use this ability to gain a Will saving throw. He or she still gains the +20 bonus on the saving throw in such a case.  

**Unstoppable (Ex):** Twice a day, Juiblex can concentrate it’s power, gaining a +20 bonus on it’s Strength check to break or burst a door or item. As a special use of this ability, it can attempt to break a _wall of force_ (Strength DC 32, and it applies his unstoppable bonus to this check as well). Alternatively, it can apply the +20 bonus to a single attack roll.  

**Curse of the Faceless (Su):** Six times a day, Juiblex may force everyone within 500 feet of it to roll a Fort save DC 51\. Should they fail then their face is instantly removed from their body, rendering them simoultaneously blind, unable to eat or speak, unable to smell, and unable to breathe. Victims of the Curse of the Faceless will immediately start suffocating under standard rules. The Curse of the Faceless is permanent unless removed through the use of a _wish_ followed by a _restoration_ spell cast by a 21st-level or higher Cleric.  

**Gelatinous Conversion (Su):** Twelve times a day, Juiblex may attempt to infest others with it’s slime. Should a target be successfully grappled, Juiblex may insert a set of it’s pseudopods down the nose and throat of any creature that it is in contact with. Each round a target must make a Fort save DC 45 or else take 1d4 Charisma and 1d4 Wisdom drain as their flesh turns transparent while Juiblex is attached to them. Should a victim ever reach 0 Wisdom or Intelligence, then they must make a final Fort save DC 45 or else Juiblex pulls their skeleton out of their still-living body, transforming them into a Gelatinous creature permanently enthralled to Juiblex.  

**Maw of Dissolution (Ex):** Regardless of what form Juiblex is in, he may always choose to engulf any opponent or object that he may grasp with it’s pseudopods. Creatures and objects engulfed in this manner take 6d6 acid damage and 6d6 unholy damage per round that they have been absorbed; in the case of objects, this damage bypasses their hardness and damages them directly. Beings that are completely consumed through the Maw of Dissolution are unraisable except through the use of a _wish_ followed by a _restoration_ spell cast by a 21st level caster or above. Without the use of the restoration spell, beings resurrected will otherwise be returned to life totally insane from the experience of dying in this manner. Juiblex may engulf any creature one size category smaller than itself or lower.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *