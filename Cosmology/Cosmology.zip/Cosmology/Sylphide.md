# Sylphide
Small Fey (Air)  
**Hit Dice:** 4d6-4 (10 hp)  
**Initiative:** +1  
**Speed:** 30 ft., fly 90 ft. (good)  
**Armor Class:** 12 (+1 Dex, +1 size), touch 11, flat-footed 11  
**Base Attack/Grapple:** +2/-4  
**Attack:** Unarmed strike +1 melee (1d2-2 nonlethal) or spell +1 touch or spell +4 ranged touch  
**Full Attack:** Unarmed strike +1 melee (1d2-2 nonlethal) or spell +1 touch or spell +4 ranged touch  
**Face/Reach:** 5 ft./5 ft.  
**Special Attacks:** Spells  
**Special Qualities:** Airy body, damage reduction 5/cold iron, greater invisibility, low-light vision, spell resistance 19  
**Saves:** Fort +0, Ref +5, Will +7  
**Abilities:** Str 7, Dex 13, Con 8, Int 15, Wis 16, Cha 17  
**Skills:** Concentration +6, Escape Artist +8, Hide +12, Listen +10, Knowledge (nature) +9, Knowledge (the planes) +9, Move Silently +8, Spot +10, Survival +3 (+5 in aboveground natural environments and on other planes)  
**Feats:** Dodge, Empower Spell  
**Environment:** Any mountains  
**Organization:** Solitary  
**Challenge Rating:** 4  
**Treasure:** Standard  
**Alignment:** Usually neutral  
**Advancement:** 5-7 HD (Small)  
**Level Adjustment:** +6  

_This being resembles a very small human woman with gossamer wings._  

Sylphides are strongly tied to air. In fact, they once belonged to the race of air protogenoi known as sylphs. Now, the sylphides are fey associated with breezes, cool or calm air, static electricity, and minor air disturbances. Due to their racial history, they still feel some kinship with air elementals. They sometimes try to convince elementals to follow them in joining the natural order.  

Sylphides are very curious, and are fond of physical affection (particularly from mortal males). Their curiosity will sometimes lead them into trouble. Though they prefer to live in mountains, they are found away from home more often than not.  

Sylphides largely ignore the Two Courts, though they are avid participants in the Court of Winds. They love to socialize almost as much as they love to explore. Though they don't form family groups after they reach maturity (about age 800), sylphides like to keep in touch with their family members with visits every few decades and gatherings every century or so.  

Sylphides who fulfill their normal life cycle live about 10,000 years. Once a sylphide reaches middle age (4,000), she ceases to age normally until she fulfills the rite of passage to become a gaoth sidhe. During this time, she approaches death by old age at triple the normal rate, and will become sickly and die of old age by her 6,000th birthday without looking a day older than on her 4,000th. While sylphides can have children as soon as they are mature, they typically avoid doing so until they are ready to become gaoth sidhe.  

A sylphide appears as a small, lovely human woman with translucent, brightly colored wings.  

Sylphides speak Auran, Common, and Sylvan.  

**COMBAT**  
A sylphide avoids physical combat at all costs and relies on her spells to defend herself. Sylphides rarely carry weapons.  

**Airy Body (Ex):** A sylphide can transform parts of her body into a thin vapor which can flow away to avoid attacks. Any time that a sylphide is struck by a weapon, she may attempt a Reflex save (DC = attack roll). If she succeeds, the attack automatically misses.  

**Greater Invisibility (Su):** A sylphide remains invisible even when she attacks. This ability is constant, but the sylphide may suppress or resume it as a free action.  

**Spells:** A sylphide casts spells as a sorcerer with a level equal to her Hit Dice.  
_Typical sorcerer spells known_ (6/7/4; save DC 13 + spell level): 0—_daze, detect magic, dancing lights, ghost sound, mage hand, ray of frost;_ 1st—_chill touch, shocking grasp, sleep;_ 2nd—_gust of wind._  

**Gaoth Sidhe**  
Medium Fey (Air)  
**Hit Dice:** 8d6+16 (44 hp)  
**Initiative:** +2  
**Speed:** 30 ft., fly 90 ft. (good)  
**Armor Class:** 16 (+2 Dex, +4 natural), touch 11, flat-footed 11  
**Base Attack/Grapple:** +4/+6  
**Attack:** Slam +6 melee (1d4+2) or spell +6 touch or spell +6 ranged touch  
**Full Attack:** Slam +6 melee (1d4+2)  
**Face/Reach:** 5 ft./5 ft.  
**Special Attacks:** Faerie wind, spells  
**Special Qualities:** Damage reduction 10/cold iron, _fertile rain_, greater invisibility, low-light vision, resistance to cold 10 and electricity 10, resistance to wind, soothing mist, spell resistance 23  
**Saves:** Fort +2, Ref +8, Will +10  
**Abilities:** Str 14, Dex 14, Con 14, Int 16, Wis 18, Cha 18  
**Skills:** Concentration +15, Diplomacy +6, Escape Artist +13, Hide +13, Listen +15, Knowledge (nature) +14, Knowledge (the planes) +14, Move Silently +13, Sense Motive +15, Spot +15, Survival +4 (+6 in aboveground natural environments and on other planes)  
**Feats:** Dodge, Empower Spell, Eschew Materials  
**Climate/Terrain:** Any forests, hills, or mountains  
**Organization:** Solitary, with child, or with 2d4 sylphides  
**Challenge Rating:** 8  
**Treasure:** Standard  
**Alignment:** Usually neutral  
**Advancement:** 9-15 HD (Medium)  
**Level Adjustment:** +8  

_This being resembles a motherly human woman with small gossamer wings._  

When a sylphide reaches middle age, she participates in a rite of initiation to become a gaoth sidhe, which requires her to become pregnant and give birth. The new gaoth sidhe must care for her sylphide child until she is grown and leaves home. This process causes a gaoth sidhe to become better integrated into nature and leads to a deviation from pure air to include life-giving water. Gaoth sidhe are associated with protection, biting winds, rain showers, and curses.  

Gaoth sidhe are cautious and protective of their children. A gaoth sidhe will rarely stray far from home, and repulses all those who came near other than her friends. She usually makes her home in secluded forests, hills, or mountains, but often chooses areas that are under the protection of fey gentry, such as daoine sidhe. A gaoth sidhe builds a fairy mound for her home, or finds an uninhabited one to live in. Once a gaoth sidhe’s child is reared, she usually goes on to become a leader in sylphide social circles and often in the Court of Winds.  

Sometimes a gaoth sidhe chooses to have additional children after her first is grown, but it is rare for one to rear multiple children at once. To satisfy her child’s need for socialization, a gaoth sidhe will sometimes kidnap mortal children for short periods, but she always returns them within a day.  

Gaoth sidhe largely ignore the Two Courts, though they are avid participants in the Court of Winds and in regional courts when their familial commitments do not prevent them.  

A gaoth sidhe appears as a strong human woman of middle age with vestigial insectoid wings. She wears functional but elegant clothes and has pale skin.  

Gaoth sidhe speak Auran, Common, and Sylvan.  

**COMBAT**  
A gaoth sidhe avoids physical combat and relies on her spells to defend herself. However, she will enter melee with her mild physical strength if necessary to protect her child.  

**Faerie Wind (Su):** A gaoth sidhe can create a line-shaped blast of piercing wind 80 feet long as a standard action. All creatures in the area suffer 8d6 cold damage unless they succeed on a Reflex save (DC 18) for half damage. Each creature must also succeed on a Will save (DC 18) or suffer the effects of _bestow curse_ at caster level 8th. The range, damage dice, and caster level are Hit Dice-based; the save DCs are Charisma-based.  

**_Fertile Rain_** _(Sp):_ Once per week as a full-round action, a gaoth sidhe may create rainy weather, but not a thunderstorm, as per _control weather_ (as a druid, caster level 8th). The effect manifests after only 5 rounds and the gaoth sidhe may not redirect or dismiss it. At the end of the shower (if the effect was not disrupted), the entire area is affected as if by the _enrichment_ function of _plant growth_ (caster level 8th). The caster level is Hit Dice-based.  

**Greater Invisibility (Su):** A gaoth sidhe remains invisible even when she attacks. This ability is constant, but the gaoth sidhe may suppress or resume it as a free action.  

**Resistance to Wind (Ex):** A gaoth sidhe receives a +4 racial bonus on saving throws against air and wind effects. Reduce all damage dealt to the gaoth sidhe by air and wind effects by 10 points.  

**Soothing Mist (Su):** As a standard action once per day, a gaoth sidhe may create a cylindrical region of misty rain 80 feet in diameter and 160 feet tall centered on her. Within the mist, fey gain fast healing 5 and all other living creatures gain fast healing 1\. All creatures in the area gain a +4 bonus on saving throws against pain effects. The mist remains stationary and lasts for 8 minutes. The area is Hit Dice-based.  

**Spells:** A gaoth sidhe casts spells as a sorcerer with a level equal to her Hit Dice.  
_Typical sorcerer spells known_ (6/7/7/6/4; save DC 14 + spell level): 0—_daze, detect magic, dancing lights, ghost sound, mage hand, prestidigitation, ray of frost, touch of fatigue;_ 1st—_alarm, chill touch, ray of enfeeblement, shocking grasp, sleep;_ 2nd—_fog cloud, gust of wind, hypnotic pattern;_ 3rd—_lightning bolt, sleet storm;_ 4th—_rainbow pattern._  

**Cailleach Bheur**  
Large Fey (Air, Cold, Water)  
**Hit Dice:** 16d6+64 (106 hp)  
**Initiative:** +4  
**Speed:** 30 ft., swim 60 ft., fly 90 ft. (good)  
**Armor Class:** 26 (+4 Dex, +13 natural, -1 size), touch 13, flat-footed 22  
**Base Attack/Grapple:** +8/+20  
**Attack:** Claw +16 melee (1d8+8 plus 1d6 cold plus 1 Str)  
**Full Attack:** 2 claws +16 melee (1d8+8 plus 1d6 cold plus 1 Str) and bite +13 melee (2d6+4 plus disease)  
**Face/Reach:** 5 ft./5 ft.  
**Special Attacks:** Chilling touch, disease, spells, storm mastery  
**Special Qualities:** Change size, damage reduction 15/cold iron, immunity to cold and electricity, low-light vision, meld into weather, resistance to sonic 20, resistance to wind, spell resistance 31, vulnerability to fire  
**Saves:** Fort +9, Ref +11, Will +16  
**Abilities:** Str 26, Dex 16, Con 19, Int 17, Wis 22, Cha 20  
**Skills:** Concentration +14, Intimidate +15, Listen +15, Knowledge (nature) +14, Spot +15, Survival +15 (+17 in aboveground natural environments)  
**Feats:** Dodge, Empower Spell, Eschew Materials, Flyby Attack, Multiattack, Weapon Focus (claw)  
**Climate/Terrain:** Any aquatic, marsh, mountain, or hills  
**Organization:** Solitary or covey (3 or 13)  
**Challenge Rating:** 16  
**Treasure:** Standard  
**Alignment:** Usually chaotic neutral  
**Advancement:** 17-32 HD (Large)  
**Level Adjustment:** +6  

_Through the driving rain, you can make out the shape of ._  

Cailleachan bheur are fey tied to winter and storms. When a gaoth sidhe reaches old age, she participates in an initiation ritual which results in her becoming a cailleach bheur. The rite calls for the gaoth sidhe to ride in the heart of a hurricane from beginning to end. When the storm dies down and the clouds clear, a new cailleach bheur is left behind.  

Cailleachan bheur consider themselves to be guardians of the weather and do not alter it without a reason. They appreciate and enjoy the power of storms, however, and so like to be near them when the occur naturally.  

These fey love to ride storms, and are closely associated with winter and frostbite, the killing frost of mountain peaks and the blasting hurricanes of autumn. Their intimate connection of storms brings them to have nearly as strong a link to water as they have to air, and they are happiest in places where sea and sky mingle together. They have a masterful knowledge of the weather and are often consulted by sages for predictions.  

Cailleachan bheur typically lair in high snowy mountains, on icebergs, or on the floor of lakes or oceans prone to storms, typically in cold climates. When winter sets in in temperate areas, they like to ride in on the first blizzards of the season and leave at the onset of spring after making sure the area is properly chilled in winter. They take great offense when magic is used to calm stormy weather or to warm wintry weather, and usually kill offenders against the seasons.  

Cailleach bheur often live alone, but are greatly respected by sylphides and gaoth sidhe and are often visited by those fey. They keep in touch with each other by meeting at the Unseelie Court's winter gala or other fey gatherings. They are also very mindful of the future and tend to make long-term plans. If they have problems which they cannot tackle alone, such as a powerful mortal spellcaster suppressing winter in a small region, they are quick to seek the aid of others of their kind in coveys of three. If they are faced with a significant threat, such as the possible summoning of a fiendish minor cosmic entity playing havoc with the weather, they will join into a more powerful covey of 13 led by a cailleach bheur of at least 32 HD to prevent the occurrence.  

It is not uncommon for them to be involved in fey courts, especially the Court of Winds and occasionally the Court of Waves. Due to their love of destruction, they often associate with the Unseelie Court.  

A cailleach bheur appears as a wizened old crone with blue-grey skin and stringy grey hair. It usually wears a tattered black peasant’s dress.  

Cailleachan bheur speak Aquan, Auran, Common, and Sylvan.  

**COMBAT**  
A cailleach bheur prefers to first create a storm cover to distract her enemies, then swoop in with claw or bite attacks to weaken her foes before moving out to a distance again. After that, it attempts to destroy its enemies from a distance using its spells.  

**Change Size (Su):** A cailleach bheur can become any size from Medium to Huge as a move action. It does not revert to a particular size when killed.  

**Chilling Touch (Su):** A cailleach bheur’s claw attack inflicts 1d6 cold damage and 1 Strength damage on a successful hit.  

**Disease (Ex):** Frost chills – bite, Fortitude DC 16, incubation period 1 day, damage 1d4 Strength, 1 Dexterity, and 1d4 Constitution. The victim’s skin turns frost-white and cold to the touch. The save DC is Constitution-based.  

**Meld into Weather (Su):** A cailleach bheur can create a blurring veil of precipitation around itself when it is in an area of precipitation. It becomes effectively invisible as if by _greater invisibility_. The cailleach bheur may suppress or resume this effect as a free action.  

**Resistance to Wind (Ex):** A cailleach bheur receives a +8 racial bonus on saving throws against air and wind effects. Reduce all damage dealt to the cailleach bheur by air and wind effects by 20 points.  

**Spells:** A cailleach bheur casts spells as a 16th-level sorcerer.  
_Typical sorcerer spells known_ (6/8/7/7/7/6/6/5/3; save DC 15 + spell level): 0—_daze, detect magic, dancing lights, flare, ghost sound, mage hand, prestidigitation, ray of frost, touch of fatigue;_ 1st—_chill touch, magic missile, ray of enfeeblement, shocking grasp, sleep;_ 2nd—b_lur, eagle’s splendor, gust of wind, hypnotic pattern, shatter;_ 3rd—_dispel magic, haste, lightning bolt, slow;_ 4th—_contagion, ice storm, shout, solid fog;_ 5th—_cone of cold, control winds, telekinesis, waves of fatigue;_ 6th—_acid fog, chain lightning, greater dispel magic;_ 7th—_control weather, finger of death;_ 8th—_greater shout._  

**Storm Mastery (Su):** As a swift action once per day, a cailleach bheur can create a thunderstorm, hurricane, tornado, or blizzard as per _control weather_ (as a druid, caster level 16th). The initial effect and changes to the effect take only 3 rounds to manifest instead of 10 minutes. A cailleach bheur is immune to all weather effects created by her own storm mastery ability. The effective caster level is Hit Dice-based.  

* * *
 
The Faerie Project is depicting fairy-like sylphs as elementals who chose to become fey. There are also sylphs who are the intelligent, magical protogenoi or true elementals of air. The fey sylphs were once part of that race. To differentiate, I am considering calling the fey-sylphs "sylphides" after the French version of the word. The sylphides grow and change in power as they age. The stages are as follows. Young adult: sylphide; middle age: gaoth sidhe; old age: cailleach bheur. The sylphides replace the outsider sylphs from the MMII and are based on them. I'm aiming very specifically at the CR listed, so please help me get there if I'm off target.  

**

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *