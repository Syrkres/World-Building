# Cosmology Timeline
The following is the official breakdown of Powers in the Godspell Campaign Setting. Powers include deities, cosmic entities, and entities beyond that level of power.  

* **Divine Rank 0** Quasi-Powers  
* **Divine Rank 1-5** Demipowers  
* **Divine Rank 6-10** Lesser Powers  
* **Rank 11-15** Intermediate Powers  
* **Rank 16-20** Greater Powers  
* **Rank 21-25** Elder Ones (includes Elder Gods such as Ao)  
* **Rank 26-30** Old Ones (includes entities such as the Overlord of Hell)  
* **Rank 31-35** First Ones (includes entities such as the Circle of Law)  
* **Rank 36-40** The Primordium (the proto-cosmos)  
* **Rank 41-45** The Others (the Xural)  
* **Rank 46-50** The Alpha-Omega (previous casters of The Godspell, current casters of The Godspell, and the Singularity from whence all came)  

_Notes:_  
Divine and cosmic distinctions no longer apply beyond DvR 20\. That is, Ao, is technically neither specifically a deity nor a cosmic entity.  

Alignment is a trapping of DvR 35 and lower.  

The First Ones included the origins of major alignments, as well as Matter and other basic building blocks of the emerging cosmos as it currently stands.  

**End of the Last Reality**  

The Godspell is cast by a nameless Agency. The entirety of the previous Reality, save the xural, is destroyed, the Agency becomes God, and resets Creation with a new Reality.  

**The Awakening**  

The Agency departs the new Reality, leaving the xural to tend to the Godspell and the Primoridium, the potential of a new Cosmos.  

The xural, the Cosmic Imperatives, seal The Godspell away in a prison plane of [Midlorr]. This is their last collective act. Other than Aul, the xural consciousnesses disappear to remote regions of Cosmos (their essences are, however, later indirectly utilized by the First Ones). Aul dwells in [Midlorr]to guard The Godspell.  

**The Xural** (Also known as the Cosmic Imperatives, The Others, The Eternals)  
_Azima_: The Imperative of Magic  
_Aul_: The Imperative of Being  
_Bahati_: The Imperative of Fate  
_Nardal_: The Imperative of Time  
_Sifur_: The Imperative of Oblivion  
_Yi_: The Imperative of Existence  
_Duru_: The Imperative that encompasses all and binds The Others together.  

The Primoridium: Simultaneously to the sealing of The Godspell, the Primordium -- without the guidance of the xural -- moves. From it emerges the Cosmic Ideals, "later" known as the First Ones. Included in this group are Chaos and Law, and Good and Evil, and [Matter] and [Energy], and all exist in Balance. Most confuse the Primoridium for Chaos.  

**The First Cosmic Paradigm: Primordium Ascendant**  

Of the members of the Primordium, there is no consciousness; however, there is desire. And the first to enact its desire was Law, which strove to separate identify the distinctions within the Primoridum. This resulted in the immediate reaction of Chaos and the eternal conflict between the two started.  

Meanwhile, Evil and Good remained inert, unable to act without something upon which to respond.  

[Matter] and [Energy], acting as one, forge what is intended to be a tentative union, becoming the [Proto-Inner Planes]. [The Proto Inner Planes] remains within Primordium with Balance.  

_The Circle of Law Emerges_: Law develops consciousness and becomes the First One known as the Circle of Law. Its desire to separate the Primordium instigates the development of consciousness/wakefulness in the other First Ones. Ostensibly, the Circle of Law remains unaffected by Evil and Good.  

_Ur-Chaos Shudders_: In reaction to the Circle of Law, Chaos swirls into a multitude of different consciousnesses of varying degrees of strength and under the influence of Good and Evil. It becomes Ur-Chaos. This is the first action on the part of Evil and Good and results in the creation of the three greatest personifications of Chaos: The Demiurge (influenced by Evil), [Chaotic Good], and Limbo (unaffected by either moral alignment).  

[Evil and Good]  

_The Creation of the Inner Realities and the Realms Beyond_: Eager to remain independent of the growing tensions between the Circle of Law, [Proto-Inner Planes] formally create the Inner Realities and separate from the Primoridium. Consequently, this creates the foundations of the Realms Beyond (or the Outer Realities). The First Ones of [Energy] and [Matter] come into existence. Initially ignored by the CoL, the Inner Realities allow portions of their essences to be used by the consciousnesses of Ur-Chaos.  

_Old Ones Emerge_: While a few Old Ones are already in existence, this time marks the emergence of many more. Some of these are the offspring/cast-offs of First Ones, while some come into existence because they have to.  

_Creation of the Primal Coil:_ Ur-Chaos, in the form of The Demiurge and the other yaldobaoths, creates the Primal Coil by drawing some of the Inner Realities into the Outer Realities in a bid to challenge the CoL. The foundations of the Eternal Bridge known as The Land of Dreams are erected.  

_The First War of Chaos and Law_: The Circle of Law seizes this time to strike at Ur-Chaos. In short order, Good and Evil are drawn into the war through lesser agents influencing the actions of both the CoL and Ur-Chaos. Although The Demiurge is cast down and Limbo is thrown aside, even the CoL does not emerge entirely unscathed for, during the conflict, Good influences mercy within the CoL, keeping a portion of it from destroying [Chaotic Good]. Thus is CoL finally affected by morality. The War also results in the first "wide-spread" opening of paths to the Void Between.  

_Destruction of the Primal Coil:_ The Demiurge is cast down and the evil associated with its creation, the Primal Coil, is gone with it; there is left only a blasted husk containing with the potential that will eventually be incorporated into the Material Plane. The first mists of the Endless Boundary take shape. The Seed of Life emerges as the center of what will become the Material Plane. While its origins are a mystery, the Seed of Life supposedly came forth out of the Primordium.  

_The Abyss is formed:_ As The Demiurge falls, it merges with the remnants of the Primal Coil to form The Abyss. The remaining yaldaboath are defeated, destroyed or sent into retreat.  

Limbo is formed {somehow}  

**The Second Cosmic Paradigm: Epoch of Absolute Order**  

_The Circle of Law reigns supreme._  

_Time is introduced into Creation_. The Circle of Law cannot extricate it once it merges, and so they set up laws and orders for how time must be governed. It is unclear to what the degree the xural of Time influenced this action on the part of the CoL.  

_Tides of Chaos_. Qlippothims arise in The Abyss. Some are born of the remaining, weakened yaldabaoth, but most emerge of their own accord from The Abyss itself. Around the same time, True Slaadi emerge inside Limbo.  

_The Foundations of Realms Beyond:_ The Circle of Law forms the Protectors and charges them with the safeguarding of Time and other aspects of Order, among these will be Paradox. They also cordon off the Realms Beyond into distinct regions based upon various Good, Evil, and Law; Limbo remains largely unaffected much to the CoL's frustration.  

[Other ancient outsiders emerge]  

_Sundering of the Circle:_ The Circle of Law, unable to maintain cohesion while attempting to define the Center and overwhelmed by the vying influences of Evil and Good, is rent into the Old Ones known as The Supreme Virtue (LG), The Progenitor (LN), and The Overlord (LE). Their respective falls form Heaven, Nirvana, and Hell and cosmic tears that begin the creation of "impure" alignment-planes. Their offspring races spring into being, though they take time to come into their own.  

**The Third Cosmic Paradigm: Age of Ancients**  

_Appearance of the Elder Ones:_ The Elder Ones begin to appear seemingly spontaneously, though occasionally as the offspring of greater entities. They influence events in many places, and contribute in some cases to the shape of the Multiverse (such as Carceri, the Land of Dreams, the Ruined Coil, the Material Plane once it exists, and/or others).  

_Eternal Bridges Are Complete:_ The Land of Dreams and Endless Boundary are complete.  

_Qlippothim Rising:_ With the disappearance of the Circle, their servants, the Protectors, weaken. The qlippothim slowly begin to get the upper hand over them.  

_The Seed of Life Stirs:_ The Seed of Life creates Ladinion and primeval life - the birds of paradwys.  

_Rise of the Vaati, Hellspawn, and Seraphim._  

_The Material Plane Lives:_ Though few know from whence it came, the Mortal Coil appears in the place of the Ruined Coil. Annwn appears in Faerie, completing all three layers of the Material Plane. Elder Ones are by now present on the Plane in great numbers, creating worlds or being drawn to existing ones. The daoine sidhe are created, and the Faerie Court is founded. Vaati and qlippothim, among others, begin to explore the new plane.  

_The Second War of Law and Chaos Begins:_ Eventually spreading across nearly the whole of the cosmos, the forces of Law and Chaos battle once more. Leading the faction of Law, the Vaati are assisted by many beings, including entities from the Elemental Realities and Realm of Spirits. Unlike the forces of Law, the forces of Chaos are divided and bereft of one single leader or primary race.  

_The Second War on the Mortal Coil:_ Conflict grows within The Mortal Coil between the vaati-led faction and the factions of Chaos. The vaati seek to bring law to all places which they can find. The qlippothim through the power of various demon princes (some of which are still extant) seek instead to warp all life where they can find it, to destroy order, and even to drag parts of The Mortal Coil wholesale into The Abyss. Meanwhile other forces of chaos (such as a number of True Slaadi) are more interested in investigating the Mortal Coil, neither desiring to dominate nor destroy it.  

While the forces of chaos all oppose the impositions of the Vaati Imperium, the various beings of Chaos disagree on how to react -many alliances are made, and broken, with the various reactions and moral decisions further shifting and blending the borders between CG, CN, and CE.  

_Pale Night's Attempt:_ The apex of this particular approach comes with Pale Night's failed attempt (now largely treated as apocryphal) to bring CG in on the side of The Abyss through the corruption of one of CG's champions.  

_Vaati Innovations:_ The vaati, struggling against a seemingly more numerous foe, as well as one that defies logic and any rational organization or unity, continues to experiment and expand its creation of tools. During this time, great weapons of war are forged, including the likes of the Form of Weapons.  

_Aul Acts_: [Midlorr] is formalized and Midlorr is created.  

_Earliest Gods Appear:_ Gods begin to appear. Primitive mortals begin to appear in significant numbers for the first time. Some Elder Ones begin to vanish mysteriously, while others are supplanted by the new gods.  

_Maleidolons appear in The Abyss._  

_Origin of the Mazza'im:_ Souls derived from the now-prolific mortals provide the seeds for qlippoth innovation. The demon lords draw from the Elemental Realities as well as the Mortal Coil to make a new slave race for themselves.  

_The Queen of Chaos Arises:_ As the forces of Chaos debate and battle amongst themselves over how and why they contest the forces of Law, the Queen of Chaos emerges as a leader of one of the larger, or at least most combative factions. She gathers together an army among the qlippothim and chooses a champion among the mazza'im.  

_The Shaping of the Rod of Law:_ Struggling against the forces of Chaos, the Vaati create the Rod of Law as their ultimate tool in winning the War. Whether a consequence or mere coincidence of the RoL's creation, the Overlord awakes, creating Lucifer the Satan, who tyrannically imposes order upon Perdition, subduing and slaying the warring hellspawn. At the same time, the Supreme Virtue stirs, engaging in similar, if morally opposite, actions.  

_The Clash of Spirits in Midlorr:_ The various gods of Midlorr do battle with each other and with cosmic entities interested in [Midlorr]. The conflict ends with the signing of the Pact of Dominance.  

_Exodus of the Elder Ones:_ The Elder Ones finish their disappearance from the Material Plane, leaving it to lesser beings such as early mortals, vaati, qlippothim, and early gods.  

_The Elder Gate:_ Looking for vanished Elder Ones, fey exiles on the Mortal Coil create a gate to the Void Beyond. The peripheral cracks to the Void Beyond already present in Creation allow a massive hole to be ripped in the Mortal Coil. Although it is largely closed with the Elder Seal (AKA Cerulean Sign), it damages time and creates the modern Void Between the Stars. The Faerie Court splinters with the death of Queen Gloriana.  

_End of the Second War:_ As more worlds and powers. both cosmic and divine, are drawn into this titanic clash between the forces of Law and Chaos, the Vaati employ the Rod of Law. While destroying the majority of the True Slaadi, as well as much of the Queen of Chaos' forces, including her champion (a powerful mazza'im demon), the RoL drives the entirety of the vaati into either extinction or hibernation and decimates mortal life. Among other things, the war's conclusion includes the seraph Apollyon departing from Realms Above to oversee The Abyss, where he swiftly yields to savagery and madness. Pandemonium becomes distinct as a plane from The Abyss.  

**The Fourth Cosmic Paradigm: Days of Antiquity**  

_The Aulspawn War in Midlorr_  

_Lucifer Attends the Mortal Coil:_ Lucifer and Lilith turn their attentions to corrupting the Mortal Coil.  

_Spawning of the Slaadi:_ In the aftermath of the War, the Spawning Stone appears in Limbo, with the Slaadi coming into being shortly thereafter, led in part by such beings as Ssendam and Ygorl.  

_Wars of Divine Succession Begin:_ Gods, present but generally in the background since the Exodus of the Elder Ones, begin to take center stage across the Mortal Coil.  

_Blood War Begins:_ While in many ways the continuation of the 2nd War of Law and Chaos, the fiends of the Depths Below wage war upon one another. Unlike the previous wars between law and chaos, the natives of Nirvana and Limbo only participate in limited means. Likewise, while the Blood War occasionally spills onto other planes, the vast majority of the conflict occurs in the Depths Below.  

_The Saldrash War in Midlorr:_  

_The Rise of the Protectorate:_ After a momentary period of infighting, the remnants of the vaati imperium unite to create a confederacy of previous servitor races of the vaati. In time, this alliance becomes the Protectorate, eventually expanding to include areas and factions within Arcadia and Acheron.  

_The Voyeurs:_ Interested in the actions of mortals, some angels defy agreements between gods and the Realms Above. Led by the seraph Semyaza, these angels are cast out of the Realms Above, many falling into The Abyss, Limbo, and Pandemonium.  

_The Creation of Humen_  

_Fall of the Protectorate_ Over time, the Protectorate crumbles from a combination of several attacks both from within and without Nirvana.  

_The Illithid Suddenly Appear_  

_The War of Light and Greed:_ Lucifer the Satan goes to war with Asmodeus the Devil and loses his throne, his final fate unclear. (Treat him as dead.) Asmodeus becomes the new Overlord of Hell.  

**The Fifth Cosmic Paradigm**  

_The Great Fall:_ Fully 1/3 of the angels of the Realms Above fall into Evil, the bulk descending into Hell. Chief among these are Astarte, Beelzebul, Belial, Eblis, and Moloch. Shortly thereafter, many of these Fallen become Lord-Regents of Hell.  

[more stuff]  

_Gith's rebellion_  

**The Sixth Cosmic Paradigm: Rise of Humen (present day)  

The Seventh Cosmic Paradigm: End** of Days (coming)  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *