# ELDER SIDHE (CR 30)
Often N Medium fey  
**Init** +14; **Senses** low-light vision, true seeing; Listen +52, Spot +52  
**Aura** glamour (30 ft., DC 37, charm), stunning gaze (30 ft., DC 37, stun 2d4 rounds); **Languages** all  
**AC** 40, touch 35, flat-footed 26 (+14 Dex, +11 insight, +5 natural)  
**hp** 435 (30 HD), fast heal 10 **DR** 20/cold iron and epic  
**Immune** ability damage, ability drain, death effects, death from massive damage, disease, energy drain, mind-affecting effects, poison, sleep, and petrification, polymorphing, and other form-altering effects  
**SR** 43 (CR + 13)  
**Fort** +25, **Ref** +31, **Will** +28  
**Speed** 40 ft. (8 squares)  
**Melee** _+7 frost silver shortsword_ +47/+42/+37 (1d6+25 plus 1d6 cold/19-20) or  
spell +40 touch  
**Ranged** _+7 seeking shock composite longbow_ (+7 Str bonus) with silver arrows +48/+43/+38 (1d8+25 plus 1d6 electricity/x3) or  
_+7 seeking shock composite longbow_ (+7 Str bonus) with silver arrows +46/+46/+41/+36 (1d8+25 plus 1d6 electricity/x3)  
**Base Atk** +15; **Grp** +22  
**Atk Options** arrow of mortality, Point-Blank Shot, Precise Shot, Rapid Shot, Shot on the Run, sneak attack +6d6  
**Special Actions** stunning gaze (30 ft., DC 37, stun 2d4 rounds)  
**Spell-like Abilities** (CL 30th)  
At will—_awaken, bestow curse_ (DC 25), _charm monster_ (DC 26), _command plants_ (DC 26), _detect thoughts_ (DC 24), _displacement, entangle_ (DC 23), _greater invisibility, greater teleport, harm_ (DC 28), _haste_ (self only), _heal, knock, mass hold monster_ (DC 31), _persistent image_ (DC 27), _speak with animals, speak with plants, spell turning, true dispelling, water breathing_  
7/day—_animate plants_ (DC 29)  
1/month—_verdigris tsunami_ (DC 32)  
**Abilities** Str 24, Dex 38, Con 32, Int 30, Wis 32, Cha 34  
**SQ** freedom of movement, improved uncanny dodge, hide in plain sight, invisibility, mythic nature, nature’s sanctity, otherworldly grace, true seeing, wild empathy +48  
**Feats** Dodge (B), Mobility, Point Blank Shot, Precise Shot, Quicken Spell-Like Ability (_mass hold monster_), Rapid Shot, Shot on the Run, Weapon Finesse, Weapon Focus (longbow)  
**Epic Feats** Epic Fortitude, Polyglot (B), Spell Stowaway (_heal_), Swarm of Arrows  
**Mythic Nature Abilities** arrow of mortality, nature’s sanctity  
**Skills** Appraise +43, Bluff +45, Concentration +41, Diplomacy +53, Disguise +45 (+49 acting), Hide +47, Intimidate +49, Knowledge (arcana) +43, Knowledge (nature) +43, Listen +52, Move Silently +47, Perform (any two) +53, Search +18, Sense Motive +44, Spellcraft +47, Spot +52, Survival +19 (+23 in aboveground natural areas)  
**Possessions** _+7 seeking shock composite longbow_ (+7 Str bonus), _+7 frost silver shortsword_, 40 silver arrows  

**ELDER SIDHE**  

The elder sidhe are among the oldest and most powerful types of fey. They are usually widely-known and influential rulers of fey courts. 

**Aptitude Focus** Although elder sidhe do not always have class levels, their immense life spans and knack for learning allow them to acquire abilities from their racial Hit Dice similar to those conferred by class levels. Each elder sidhe may choose one of the following. This elder sidhe has chosen the stealth aptitude focus, granting her improved uncanny dodge, sneak attack +6d6, and hide in plain sight. For the purposes of uncanny dodge and other effects, she is treated as if she were a 22nd-level rogue.  

_Arms_ The elder sidhe gains one bonus fighter feat per five racial hit dice and may select fighter-only feats as if she were a fighter of a level equal to her racial Hit Dice.  

_Hunter_ The elder sidhe gains the favored enemy abilities of a ranger of a level equal to the elder sidhe's racial Hit Dice.  

_Magic_ The elder sidhe has the spells per day and spells known of a cleric, druid, sorcerer, or wizard whose level is equal to one-half her racial Hit Dice, or of a bard whose level is equal to three-quarters her racial Hit Dice. The elder sidhe's effective caster level for her spells is equal to three-quarters her racial Hit Dice.  

_Music_ The elder sidhe has unearthly musical prowess. She gains the bardic music of a bard whose level is equal to her racial Hit Dice.  

_Rage_ The elder sidhe has the ability to unlock the amazing strength of anger. She gains the rage, uncanny dodge, greater rage, and indomitable will abilities. Her effective barbarian level is equal to three-quarters her racial Hit Dice. She may choose to utilize the whirling frenzy variant.  

_Stealth_ The elder sidhe gains the improved uncanny dodge ability and may sneak attack as a rogue, inflicting 1d6 points of damage per five racial Hit Dice. The elder sidhe also gains either improved evasion or hide in plain sight. Her effective rogue level for purposes such as flanking a character with improved uncanny dodge is equal to three-quarters her racial Hit Dice.  

**Freedom of Movement (Su)** An elder sidhe is difficult to hinder, as if warded by a _freedom of movement_ effect with caster level 30th.  

**Glamour (Su)** Whenever a creature comes within 30 feet of an elder sidhe, it must succeed on a Will save (DC 37) or become charmed with the elder sidhe as _charm monster_ at caster level 30th. Once a creature attempts a save against this ability, whether successful or not, it cannot be affected by the same elder sidhe’s glamour for 24 hours.  

**Invisibility (Su)** An elder sidhe is naturally invisible as if through _greater invisibility_. She may suppress or resume this effect as a free action. As a supernatural effect, this ability is not subject to dispelling or _invisibility purge_.  

**Mythic Nature** An elder sidhe is an aspect of nature's power and magic. As such, an elder sidhe has one or more unique special abilities, whose total power varies along with the power of the elder sidhe. Generally, mythic nature impacts the elder sidhe’s overall power level about as much as two salient divine abilities available to a divine rank 1 demigod would. The caster level for all mythic nature effects which use one is equal to the elder sidhe’s spell-like ability caster level unless noted otherwise.  

**Sample Mythic Nature Ability: Arrow of Mortality (Su)** Whenever the elder sidhe fires an arrow, the arrow becomes invisible. It disintegrates after dealing damage. The wound is superficially closed, leaving no outward sight of harm. Additionally, up to three times per day, the elder sidhe can use a standard action to fire an arrow that passes through all nonmagical barriers in its way (so it can be stopped by a _wall of fire_ or _wall or force_), negating cover and concealment, and strikes as a ranged touch attack. If this special arrow hits, the creature struck must succeed on a Fortitude save (DC 37) or die instantly; even if it succeeds, it suffers 3d6+30 points of damage. If the creature is not living, it still affected; it is simply destroyed rather than killed if it fails. If the creature struck is living, this is a death effect.  

**Sample Mythic Nature Ability: Nature’s Sanctity (Su)** An elder sidhe with this special quality can avoid attacks and effects by merging momentarily with the basic fabric of nature and reality. It effectively leaves existence for a brief moment. Any physical attack or individually targeted spell directed at the elder sidhe has a 50% miss chance. Area effects that include the elder sidhe have a similar chance to be ineffective.  

**Otherworldly Grace (Su)** An elder sidhe receives an insight bonus to its Armor Class, attack rolls, and weapon damage rolls equal to its Wisdom bonus. It is unaffected and undamaged by natural hazards of all sorts, including difficult terrain, natural magma, and exposure to naturally cold or windy weather. This ability offers no protection against sentient-made hazards or the special abilities of creatures. Finally, an elder sidhe leaves no trail in natural environs unless it wishes to.  

**Stunning Gaze (Su)** Stunned for 2d4 round, 30 feet, Fortitude DC 37 negates. The save DC is Charisma-based.  

**True Seeing (Ex)** An elder sidhe’s senses are extraordinarily powerful, granting it the benefits of a _true seeing_ effect (as the spell, caster level 30th).  

**Wild Empathy (Ex)** An elder sidhe can use wild empathy as a 30th-level druid. An elder sidhe has a +6 racial bonus on wild empathy checks.  

Here’s the stuff which there’s nowhere to put in this template:  

**Skills:** An elder sidhe receives a +8 racial bonus on Listen, Perform, Search, Spot, and Survival checks.  
**Environment:** The Plane of Faerie  
**Organization:** Solitary, with 1-5 lesser fey attendants, or court (1-13 plus 10-50 lesser fey attendants)  
**Treasure:** Double standard (including gear)  
**Advancement:** 31-90 HD (Medium); or by character class  
**Level Adjustment:** –  

Finally, here is the elder sidhe in her 3.5 MM format glory:  

**Elder sidhe**  
Medium Fey  
**Hit Dice:** 30d6+330 (435 hp)  
**Initiative:** +14  
**Speed:** 40 ft.  
**Armor Class:** 40 (+14 Dex, +11 insight, +5 natural), touch 35, flat-footed 26  
**Base Attack/Grapple:** +15/+22  
**Attack:** _+7 frost silver shortsword_ +47 melee (1d6+25 plus 1d6 cold/19-20) or _+7 seeking shock composite longbow_ (+7 Str bonus) with silver arrows +48 ranged (1d8+25 plus 1d6 electricity/x3) or spell +40 touch  
**Full Attack:** _+7 frost silver shortsword_ +47/+42/+37 melee (1d6+25 plus 1d6 cold/19-20) or _+7 seeking shock composite longbow_ (+7 Str bonus) with silver arrows +48/+43/+38 ranged (1d8+25 plus 1d6 electricity/x3) or _+7 seeking shock composite longbow_ (+7 Str bonus) with silver arrows +46/+46/+41/+36 ranged (1d8+25 plus 1d6 electricity/x3)  
**Space/Reach:** 5 ft./5 ft.  
**Special Attacks:** Arrow of mortality, bardic music, glamour, sneak attack +6d6, spell-like abilities, stunning gaze  
**Special Qualities:** Damage reduction 20/cold iron and epic, fast healing 10, freedom of movement, improved uncanny dodge, hide in plain sight, immune to ability damage, ability drain, death effects, death from massive damage, disease, energy drain, mind-affecting effects, poison, sleep, and petrification, polymorphing, and other form-altering effects, invisibility, low-light vision, mythic nature, otherworldly grace, spell resistance 43, true seeing, wild empathy  
**Saves:** Fort +25, Ref +31, Will +28  
**Abilities:** Str 24, Dex 38, Con 32, Int 30, Wis 32, Cha 34  
**Skills:** Appraise +43, Bluff +45, Concentration +41, Diplomacy +53, Disguise +45 (+49 acting), Hide +47, Intimidate +49, Knowledge (arcana) +43, Knowledge (nature) +43, Listen +52, Move Silently +47, Perform (any two) +53, Search +18, Sense Motive +44, Spellcraft +47, Spot +52, Survival +19 (+23 in aboveground natural areas)  
**Feats:** Dodge (B), Mobility, Point Blank Shot, Precise Shot, Quicken Spell-Like Ability (_mass hold monster_), Rapid Shot, Shot on the Run, Weapon Finesse, Weapon Focus (longbow)  
**Epic Feats:** Epic Fortitude, Polyglot (B), Spell Stowaway (_heal_), Swarm of Arrows  
**Environment:** The Plane of Faerie  
**Organization:** Solitary, with 1-5 lesser fey attendants, or court (1-13 plus 10-50 lesser fey attendants)  
**Challenge Rating:** 30  
**Treasure:** Double standard (including gear)  
**Alignment:** Often neutral  
**Advancement:** 31-90 HD (Medium); or by character class  
**Level Adjustment:** –  

**COMBAT**  
An elder sidhe’s natural weapons are considered epic weapons for the purpose of overcoming damage reduction.  

**Aptitude Focus:** Although elder sidhe do not always have class levels, their immense life spans and knack for learning allow them to acquire abilities from their racial Hit Dice similar to those conferred by class levels. Each elder sidhe may choose one of the following. This elder sidhe has chosen the stealth aptitude focus, granting her improved uncanny dodge, sneak attack +6d6, and hide in plain sight. For the purposes of uncanny dodge and other effects, she is treated as if she were a 22nd-level rogue.  

_Arms_: The elder sidhe gains one bonus fighter feat per five racial hit dice and may select fighter-only feats as if she were a fighter of a level equal to her racial Hit Dice.  

_Hunter_: The elder sidhe gains the favored enemy abilities of a ranger of a level equal to the elder sidhe's racial Hit Dice.  

_Magic_: The elder sidhe has the spells per day and spells known of a cleric, druid, sorcerer, or wizard whose level is equal to one-half her racial Hit Dice, or of a bard whose level is equal to three-quarters her racial Hit Dice. The elder sidhe's effective caster level for her spells is equal to three-quarters her racial Hit Dice.  

_Music_: The elder sidhe has unearthly musical prowess. She gains the bardic music of a bard whose level is equal to her racial Hit Dice.  

_Rage_: The elder sidhe has the ability to unlock the amazing strength of anger. She gains the rage, uncanny dodge, greater rage, and indomitable will abilities. Her effective barbarian level is equal to three-quarters her racial Hit Dice. She may choose to utilize the whirling frenzy variant.  

_Stealth_: The elder sidhe gains the improved uncanny dodge ability and may sneak attack as a rogue, inflicting 1d6 points of damage per five racial Hit Dice. The elder sidhe also gains either improved evasion or hide in plain sight. Her effective rogue level for purposes such as flanking a character with improved uncanny dodge is equal to three-quarters her racial Hit Dice.  

**Freedom of Movement (Su):** An elder sidhe is difficult to hinder, as if warded by a _freedom of movement_ effect with caster level 30th.  

**Glamour (Su):** Whenever a creature comes within 30 feet of an elder sidhe, it must succeed on a Will save (DC 37) or become charmed with the elder sidhe as _charm monster_ at caster level 30th. Once a creature attempts a save against this ability, whether successful or not, it cannot be affected by the same elder sidhe’s glamour for 24 hours.  

**Invisibility (Su):** An elder sidhe is naturally invisible as if through _greater invisibility_ (caster level 30th). She may suppress or resume this effect as a free action. As a supernatural effect, this ability is not subject to dispelling or _invisibility purge_.  

**Mythic Nature:** An elder sidhe is an aspect of nature's power and magic. As such, an elder sidhe has one or more unique special abilities, whose total power varies along with the power of the elder sidhe. Generally, mythic nature impacts the elder sidhe’s overall power level about as much as two salient divine abilities available to a divine rank 1 demigod would. The caster level for all mythic nature effects which use one is equal to the elder sidhe’s spell-like ability caster level unless noted otherwise.  

**Sample Mythic Nature Ability: Arrow of Mortality (Su):** Whenever the elder sidhe fires an arrow, the arrow becomes invisible. It disintegrates after dealing damage. The wound is superficially closed, leaving no outward sight of harm. Additionally, up to three times per day, the elder sidhe can use a standard action to fire an arrow that passes through all nonmagical barriers in its way (so it can be stopped by a wall of fire or wall or force), negating cover and concealment, and strikes as a ranged touch attack. If this special arrow hits, the creature struck must succeed on a Fortitude save (DC 37) or die instantly; even if it succeeds, it suffers 3d6+30 points of damage. If the creature is not living, it still affected; it is simply destroyed rather than killed if it fails. If the creature struck is living, this is a death effect.  

**Sample Mythic Nature Ability: Nature’s Sanctity (Su):** An elder sidhe with this special quality can avoid attacks and effects by merging momentarily with the basic fabric of nature and reality. It effectively leaves existence for a brief moment. Any physical attack or individually targeted spell directed at the elder sidhe has a 50% miss chance. Area effects that include the elder sidhe have a similar chance to be ineffective.  

**Otherworldly Grace (Su):** An elder sidhe receives an insight bonus to its Armor Class, attack rolls, and weapon damage rolls equal to its Wisdom bonus. It is unaffected and undamaged by natural hazards of all sorts, including difficult terrain, natural magma, and exposure to naturally cold or windy weather. This ability offers no protection against sentient-made hazards or the special abilities of creatures. Finally, an elder sidhe leaves no trail in natural environs unless it wishes to.  

**Spell-Like Abilities:** At will—_awaken, bestow curse_ (DC 25), _charm monster_ (DC 26), _command plants_ (DC 26), _detect thoughts_ (DC 24), _displacement, entangle_ (DC 23), _greater invisibility, greater teleport, harm_ (DC 28), _haste_ (self only), _heal, knock, mass hold monster_ (DC 31), _persistent image_ (DC 27), _speak with animals, speak with plants, spell turning, true dispelling, water breathing;_ 7/day—_animate plants_ (DC 29); 1/month—_verdigris tsunami_ (DC 32). Caster level 30th. The DCs are Charisma-based.  

**Stunning Gaze (Su):** Stunned for 2d4 round, 30 feet, Fortitude DC 37 negates. The save DC is Charisma-based.  

**True Seeing (Ex):** An elder sidhe’s senses are extraordinarily powerful, granting it the benefits of a _true seeing_ effect (as the spell, caster level 30th).  

**Wild Empathy (Ex):** An elder sidhe can use wild empathy as a 30th-level druid. It gains a +6 racial bonus on wild empathy checks. Its total modifier for this ability is +48.  

**Skills:** An elder sidhe receives a +8 racial bonus on Listen, Perform, Search, Spot, and Survival checks.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *