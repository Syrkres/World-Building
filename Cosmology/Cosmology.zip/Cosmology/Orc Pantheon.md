# Orc Pantheon
_Does not include individually stated gods._  

**Name:** Ezric  
**Gender:** f  
**Rank:** Demigod  
**Areas of Concern:** Passion, Personal Combat, Women’s Suffrage  
**Titles:** The *****, Queen of sows  
**Holy Symbol:** Pelvic Bone  
**Alignment:** CN  
**Preferred Weapon:** Dagger  
**Domains:** Chaos, Liberation, Protection  
**Description:** The sister of Ilneval, Ezric has always been the goddess of passion. She does not delight so much in seeing two orcs get together as she does in watching multiple orc males fight over a single female. This was a source of great amusement to this mercurial goddess until she started causing great upheavals in many orc tribes. Similarly, she caused similar problems among the pantheon as she was clearly the most beautiful of all the orc females and would pit male against male never giving in to either and always pretending that she had a new suitor to fight the other off with. Gruumsh felt that he would teach her a lesson and stop her antics in one fell swoop and married her to Yurtrus. Little is known of what befell her with Yurtrus other than she now completely covers her body whenever she is in the presence of other orcs but her face is still as radiant and beautiful as ever. It is believed that Yurtrus’ withering touch even has an effect on the gods. The only other thing that is known is that she gave birth to Genki. Once Genki was old enough to stand on his own, Ezric fled from Yurtrus. None know where she goes except that it is somewhere on limbo. Occasionally either Yurtrus or Genki bring her back but she is ever watchful of a chance to escape. In her role as goddess, Gruumsh’s plan backfired for now more than ever she delights in setting orc male against orc male and encourages all orc females to do the same and follow her example. Priests of Ezric preside over battles between males over females and also try and bait men as much as possible without giving in (sometimes leading to grave consequences for the female in question). Ezric appears as a woman fully obscured from neck to foot by a voluminous cloak. What can be seen is the height of orc beauty. Sometimes her gloved hand emerges from the cloak to wield a dagger but this is only when she feels that she is in danger. Her omens usually take the form of impotence or other forms of embarrassment to men.  

**Name:** Farok  
**Gender:** m  
**Rank:** Demigod  
**Areas of Concern:** Fate, Time  
**Titles:** The Giver of Days, The Measurer  
**Holy Symbol:** A pair of scissors about to cut a piece of thread  
**Alignment:** NE  
**Preferred Weapon:** Dart  
**Domains:** Destiny, Fate, Oracle, Planning  
**Description:** Farok is the god of Fate who measures the lives of all orcs and determines when their days will no longer be as great as the days before them and ends them abruptly. It is said that this is why so many orcs die before the end of their middle-aged period. Farok cares little for orc politics and secrets himself away from the other gods. He answers only to Gruumsh. Clerics of Farok prophesy for the tribe and are often petitioned by tribesmen who feel themselves getting old but wish to live longer. It is believed that Farok isn’t above a little bribery, which is why some orcs do eventually reach old and even venerable age. Priests of Farok typically only report bad news because they wish for such bribes. Farok appears as a normal orc male with a heavily lined face and thin fingers. Otherwise he looks vibrant and strong. Some say that his eyes look through whoever he looks at to their ultimate fate. His omens can take almost any form and priests of Farok believe that anything can be an omen.  

**Name:** Feng  
**Gender:** m  
**Rank:** Demigod  
**Areas of Concern:** Half-Orcs, Assassins, Stealth, Ninja  
**Titles:** The Silent Killer  
**Holy Symbol:** A kukri dripping blood  
**Alignment:** CN  
**Preferred Weapon:** Kukri  
**Domains:** Celerity, Luck, Trickery  
**Description:** Feng is the other lieutenant of Shargaas and the second half-orc to be allowed to ascend to godhood. Shargaas values the half-orcs for their lessened aggressiveness and higher perceptive ability and Shargaas greatly impressed him with his abilities of stealth. It is believed by many the Gruumsh allowed Feng’s ascension, as a means of combating the ever-growing cult of Nazarn, something that the orc gods believe is a grave threat to them. Feng allows half-orcs to have a role model worthy of emulation who fits in on the god’s hierarchy at the very bottom, teaching half-orcs that they must always be subservient to orcs. Nazarn’s philosophy of honorable and public combat is diametrically opposed to Feng’s own beliefs and Feng hates Nazarn with a passion. Followers of Feng are charged with killing followers of Nazarn whenever the opportunity arises. Priests of Feng tend to be either multiclass ninja/clerics or the benefactors and agents of assassins. Feng will sometimes prompt his priests towards a particular mark but usually he does not interfere. He only cares that his followers are good at what they do and deadly efficient. Feng appears as thin, smallish half-orc clothed in black ninja clothing. His kukri is never visible but he can produce it at a moment’s notice. Feng’s omens to his followers typically take the form of quick, sudden noises that draw attention to themselves.  

**Name:** Gar  
**Gender:** m  
**Rank:** Demigod  
**Areas of Concern:** Orogs, Destruction  
**Titles:** The Great Orog  
**Holy Symbol:** A skull with the top cracked in  
**Alignment:** NE  
**Preferred Weapon:** Greataxe  
**Domains:** Destruction, Force, Strength  
**Description:** Gar is an orog whom Ilneval feels best represents his philosophy that orcs must mate with stronger races to thrive. He championed his ascension although Gruumsh is not happy with a half-breed in the pantheon. Gar cares little for the politics of the pantheon and simply likes to be let loose in battle although he does like being the patron of orogs. Priests of Gar are almost always multiclass barbarian/clerics who unleash their great rage in combat after buffing themselves with spells. Gar appears as a gigantic orog roughly 12 feet in height leather armor and clutching a greataxe. Omens from Gar typically take the form objects mysteriously breaking.  

**Name:** Garthel  
**Gender:** m  
**Rank:** Demigod  
**Areas of Concern:** Snow, Winter  
**Titles:** The IceBreaker  
**Holy Symbol:** An axe made of ice dripping with blood  
**Alignment:** CE  
**Preferred Weapon:** Handaxe  
**Domains:** Cold, Storm, Weather, Winter  
**Description:** The lord of snow and the frost, Garthel is an orc who loves the cold and leads orcs in frozen lands against their enemies, especially snow elves and glacier dwarves. He is said to launch winter each year to spread his domain although Gruumsh always chastises him for this, which leads to the retreat of winter into summer. Clerics of Garthel revel in the cold and try to spread the cold as far as they can making many magical strongholds of ice in the process. Garthel appears as a large orc covered in a sheen of frost so that his hair appears to be composed of icicles. He wears leather armor and wields a handaxe. Omens from Garthel usually involve cold such as the sudden drop of temperature in an area or a chill wind blowing from a certain direction.  

**Name:** Genki  
**Gender:** m  
**Rank:** Demigod  
**Areas of Concern:** Pygmy Orcs, Cannibals, Jungles  
**Titles:** The Pygmy, The Cannibal, The Devourer  
**Holy Symbol:** A cooking pot with steam rising  
**Alignment:** CE  
**Preferred Weapon:** Shortspear  
**Domains:** Chaos, Death, Madness, Summer  
**Description:** Genki is the son of Ezric and Yurtrus. It is no wonder that the child of such a union is a twisted, deranged thing. Ezric has reviled Genki since birth although she at least took care of him until he was able to move on his own. Yurtrus has never shown much acknowledgment that Genki is his son although Genki has learned much about torture from observing his father. Genki has ever had an insatiable appetite, something else that Ezric loathes and he was soon devouring any creatures that he could find in Fleshslough or Acheron. As he got older he went for larger and larger faire until he started eating intelligent creatures and eventually orcs. No one knows if Genki has a philosophy beyond consuming anything that he feels will taste good. However, he does seem to take a paternalistic attitude towards pygmy orcs (he feeds on them less than others) and has been known to intervene on the behalf of their people when fighting great wars. Genki’s clerics are usually the master cooks of their tribe and believe that partaking of the flesh of others gives you their strength, which they believe is Genki’s philosophy as well. Genki appears as a small orc with overgrown arms for his size and one eye oddly larger than the others. He has a characteristically manic grin and is always depicted that way. Genki’s omens usually take the form of a sudden pang of hunger or craving for a particular type of food.  

**Name:** Grimlok  
**Gender:** m  
**Rank:** Demigod  
**Areas of Concern:** Death, Judgment, Travel  
**Titles:** The Judge, The Pilot, The Life Taker, The Cudgel  
**Holy Symbol:** Giant bat with a hooded rider on the back  
**Alignment:** LE  
**Preferred Weapon:** Club  
**Domains:** Death, Law, Repose  
**Description:** Grimlok is the pilot who takes souls to their designated afterlife. He is also the judge who appears to judge all departed orcs at the moment of death and designate whether they deserve to join their patron deity in death or to be designated to Fleshslough or Kabok. He is also become associated with travel due to the fact that he must journey throughout the planes and does so with great speed. Little is known of Grimlok and he is shrouded in as much mystery as Farok. Some believe that these two are one and the same. In either event, their areas of concern have overlap and they are often associated together. Clerics of Grimlok either tend to be travelers or messengers or the ones who preside over funeral rites and judge disputes between orcs. He is known as The Cudgel because of his club, which is used to “persuade” any spirits who resist his attempts to take him to another plane. After one hit from The Cudgel most spirits are docile until they are deposited at their destination. Grimlok appears as an orc skeleton wrapped in a black shroud with the hood drawn. His omens to his followers typically take the form of a sudden movement of bats in the area or the sudden death in either large or small creatures.  

**Name:** Gyen  
**Gender:** m  
**Rank:** Demigod  
**Areas of Concern:** The Mind, Dreams, The Supernatural  
**Titles:** The Dream Chief, The Mind Bender, Dweller in the Mystic  
**Holy Symbol:** An orc sitting in the lotus position  
**Alignment:** CG  
**Preferred Weapon:** Dagger  
**Domains:** Dream, Mind, Mysticism  
**Description:** Gyen is the friend of Touvos and the only deity to join him in exile. While Touvos believes in study and honing the mind, Gyen believes in meditation and enhancing the mental state. As such he presides over the mind itself, dreams, and all things supernatural. Gyen’s followers are even smaller than those of Touvos are but typically they come from the ranks of skalds, shaman, and enchanters. His priests are often multiclass clerics with either of those other classes. He has a high proclivity towards the enchantment school of magic, as one of the things that he hopes to gain through his meditation is the ability to influence others. Some of Gyen’s followers live among orcs as skalds or shaman but most are those orcs that could not fit into orc society and are living their lives as adventurers among the greater world. Gyen is always depicted as a tall, thin orc with small musculature in the lotus position and deep in meditation. Gyen’s omens always take the form of dreams.  

**Name:** Ilneval  
**Gender:** m  
**Rank:** Lesser Deity  
**Areas of Concern:** Warfare, Leadership  
**Titles:** The Horde Leader, The War Maker, The Lieutenant of Gruumsh  
**Holy Symbol:** Bloodied Longsword  
**Alignment:** NE  
**Preferred Weapon:** Longsword  
**Domains:** Courage, Destruction, Evil, Mysticism, War  
**Description:** The brother of Ezric, Ilneval is Gruumsh’s battle lieutenant to whom he trusts the command of warfare when he does not wish to exercise it himself. Ilneval is the archetype of the leader-from-the-front and plunges into battle with nothing but victory and destruction on his mind. Ilneval has deposed of several other orcish gods in his quest for power but he is fiercely loyal to Gruumsh. This does not extend to his son and Ilneval is jealous of Bahgtru but does not dare fight with him openly. Ilneval believes that the orc race must increase their strength by mating with stronger races such as ogres and is a fierce proponent of using orogs in battle and is the only orc god to accept orogs as clerics. Ilneval appears as a tall, unsmiling orc clad in red chainmail, very heavily battle-scarred about his face and arms. He sends omens to his priests in the form of blood seeping from chainmail.  

**Name:** Jergic  
**Gender:** m  
**Rank:** Demigod  
**Areas of Concern:** Boasts, Competition, Hunting  
**Titles:** The Braggart, The Great Hunter  
**Holy Symbol:** A giant hand wrapped around the throat of an elk.  
**Alignment:** NE  
**Preferred Weapon:** Greatbow  
**Domains:** Celerity, Competition, Glory, Strength  
**Description:** Jergic is the aggressive, confident hunter. He believes that those who know their strengths should let others know as well. He delights in seeing the skilled boast and he likes watching them shamed by others. He combines these two delights by sponsoring competitions to watch others compete each other to test their boasts. He is also a mighty hunter and carries his greatbow wherever he goes. He is technically subservient to Kargyev but from the way he boasts one would think that it is the other way around. Still, he does whatever he is told even if he always insinuates that it just goes along with his own plans anyway. Priests of Jergic are often ranger/clerics, scout/clerics, or barbarian/clerics. Jergic’s priests gain a reputation as great hunters and often train with the greatbow. They also preside over competitions and choose the winner. Jergic appears as a mighty orc hunter in brown leathers with a quiver slung across his back and a gigantic bow. He wears the skull of an elk on his head which legend has it was his first kill. Jergic’s omens to his followers typically involve a sudden rush of strength or extraordinary ability or the lack of ability to do a normal task.  

**Name:** Kag  
**Gender:** m  
**Rank:** Hero-God  
**Areas of Concern:** Cooking, Eating, Hunting  
**Titles:** The Great Chef  
**Holy Symbol:** A ladle with a meaty broth  
**Alignment:** CE  
**Preferred Weapon:** Club  
**Domains:** Creation, Luck  
**Description:** Kag is the first pygmy orc and the only known being to escape from Genki after the demented god had started to consume him. Kag’s offer earned him his life and Genki sponsored his ascension to godhood to continue as his chef for centuries ever after. Little is known of Kag other than that he enjoys carving up meat for his lord. He exemplifies chaos and evil even though he is loyal because the orders of his god lead to the suffering and death of others and he tells others to do the same. “Know your place because the leaders know how to cause more excitement then you ever could.” Kag wields a club that he uses to persuade uncooperative ingredients to do as they’re told. He only believes in cooking live meat. Priests of Kag although rare even among pygmy orcs are often master chefs. Typically they are multiclass expert (cook)/clerics and are the foremost chefs in a tribe. Kag appears as wide pygmy orc with uncommonly long arms. He is usually depicted in front of a cooking pot and wearing tattered clothes. Kag’s omens to his followers typically involve an unexpected taste appearing in a dish or a sudden blandness.  

**Name:** Kargyev  
**Gender:** f  
**Rank:** Demigod  
**Areas of Concern:** Forest Orcs, Hunting, Freedom, Woodlands, Fire  
**Titles:** The Huntress, The Fire Witch  
**Holy Symbol:** Deer pierced through the heart with an arrow  
**Alignment:** NE  
**Preferred Weapon:** Longbow  
**Domains:** Evil, Fire, Liberation, Plant  
**Description:** Once, the mistress of Gruumsh she spurned him when she learned that he was also bedding Luthic. Since then she has kept up a dalliance with Bargvar but has made no formal commitment. She is the mother of Shargaas and Savidge and is the other nature deity of the orcs. Kargyev is more accepted by orc culture in general because she revels in the savage, bestial side of nature. She hates those who hunt animals in overwhelming numbers or with superior technology. She particularly likes hunters who hunt alone and either unarmed or with one trusty weapon. She favors stealth more than most orc deities. It has kept her alive and she also prefers cunning deception of an enemy to outright besting in strength for she feels that it feels all the sweeter. Kargyev is also the orc goddess of fire, which is probably another reason that she is drawn to the woodlands. Ceremonies of her priests typically involve burning as many things as they can find that will catch fire and many times forest orcs must move because they have set a blaze that ends up burning down their own homes. Most of Kargyev’s priests are ranger/clerics or scout/clerics and they usually preside over hunting competitions to see which orc can bring back some selected game or to see which orc can bring back the most game. Kargyev is on good terms with Ezric, as both believe that women should have a stronger role in orc society. Kargyev appears as an orc of normal size of indeterminate gender. She wears forest green clothes and carries a longbow and quiver. Her eyes are usually depicted as dancing with flames. Omens from Kargyev usually take the form of an attack from a wild animal or finding prey the prey that you were tracking has already died.  

**Name:** Korak  
**Gender:** m  
**Rank:** Lesser Deity  
**Areas of Concern:** Nobility, Honor, Storm Orcs  
**Titles:** The First Emperor, Father of Honor  
**Holy Symbol:** An open scroll with blood red letters  
**Alignment:** LE  
**Preferred Weapon:** Orc Double Axe  
**Domains:** Community, Courage, Glory, Inquisition, Law, Nobility  
**Description:** The first emperor of Quarnost with named Korak. Legend says that he created the law of Sharg’troth after being dealt an almost fatal blow by his brother. As he waited for death he wrote down the rule of law that came to him in visions. He wrote with his blood and it is said that the words gave him strength until he recovered. While some dispute this as legend it is well documented that he presented the law and instituted it upon uniting the storm orc tribes into a single unified empire. Korak believes in the most rigid adherence to law and believes that only by eliminating chaos can one achieve one’s true potential. Korak believes in war to spread this belief and thus eliminate the chaos produced by other races. Only when the entire world is dominated by the rule of Sharg’troth can perfection be attained. Korak favors the nobles for he believes that they naturally lead the commoners. Many of Korak’s priests come from the lesser sons of the nobility and are typically multiclass aristocrat/clerics. Clerics of Korak study bloodlines and ensure lines of succession are upheld. They also rule on matters of Sharg’troth and root out magical and spiritual possession. Inquisitors are a powerful force in Quarnost due to Korak’s extreme hatred of mind control. Korak appears as a mighty and large orc lord with glistening banded male and a sash of medals and decorations across his chest. He wears a simple crown that appears as a golden band and wields an oversized double axe. Omens from Korak to his followers typically take the form of an accidental breach in Sharg’troth.  

**Name:** Luthic  
**Gender:** f  
**Rank:** Lesser Deity  
**Areas of Concern:** Female Orcs, Fertility, Medicine, Healing, Servitude, Caves, Home  
**Titles:** The Cave Mother, The Blood Moon Witch  
**Holy Symbol:** Orc rune for home  
**Alignment:** NE  
**Preferred Weapon:** Spiked Gauntlet  
**Domains:** Community, Earth, Evil, Healing, Protection  
**Description:** Luthic is the wife of Gruumsh and the paragon of female orc virtues. She obeys her husband without question, tends his wounds, and bears his children. She is fiercely jealous of any that seek to take her power away from her. Orcs who follow Luthic have a greater instinct for self-preservation than many other orcs but they are vicious to those in whom they sense some weakness. Clerics of Luthic hang back in battle to heal the wounded and return them to the front. Luthic appears as a huge female orc with unbreakable black claws four feet long. Her hair and eyes are dull black and her skin is dark brown, lighter around her nose and ears. Her omens to her priests take the form of claw marks in rock, a magical darkening of some area, or a rumbling in a cave mouth.  

**Name:** Maegric  
**Gender:** f  
**Rank:** Hero-God  
**Areas of Concern:** Mariticide, Runaways, Female Orcs  
**Titles:** She-Who-Kills-Men  
**Holy Symbol:** A broken orc marriage wreath  
**Alignment:** CN  
**Preferred Weapon:** Punching Dagger  
**Domains:** Strength, Travel  
**Description:** Maegric is the bane of the orc pantheon and one of their greatest embarrassments. Maegric was an orc wife who could not stand the abuse from her husband so one day after he was sleepy from eating a large meal and drinking a great deal of beer she punched her knife into his chest and then ran as fast as she could. She was hunted from that day forward but always eluded capture. Ezric took pity on her and sponsored her for divine ascension one of the few times that this has gone unnoticed by Gruumsh. Maegric now serves as the champion of women and endorses all of their efforts to throw off male oppression. Orc society has outlawed worship of Maegric, but many females worship her in secret. Even more secret are her priests who must masquerade as typical orc homemakers while worshipping the goddess that would have them live on their own terms. Many followers of Maegric end up killing their husbands or fathers and she aids them in their efforts of escape. Some priests must stay with the tribe, however, so that younger females may learn of Maegric. Maegric appears as a gigantic and formidable orc woman as tall as she is wide and arms as muscled as any man’s. Her omens to her priests typically take the form of a particularly nasty beating from their husband or father or if they have escaped a sense of being followed.  

**Name:** Meega  
**Gender:** f  
**Rank:** Demigod  
**Areas of Concern:** Light, The Moon  
**Titles:** The Shining One  
**Holy Symbol:** A moon with half white and half black  
**Alignment:** NE  
**Preferred Weapon:** Shortbow  
**Domains:** Community, Evil, Luck, War  
**Description:** Meega was an excellent example of orc femininity that Luthic petitioned for godhood. Her beauty was said to be so great that she was placed in the heavens for all to see. Even the hated sun could not stand to be near her beauty and fled before it. Sometimes it gains courage and tries to come out and attack her while she is still visible but she shoots at it with her shortbow and drives it off. Meega is often lauded as an aid to orc warbands at night and thus has a unique position as a female goddess petitioned by warriors. Priests of Meega are often the wives of orc soldiers who petition her to lead their husbands to victory and then lead them home safely. They champion the efforts of orc women to aid their men in giving them everything they might need such as making large amounts of food for the journey, repairing their armor, and so forth. Meega appears as a beautiful orc woman with a slight glow about her. Before her marriage, Ezric was said to be the most beautiful of all orc women but now consensus has it that it is Meega. Omens from Meega typically take the form of the moon passing underneath clouds or an unscheduled eclipse (in extreme circumstances).  

**Name:** Nazarn  
**Gender:** m  
**Rank:** Hero-God  
**Areas of Concern:** Formal and Public Combat  
**Titles:** The Gladiator  
**Holy Symbol:** A chain wrapped around a shortsword  
**Alignment:** N  
**Preferred Weapon:** Short Sword  
**Domains:** Luck, War  
**Description:** Nazarn is the first half-orc to ascend to godhood, which was an event of some note. Sponsored by Kord, it almost lead to a war between Kord and Gruumsh who felt that the ascension of anyone of orcish blood should have his ultimate approval. Nazarn is an inspiration to half-orcs although he does not limit himself to worship by them. He is the patron of any who fight honorably in the arena. Nazarn was a great warrior and greatly impressed Kord by defeating all of the opponents thrown against him. He does not care for moral or ethical debate. He simply wishes for freedom to do what he wishes and have a fair fight in the arena. This has put him at odds with Feng who believes in anything but a fair fight and neither deity can stand the other. Their followers are always at odds with one another. Priests of Nazarn usually work as professional gladiators or as officiators at formal duels. They often minister to gladiators after a battle. Their eyes are always open to find new potential gladiators to either test their mettle against them or to invite them to the arena. Nazarn appears as an older half-orc with a strongly orcish appearance and hair that is rapidly graying to white. He is often depicted with his sword, Crowdpleaser. Nazarn’s omens to his followers usually involve the reactions of a crowd to a duel or combat.  

**Name:** Savidge  
**Gender:** m  
**Rank:** Lesser Deity  
**Areas of Concern:** Swamp Orcs, Swamps, Nature, Plants  
**Titles:** The Protector, The Outcast  
**Holy Symbol:** The roots of a large swamp tree  
**Alignment:** N  
**Preferred Weapon:** Quarterstaff  
**Domains:** Animal, Creation, Mysticism, Plant, Protection, Water  
**Description:** Savidge is the son of Gruumsh and Kargyev and the half-brother of Shargaas. Savidge has forever been outcast from orc society due to Gruumsh’s falling out with Kargyev and due to his neutral tendencies. The other orc gods found Savidge weak and timid. The god set out on his own and became a beacon for other outcast orcs. After Touvos’s exile the two gods became friends and swamp orcs remain the only orc subrace that allows free worship of Touvos although few ever do. Savidge believes strictly in harmony in nature in both its brutal and beautiful forms. He and Obad-Hai are very friendly and druids are always welcome among swamp orcs. Clerics of Savidge patrol the swamps and keep them free the taint of civilization such as from pollution, constructs, or the undead. Less prone to fight than other orcs, they only defend themselves when provoked but neither will they help a non-swamp orc in trouble. The law of nature is everything a cleric of Savidge in accord with his teachings. Savidge appears a monstrously huge swamp orc that rises up from water covered in slime and muck. Savidge’s omens usually take the form of strange and sudden swamp noises or plants that only grow in a certain direction.  

**Name:** Shargaas  
**Gender:** m  
**Rank:** Lesser Deity  
**Areas of Concern:** Darkness, Thieves, Stealth, Night, Undead  
**Titles:** The Night Lord, The Blade in the Darkness, The Stalker Below  
**Holy Symbol:** Skull on a red crescent moon  
**Alignment:** CE  
**Preferred Weapon:** Short Sword  
**Domains:** Chaos, Death, Evil, Mysticism, Pestilence, Trickery  
**Description:** Shargaas is the orc deity of darkness, thieves, and assassins and is a lesser son of Gruumsh (with Kargyev). His philosophy is to take at night what cannot be taken by force. Tribes loyal to Shargaas often fight with poisoned weapons and darker tactics. They tend to flee in the press of combat, however – they have no stomach for prolonged battle. Shargaas is the only orc deity that will allow half-orcs to become clerics and many of his clerics are multiclass rogue/clerics or assassin/clerics. Shargaas toes the line in the orc pantheon. He will never oppose the interests of Gruumsh or Ilneval but he seeks to limit the influence of their priests. Shargaas has a particular hatred of Yurtrus and in tribes loyal to Shargaas worship of Yurtrus is not allowed. Shargaas appears as a tall, gaunt orc with jet-black eyes and skin, wearing a black cloak. His omens to his priests take the form of sudden chills in the air, lamenting moans, and dreaded “cold fevers” which inflict great pain.  

**Name:** Shauka  
**Gender:** f  
**Rank:** Demigod  
**Areas of Concern:** Wind, Life, Family, Nature, Swamp Orcs  
**Titles:** The Breather of Life, The Healer  
**Holy Symbol:** Hanging Moss  
**Alignment:** NG  
**Preferred Weapon:** Javelin  
**Domains:** Air, Community, Earth, Healing  
**Description:** Shauka is the wife of Savidge and the goddess of swamps and the swamp orcs. It is not known how a goddess devoted to goodness came to be among the orc pantheon. Tales of Shauka only begin with Savidge leaving the swamp and finding her there. Some believe that she is not an orc goddess at all. Others believe that she is an ascended swamp orc. What is known is that Shauka is like an elemental force of life. Her areas of concern and domains are all associated with the creation, nurturing, preservation, and extension of life. Unlike her husband she venerates nature in its most beautiful form and does her best to ensure that nothing is injured either in it or by it. As such she gets along well with Ehlonna much to her husband’s chagrin and finds Obad-Hai dour and difficult to get along with. Priests of Shauka tend to be activists in the community, healers, midwives, or diplomats. Many of them are multiclass ranger/clerics and they patrol the swamps to ensure their safety from others and the safety of those travelling through them. Shauka appears as a gigantic orc shaped elemental of air and earth. This of course only adds to the enigma of her origin. Omens from Shauka to her followers typically take the form of sudden, mysterious healing, strange tracks in the ground, or a sudden gust of wind.  

**Name:** Tarok  
**Gender:** m  
**Rank:** Demigod  
**Areas of Concern:** Scab Orcs, Raids, Desert  
**Titles:** The War Lord, The Giver of Thirst  
**Holy Symbol:** A head veiled in black with two red eyes peering out from the darkness  
**Alignment:** NE  
**Preferred Weapon:** Scimitar  
**Domains:** Summer, Thirst, Trickery  
**Description:** Tarok is the patron of scab orcs and one of the two lieutenants of Shargaas. Tarok believes in stealth and subtlety mixed with a fierce brutality once he has committed himself. He combines the worst elements of a rogue and barbarian, stealthily sneaking up on an encampment and slaughtering everyone in a bloody massacre once he is close enough. He has been called The War Lord due to his phenomenal success in his raids while in mortal form. Tarok is also the lord of thirst and it is said that he uses the desert to test his faithful. Priests of Tarok must spend two weeks in the desert naked and with no equipment before they can be initiated into his service. Clerics usually take on the role of water guardian in a desert tribe. It is said that Tarok withholds the right to decide who may or may not drink but others believe that the priests simply want to be near the water in case of a shortage or emergency. Tarok appears as a large orc clothed in black desert garments with a veiled face from which one can only see two red eyes. Tarok always carries a scimitar. When he is not using it, it is tucked in a black belt on his waist. Tarok’s omens to his followers usually take the form of a sudden increase in temperature in an area or stinging sands being blown up into someone’s face.  

**Name:** Thokesh  
**Gender:** m  
**Rank:** Demigod  
**Areas of Concern:** Tactics, Warfare  
**Titles:** The Plotter  
**Holy Symbol:** A chessboard with all the white pieces broken.  
**Alignment:** LE  
**Preferred Weapon:** Orc Double Axe  
**Domains:** Domination, Planning, Tyranny, War  
**Description:** Thokesh is the tactician. Whereas Ilneval represents the general who commands from the front, Thokesh is the general who commands from the rear. He pours over information and tries to analyze all the battle data before coming up with a suitably bloody and effective counter move. Thokesh is Ilneval’s chief advisor and the two usually plot campaigns together. Priests of Thokesh are chessmasters and strategists being some of the few orcs who can play chess (most orcs prefer Throg-Khack-Org a game akin to Tik-Tac-Toe). They are usually cunningly evil always trying to not only defeat their foe but also to humiliate and humble them. They are pragmatic, however, and will not give up a sure victory to prolong their foe’s agony. It is only a nice perk if they can make their opponent suffer and lose. Thokesh appears as an orc with an incredibly serious face and a brow always furrowed in concentration. He wields an orc double axe and wears red banded mail. Omens of Thokesh usually take the form of improbable consequences to meticulously planned events or an unpredicted variable quashing an otherwise certain victory such as a table breaking underneath a chessboard keeping either player from ascertaining victory.  

**Name:** Touvos  
**Gender:** m  
**Rank:** Lesser God  
**Areas of Concern:** Knowledge, Magic, Diplomacy  
**Titles:** The Coward, Elf-Friend, Father of Tales  
**Holy Symbol:** A tower rising out of sand  
**Alignment:** CG  
**Preferred Weapon:** Sling  
**Domains:** Chaos, Fate, Good, Knowledge, Magic, Pact  
**Description:** The father of Luthic, orc mytho-history says that Touvos lead the second rebellion against Gruumsh after Bargvar. The truth is that Touvos had long tried to persuade Gruumsh that orcs would be better off if they were more literate and studied the magic and technology of other races. Gruumsh dismissed what he called elven nonsense and called Touvos a coward. He was banished when he tried to tell Gruumsh that diplomacy might help the orcs negotiate for a better position among some of the other races. Enraged, Gruumsh picked up a sword and tried to cleave through Touvos who stepped back. Gruumsh only succeeded in gouging a huge scar down Touvos’ face over the eye. Touvos escaped and like Savidge tries to summon all outcast orcs who believe in goodness or simply want to better themselves through knowledge. He is on good terms with Savidge but is completely ostracized from other orcs, although skalds (bards) still pay him some tribute. His title as the Father of Tales comes from the time when he was still part of the pantheon. The appellations “The Coward” and “Elf-Friend” came later as orc curses against him although neither is true. Clerics of Touvos are often short lived, preaching against the establishment of orc culture. Those among the swamp orcs are simply scholars. Those who have escaped form orc culture entirely may be scholars, exemplars of a particular skill who seek perfection, or those who seek to champion the cause of good in the world. Many priests of Touvos are multiclass bard/clerics who ingratiate themselves into orc tribes as skalds and then through their tale telling try and undermine orthodox orc faith. Touvos appears as a stooped, thin orc of great age although it is clear that if he did not stoop that he would be toweringly tall. He has a scar down the right side of his face that is complete when he closes his right eyelid. He is always clad in brown robes.  

**Name:** Yurtrus  
**Gender:** m  
**Rank:** Lesser Deity  
**Areas of Concern:** Death, Disease  
**Titles:** White Hands, The Lord of Maggots, The Rotting One  
**Holy Symbol:** White hands on a dark background  
**Alignment:** NE  
**Preferred Weapon:** Unarmed Strike  
**Domains:** Death, Destruction, Evil, Madness, Pestilence  
**Description:** The orc deity of death and disease seeks the domination of all orcs and eventually all humanoids. His worship is barely tolerated by the rest of the pantheon but he brings great power and great fear both from the deities themselves and to the tribes. The smarter orc deities realize that this fear can be harnessed to keep mortals in line. Yurtrus appears as a huge, vaguely orcish giant covered with peeling and rotten green flesh. His hands are entirely normal save for being chalk-white. He has no mouth, and never communicates (orcs say “when White-Hands speaks” as a way of saying “Never”). His omens to the priests take the form of plagues and pandemics.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *