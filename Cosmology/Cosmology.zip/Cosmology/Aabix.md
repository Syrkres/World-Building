# Aabix the Devil Killer (CR 27)  
Demon Atrocity  
CE Huge outsider (chaotic, fire, evil, extraplanar, tanar'ri)  
Init +6; **Senses** blindsight 60 ft.; darkvision 60 ft.; Listen +51, Spot +51; trap sense +5; true seeing  
**Languages:** Abyssal, Celestial, Draconic; telepathy 100 ft.  
_________________________________  
**AC 39**, touch 18, flat-footed 29 (-2 size, +10 dex, +19 natural, +2 chains) Improved Dodge, Improved Uncanny Dodge  
**Hit Points:** 778 (36d8+612); DR 10/cold iron and good, DR 4/-; Fast Healing 10  
**Immune:** electricity, fire, poison  
Resist: acid 10, cold 10, fire 10; SR 35  
**Fort:** +37, Ref +32, Will +24  
_____________________  
**Speed:** 50 ft. (10 squares); Earth Glide 20 ft.  
Melee: Aabix Blade +58 (4d6+24/19-20) or  
Melee: slam +54 (2d6+20) or  
Melee: tail slap +54 (6d6+20) or  
Melee: Aabix Blade +58/+53/+48/+43 (4d6+24/19-20) and 5 Aabix Blades +58/+53/+48/+43 (4d6+14/19-20) and tail slap +49 (6d6+10) or  
Melee: 6 slams +54 (2d6+20) and tail slap +49 (6d6+10)  
Space: 15 ft.; Reach 15 ft.  
Base Atk: +36; Grp +68  
Atk Options: constrict 6d6+30, improved grab, greater rage 5/day, summon demon;  
Combat Gear:  
____________  
**Spell-Like Abilities (CL 36th):**  
At will -- align weapon, blade barrier (DC 24), magic weapon, project image (DC 24), polymorph, see invisibility, telekinesis (DC 23), greater teleport (self plus 50 pounds of objects only), unholy aura (DC 26).  
________________________________________________________  
**Abilities:** Str 50, Dex 30, Con 44, Int 7, Wis 18, Cha 26  
**SQ:** fast movement, indomidable will, powerful build, ravaged, tireless rage, true seeing, vulnerability to cold  
**Feats:** Cleave, Combat Reflexes, Dodge, Great Cleave, Greater Multiweapon Fighting, Improved Dodge, Improved Multiweapon Fighting, Lightning Reflexes, Mobility, Multiweapon Fighting, Power Attack  
**Epic Feats:** Improved Combat Reflexes, Perfect Multiweapon Fighting  
**Skills:** Concentration +56, Intimidate +45, Listen +51, Move Silently +31, Search +37, Sense Motive +43, Spot +51, Use Magic Device +27  
**Possessions:** 6 Aabix Blades (Gargantuan silvered +4 lawful outsider bane longswords), Manual of Mindless Might (minor artifact, reading a single word causes an instant and permanent +4 bonus to Strength and -4 loss to Intelligence. Cannot work on the same subject twice.), Chains (+2 armor bonus)  

**Constrict (Ex):** Aabix deals 6d6+30 points of damage with a successful grapple check. The constricted creature must succeed on a DC 48 Fortitude save or lose consciousness for as long as it remains in his coils and for 2d4 rounds thereafter. The save DC is Strength-based.  

**Improved Grab (Ex):** To use this ability, Aabix must hit with his tail slap attack. He can then attempt to start a grapple as a free action without provoking an attack of opportunity. If he succeeds on the grapple check, he can constrict.  

**Ravage-Ability Boost (Common):** Aabix has recieved a +4 bonus to Dexterity.  

**Ravage-Additional Movement Form (Abhorrent):** Aabix can Earth Glide at a speed of 20 ft.  

**Ravage-Blindsight (Vile):** Aabix has Blightsight with a radius of 60 ft.  

**Ravage-Elemental Subtype (Common):** Aabix has the Fire subtype.  

**Ravage-Fast Healing (Abhorrent):** Aabix has fast healing 10  

**Ravage-Ignore Damage Reduction/Hardness (Vile):** Aabix ignores 15 points of object hardness or creature damage reduction.  

**Ravage-Ignore Immunity to Critical Hits (Vile):** Aabix has a 50% chance to ignore critical hit immunity.  

**Ravage-Powerful Build (Common):** Aabix is treated as Gargantuan, rather than Huge, for all areas that are covered by Powerful Build.  

**Ravage-Virtual Class Levels (Vile):** Aabix has the abilities of an 18th level Barbarian.  

**Summon Demon (Ex):** Twice per day, Aabix can automatically summon 6d10 dretches, 1d6 hezrou, 1d4 nalfeshnee, 1d4 glabrezu, or 1d4 marilith. This ability is the equivilant of a 5th level spell.  

**True Seeing (Su):** Aabix continuously uses this ability, as the spell (caster level 36th).  

**Feats:** In combination with his natural abilities, Aabix's Multiweapon Fighting Feat allows him to attack with all his arms at no penalty.  

* * *
**Appearance**  
Far from the norm of his sisters, the monstrous yet beautiful mariliths, Aabix is the very image of horrific savagery. Every inch of his massive body, over 20 feet tall and 50 feet in length, is bulging with disgusting musculature, marked with scars of every sort. His skin and scales are dark gray like storm clouds, his eyes little more than orange orbs of spiraling and steaming fury. From his head hangs the torn and ravaged remains of a mane of long red hair. It, along with the rest of his body is stained in all manner of diabolic remains which seem to perpetually boil against his skin, but never evaporate. On his back is an untitled book, firmly strapped with chains that gouge deeply into Aabix's flesh.  

Aabix maintains a contorted and painful-looking posture, though it gives no discomfort to his body, which is extremely limber even by demon standards.  

**History**  
From the beginning of his existance, Aabix was noted to be an unusually alluring and mighty, yet inordinarily stupid, demon. It wasn't long before the brute was claimed by none other than Graz'zt, the Prince of Darkness, himself. Graz'zt delighted in Aabix much like a child with a new toy, and did much to augment his power. Aabix served primarily as a guard for one of Graz'zt's minor acquisition, eagerly hoping for a chance to slaughter anyone who dared approach. The particular area was home to a permanent portal to a part of Hades where Blood War battles were a regularity, and Aabix was happy to slice any approaching devils to pieces.  

One day, suddenly and without warning, Aabix was called from the Abyss by a malicious wizard who wished to test his latest creation, the Manual of Mindless Might. From the day he looked upon the pages of that book, what little intellect Aabix had was permanently shattered, but was in turn strengthed significantly, just as the book promised. He was then sent back to the Abyss with the book bound to him, though the wizard continued to keep an eye on him.  

It is unknown precisely what happened to Aabix after this time. Many diviners have come to the conclusion that soon after this event Aabix was buried under an avalanche of lava and super-heated rock, emerging later from solid stone, his former beauty still seeming to burn away.  

For the last few millennium, Aabix has been unintentionally leading vast demonic armies against the forces of Perdition, and is known throughout the planes as one of the greatest warriors of the Blood War. Thus far, all attempts to destroy Aabix have only succeeded in fueling his power and bloodlust, and some fear that he could grow to become a Demon Lord.  

**Nature**  
Aabix wavers between being a near-perfect representation of mindless fury and cold, animalistic cunning. Though never an intellectual, his mind is now only a little better than that of an ogre, and his only memories are of his complete hatred for devils and all other things, as well as his formidable martial talents. His only purpose in existing seems to be to kill devils and grow stronger so that he may kill more powerful devils. Beyond his desire to kill anything not of the Abyss, Aabix has no goals, no aims, and no real thoughts. When with his armies, Aabix fights with utter abandon, cutting through everything that approaches him. When alone, Aabix seems to have enough common sense to stalk his prey from beneath.  

**Organization**  
It makes little difference to Aabix, but many of the demons who fight the Blood War rally around him. Though none among them have anything even remotely resembling camaraderie with the Devil-Killer, all of them know that it is in their best interest to not turn against him. He is a prime target in all battles with the devils and daemons, and whoever is seeking to eliminate Aabix can’t focus equal attention to anything else.  

**Relations to other Powers**  
Aabix knows little and thinks nothing of the other powers of the Abyss, but many among them desire to possess him for any number of reasons. However, most attempts to capture Aabix are foiled by, if not by Aabix and his armies, other powers who would, in their infinite spite, prefer that Aabix belongs to no one rather than to their enemies. Many times Graz'zt has attempted to take back his former pet, only to have his forces stopped by those of Orcus or Demogorgon.  

---


A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

