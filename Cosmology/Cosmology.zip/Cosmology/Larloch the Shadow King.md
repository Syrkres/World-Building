# Larloch the Shadow King, the Last True Arcanist
**Wizard 17/Archmage 5/Arcane Lord19/Variator 5**  
**Medium Undead (archlich, augmented human)**  
**Hit Dice:** 46d12 + 598 (966 hp)  
**Initiative:** +7 (Dex)  
**Speed:** 30 ft.  
**AC:** 62 (+12 armor, +13 deflection, +7 Dexterity, +5 insight, +5 luck, +5 natural, +5 profane), touch 45, flat-footed 55  
**Base Attack/Grapple:** +23/+28  
**Attack:** +38 melee touch (5d8 + 13 [Will half DC 54] + curses [Will negates DC 54]); or _arcane fire_ +40 ranged touch (5d6 + 1d6/spell level); or spell +38 melee touch or +40 ranged touch.  
**Full Attack:** +38/+33 melee touch (5d8 + 13 [Will half DC 54] + curses [Will negates DC 54]); or _arcane fire_ +40/+35 ranged touch (5d6 + 1d6/spell level); or spell +38/+33 melee touch or +40/+35 ranged touch.  
**Space/Reach:** 5 ft. x 5 ft./5 ft.  
**Special Abilities:** _Arcane fire_, arcane mastery, _arcane shield_, curses, expanded spell power 3/day, gauge weakness 2/day, mastery of elements, mastery of shaping, metamagic effect, nether lore, recall spell 6/day, seize concentration, snatch spell, spellpool.  
**Special Qualities:** Arcane reach (60 ft.), backlash resistance 15, DR 25/epic and bludgeoning, fear aura, immunities, mind-link, phylactery, recognize spell, silver vulnerability, spell reflection, turn immunity, undead qualities.  
**Saves:** Fort +29, Ref +36, Will +43.  
**Abilities:** Str 20, Dex 24, Con —, Int 46, Wis 26, Cha 36  
**Skills:** Appraise +52 (+54 all craftable items), Bluff +47, Concentration +59, Craft (alchemy) +77, Craft (blacksmithing) +52, Craft (bookbinding) +52, Craft (calligraphy) +52, Craft (gemcutting) +52, Craft (metalworking) +52, Craft (trapmaking) +52, Craft (weaving) +52, Decipher Script +77, Diplomacy +53, Forgery +52, Hide +41, Intimidate +49, Knowledge (arcana) +77, Knowledge (architecture and engineering) +77, Knowledge (dungeoneering) +52, Knowledge (geography) +52, Knowledge (history) +77 (+81 Netheril), Knowledge (local [Netheril]) +77, Knowledge (nature) +52, Knowledge (nobility and royalty) +52 (+58 Netheril), Knowledge (the planes) +77, Knowledge (religion) +52, Listen +42, Move Silently +41, Ride +41, Search +52 (+58 vs. secret doors and compartments), Sense Motive +67, Slight of Hand +49, Spellcraft +148 (+160 to decipher scrolls), Spot +42, Use Magic Device +48 (+50 on scrolls).  
**Feats:** Arcane Manipulation, Arcane Mastery, Augment Spell, Chain Spell, Craft Construct, Craft Rod, Craft Wondrous Item, Greater Spell Focus (variation), Quicken Spell, Scribe Scroll, Skill Focus (spellcraft), Spell Focus (necromancy, transmutation, variation), Spellcasting Prodigy (wizard), Split Ray, Transdimensional Spell, Twin Spell.  
**Epic Feats:** Craft Epic Rod, Craft Epic Wondrous Item, Epic Arcane Manipulation, Epic Skill Focus (spellcraft), Epic Spell Artisan, Epic Spellcasting, Extra High Arcana (true mastery of elements, true mastery of shaping), Improved Metamagic x3, Improved Spell Capacity (10th, 11th, 12th), Multispell x2, Persistent Spell.  
**Salient Abilities:** Arcane Fire, Arcane Shield, Fear Aura, Greater Arcane Fire, Greater Arcane Shield, Improved Fear Aura, Improved Snatch Spell, Seize Concentration, Snatch Spell, Turn Immunity.  
**Climate/Terrain:** The Warlock's Crypt  
**Organization:** Solitary, or with study group (2d4 nec20/acm3 alumnus liches and 1d4 wiz24/acm4/var3 magister liches)  
**Challenge Rating:** 41  
**Treasure:** Ten times standard.  
**Alignment:** Lawful Evil  
**Advancement:** By character class.  

Larloch is said to be the last surviving Netherese arcanist-king, who ruled over his flying city for centuries and abandoned it before Karsus' Folly. Now a lich and one of the oldest non-draconic beings in Faerûn, Larloch has amassed an arsenal of spells, magic items, and servants. The Shadow King, as he is known in the Sword Coast, now rules the Warlock's Crypt (which is actually a corruption of Larloch's name) and its inhabitants—liches (many from Netheril), vampires, wights, and lesser undead.  

Larloch's sole driving motivation seems to be the accumulation of arcane lore. Though his control and understanding of magic is far beyond the ability of most spellcasters to even _comprehend,_ he remains unsatisfied. The author of such masterworks as _Precession and Binary Inversion_ and the great _Book of Inversion and Duplex_, his mastery of metamagic is unequaled even by many gods, and he has personally crafted many an artifact. Larloch remembers well the days of the Netherese Imperium, when mortal men rose in power until they challenged the gods, and wonders were worked that are still the stuff of legends thousands of years later. _He_ was one of those wonder-workers, and the secrets of the mightiest archmages in history yet live on in his mind, and in the thousands of tomes and grimoires he has collected over the centuries (including the original manuscripts of Kirasect's _Necrofolio_, Ralmevik's _Codex of Deviation Theory_, and Morianton's _Investigations and Observations_). But Larloch wants more, and it seems he will not rest until he has learned even the deepest secrets of arcane magic. Though some might say that this is an impossible task, that it would take forever to achieve, Larloch is unconcerned—he has time.  

An important focus of his research has been the reconstruction of the foundation of all Netherese magic—the Nether Scrolls. Though their creation is beyond even his vast power, he has spent many centuries patiently searching for and gathering as many of the originals as he could. His collection totals seventeen scrolls in all, including the complete _arcanis fundare_—the chapter focused on the nature of magic itself. Though the Netherese believed that this chapter contained only the most basic knowledge, and existed only to prepare a reader for more advanced material in the succeeding chapters, like all the scrolls it changes to match the knowledge of its reader. From the _arcanis fundare_ Larloch has drawn great insights into metamagic and epic spellcasting, and the nature of the Weave itself. This set of scrolls has formed the core of his arcane research, and even after over a millennium of study he continues to glean new revelations on the manipulation of magic. Having secured this chapter in its entirety, Larloch is less concerned with the others, though he plans to eventually secure a complete set.  

Having survived the cataclysm that resulted from the death of Mystryl, Larloch values the goddess of magic—and the Weave she protects—very highly. Probably the only thing that could draw him out of his studies would be an imminent threat to Mystra or the Weave. When the first Chosen of Mystra appeared, Larloch took note and spent many years observing and studying them very closely. When he was sure he understood correctly their purpose on Toril, he decided to never cross paths or interfere with them in any way. This should be considered in context, though. Larloch realizes that the destruction or malfunction of the Weave would mean the end of his research and the destruction of all he has accomplished in the last few millennia. He also receives many boons from Mystra—in exchange for disseminating many of his new discoveries, Mystra grants him great freedom in the research of mighty spells and the creation of powerful artifacts. In some ways the magic he works rivals that of ancient Netheril itself. (Note that two of the ten scrolls in his _arcanis fundare_ were recieved directly from the Lady of Mysteries herself as a reward for completing an important task; they did not come from either of the original sets, though—Mystra crafted them personally.)  

Larloch is completely secure in his knowledge and power, and feels no need to compete with anyone. When invaders threaten, he destroys them without remorse. When visitors come peacefully, he often allows them to leave, provided they render him some service that advances his studies—often the acquisition of some artifact or tome that he requires. At least sixteen powerful Red Wizards have tried to kill him and take his power, but all failed. Zulkir Szass Tam, on the other hand, approached him peacefully in negotiations and received two powerful artifacts from his hand. In the end, though, Larloch wants nothing more than to be left alone, to study and experiment in peace.  

Had Larloch desired to conquer Faerûn, he probably could have—or at the very least taken control of a sizeable piece. But he does not. Ruling nations does not interest him in the slightest—he had his fill of that in Netheril, and chose to step down some time before its destruction. He is, however, interested in creating and controlling a network of portals linking many planes and crystal spheres. Like all of his endeavors, this network would be used to advance his research, as the portals would be designed to relieve their users of powerful magic items, and record any arcane secrets contained in their minds. Though the portals themselves are simple enough to create (Larloch has personally visited more planes than almost anyone on Toril), the special enchantments are still proving problematic, even after various centuries of research. Never one to give up, Larloch plans to continue working on this problem until he perfects the process.  

Larloch's form has succumbed to the ravages of time. His flesh is completely gone, leaving only white bone draped in fine garments. His empty eye sockets glow with pinpoints of red light, and over two-dozen _ioun stones_ drift around his head.  

**Combat**  

If pressed in combat or bored with a situation, Larloch prefers to disappear, either with _greater teleport_, _etherealness,_ or a custom spell that allows him to walk through walls. Hidden within his tower are chambers that possess the major negative energy trait (so as to rapidly heal undead bodies), and he spends much of his time in such places. If forced to fight (or in the mood to do so), he enjoys using a rapid arsenal of _time stop_ and quickened twinned spells to overwhelm opponents before they even have the chance to react. He often ignores enemy spellcasters, relying on his spell reflection to take care of them while he focuses on other opponents. With the armory of items he carries with him, it is extremely doubtful that he could ever be caught unawares, and even if he were suddenly overwhelmed by attacks, he is protected by a _chain contingency_ spell that teleports him to one of his safe rooms, completely recovers his hit points, and cures him of ailments as the _greater restoration_ and _break enchantment_ spells, which activates if he loses more than half of his hit points. As a being over two thousand years old, Larloch has thought of ways to deal with almost any situation, and with his supragenius intellect he can compose near-perfect plans at will about situations for which he had not prepared.  

Larloch speaks speaks a wide range of ancient and obscure tongues, including Loross, Aragrakh, and Seldruin, as well as a variety of more mundane languages. His natural weapons are treated as epic for the purpose of overcoming damage reduction.  

**_Arcane Fire_** _(Su):_ Larloch can channel arcane spell energy into _arcane fire_, manifesting it as a bolt of raw magical energy. The bolt is a ranged touch attack with a range of 600 feet that breaks through barriers as a _divine blast_ and deals 5d10 points of damage plus 1d10 per level of the spell used to create the effect (maximum 17d10 damage from a 12th-level spell slot).  

**Arcane Mastery:** Once per day, Laroch may re-roll a random effect of any arcane spell he has just cast. He may then use either result. In addition, Larloch can take 10 on any caster level check, regardless of distractions.  

**_Arcane Shield_** _(Su):_ As a move-equivalent action, Larloch can expend a spell slot to create a barrier that absorbs incoming attacks. The barrier can absorb up to 5 hit points of damage per spell level before it collapses (maximum 60 hit points from a 12th-level spell slot). The damage can be from any source, including a _divine blast_ attack. Larloch can adjust the shield so that it does not block damage that he ignores anyway. He can only have one _arcane shield_ at a time.  

**Curses:** Trails of emerald energy occasionally travel across Larloch's body. These manifestations are a side effects of the defensive curses he protects himself with. If he touches a creature or is struck by a touch attack or unarmed strike, it is affected by a _bestow greater curse_ spell (Will DC 54 negates and spell resistance applies). In addition to the possible effects listed in the _Player's Handbook_ and _Book of Vile Darkness_, Larloch has also devised several unique curses. Some of Larloch's curses take effect days or weeks after this contact. A creature trying to remove one of these curses must make a caster level check to succeed, even with spells such as _wish_ or _miracle_.  

**Expanded Spell Power (Ex):** Three times per day, Larloch can cast any spell that has an effect that is capped by level (such as _fireball_) as if the cap were twice the listed amount. His caster level still applies to such limits. The spell's casting time is unaffected. Larloch decides whether to expand a spell's power when he begins casting.  

**Guage Weakness (Su):** Twice per day, Larloch may spend a standard action to analyze any single foe that he can see (even via a _scrying_ effect). He instantly knows all of that foe's current save bonuses (Fortitude, Reflex, and Will), thus allowing him to better tailor his spell choice for the encounter. If the target's save bonuses change at a later time, Larloch is not automatically privy to this information.  

**Mastery of Elements:** When Larloch casts a spell that deals elemental damage, the elemental damage is of the type that is most effective against the target. If a creature is equally vulnerable to multiple elements, he may choose which element the spell uses. The spell's casting time is unaffected.  

**Mastery of Shaping:** Larloch can alter area and effect spells that use burst, cone, cylinder, emanation, or spread shapes. He can create spaces within the spell’s area or effect that are not subject to the spell. The minimum dimension for these spaces is a 5 ft. cube. Larloch can also change the shape of the spell itself. The new area must be chosen from the following list: cylinder (10-foot radius, 30 feet high), 40-foot cone, four 10-foot cubes, or a ball (20-foot radius spread). He can increase the spell's area, range, and duration by 50 %. Finally, his spell effects can be delayed up to 3 rounds. The spell works normally in all respects except for its new shape.  

**Metamagic Effect (Su):** 21 times per day, Larloch can attempt to apply a metamagic feat she possesses to a persistent spell effect that is already in place. To use this ability, he must be adjacent to or within the spell effect and make a successful Spellcraft check (DC 18 + [3 x modified spell level]). Using this ability is a full-round action that provokes attacks of opportunity.  

**Nether Lore:** Before the fall of Netheril, Larloch was an archwizard of considerable power and prestige, and had full access to the legendary Nether Scrolls. He studied these intensly for many years, and reaped many benefits. From the _arcanis fundare_, Larloch gained a +30 inherent bonus on Spellcraft checks and a +1 bonus to the DCs of his arcane spells. From the _magicus creare_, he gained the Craft Rod, Craft Epic Rod, and Craft Epic Wondrous Item feats; he also learned the secrets of crafting items more efficiently, and only need expend 75% of the normal experience cost in item creation. From the _maior creare_, Larloch gained the Craft Construct feat, and how to craft constructs in such a way that they always gain the maximum number of hit points per hit die. From the _planus mechanus_, he learned to use _plane shift_ and _gate_ as spell-like abilities once per day, and he also discovered a ritual which, when he performed it, gave him immunity to any hostile or debilitating planar effects. From the final chapter, the _ars factum_, Larloch discovered the secrets and processes for creating artifacts--secrets he has closely guarded, and used only rarely.  

Having again obtained the _acanis fundare_, Larloch has unlocked many of its deeper secrets. He has gained the Arcane Mastery, Arcane Manipulation, and Epic Arcane Manipulation feats as bonus feats. He has also gained one additional epic spell slot per day. In addition, whenever he uses metamagic feats, the required increase in spell level (if any) is reduced by one (minimum +1 spell level). For example, he could cast a _quickened twinned fireball_ as a 4th-level spell.  

**Recall Spell (Su):** Six times per day, Larloch can use a standard action to recall any spell he has already cast within the past hour.  

**Seize Concentration (Su):** Larloch has the ability to wrest control of a spell that requires concentration from another spellcaster within 30 ft. If the target spellcaster is willing, this transfer of concentration occurs automatically. Otherwise, Larloch and the target spellcaster make an opposed caster level check. A divine spellcaster receives a +2 bonus on this check. If Larloch wins, he gains control of the spell for as long as he maintains concentration or until the original spell duration expires. The spell functions as though Larloch were the caster (even if it is a spell he cannot cast), except that any variables determined when the spell can cast (including its caster level), remain as determined by the original caster. The original spellcaster can be affected by her own spell, though she receives a +2 circumstance bonus on any saving throw allowed against it. If Larloch allows his concentration to lapse before the spell duration expires, the original caster may reassert control over her spell by making a successful caster level check (DC 15 + spell level). If she fails to do so, no one controls the spell, and it dissipates.  

**Snatch Spell (Su):** Larloch can attempt to seize control over a persistent effect created by another spellcaster. The effect must be one that does not depend on concentration but still relies on or responds to the caster's control. Furthermore, the effect (but not necessarily the spellcaster) must be within 30 ft. of him. If the target spellcaster is willing, this transfer of control occurs automatically. Otherwise, Larloch and the target spellcaster make an opposed caster level check. A divine spellcaster receives a +2 bonus to this check. If Larloch wins, he gains control of the spell until its original duration expires. The spell functions as if he himself had cast it, and he may change any of the variables of the spell that are normally set at casting time, including the application of metamagic and similar abilities. He may substitute his own caster level for the spell's original caster level. The original caster can be affected by her own spell, though she receives a +2 circumstance bonus on any saving throw allowed against it. If the spell is dismissible and Larloch wishes to dismiss it, he must make a second successful opposed caster level check to do so. If he fails, the spell remains in effect and control reverts to the original caster.  

**Spellpool:** As part of his efforts to simulate old Netheril, Laroch and his apprentices have constructed a highly sophisticated spellpool. Just as the arcanists of old Netheril could draw spells directly from the Weave, if Larloch leaves a spell slot of the appropriate level open, he can call a spell of his choice from his Spellpool. These spells can be enhanced with any metamagic feats he possesses, as well as the Empower Spell and/or the Enhance Spell feats, despite the fact that he does not possess them--they are embedded directly into the Spellpool. Larloch may also take advantage of his Arcane Manipulation and Epic Arcane Manipulation feats when using his spellpool.  

**Arcane Reach (Su):** Larloch can use spells with a range of touch on a target up to 60 feet away. He must succeed at a ranged touch attack. He can also apply his Split Ray and Chain Spell feats to such spells.  

**Backlash Resistance (Su):** Larloch has damage reduction 15 against backlash damage from casting epic spells. Each time he casts an epic spell with a backlash, that damage is reduced by 15 points (minimum 0). If the backlash damage continues for more than 1 round, the reduction is 15 points each round.  

**Fear Aura (Su):** Creatures with less than 46 HD in a 60-foot radius that look at Larloch must succeed at a Will save (DC 54) or be affected as though by a _fear_ spell cast by a 46th-level sorcerer. A creature that successfully saves cannot be affected again by Larloch's aura for 24 hours.  

**Immunities (Ex):** Larloch has immunity to cold, electricity, and polymorphing (though he can use _polymorph_ effects on himself).  

**Mind Link (Su):** Larloch shares a mental link with the 60 other liches (including at least three demiliches) that inhabit the Warlock's Crypt. This link has several important effects. First, their senses are joined. If one is aware of a particular danger, they all are. If one in the link is not flat-footed, none of them are. No member of the mind-link is considered flanked unless they all are. Second, their minds are in constant communication, and all members of the link receive a +8 circumstance bonus to all Intelligence-based skills and abilities, including wizard spellcasting. Finally, the individual mental strength of each lich serves to bolster the rest, and therefore when one member of the mind-link must make a Will save, all members make one. If even one of them succeeds, all are considered to have succeeded. But if all fail, every member of the link is affected fully as though the effect had been targeted at them specifically.  

Larloch is the keystone of this mind-link, and this position allows him to exert control over the others as though through a _dominate monster_ spell (automatically bypassing the undead immunity to mind-affecting effects). The other members of the mind-link are automatically considered to be willing when Larloch targets them with a spell or other special ability. It is quite likely that were Larloch somehow removed or cut off from the mind-link, none of the others would long survive.  

**Phylactery (Su):** If slain, Larloch's soul returns to his phylactery. Once within the phylactery for three days, he may return to life by possessing any corpse within 2,200 feet. The corpse, once possessed, has the same statistics as Larloch did before his destruction. While within his phylactery, Larloch can continue directing the mind-link, and when he returns to unlife, he may choose to possess any of its members instead of an unoccupied corpse (the evicted lich is then forced back into its phylactery.  

**Recognize Spell (Ex):** Larloch instantly knows when an arcane spell is cast within line of sight, even if he can't see or hear the caster. He also knows with unerring precision exactly what the spell is (including any metamagic effects). This ability doesn't grant any bonus to saves, but it can help Larloch's counterspell efforts immensely.  

**Silver Vulnerability (Ex):** Silver weapons automatically penetrate Larloch's damage reduction, and deal double damage to him. This unique vulnerability is the result of some of the permanent magical alterations he has made to his body.  

**Spell Reflection (Ex):** Any spells or spell-like abilities of 12th-level or lower that target Larloch or include him in their area of effect are automatically reflected back at their casters. Epic spells are also reflected, but he must first succeed at a caster level check (DC 11 + opponent's caster level). If the reflected spell cannot affect the caster, it simply fails. He may voluntarily lower this defense at will, such as when he casts a spell on himself.  

**Undead Traits (Ex):** As an undead creature, Larloch is immune to mind-affecting effects (charms, compulsions, phantasms, patterns, and morale effects), poison, sleep effects, paralysis, stunning, disease, and death effects. He is not subject to critical hits, nonlethal damage, ability drain, or energy drain, and is immune to damage to his physical ability scores (Strength, Dexterity, and Constitution), as well as to fatigue and exhaustion effects, and any effect that requires a Fortitude save (unless the effect also works on objects or is harmless). Larloch is not at risk of death from massive damage, but when reduced to 0 hit points or less, he is immediately slain. Larloch does not breathe, eat, or sleep.  

**Wizard Spells Per Day:** 14/14/14/13/13/13/11/8/10/10/4/3/5\. 50th caster level. Base DC = 36 + spell level, 37 + spell level for necromancy and transmutation spells, 38 + spell level for epic spells. 6 epic wizard spells (inc. one bonus variation spell), up to Spellcraft DC 158 (when taking 10; DC 178 with _moment of prescience_). Major field: variation; minor field: invention.  

Larloch's metamagic feats may be applied up to three times to the same spell, and have level increases as follows: Augment Spell (varies), Chain Spell (+1), Quicken Spell (+1), Split Ray (+1), Transdimensional Spell (+1), Twin Spell (+1), Persistent Spell (+3). All spell level increases from metamagic feats are decreased by one (minimum +1). Three quickened spells may be cast per round.  

Larloch typically prepares a variety of offensive, defensive, and utility spells, including a _quickened greater teleport,_ a _quickened time stop,_ and a _quickened twinned wail of the banshee._ All of his offensive spells are quickened and twinned, Most of his spells are prepared with a variety of metamagic feats, and he has spent long years determining the most effective metamagic combinations for each of them.  

**Spellbook:** As a wizard dating back to the time of Netheril, Larloch has access to spellbooks containing all arcane spells from the _Player's Handbook_, _Complete Arcane_, _Tome & Blood,_ all _Forgotten Realms_ sourcebooks, and any other source you deem appropriate. It is quite likely that he has access to most of the secret and unique spells developed by other NPCs, as well. In his millennia of life, Larloch has also developed dozens of epic spells, and always seems to have the perfect spell for any situation he encounters already prepared.  

**Possessions:** _Bracers of armor +12_, _mantle of resistance +5_, pair of _gloves of storing_ (containing his _staff_ and _scepter_), _Larloch's scepter_ (_+1 light mace of disruption_ that functions as a _rod of the epic spellcaster_ and a _greater rod of intensification_ usable 9/day), _ring of spellcraft +30_, _ring of x-ray vision_, _robe of eyes_, _staff of the magi_, _winged boots_ (4 hours per day). Ioun stones: bright orange cube, bright silver cylinder, cerulean rhomboid, dark blue rhomboid, dark gray spiral, dark green ellipsoid, dark purple spiral, dark red cube, deep green cube, deep red sphere, dull orange rhomboid, dusty rose ellipsoid, incandescent blue sphere, mottled gray sphere, 5 orange prisms, pale blue sphere, pale green prism, pale white sphere, pearlized black spindle, pink and green spiral, rich green star, shining black spiral, 2 vibrant purple prisms.  

**Wealth:** Larloch has an additional 10,000,000 gp or more worth of magic items in his lair, and knows all the properties of these items. If he is attacked or expecting to be attacked, he can arm himself with any non-artifact magic item ever created, as well as any of a large collection of artifacts, many of which he designed and built personally. It is possible that he has access to a minor _mythallar_ or similar device, allowing him to arm himself with numerous quasi-magical items and augment his already-considerable arcane prowess. His spellpool is also stored somewhere in the bowels of the Warloch's crypt, or possibly within a closed demiplane accessable from such a location.  


***

The dusty corridors of Warlock’s Keep led everywhere and yet nowhere, but Szass Tam knew where he was going. Walking through seemingly solid walls, Thay’s Zulkir of Necromancy felt his body magically whisked away to deeper and darker chambers of the Keep. The lich glanced around the halls as he walked‚ noting the many traps that would have destroyed a mortal form that walked these halls.  

“Larloch!” Szass called out, entering an ancient library. “I bring part of the payment that I promised you. Show yourself.”  

“Ashrath,” intoned a rumbling voice some distance away. The library slowly illuminated itself in a flickering red glow, casting a fiery light across the assembled tomes. “I’ve been expecting you, Tam,” the voice intoned. “But you’re still three weeks late with payment.”  

Szass Tam walked toward the sound of the voice, rounding the end of a bookshelf and strolling nonchalantly toward an ornate golden throne pushed into a corner. Larloch, the ancient lich who hailed from Netheril, sat amidst a clutter of books and braziers.  

The Shadow King’s body was in stark contrast to that of Tam. While the Zulkir of Necromancy strove to maintain his human appearance, Larloch was nothing more than a collection of bones partially covered in fine garments. The Netheril lich’s bones were bright white in color, and trails of emerald energy traveled across his form. More than two dozen ioun stones circled his skull, and globes of red light gazed up at Szass Tam as he approached.  

“As I expected, we ran into some Harper resistance,” Tam replied, taking a seat opposite the Shadow King. “They weren’t going to give up the mantle without a fight.”  

“If they had any inkling of its power‚ they wouldn’t have given it up in death‚ either‚” Larloch grumbled. With a wave of his hand‚ the entire collection of books that lay before him scattered back to their appropriate shelf. His skeletal hand then reached toward Tam. “The mantle?” he asked.  

Szass reached into a pouch and pulled from its magical confines a metal vest enveloped in a violet glow. Larloch’s red eyes shimmered briefly for a moment, determining the magic surrounding the mantle to be a form of preservation spell. He then took the vest from Szass and laid it on the table. A moment later‚ Larloch glanced up at Szass Tam. “Why are you still here‚ Tam?” questioned the ancient lich. “This part of your payment is completed.”  

“The search for this ancient magic has raised my curiosity,” the Zulkir replied. “I wish to know more about what Netheril really was.”  

A long moment of silence descended over the two undead creatures, their gazes locked on one another. If Szass would have had a heart, it would have been racing. Finally, Larloch replied.  

“You are both vain and impetuous,” the Shadow King replied. “All who have visited me in the past have been destroyed, regardless of their allegiance.”  

“That’s because the others who came before me were inept,” said Szass. “True,” replied Larloch. “You have not failed me,” he intoned. “Not yet.”  

Another long moment of silence filled the library. Years could have passed for all either of the undead cared. Time was meaningless. Finally, without warning or preamble, Larloch, the Shadow King, revealed the secret past of Netheril.  

~ Netheril: Empire of Magic  


**New Ioun Stones**  

COLOR SHAPE EFFECT  
----------------- ---------- -------------------------------------------------------  
Bright Orange Cube As -major cloak of displacement-  
Bright silver Cylinder As -cloak of etherealness,- double duration  
Cerulean Rhomboid As -ring of freedom of movement-  
Dark gray Spiral As -amulet of proof against detection and location-  
Dark green Ellipsoid +5 luck bonus to AC  
Dark purple Spiral As -rings of wizardry I-XII-  
Dark red Cube As -medallion of thoughts-  
Deep green Cube As -amulet of the planes-  
Deep red Sphere +6 enhancement bonus to Dexterity  
Dull orange Rhomboid As -brooch of shielding-  
Dusty Rose Ellipsoid +5 insight bonus to AC  
Incandescent blue Sphere +6 enhancement bonus to Wisdom  
Mottled gray Sphere As -ring of evasion- and -invisibility-  
Pale blue Sphere +6 enhancement bonus to Strength  
Pale green Prism +5 competence bonus on attack rolls, saves, and checks  
Pale white Sphere Recall 3 9th-level spells, as -pearl of power-  
Pearlized brown Ellipsoid As -boots of speed,- activates as a free action  
Pearly black Spindle As -ring of regeneration,- only functions on undead  
Pink and green Spiral +12 enhancement bonus to Charisma  
Rich green Star As -stone of good luck +5-  
Shining black Spiral As -helm of teleportation-  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *
