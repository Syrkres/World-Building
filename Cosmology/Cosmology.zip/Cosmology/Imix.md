# Imix, Prince of Evil Fire Elementals
**Gargantuan Elemental (Extraplanar, Evil, Fire)**  
**Hit Dice:** 40d8+26d10+726 (1306 hp)  
**Initiative:** +25 (+17 Dex, +8 Superior Initiative)  
**Speed:** 180 ft. (36 squares), burrow 90 ft., fly 90 ft. (good)  
**Armor Class:** 67 (+17 Dex, +25 natural, +10 insight, +9 deflection, -4 size), touch 42, flat-footed 50  
**Base Att/Grapple:** +38/+52  
**Attack:** _Inferno_ +62 melee (4d8+34 plus 3d6 fire plus 3d6 unholy/19-20 plus 6d6 fire plus 6d6 unholy); or slam +55 melee (2d10+20/19-20 plus 4d8 fire); or flamestream +55 ranged touch (10d8 fire); or spell +52 melee touch or +55 ranged touch.  
**Full Attack:** _Inferno_ +62/+57/+52 melee (4d8+34 plus 3d6 fire plus 3d6 unholy/19-20 plus 6d6 fire plus 6d6 unholy); or 2 slams +55 melee (2d10+20/19-20 plus 4d8 fire); or flamestream +55 ranged touch (10d8 fire); or by spell.  
**Face/Reach:** 20 ft./20 ft.  
**Special Attacks:** Burn, continual burn, final flash, flameburst, flamestream, radiant heat, spell combustion, spell-like abilities, summon elemental, turn elemental, wrath of the Inner Planes.  
**Special Qualities:** Acid and electricity resistance 20, archomental qualities, darkvision 60 ft., DR 10/--, DR 25/epic and cold, fast healing 9, fire absorbtion, fire immunity, fire incarnate, fire prime, fire subtype, heat sense, SR 48, vulnerability to cold.  
**Saves:** Fort +42, Ref +58, Will +40  
**Abilities:** Str 38, Dex 44, Con 32, Int 30, Wis 28, Cha 28  
**Skills:** Appraise +53 (+57 weapons), Bluff +52, Concentration +36, Climb +54, Craft (weaponsmithing) +52, Diplomacy +60, Disguise +9 (+13 acting), Hide +5, Intimidate +78, Jump +58, Knowledge (arcana) +30, Knowledge (history) +25, Knowledge (the planes) +53, Knowledge (religion) +20, Listen +54, Sense Motive +49, Spellcraft +32, Spot +54, Survival +52 (+56 planar), Tumble +61.  
**Feats:** Alertness, Awesome Blow, Blind-Fight, Cleave, Combat Expertise, Combat Reflexes, Dodge, Energy Substitution, Great Fortitude, Improved Bull Rush, Improved Combat Expertise, Improved Critical (greatsword), Improved Critical (slam), Improved Initiative, Improved Sunder, Improved Trip, Iron Will, Lightning Reflexes, Mobility, Power Attack, Power Critical (greatsword), Spring Attack, Weapon Finesse (slam), Weapon Focus (greatsword), Weapon Specialization (greatsword), Weapon Focus (slam), Weapon Specialization (slam), Whirlwind Attack.  
**Epic Feats:** Blinding Speed, Devastating Critical (greatsword), Epic Reflexes, Epic Weapon Focus (greatsword), Epic Weapon Focus (slam), Epic Weapon Specialization (greatsword), Epic Weapon Specialization (slam), Improved Combat Reflexes, Improved Whirlwind Attack, Overwhelming Critical (greatsword), Penetrate Damage Reduction (adamantine), Superior Initiative.  
**Climate/Terrain:** Elemental Plane of Fire  
**Organization:** Solitary (unique)  
**Challenge Rating:** 36  
**Treasure:** _Inferno_, quadruple standard (no flammables)  
**Alignment:** Chaotic evil  
**Advancement:** By character class  

_This 50-foot-tall creature is a red, flaming mass, humanoid-shaped but almost featureless except for eyes that burn white-hot. He wields a colossal greatsword studded with rubies._  

**Combat**  

Imix is haughty and confident in battle. He relishes combat and sets to hacking apart foes with his sword as quickly as possible, virtually ignoring his spell-like abilities unless he finds his foes more powerful than he expected.  

- **Archomental Qualities:** Imix possesses the following:  
• Damage Reduction: Imix has DR 25/epic and cold, as well as DR 10/--. This does not stack; only the best for the situation applies.  
• _See Invisibility_ at will (caster level 40th).  
• _Detect Magic_ at will (caster level 40th).  
• Immunity to poison, sleep effects, and stunning.  
• _Plane Shift_ (Su): At will, to the Elemental Plane of Fire only.  
• Elemental Leap (Su): If Imix is in contact with a fire of at least large size, he may transfer himself to another such blaze anywhere on the current plane. This ability otherwise works exactly like _greater teleport_.  
• Fire Absorption: If struck by fire attacks, Imix instead heals the damage it would otherwise deal.  
• Vulnerability to Cold: Imix takes 50% more damage from effects that deal cold damage.  
• Resistance 20 to acid and electricity.  
• Not subject to critical hits or flanking.  
• Darkvision 60 ft.  
• Fast Healing 9.  
• Turn Elementals (Su): Imix can turn or destroy water creatures as a good cleric turns undead. He can also rebuke, command, or bolster fire creatures as an evil cleric rebukes undead. He may do this 10 times per day as a 40th level cleric.  
• Regeneration (Ex): While in contact with fire, Imix gains regeneration 20\. Effects that the Imix creates himself does not cause this regeneration to activate, but indirect effects do. (For instance, his flaming aura would not give him regeneration, but if it set the trees in a forest ablaze, the forest fire would give him regeneration).  
• Spell Resistance 48.  
• Divine Rank 0: As the Prince of Elemental Fire, Imix gains a degree of might unknown to mortals and common elementals. He possesses immunity to polymorphing, petrification, or any other attack that alters his form. He is not subject to energy drain, ability drain, or ability damage. He is immune to mind-affecting effects. He is immortal and cannot die from natural causes. Imix does not age, and does not need to eat, sleep, or breathe. The only way for him to die is through special circumstances.  
• For the purpose of gate and similar spells, Imix is treated as a unique creature.  

- **Blazing Wake (Ex):** Imix leaves a roaring inferno behind him. The path of Imix's movement burns as an intensified _wall of fire_ spell. Both sides of the wall radiate heat, dealing 16 points of damage to those within 10 ft., and 8 points of fire damage to those within 20 ft. Those passing through the wall take 64 points of fire damage. This effect fades after 4 rounds.  

Imix can also remain in one place, causing the inferno to arise around him. If Imix does not move in the round, a 15 ft. radius flaming circle centered on him is formed, with all the same properties of the blazing wake.  

- **Burn (Ex):** Imix's slam attack deals bludgeoning damage plus fire damage from his flaming body. Those hit by Imix's slam attack must succeed on a Reflex save (DC 54) or catch on fire. The flame burns for 1d4 rounds. A burning creature can take a move action to put out the flame.  

Creatures hitting Imix with natural weapons or unarmed attacks take fire damage as though hit by his slam attack, and also catch on fire unless they succeed at a Reflex save.  

- **Continual Burn:** Those who are dealt fire damage from any of Imix’s fire attacks take half that damage the following round for the next 5 rounds. For example, a creature taking 20 points of fire damage from one of the Imix's slam attacks will take 10 points of fire damage the following 5 rounds.  

- **Elemental Metamorphosis (Ex):** Imix may assume a new shape and size based on his own preference. Any adjustments in size and or form may affect Imix's attack methods or size modifiers (including ability score changes, natural armor bonuses, and so on). Imix rarely uses this ability; he is haughty and confident in his ability to destroy foes in simple melee.  

- **Elemental Prime (Ex):** The might of Imix within his element is unquestioned. His attacks cut through fire resistances like a blade. Creatures with nonpermanent resistance or immunities (such as that from spells or magic items) have their protections subjected to a dispel check each they attempt to resist an elemental attack from Imix, as if he had cast _greater dispelling_. This check happens automatically. Items that are dispelled in this way remain inactive for 24 hours.  

Creatures with innate resistance or immunity are not safe from Imix’s attacks either. They must make a Fort save (DC 54) every time they are exposed to an attack they would resist or ignore. Failure indicates their resistance is stripped away completely, and success indicates it has been halved. Creatures with immunity who pass their save are treated as having resistance 40\. Imix may be able to strip other fire-based abilities away (also a DC 54 save, as appropriate). Imix cannot remove the fire resistance or immunity of creatures with divine rank or virtual divine rank greater than his own.  

- **Elemental Splendor (Su):** The presence of Imix brings with it all the glory of the Elemental Plane of Fire. The area within 80 ft. of Imix is suffused with the essence of fire, which has the following effects:  

The area becomes blisteringly hot. Unprotected flammable materials catch fire immediately, such as paper, cloth and wood. Those with unprotected clothing catch on fire. Magical flammable items, such as wand and scrolls get a save to avoid combustion. (Fort save DC 54). All metal in the area is treated as if under the 3rd round effects of a _heat metal_ spell if it fails the Fort save; success indicates that they are affected as if in the 2nd round of the spell instead. All items that fail their saves also take fire damage each round equal to 1d8 minus their hardness points. Metal and magic items that pass their save must continue to make a save every round they are within the aura. All creatures within the area take 5d6 points of fire damage a round.  

Imix may make his followers, allies, or beings of similar alignment immune to the negative effects of his aura. This immunity lasts until Imix dismisses it (a free action).  

- **Final Flash (Su):** If Imix is destroyed, he explodes in a spectacular shockwave of light and heat. Everything in 400 ft. must make a Reflex save (DC 54) for half damage, or take 200 points of divine damage and 200 points of fire damage. Anyone within 200 ft. must also make a Fortitude save (DC 54) or be knocked prone by the force of the blow. Anyone within 1000 ft. who witnesses the terrible explosion must make a Fortitude save (DC 54) or be struck blind.  

- **Flameburst (Su):** 3/day, as a full round action, Imix can release a blast of flame striking everyone in the area. All creatures within 30 ft. of Imix take 20d8 points of fire damage (Reflex save DC 54 for half) as an inferno bursts forth from the archomental’s inner self.  

- **Flamestream (Su):** As a standard action, Imix can release a jet of white hot flames at his foes. This is a ranged touch attack, which deals 10d8 points of fire damage. The max range on a flamestream is 60 ft., with no range increments.  

- **Heat Sense (Su):** Imix can detect the location and power of all heat sources within 400 ft. Within 100 ft., he may pinpoint the location of any creature that gives off heat, regardless of cover, concealment, darkness, etc.  

- **Radiant Heat (Ex):** Imix's body burns with the heat of a thousand suns. Any being within 10 ft. of Imix takes 2d8 points of fire damage per round.  

- **Spell-Like Abilities:** Caster level 84, save DC 17 + spell level.  
At will - _burning hands, combust, explosive cascade, fireball, fire brand, fire seeds, fire shield, fire stride, flame arrow, flame dagger, flaming sphere, flame strike, heat metal, produce flame, resist energy (resist cold or fire only), wall of fire._  
3/day - _delayed blast fireball, elemental swarm (as fire spell only), fire storm, incendiary cloud, meteor swarm._  
1/day - _rain of fire_.  

- **Spell Combustion:** As a full round action, Imix can trigger the release of fire spells within a spellcaster's repetoire. If the spellcaster he focuses on fails a Will save (DC 54), any spells with the fire descriptor they currently have memorized instantly activate upon the spellcaster's person, as though he instantly cast them all with himself as the target.  

- **Summon Elemental (Sp):** As a standard action, Imix can summon fire elementals. Imix may summon a total of 50 HD of small to elder fire elementals in a given day. 1/week, Imix may summon a primal fire elemental of up to 50 HD. Imix is under no obligation to use all of his limit at once, and may divide it up over the day as he sees fit. Imix prefers to meet worthy foes in single combat, and often summons other fire elementals only to order them off and burn down villages, attack unprotected civilians, and so on. He will summon a primal fire elemental only if he finds himself overmatched.  

1/day each, Imix may also summon 1d3 efreet, 1d6 salamanders, or 3d6 fire mephits. This is separate from his elemental summoning ability, and does not count towards that limit.  

- **Wrath of the Inner Planes (Sp):** 4/day, Imix may bring forth a blast of elemental fire. From his outstretched hand pours forth a roaring blast of white-hot flames, burning and melting everything in it's path. This attack deals 29d12 points of damage. Creatures caught in the blast may make a reflex save (DC 54) for half damage. The blast is a 60 ft. cone, and the damage type is ½ fire and ½ divine.  

- **Possessions:** Imix wields _Inferno_, a colossal _+7 fiery blast unholy power greatsword_. Anyone holding it is sheathed in a constant warm _fire shield_ effect, and the wielder takes 3d6 points of fire damage per round from the intense heat (whether the fiery blast power is active or not). It is studded with rubies, increasing its material value by another 10,000 gp or more. (_Caster Level:_ 50th; _Weight: 128 lbs.)_  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *