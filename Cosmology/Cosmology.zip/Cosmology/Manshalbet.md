# Manshalbet  the Merciless (CR 30)
**Demon Atrocity**  
CE Gargantuan Outsider (Chaotic, evil extraplanar)  
**Init** +2; **Senses** Listen +45, Spot +45, darkvision 60 ft. true seeing  
**Languages** Abyssal, Aquan, Celestial, Common, Draconic, Infernal, Terran, Undercommon  
_____________________________________________________________  

**AC** 43, touch 12, flat-footed 41 (+2 Dex, +31 natural, +4 profane, -4 size)  
**hp** 543 (36d8+468), regeneration ( 5/epic and good ); **DR** 20/cold iron, epic and good  
**Immune** acid, electricity, mind-affecting effects, polymorph, poison  
**Resist** cold 20 and fire 20; **SR** 38 (CR+8)  
**Fort** +33, **Ref** +22, **Will** +26  
_____________________________________________________________  

**Speed** 30ft. (6 squares), fly 40 ft.(poor), swim 45 ft.  
**Melee** bite +44 (3d8+12 plus 3d10 acid)  
2 claws +41 (2d6+6 plus 3d10 acid/19-20/x2 plus 1d6 plus Fortitude save 40 or death)  
**Melee** +44 touch  
**Ranged** +34 touch  
**Space** 20ft.; **Reach** 20 ft. (30 ft. with claws)  
**Base Atk** +36; **Grp** +60  
**Atk Options** Awesome Blow, Cleave, Great Cleave, Improved Bull-Rush, Improved Grapple, Improved Sunder, Power Attack, Swallow Whole, Trample 3d8+18  
**Special Actions** Breath weapon, nauseating stench, summon demons  
_____________________________________________________________  

**Spell-like Abilities (CL 36th):**  
At will – _acid fog_ (DC 25), _call lightning_ (DC 21), _feeblemind_ (DC 23), _greater dispel magic_, _slow_ (DC 21), _greater teleport_ (self plus 50 pounds only), _unholy aura_ (DC 26), _wall of acid_ (similar to _wall of fire_, but deals acid damage)  
3/day – _implosion_ (DC 27)  
_____________________________________________________________  

**Abilities** Str 35, Dex 14, Con 36, Int 22, Wis 22, Cha 27  
**SQ** acid body, telepathy 300 ft.  
**Feats** Aweome Blow, Cleave, Empower Spell-like ability, Great Cleave, Improved Bull-Rush, Improved Sunder, Improved Critical (claw), Persuasive, Power Attack, Quicken Spell-like ability, Weapon Focus (claw)  
**Epic Feats** Devastating Critical (claw), Overwhelming Critical (claw)  
**Skills** Bluff +47, Concentration +52, Diplomacy +47, Hide +29, Intimidate +47, Knowledge (arcana) +45, Knowledge (religion) +45, Knowledge (the planes) +45, Listen +45, Move Silently +41, Search +45, Sense Motive +45, Spellcraft +45 (+47 scrolls), Spot +45, Use Magic Device +47 (+49 scrolls)  
**Possessions** none  
_____________________________________________________________  

**Organization** Solitary (Unique) or with vessels (4-8 nalfeshness)  
**Environment** The city of Manshalb, Marshes of Loss, 225th layer of the Abyss  
_____________________________________________________________  

**Ravage – Acid Body (Su/Vile):** Manshalbet’s skin is covered by an acidic slime. Any weapon that touches it takes 3d6 points of acid damage from the corrosive acid, and the weapon’s hardness does not reduce this damage. A magic weapon may attempt a DC 41 Reflex save to avoid taking this damage. A creature who strikes Manshalbet with an unarmed attack, unarmed strike, touch spell, or natural weapon takes this damage as well but can’t negate it. Also, whenever Manshalbet is attacked by a ranged weapon or thrown weapon, a cloud of gaseous acid quickly corrodes it and destroys it, before it harms the demon. A magic weapon may attempt a DC 41 Fortitude damage to negate the effect. The save DCs are Constitution-based.  

**Ravage – Additional Movement Type (Ex/Abhorrent):** Swim 45 feet.  

**Ravage – Breath Weapon (Su/Vile):** Once every 1d6 rounds, Manshalbet can expel a vomit similar to a breath weapon. It’s a 60 feet cone of chaotic acid that deals 6d10 acid damage and 6d10 anarchic damage (Reflex save DC 41 for half damage). The save DC is Constitution-based.  

**Ravage – Energized Attacks (Su/Vile):** Manshalbet’s natural attacks deal 3d10 acid damage.  

**Ravage – Extended Reach (Ex/Vile):** Manshalbet’s reach with his claws attacks is increased by 10 feet.  

**Ravage – Immunities:** Manshalbet is immune to acid damage (Vile), mind-affecting effects (Vile) and polymorph effects (Abhorrent).  

**Ravage – Improved Grapple (Ex/Common):** To use this ability, Manshalbet must hit a Large or smaller opponent with his bite attack. He can then attempt to start a grapple as a free action without provoking an attack of opportunity. If he wins the grapple check, he establishes a hold and can try to swallow the foe the following round.  

**Ravage – Profane bonus to AC (Su/Vile):** Manshalbet gains a +4 profane bonus to AC.  

**Ravage – Regeneration (Ex/Vile):** Manshalbet takes normal damage from epic and axiomatic weapons, and from spells with the Good or Lawful descriptors.  

**Ravage – Spell-like abilities (Sp/Vile):** Manshalbet adds 21 levels of spells to his SLAs.  

**Ravage – Swallow Whole (Ex/Common):** Manshalbet can try to swallow a grabbed opponent of Large or smaller size by making a successful grapple check. Once inside, the opponent takes 2d6+6 points of crushing damage plus 2d6 points of acid damage and 2d6 anarchic damage per round from the demon’s digestive juices. A swallowed creature can cut its way out by dealing 40 points of damage to Manshalbet's digestive tract (AC 21). Once the creature exits, muscular action closes the hole; another swallowed opponent must cut its own way out. Manshalbet’s gullet can hold 2 Large, 8 Medium, 32 Small or 128 Tiny or smaller creatures.  

**Ravage – Trample (Ex/Common):** Manshalbet’s trample attack deals 3d8+18 bludgeoning damage (Reflex DC 40). The save DC is Strength-based.  

**Summon Demons (Sp):** Three times per day Manshalbet can attempt to summon 1d6 vrocks, 1d6 hezrous, or 1d4 glabrezus, or 1d4 nalfeshnees.  

**_True Seeing_ **_(Sp):_ Manshalbet continuously uses _true seeing_, as the spell (caster level 36th).  

**Warp – Nauseating Stench (Su):** Instead of a smite attack, the Merciless can create a nauseating stench to debilitate his enemies. Three times per day, Manshalbet can expel his cloud of acid gas in a 60-foot radius burst. Any creature within this area must succeed on a DC 41 Fortitude save or be nauseated for 1d10 rounds, by the horrible stench of it. The save DC is Constitution-based.  

* * *

**Appearance:**

Manshalbet is a terrifying creature, and he never assumes illusionary forms or disguises. He is an enormous demon, standing 60 feet tall. He is morbidly obese, barely standing on two muscular bovine legs. His hooves are always dripping acid, slowly corroding any surface where he stands. His skin is of a corrosive yellow color, always covered in an acidic slime. He’s always covered in a gaseous acid cloud. His stomach is enormous, and his arms are very long, ending is huge clawed hands. He has a pair of wings that rot, being almost bare bones but still able to make him fly. His enormous head is that of a gaunt demonic bull without horns, his mouth dripping acid and his black eyes filled with hatred.  

**History:**  

Thousands of years ago, there was a powerful demon named Levadigass. This demon ruled over a remote layer, without ever leaving it. He was a servant of Orcus, but he was almost ever forgotten by his master, who never required his assistance. Nevertheless, he was afraid of the Prince of Undead and would obey him anytime. He had achieved great power when he found a source of chaotic essence in his realm, a giant pool of acid that ravaged his essence and made him much more powerful than he ever was. His body couldn’t sustain too much of it, however and he only bathed in it when he knew it was safe. This pool was his most deep secret, and no one knew of it. Or so he thought.  
One day, the Goat required his service in a great battle with the armies of Grazz’t. Without thinking that one of his servants could have known his secret, he left to serve his dreaded master. A nalfeshnee named Manshalbet was left to take care of his dominions in his absence. Manshalbet knew the secret of his master for long, but waited for the right time to take advantage of it. When his master left, he went to the pool and bathed on it, brutally ravaging his essence. By doing this, he drew all that was left of the power of the pool, but was more powerful than he ever was. When Levadigass returned victorious, he found his former servant ruling over his realm. Furious, but still unable to destroy him by himself, he sought the aid of Orcus. The Goat assisted him, and Manshalbet was defeated and forced to flee or meet his destruction.  
Frustrated, he fled to a remote layer, named Marshes of Loss.  
Using the great powers he had gained, he started to conquer the cities in the layer one by one. He began his conquer with the largest city in the layer, subduing the former balor lord and humiliating him by turning him into a palrethee under his command. Manshalbet then turned his attention to the rest of the layer. He believes that by conquering it entirely he will achieve the Demon Lord status.  
He quickly wiped out all resistance near him, but then found two obstacles, Kibomarch the demon dragon and Vaydryx, the lord of the swamps. Now, he is at war against them, and his main concern is destroying them, and achieving even more power. When he does so, he plans to take on his former master and get his revenge.  

**Nature:**  

Manshalbet is a coward. He fled to a distant and remote layer just to be far from his former master, but not only that. Manshalbet’s truly reason for leaving is not Levadigass, but Orcus. He’s terrified by any being more powerful than him, and seeks isolation to somehow become stronger and subduing the weaker than him. He delights in opressing and inflicting pain in the creatures less powerful than him.  

**Organization:**  

In order to accomplish his goals, Manshalbet employs his terrified minions. He is smart enough to realize that his servants only bow to him because they fear him, and so he trusts no one. This could have made him paranoid, but instead the overconfident demon believes that all others are so lower than him that he has not to fear anything. Most of his minions are warriors that fight against the armies of the other lords of the Marshes of Loss, although few are spies sent to gather information for him. This role is usually left for those who need punishment for any reason, as almost all ends up dead in a horrible death, even for a demon.  
He specially enjoys employing Sohdok, the former balor ruler of the city of Manshalb, a palrethee. Sohdok loathes his master, but is also afraid of him. He was once defeated and humiliated, and don’t want to be destroyed before he can get his revenge. He obeys his master and unleashes his anger in the enemies of his lord. Manshalbet is aware of this revengeful intention but couldn’t care less, as he believes the palrethee is no threat to him.  

**Relations to other Powers:**  

Manshalbet is aware of his impotence in relation to the great powers of the Abyss. He learned this in the hard way, when he was defeated by Levadigass, only because of the assistance of Orcus. To prevent the influence of such powers, he chooses isolation. In the slimy Marshes of Loss, he’s far from the influence of the Princes that rule the Abyss. He is interested in alliances, but only with those weaker than him. The King of Ghouls is considered a possible ally, but he already is a vessel of the Prince of Gnolls. An attempt to approach Juiblex ended up with the death of all his emissaries.  
Devils are despised by Manshalbet, but his demonic enemies are his priorities in the moment. The powers of the heaven also aren’t a priority in Manshalbet’s agenda.  


***

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *