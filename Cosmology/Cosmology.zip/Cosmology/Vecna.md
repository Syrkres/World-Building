# Vecna, The Maimed Lord
_The Maimed Lord, The Whispered One, The Master of All That is Secret and Hidden, The Chained God, The Arch-Lich, Lord Whisper_  
**Lesser Oerthian Deity**  
**Symbol:** Left hand clutching an eyeball  
**Home Plane:** Material Plane (Oerth)  
**Alignment:** Neutral Evil  
**Portfolio:** Secrets, intrigue  
**Worshipers:** Wizards, sorcerers, conspirators  
**Cleric Alignments:** CE, LE, NE  
**Domains:** Evil, Knowledge, Madness, Magic  
**Favored Weapon:** Dagger  

VECNA  
Wizard 30, Loremaster-15, Archmage-5  
Medium Undead  
**Divine Rank:** 10  
**Hit Dice:** 30d12+330 (Wiz) plus 15d12+165 (Lor) plus 5d12+55 (Acm) (1150 hp)  
**Initiative:** +4 (+4 Dex)  
**Speed:** 60 ft. (12 squares)  
**Armor Class:** 77 (+4 Dex, +10 divine, +25 natural, +12 armor, +11 deflection, +5 profane), touch 40, flat-footed 73  
**Base Att/Grapple:** +25/+38  
**Attack:** _Afterthought_ +44 melee (1d4+13 plus +2d6 unholy/19-20) or deadly touch +38 melee (1d8+11 plus Fort DC 58 or die); or spell +38 melee touch or +39 ranged touch.  
**Full Attack:** _Afterthought_ +44/+44/+39 melee (1d4+13 plus +2d6 unholy/19-20) or deadly touch +38/+33 melee (1d8+11 plus Fort DC 58 or die); or by spell.  
**Space/Reach:** 5 ft./5 ft.  
**Special Attacks:** Arcane reach, domain powers, fear aura (DC 46), magic mimicry, mastery of counterspelling, mastery of elements, mastery of shaping, paralyzing touch (DC 46), salient divine abilities, spell power, spell-like abilities, spells.  
**Special Qualities:** Alternate form, divine aura (1,000 ft., DC 31), divine immunities, DR 25/epic, good, silver and bludgeoning, familiar (snakes), fire resistance 15, godly realm, _greater teleport_ at will, permanent spells, _plane shift_ at will, secrets, SR 87, undead traits, understand, speak, and read all languages and speak directly to all beings within 10 miles, remote communication.  
**Saves:** Fort +45, Ref +47, Will +64.  
**Abilities:** Str 17, Dex 18, Con --, Int 46, Wis 38, Cha 32.  
**Skills:** Appraise +51, Bluff +23, Concentration +74, Craft (alchemy) +48, Decipher Script +57, Diplomacy +23, Disguise +23, Hide +24, Intimidate +23, Knowledge (arcana) +91, Knowledge (history) +81, Knowledge (nobility and royalty) +33, Knowledge (religion) +81, Knowledge (the planes) +81, Listen +33, Move Silently +24, Search +55, Sense Motive +31, Spellcraft +97, Spot +33, Survival +23 (+29 planar)  
**Feats:** Brew Potion, Craft Magic Arms & Armor, Craft Rod, Craft Staff, Craft Wand, Craft Wondrous Item, Empower Spell, Enlarge Spell, Eschew Materials, Extend Spell, Forge Ring, Greater Spell Penetration, Heighten Spell, Maximize Spell, Scribe Scroll, Silent Spell, Spell Penetration, Still Spell, Violate Spell, Widen Spell.  
**Epic Feats:** Epic Skill Focus (Knowledge [arcana]), Epic Skill Focus (Spellcraft), Epic Spellcasting, Ignore Material Components, Improved Heighten Spell, Improved Metamagic, Multispell (x2).  
**Environment:** Material Plane  
**Organization:** Unique  
**Challenge Rating:** 54  
**Treasure:** _Afterthought_, _bracers of armor +12_, _cloak of resistance +12_  
**Alignment:** Neutral Evil  
**Advancement:** --  
**Level Adjustment:** --  

- **Lich Salient Abilities:** Agonizing gaze, deadly touch (Will DC 58 half, Fort DC 58 or die), fear aura, forbidden lore +84, improved command (+25), improved fear aura (Will DC 58, up to 60 HD), paralyzing gaze (Fort DC 58 negates), paralyzing touch, rebuke undead (as 55th level cleric), undead mastery (500 HD). Vecna's natural attacks are treated as epic and evil for the purposes of overcoming damage reduction.  
- **Secrets:** Vecna has learned newfound arcana (1 bonus 1st-level spell), more newfound arcana (1 bonus 2nd-level spell), applicable knowledge (any one feat), secrets of inner strength (+2 bonus on Will saves), and the lore of true stamina (+2 bonus on Fortitude saves).  
- **Arcane Reach (Su):** Vecna can use spells with a range of touch on a target up to 30 feet away. Vecna must make a ranged touch attack.  
- **Mastery of Counterspelling:** When Vecna counterspells a spell, it is turned back upon the caster as if it were fully affected by a spell turning spell. If the spell cannot be affected by spell turning, then it is merely counterspelled.  
- **Mastery of Elements:** Vecna can alter an arcane spell when cast so that it utilizes a different element from the one it normally uses. This ability can only alter a spell with the acid, cold, fire, electricity, or sonic descriptor. The spell's casting time is unaffected. Vecna decides whether to alter the spell's energy type and chooses the new energy type when he begins casting.  
- **Mastery of Shaping:** Vecna can alter area and effect spells that use one of the following shapes: burst, cone, cylinder, emanation, or spread. The alteration consists of creating spaces within the spell's area or effect that are not subject to the spell. The minimum dimension for these spaces is a 5-foot cube. Furthermore, any shapeable spells have a minimum dimension of 5 feet instead of 10 feet.  
- **Spell Power:** This ability increases Vecna's effective caster level by +1 (for purposes of determining level-dependent spell variables such as damage dice or range, and caster level checks only).  
- **Permanent Spells:** Vecna has used _permanency_ upon the following spells: _arcane sight_, _read magic_, _see invisibility_.  
- **Undead Traits:** Darkvision, not subject to critical hits or nonlethal damage.  
- **Divine Immunities:** Ability damage, ability drain, acid, cold, death effects, disease, disintegration, electricity, energy drain, mind-affecting effects, paralysis, poison, _sleep_, stunning, transmutation, _imprisonment_, _banishment_, turning or rebuking.  
- **Divine Power:** Vecna is a living embodiment of power, and ancient divine magics flow through his veins. As such, mortal items are of virtually no use to him, being so much weaker than his own innate powers. Vecna gains no benefit from a deflection, enhancement, resistance, insight, sacred or profane bonus that is less than +10\. Note that this only applies to bonuses that affect Vecna himself; weaponry and armor is unaffected by this.  
- **Salient Divine Abilities:** Arcane Mastery, Automatic Metamagic (quicken wizard spells), Craft Artifact, Divine Blast (14/day, 21d12 damage), Divine Shield (14/day, absorbs 100 damage), Divine Spellcasting, Extra Domain (Madness), Increased Damage Reduction, Increased Spell Resistance, Know Secrets, Spontaneous Wizard Spells, True Knowledge.  
- **Alter Reality:** Vecna can use the _wish_ spell with regard to his portfolio, save for the replication of other spells. This ability costs Vecna no XP, and requires a standard action to implement. Vecna adds once again his Intelligence modifier for determining spell saving throw DCs. As a free action 10/day, for one round at a time, Vecna may add +11 to his effective spellcaster level.  
- **Domain Powers:** 1/day, add +25 to a single Wisdom-based skill check or Will save; cast divination spells at +1 caster level; cast evil spells at +1 caster level.  
- **Spell-Like Abilities:** Vecna uses these abilities as a 60th-level caster, except for divination spells and evil spells, which he uses as a 61st-level caster. The save DCs are 41 + spell level. _Antimagic field, bolts of bedevilment, blasphemy, confusion, clairaudience/clairvoyance, create undead, desecrate, detect secret doors, detect thoughts, discern location, dispel good, dispel magic, divination, find the path, foresight, identify, imbue with spell ability, insanity, legend lore, lesser confusion, maddening scream, magic circle against good, Mordenkainen's disjunction, Nystul's undetectable aura, phantasmal killer, protection from good, protection from spells, rage, spell resistance, spell turning, summon monster IX_ (as evil spell only)_, touch of madness, true seeing, unholy aura, unholy blight, weird._  
- **Spells:** As a 51st level wizard (62nd with alter reality), +65 vs. spell resistance (+76 with alter reality). Vecna may cast up to 5 epic spells per day, up to DC 107 (when taking 10).  
- **Wizard Spells/Day (Levels 0-18):** 4/10/10/8/8/7/7/5/6/7/4/3/3/3/3/2/2/2/2; base DC = 47 + spell level.  
- **Possessions:** Vecna carries _Afterthought_, a _+6 ghost touch speed unholy wounding dagger_. A spellcaster struck by this weapon loses 1d4+1 spell slots for the day (beginning with his highest available spell levels), as chosen by Vecna. (_Caster Level:_ 50th, _Weight:_ 1 lb.) Besides his dagger, Vecna wears _bracers of armor +12_ and a _cloak of resistance +12_.  

**Other Divine Powers**  
- As a lesser deity, Vecna may take 10 on any check. Vecna treats a 1 on an attack roll or saving throw normally and not as an automatic failure. He is immortal.  
- **Senses:** Vecna can see (using normal vision or darkvision), hear, touch, and smell at a distance of ten miles. As a standard action, he can perceive anything within ten miles of his worshippers, holy sites, objects, or any location where on of his titles or name was spoken in the last hour. He can extend his senses to up to five locations at once. He can block the sensing power of deities of his rank or lower at up to two remote locations at once for 10 hours.  
- **Portfolio Sense:** Vecna can sense the discovery, recording, or sharing of any secret that affects at least five hundred people (such secrets might be political such as a secret alliance, or personal such as a leader's illness).  
- **Automatic Actions:** Vecna can use Knowledge (arcana), Knowledge (history), Knowledge (religion), Knowledge (the planes), or Spellcraft as a free action if the DC for the task is 20 or lower. He can perform up to five such free actions each round.  
- **Create Magic Items:** Vecna can create any kind of magic item.  

**Avatars**  
- Vecna's avatars appear like him; a richly dressed human skeleton in black robes. His left hand is missing, and his left eye socket is a pit of darkness, while his right socket burns with a pinpoint of crimson light.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *