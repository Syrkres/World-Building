# The Ebon Flame (CR 28)
**Demonic Atrocity (half-fiend red wyrm)**  
CE gargantuan outsider (Chaotic, evil, fire, native)  
**Init** 0; **Senses** Listen +47; Spot +47; Blindsense 60 ft.; Darkvision 120 ft.  
**Aura** Frightful Presence  
**Languages** Abyssal, Draconic  

----  

**AC** 43, touch 6, flat-footed 43 (+37 Natural, -4 Size)  
**hp** 449 (37d12+403-198); DR **20/magic  
Immune Fire, Poison, Magical Sleep, Paralysis, Mind-affecting effects, Stunning, Disease, and Death effects  
Resist Acid 10, Cold 10, Electricity 10; [b]SR** 35  
**Weaknesses** Cold.  
**Fort** +31, **Ref** +22, **Will** +27  

----  

**Speed** 40 ft (8 squares)., fly 200 ft. (clumsy)  
**Melee** Bite +48 (4d6+17+1d8neg+energy drain), and Claw +48/+48 (2d8+8+1d8neg), Wings +48/+48 (2d6+8+1d8neg), Tail Slap +48 (2d8+25+1d8neg)  
**Base Atk** +37; **Grp** +64  
**Atk Options** Great Cleave, Flyby Attack, Rend, Snatch  
**Special Actions** Breath Weapon, Hover, Power Climb, Wingover, Rebuke Undead  

----  

Spell-like Abilities (CL 17): 11/day - _locate object_, 3/day - _suggestion_ (DC 21), 1/day - _find the path_  
(CL 37) At will-_Animate Dead, Animate Objects, Awaken, Call Lightning Storm, Create Undead, Enervation, Ray of Enfeeblement, Scrying, Spectral Hand, Vampiric Touch, Waves of Fatigue_  
3/day Darkness - _Poison, Unholy Aura_, 1/day- _Blasphemy, Contagion, Desecrate, Destruction, Horrid Wilting, Summon Monster IX, Unhallow, Unholy blight, Wail of the Banshee_; save DC 18+spell level  

----  

**Abilities** Str 45, Dex 14, Con 33, Int 28, Wis 25, Cha 26  
**SQ** low-light vision  
**Feats** Cleave, Great Cleave, Flyby Attack, Hover, Improved Initiative, Improved Multiattack, Magical Aptitude, Multiattack, Power Attack, Power Climb, Rend, Snatch, Wingover.  
**Epic Feats** Improved Elemental Wild Shape, Negative Energy Burst, Undead Mastery,  
**Skills** Skills Appraise +46, Bluff +45, Concentration +31, Diplomacy +51, Hide -10, Intimidate +49, Jump +57,  
Knowledge (arcana) +49, Knowledge (geography) +35, Knowledge (history) +35, Knowledge (the planes) +49, Knowledge (religion) +37, Search +46, Sense Motive +47, Spellcraft +30, Use Magical Device +8  

----  

**Spellbook** (Sorcerer CL 17; Can also cast cleric spells and those from the Chaos, Evil, and Fire domains as arcane spells. 6/8/8/8/8/7/7/7/5; save DC 18+spell level):  

0th - arcane mark, dancing lights, detect magic, ghost sound, guidance, mage hand, prestidigitation, read magic, resistance  
1st - alarm, chill touch, divine shield, magic missile, shield  
2nd - cat's grace, cure moderate wounds, darkness, detect thoughts, pyrotechnics  
3rd - deeper darkeness, dispel magic, haste, protection from energy  
4th - charm monster, inflict critical wounds, greater invisibility, spell immunity  
5th - mass inflict light wounds, feeblemind, hold monster, permanency  
6th - greater dispel magic, heal, mass suggestion  
7th - insanity, reverse gravity, word of chaos  
8th - horrid wilting, symbol of death  

----  

**Breath Weapon** (Su): 60 ft. cone, 22d10 fire, Reflex DC 39 half.  
**Crush** (Ex): Area 20 ft. by 20 ft.; Medium or smaller opponents take 4d6+22 points of bludgeoning damage, and must succeed on a DC 39 Reflex save or be pinned.  
**Frightful Presence** (Ex): 330 ft. radius, HD 36 or fewer, Will DC 40 negates.  
**Ravage - Bonus feats (abhorrent):** improved elemental wild shape, negative energy burst, undead mastery  
**Ravage - Class feature (common):** Wild shape, as 18th level druid. 6/day animal or plant, size tiny to huge, 2/day elemental creature, size tiny to huge.  
**Ravage - Energised Attacks (common):** All natural attacks do 1d8 negative energy damage.  
**Ravage - Energy Drain (vile):**Her bite drains three levels.  
**Ravage - Mimic Type (undead) (abhorrent):** gains most undead traits, except those derived from null constitution (Immunity to all mind-affecting effects; Immunity to poison, sleep effects, paralysis, stunning, disease, and death effects; Not subject to critical hits, nonlethal damage, ability drain, or energy drain)  
**Ravage - Rebuke Undead (abhorrent):** As 27th level cleric, 11/day  
**Ravage - Spell-like Abilities (common):** At Will - animate dead, enervation, ray of enfeeblement, spectral hand, vampiric touch  
**Ravage - Spell-like Abilities (abhorrent):** At will - _Waves of Fatigue, Create Undead_; 1/day _Wail of the Banshee_  
**Ravage - Spell-like Abilities (abhorrent):** At will Animate objects, Awaken, Call lightning Storm, Scrying  
**Rend** (Ex): Extra damage 4d8+25  
**Snatch** (Ex): Against Medium or smaller creatures, bite for 4d6+17/round, or claw for 2d8+8/round.  
**Tail Sweep** (Ex): Half-circle 30 ft. in diameter, Small or smaller opponents take 2d6+25 points of bludgeoning damage, Reflext DC 39 half.  

* * *

**Appearance:**  

A great red dragon, with eyes like smouldering ashes. Her scales are mottled, the grey of rotting flesh blending with the dull red of dying flames. There are wounds in her side that do not heal, gashes from which putrescent fluids constantly ooze, and in their depths maggots writhe, ever-gnawing at her living flesh. Around her, the air is dim, filled with the chill of the grave and the stench of decay.  

**History:**  

The spawn of a red dragon and a mighty glabrezu, for centuries the ebon flame was the terror of a continent, gathering the wealth of nations into her hoard, but this was not enough to sate her hungers. Her father, a mere demon, had powers she did not, powers that only a dragon like herself, who rivalled the very gods, was fit to wield.  

It was while she was brooding on this cosmic injustice that men came to her and spoke of the power that could be hers as a dracolich, power befitting one as mighty as she. The ebon flame listened to these imperinent creatures for a time, then decided that with her great wisdom she could improve on their designs. Undeath was a fine ambition for lesser races, but she could do better than a half-life. She could link her soul, not to the negative energy plane, but to the abyss itself, and so gain the godlike powers she deserved. All that would be necessary was a small adjustment to the lich-creating ritual. Add a little demon blood, a few dark spells, and the might of the abyss would be hers to command.  

Deep in the abyss she performed the twisted rite, and the abyss responded, its vile energies brushing aside the flimsy magics with which she had sought to control the transformation. Her body writhed as the magic flooded her, power too great for her soul to bear, and great rents opened in her side, wounds that would never heal, and then it was over.  

Great powers she had gained, but not the powers she had sought, the powers she had designed the ritual to yield, for only the demon princes can so constrain the abyss. Instead she who had spurned undeath gained powers resembling the undead lords, and other powers, attributable only to the abyss's infinite caprice, that no true dragon would seek.  

**Nature:**  

Greedy, vain, and a little paranoid, the ebon flame is convinced the only reason her rite failed is because the demon lords sabotaged it, fearful of the power she would gain. She isn't quite arrogant enough to storm their citadels, not yet, but she has plans. One day, she will be the only demon queen, and all the worlds that be shall burn, their wealth gathered into her horde. Come that day, even the gods shall crawl before her, and Tiamat herself will surrender her crown.  

If anyone too weak to pose a threat approaches, the ebon flame will tell them this, at great length, pausing only to let them make flattering replies.  

**Organisation:**  

The ebon flame has used her powers to gather an army of controlled undead, including three mighty liches, though not all her minions are undead. The lesser creatures patrol the lair, the greater she sends out on her errands, and the liches endlessly research powerful spells and enchanted objects that can aid her plans.  

At any one time, she has a few dozen mid-level minions roaming the abyss and beyond, hunting for arcane lore with which to increase her power, information about the demons she believes conspired against her, and treasure. If they find anything sufficiently rewarding but insufficiently defended, the ebon flame will come and take it.  

**Relations to other powers**  

She has no known allies, nor does she want any. Outside the abyss, she is little known; inside, there are several minor demonic powers who want her dead for raiding their realms.  

The only greater power known to be interested in her is Orcus, who thinks her modifications to the lichdom ritual might have potential. She doesn't merit his personal attention, but he has ordered that she be captured and brought before him. He'll learn more from dissecting her if she's still alive at the time.  

***
A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *