# Olhydra, Lord of Water Elementals
Huge Elemental (Extraplanar, Water)  
Hit Dice: 45d8+630 (990 hp)  
**Initiative:** +17  
**Speed:** 40 ft., swim 240 ft.  
**AC:** 59 (+12 deflection, +9 Dex, +11 insight, +19 natural, -2 size), touch 40, flat-footed 39  
**Base Attack/Grapple:** +33/+54  
**Attack:** Slam +45 melee (6d6+13 19-20/x3)  
**Full Attack:** 2 slams +45 melee (6d6+13 19-20/x3)  
**Space/Reach:** 15 ft. /15 ft.  
**Special Attacks:** Call aquatic creatures, engulf, rebuke water creatures, spell-like abilities, supernatural abilities  
**Special Qualities:** Damage reduction 25/-, fire and freeze vulnerability, immunity to acid, cold, petrification and water, Lady of the Waves, regeneration 25, spell resistance 41  
**Saves:** Fort +38, Ref +24, Will +26  
**Abilities:** Str 36, Dex 28, Con 38, Int 29, Wis 33, Cha 34  
**Skills:** Bluff +60, Gather Information +60, Hide +49, Intimidate +66, Knowledge (the planes) +33, Knowledge (religion) +33, Listen +59, Move Silently +57, Sense Motive +59, Spot +59, Survival +59 (+112 planes), Swim +69  
**Feats:** Awesome Blow, Cleave, Combat Reflexes, Great Cleave, Improved Bull Rush, Improved Critical (slam), Improved Initiative, Improved Sunder, Iron Will, Lightning Reflexes, Power Attack, Weapon Focus (slam)  
**Epic Feats:** Epic Reflexes, Epic Will, Overwhelming Critical (slam), Superior Initiative  
**Climate/Terrain:** Elemental Plane of Water  
**Organization:** Solitary (Unique)  
**Challenge Rating:** 32  
**Treasure:** Triple Standard  
**Alignment:** Neutral Evil  

**_Call Aquatic Creatures_ **_(Sp):_ 4/day, Olhydra may call 40HD of creatures with either the Aquatic or Water subtype to aid her.  

**Engulf (Ex):** Olhydra may engulf opponents simply by moving over them. Opponents can make opportunity attacks against her, but if they do so they are not entitled to a saving throw. Those who do not attempt attacks of opportunity must succeed on a DC 45 Reflex save or be engulfed; on a success, they are pushed back or aside (Olhydra’s choice) as the archomental moves forward. Engulfed creatures are subject to 10d10 points of bludgeoning damage per round, and are considered to be grappled and trapped within her body. Engulfed creatures that are one size category or smaller than Olhydra must hold their breath or drown. A successful grapple check against Olhydra on an engulfed creature's turn places the creature in the nearest open adjacent space to the archomental.  

**Rebuke Water Creatures (Su):** Olhydra may rebuke or command creatures with the Water or Aquatic subtype as a 45th level evil cleric rebukes undead. Nonelementals gain their Charisma modifier as "turn resistance" for the purposes of this ability.  

**Spell-like Abilities:** Always active- _detect good, see invisibility_; at will- _control currents, control water, dark tide, depth surge, drown, elemental swarm (water only), endure elements, freedom of movement, greater dispel magic, greater teleport, ice storm, maelstrom, pressure sphere, red tide, spell turning, suggestion, summon nature's ally IX (aquatic creatures only), swim, telekinesis, transmute rock to mud, wall of ice, wall of water, water breathing, waterspout;_ 4/day- _comprehend language, read magic_. Caster level 45th, DC 22+ spell level.  

**Drench (Ex)** Olhydra’s presence puts out torches, campfires, exposed lanterns, and other open flames of nonmagical origin regardless of size. Magical fire (including instantaneous spells cast or targeting within 20 feet of Olhydra) within a 20 foot radius is subject to being dispelled as per _dispel magic_. (1d20+45)  

**Freeze vulnerability (Ex):** While Olhydra is immune to cold damage, any such attack forces her to make a Fortitude save (DC=10+damage the attack would have dealt) or be affected as if by a _slow_ spell for 2d4 rounds.  

**Lady of the Waves**: Olhydra possesses the following traits.  
- Divine Rank 0  
- All slashing, bludgeoning and piercing damage against Olyhydra is halved. (Before damage reduction)  
- Those that successfully strike Olhydra with handheld weapons must make a Reflex save (DC 46) or have their weapon torn from their grasp and flung 1d6 x10 feet in a direction of Olhydra's choosing.  
- Olhydra gains a +10 bonus on attack and damage rolls and the DC of her special attacks if both she and her opponent are touching water. If the opponent or Olhydra is touching the ground, she takes a -4 penalty on attack and damage rolls. (These modifiers are not included in the statistics block.)  

**Regeneration (Ex):** Fire and electricity deal normal damage to Olhydra. Olhydra's rate of regeneration is doubled when she is in contact with a body of water at least twice her size.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *