# Set, Lord of Evil, Brother of Serpents
_Lord of Evil, Defiler of the Dead, Lord of Carrion, Father of Jackals, Outcast of the Gods, King of Malice, Brother of Serpents_  
**Greater Deity**  
**Symbol:** Coiled Cobra  
**Home Plane:** The Black Pyramid, Ankhwugat (Stygia, Fifth of the Nine Hells of Perdition)  
**Alignment:** Lawful Evil  
**Aliases:** Sutekh  
**Superior:** None  
**Allies:** Sebek, Tiamat  
**Foes:** Anhur, Apep, Asmodeus (possibly), Hathor, Horus, Isis, Prince Leviathan, Merodach, Merrshaulk, Nephthys, Orcus, Osiris, Thoth  
**Servants:** Nekrotheptis Skorpios (Proxy, Deceased), Omikrostis (Proxy)  
**Servitor Creatures:** bezekira, flame snakes (lesser, ordinary, and greater), hell hounds, jackal lords, minions of Set, nightmares, risen dead, venomous serpents (all types, particularly fiendish), yuan-ti  
**Manifestations:** rattlesnake rattles, jackal skulls, hissing noises in the wind, tracks of serpents in sand or dust, serpent shadows, appearances of mummies, the Set hieroglyph appearing in sand formations  
**Signs of Favor:** rattlesnake rattles, jackal skulls, the Set hieroglyph appearing in sand formations  
**Worshipers:** Reptilian creatures, assassins, jealous mortals  
**Cleric Alignments:** NE, LE, CE  
**Speciality Priests:** Yes (Nighthunters)  
**Holy Days:** Deconsecrations  
**Portfolio:** treachery, the desert, storms, drought, venomous reptiles  
**Domains:** Air, Darkness, Evil, Hatred, Law, Scalykind, Trickery  
**Favored Weapon:** _Spear of Darkness_, an unholy spear  

Set  
Fighter 17/Rogue 13/Sorcerer 20/Assassin 10  
Medium Outsider (_Lawful, Evil, Extraplanar_)  
Divine Rank: 16  
**Hit Dice:** 17d10 (fighter) plus 13d6 (rogue) plus 10d6 (assassin) plus 20d4 (sorcerer) plus 900 (1291 hp)  
**Initiative:** +22 (+14 Dex, +8 Superior Initiative)  
**Speed:** 60 ft., fly 240 ft. (perfect)  
**Armor Class:** 88 (+31 natural, +14 Dex, +16 divine, +17 deflection), touch 56, flat-footed 88  
**Base Attack/Grapple:** +39/+71  
**Attack: *** +86 _Spear of Darkness_ or bite +71 and 2 claws +66 or melee touch +71 or ranged touch +69  
* always rolls 20  
**Full Attack: *** +86/+86/+81/+76/+71 _Spear of Darkness_ (1d6 plus +3d6 (unholy power) plus 1 negative level (Fort save DC 23 to remove) plus +60/19-20/x3 plus +2d6 (overwhelming critical) plus +9d6 (unholy) plus 3 negative levels (Fort save DC 23 to remove) and Fort save DC 56 or die) or bite +71 (1d4 plus +16 and Fort save DC 53 or die) and 2 claws +66 (1d4 plus +8) or melee touch +71 or ranged touch +69 *  
* _The Spear of Darkness_ always deals 66 normal damage, 18 unholy, and 1 negative level, Set’s bite always does 20 normal damage, and Set’s claws always do 12 points of damage. Check for criticals.  
**Space/Reach:** 5 ft./5 ft.  
**Special Attacks:** crippling strike, death attack (Fort save DC 44 or die), domain powers, salient divine abilities, sneak attack +15d6 (always does 90 points of damage for two rounds), spells, spell-like abilities  
**Special Qualities:** Divine aura (16 miles, DC 38), divine immunities, DR 35/epic and golden and wielded by a mortal that has read _The Book of Smiting Set *_, evasion, godly realm (100 miles outer plane, 1600 ft. Material Plane), _greater teleport_ at will, hide in plain sight, improved evasion, improved uncanny dodge, _plane shift_ at will, remote communication, resistance (cold) 36, speak, and read all languages and speak directly to all beings with 16 miles, SR 78, trapfinding, trap sense +4, uncanny dodge  
**Saves:** Fort +63 Ref +62 Will +54 *always rolls a 20  
**Abilities:** Str 42 Dex 38 Con 40 Int 38 Wis 34 Cha 44  
**Skills:** Balance +61, Bluff +96, Concentration +51, Decipher Script +48, Diplomacy +136, Disguise +85 (+91 observed in character), Escape Artist +56, Gather Information +60, Handle Animal +41, Hide +83, Intimidate +102, Jump +62, Knowledge (arcana) +80, Knowledge (architecture and engineering) +35, Knowledge (geography) +36, Knowledge (nature) +52, Knowledge (nobility and royalty) +45, Knowledge (religion) +60, Knowledge (the planes) +53, Listen +52, Move Silently +73, Search +60 (+62 find secret doors/hidden compartments), Sense Motive +91, Sleight of Hand +62, Spellcraft +97 (+103 spells on scrolls), Spot +65, Survival +38 (+40 aboveground environments, avoid getting lost, extraplanar), Tumble +61, Use Magic Device +63 (+71 scrolls), Use Rope +32 (+36 bindings) * always rolls 20 on skill checks  
**Feats:** Arcane Preparation, Blind Fight, Cleave, Combat Expertise, Corrupt Spell, Dark Speech, Death Blow, Deft Strike, Dodge, Empower Spell, Eschew Material Components, Great Cleave, Greater Weapon Focus (longspear), Greater Weapon Specialization (longspear), Heighten Spell, Improved Critical, Improved Initiative, Mobile Spellcasting, Power Attack, Twin Spell, Two-Handed Mastery, Weapon Focus (spear), Weapon Specialization (spear)  
**Epic Feats:** Devastating Critical (longspear), Epic Reflexes, Epic Spellcasting, Ignore Material Components, Improved Heighten Spell, Intensify Spell, Overwhelming Critical (longspear), Superior Initiative  
**Environment:** The Black Pyramid, Ankhwugat (Stygia, Fifth Hell of Perdition)  
**Organization:** Set and Retinue (4-6 Fully Advanced Greater Flame Snakes), or Set and Courtiers (2 Ancient Dead, 4-6 Minions of Set)  
**Challenge Rating:** 62  
**Treasure:** _Spear of Darkness_  
**Alignment:** Lawful Evil  
**Advancement:** --  
**Level Adjustment:** --  

**Alter Reality (Su):** Set exerts a considerable measure of control over reality itself, and his presence can command the very essence of the world around him. This warping of reality manifested in a number of ways. Set can use _wish_ when doing so could help him to express his loathing and resentment for the rest of his former pantheon, promote his own worship by tearing down his rivals, or promote ordered evil under his scaled fists through betrayal. Note that in the situation where Set and another deity both try to Alter Reality in opposition to each other, an opposed rank check may be necessary to determine how reality is actually altered.  
- Set can use alter reality to cast any _inflict_ spell at will as a standard action; Set can apply metamagic feats to the spells if desired, but doing so requires him to forego using alter reality for 1 round for each level the feat would normally add to the equivalent spell.  
- As a free action, Set can assume any size from Fine to Colossal. Set can also change the size of up to 100 pounds of objects he touches. This ability allows Set to assume any proportions from the size of a grain of sand up to as much as 1,600 feet tall. A radical change in size can have great impact on Set’s combat ability. Set's Strength, Armor Class, attack bonus, and damage dealt with weapons changes according to the size the deity assumes. Set's Strength score can never be reduced to less than 1 through this ability. Also note that use of this divine ability does not affect all of Set's characteristics.  
**- Divine Immunities:** Ability damage, ability drain, _banishment, binding,_ death effects, _dimensional anchor,_ disease, _disintegration, dismissal,_ electricity, energy drain, fire, _imprisonment,_ mind-affecting effects, paralysis, poison, _repulsion,_ sleep, _soul bind,_ stunning, _temporal stasis,_ transmutation, _trap the soul,_ and turning and rebuking.  
**Divine Power:** Set is a living embodiment of power, and ancient divine magics flow through his veins. As such, mortal items are of virtually no use to him, being so much weaker than his own innate powers. Set gains no benefit from a deflection, enhancement, resistance, insight, sacred or profane bonus that is less than +16\. Note that this only applies to bonuses that affect Set himself; weaponry and armor is unaffected by this.  
**Domain Powers:** rebukes earth elementals and commands air elementals 20/day; gains Blind-Fight as a free feat; casts evil and lawful spells at +1 caster level; gains a +2 bonus on attacks, saves and AC v. 1 opponent for 1 minute 16/day; rebukes reptiles 20/day; treats Bluff, Disguise, and Hide as class skills.  
**Salient Divine Abilities:** Alter Form, Automatic Metamagic (Corrupt Spell), Divine Air Mastery, Divine Blast (20/day, 16 miles long, 33d12 points of damage) *, Divine Dodge (66% miss chance), Divine Skill Focus (Diplomacy), Divine Sneak Attack, Divine Spellcasting, Divine Weapon Focus (spear), Divine Weapon Specialization (spear), Eldritch Knowledge, Extra Domain (Evil), Extra Domain (Hatred), Hand of Death (Fort save DC 53 or die, 16d8 points of damage), Increased Damage Reduction, Lay Curse (16/day, Will save DC 53), Lord of Serpents (Unique Salient Divine Ability), Night Magic (Unique Salient Divine Ability), Power of Nature (16 mile radius, up to 16 minutes after concentration ends), Shapechange, Supreme Damage Reduction  
* always does 396 divine damage  
** always does 128 points of damage  
**Spell-like abilities (Sp):** at will: _air walk, animal growth, animal shapes, animal trance, antipathy, bestow curse, black tentacles, blasphemy, chain lightning, confusion, control winds, control weather, create undead, damning darkness, darkvision, darkbolt, deeper darkness, desecrate, disguise self, disjunction, dispel good, doom, elemental swarm_ (air only), _eyebite, false vision, forbiddance, gaseous form, greater magic fang, invisibility, magic circle against good, magic fang, mislead, nondetection, obscuring mist, poison, polymorph any object, protection from good, righteous might, screen, scare, screen, shadow walk, shapechange, song of discord, summon monster IX_ (lawful and evil spell only), _time stop, unholy blight, unholy aura, utterdark, vipergout, wail of the banshee, wall of force, whirlwind, wind wall._ Cast at 76th level, except for lawful and evil spells which are cast at 77th level. The save DC’s are 53 + spell level and are Charisma-based.  
**Possessions:** _Spear of Darkness_  

**Assassin Spells (Sp) (1st-4th level) 7/7/6/6:** Set casts his Assassin spells at 13th level and at 29th level for the purposes of spell penetration.  

**Assassin Spells Known:** 1st level: _critical strike, sniper’s shot, stupor, true strike._ 2nd level: _illusory script, pass without trace, undetectable alignment, wraithstrike._ 3rd level: _deep slumber, false life, misdirection, nondetection._ 4th level: _cursed blade, dimension door, greater invisibility, sniper’s eye._  

**Lord of Serpents (Unique Salient Divine Ability):** Besides Merrshaulk, Set is one of the beings that has the most sway among reptiles of all sorts, magical and mundane. This influence belonged to Set before he defeated Apep as Sutekh, and extends to the present despite his exile from the Ennead and descent to Perdition as the Outcast of the Gods. Set’s powers not only allow him to command reptiles, but also extend to his taking on some of their traits in the following manners:  

_Distendible Jaw:_ As a full round action, Set may both unhinge and elongate his jaws massively, enabling him to swallow whole any creature of that is of the same size category as himself or one size larger (although if Set opts for the latter choice, he must take 1 full round for 4 HD of the creature that he is devouring). A being that is completely swallowed by Set in this manner is unrecoverable by mortal magic, and even using means such as forbidden magic or salient divine abilities, beings must succeed on a rank check in order to try and resurrect a being devoured by the Defiler of the Dead. Set will often execute servitors that have failed him previously by devouring them slowly in order to demonstrate to the survivors the consequences of potential incompetence.  

_Reptilian:_ Set may bite and claw his opponents in his most natural form. When he chooses to do so, his bite is considered to be a primary attack, and his claws are considered to be a secondary attack.  

_Serpent’s Eyes:_ Beings that meet Set’s eyes, which are amber in what is believed to be his true form, find themselves transfixed by them and must make a Will save DC 53 or else be unable to move unless Set commands them to do so. Furthermore, a being that is transfixed by Set’s gaze additionally takes a –8 penalty to all saving throws and skill checks that are intended to help them discern Set’s malign intentions or resist his enchantments. The effects of the Serpent’s Eyes are only reversible through the casting of _break enchantment, miracle,_ or _wish_ by a 31st level or higher caster.  

_Venomous:_ Set’s canines are hollow, and connect to a set of venom glands contained within his jaws. As a result, the bite of Set is utterly lethal, and anyone bitten by Set must make a Fort save DC 53 or else die instantly as a result. Set may also choose to cause his hands and scales to secrete an extremely potent venom as well, dealing 2d8 points of Con damage to any being that is injured by his claws or attempts to grapple him. Set’s venoms may affect divine beings as well upon a successful rank check.  

Furthermore, Set may choose to spit his venom at his opponents as a standard action. He may either choose to release it as a concentrated stream, hitting opponents up to 60 feet away with it, or he may instead spray it in a cone, hitting everything that is 20 feet in front of him. Set’s venom does not linger if it does not hit a living being and becomes nontoxic within 1 round after landing on an inert surface. While Set may bite his victims at any time in order to inject venom, he must wait 1d4 rounds between either spraying venom or spitting it.  

**Night Magic (Unique Salient Divine Ability):** The power of Set is at it’s greatest in darkness, and it is through darkness that Set as Sutekh defeated his first, great opponent, Apep. Although Set’s jealousy has twisted his own power into the service of boundless ambition, jealousy, and evil, he still retains some of this power in the following ways:  

First, all spells-like abilities that Set uses that create or manipulate darkness are Quickened as long as he casts them during the night.  

Set additionally receives a +8 profane bonus the saving throws of his Illusionary and Necromantic spells if he is casting them at night. Night, for the purposes of receiving these benefits, refers to a period of darkness that is at least 8 hours long, or is produced through his own divine control over the length of the day and night.  

**Sorcerer Spells (Sp) (0th-17th level) 6/11/10/10/10/10/9/9/9/9/5/5/5/5/4/4/4/4** Set casts his Sorcerer spells at 20th level and at 36th level for the purposes of spell penetration. Saving throws against Set’s Sorcerer spells are DC 27 + spell level (45 + spell level while casting at night), and all of Set’s spells are Corrupted. Set may cast 6 epic spells/day with a maximal Spellcraft DC of 117\. The saving throw DC’s are Charisma-based.  

**Sorcerer Spells Known:** 0th level: _arcane mark, detect poison, ghost sound, mage hand, message, prestidigitation, preserve organ, read magic, slash tongue._ 1st level: _alarm, animate rope, backbiter, charm person, detect secret doors, identify, expeditious retreat, ray of enfeeblement, silent image, stupor, unseen servant, ventriloquism._ 2nd level: _addiction, blindness/deafness, detect thoughts, entice gift, gust of wind, knock, phantasmal assailants, spectral hand, wall of gloom, whispering wind, wither limb._ 3rd level: _dread word, evil eye, haste, hold person, illusory script, lightning bolt, protection from energy, stony grasp, tongue serpents, vampiric touch._ 4th level: _bestow curse, blast of sand, detect scrying, enervation, illusory wall, orb of electricity, psychic poison, stone shape, wall of sand, wither._ 5th level: _baleful polymorph, choking sand, cloudkill, flaywind burst, mirage arcana, persistent image, telekinesis, transmute stone to sand, wall of stone, waves of fatigue._ 6th level: _ashen union, chain lightning, desiccate_ (mass), _dispel magic_ (greater), _false sending, mislead, programmed image, undeath to death._ 7th level: _banishment, control undead, grasping hand, invisibility_ (mass), _phase door, reverse gravity, scrying_ (greater), _sequester._ 8th level: _bestow greater curse, demand, discern location, horrid wilting, maze, moment of prescience, phantasmal thief, shadow evocation_ (greater). 9th level: _dominate monster, energy drain, hold monster_ (mass), _imprisonment, programmed amnesia, reaving dispel, shades, superior invisibility._ epic spells known: _bile of the betrayer, dissatisfaction, eclipse, epic dimension door, epic dispel magic, forked tongue, greater ruin, minion of set, momento mori, mummy dust, nailed to the sky, ritual mummification, Set’s constrictor, soul scry, true name of the serpent._  

**Other Divine Powers:**  
- As an greater deity Set recieves the best result on any check. Set treats a 1 on an attack roll or saving throw normally and not as an automatic failure. He is immortal.  
**- Senses:** Set can see (using normal vision or darkvision), hear, touch, and smell at a distance of 16 miles. As a standard action, he can perceive anything within 16 miles of his worshippers, holy sites, objects, or any location where one of his titles or name was spoken in the last hour. He can extend his senses to up to ten locations at once. He can block the sensing power of deities of his rank or lower at up to two remote locations at once for 16 hours.  
**- Portfolio Sense:** Set is aware of any event involving concerning betrayal, serpents, the desert, or the creation of darkness up to 16 weeks in the past and 16 weeks in the future.  
**- Automatic Actions:** Set can use any skill that aids him in betraying others for power, serpents, creating or studying darkness, or helping to spread the desert such as Diplomacy, Knowledge (nature), or Sense Motive as a swift action if the DC for the task is 30 or lower. To use a skill as a free action, Set must have ranks in the skill, or the skill must be usable untrained. He can perform up to 20 such free actions each round.  
**- Create Magic Items:** Set can create any magical item that incites betrayal, relates to serpents or is used by reptilian races, spreads darkness, or concerns the desert, including artifacts.  

_Possessions:_ Set wields the _Spear of Darkness_, a _+9 returning Large longspear of distance, speed,_ and _unholy power._ The _Spear of Darkness_ carries two separate curses, either of which Set may employ up to four times a day:  

_The Curse of the Desert:_ Any being struck by the _Spear of Darkness_ must make a Fort save DC 53 or else die instantly and be transformed into a pillar of sand.  

_The Curse of Set’s Favor:_ This Curse Set uses when Set desires to acquire the service of another being, constricting them in the bonds of their obligation to him. The victim of _The Curse of Set’s Favor_ must make a Will save DC 53 or else find themselves obligated to perform a single favor of Set’s choosing as stated by Set.  

**Avatars:**  
The Avatar of Set appears as a creature so distinct that scholars have had no recourse other than to name it as a unique exemplar: _The Set Beast_. Nearly seven feet tall, it is covered in dark brown and closely joined scales. His head possesses a almost-canine snout/muzzle, tall ears similar to those of an ass or donkey, and a red, serpentine forked tongue that flickers in and out of his muzzle whenever he is not speaking, and he looks at the world with unblinking, amber eyes with the iris of a serpent. Despite his great differences from most mortals in his true form, Set speaks with a perfect voice, as convincing as it is filled with unbridled ambition and cold calculation as to how he can better promote him own rule at the expense of all others.  

The other form that Avatars of Set typically take is a semblance of the form in which he was still part of the Ennead. In such circumstances, Set appears as a red-haired youth with dark skin and amber eyes at the peak of both physical strength and mental health, with a smooth, convincing manner and whose only indications of real difference from a mortal are that he tends to draw his s’s out slightly, and always smiles in a tight-lipped manner in order to conceal the hollow, venomous fangs lurking within his mouth as a reflection of the treachery lurking within his soul.  

Set’s Avatar  
Medium Outsider (_Evil, Extraplanar, Lawful_)  
Divine Rank: 0  
**Hit Dice:** 10d10 (fighter) plus 6d6 (rogue) plus 6d6 (assassin) plus 8d4 (sorcerer) plus 330 (566 hp)  
**Initiative:** +15 (+11 Dex, +4 Improved Initiative)  
**Speed:** 60 ft. (12 squares)  
**Armor Class:** 50 (+15 natural, +11 Dex, +14 deflection), touch 35, flat-footed 50  
**Base Attack/Grapple:** +22/+35  
**Attack:** +42 melee _+2 shocking burst, unholy longspear_ or bite +35 melee or 2 claws +30 melee or +35 melee touch or +33 ranged touch  
**Full Attack:** +42/+37/+32 melee _+2 shocking burst, unholy longspear_ (1d6 plus +1d6 (electricity) plus +17/19-20/x3 plus 2d10 (electricity) and Fort save DC 38 or die) or bite +35 melee (1d4 plus +13 and Fort save DC 34 or die) or 2 claws +30 melee (1d4 plus +6) or +35 melee touch or +33 ranged touch  
**Space/Reach:** 5 ft./5 ft.  
**Special Attacks:** death attack (Fort save DC 27 or die), domain powers, salient divine abilities, sneak attack, spells, spell-like abilities  
**Special Qualities:** divine aura (1600 feet, DC 24), divine immunities, DR 10/epic, evasion, _greater teleport_ at will, _plane shift_ at will, resistance (electricity) 20, sneak attack +6d6, SR 46, trapfinding, trap sense +2, uncanny dodge  
**Saves:** Fort +26 Ref +20 Will +16  
**Abilities:** Str 36 Dex 32 Con 32 Int 32 Wis 28 Cha 38  
**Skills:** Balance +24, Bluff +47, Concentration +21, Decipher Script +20, Diplomacy +57, Disguise +41 (+45 observed in character), Escape Artist +25, Gather Information +25, Handle Animal +17, Hide +22, Intimidate +43, Jump +20, Knowledge (arcana) +28, Knowledge (architecture and engineering) +13, Knowledge (geography) +14, Knowledge (nature) +20, Knowledge (nobility and royalty) +20, Knowledge (religion) +15, Knowledge (the planes) +22, Listen +18, Move Silently +27, Search +26, Sense Motive +35, Sleight of Hand +23, Spellcraft +43 (+45 scrolls), Spot +25, Survival +14 (+16 aboveground environments, extraplanar), Tumble +23, Use Magic Device +25 (+31 scrolls), Use Rope +13 (+15 bindings)  
**Feats:** Arcane Preparation, Blind Fight, Cleave, Corrupt Spell, Dark Speech, Deft Strike, Eschew Material Components, Great Cleave, Improved Critical (longspear), Improved Initiative, Power Attack, Weapon Focus (longspear), Weapon Specialization (longspear)  
**Epic Feats:** Devastating Critical (longspear), Epic Reflexes, Overwhelming Critical (longspear)  
**Environment:** The Mortal Coil  
**Organization:** Solitary (unique)  
**Challenge Rating:** 30  
**Treasure:** _+2 shocking burst, unholy longspear_  
**Alignment:** Lawful Evil  
**Advancement:** --  
**Level Adjustment:** –  

**- Divine Immunities:** Ability damage, ability drain, mind-affecting effects.  
**- Domain Powers:** rebukes earth elementals and commands air elementals 20/day; gains Blind-Fight as a free feat; casts evil and lawful spells at +1 caster level; gains a +2 bonus on attacks, saves and AC v. 1 opponent for 1 minute 1/day; can use magic items as a wizard of 30th level; rebukes reptiles 20/day.  
**- Salient Divine Abilities:** Divine Weapon Focus (longspear), Extra Domain (Evil), Extra Domain (Hatred), Hand of Death (Fort save DC 34 or die), Lord of Serpents  
**- Spell-Like Abilities:** 3/day: _air walk, animal growth, animal shapes, animal trance, antipathy, bestow curse, black tentacles, blasphemy, chain lightning, confusion, control winds, control weather, create undead, damning darkness, darkvision, darkbolt, deeper darkness, desecrate, disguise self, disjunction, dispel good, doom, elemental swarm_ (air only), _eyebite, false vision, forbiddance, gaseous form, greater magic fang, invisibility, magic circle against good, magic fang, mislead, nondetection, obscuring mist, poison, polymorph any object, protection from good, righteous might, screen, scare, screen, shadow walk, shapechange, song of discord, summon monster IX_ (lawful and evil spell only), _time stop, unholy blight, unholy aura, utterdark, vipergout, wail of the banshee, wall of force, whirlwind, wind wall._ Cast at 30th level, except for evil spells which are cast at 31th level. The save DC’s are 24 + spell level and are Charisma-based.  

**Assassin Spells (Sp) (1st-3th level) 6/5/3:** Set’s Avatar casts his Assassin spells at 6th level. Saving throws against Set’s Assassin spells are DC 21 + spell level.  

**Assassin Spells Known:** 1st level: _critical strike, sniper’s shot, stupor, true strike._ 2nd level: _illusory script, pass without trace, undetectable alignment, wraithstrike._ 3rd level: _deep slumber, misdirection, nondetection._  

**Sorcerer Spells (Sp) (0th-4th level) 6/10/10/8/6** Set’s Avatar casts his Sorcerer spells at 8th level. Saving throws against Set’s Avatar’s Sorcerer spells are DC 24 + spell level. The saving throw DC’s are Charisma-based.  

**Sorcerer Spells Known:** 0th level: _arcane mark, detect poison, ghost sound, mage hand, message, prestidigitation, preserve organ, read magic, slash tongue._ 1st level: _detect secret doors, expeditious retreat, magic aura, silent image, ventriloquism._ 2nd level: _addiction, phantasmal assailants, wall of gloom._ 3rd level: _lightning bolt, tongue serpents._ 4th level: _blast of sand._  

* _The Book of Smiting Set_  

_The Book of Smiting Set_ is an extremely powerful tome of artifact-level magic kept in Thebestys in the Concordant Domain of the Outlands. It was created by Thoth and Isis themselves after the fateful battle in which Set was exiled from the Ennead, forcing him to reach the agreement with Lucifer which resulted in his current status within Ankhwugat in the Perditions. _The Book of Smiting Set_ is a chronicling of Set’s loathesome deeds and methods, intended to fortify it’s reader with the knowledge necessary to fight Set himself.  

Reading _The Book of Smiting Set_ requires it’s current possessor to begin reading it at sunrise and complete reading it at sunset for six successive days while taking no other actions except for eating, drinking, and learning of Set’s horrible deeds and how to combat them from it’s pages. If a single day is missed in the process, then they may start again only once and should they fail again, then the Book becomes permanently illegible to that particular individual.  

Upon the completed reading, it’s beneficiary acquires the following abilities:  

• A +7 sacred bonus to all saving throws against attacks by Set or his servitors (for these purposes, a servitor of Set is any creature that either receives spells by praying to Set, proxies, or beings that have either been manipulated by Set or summoned by The Lord of Evil.  
• The ability to penetrate Set’s damage reduction.  
• The ability to prepare a single personal weapon using an invocation from _The Book of Smiting Set_ that is treated as a dread weapon against all servitors of The Lord of Evil, giving it’s wielder a +4 bonus to their attack rolls against them, inflicting an additional +4d6 points of damage with each successful hit, and upon a critical hit, force their opponents to make a Fort save DC 23 or else die.  

However, reading _The Book of Smiting Set_ carries a steep obligation. Each time a being that has read _The Book of Smiting Set_ confronts a being that they know serves Set, they must make a Will save DC 47 or else enter into combat with them immediately with whatever weapons they have available. Successfully resisting the suggestion causes the reader to be punished as described in the spell _geas_, requiring a quest from a cleric of either Thoth or Isis to lift the relevant penalties.  

Finally, _The Book of Smiting Set_ will not suffer the touch of any being that defies Ma’at, or Balance. As a result, any being that is evil in alignment that touches the _Book of Smiting Set_ takes 3 negative levels (Fort save DC 47 to remove).  

Bile of the Betrayer  
**Necromancy**  
Spellcraft DC: 116  
**Components:** V, S  
**Casting Time:** 1 action  
**Range:** 10 ft. by 150 ft. bolt  
**Duration:** 20 minutes/permanent  
**Saving Throw:** Fort  
**Spell Resistance:** Yes  
**To Develop:** 1,044,000 gp; 21 days; 41,760 XP. **Seeds:** _afflict_ (DC 23) _drain_ (DC 19) **Factors:** lose both senses of sight and touch (+4 DC) 1-action casting (+20 DC), additional 16 points of Dex drain (+64 DC), change from target to area (+10 DC), change area to 10 ft. x 150 ft. bolt (+2 DC), add +12 to save DC (+24 DC). **Mitigating Factors:** 30d6 points of backlash damage (-30 DC), burn 3,000 XP (-30 DC).  

Using this epic spell, Set calls forth a form of venom so potent that doing so even harms him: the _bile of the betrayer_. Spraying it from his fanged jaws, every being in the path of the venom must make a Fort save DC 32 + spellcasting modifier or else go completely numb and be blinded for the next 20 minutes. Far worse, however, is the damage that the _bile of the betrayer_ does to the bodies of it’s victims as it also dissolves their muscles and nerves inflicting 20 points of Dexterity drain upon them.  

Dissatisfaction  
**Enchantment [Evil]**  
Spellcraft DC: 116  
**Components:** V, S, Dark Speech  
**Casting Time:** 1 minute  
**Range:** 75 ft.  
**Duration:** 10 hours  
**Saving Throw:** Will negates  
**Spell Resistance:** Yes  
**To Develop:** 1,044,000 gp; 21 days; 41,760 XP. **Seeds:** _compel_ (DC 19) _conceal_ (DC 17) **Factors:** increase duration by 200% (+4 DC), increase saving throw DC by +25 (+50 DC), unreasonable course of action (+10 DC), cast 10 levels higher (+20 DC). **Mitigating factors:** Dark Speech (-4 DC).  

As Set’s own capabilities for understanding anything other than betrayal, ambition, and resentment overwhelmed all other aspects of his personality, he acquired the ability to bring out those same horrible traits in other beings. Through the Dark Speech, Set may speak to another individual of the dissatisfaction and anger that they feel throughout their existence, motivating them to undertake a course of action that will bring them greater power through acts of treachery and betrayal for the duration of this epic spell. The saving throw against this spell is DC 45 + spellcasting modifier, and this spell is additionally cloaked against detection to the point where it is treated as 10 levels higher for the purposes of even determining whether a being is under it’s effects or not.  

Forked Tongue  
**Transmutation Conjuration [Teleportation]**  
Spellcraft DC: 121  
**Components:** V, S  
**Casting Time:** 6 minutes  
**Range:** 75 ft.  
**Duration:** 20 hours  
**Saving Throw:** Will  
**Spell Resistance:** Yes  
**To Develop:** 1,044,000 gp; 21 days; 41,760 XP. **Seeds:** _fortify_ (DC 23), _transport_ (DC 27) **Factors:** grant +8 profane bonus to Charisma (+48 DC), contingency (+25 DC), interplanar transport (+4 DC), transport unwilling creature (+4 DC). **Mitigating Factors:** 5 minute casting (-10 DC), 6d6 hp backlash (-6 DC).  

Set is one of the most deceitful deities in existence, and he grants no boon that does not serve his greater purpose at the expense of his alleged beneficiary. This is epitomized through the epic spell _forked tongue_. Upon the completed casting of the _forked tongue_, Set grants a being a +8 profane bonus to their Charisma for the next 20 hours. At the end of this period, however, the beneficiary of this epic spell is teleported directly to a location of Set’s designation at the beginning of the spell. While a Will save is allowed in order to avoid the teleportation aspect of the spell, typically Set acquires their agreement before casting the spell upon them, causing them to be treated as a willing being for the purposes of the planeshifting and so allowing them no saving throw at all.  

Minion of Set  
**Transmutation**  
Spellcraft DC: 115  
**Components:** V, S  
**Casting Time:** 1 action  
**Range:** Touch  
**Duration:** Permanent  
**Saving Throw:** Fort  
**Spell Resistance:** Yes  
**To Develop:** 1,035,000 gp; 21 days; 41,400 XP. **Seed:** _transform_ (DC 23) **Factors:** specific individual (minion of Set) (+25 DC), add fear immunity (+ 10 DC), add alternate form (+10 DC), spell resistance (+10 DC), transform into outsider (+5 DC), change from target to touch (+4 DC), add +15 to saving throw DC (+30 DC), 1-action casting (+20 DC). **Mitigating Factors:** 8d6 hp backlash (-8 DC), burn 1,400 XP (-14 DC).  

Through this epic spell, Set transforms a mortal into one of his most valued servitors; a Minion of Set. The Minion of Set created in this manner possesses all of the normal qualities of it’s kind, and the being to be transformed must make a Fort saving throw DC 35 + spellcasting modifier in order to resist the effects of Set’s spell.  

Ritual Mummification  
**Necromancy**  
Spellcraft DC: 116  
**Components:** V, S, M  
**Casting Time:** 11 minutes  
**Range:** 75 ft.  
**Duration:** Permanent  
**Saving Throw:** Will  
**Spell Resistance:** Yes  
**To Develop:** 1,044,000 gp; 21 days; 41,760 XP. **Seeds:** _slay_ (DC 19) _animate dead_ (DC 23) **Factors:** up to 50 HD creature (+30 DC), control 50 HD undead (+45 DC), increase saving throw by +15 (+30 DC) **Mitigating factors:** increase casting time by 10 minutes (-20 DC), unique material components (-7 DC), Dark Speech (-4 DC)  

Besides Orcus, Set has some of the most powerful of the Risen Dead serving him that are known to exist throughout the Realms Beyond. Set is responsible for their creation through the use of this epic spell; the _ritual of mummification._ In order to cast this epic spell, Set opens a jar of specially prepared mummifying salts and pours them over his potential victim even while using the Dark Speech to describe their undying servitude to him as their future master. At the end of the casting, the victim must make a Fort save DC 35 + spellcasting modifier or else die, their flesh desiccating and withering away as negative energy transforms them into a Risen Dead bound to serve Set loyally until he destroys them, or until he reaches his limit of controlled undead, and releases them from servitude. Set may mummify a creature with up to 50 HD with this epic spell.  

Set’s Constrictor  
**Necromancy Evil**
Spellcraft DC: 113  
**Components:** V, S  
**Casting Time:** 1 minute  
**Range:** 75 ft.  
**Duration:** 10 hours  
**Saving Throw:** Fort negates  
**Spell Resistance:** Yes  
**To Develop:** 1,017,000 gp; 21 days; 41,680 XP. **Seeds:** _heal_ (DC 19) _drain_ (DC 23) _drain_ (DC 23) **Factors:** add additional 6 points of Str drain, (+24 DC), add additional 6 points of Dex drain (+24 DC).  

Set calls upon the air itself to crush his victim, swirling and turning into a serpentine mass that wraps around them, tightening until it cracks every bone in their body and does an incredible amount of damage to them. The victims of _Set’s constrictor_ lose all but 1d4 of their hit points as a result, and furthermore take an additional 10 points of Strength and Dexterity drain apiece due to the damage to their entire body as a result of the casting of this horrific spell.  

True Name of the Serpent  
**Transmutation**  
Spellcraft DC: 55  
**Components:** V, S, M  
**Casting Time:** 1 minute  
**Range:** Touch  
**Duration:** Permanent  
**Saving Throw:** Fort  
**Spell Resistance:** Yes  
**To Develop:** 495,000 gp; 10 days; 19,800 XP. **Seed:** _transform_ (DC 21). **Factors:** add poison immunity (+10 DC), add bite attack (+10 DC), add poison to bite attack (+10 DC), change from targe to touch (+4 DC).  

As the Brother of Serpents, Set may call upon the _true name of the serpent_ in order to transform one of his worshippers into a form more resembling his own and the creatures which he has claimed rulership over. When Set does so, he grants a being immunity to all forms of poison, while simoultaneously causing the target to grow venom glands even while their canines elongate and develop a hollow channel, allowing them to bite and inject venom into targets that does 1d6 points of both primary and secondary Con damage.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *