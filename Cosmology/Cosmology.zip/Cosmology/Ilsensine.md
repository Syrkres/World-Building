# Ilsensine, Cosmic Entity of Illithids
Patron Cosmic Entity of Illithids  
**Symbol:** An illithid head with tentacles draped over a sphere representing a world  
**Home Plane:** Unknown (currently the Caverns of Thought/Outlands)  
**Alignment:** Lawful Evil  
**Portfolio:** Psionics, Mental Power, Domination  
**Worshippers:** Illithids  
**Cleric Alignment:** Lawful Evil  
**Domains:** Law, Evil, Mind  
**Favored Weapon:** Psionic Powers  

ILSENSINE  
Huge Outsider (Lawful, Evil, Extraplanar, Psionic)  
Virtual Divine Rank: 18  
**Hit Dice:** 65d8 (outsider) +38 (psionic body) +910 (1468 hp)  
**Initiative:** +12 (+4 Dex, +8 Superior Initiative)  
**Speed:** swim 90 ft., levitate 90 ft.  
**AC:** 72 (+25 natural +4 Dex +18 cosmic +15 deflection), touch 47, flat-footed 68  
**Face/Reach:** 15 ft. by 15 ft./10 ft.  
**Base Attack/Grapple:** +65/+76 or +69 ranged  
**Attacks:** Tentacle +65 melee (2d6+1); or psionic ray +70 ranged (damage varies)  
**Full Attack:** 4 tentacles +65 melee (2d6+1) or 4 psionic rays +70 ranged (damage varies)  
**Special Attacks:** Call The Transformed, Ceremorphosis, Extract Mind, Mind Blast, Psionic Mastery  
**Special Qualities:** Blindsight, Cosmic Divinity (vDR 18), Cosmic Presence, DR 30/epic and silver, DR 20/good, immunities (electricity, acid), Patron Qualities, regeneration 14/silver and good, fire and cold resistance 20, SR 62  
**Saves:** Fort +48, Ref +39, Will +49  
**Abilities:** Str 12, Dex 18, Con 38, Int 58, Wis 38, Cha 40  
**Skills:** Appraise +56, Autohypnosis +68, Bluff +83, Concentration +82, Diplomacy +83, Gather Information +83, Intimidate +83, Knowledge (architecture and engineering) +82, Knowledge (arcana) +92, Knowledge (dungeoneering) +92, Knowledge (geography) +92, Knowledge (local-Outlands) +92, Knowledge (the planes) +92, Knowledge (psionics) +102, Psicraft +110, Search +56 (+62 to find secret doors/hidden compartments), Sense Motive +82, Spellcraft +56, Spot +38, Survival +46 (+54 to avoid getting lost/natural hazards, +58 to survive on other planes, +58 while underground), Use Magic Device +47, Use Psionic Device +83  
**Feats:** Chain Power, Empower Power (/cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, Enlarge Power, Extend Power, Greater Power Penetration, Improved Initiative, Opportunity Power, Power Penetration, Power Specialization (ray), Psionic Body, Psionic Meditation, Quicken Power, Twin Power, Weapon Focus (ray)  
**Epic Feats:** Epic Psionic Focus(x3), Epic Manifesting (/cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, Epic Skill Focus (Knowledge-psionics), Epic Skill Focus (Psicraft), Improved Metapsionics(x3), Superior Initiative  
**Climate/Terrain:** The Caverns of Thought (Outlands)  
**Organization:** Unique (Solitary)  
**Challenge Rating:** 47  
**Treasure:** Nutrient Pool  
**Alignment:** Lawful Evil  
**Advancement:** N/A  

Ilsensine is a spherical, pink brain ten feet wide with four constantly waving, 10-foot long tentacles that glow with a bright, yet sickeningly green light that is but a pale reflection of the psionic power that flows through them. Typically Ilsensine lies submerged in it’s nutrient pool, a dark blue mass of viscous liquid which allows it to withdraw power points as if it was a power crystal.  

Spell-like abilities: At will-_astral projection, blasphemy, brain spider, calm emotions, charm monster, comprehend languages, create undead, desecrate, detect thoughts, dictum, discern lies, dispel chaos, dispel good, hold monster, levitate, telepathic bond_ (lesser), _telepathic bond, magic circle against chaos, magic circle against good, order’s wrath, plane shift, probe thoughts, protection from good, protection from chaos, suggestion, unholy blight._ 6/day-_mind blank, shield of law, summon monster IX_ (lawful and evil creatures only), _unholy aura, weird_. Cast at 65th level. Saving throws are 23+the level of the spell. Ilsensine casts both Lawful and Evil spells at +1 caster level, gains a +2 bonus on Bluff, Diplomacy, and Sense Motive checks, and also gains a +2 bonus on Will saves against enchantment spells and effects.  

**Blindsight (Ex):** Although Ilsensine possesses no eyes, it is capable of detecting living creatures that possess a nervous system through the electrical impulses that they generate. As such, Ilsensine may be considered to have blindsight in a radius of 1800 ft. around it.  

**Mind Blast (Ex):** This attack is a cone 100 feet long. Anyone caught in the cone must succeed at a Will save (DC 41) or be stunned for 21d4 rounds.  

**Call The Transformed (Sp):** Ilsensine may call a total of 180 HD worth of Illithids or Illithid-related creatures (such as Neothelids or Ulitharids) in a single day, but no creature that it calls may have a higher CR than 35.  

**Cosmic Divinity (Ex):** Although the illithids are not what most would consider to be ‘religious’, there are among the spellcasting members of their species those that have been selected by Ilsensine to serve a special purpose based on their superlative competence and intellects. To those individuals selected, they may be granted spells from the domains of Mind, Evil, and Law.  

Ilsensine possesses a virtual divine rank of 18 as defined in the “Virtual Divine Ranks and Cosmic Entities Defined” article regardless of location. It’s cosmic realm is known as Caverns of Thought in the Outlands, a sprawling labyrinth of caves made of brain tissue where it has lurked since the successful Gith revolution against it’s tyranny.  

**Cosmic Presence (Ex):** The physical presence of Ilsensine is so powerful and awe-inspiring that it causes lesser creatures to succumb to its magnificence. All creatures within 1000 feet of Ilsensine must succeed in a Will save 55\. Failure indicates the creature succumbs to an emotion of Ilsensine’s choosing. Ilsensine normally chooses to make those creatures that wander or are attracted to the Caverns of Thought so awestruck by it’s presence as to ease interrogation, or alternately, it will induce unreasoning terror in creatures which approach it’s caverns in beings that it does not wish to deal with in order to keep them away from it’s demensne.  

**Patron Qualities (Ex):** Ilsensine is immune to acid and electricity and possesses fire and cold resistance 20\. It has DR 30/epic and silver and regeneration 14/silver and good. Ilsensine is immune to mind-affecting effects, polymorphing, petrification, or any other attack that alters its form. It is not subject to energy drain, ability drain, or ability damage. Ilsensine does not age, does not need to eat, sleep or breathe, is immortal, and cannot die from natural causes.  

Additionally, Ilsensine may sense anything within one mile around the mention of it’s name, titles, or an item of importance to it for up to one hour after the event. This power is barred from places associated with beings with divine ranks or virtual divine ranks of higher than it.  

**Patron Omniscience:** Ilsensine may sense any event that affects any of it’s children 18 weeks in the past and 18 weeks in the future. When Ilsensine senses an event, it merely knows that the event is occuring and where it is. It recieves no sensory information about the event.  

**Ceremorphosis (Ex):** As a full round action with two of it’s tentacles, Ilsensine may implant pieces of itself in any living creature that has an intelligence score. It accomplishes this by taking two of it’s tentacles, inserting them into the auditory canals (or suitable orifices) of a living creature, and then transforming it’s brain tissue. They must make a Will save DC 61 or over the course of the next 18 rounds, Ilsensine will telepathically command the mutated brain that it has inserted into it’s target to literally redesign their body into what Ilsensine considers to be absolute perfection.  

Humans transformed through this process will become Illithids utterly convinced of Ilsensine’s superiority to all other life, losing any class and alignment abilities that are incompatible with Ilsensine’s powers and alignment and adopting the subtypes Psionic, Lawful, and Evil instead. Any other creature transformed will take on the Half-Illithid template but will still have their alignment automatically change to both Lawful and Evil if it was not such previously.  

The changes that Ilsensine inflicts upon other beings are exceptionally difficult to reverse, requiring the aid of a deity possessing the Mass Life and Death Salient Divine Ability and an equivalent or greater divine or virtual divine rank than Ilsensine.  

Ilsensine’s ability to engage in Ceremorphosis, however, is extremely limited and it may only do this 13/year although there are persistent rumors that in Ilsensine’s ‘youth’ as a power, it was able to convert far more individuals then that it is now. Usually such transformation is the culmination of a labyrinthine sequence of plans in order to help restore itself to it’s former position of glory in the Planes; the contingencies of which are so convoluted as to almost defy description.  

**Extract Mind (Ex):** If Ilsensine begins a turn with two of its four tentacles attached and successfully maintains it’s hold, then it’s target must make a Will save DC 55\. Should the target lack divine rank and they fail the save, then their mind and soul have been extracted from their bodies by Ilsensine’s psionic mastery leaving them a soulless, drooling husk. Ilsensine gains 1d10 temporary power and hit points for each HD of it’s target that it consumes and absorbs the sum total of all of their memories into it’s eldritch mass permanently. The victim loses 1d4 Con per round until they are dead. Temporary hit and power points gained in this manner are lost at the end of an hour.  

Ilsensine may instead opt to use such an individual emptied by placing a selection of memories and sufficient knowledge into it’s body to allow it to continue living, but enthralled to Ilsensine. Whether it chooses to do this or not is largely dependent on it’s needs at the time.  

Creatures drained in this manner may only be restored to life through the use of the Mass Life and Death Salient Divine Ability by a deity of equivalent or greater Divine or Virtual Divine Rank than Ilsensine, and even then, there is only a 50% chance that memories stolen by Ilsensine can be returned to a victim.  

Because of the extreme length of time that Ilsensine has been absorbing memories from other sentient beings, Ilsensine has also become one of the most knowledgeable beings in the Planes, and recieves a +18 competence bonus to all knowledge checks. This is included in the statistics above.  

**Psionic Mastery (Ex):** Ilsensine is the most powerful psion in the Planes and few beings even marginally approach it’s mental prowess. This has provided him with myriad benefits:  

Perfection of Powers: Ilsensine may manifest any psionic power it wishes from any school and manifests all powers at 65th level from a power point reserve of 993\. It may also manifest 8 epic powers per day with a maximal Psicraft DC of 120\. The saving throws against Ilsensine’s powers are DC 34+power level+relevant augmentation. Ilsensine may also expend it’s psionic focus and manifest a power at 73rd level using the Feats Power Penetration and Greater Power Penetration. Ilsensine may affect any sentient living creature or outsider with it’s telepathic prowess, including beings with lower divine ranking than itself. Ten times a day, Ilsensine may instead choose to boost it’s manifester level when manifesting a single power by it’s virtual divine ranking, giving it a manifester level of 83rd level for the purposes of that particular power. This boost also stacks with the feats Power Penetration and Greater Power Penetration, should it choose to use them.  

Ilsensine may also devise new psionic powers to better serve it’s desire for universal conquest at an accelerated rate. Research for Ilsensine requires 20 XP per day and takes one day per level of the power. As a result, Ilsensine has been responsible for the development of hundreds, if not thousands, of novel psionic powers.  

Blessings of the Divided Mind: Ilsensine is also the permanent beneficiary of a much more powerful variant of the Schism psionic power, allowing it to manifest four different powers simoultaneously at full level, or to use any of it’s four tentacles independent of the other three. While this offers benefits in terms of combat (which Ilsensine naturally loathes), in other situations this has proved to be a hindrance as each of the quadrants of Ilsensine is likely to formulate it’s own plan of action and then telepathically argue it to the rest of Ilsensine.  

Planar Metaconcert: 13 times a day, Ilsensine may enter a Planar Metaconcert with up to six different Illithids that it is aware of, anywhere simoultaneously. A Planar Metaconcert with any particular Illithid lasts for 13 rounds, and comes at a great price for those that contact has been initiated with. For each round that contact has been initiated, they must make a Will save DC 43 or else take 1 Wisdom damage as even by Illithid standards, the mind of Ilsensine is so unimaginably powerful that to contact it brings them pain. As long as Ilsensine is in Planar Metaconcert, his manifester level and power resistance increase for two levels for each Illithid that his mind is linked to and he may additionally increase the save DC’s of all of his psionic powers up to six. Ilsensine may additionally opt to shunt half of all damage done to him to the Illithids that he is psionically linked to; he may distribute this damage in any manner that he wishes.  

**Combat:** Despite Ilsensine’s enormous power, it has actually avoided combat since the Gith revolt. This is because it has reasoned that any being that would dare to seek it out would have established sufficient contingencies in order to ensure that others could follow it to the Caverns of Thought, which would eventually lead to the Githyanki under the lich-queen or worse, the forces of Perdition discovering it’s location and attempting to kill it. However, to stumble upon Ilsensine’s Nutrient Pool within it’s caverns means almost certain doom for the creature involved, as a single psionic ray from it’s power is easily enough to annihilate most lesser beings, much less four aimed at them at once. The few instances in which Ilsensine actually allows a being to gaze upon it’s majesty only means a worse fate for them than total destruction-namely Ceremorphosis and permanent, perfect, thralldom.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *