# Shadow Sidhe (CR 20)  
N Medium fey (Extraplanar)  
**Init** +10; **Senses** Listen +26, Spot +26, darkvision 60, low-light vision  
**Aura** shadow aureole; **Languages** common, elven, gnome, sylvan, undercommon  
**AC** 40, touch 30, flat-footed 30 (+10 dexterity, +10 natural, +10 unearthly grace), _cloak of the stars_, evasion, uncanny dodge  
**hp** 145 (15 fey), fast heal 5; **DR** 10/cold iron and magic  
**Immune** poison, petrification  
**Resist** cold 15, sonic 15; **SR** 25 (HD+10)  
**Fort** +21, **Ref** +29, **Will** +27  
**Speed** 60 ft. (12 squares)  
**Melee** +1 skillfull duskblade +22/+17/+12 (1d10+13 19-20/x2) or Two +1 skill full duskblades +20/+15/+10 (1d10+13 19-20/x2)  
**Melee** +21 touch  
**Ranged** +21 touch  
**Base Atk** +7; **Grp** +10  
**Atk Options** Arcane strike, bardic music 1/round (countersong, fascinate 5 creatures, inspire competence, inspire courage +3, inspire heroics, inspire greatness 3 creatures, song of awakening, song of despair [DC 28], song of freedom, _suggestion_ [DC 27]], twilight wardance (+10 Atck, 18 rounds)), shadow hand savant, sneak attack +5d6  

**Beguiler Spells** (CL 15th)  
7th (5/day)—  
6th (8/day)—  
5th (8/day)—  
4th (8/day)—  
3rd (8/day)—  
2nd (9/day)—  
1st (9/day)—  
0th (at will)—  
**Spell-like Abilities** (CL 15th)  
At will – shadow walk, greater shadow conjuration (summoning only, but may duplicate summon nature's ally spells)  
**Manoeuvres and Stances Known (IL 15th)**  
Stances – Assassin's Stance (3rd), Dance of the Spider (3rd), Step of the Dancing Moth (5th)  
Strikes – Bloodletting Strike (DC 23) (5th), Clinging Shadow Strike (DC 16) (1st), Death in the Dark (DC 25) (7th), Ghost Blade (6th), Hand of Death (DC 22) (4th), Obscuring Shadow Veil (DC 22) (4th), Stalker in the Night (6th),  
Teleportation – Shadow Blink (7th)  
Disciplines – Shadow Hand  
**Abilities** Str 16, Dex 30, Con 22, Int 22, Wis 26, Cha 30  
**SQ** shadow blend, swift tracker, unearthly grace, woodland stride  
**Feats** Arcane Strike, Improved Two Weapon Fighting, Mounted Combat, Shadow Blade (B), Track (B), Twilight Warsong (As Snowflake Wardance) , Two Weapon Fighting, Weapon Finesse  
**Skills** Hide +38, Knowledge [Arcana, Nature, the Planes] +22, Listen +26, Move Silently +38, Perform (Sing) +28, Ride +28, Spellcraft +22, Spot +26, Survival +26, Tumble +28  
**Possessions** 2 +1 skillfull duskblades, cloak of the stars  

**Organization** Solitary, Hunt (2d4 Shadow Sidhe + Ecalypses + 2d6 shadow masiffs)  
**Environment** The Plane of Shadow, or the Prime at twilight  
**Advancement** 16-30 (medium)  
**Level Adjustment:** +7  

**Bardic Music:** A shadow sidhe may use bardic music as a bard of level equal to its hit die. Shadow Sidhe can use or maintain concentration on bardic music once per round as a free action, using their voices as their instrument. In addition to normal bardic music, the shadow sidhe have access to their own unique melodies:  

_Song of Awakening_ – The shadow sidhe may imbue nearby plants and and animals with malign intelligence drawn from the plane of shadow. It can _awaken_ two HD of plant or animal for every rank of Perform [song] it has. The subjects are loyal to the shadow sidhe and remain awakened only as long as the bard sings.  

_Song of Despair_ – The shadow sidhe's voice can draw on the darklands of the plan of shadow to shatter the hearts of its foes. Any enemy within 60 ft who hears the song must make a Will save (DC 10+the shadow sidhe's ranks in Perform [Song]), or suffer 1d6 Charisma and 1d6 Wisdom damage. A creature that hears the Song of Despair cannot be affected by the same shadow singer's song of despair for 24 hours.  

**Beguiler Spellcasting:** A shadow sidhe can cast arcane spells as a beguiler with a level equal to the shadow sidhe's hit die.  

**Shadow Aureole (Su):** The area within 40 ft. of a shadow sidhe is swathed in flicking shadows, making it have shadowy illumination. A light effect of 7th level or higher can counter this effect.  

**Shadow Blend (Su)** In any other conditions than full illumination, a shadow sidhe can disappear into shadows, giving it full concealment. Artificial illumination does not negate this ability, unless it can overcome its **Shadow Aureole**.  

**Shadow Hand Savant (Ex):** The shadow sidhe are natural prodigies at the arts of the Shadow Hand. They have initiator level equal to their hit die, and know one shadow hand stance per five racial HD and one shadow hand manoeuvre per two racial hit die they possess.  

**Skills:** Shadow sidhe are no longer wholly real, and so are more difficult to perceive. They receive a +10 racial bonus to hide and move silently checks.  

**Unearthly Grace (Su)**: The shadow sidhe gains a (deflection) bonus to armour class and saving throws equal to its charisma modifier.  

**Advancement**  

For each hit die the shadow sidhe advances its bardic music, beguiler spellcasting and shadow hand savant ability improves.  

_**New Weapon Special Ability**_  

**Dusk Blade (+1):** Like the sun blade ability to be treated as either a short sword or a bastard sword, whichever is most advantageous. This ability can only be placed on shortswords and only functions when wielded by a character with some metaphysical link to Shadow.  

* * *


**Origin**  

The fey are relatively immune to the taint of those Outside or Inside, by Exemplars or Elementals, due to their cosmological separation from their Realms by the gulfs of the Astral and Ethereal, although some few fey do betray their roots and seek Apotheosis as a Power over mortals or Clarification as a Master of an element. They are vulnerable however, to influence of a different sort, that of Shadow, a plane and concept with a haunting familiarity to the fey, for what is the Prime but a shadow of feyrie, as Shadow is a dark reflection of the Prime. Emboldened by this, fey of the lesser courts commonly seek to extend their influence into Near Shadow, controlling the interstices and nexuses that link “their” parts of the Prime to it. Usually the process stops there, harmlessly enough. Occasionally however, the noble fey continue their quest to subsume Shadow, and find that they come to regard Shadow as much their home as feyrie. From this point, it is Shadow which does the subsuming, so as the sidhe masters the place it becomes him, until the once fey loses it connection with feyrie and does not care, for he is master of a place of glorious shadows, and regret was never an attribute of the fey.  

**Appearance:**  

The shadow sidhe appear much as they did before they partook of shadowstuff – tall, pale, and possessing a beauty only accentuated by the flicking shadows the flock around them. From some angles a shadow sidhe may appear translucent, but the effect is transient as the shadows weave around them.  

**Powers**  

The slow process of transformation into a shadow sidhe robs them of much of their feyrie power, but does bring with it a host of abilities over shadow, some innate, but also many skills developed as an essential part of their quest for mastery over Shadow.  

**Realms**  

The shadow sidhe do not dwell in Shadow itself, instead they dwell in demiplanes suspended between Near and Deep Shadow, formed as their realms in feyrie blended across into Shadow. They usually claim mastery of the Near Shadow in the vicinity. They are served there by Shadow (shadow creature template) versions of normal fey, animals, and plant creatures, as well as unique shadow creatures such as Ecalypses and shadow mastiffs These demiplanes have traits of both Shadow and feyrie. These demiplanes are accessible from the border of Near and Deep Shadow.  

The presence of a shadow sidhe realm tends to prevent Darklands from forming nearby.  

**Ecology**  

When the shadow sidhe convert they cut themselves off from feyrie, and so a new generation of sidhe arises to take their place, usually junior members of the original court who were less concerned with exploring Shadow. The shadow sidhe usually retain cool but cordial relations with their kin the other side of the Prime (see below). Shadow Sidhe do not always persist in this state indefinitely – often they are driven to know their adopted home, and they and their realm retreat from mortal view into Deep Shadow to become Powers of that place, or they blend into Near Shadow, loosing their independent identity in the murk. Shadow Sidhe are comparatively rare, a given prime realm way well have less then a dozen minor shadow courts.  

**Relations with other fey**  

Shadow sidhe have an ambivalent relation with their untainted kin. Their agendas do conflict, as the shadow sidhe see nothing wrong with weakening the barriers between Shadow and the Prime, which the true fey object to, but this rarely leads to open warfare – seeing Shadow Sidhe guests at a Faries Lord's banquet is not unusual. They commonly co-operate in the face of external threats to nature, but the shadow sidhes embrace of the the more arbitrary and flickering dance of shadows in favour of the stately procession of the natural cycles does forever distance them.  

**Relations with mortals**  

The shadow sidhe are likely to resist mortal encroachment into areas of the prime they consider “theirs” (even if disputed with true sidhe). If and when mortal victory becomes inevitable, the shadow sidhe usually adapt to the change in the nature of the coexistant prime far better than “real” fey, and find ways of existing happily amongst the Shadows of a mortal city.  

**Relations with outsiders**  

Shadow sidhe bring their prejudice against Outsiders with them from feyries, and generally oppose their presence on the Prime or in Shadow. This is particularly prevalent amongst those courts who have “adopted” a human community, where they commonly work to subvert mortal religions and expel outsider cults.  

***

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *