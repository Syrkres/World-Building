# Istus  
_Lady of Our Fate_  
**Greater Baklunish Deity**  
**Symbol:** Golden spindle with 3 strands  
**Home Plane:** Temporalis Procellos  
**Alignment:** True Neutral  
**Aliases:** The Colorless and All-Colored  
**Superior:** None.  
**Allies:** Cyndor, Lendor (both tenuous)  
**Foes:** Tharizdun  
**Servants:** The Spectre (Proxy)  
**Servitor Creatures:** Temporal Elementals  
**Manifestations:** uncanny lucky or unfortunate coincidences, webs or netting forming the symbol of Istus, visions  
**Signs of Favor:** uncanny lucky coincidences, visions  
**Worshipers:** Baklunish Seers, mystics, people depending on luck or fortune for their living  
**Cleric Alignments:** LN, TN, CN, NG, NE  
**Speciality Priests:** Yes  
**Holy Days:** Days in which fate or coincidence played special importance  
**Portfolio:** fate, destiny, divination, the future, honesty  
**Domains**: Chaos, Knowledge, Oracle, Law, Luck, Mind, Time  
**Favored Weapon:** "_Web of Istus_” (net)  

**Istus  
Wizard 20/Divine Oracle 10/Seer 20/Cerebremancer 10  
Medium Outsider (_Extraplanar_**_)  
Divine Rank:_ 18  
**Hit Dice:** 20d4 (wizard) plus 10d6 (divine oracle) plus 20d4 (seer) plus 10d4 (cerebremancer) plus 780 (1020 hp)  
**Initiative:** +22 (+14 Dex, +8 Superior Initiative* always goes first)  
**Speed:** 60 ft.  
**Armor Class:** 89 (+33 natural, +18 divine, +14 Dex, +14 deflection), touch 56, flat-footed 89  
**Base Attack/Grapple:** +30/+43  
**Attack:** +85 melee touch or +86 ranged touch or thrown weapon +80 or melee touch +61 or ranged touch +62 * always rolls 20 on attack rolls  
**Full Attack:** +85/+85/+80 melee touch _Web of Fate_ or +86/+86/+81 ranged touch _Web of Fate_ or thrown weapon +80 (1d4 plus +31) or melee touch +61 or ranged touch +62 * thrown weapons always deal 35 points of normal damage. Check for critical.  
**Space/Reach:** 5 ft./5 ft.  
**Special Attacks:** domain powers, salient divine abilities, psionics, spells, spell-like abilities  
**Special Qualities:** divination enhancement, divine aura (18 miles, DC 42), divine immunities, DR 30/epic and adamantine, godly realm (100 miles outer plane, 1800 ft. Material Plane), _greater teleport_ at will, immune to surprise, improved uncanny dodge, _plane shift_ at will, prescient sense, remote communication, resistance (fire) 38, speak, and read all languages and speak directly to all beings with 18 miles, SR 80, trap sense +3, uncanny dodge  
**Saves:** Fort +57 Ref +58 Will +66 * always rolls 20 on saves  
**Abilities:** Str 36, Dex 39, Con 37, Int 45, Wis 43, Cha 38  
**Skills:** Balance +37, Bluff +59, Concentration +66, Craft (weaponsmithing, weaving) +61, Decipher Script +92, Diplomacy +76, Disguise +52 (+56 observed in character), Escape Artist +52, Gather Information +75, Intimidate +36, Knowledge (arcana) +98, Knowledge (architecture and engineering) +67, Knowledge (geography) +65, Knowledge (history) +91, Knowledge (local [Flanaess]) +98, Knowledge (nature) +37, Knowledge (nobility and royalty) +70, Knowledge (psionics) +95, Knowledge (religion) +75, Knowledge (the planes) +98, Listen +69, Psicraft +104, Search +65 (+69 find secret doors/hidden compartments), Sense Motive +61, Spellcraft +104, Spot +76, Survival +41 (+45 avoid getting lost/natural hazards, find/follow tracks, +47 extraplanar) * always rolls 20 on skill checks  
**Feats:** Combat Reflexes, Empower Power, Empower Spell, Eschew Material Components, Extend Power, Extend Spell, Heighten Spell, Improved Initiative, Persistent Spell, Power Penetration, Psionic Meditation, Quick Draw, Quicken Power, Quicken Spell, Repeat Spell, Scribe Scroll, Twin Power  
**Epic Feats:** Epic Spellcasting, Epic Psionic Focus(x2), Improved Combat Reflexes, Improved Heighten Spell, Improved Metamagic(x2), Improved Metapsionics(x2), Intensify Spell, Multipower, Multispell, Spell Opportunity, Superior Initiative  
**Salient Divine Abilities:** Alter Form, Area Divine Shield, Automatic Metamagic (Extend Spell), Clearsight (180 ft.), Divine Blessing (Wisdom), Divine Fast Healing (fast healing 38), Divine Psionics, Divine Recall (each instance of a spell that can affect the timeline), Divine Shield, Divine Spellcasting, Extra Domain (Law), Gift of Life, Know Death, Know Secrets (Will save DC 52), Lay Quest (18 creatures at once or 18/day, Will save DC 52), Life and Death, Power of Luck (18 creatures at once or 18/day, +18/-18 luck), Power of Truth (18 creatures at once or 18/day, Will save DC 52), Rejuvenation, Shapechange, Shielded Causality (Unique Salient Divine Ability), Spindle of Istus (Unique Salient Divine Ability), Superior Initiative  
**Environment:** The Loom of Fate (Temporalis Procellos)  
**Organization:** Istus and one Temporal Elemental  
**Challenge Rating:** 63  
**Treasure:** _Web of Fate_  
**Alignment:** True Neutral  
**Advancement:** --  
**Level Adjustment:** –  

**Alter Reality (Su):** Istus exerts a considerable measure of control over reality itself, and her presence can command the very essence of the world around her. Ther warping of reality manifested in a number of ways. Istus can use _wish_ when doing so could help her to discover threats to the timeline of Oerth, determine the future or the past, or repair any damage to the timeline of Oerth that she has discovered. Note that in the situation where Istus and another deity both try to Alter Reality in opposition to each other, an opposed rank check may be necessary to determine how reality is actually altered.  
- Istus can use alter reality to cast any _cure_ spell at will as a standard action; Istus can apply metamagic feats to the spells if desired, but doing so requires her to forego using alter reality for 1 round for each level the feat would normally add to the equivalent spell.  
- As a free action, Istus can assume any size from Fine to Colossal. Istus can also change the size of up to 100 pounds of objects she touches. Ther ability allows Istus to assume any proportions from the size of a grain of sand up to as much as 1,600 feet tall. A radical change in size can have great impact on Istus’s combat ability. Istus' Strength, Armor Class, attack bonus, and damage dealt with weapons changes according to the size the deity assumes. Istus' Strength score can never be reduced to less than 1 through ther ability. Also note that use of ther divine ability does not affect all of Istus' characteristics.  
**- Divine Immunities:** Ability damage, ability drain, _banishment, binding,_ cold, death effects, _dimensional anchor,_ disease, _disintegration, dismissal,_ electricity, energy drain, _imprisonment,_ mind-affecting effects, paralysis, poison, _repulsion,_ sleep, _soul bind,_ stunning, _temporal stasis,_ transmutation, _trap the soul,_ and turning and rebuking.  
**- Domain Powers:** Casts chaotic and lawful spells at +1 caster level; casts divinations at +1 caster level and treats all Knowledge skills as class skills; can reroll her last die roll 18/day; gains a +2 bonus on Bluff, Diplomacy, and Sense Motive checks; casts divinations at +2 caster level.  
**- Spell-Like Abilities:** At will: _age creature, aid, animate objects, augury, brain spider, break enchantment, calm emotions, chaos hammer, choose future, clairaudience/clairvoyance, cloak of chaos, commune, comprehend languages, detect secret doors, detect thoughts, dictum, discern lies, discern location, dispel chaos, dispel law, divination, entropic shield, find the path, foresight, freedom of movement, greater scrying, hesitation, haste, hold monster, identify, legend lore, lesser telepathic bond, magic circle against chaos, magic circle against law, mind blank, miracle, mislead, moment of prescience, order’s wrath, probe thoughts, protection from chaos, protection from energy, protection from law, repeat action, scrying, shield of law, temporal stasis, time pool, time stop, reverse time, shatter, spell turning, summon monster IX_ (lawful or chaotic creatures only), _true seeing, telepathic bond, weird, word of chaos._ Istus uses these abilities as an 78th level caster, except for chaotic and lawful spells, which she uses as a 79th-level caster, and divinations, which she uses as an 81st level caster. The save DCs are 52 + spell level.  

**Divination Enhancement (Ex):** Istus may roll twice and take the better result when using divination spells such as _augury_ or _divination_.  

**Immune to Surprise (Ex):** Istus’ sensitivity to danger is so great that she is never surprised. She can always take a standard action during a surprise round, unless she is physically restrained from doing so. If there is no surprise round then this ability doesn’t help.  

**Prescient Sense (Ex):** If Istus makes a successful Ref saving throw against an attack that normally inflicts half damage on a successful save, she instead takes no damage, since her prescience allows her to get out of the way faster. This form of evasion works regardless of any armor worn.  

**Psionic Powers (Sp):** Istus manifests as a 30th level Seer or at 48th level for the purposes of power penetration, or she may expend her psionic focus to manifest as a 56th level Seer. Saving throws against Istus’ psionic powers are DC 27 + power level + relevant augmentation. The saving throw DC’s are Intelligence-based. Istus knows 36 powers and has a daily reserve of 721 power points.  

**Seer Powers:** 1st level: _catfall, detect psionics, know direction and location, mind thrust._ 2nd level: _object reading, sensitivity to psychic impressions._ 3rd level: _body adjustment, body purification, danger sense, escape detection, time hop, touchsight._ 4th level: _anchored navigation, detect remote viewing, psychic reformation, remote viewing, telekinetic maneuver, trace teleport._ 5th level: _clairtangent hand, psychic crush, shatter mind blank, tower of iron will._ 6th level: _aura alteration, cloud mind_ (mass), _contingency_ (psionic), _overland flight_ (psionic). 7th level: _divert teleport, energy conversion, mind blank_ (personal), _phase door_ (psionic). 8th level: _bend reality, hypercognition, teleport_ (psionic greater). 9th level: _metafaculty, reality revision, timeless body._  

**Scry Bonus (Su):** Istus adds a +1 sacred bonus to the DC of all of her Divination (scrying) spells.  

**Shielded Causality (Unique Salient Divine Ability):** Istus cannot be affected by any spell intended to alter time unless the being involved succeeds on a rank check against her. For the purposes of spells such as _time stop_, or psionic powers such as _time hop_ or _mass time hop_, she is additionally considered to be located in the same timestream as anyone who casts or manifests them within any area that she can sense directly. If there are multiple castings of _time stop_ or similarly inclined spells or psionic powers, Istus is considered to be in the timestream of the first such spell or power that takes effect, and may choose afterwards which timestream she wishes to enter once the duration of the first casting or manifestation ends.  

**Spindle of Istus (Unique Salient Divine Ability):** Istus is closely associated with the device known as the _Spindle of Istus_ or the _Web of Istus_. A small golden rod wrapped with silver strands and often thought to be an Artifact, it is, in fact, generated by Istus herself as a salient divine ability. The _Spindle of Istus_ allows Istus the power both to control time, as well as to control those that interfere with her actions should it be fated that she need to enter combat against them. As a result, the _Spindle of Istus_ may throw strands within a 60 foot range, or create webs within a 15 foot radius as melee touch attacks that have the following effects. For those effects that have saving throws, the relevant save DC is 52 and is Charisma-based.  

_Strand of Binding:_ By throwing this strand at a target, Istus shunts her target into a unique timeline in which time flows so slowly that it is considered to be effectively held in place for 10d10 rounds. While the unique timeline created in this manner is unstable and degenerates naturally, it is exceptionally difficult for any other being to reach and release the being temporarily imprisoned in this manner, requiring a successful rank check against the Lady of Fate. Istus may use the _Strand of Binding_ three times a day. Targets of this strand receive a save against its effects.  

_Strand of Cancellation:_ Istus disintegrates a magical object or living being with this strand, causing their uttermost destruction. For objects or living beings disintegrated in this manner, a successful rank check against Istus is required to bring them back into existence. Targets of this strand receive a save against its effects.  

_Strand of Death:_ The fate of Istus’ foe is sealed, causing a living being to die instantly. Individuals slain by the _Strand of Death_ can not be resurrected except through making a successful rank check against Istus, and the _Strand of Death_ can be used once a day. Istus does not require rest after throwing this particular strand. Targets of this strand receive a save against it’s effects.  

_Strand of Hostility:_ Fate binds a target of Istus’ choosing to her, and compels them to become her champion, implanting an essentially permanent charm within their mind that convinces them that they should fight for Istus, even at the cost of their own life. The _Strand of Hostility_ can be thrown twice a day. Targets of this strand receive a save against it’s effects.  

_Strand of the Realms Beyond:_ Istus temporarily links two planes together through throwing this particular strand. This is similar to the transport function of the spell _gate_ except for the fact that Istus can successfully transport herself along with any other being that touches the Strand anywhere she can sense upon a successful rank check. The Strand remains for three rounds, but travel only occurs in one direction from Istus’ current location to the destination that she has chosen. The _Strand of the Realms Beyond_ can be thrown three times a day.  

_Strand of Sending:_ By throwing this strand at a willing target, the creature struck is sent up to 200 days into the future to a point in the future timeline where Istus considers it’s freedom or existence to be the most threatened, or where fate best presents itself with opportunities for the creature sent forwards. This strand may be thrown at will.  

_Web of Enmeshing:_ Istus creates an interlinked network of strands that functions as an entrance to a distorted extradimensional space similar to a maze that forces all beings except for Istus and one ally of her choice to make two separate Will saves. If the first Will save is failed, then they are trapped in the web, and beings caught within the _Web_ that are slain while it exists remain within it, even if the entrance to the Web disappears. If the second Will save is failed, then victims of the _Web_ are treated as _confused_ as the spell for the next 1d6 rounds. The _Web of Enmeshing_ can be created once a day. Targets of this web receive a save against it’s effects.  

_Web of Entropy:_ One of Istus’ most powerful webs, the _Web of Entropy_ causes the degeneration of any magical effects and items except for those which Istus designates. Unattended magical items are _disintegrated_ as the spell, while beings carrying magical items receive a Will save in order to avoid the same fate occuring to their possessions. The _Web of Entropy_ lasts for one round, which additionally blocks any magical spells or psionic effects from either entering or leaving the _Web_. The _Web of Entropy_ can be created once a day.  

_Web of Stars:_ When Istus throws this web, all creatures within range must make a Will save or else be transported to a demiplane of Istus’ creation filled with strands. Creatures dragged into the _Web of Stars_ can make a Knowledge (the planes) check DC 38 in order to identify which direction can taken them back to their entry point, or to other locations throughout the Realms Beyond, or the Temporal Plane itself. The _Web of Stars_ can be created once a day. Targets of this web receive a save against it’s effects.  

In addition to the attack potential of the _Spindle of Istus_, Istus may use her _Spindle_ to move through time itself, although this exhausts the power of the _Spindle_. As a result, for each day that Istus wishes to move forwards or backwards in time, the _Spindle_ cannot be used for throwing any strands for one round; for each week that Istus wishes to move forwards or backwards in time, the _Spindle_ cannot be used for one minute; for each year that Istus wishes to move forwards or backwards in time, the _Spindle_ cannot be used for one hour, and for each century that Istus wishes to move forward or backwards in time, the _Spindle_ cannot be used for one day.  

Finally, Istus may grant her proxies and some of her most favored worshippers the ability to throw Strands. This is exceptionally rare, and no worshipper may be granted any more than two Strands per day. In such cases, the saving throw DC is based upon the worshipper’s Charisma, and not Istus’.  

Finally, the _Spindle of Istus_ is considered to be linked through fate to Istus herself. As long as she has not been permanently destroyed, the _Spindle_ regenerates 1d100 days after Istus has Rejuvenated, even if it is disjoined. If Istus is slain first, however, then the _Spindle_ may be disjoined as normal.  

**Wizard Spells (Sp) (0th-17th level): 4/9/8/8/8/8/7/7/7/7/5/5/5/5/4/4/4/4** Istus casts spells as a 40th level Wizard and at 58th level for the purposes of spell penetration except for Divinations, which are cast at 43rd level and at 61st level for the purposes of spell penetration. Saving throws against Istus’ Wizard spells are DC 27 + spell level, except for Divination (scrying) spells, which have save DC’s of 28 + spell level. The saving throw DC’s are Intelligence-based, and all of Istus’ spells are Extended. Istus may cast 6 epic spells/day with a maximal Spellcraft DC of 124.  

0th level: _arcane mark, read magic(x3)._ 1st level: _erase, hold portal(x2), portal beacon(x2), silent image(x2), true strike(x2)._ 2nd level: _blur, darkvision, mirror image, misdirection, obscure object, wall of gloom(x2), whispering wind._ 3rd level: _analyze portal(x2), displacement,_ quickened _erase, haste, illusory script, magic circle against good, magic circle against evil._ 4th level: _dimensional anchor(x2), illusory wall,_ quickened _mirror image(x2), resist energy_ (mass), _scramble portal, unluck._ 5th level: _aiming at the target, dream,_ empowered _orb of force, persistent image(x2), refusal(x2), wall of force._ 6th level: quickened _dimensional anchor, dispel magic_ (greater)(x2), _mislead, permanent image, seal portal(x2)._ 7th level: empowered _disintegrate, ghostform, project image(x2), sequester(x2), vision._ 8th level: _anticipate teleportation_ (greater), _antipathy, demand,_ quickened _dispel magic_ (greater)(x2), _maze, screen._ 9th level: _etherealness, freedom,_ quickened _hold person_ (mass), _imprisonment,_ repeated _maze,_ empowered, quickened _orb of force, programmed amnesia._ 10th level: heightened (to 10th level) _banishment(x2),_ quickened _charm monster_ (mass)(x2), heightened (to 10th level) _demand._ 11th level: quickened _disjunction(x2),_ persistent _ghostform,_ heightened (to 11th level) _transfix,_ quickened _weird._ 12th level: heightened (to 12th level) _hold monster_ (mass)(x2), heightened (to 12th level) _imprisonment,_ heightened (to 10th level), quickened _unluck(x2)._ 13th level: heightened (to 13th level) _imprisonment,_ intensified, quickened _orb of force(x2),_ persistent _superior invisibility(x2)._ 14th level: heightened (to 14th level) _banishment(x2)_, heightened (to 13th level), repeated _disintegrate,_ heightened (to 12th level), quickened _imprisonment._ 15th level: heightened (to 15th level) _demand,_ persistent, quickened _forcecage,_ heightened (to 13th level), quickened _unluck,_ heightened (to 13th level), quickened _weird._ 16th level: empowered, heightened (to 11th level), quickened _orb of force(x2),_ heightened (to 16th level) _transfix,_ heightened (to 9th level), persistent, quickened _unluck._ 17th level: heightened (to 12th level), intensified _disintegrate,_ heightened (to 15th level), quickened _maze,_ heightened (to 13th level), persistent _unluck,_ heightened (to 15th level), quickened _weird._ epic spells known: _dreamscape, epic dispel magic, future sight, Istus’ contingent recall, Istus’ inexorable web, peripety, safe time, soul scry, the subtle touch of fate._  

**Other Divine Powers:**  
- As a greater deity, Istus is immortal, and is not considered to be permanently dead unless she is killed in The Loom of Fate and provided that the attacker makes a successful rank check. Otherwise, Istus reforms after 10d10 – 18 days in the Loom of Fate. If she is killed in a divinely morphic Realm Beyond, she reforms after 10d10 – 36 days, but it always takes her at least one day to reform. Istus’ ability to reform can be negated upon a successful rank check. If Istus is slain upon Oerth, she loses jurisdiction on that world and seems to die. Istus may reform after 60 years if sufficient worship is available or a suitable ritual is performed.  
**- Senses:** Istus can see (using normal vision or low-light vision), hear, touch, and smell at a distance of 18 miles. As a standard action, she can perceive anything within 18 miles of her worshipers, holy sites, objects, or any location where one of her titles or name was spoken in the last hour. She can extend her senses to up to twenty locations at once. She can block the sensing power of deities of her rank or lower at up to two remote locations at once, plus the area within one mile of herself for 18 hours.  
**- Portfolio Sense:** Istus senses any attempt to determine fate, influence destiny, or action of great historical import up to 18 weeks in the past and 18 weeks in the future.  
**- Automatic Actions:** Istus can use any skill that aids her to unravel the strands of fate, such as Knowledge (history), Knowledge (the planes), Gather Information, or Sense Motive as a swift action if the DC for the task is 30 or lower. She can perform up to ten such swift actions each round.  
**- Create Magic Items:** Istus can create any kind of magic item including artifacts if it can be used to influence or discern fate, or was or will be destined to be vitally important.  

**Possessions:** While Istus is believed to have a wide array of possessions in her personal demensne, her most common possession is, in fact, the _Spindle of Istus_.  

**Avatars**:  
Istus sends her Avatar to Oerth only to monitor exceptionally important events, or to select a single Proxy that has met her criteria for a being touched sufficiently by the strands of fate to attract her attention. Such criteria often include being the last survivor of an otherwise extinct group through sheer luck and similar selective processes. Istus’ Avatar additionally has very strict rules about not disturbing her own observations except in the most dire of circumstances, and more often than not is cloaked through means such as _cloud mind_ in order to prevent detection.  

When Istus’ Avatar is visible, however, she has three forms: either a middle-aged noble woman or dame, a young child, or an extremely old woman whose decrepit physical appearance belies her true strength and spryness. In such circumstances, she may be accompanied by a Temporal Elemental but there is a slightly less than 1/3 chance that this will occur.  

**Istus’ Avatar  
Medium Outsider (_Extraplanar_**_)  
Divine Rank:_ 0  
**Wizard 10/Divine Oracle 5/Seer 10/Cerebremancer 5  
Hit Dice:** 10d4 (wizard) plus 5d6 (divine oracle) plus 10d4 (seer) plus 5d4 (cerebremancer) plus 300 (430 hp)  
**Initiative:** +20 (+11 Dex, +9 Superior Initiative * always goes first)  
**Speed:** 60 ft. (12 squares)  
**Armor Class:** 47 (+15 natural, +11 Dex, +11 deflection), touch 32, flat-footed 36  
**Base Attack/Grapple:** +15/+25  
**Attack:** _Spindle of Istus_ +25ranged touch or +25 melee touch or +26 ranged touch  
**Full Attack:** _Spindle of Istus_ +25/+20 ranged touch or +25 melee touch or +26 ranged touch  
**Space/Reach:** 5 ft./5 ft.  
**Special Attacks:** domain powers, psionics, salient divine abilities, spells, spell-like abilities  
**Special Qualities:** divination enhancement, divine aura (180 feet, DC 21), divine immunities, DR 10/epic, _greater teleport_ at will, _plane shift_ at will, prescient sense, resistance (cold) 20, scry bonus, SR 30, trap sense +2, uncanny dodge  
**Saves:** Fort +21 Ref +22 Will +30  
**Abilities:** Str 31, Dex 33, Con 31, Int 37, Wis 36, Cha 32  
**Skills:** Bluff +23, Concentration +23, Decipher Script +28, Diplomacy +34, Disguise +26 (+28 observed in character), Escape Artist +18, Gather Information +23, Intimidate +13, Knowledge (arcana) +46, Knowledge (architecture and engineering) +26, Knowledge (history) +46, Knowledge (local [Flanaess] +21), Knowledge (nobility and royalty) +23, Knowledge (psionics) +46, Knowledge (religion) +28, Knowledge (the planes) +46, Listen +10, Psicraft +50, Search +23 (+25 find secret doors/hidden compartments), Sense Motive +27, Spellcraft +50, Spot +29, Survival +15 (+19 extraplanar, +17 find/follow tracks)  
**Feats:** Combat Reflexes, Empower Power, Empower Spell, Eschew Material Components, Extend Power, Extend Spell, Heighten Spell, Improved Initiative, Power Penetration, Psionic Meditation, Quick Draw, Quicken Power, Quicken Spell, Scribe Scroll, Twin Power  
**Epic Feats:** Epic Psionic Focus, Superior Initiative  
**Environment:** Oerth  
**Organization:** Solitary (unique) or Istus’ Avatar and one Temporal Elemental  
**Challenge Rating:** 31  
**Treasure:** None  
**Alignment:** True Neutral  
**Advancement:** --  
**Level Adjustment:** –  

**- Divine Immunities:** Ability damage, ability drain, mind-affecting effects.  
**- Domain Powers:[/b Casts chaotic and lawful spells at +1 caster level; casts divinations at +1 caster level and treats all Knowledge skills as class skills; can reroll her last die roll 3/day; gains a +2 bonus on Bluff, Diplomacy, and Sense Motive checks; casts divinations at +2 caster level.  
[b]- Salient Divine Abilities:** Alter Form, Bonus Domain (Law), Shielded Causality, Spindle of Istus, Supreme Initiative  
**- Spell-Like Abilities:** 3/day: _age creature, aid, animate objects, augury, brain spider, break enchantment, calm emotions, chaos hammer, choose future, clairaudience/clairvoyance, cloak of chaos, commune, comprehend languages, detect secret doors, detect thoughts, dictum, discern lies, discern location, dispel chaos, dispel law, divination, entropic shield, find the path, foresight, freedom of movement, greater scrying, hesitation, haste, hold monster, identify, legend lore, lesser telepathic bond, magic circle against chaos, magic circle against law, mind blank, miracle, mislead, moment of prescience, order’s wrath, probe thoughts, protection from chaos, protection from energy, protection from law, repeat action, scrying, shield of law, temporal stasis, time pool, time stop, reverse time, shatter, spell turning, summon monster IX_ (lawful or chaotic creatures only), _true seeing, telepathic bond, weird, word of chaos._ Istus’ Avatar uses these abilities as a 30th level caster, except for lawful and chaotic spells, which she uses as a 31st-level caster, and divinations, which she uses as a 33rd level caster. The save DCs are 21 + spell level. The saving throw DC’s are Charisma-based.  

**Divination Enhancement (Ex):** Istus’ Avatar may roll twice and take the better result when using divination spells such as _augury_ or _divination_.  

**Prescient Sense (Ex):** If Istus’ Avatar makes a successful Ref saving throw against an attack that normally inflicts half damage on a successful save, she instead takes no damage, since her prescience allows her to get out of the way faster. This form of evasion works regardless of any armor worn.  

**Psionic Powers (Sp):** Istus’ Avatar manifests as a 15th level Seer or she may expend her psionic focus to manifest as a 19th level Seer. Saving throws against Istus’ psionic powers are DC 21 + power level + relevant augmentation. The saving throw DC’s are Intelligence-based. Istus’ Avatar knows 28 powers and has a daily reserve of 293 power points.  

**Seer Powers:** 1st level: _catfall, detect psionics, know direction and location, mind thrust._ 2nd level: _object reading, sensitivity to psychic impressions._ 3rd level: _body adjustment, body purification, danger sense, escape detection, time hop, touchsight._ 4th level: _anchored navigation, detect remote viewing, trace teleport._ 5th level: _clairtangent hand, psychic crush, shatter mind blank, tower of iron will._ 6th level: _aura alteration, cloud mind_ (mass), _contingency_ (psionic), _overland flight_ (psionic). 7th level: _divert teleport, mind blank_ (personal). 8th level: _bend reality, hypercognition, teleport_ (psionic greater).  

**Scry Bonus (Su):** Istus’ Avatar adds a +1 sacred bonus to the DC of all of her Divination (scrying) spells.  

**Wizard Spells (0th-9th level) (Sp): 4/8/7/7/7/7/6/6/6/6:** Istus’ Avatar casts her Wizard spells at 20th level. Saving throws against Istus’ Avatar’s Wizard spells are DC 21 + spell level, except for divinations, which have save DC’s of 22 + spell level. The saving throw DC’s are Intelligence-based.  

Istus’ Contingent Recall  
**_Conjuration [Teleportation]_**_  
Spellcraft DC:_ 78  
**Components:** V, S  
**Casting Time:** 11 minute  
**Range:** Personal  
**Duration:** Contingent until expended, then instantaneous  
**Saving Throw:** None (see text)  
**Spell Resistance:** Yes (harmless)  
**To Develop:** 702,000 gp; 15 days; 28,080 XP. **Seed:** _transport_ (DC 27). **Factors:** interplanar travel (+4 DC), Temporal Plane transport (+2 DC), contingent (+25 DC) cast 20 levels higher to beat dispel effect (+40 DC). **Mitigating Factors:** 10 minute casting (-20 DC).  

The casting of this epic spell involves the caster setting a trigger event which will cause the spell to be set off. Unless this trigger even occurs, _Istus’ contingent recall_ remains inactive and occupies one of the her epic spell slots until the day has passed or the contingency is triggered, whichever occurs earlier. If the trigger takes place, however, Istus as well as another touched willing creature weighing up to 1,000 lbs are instantly transported through the Temporal Plane back to Istus’ personal demensne. For the purposes of avoiding dispelling, _Istus’ contingent recall_ is treated as cast 20 levels higher.  

Istus’ Inexorable Web  
**_Abjuration_**_  
Spellcraft DC:_ 122  
**Components:** V, S  
**Casting Time:** 1 quickened action  
**Range:** 60 ft. radius spherical emanation  
**Duration:** 24 hours  
**Saving Throw:** None  
**Spell Resistance:** Yes  
**To Develop:** 972,000 gp; 20 days; 38,880 XP. **Seed:** _ward_ (DC 14). **Factors:** ward against _planeshift_ (+12), _gate_ (+16), _teleport_ (+8 DC), _greater teleport_ (+12 DC), cast 15 levels higher (+30 DC), increase area 500% (+10 DC), 1-action casting (+20 DC).  

For beings that attempt to evade what fate may have in store for them, Istus casts _Istus’ inexorable web._ _Istus’ inexorable web_ appears as a spherical network of glowing, silvery-netting that extends in a sphere around Istus with a 60-foot radius, and is otherwise harmless to any being that crosses into it. At the same time, it is a potent abjuration which prevents any beings within the radius when it is cast from casting the spells _greater teleport, teleport, planeshift,_ or _gate_ and attempting to evade fate through such means. _Istus’ inexorable web_ is treated as cast 15 levels higher for the purposes of resisting dispel checks.  

Subtle Touch of Fate  
**_Divination_**_  
Spellcraft DC:_ 120  
**Components:** V, S, XP  
**Casting Time:** 11 minutes  
**Range:** 60 ft. radius spherical emanation  
**Duration:** 20 minutes  
**Saving Throw:** None  
**Spell Resistance:** No  
**To Develop:** 1,080,000 gp; 22 days; 43,200 XP. **Seed:** _reveal_ (DC 19). **Factors:** both hear and see (+2 DC), reach Oerth (+8 DC), allow magically enhanced senses to work through sensor (+4 DC), cast spells through sensor with no line of sight restriction (x10). **Mitigating factors:** 10 minute casting time (-20 DC), burn 19,000 XP (-190 DC).  

There are exceptionally rare instances where Istus must act directly upon Oerth; in such circumstances her actions are subtle and accomplished through the _subtle touch of fate_. Once the casting is completed, Istus creates a magical sensor through which she can both hear and see magically, and can cast spells through. Istus typically casts this epic spell in combination with _animate objects_ and similar spells in order to create subtle changes in the spatial locations of objects which will have important ramifications as far as fate itself is concerned.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *