# Pelor, The Shinning One
Greater Deity  
**Symbol:** Sun Face  
**Home Plane:** Elysium  
**Alignment:** Neutral Good  

**Portfolio:** Sun, light, strength, healing  
**Cleric Alignments:** CG, LG, NG  
**Domains:** Good, Healing, Strength, Sun  
**Favored Weapon:** Mace  

**Cleric 30/Fighter 20/Druid 10  
Medium-Size Outsider  
Divine Rank:** 17  
**Hit Dice:** 30d8 (cleric) + 20d10 (fighter) + 10d8 (druid) + 780, (1,300 hp)  
**Initiative:** +16 (+12 Dex, +4 Improved Initiative)  

**Speed:** 60 ft.  
**AC:** 98 (+12 Dex, +17 divine, +42 natural, +17 deflection)  
**Base Attack/Grapple:** +35/+69  
**Attacks*:** +10 _mighty disruption fiery blast_ heavy mace +84 (1d8+30, 19-20/x20). _*Always receives a 20 on attack rolls; roll die to check for critical hit. Maximum damage with mace (mace 38 + 18 fire)_  

**Full Attack*:** +10 _mighty disruption fiery blast_ heavy mace +84/+79/+74 (1d8+30, 19-20/x20). _*Always receives a 20 on attack rolls; roll die to check for critical hit. Maximum damage with mace (mace 38 + 18 fire)._  
**Face/Reach:** 5 ft. by 5ft./5 ft.  
**Special Attacks:** turn undead (32/day, +2 synergy), domain powers, salient divine abilities, spell-like abilities  

**Special Qualities:** Divine Immunities, DR 25/epic and silver and unholy, Fire Immunity, Fast Healing 37, Godly Communication, Godly Realm, SR 79, divine aura (1700’ DC 44), animal companion, nature’s sense, resist nature’s lure, trackless step, wild empathy (+44), wild shape (large) 4/day, woodland stride.  
**Saves*:** Fort +62, Ref +55, Will +74 _*Always receives a 20 on saves._  
**Abilities:** Str 46, Dex 34, Con 36, Int 40, Wis 61, Cha 44.  

**Skills *:** Concentration +83 (53), Craft (glassmaking) +81 (49), Craft (metalworking) +81 (49), Diplomacy +73 (39), Handle Animal +67 (33), Heal +97 (55), Knowledge (arcana) +80 (48), Knowledge (nature) +68 (36), Knowledge (religion) +80 (48), Knowledge (undead) +54 (22), Listen +91 (49), Perform +59 (25), Profession (farmer) +94 (52), Profession (herbalist) +95 (53), Profession (sailor) +95 (53), Ride (horse) +60 (31), Search +54 (22), Sense Motive +64 (22), Spellcraft +84 (52), Spot +78 (36), Survival +79 (37). _*Always receives a 20 on checks_.  
**Feats:** Cleave (B), Combat Expertise (B), Dodge, Empower Spell, Extra Turning x3, Great Cleave, Improved Critical (heavy mace), Improved Initiative, Mobility (B), Mounted Combat (B), Power Attack (B), Ride-by Attack (B), Spirited Charge (B), Spring Attack (B), Weapon Focus (heavy mace), Weapon Specialization (heavy mace), Whirlwind Attack (B).  
**Epic Feats:** *Divine Might, *Divine Vengeance, Enhance Spell, Epic Spellcasting, *Heighten Spell, Improved Heighten, Improved Metamagic, Intensify Spell, *Maximize Spell, *Natural Spell, Planar Turning, Positive Energy Aura, *Reach Spell, *Twin Spell. _*feats taken in epic slots_  

**Divine Immunities:** Ability Damage, ability drain, acid, cold, death effects, disease, disintegration, electricity, energy drain, mind-affecting effects, paralysis, poison, sleep, stunning, transmutation, imprisonment, banishment.  
**Salient Divine Abilities:** Area Divine Shield, Automatic Meta-magic (quicken spell), Call Creatures (eagles of all sorts), Create Greater Object, Create Object, Divine Blast, Divine Creation, Divine Fast Healing, Divine Radiance, Divine Shield, Divine Spellcasting, Divine Storm, Divine Weapon Focus (heavy mace), Extra Domain (strength), Extra Energy Immunity (fire), Gift of Life, Increased Damage Reduction, Life and Death, Mass Divine Blast, Mass Life and Death, Rejuvenation, Supreme Initiative.  
**Domain Powers:** Cast good spells at +1 caster level; cast healing spells at +1 caster level; 17/day feat of strength (+30 enhancement to Str for 1 round); 17/day greater turing.  
**Spell-Like Abilities:** _At will_ - Good, Healing, Strength, and Sun domain spells (caster level 27th, DC 44 + spell level), _teleport, greater_ (1700 lbs) and _plane shift_ (1700 lbs) (caster level 20th)  

**Cleric Spells/Day:** (6/12+1/11+1/11+1/11+1/11+1/9+1/9+1/9+1/9+1/5/5/5/5/4/4/4/4/3/3/3/3/2/2; caster level 47th, DC 61 + spell level)  
**Druid Spells/Day:** (6/11/10/9/9/8; caster level 27th, DC 35 + spell level)  
**Possessions:** +10 _mighty disruption fiery blast_ heavy mace  

**Other Divine Powers**  

**Alter Reality**  
Pelor can use wish with regard to any action that involves the sun, light, a act of strength, or healing; he cannot duplicate spells though. It is a standard action for Pelor to alter reality in this fashion.  
Pelor has full access to the abilities described in the Alter Size SDA.  
Pelor may create an avatar as described in the Avatar SDA.  

Pelor also gains the following benefits:  
Pelor adds his Wisdom modifier (+25) again for determining cleric spell DC’s.  

Pelor may also do the following up to 17/day: add his Charisma modifier (+17) to his cleric spellcaster levels for purpose of determining damage, range, SR checks, # of targets, etc.  

**Senses:** Pelor can see, hear, touch, and smell at a distance of seventeen miles. As a standard action, Pelor can perceive anything within seventeen miles of his servants or worshippers, holy sites, objects, or any location where one of his titles or name was spoken in the last hour. He can extend his senses up to 20 locations at once.  

**Portfolio Sense:** Pelor can sense any dusk or dawn. He knows when any light is lit, he is likewise aware of any healing. He notes this 17 weeks before they happen and retains them for 17 weeks thereafter.  

**Automatic Action:** Pelor can use any Strength-related skill as a free action if the DC for the task is 30 or lower. He may use any one of his craft, knowledge, or profession skills as a free action if the DC for the task is 30 or lower. He cannot do anything as a free-action if his task is part of a move action. He can perform up to 20 such free actions each round.  

**Magic Items:** Pelor can create any item that sheds light or flame as a flaming burst weapon. He can also create items that heal injures or restores life.  

* * *


## On the evil of Pelor
Pelor is commonly thought to be the near embodiment of Neutral Good. As a sun god, he is thought to be the enemy of the undead and the author of life through his gifts. He is also a god of Strength, for he advocates that the weak must be protected by those capable.  

However, recent revelations have given rise to a sect of thought (some label it an outright heresy) that Pelor may not be what he claims to be. A passage in the Book of Exalted Deeds states that Pelor refused to send his paladin a sunfly swarm to destroy a vampire that had murdered his family, while the paladin was out doing Pelor’s work. In the same section, a CG god named Kord visited a plague upon his worshipper who was defeated on the battlefield. Speculations abound as to why Pelor refused his faithful paladin and range from defending the god (Pelor couldn’t allow himself to stoop to the mortal’s level of hate) to accusing the god (Pelor wanted to see his paladin suffer). No concrete answer could be found, but for those who thought it was a poor choice on Pelor’s part, it led to a path of horrific discovery after discovery.  

Further investigation revealed (in the Epic Level Handbook) that the Lord High Priest of Pelor denounced her deity and the faith. It also said that the secret texts of a prominent religion, recently discovered, call into question the church’s real goal, its actual origin and the agenda of its god.  

From there we turn to the Player's Handbook, as noted by Lord-Masker.  

Jozan, the archetypical cleric of the Burning Hate is shown using symbol of pain, a 5th level cleric spell with the evil descriptor (PH 291). The SRD has two things to say about this:  

First, a cleric can’t cast spells of an alignment opposed to his own or his deity’s (if he has one). Spells associated with particular alignments are indicated by the chaos, evil, good, and law descriptors in their spell descriptions.  

Second, a cleric’s alignment must be within one step of his deity’s (that is, it may be one step away on either the lawful-chaotic axis or the good-evil axis, but not both). A cleric may not be neutral unless his deity’s alignment is also neutral.  

This means that Jozan can not be good-aligned, since he can casts evil spells. Nor Pelor can be , because he can grant evil aligned spells, that can only come from a non-good deity. So, Pelor can not be good-aligned.  

Also, Jozan has been seen steping on the face of his allies to rise higher, rather than store his shield and mace (PH 68 ). That is not the act of a good-aligned being and shows quite a level of paranoia and mistrust against his allies.  

Moving on from there to the Complete Scoundrel, we find the path of the malconvoker introduced. This path requires a non-evil alignment and deals in the summoning of demons. A quote from the iconic malconvoker: “Take him my slaves! Drag his soul back to your dark masters!” - Argyll Te’Shea, servant of Pelor and malconvoker. The summoning of demons has always been one of the most vile acts. Page 8 of the Book of Vile Darkness states that Consorting with Fiends is evil. The statement “Allowing a fiend to exist, let alone summoning one or helping one is clearly evil”. More minor sections deal with ‘casting evil spells’ and ‘damning or harming souls’, both of which are clearly present within the Pelor-sponsored malconvoker. One could very well suspect this path to be nothing more than a thinly disguised trap for the unwary and their souls.  

Also introduced into the Complete Scoundrel is the grey guard, which some may note “hey, that’s just a slightly lighter version of the blackguard!” Indeed. Another step into the Lower Planes, this one is aimed at paladins rather than wizards and clerics. While I have not been able to tie the grey guard directly to Pelor as of yet, it seems that the taint caused by his masquerade is growing to touch even the sincere good aligned gods.  

Looking at the relics that Pelor sponsors shows another side of this dark story. The dawnstar, if sundered or broken, deals massive damage to all other creatures (aside from the wielder) within a 30 foot radius. Clearly, this power was inserted with no thought given to the cost for the wielder’s allies. The original dawnstars were given to 4 solars who rescued one of Pelor’s paladins from Baator (Known as Perdition in some texts). A question arises then: what exactly was the paladin doing in Hell? If he had died and went to Hell, that suggests some oddity concerning his faith and alignment. If he ended in Hell due to his own dealings with the devils (which are endorsed by the Church of Pelor, don’t forget), then it seems that Pelor was flouting the Pact Primeval, an ancient law enacted before Pelor’s time. It seems that there are only a few possible answers. One, Pelor is truly of Hell, and his worshipper ended there because of his faith. Two, the paladin ended up in Hell of his own actions and Pelor gave no thought to the stability of the cosmos in order to bring him back. (Probably out of fear for what information torture would bring to the paladin’s tongue.) Three, Pelor sponsors LE paladins, known as paladins of tyranny (in a complete twisting of the term paladin) because he is a vile god of evil.  

The Inquisitor Bracers are another magic item sponsored by Pelor. These bracers justify the use of force on innocent people in order to sort them out from undead. You can’t use the power of the bracers with a touch attack (to see if the positive energy perhaps burns the undead). You must swing your weapon with all force at the target, and hope that the positive energy undoes any mistake you might make. What a sick idea. A paladin on a different world once had a similar idea for dealing with undead. His name was Prince Arthas.  

Pelor’s final relic is a sun shard, which is fairly simple, it fires searing light at two targets. This isn’t damning in and of itself, but consider that while other good gods (Elonna and Yondalla for example) offered relics that aided mortals, Pelor’s are all intended to destroy. This is of course, not a huge point against Pelor, but when added onto the mountain of evidence, seems to be just one more confirmation.  

One adventuring group, headed by a tough talking thug named Dyson, followed the path against Pelor when they discovered something amiss within his church. Connections were drawn between Pelor and Baal. That story can be told by Dyson himself or his dungeon master Feanor. It should be noted however, that they began following this path of discovery prior to the release of the Book of Exalted Deeds. They were the first to see the truth and were shunned for it at the time. Those of us who have had our eyes opened to the light of the Burning Hate owe them a debt of gratitude.  

Another adventuring group, this one composed of angels, were betrayed by their god into the hands of Lixer, Prince of Hell. They were broken, one by one. One was twisted into a demon, one lost faith in the path of the Celestial Compact, one was blasted from existence and the last was petrified and stands still in the Court of a Lord of Hell. The god was not named, but he was a god of the sun. Again, this story predates the release of the Book of Exalted Deeds. Ro3 (Ouroboros) was the one who revealed it to us.  

One final member of Dicefreaks has added information. Alratan was the first Freak to bring up evil uses for positive energy and good uses for negative energy. While his study does not accuse Pelor of anything (or indeed, deal with Pelor at all), it does point to an alternate path of positive energy, with which Pelor is definitely associated. (Positive energy, not the alternate path) This is important because many dubious (and some slack jawed) people have pointed towards Pelor’s association with the sun and positive energy as proof of his inherent goodness.  

It must be noted that nothing is proven. Pelor still sits in Elysium. No good aligned gods have moved against him, nor have they chilled alliances with the Sun God. It may be this is a smear campaign engineered by fiends, or simply the overactive imaginations of mortals. However, the above presented are facts, not fiction. Draw your own conclusions, but think twice before you choose the True Believer feat in Pelor’s name. Below are my own conclusions drawn from the evidence.  

Pelor is a Neutral (lawful tendancies) Evil god of Sun and Strength.  
Pelor is a god of skin cancer, sun burns, thirst and burning agony.  
Pelor hates undead as they cannot properly suffer in the same way as mortals.  
Pelor’s divine realm is on Elysium  
Pelor has deceived the good gods and mortals for so long that he has grown complacent in his position. The recent revelations are not purposeful, they are accidents caused by the god being sloppy.  
Pelor has many connections with Hell through both Baal and Belial and previously through Astarte.  
Pelor may have engineered the Great Fall of Eblis, Triel and the others.  
It is unknown if the devils, daemons or demons are aware that Pelor is evil. Presumably they are ignorant.  

The above is intended to make clear the position of those people who claim Pelor is evil. It is not intended as a slur on those who seek to worship Pelor as a benign deity nor as concrete proof of his evil. The investigation into his misconduct is currently ongoing and no final judgement should be passed at this juncture.

***

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.  

* * *