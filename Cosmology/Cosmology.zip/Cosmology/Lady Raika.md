# Lady Raika, Mistress of Storms (CR 41) 
**Demon Atrocity**  
**Virtual Sorcerer 20 / Virtual Bard 20 / Sublime Chord 10 / (Air) Elemental Savant 10**  
CE Medium Outsider [Chaotic, Evil, Extraplanar, Air]  
**Init +6; [b]Senses** Listen +70, Spot +70, darkvision 60ft  
**Aura** chaotic evil; **Languages** common, infernal, abyssal, celestial, auran, draconic, elven, dwarven  
_____________________________________________________________  

**AC** 52, touch 27, flat-footed 46 (10 +6 (dex) +6(profane) +17(nat) +8(armor) +5(deflection))  
**hp** 890 (40 outsider +10d6, +10d4 +660), fast heal 30, regeneration 10 (epic and axiomatic or spells with the Good or Lawful descriptor ); **DR** 30 / cold iron and good and epic  
**Immune** electricity, fire, poison, critical hits, stunning, flanking, sleep effects, paralysis,  
**Resist** acid 10, cold 10; **SR** 49 (SR + CR)  
**Fort** +43, **Ref** +40, **Will** +39  
_____________________________________________________________  

**Speed** 40ft. (8 squares), fly 220ft (perfect) (44 squares)  
**Melee** +66/+61/+56/+51 Rudra (+10 keen, ghost touch, anarchic, thundering and shocking burst scythe) (2d4 +19 +2d6 (lawful creatures only) +1d10 electricity +1d8 sonic 19-20/x4)  
**Ranged** +58 ranged and ranged touch spells.  
**Space** 5ft. (omit if 5 ft.); **Reach** 5ft. (omit if 5 ft.)  
**Base Atk** +50; **Grp** +56  
**Atk Options** spell-like abilties, spellcasting, melee attack, energy drain, song of cosmic fire (DC 37 ref), grapple.  
**Special Actions** bardic music, bardic lore, inspire courage +4, inspire competence, suggestion, inspire greatness, song of freedom, inspire heroics, mass suggestion, countersong, fascinate, song of arcane power, song of timelessness (DC 37 will), spell-like abilities, spellcasting.  
_____________________________________________________________  

**Sorcerer**  
**[Arcane] Spells Known** (CL 42nd)  
9th (9/day)— _wish, time stop, disjunction_  
8th (9/day)— _lightning ring, moment of prescience, discern location_  
7th (9/day)— _magnificient mansion, armor of bats*, solipsism_  
6th (9/day)— _acid fog**, chain lightning, legend lore, disintegrate_  
5th (10/day)— _cloudkill, major creation, shield of bats*, cyclonic blast_  
4th (10/day)— _dimensional anchor, orb of force, orb of electricity, assay spell resistance_  
3rd (10/day)— _aura of bats*, fireball**, lightning bolt, devil blight_  
2nd (10/day)— _blast of force, detect thoughts, gust of wind, scorching ray**, earthbind_  
1st (10/day)— _shield, obscuring mist, magic missile, ray of enfeeblement, ray of flame**_  
0th (6/day)— _caltrops, detect magic, read magic, amanuensis, arcane mark, acid splash, ray of frost, touch of fatigue, prestidigitation._  

**Bard**  
**[Arcane] Spells Known** (CL 44th)  
6th (7/day)— _analyse dweomer, project image, greater scrying, sympathetic vibration_  
5th (8/day)— _mirage arcana, body harmonic, dream, mind fog, mislead_  
4th (8/day)— _cacophony shield, cure critical wounds, detect scrying, modify memory, ray deflection_  
3rd (8/day)— _dirge of discord, infernal thredony, glibness, wounding whispers, creaking cacophony_  
2nd (8/day)— _calm emotions, delusions of grandeur, mindless rage, enthrall, know vulnerbilities_  
1st (8/day)— _distort speech, comprehend languages, ventriloquism, identify, insidious rhythm_  
0th (4/day)— _dancing lights, light, mending, ghost sound, know direction, message_  

**Sublime Chord**  
**[Arcane] Spells Known** (CL 44th)  
9th (5/day)— _meteor swarm**, effulgent epuration_  
8th (6/day)— _polar ray**, superior invisibility, lightning ring_  
7th (6/day)— _delayed blast fireball**, simulacrum, iron guard, hiss of sleep_  
6th (7/day)— _guards and wards, probe thoughts, opalescent glare, imperious glare_  
5th (9/day)— _passwall, shroud of flame, graymantle, wrack_  
4th (9/day)— _scrying, force missiles, sensory deprivation, translocation trick_  

**Spell-like Abilities** (CL 45th) at will – _blasphemy, dominate monster, greater dispel magic, planeshift, nondetection, greater invisilibity, see invisibility, telekinesis, unholy aura, firestorm**, implosion, detect good, detect thoughts, suggestion, greater teleport, disguise self, mind blank_  

*Indicates new spells, see below  
**Indicates spells where the elemental damage will be altered to electricity.  
_____________________________________________________________  

**Abilities** Str 22, Dex 26, Con 32, Int 24, Wis 24, Cha 44  
**SQ** air mastery, whirlwind, telepathy 100ft, true seeing, energy penetration +4, energy focus +2, song of arcane power, song of timelessness (DC 37 will), song of cosmic fire (DC 37 ref), bardic music 30/day, bardic lore, countersong, fascinate, inspire courage +4, inspire competence, suggestion, inspire greatness, song of freedom, inspire heroics, mass suggestion, darkvision 60ft, fast heal 30, regeneration 10 (epic and axiomatic or spells with the Good or Lawful descriptor), DR 30 (cold iron and good and epic), SR 59, tanari traits.  
**Feats** energy substitution (electricity), practised spellcaster x2 (bard and sorcerer), versatile performer, disguise spell, lingering song, subsonics, mobile spellcasting, quicken spell  
**Epic Feats** epic inspiration x2, group inspiration, lasting inspiration inspire excellence, music of the gods, rapid inspiration, automatic quicken spell x3, multispell.  
**Skills** Bluff +80, Concentration +74, Sense Motive +70, Spot +70, Listen +70, Perform (singing) +80, Perform (lute) +80, Perform (dance) +80, Perform (acting) +80, Spellcraft +71, Knowledge (arcane) +71, Knowledge (religion) +38, Knowledge (the Planes) +38, Knowledge (nature) +28, Diplomacy +80, Intimidate +80, Diguise +80  
**Possessions** _Rudra, bracelets of armor +8, ring of protection +5_  
_____________________________________________________________  

**Organization** Solitary or with Storm Sisters  
**Environment** Abyss  
**Advancement** By character class / hd  
_____________________________________________________________  

**Rudra – Major Artifact:** A gift from the Queen of Succubus Malcanthet, Rudra was originally an exquisitely crafted lute which is long, angular and sharp looking that is a scythe in disguise, where the blade snaps out when swung out to attack. After delivering a killing blow to a storm elemental in an attempt to collect its essence to further augment her power, the essence was trapped in the weapon instead and Raika’s blood bleeding from the blasted wounds somehow activated that essence and bound it into the weapon.  

Rudra strikes as a +10 keen, ghost touch, anarchic, thundering and scythe that functions as a masterwork lute that confers +5 competence bonus to her perform checks when using it as well as increasing her bardic music attempts per day by 5\. Raika can also recall this weapon into her hands as a free action as long as it is on the same plane of existence as her.  

**Warp – Ability score adjustment (Ex):** Raika has traded 12 Str points for 6 Cha points.  

**Warp - Energy Drain (Su):** Raika’s vorpal sword ability is exchanged for a succubus ‘s energy drain ability.  

**Warp - _Tongues_** _(Su):_ Raika’s entangle ability is exchanged for a succubus’s tongues ability.  

**Warp - Surged (Ex):** Raika’s flaming body ability is exchanged for an arcane ooze’s acid ability elementally changed to electricity, this bonus damage is applied to manufactured weapons as well as though it is a shocking burst weapon.  

**Warp - Electrical and Sonic Healing (Ex):** Raika’s death throes ability is exchanged for a storm elemental’s ability of the above name and nature.  

**Warp - Medium size (Ex):** Raika’s size has been reduced to medium.  

**Ravage - Virtual Class Level (Ex/Vile):** Lady Raika is treated as if she possess 20 levels of Bard  

**Ravage - Virtual Class Level (Ex/Vile):** Lady Raika is treated as if she possess 20 levels of Sorcerer.  

**Ravage – High Voltage (Su/Vile):** All electricity damage Raika deals bypasses resistance to electricity as if affected target does not have any electricity resistance at all. Creatures immune to electricity take half damage from any electricity damage done by Raika. Any elemental damage dealt by Raika becomes electrical regardless of source.  

**Ravage – Sonic Boom (Su/Cosmic):** All Raika’s spells, spell-like abilities and abilities that deal electricity damage are constantly admixtured with sonic energy.  

**Ravage – Corrupt Storm (Su/Cosmic):** All Raika’s spells, spell-like abilities and abilities that are affected by High Voltage are constantly affected by Corrupt spell or Corrupt spell-like ability or the like.  

**Ravage – Fast Healing (Ex/Cosmic):** Raika gains fast healing 30.  

**Ravage – Regeneration (Ex/Cosmic):** Raika gains regeneration 10 that is bypassed by epic and axiomatic, , or spells with the Good or Lawful descriptor.  

**Ravage – Profane AC Bonus (Ex/Cosmic):** Raika gains a +6 profane bonus to AC  

**Ravage – Charisma Boost (Ex/Abhorrent):** Raika gains +4 increase to her Charisma score.  

**Ravage – Improved Movement Speed (ex/Cosmic):** Raika’s fly speed gains 120ft.  

_____________________________________________________________  

**Aura of Bats**  
Conjuration (Summoning)  
**Level:** Sorc/Wis 3  
**Components:** V, S, M  
**Casting Time:** 1 swift action  
**Range:** Personal  
**Effect:** A swarm of bats circling you closely.  
**Duration:** 10 min/level or until discharged  
**Saving Throw:** None (harmless)  
**Spell Resistance:** None (harmless  

A swarm of bats emerge out of nowhere and swirl around you in a tight spiral, forming a barely seen sphere of flying objects. This spell is created by Lady Raika, whom despite her title as Lady of Storms, holds bats as her animal totem. This swarm of bats provides half-cover for the caster without hindering the movement or sight of the caster. Any attacks or abilities on the caster or the bats will not drive the bats away, if any bats die, more will appear to replace those lost.  
_Material Component:_ Bat guano  

**Shield of Bats**  
Conjuration (Summoning)  
**Level:** Sorc/ Wis 5  
**Components:** V, S, M  
**Casting Time:** 1 immediate action  
**Range:** Personal  
**Effect:** A dense concentration of bats in one direction  
**Duration:** Instantaneous  
**Saving Throw:** None (harmless)  
**Spell Resistance:** None (harmless)  

A swarm of bats emerge out of nowhere and swirl before you as an attack approaches. The swarm of bats take the full brunt of the attack as they dissipate. This spell is meant as a neat survival trick against what might be a devastating blow, by sacrificing a swarm of bats as a shield, the caster escapes unscathed from that attack.  
This spell allows you to evoke a dense pack of bats before you as a reaction to an attack against you. This shield lasts just long enough to disrupt your foe’s line of effect towards you, providing you with total cover against a single attack with a weapon, spell, or psionic power, or spell-like or supernatural ability. Your foe’s first attack in this round can be made but on a hit, the damage is instead soaked up by the bats instead, dealing no damage at all to the caster, though the foe could decide to take any other action, including choosing to attack one of your allies instead, or take a full attack action that grants him additional melee attacks against you in this round (if your foe is able to execute a full attack action). The bats scatter and dissipate an instant later.  
Your foe could choose to attack the area in which you have taken cover with an area attack (such as a _fireball_ spell). In this case, you gain +8 bonus to AC (if applicable) and a +4 bonus on Reflex saves.  
_Special:_ If you have Aura of Bats spell active when you cast this, you may choose to immediately expend the rest of Aura of Bats’ duration and cast Shield of Bats as a free action as a reaction to a second attack with a weapon, spell, or psionic power, or spell-like or supernatural abilities.  
_Material Components:_ A tiny carving of a bat  

**Armor of Bats**  
Conjuration (Summoning)  
**Level:** Sorc/Wiz 7  
**Components:** V, S  
**Casting Time:** 1 standard action  
**Range:** Personal  
**Effect:** A dense swarm of bats swirling around caster.  
**Duration:** 10 min/level or until discharged  
**Saving Throw:** None (harmless)  
**Spell Resistance:** None (harmless)  

A swarm of bats swirl around you, actively shielding you from blows and spells by sacrificing their lives.  
The caster gains resistance to blows, cuts, slashes, stabs other damaging effects. The caster gains damage resistance 5/adamantine and ignores the first 50 points of damage from each attack, spell, psionic power, spell-like or supernatural ability directed towards the caster. Once the spell has negated an amount of damage equal to 10 points of damage per caster level (maximum 200 damage), the spell is discharged. Damage that goes past the damage reduction and damage negation which reaches the caster is still subject to the caster’s damage reduction or regeneration as per normal.  
_Special:_ If Aura of Bats spell is active during the casting of this spell, the caster may elect to immediately expend the rest of Aura of Bats’ duration to increase the maximum damage the Armor of Bats can absorb to 300 damage.  

_____________________________________________________________  

Annex A:  
-40 HD (CR 30)  
-Balor as the foundation, Warped to emulate a succubus, retaining however its ability scores as well as spell-like abilities as well as its constant _true seeing_  
-Virtual class levels ravage for bard and sorcerer begins here.  
-Traded 12 Str points for 6 Cha points  
-One ability point for Dex and Con respectively, the rest are into Cha  
-Ravage obtained : Fast Healing, Virtual Class Level (Bard / Sorc)  

Annex B:  
-49 HD (CR 35)  
-9 levels of (Air) Elemental Savant  
-Warp obtained : Surged (acid substituted to electricity, arcane ooze acid ability base), Ability Adjustment, [i[tongues[/i], Energy Drain.  
-Ravage obtained : High Voltage, Sonic Boom, Regeneration  

Annex C:  
-54 HD (CR 38)  
-10 levels of (Air) Elemental Savant  
-2 levels of Sublime Chord  
-Obtained Rudra  
-Warp obtained : Electrical and Sonic Healing  
-Ravage obtained : Corrupt Storm  

Annex D:  
-60 HD (CR 41)  
-10 levels of Sublime Chord  
-Ravage obtained : Profane AC bonus, Charisma Boost, Improved Movement Speed  

* * *

**Appearance:**  
The elegant and alluring figure before you sports silky long raven black hair with lightning blue fringes and highlights. Her long hair flows down to her perfectly shaped bosom which is barely covered by a dark sapphire blue shawl draped from her shoulders down, its sheer fabric barely covering her chest, while exposing her midriff. A black skirt with stripes of electric blue wraps around her tiny waist down to the ground, exposing her calves and shoeless feet at the front as it trails the ground.  

Her eyes glow midnight blue as she regards you, her full cherry red lips smiles to reveal a roll of pearl white teeth.  

On both her delicate wrists she wears simple silver bracelets while her right hand wears a plain silver ring. Carried on her left hand is a lute of exquisite design. The extra long neck is seemingly made from magically hardened sapphire with quartz crystals as its frets, and so is the angular bowl which fans outwards into an asymmetrical layout with one left side slightly fuller to allow the wrists to rest during play while the other side is caved in and sports a curved blade-like object that goes over the caved in portion.  

Suddenly in a clap of thunder, the shawl fades away as the black skirt unfurls into wings, her hair swept back by an unseen wind as her naked form reveals subtle bluish veins under that porcelain skin. She readies the lute in a playing position as bats start to swirl around her. With a smile, she strums the lute hard once and swings her arm towards you, a bolt of crackling dark blue lightning pierces through you as the shrill cries of the bats accompany the lady’s electrified laughter.  

**History:**  
Raika was an exceptional succubus with a dark taste for music and storms (Annex A), often singing out to a thunderstorm while playing on her lute when she is not out seducing mortals to their doom. One of the close aides of the Queen of Succubus, Malcanthet, Raika was afforded great respect amongst other sisters. And near the height of her power, she developed a powerful skill of magic and proceeded to harness the power of thunder and lightning as her totem as she resumes her normal duties. Known as a great beauty even amongst a crowd of alluring creatures, she has had offers of being a consort under Graz'zt and other powerful beings in exchange for her skills in the art of pleasure, but remaining loyal to her queen, Raika made enemies by rejecting those offers.  

Shortly before she has mastered the elemental force of air (Annex /cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, a strike force of adventurers launched a ferocious assault on her during her return to the prime material plane. Brutally assaulted and wounded she was torn apart by devastating bolts of lightning which she herself tried to master as her soul was forcefully sent back to the Abyss. In the roiling chaos, her rage against her defeat pounded at the roiling energies of the Abyss, swearing dark vengeance and a renewed effort to master the very energies that sent her back in agony and defeat. It seems that the Abyss has heard her, and molded its energies into her, changing her and evolving her.  

After her reformation she returned to Malcanthet’s realm in determination, recognizing the signs about her, Malcanthet’s mind whirled into new schemes as she presented one of her masterpiece instruments to Raika, which will then be called Rudra after she had slain a primal storm elemental in an attempt to harness its essence to further augment her powers. (Annex C)  

Her own investigations on the group of adventurers revealed that Malcanthet and Graz'zt had vested interests in that prime, and mainly centered around the heir of the most powerful kingdom on the prime, and the adventurers were sent to get rid of her. Using her formidable reputation yet untainted in these lands (because she is a master of many identities), she arranges a massive concert where through invitation, all important pawns in Graz'zt’s camp assemble where Raika unleashed a hell of lightning and thunder with her newly developed powers, breaking the power base of her patron’s rival permanently. (Annex D)  

Such an act has earned her notoriety as well as the begrudging respect of her rivals, whose misconception of succubus being wily cowards was shattered miserably. Till date she still serves Malcanthet and has formed a small musical group called the Storm Sisters whose members comprise of musically talented succubi.  

**Nature:**  
With the fury of thunder and lightning tainted with the will of the Abyss as her totem, and a love, which some say is a fetish, for bats, Raika is as capricious as the lot of succubi scattered throughout the cosmos. Yet this caprice is tempered by wisdom, experience and prudence.  

Hiding behind an elaborate web of social intrigue where all tactics are fair game and all avenues of weaknesses are exploited, Raika has not abandoned her usual modus operandi of deceit, corruption and defilement. Yet throughout this, the foreboding sense of a lingering storm is not far away. Far from a quiet finale, Raika begins to gain a liking for each grand finale orchestrated to feel like a bolt from the blue, the sudden thunderstorm that strikes with such fury that it blinds and stuns. Yet this obsession clouds not her judgement nor dampened her willingness to take risks, if nothing, her defeat has taught to no longer hold back if any threat even seemed real enough, and being thorough in her methodology earns her not only the enmity of powers, but also the wary respect they afford her with, no matter how little.  

**Organisation:**  
Besides serving as Malcanthet’s loyal follower, Raika has shown and is given considerable leeway to take liberties to set up her powerbase, but knowing fully well the price for even suspected betrayal, has never even attempted to step out of line at all. The Storm Sisters, a coven of bardic witches who use their charms, wiles and musical ability to bewitch, manipulate and control events across the cosmos. Trained in the deadly grace of lightning, the Storm Sisters became an auxiliary powerbase upon which Raika controls, but Malcanthet taps into.  

Besides leading the Storm Sisters, Raika could probably be noted as one of the more powerful allies and subordinate that Malcanthet has, and Malcanthet values her assistance and power and has many times reached a level of relationship with Raika that some would consider to be on a perverse level.  

**Relations to other powers:**  
No doubt that Raika is one of Malcanthet’s lovers and subordinate. Where the rest of the Abyss is concerned, there is nothing but hostility. Amongst the powers to be feared, Graz'zt is perhaps the one that would truly be the greatest threat to her, and no doubt Raika knows it. Still she defiantly schemes and destroys his plans from time to time, confident that even if her patron will not back her up, she will still not go down in a fight.  

Beyond the Abyss, the Lady of Storms has plenty of enemies, particularly amongst nature deities for her adoption of a totem based on Nature’s fiercest weapons and twisting them as well as deities of love, family and friendship for her tainted intrusion upon their sacred institutions, trampling them like weed. Prominent deities who wish nothing but her permanent demise includes Talos, Chauntea, Sune, Obad Hai and many others. It is also speculated that Raika has offended the deities of music and the arts for despoiling the value of entertainment into a tool for manipulation and evil.  

Perhaps her greatest rival would be Lilith herself. Lacking in power to take down one who almost had complete power over Nature, Raika relishes the day where she can fully absorb the fury of Nature’s storms into her being, and watch with pleasure as Lilith gets torn apart by the very forces that she seeks to dominate. Till this end she contemplates deicide as one of her plans to wrest more power over Nature.  

***

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *