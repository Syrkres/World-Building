# Panzuriel
_The Down-dragger, Whisperer of the Depths_  
**Intermediate Deity**  
**Symbol:** Left footprint  

**Home Plane:** Rezuriel, Niflheim (Second Gloom of the Grey Wastes of Despair)  
**Alignment:** Neutral evil  
**Portfolio:** Murder, confusion, subversion  
**Worshipers:** Krakens, merrow, scrag, kapoacinth  

**Cleric Alignments:** NE, CE  
**Domains:** Destruction, Evil, War, Water  
**Favored Weapon:** quarterstaff  

**Panzuriel  
Hexblade 20/Illusionist 20/Druid 20  

Medium Outsider (evil, extraplanar, water)  
Divine Rank:** 13  
**Hit Dice:** 3d8 (outsider) plus 20d10 (hexblade) plus 20d4 (illusionist) plus 20d8 (druid) plus 840 (1304 hp)  
**Initiative:** +21 (+13 Dex, +8 Superior Initiative* always goes first)  
**Speed:** 60 ft., swim 60 ft.  

**Armor Class:** 77 (+13 Dex, +28 natural, +13 divine, +13 deflection), touch 49, flat-footed 64  
**Base Attack/Grapple:** +41/+54  
**Attack:** +88 melee _Vengeance_ (+92 against good outsiders) or _Crystal Foot_ +84 melee or +53 melee touch or +53 ranged touch  

**Full Attack:** +88/+83/+78/+73 melee _Vengeance_ (+92/+87/+82/+77 against good outsiders) (1d4 plus +1d6 (lightning) plus +1 (vile) plus +4d6 against good outsiders and Fort save DC 36 or die plus +18/19-20/x2 plus +1d10 (lightning) and good outsiders Fort save DC 27 or die) or _Crystal Foot_ +84 melee (1d4 plus +3d6 (unholy) plus 1 negative level (Fort save DC 23) and Fort save DC 36 or die and Will save DC 47 or deluded as _mirage arcana_ plus +17/20/x2 plus +6d6 (unholy) plus 2 negative levels (Fort save DC 23)) or +53 melee touch or +53 ranged touch  
**Space/Reach:** 5 ft./5 ft.  

**Special Attacks:** aura of unluck, dire hexblade’s curse, salient divine abilities, spells, spell-like abilities  
**Special Qualities:** animal companion, a thousand faces, arcane resistance, darkvision 60 ft., divine aura (1300 feet, DC 36), divine immunities, DR 20/epic and adamantine, godly realm (10 miles outer plane, 1300 ft. Material Plane), greater teleport at will, mettle, nature sense, plane shift at will, remote communication, resistance (acid) 18, speak, and read all languages and speak directly to all beings with 13 miles, SR 76, timeless body, wild shape 6/day (medium to gargantuan sized), huge elemental 3/day, trackless step, venom immunity, wild empathy, woodland stride  
**Saves:** Fort +60 Ref +53 Will +53  
**Abilities:** Str 36, Dex 37, Con 38, Int 39, Wis 35, Cha 37  

**Skills:** Appraise (weapons) +56, Bluff +83, Concentration +87, Craft (weaponsmithing) +77, Decipher Script +72, Diplomacy +91, Disguise +52 (+58 observed in character), Escape Artist +41, Gather Information +37, Handle Animal +61, Hide +55, Intimidate +83, Knowledge (arcana) +93, Knowledge (local-Niflheim +39), Knowledge (nature) +99, Knowledge (the planes) +87, Knowledge (religion) +84, Listen +83, Move Silently +46, Search +48, Sense Motive +50, Spellcraft +99, Spot +69, Survival +86 (+88 find/follow tracks, +90 extraplanar), Swim +76  
**Feats:** Empower Spell, Enlarge Spell (/cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, Eschew Material Components, Extend Spell (/cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, Greater Spell Focus (Illusions), Greater Spell Penetration (/cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, Heighten Spell, Improved Critical (quarterstaff), Improved Initiative, Natural Spell, Persistent Spell, Quicken Spell, Spell Focus (Illusions), Spell Penetration (/cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, Scribe Scroll (/cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, Silent Spell (/cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, Vile Martial Strike (quarterstaff), Violate Spell (/cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, Weapon Focus (quarterstaff) (free)  
**Epic Feats:** Automatic Vile Spell(x3), Epic Spellcasting, Epic Weapon Focus (quarterstaff), Gargantuan Wild Shape, Ignore Material Components, Improved Heighten Spell, Magical Beast Wild Shape, Superior Initiative, Vile Deathstrike  
**Environment:** Rezuriel (Niflheim, Second Gloom of the Grey Wastes of Despair)  
**Organization:** Panzuriel and Awakened Animal Companion or Troupe (Panzuriel and Awakened Animal Companion and 4-6 Kraken)  

**Challenge Rating:** 56  
**Treasure:** _Vengeance_, _Crystal Foot_  
**Alignment:** Neutral Evil  
**Advancement:** --  

**Level Adjustment:** –  

**Alter Reality:**  
- Panzuriel can use the _wish_ spell with regard to his portfolio, save for the replication of other spells. This ability costs Panzuriel no XP, and requires a standard action to implement.  
- 13/day Panzuriel may add +14 to his effective caster level.  

- 13/day Panzuriel may add +13 to his damage rolls for 1 round.  
- 13/day Panzuriel may add +13 to his Fort or Will saves.  
- Panzuriel may alter his size between Tiny and Gargantuan.  
**- Divine Immunities:** Ability damage, ability drain, acid, cold, death effects, disease, disintegration, energy drain, mind-affecting effects, paralysis, poison, sleep, sonic, stunning, transmutation, imprisonment, banishment.  
**- Divine Power:** Panzuriel is a living embodiment of power, and ancient divine magic flows through his veins. As such, mortal items are of virtually no use to him, being so much weaker than his own innate powers. Panzuriel gains no benefit from a deflection, enhancement, resistance, insight, sacred or profane bonus that is less than +13\. Note that this only applies to bonuses that affect Panzuriel himself; weaponry and armor is unaffected by this.  
**-Domain Powers:** Casts evil spells at +1 level; may smite 1/day with +4 bonus to the attack roll and +6 to damage; may rebuke fire creatures/command water creatures as an evil cleric 16/day; gains Weapon Focus (quarterstaff) as a free feat.  

**- Salient Divine Abilities:** Annihilating Strike, Automatic Metamagic (Silent Spell), Benthic (Unique Salient Divine Ability), Call Creatures (squid), Control Creatures (squid), Divine Blast (16/day, 13 miles, 26d12 divine damage), Divine Inspiration, Divine Spell Focus (Illusion), Divine Spellcasting, Divine Water Mastery, Lay Curse, Mud Storm (Unique Salient Divine Ability), Power of Nature, Speak With Creatures (squid), Supreme Initiative, Sink (Unique Salient Divine Ability)  
**- Spell-Like Abilities:** At will: _acid fog, acid strike,_ (as flame strike), _blade barrier, blasphemy, cone of cold, contagion, control water, create undead, desecrate, disintegrate, dispel good, divine power, earthquake, elemental swarm_ (water elementals only), _fog cloud, horrid wilting, ice storm, implosion, inflict critical wounds, inflict light wounds, inflict light wounds_ (mass), _harm, magic circle against good, magic vestment, magic weapon, obscuring mist, power word_ (blind), _power word_ (kill), _power word_ (stun), _protection from good, shatter, spiritual weapon, summon monster IX_ (evil creatures only), _unholy aura, unholy blight, water breathing._ 1/day: _summon nature’s ally VI._ Panzuriel uses these abilities as a 76th level caster, except for evil spells, which he uses as a 77th-level caster. The save DCs are 48 + spell level.  

**Benthic (Unique Salient Divine Ability):** Panzuriel recieves a +13 profane bonus to his AC and attacks as long as some part of his form is touching the floor of whatever body of water he is currently located in. However, if he is removed forcibly from the sea floor, then he takes a penalty to his AC and attacks which starts at –2 and which increases each round by –2 until he is penalized by a maximum of –13 to his AC and attacks. Should Panzuriel be weakened to this point, he additionally takes 7d6 points of damage/round until he touches the sea floor again.  

**Mud Storm (Unique Salient Divine Ability):** Panzuriel may command the muck and silt at the bottom of the ocean to rise in a torrent even while freezing the life out of those caught within it’s grasp. Creatures caught within Panzuriel’s Mud Storm take 13d8 cold damage/round they are caught within it, and are unable to see anything as a result.  

**Sink (Unique Salient Divine Ability):** Any nautical vessel within Panzuriel’s sensory range he may choose to capsize. Vessels so affected take 7d6 points of damage to their hulls, which begin to crumble. This damage bypasses hardness and is applied directly to the material involved.  

Panzuriel may also use this same Salient Divine Ability in order to sink any sentient creature within his sensory range as well. Potential victims must make a Fort save DC 55 or else completely lose their buoyancy and sink to the bottom of the ocean. Victims of this use of the power may teleport onto dry land in order to escape it’s effects, but this does not actually remove the effect and they will still continue to sink in any body of water sufficiently deep. If potential victims of this power are using magical means to swim (such as through _shapechange_ spells or wild shaping), they are still affected by this particular power.  

**-Possessions:** Where Panzuriel’s left foot was sliced off during the battle with Deep Sashelas that forced him back to the Grey Wastes, he has reattached an item of his own creation called the _Crystal Foot_. Once a round he may kick with his foot as an unarmed strike, and the _Crystal Foot_ is treated as a +4 unholy power weapon for the purposes of damage. Anyone struck by the _Crystal Foot_ must also make a Will save DC 47 or else be affected as the spell _mirage arcana_ and become unable to discern their exact location (cast at 34th level). Panzuriel’s _Crystal Foot_ additionally grants Panzuriel the ability to attack with it as if he possessed the Improved Unarmed Strike feat, doing lethal damage.  

Panzuriel also wields _Vengeance_. It is a +5 shocking burst quarterstaff of good outsider dread which was made for him by a powerful mage enslaved by some of his powerful worshippers on one of the Prime Material Planes that his cults have spread to after his initial defeat.  

**Other Divine Powers:**  
- As an intermediate deity, Panzuriel may take 10 on any check, provided he needs to make a check at all. He is immortal.  
**- Senses:** Panzuriel can see (using normal vision or low-light vision), hear, touch, and smell at a distance of 13 miles. As a standard action, he can perceive anything within 13 miles of his worshipers, holy sites, objects, or any location where one of his titles or name was spoken in the last hour. He can extend his senses to up to five locations at once. He can block the sensing power of deities of his rank or lower at up to two remote locations at once for 8 hours.  

**- Portfolio Sense:** Panzuriel senses any act of murder or attempt to subvert established order if it takes place on a body of water, or concerns any of the beings which worship him.  
**- Automatic Actions:** Panzuriel can use Intimidate as a free action if the DC for the task is 25 or lower. He can perform up to five such free actions each round.  
**- Create Magic Items:** Panzuriel can create any kind of magic item worth less than 200,000 gp if it can be used to incite or participate in murder, cause confusion, or subvert any kind of order.  

**Illusionist Spells (0th-14th level) (Sp): 4/8/8/7/7/7/7/6/6/6/3/2/2/2/2**. Panzuriel casts his Illusionist spells at 20th level and at 24th level for the purposes of penetrating spell resistance. Saving throws against Panzuriel’s spells is DC 38 + spell level, except for Illusionary spells which have saving throw DC’s of 44 + spell level. The saving throw DC’s are intelligence-based. Panzuriel’s prohibited school is Transmutation, and all of his spells are silenced.  

**Druid Spells (0th-12th level) (Sp): 6/8/8/8/8/7/6/6/6/5/2/2/2** Panzuriel casts his Druid spells at 20th level and at 24th level for the purposes of penetrating spell resistance. Saving throws against Panzuriel’s Druid spells is DC 34 + spell level. Panzuriel may cast nine epic spells per day with a maximal Spellcraft DC of 109\. Epic spells known: _cloak of deception, greater ruin, horror of the deep, momento mori, peripety, pestilence, rain of acid_ (as rain of fire), _soul dominion, spawn of Panzuriel_  

**Hexblade Spells (1st-4th level) (Sp): 7/6/6/6** Panzuriel casts his Hexblade spells at 20th level and at 24th level for the purposes of penetrating spell resistance. Saving throws against his Hexblade spells are DC 36 + spell level. The saving throw DC’s are Charisma-based. **Spells Known:** 1st level: _charm person, disguise self, hideous laughter, identify, undetectable alignment._ 2nd level: _blindness/deafness, bull’s strength, mirror image, rage, touch of idiocy._ 3rd level: _charm monster, confusion, dispel magic, poison, vampiric touch_ 4th level: _baleful polymorph, cursed blade, detect scrying, dimension door, enervation._  

**Arcane Resistance (Su):** Panzuriel has a +13 bonus on his saving throws against spells and spell-like effects.  

**Dire Hexblade’s Curse (Su):** Four times a day Panzuriel can unleash a curse upon a foe. The target must be visible to him and within 60 ft. The target of the curse suffers a –6 penalty on attacks, saves, skill checks, ability checks, and weapon damage for 1 hour afterwards unless they succeed at a Will save DC 28.  

**Mettle (Ex):** If Panzuriel makes a successful Will or Fort save against an attack that would normally have a lesser effect on a successful save, he instead completely negates the effect. If he is asleep or unconscious he does not benefit from mettle.  

**Aura of Unluck (Su):** Three times a day Panzuriel can create a baleful aura of misfortune. Any melee or ranged attack made against him while this ability is active has a 20% miss chance. Activating the aura is a free action, and the aura lasts for 19 rounds.  

**Animal Companion (Awakened Giant Squid)  
Gargantuan Magical Beast  
Hit Dice:** 24d8 plus +222 (318 hp)  

**Initiative:** +13 (+9 Dex, +4 Improved Initiative)  
**Speed:** swim 80 ft.  
**Armor Class:** 34 (-4 size, +6 Dex, +22 natural), touch 12, flat-footed 25  
**Base Attack/Grapple:** +15/+46  
**Attack:** 10 tentacles +27 melee and bite +23 melee.  

**Full Attack:** 10 tentacles +27 (3d6 plus +15 plus +1 (vile)/19-20/x2 plus +2 (vile)) and bite +23 (4d8 plus +7)  
**Space/Reach:** 25 ft./25 ft. (40 ft. with tentacles)  
**Special Attacks:** constrict 1d6+8, improved grab  
**Special Qualities:** bonus tricks (7), darkvision 60 ft., devotion, DR 10/magic, evasion, improved evasion, ink cloud, jet, link, low-light vision, share spells  

**Saves:** Fort +26 Ref +20 Will +16  
**Abilities:** Str 36, Dex 29, Con 29, Int 18, Wis 20, Cha 27  
**Skills:** Listen +10, Spot +11, Swim +16  
**Feats:** Alertness, Diehard, Endurance, Improved Critical (tentacle), Improved Initiative, Improved Natural Attack (tentacles), Multiattack (/cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, Toughness (2), Vile Natural Attack (tentacle)  
**Environment**: Rezuriel, Niflheim  

**Organization:** Always found with Panzuriel  
**Challenge Rating:** 15  
**Treasure:** N/A  
**Alignment:** Neutral evil  

**Advancement:** --  
**Level Adjustment:** –  

**Avatars:**  
Avatars of Panzuriel appear as deceptively frail-looking, elderly males with a bizarre combination of triton and human features, such as silver and green scales, and a set of gills on his neck which regularly exhale black water. In whichever form an Avatar of Panzuriel appears in they will always lack a left foot and instead have it replaced with the prosthetic/wondrous item the _Crystal Foot_ as described earlier. Panzuriel will only send an Avatar as an absolute last resort in order to deal with potential threats to his cults, such as interference from the servants of either Neptune or Deep Sashelas.  

**Panzuriel’s Avatar  
Hexblade 10/Illusionist 10/Druid 10  
Medium Outsider (evil, extraplanar)  
Divine Rank:** 0  
**Hit Dice:** 3d8 (outsider) plus 10d10 (hexblade) plus 10d4 (illusionist) plus 10d8 (druid) plus 297 (541 hp)  

**Initiative:** +17 (+9 Dex, +8 Superior Initiative)  
**Speed:** 60 ft. (12 squares)  
**Armor Class:** 42 (+15 natural, +9 Dex, +8 deflection), touch 27, flat-footed 33  
**Base Attack/Grapple:** +22/+31  
**Attack:** +39 _Vengeance_ or _Crystal Foot_ or +31 melee touch or +31 ranged touch  

**Full Attack:** +39/+34/+29/+24 (+43/+38/+33/+27 against good outsiders) melee _Vengeance_ (1d4 plus +1d6 (lightning) plus 4d6 against good outsiders plus +1 (vile) plus +14/19-20/x2 plus +1d10 (lightning) and good outsiders Fort save DC 27 or die) or +35 melee _Crystal Foot_ (1d4 plus +3d6 (unholy) plus 1 negative level (Fort save DC 23) plus +13 and Will save DC 47 or deluded as _mirage arcana_/20/x2 plus +6d6 (unholy) plus 2 negative levels (Fort save DC 23)) or +31 melee touch or +31 ranged touch  
**Space/Reach:** 5 ft./5 ft.  

**Special Attacks:** domain powers, salient divine abilities, spells, spell-like abilities  
**Special Qualities:** animal companion, divine aura (1300 feet, DC 19), divine immunities, DR 10/epic, greater teleport at will, nature sense, plane shift at will, resistance (electricity) 5, SR 48, resist nature’s lure, trackless step, venom immunity, wild empathy, wild shape (plant and tiny to huge 4/day), woodland stride  
**Saves:** Fort +26 Ref +20 Will +16  
**Abilities:** Str 29 Dex 28 Con 29 Int 31 Wis 28 Cha 29  
**Skills:** Appraise (weapons) +18, Bluff +27, Concentration +30, Craft (weaponsmithing) +30, Decipher Script +25, Diplomacy +35, Disguise +15, Escape Artist +17, Gather Information +14, Handle Animal +20, Hide +26, Intimidate +31, Knowledge (arcana) +46, Knowledge (local-Niflheim +16), Knowledge (nature) +47, Knowledge (the planes) +35, Knowledge (religion) +28, Listen +28, Move Silently +12, Search +21, Sense Motive +21, Spellcraft +50, Spot +16, Survival +42 (+44 find/follow tracks, +46 extraplanar), Swim +25  

**Feats:** Empower Spell, Enlarge Spell (/cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, Eschew Material Components, Greater Spell Penetration (/cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, Heighten Spell, Improved Critical (quarterstaff), Improved Initiative, Natural Spell, Scribe Scroll (/cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, Spell Focus (Illusions), Spell Penetration (/cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, Vile Martial Strike (quarterstaff), Violate Spell (/cool.gif"" style=""vertical-align:middle"" emoid=""B)"" border=""0"" alt=""cool.gif"" />, Weapon Focus (quarterstaff)  
**Epic Feats:** Epic Weapon Focus (quarterstaff), Superior Initiative, Vile Deathstrike  
**Environment**: Any aquatic  
**Organization:** Solitary (unique)  
**Challenge Rating:** 30  

**Treasure:** _Crystal Foot_, _Vengeance_  
**Alignment:** Neutral evil  
**Advancement:** --  
**Level Adjustment:** –  

**- Divine Immunities:** Ability damage, ability drain, mind-affecting effects.  
**- Domain Powers:** Casts evil spells at +1 level; may smite 1/day with +4 bonus to the attack roll and +6 to damage; may rebuke fire creatures/command water creatures as an evil cleric 16/day; gains Weapon Focus (quarterstaff) as a free feat.  
**- Salient Divine Abilities:** Benthic, Divine Water Mastery, Power of Nature  
**- Spell-Like Abilities:** 3/day: _acid fog, acid strike_ (as flame strike), _blade barrier, blasphemy, cone of cold, contagion, control water, create undead, desecrate, disintegrate, dispel good, divine power, earthquake, elemental swarm_ (water elementals only), _fog cloud, horrid wilting, ice storm, implosion, inflict critical wounds, inflict light wounds, inflict light wounds_ (mass), _harm, magic circle against good, magic vestment, magic weapon, obscuring mist, power word_ (blind), _power word_ (kill), _power word_ (stun), _protection from good, shatter, spiritual weapon, summon monster IX_ (evil creatures only), _unholy aura, unholy blight, water breathing._ 1/day: _summon nature’s ally VI._ Panzuriel’s Avatar uses these abilities as a 33rd level caster, except for evil spells, which he uses as a 34th-level caster. The save DCs are 19 + spell level.  

**Illusionist Spells (0th-5th level) (Sp): 4/7/7/5/5/4**. Panzuriel’s Avatar casts his Illusionist spells at 10th level and at 14th level for the purposes of penetrating spell resistance. Saving throws against Panzuriel’s spells is DC 20 + spell level. The saving throw DC’s are intelligence-based. Panzuriel’s Avatar’s prohibited school is Transmutation.  

**Druid Spells (0th-5th level) (Sp): 6/7/6/5/5/4** Panzuriel ‘s Avatar casts his Druid spells at 10th level and at 14th level for the purposes of penetrating spell resistance. Saving throws against Panzuriel’s Druid spells is DC 19 + spell level.  

**Hexblade Spells (1st-2nd level) (Sp): 4/3** Panzuriel’s Avatar casts his Hexblade spells at 10th level and at 14th level for the purposes of penetrating spell resistance. Saving throws against his Hexblade spells are DC 19 + spell level. The saving throw DC’s are Charisma-based. **Spells Known:** 1st level: _charm person, disguise self, hideous laughter, undetectable alignment._ 2nd level: _blindness/deafness, mirror image, touch of idiocy._  

**Arcane Resistance (Su):** Panzuriel’s Avatar has a +9 bonus on his saving throws against spells and spell-like effects.  

**Greater Hexblade’s Curse (Su):** Four times a day Panzuriel’s Avatar can unleash a curse upon a foe. The target must be visible to him and within 60 ft. The target of the curse suffers a –4 penalty on attacks, saves, skill checks, ability checks, and weapon damage for 1 hour afterwards unless they succeed at a Will save DC 24.  

**Mettle (Ex):** If Panzuriel’s Avatar makes a successful Will or Fort save against an attack that would normally have a lesser effect on a successful save, he instead completely negates the effect. If he is asleep or unconscious he does not benefit from mettle.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.  

* * *