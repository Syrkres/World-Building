# Selune, The Night White Lady
_Our Lady of Silver, the Moonmaiden, the Night White Lady_  
**Intermediate Faérunian Deity**  
**Symbol:** Two darkly beautiful female eyes surrounded by a circle of seven silver stars  
**Home Plane:** The Gates of the Moon, Ysgard  
**Alignment:** Chaotic good  
**Portfolio:** Good and neutral lycanthropes, moon, navigation, questers, stars, wanderers  
**Worshipers:** Female spellcasters, good and neutral lycanthropes, navigators, monks (Sun Soul), sailors  
**Cleric Alignments:** CG, CN, NG  
**Domains:** Chaos, Good, Moon, Protection, Travel  
**Favored Weapon:** "The Rod of Four Moons" (heavy mace)  

**SELUNE**  
Wizard 23, Cleric 20, Fighter 14, Bard 12  
Medium Outsider (Chaotic, Good)  
**Divine Rank:** 15  
**Hit Dice:** 23d4+184 (Wiz) plus 20d8+160 (Clr) plus 14d10+112 (Ftr) plus 12d6+96 (Brd) (1016 hp)  
**Initiative:** +11 (+11 Dex)  
**Speed:** 60 ft. (12 squares)  
**Armor Class:** 95 (+11 Dex, +14 armor, +15 divine, +30 natural, +15 deflection), touch 51, flat-footed 84  
**Base Att/Grapple:** +37/+59  
**Attack:** _The Rod of Four Moons_ +76 melee (1d8+35 plus +3d6 holy/19-20/x3 plus +6d6 holy); or _Moonblade_ +67 melee (1d8+16/17-20 plus magic scramble); or spell +59 melee touch or +60 ranged touch.  
**Full Attack:** _The Rod of Four Moons_ +76/+71/+66 melee (1d8+35 plus +3d6 holy/19-20/x3 plus +6d6 holy); or _Moonblade_ +67/+62/+57 melee (1d8+16/19-20 plus magic scramble); or by spell.  
**Space/Reach:** 5 ft./5 ft.  
**Special Attacks:** Domain powers, salient divine abilities, spell-like abilities, spells, turn undead 19/day.  
**Special Qualities:** Bardic knowledge +34, bardic music (countersong, _fascinate_, inspire competence, inspire courage +4, inspire greatness, inspire heroics, _mass suggestion_, _suggestion_) 12/day, divine aura (1500 ft., DC 40), divine immunities, DR 25/epic and silver, familiar (owls), fire resistance 20, godly realm (10 miles Outer Plane, 1500 ft. Material Plane), _greater teleport_ at will, _plane shift_ at will, remote communication 15 miles, SR 81, understand, speak, and read all languages and speak directly to all beings within 15 miles.  
**Saves:** Fort +56, Ref +56, Will +70  
**Abilities:** Str 26, Dex 32, Con 26, Int 43, Wis 45, Cha 41  
**Skills:** Appraise +31 (+35 alchemy), Balance +70, Bluff +60, Concentration +82, Craft (alchemy) +73, Decipher Script +46, Diplomacy +116, Disguise +30 (+34 acting), Escape Artist +71, Handle Animal +70, Heal +104, Hide +51, Intimidate +74, Jump +52, Knowledge (arcana) +101, Knowledge (geography) +69, Knowledge (history) +91, Knowledge (nature) +75, Knowledge (nobility and royalty) +71, Knowledge (religion) +101, Knowledge (the planes) +91, Listen +57, Move Silently +76, Perform (sing) +60, Ride (horse) +55, Search +54, Sense Motive +81, Spellcraft +108, Survival +72 (+76 avoid getting lost, +76 natural, +78 planar, +74 tracking), Tumble +55, Use Rope +26 (+32 bindings).  
*Always recieves a 20 on checks.  
**Feats:** Blind-Fight, Combat Expertise, Combat Reflexes, Craft Rod, Craft Wand, Craft Wondrous Item, Delay Spell, Divine Might, Dodge, Eschew Materials, Expertise, Forge Ring, Greater Spell Penetration, Heighten Spell, Improved Combat Expertise, Improved Critical (heavy mace), Improved Disarm, Improved Initiative, Improved Trip, Maximize Spell, Mobility, Power Attack, Quicken Spell, Reach Spell, Sacred Spell, Scribe Scroll, Spell Penetration, Spring Attack, Still Spell, Weapon Focus (heavy mace), Weapon Specialization (heavy mace), Whirlwind Attack.  
**Epic Feats:** Epic Spellcasting, Epic Weapon Focus (heavy mace), Epic Weapon Specialization (heavy mace), Improved Heighten Spell, Multispell.  
**Environment:** The Gates of the Moon  
**Organization:** Unique  
**Challenge Rating:** 62  
**Treasure:** _The Rod of Four Moons_, _Lunar Mail_, _Moonblade_.  
**Alignment:** Chaotic good  
**Advancement:** --  
**Level Adjustment:** --  

- **Divine Immunities:** Ability damage, ability drain, acid, cold, death effects, disease, disintegration, electricity, energy drain, mind-affecting effects, paralysis, poison, _sleep_, stunning, transmutation, _imprisonment_, _banishment_.  
- **Divine Power:** Selûne is a living embodiment of power, and ancient divine magics flow through her veins. As such, mortal items are of virtually no use to her, being so much weaker than her own innate powers. Selûne gains no benefit from a deflection, enhancement, resistance, insight, sacred or profane bonus that is less than +15\. Note that this only applies to bonuses that affect Selûne herself; weaponry and armor is unaffected by this.  
- **Salient Divine Abilities:** Alter Form, Arcane Mastery, Annihilating Strike (Fort DC 33, or destroy up to 15,000 cubic feet of nonliving matter), Area Divine Shield (up to 15 10-foot squares, or a sphere or hemisphere with a radius of up to 15 feet), Divine Blast (18/day, up to 15 miles, 30d12 damage), Divine Blessing (Wisdom), Divine Inspiriation (frenzy, Will DC 40, up to 15 creatures/day), Divine Shield (11/day, stops 150 points of damage), Divine Spellcasting, Divine Weapon Focus (heavy mace), Divine Weapon Specialization (heavy mace), Extra Domain (Travel), Lay Curse (Will DC 40, up to 15 creatures/day), Lay Quest (up to 15 creatures/day), Lycanthrope Mastery*, Mass Divine Blast (up to 75 targets, no two of which can be more than 15 miles apart, or a cone up to 1,500 ft. long, or a burst or spread with a radius of up to 750 ft. and a height of up to 150 ft.), Posess Mortal (Will DC 40, up to 10 mortals at once), Shapechange.  
*Unique ability, see below.  
- **Alter Reality:** Selûne can use the _wish_ spell with regard to her portfolio, save for the replication of other spells. This ability costs Selûne no XP, and requires a standard action to implement. Selûne adds once again her Intelligence modifier or Wisdom modifier for determining wizard or cleric spell saving throw DCs, respectively. As a free action 15/day, for one round at a time, Selûne may add +16 to her effective spellcaster level.  
- **Domain Powers:** Cast chaos spells at +1 caster level; cast good spells at +1 caster level; 19/day turn or destroy lycanthropes; 15/day protective ward (touched subject gains +20 resistance bonus on next saving throw, maximum duration 1 hour); 20 rounds/day _freedom of movement_.  
- **Spell-Like Abilities:** Selûne uses these abilities as a 84th-level caster, except for chaos spells and good spells, which she uses as a 85th-level caster. The save DCs are 51 + spell level. _Aid, animal shapes, animate objects, antimagic field, astral projection, blade barrier, chaos hammer, cloak of chaos, dimension door, dispel evil, dispel law, emotion, expeditious retreat, faerie fire, find the path, fly, greater teleport, holy aura, holy smite, holy word, insanity, locate object, magic circle against evil, magic circle against law, mind blank, moon blade, moon path, moonbeam, moonfire, permanent image, phase door, prismatic sphere, protection from elements, protection from evil, protection from law, repulsion, sanctuary, shatter, shield other, spell immunity, spell resistance, summon monster IX_ (as chaos or good spell)_, word of chaos_.  
- **Spells:** As a 23th level wizard (39th with alter reality), +38 vs. SR (+54 with alter reality); a 20th level cleric (36th with alter reality), +35 vs. SR (+51 with alter reality); and as a 12th level bard (28th with alter reality), +27 vs. SR (+43 with alter reality). Selûne's spells always appear as streaking moonbeams, altering to their true spell effects only when they near their intended target or area of effect. Selûne may cast up to 7 epic arcane and up to 7 epic divine spells per day, up to DC 118 (when taking 10).  
- **Bard Spells Known:** (3/7/7/7/6; base DC 26 + spell level): 0 - _dancing lights, daze, detect magic, mage hand, mending, read magic_; 1st - _hypnotism, mage armor, protection from evil, silent image;_ 2nd - _bull's strength, locate object, silence, Tasha's hideous laughter_; 3rd - _dispel magic, magic circle against evil, major image, scrying_; 4th - _break enchantment, locate creature, rainbow pattern_.  
- **Wizard Spells Per Day (levels 1-16):** (4/8/8/8/8/7/7/7/7/6/3/3/3/2/2/2/2; base DC = 43 + spell level).  
- **Cleric Spells Per Day (levels 1-17):** (6/10/9/9/9/9/7/7/7/7/3/3/3/3/2/2/2/2; base DC = 45 + spell level).  
- ***Lycanthrope Mastery (unique salient divine ability:** No lycanthrope can raise a hand against the Goddess of the Moon. They may flee or stand their ground, but any attempt to cast a spell or make an attack with Selûne as the target or within the area of effect causes the creature to be stunned for 1 round (prior to actually making the action).  
- **Possessions:** Selûne carries the _Rod of Four Moons_, a _+10 defending disruption holy power heavy mace_ that can also duplicate the effects of a _rod of security_ or cast _hold monster_ (Will DC 48), _polymorph any object_ (Fort DC 51), _lightning bolt_ (Ref DC 46), or _ressurection_ at will as a standard action. (_Caster Level:_ 69th; _Weight:_ 12 lb.) Selûne's scale mail, which she wears only in battle, has opalescent, perfectly round scales that glow with a dim silver light. It acts as a _+9 glamered elven chain of etherealness_, and Selûne sometimes lends it to beings on a quest or performing a service for her. Selûne suffers no check penalty, spell failure, or maximum dexterity bonus when wearing the armor, and she retains its AC benefit even when she has lent it away. (_Caster Level:_ 69th; _Weight:_ 20 lb.) Selûne uses the _Moonblade_ as a secondary weapon. Springing into existance from her hand, the blade of moonlight is weightless and silent, and cannot be dropped, disarmed, given to another being, or broken. It's strikes cause no visible wounds, but drain away vitality, dealing damage as a _+8 longsword_. Undead _are_ visibly wounded by it, and they take double damage. A strike with the _moonblade_ scrambles magic - if the target fails a Will save (DC 60), they may not cast any spells or use any spell-like abilities during their next turn. Any existing spells active upon their person are suspended for that round, and any magical items they wield do not function for that round. (This effect lasts only for one round after being struck, regardless of how many times they were hit during the preceeding round). (_Caster Level:_ 69th; _Weight:_ 0 lb.)  

**Other Divine Powers**  
- As an intermediate deity, Selûne automatically reives a die result of 20 on any check. She treats a 1 on an attack roll or saving throw normally and not as an automatic failure. She is immortal.  
- **Senses:** Selûne can see, hear, touch, and smell at a distance of fifteen miles. As a standard action, she can perceive anything within fifteen miles of her worshipers, holy sites, objects, or any location where one of her titles or name was spoken in the last hour. She can extend her senses to up to ten locations at once. She can block the sensing power of deities of her rank or lower at up to two remote locations at once for up to 15 hours.  
- **Portfolio Sense:** Selûne senses any act that takes place under the open light of the moon the instant it happens and retains the sensation for fifteen tendays after the event occurs.  
- **Automatic Actions:** Selûne can use Knowledge (arcana), Knowledge (geography), Knowledge (history), Knowledge (nature), Knowledge (nobility and royalty), Knowledge (the planes), or Knowledge (religion) as a free action if the DC for the task is 25 or lower. She can perform up to 10 such free actions each round.  
- **Create Magic Items:** Selûne can create any kind of magic item that bestows healing, affects shapechangers, or allows the use of spells from the Moon domain spell list, as long as the item's market price does not exceed 200,000 gp.  

**Avatars**  
- The physical appearance of Selûne's avatar changes with the phases of the moon. Sometimes, she takes the form of a dusky-hued, long-limbed, human woman of exquisite beauty, with long, white hair framing a perfect face marked with stunning, lime-green eyes. At other times, the avatar is a ghostly, lithe, young girl with dark hair and eyes who wears diaphanous robes the color of dappled moonlight. At other times, she is matronly and aging gracefully, with ample softness around the edges. Her appearance grows more radiant or more subdued with the changing of the moons, though such superficial alterations have no effect upon her powers. She prefers not to send avatars to Faerun, knowing that Shar delights in murdering her manifestations there. Instead, Selûne's avatars ply the Outer Planes in search of magical lore and some edge that will finally help her defeat the Lady of Loss.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *