# Ogremosh, Tyrant of the Crumbling Stone
Gargantuan Elemental [earth, extraplanar, evil, psionic]  
**Hit Dice:** 52d8+28d12+960 (1712 hp)  
**Initiative:** +4  
**Speed:** 100 ft., Burrow 180 ft., Swim 90 ft.  
**Armor Class:** 70, flat-footed 70, touch 13 (–4 size, +7 deflection, +45 natural, +10 armor)  
**BAB/Grapple:** +40/ +69  
**Attack:** +65 melee (Gargantuan Maul 4d8+31 plus 2 Constitution, 19-20/x3 plus 1 negative level) or +53 melee (Slam, 2d8+17) or +53 ranged (boulder 4d8+17)  
**Full Attack:** +65/+60/+55 melee (Gargantuan Maul 4d8+31 plus 2 Constitution 19-20/x3 plus 1 negative level) or +53 melee (2 slams, 2d8+17) or +53/+48/+43 ranged (boulder 4d8+17, 100’ range increment)  
**Space/Reach:** 20 ft. / 20 ft.  
**Special Attacks:** Create Boulders, Crumbling Touch, Elemental Splendor, Elemental Prime, Hammering Blows, Psi-like abilities, Spell-like abilities, Summon Elementals, Turn Elementals, Wrath of the Inner Planes.  
**Special Qualities:** Acid Absorption, Archomental Qualities, Cold Resistance 20, Darkvision 60’, DR 35/Epic, DR 23/-, _detect magic_, Electricity Vulnerability, Elemental Leap, Elemental Metamorphosis, Fast Healing 12, Fire resistance 20, Indomitable Will, Mighty Rage 8/day, Regeneration 20, _see invisible_, SR 52, Tremorsense 400 ft.,  
**Saves:** +49 Fortitude, +37 Reflex, +38 Will  
**Abilities:** Strength 45, Dexterity 11, Constitution 34, Intelligence 24, Wisdom 24, Charisma 24  
**Skills:** Bluff +25, Concentration +53, Diplomacy +29, Intimidate +92, Knowledge (the planes, arcana, religion, history) +25, Listen +90, Psicraft +48, Sense Motive +25, Spellcraft +50, Spot +62, Survival +90 (+92 planar)  
**Feats:** Brutal Throw [CAdv], Cleave, Combat Brute [CW], Deep Impact [XPH], Energy Substitution (B), Great Cleave, Improved Bull Rush, Improved Critical (Maul) Improved Initiative, Improved Sunder, Lightning Reflexes, Power Attack, Psionic Meditation, Psionic Weapon [XPH], Stand Still [XPH], Three Mountains Style [CW], Weapon Focus (Maul), Wounding Attack [XPH]  
**Epic Feats:** Damage Reduction, Devestating Critical (Maul), Dire Charge, Overwhelming Critical (Maul), Ruinous Rage, Thundering Rage, Epic Reflexes  
**Challenge Rating:** 40  
**Treasure:** Quadruple standard base creature's, plus +5 _gleaming_[XPH], _ghost touch_ Adamantine Breastplate, _Stone's Sorrow_  
**Alignment:**Chaotic Evil  
**Advancement:** By class progression  

Ogremosh’s natural weapons count as Epic for purposes of overcoming Damage Reduction.  

**Acid Absorption:** Ogremosh is immune to acid damage. If struck by acid damage, Ogremosh heals the damage it would otherwise deal.  

**Archomental Qualities:** Immunity to poison, sleep effects, and stunning. Not subject to critical hits or flanking.  
• Divine Rank 0: As a high Power of the Inner Planes, Ogremosh gain a degree of might unknown to mortals and common elementals. Ogremosh has immunity to polymorphing, petrification, or any other attack that alters its form. Ogremosh is not subject to energy drain, ability drain, or ability damage. Ogremosh is immune to mind-affecting effects. Ogremosh is immortal and cannot die from natural causes. Ogremosh does not age, and it does not need to eat, sleep, or breathe. They only way for Ogremosh to die is through special circumstances.  
• For the purpose of gate and similar spells, Ogremosh is treated as a unique creature.  

**Create Boulders:** Ogremosh can form boulders to throw from his own body as free actions. Additionally, as a full-round action, he can form and hurl a giant 25-ft diameter boulder up to 100’. All creatures within the area must roll a Reflex DC 62 saving throw or suffer 20d6+25 bludgeoning damage and be buried under 15 ft of earth & stone. (See the SRD for rules on cave-ins to see the effects of being buried, and how to dig characters out) A successful saving throw prevents burial and reduces the damage by half.  

**Crumbling Touch (Su):** Ogremosh’s slam attack, in addition to dealing damage, weakens objects of metal or stone. Each time an opponent is struck by a slam attack, any metal or stone armor worn by the target suffers 2d10+34 damage. (Fortitude DC 62 for half damage; the DC is Strength-based) Ogremosh’s slam attacks deal double damage against creatures or objects crafted from stone or metal, such as Golems or Shield Guardians, or against metal or stone weapons.  

**Earth Glide (Ex):** Ogremosh can glide through stone, dirt, or almost any other sort of earth except metal as easily as a fish swims through water. Its burrowing leaves behind no tunnel or hole, nor does it create any ripple or other signs of its presence.  

**Earth Mastery (Ex):** Ogremosh gains a +1 bonus on attack rolls, damage rolls, and Bull Rush checks if both it and its foe are touching the ground. If an opponent is airborne or waterborne, Ogremosh takes a –4 penalty on attack and damage rolls. (These modifiers are not included in the statistics block.)  

**Electricity Vulnerability:** Ogremosh suffers 50% more damage from electricity effects.  

**Elemental Leap (Su):** When Ogremosh is in contact with a piece of their element two or less size categories smaller than it is, it may transfer itself to another piece of that element anywhere on the plane. Except for that limitation, this ability works exactly like greater teleport.  

**Elemental Metamorphosis (Ex):** Ogremosh may assume a new shape and size based on its own preference. Any adjustments in size and or form may affect Ogremosh’s attack methods or size modifiers. Ogremosh has one known alternate form. If sorely pressed in combat, it will adopt an alternate form: in place of legs, his torso is supported by a column of earth that sprouts an additional 8 arms. These arms can either be used for additional Slam attacks (as above, or at -5 if Ogremosh is also using his Maul) additional boulder attacks (only one boulder per arm, no iterative attacks) or Ogremosh may wield his Maul with up to 8 hands. Each hand adds an additional +8.5 to damage (round down) and +2 to the opposed roll against a Disarm attempt. Ogremosh can only assume this form while in contact with the ground, may only move via Burrowing or 5 ft. steps, and cannot voluntarily leave the ground in this form. If forcefully removed from the ground, he reverts to his normal form.  

**Elemental Prime (Ex):** The might of Ogremosh within its element is unquestioned. Its attacks cut through resistances like a blade. Creatures with nonpermanent resistance or immunities to Acid (such as that from spells or magic items) have their protections subjected to a dispel check each they attempt to resist an elemental attack from Ogremosh, as if the Archomental had cast greater dispelling, but with a check of 1d20 +40\. This check happens automatically. Items that are dispelled in this way remain inactive for 24 hours.  
Creatures with innate resistance or immunity are not safe from Ogremosh’s attacks either. They must make a Fort save (DC 57) every time they are exposed to an attack they would resist or ignore. Failure indicates their resistance is stripped away completely, and success indicates it has been halved. Creatures with immunity who pass their save are treated as having resistance 40\. Ogremosh also strips other elemental-based abilities away such as Earth Mastery, and material-based Damage Reduction. The saving throw is the same. Combination DR loses its material-based component. (“Evil Silver” becomes “Evil”) This ability does not work against creatures with a divine rank higher than its own.  

**Elemental Splendor (Su):** The presence of Ogremosh brings with it all the glory of the Earth. The area within 80 feet of an Archomental is suffused with the essence of Earth, which has the following effect:  
The area becomes oppressing, as if one were entombed. All speeds are reduced by 20 feet, and all creatures within the aura must make a fortitude save (DC 57) or begin to suffocate. Creatures within the aura who make their saves are immune to the suffocation effect for as long as they remain within the aura. Ogremosh may make its followers, allies, or beings of similar alignments immune to the negative effects of its aura. This immunity lasts until Ogremosh dismisses it (a free action).  

**Hammering Blows (Ex):** Whever Ogremosh strikes an opponent in melee while using Power Attack, the opponent is immediately subjected to a special Bull Rush check. (+33, plus the damage bonus from Power Attack) If successful, the opponent is pushed back 5 ft. (not a 5 ft. step) and Ogremosh does not move at all. This counts as a successful bull rush maneuver.  

**Indomitable Will:** Ogremosh gains a +4 to Will saves versus enchantment effects.  

**Mighty Rage:** 8/day, +8 strength, +8 constitution, +4 morale bonus to Will saves, -2 to AC. Duration 16 rounds.  

**Psi-like Abilities:** Manifester level 44, At will - _crystal shard_ (ranged touch, 44d6 piercing damage, 135 ft. range), _dissolving touch_ (touch, 24d6 acid), _dissolving weapon_ (+24d6 acid), _exhalation of the black dragon_ (ranged touch, 42d6 acid, 135 ft. range), _hail of crystals_ (secondary damage 44d4 slashing, Reflex DC 22), _strength of my enemy_ (maximum bonus +30, swift action), _stomp_ (20 ft. cone, 44d4 nonlethal damage and fall prone, Reflex DC 18 negates)  

**Regeneration (Ex):** While in contact with earth or stone, Ogremosh gain Regeneration 20\. This regeneration may only be countered by removing Ogremosh from contact with earth or stone. Effects that the Ogremosh creates himself does not cause this regeneration to activate, but indirect effects do.  

**Spell-like Abilities:** Caster level 44, DC 17+ level. Always active – _detect magic, see invisibility_. At will – _earth reaver_[SS], _flesh to stone, harm, inflict critical wounds, inflict light wounds, inflict light wounds (mass), magic stone, move earth, plane shift_ (Earth only), _shatter, soften earth and stone, spike stones, stoneskin, stone shape, transmute mud to rock, transmute rock to mud, wall of stone._  
3/day – _clenched fist, crushing hand, disintegrate, earthquake, elemental swarm_ (earth), _grasping hand, imprisonment, iron body._  

**Summon Elemental (Sp):** As a standard action, Ogremosh can summon earth, ooze, or magma elementals. Ogremosh may summon a total of 50 HD of small to elder elementals in a given day. 1/week, Ogremosh may summon a primal elemental of up to 50 HD. It is under no obligation to use all of its limit at once, and may divide it up over the day as it sees fit.  

**Turn Elementals (Ex):** Ogremosh can rebuke and command elementals as if it possessed the Earth domain power. Its turning level is equal to 40  

**Tremorsense:** Ogremosh can automatically pinpoint the location of anything that is in contact with the ground within 400 ft, regardless of cover, concealment, darkness, etc.  

**Wrath of the Inner Planes (Sp):** 4 times per day, Ogremosh may bring forth an elemental blast. This deals 29d12 points of damage. Creatures caught in the blast may make a reflex save (DC 57) for half damage. The blast is a 60’ cone, and the damage type is ½ acid, and ½ divine.  

_Stone's Sorrow_: This +6 Greater Wounding, Soulbreaker Obdurium Maul ignores all Hardness of non-artifact objects. Stone's Sorrow can deal critical hits to objects and constructs as if they were living creatures. It also destroys Force effects as per the _disintegrate spell_ on contact. The maul is solid obdurium: head, haft, and grip. It has an unsually long grip, and can be wielded with up to eight hands with no penalty. When wielded by any creature without the [undead] type or the [earth] subtype, the wielder suffers 2d10 negative energy damage per round.  
Caster level: 50; weight 160 lbs.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *