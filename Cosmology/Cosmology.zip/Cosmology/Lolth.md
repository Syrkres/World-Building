# LOLTH, Demon Queen of Spiders, Goddess Matron, Weaver of Lies  
Demiurge  
**Symbol:** A female Drow head superimposed atop a spider with an hourglass-shaped marking on the abdomen  
**Huge Outsider (Chaotic, Evil, Extraplanar)**  

**Hit Dice:** 60d8 (outsider) +360 (840 hp)  
**Initiative:** +14 (+6 Dex, +8 Superior Initiative)  
**Speed:** 110 ft., climb 110 ft., fly 220 ft. (perfect)  
**AC:** 79 (+6 Dex, –1 size, +37 natural +9 profane +16 deflection +2 exoskeleton), 73 flat-footed, 42 ranged touch  
**Face/Reach:** 15 ft./10 ft.  
**Attacks:** Bite +62 and +60/+60 (2 claws) or +62/+62 (2 claws) or +73 Lolth’s Love or +66 ranged  
**Damage:** 4d8+5 plus spellsuck plus 1 (vile) plus Fort DC 56 (1d8 Str/2d8 Str poison) (Bite)/x2 plus 2 (vile) and 4d6+2 plus 1 (vile) and 4d6+2 plus 1 (vile) (2 Claws) or 4d6+5 plus 1 (vile) and 4d6+5 plus 1 (vile) (2 Claws) or 11+1d4 plus 1d6 (acid) plus 3d6 (unholy) plus 1 negative level/19-20/x2 plus 6d6 (unholy) plus 2 negative levels (Lolth’s Love, a _+11 unholy power distant shot spiked whip_)  
**Special Attacks:** Abyssal Vehemence, Call Demons, Call Drow, Call Spiders, Cosmic Corruption, Entropic Wave, Goddess Matron, Lolth’s Favor/Disfavor, Psionics, Ravaged Forms (Digestion, Spinnerets, Spiteful Gaze, Venomous Bite), Rebuke Undead and Outsiders (20/day), Spell-like abilities, Weaver of Lies  
**Special Qualities:** Darkvision 180 ft., Decadent Divinity (vDR 11), Demon Goddess, Demiurge Qualities, DR 25/lawful, epic, good, mithral, fast healing 15, immunities (electricity, learned spell, poison), _nondetection_ (60th level), Ravaged Forms, Regeneration 10/good and +3 holy, SR 55, tremorsense 60 ft.  
**Saves:** Fort +28, Ref +30, Will +40  
**Abilities:** Str 18, Dex 26, Con 22, Int 42, Wis 38, Cha 45  
**Skills:** Appraise +30 (+34 jewelry), Autohypnosis +25, Balance +20, Bluff +63, Climb +38, Concentration +63, Craft (Alchemy) +20, Craft (Poisonmaking) +35, Craft (jeweler) +20, Diplomacy +79, Disguise +30 (+38 observed in character), Escape Artist +20, Gather Information +63, Hide +50, Intimidate +71, Jump +26, Knowledge (arcane) +63, Knowledge (architecture and engineering) +30, Knowledge (dungeoneering) +40, Knowledge (geography) +20, Knowledge (the planes) +63, Knowledge (religion) +63, Knowledge (psionics) +63, Listen +53, Move Silently +50, Perform (oratory) +30, Psicraft +71, Search +30 (+36 find secret doors, , Sense Motive +63, Speak Language (Abyssal, Common, Draconic, Elven, Undercommon), Spellcraft +71, Spot +24, Survival +30 (+36 extraplanar, +34 find tracks, +32 avoid lost/hazards, +36 underground)  
**Feats:** Corrupt Spell-like Ability, Dark Speech, Empower Spell-like Ability, Eschew Material Components, Greater Spell Penetration, Improved Initiative, Multiattack, Psionic Meditation, Quicken Spell, Quicken Spell-like Ability, Spell Penetration, Still Spell, Twin Power, Vile Natural Strike, Violate Spell-like Ability  
**Epic Feats:** Epic Manifesting, Epic Spellcasting, Ignore Material Components, Improved Spell Capacity, Multispell, Planar Turning, Power Knowledge (_Energy Bolt, Vile Mist_), Superior Initiative  
**Climate/Terrain:** Lolth’s Web (Layer 65 in the Abyss) or Demonweb Pits (Layers 65-66 in the Abyss)  
**Organization:** Unique (Solitary) or Lolth+Thane of Lolth (Selvetarm) or Mated Pair (Lolth+’consort’) or Swarm (Lolth+Horde)  
**Challenge Rating:** 57  
**Treasure:** Lolth’s Love, Quintuple Standard  
**Alignment:** Chaotic Evil  
**Advancement:** N/A  

According to the Seldarine, Araushnee was created as the consort of Corellon and the patron deity of artisans and elven destiny. Her stories inspired crafters of spell and item to greater heights of creativity and through them the future could be seen. Yet jealousy burned within her heart, eventually conquering it until she committed acts of depravity so great that war raged within Arborea between her children and all others. She was defeated along with those elves who had been seduced to her cause, then transformed into a spider-shaped ta’anari and cast into the Abyss. She was named Lolth and still rules from the Abyss as the pre-eminent deity of her followers.  

According to many who consider themselves knowledgeable of such things, Lolth is an ancient malevolence that exists to tempt primarily elves and has a strange affinity for arachnids. Those elves tempted are driven to acts of domination, torture, and magical experimentation, and eventually come to be known as ‘drow’, or ‘dark elves’, or multiple variations of that term. They are driven underground, where their scheming against each other is only exceeded by their scheming against everything else.  

Both of these are only part of the truth.  

Lolth was the former consort of Corellon Larethian and she did bear him two children; Vhaeraun and Eilistraee. The former was born evil while the latter took more after her father and from Lolth’s perspective was an even greater disappointment than Vhaeraun. At the same time, however, Lolth succeeded in two respects where so many others had failed and did raised an army within Arvandor itself, attacked her own mate, and brought civil war to Arborea. The second respect in which Lolth succeeded is in a manner that few know about much less will discuss; it is that Lolth was always evil and may be one of the most successful liars in existence.  

Most of the theories as to the origins of Lolth even for those who know her true status also have their own share of failings. Whichever theory is adhered to, all of them are disturbing. One is that Lolth, herself, was born when the first lie was told and grows as the destruction and scheming that she has caused spreads across the planes and ensnares more individuals. Another theory is that Lolth is a projection of something far older and bizarre than even she is and seeks to infect the rest of existence until it is ‘hospitable’ by her warped standards. While the latter theory is lent some credence by the testimony of those individuals who have seen Lolth’s Web for themselves and survived the experience somewhat intact, unfortunately for the rest of existence Lolth seems to be quite capable of travelling outside her web.  

In actuality, Lolth is yet another child of Chaos himself by a forgotten deity of magic known only as “She Who Undoes Words” long after his mating with Pale Night. As a comparatively young (and minor), Demon Prince herself, Lolth marched with the armies of Pale Night to the Gates of Heaven...where she was ignominiously and painfully defeated by a male Celestial fey so horribly that the only way that she could preserve herself was in the form of a single, hour-glass symbol of glyphs.  

Cast back into the Abyss, she remembered few aspects of her previous existence except for the fact that she had been defeated by a male fey, and her utter passion for their corruption and manipulation. From the aspect of her that survived, she learned to craft forms for herself. First was the arachnid, and in this form she wrested control of the Yochlol from a rival Demon Prince, allowing her to have her own realm for her manipulations. Her first transformation into the Drow known as Araushnee marked her ascension to Demiurge status; although none would record the event or even know that it had taken place.  

Lolth’s goals are similarly obscure even if her methods are virtually archetypal to those who do not know the truth of her origins. What is definitively known is that she prefers to concentrate on the discovery and the corruption of the Prime Material Planes, rotting them from within as first their elves, and then everyone else, slowly become sadistic experimenters and cruel, chaotic rulers crushing everyone else underfoot on the basis of whim and powerlust. The only practical difference between a plane where the Drow are dominant and a plane of the Abyss is that the latter is more obvious in it’s evil. Tragically, she has been so successful at this that out of all the Demiurge she has the most worshippers in terms of sheer numbers. In fact, out of all the Demiurge, Lolth is the one whose destructive machinations are most likely to impact the daily lives of innocents for wherever there is an Underdark, there are creatures living there scheming for ways to increase to increase Lolth’s power and not all of them are Drow. In turn, as the power of Lolth’s ‘creations’ increases under the ground of everyone else, her webs ensnare more until eventually, all planes shall bend to her will.  

Lolth’s ‘relations’, such as they exist, with the other Abyssal Lords and Demiurges are absolutely horrible for the most part not as much because of her raw power, but because of her sheer skill at treachery, stealing/exterminating the powers and worshippers of others, and getting others to do her work for her. She is an ardent supporter of the Blood War precisely because she contributes so little to it from the Demonweb Pits and because Blood War veterans make excellent potential ‘recruits’ for summoning by the Drow and participation in her own plans to extend her reach across the Primes. Similarly, she also encourages internecine warfare between Demogorgon, Graz'zt and Orcus (as if any of them needed encouragement), as long as the results are that none of them actually win anything. Most Demon Lords and Princes who are worshipped by various races have either had them exterminated as competition or their members abducted for the purposes of subjugation, experimentation, or territory, and at least two evil deities have died or disappeared through her efforts.  

She despises Graz'zt for poaching male Drow to his side (this he calls ‘restoring them to their rightful status’) as well as several influential high priestesses, because cults of Graz'zt worshippers among male Drow are far more common than she would like to admit, and because Graz'zt’s cause of unifying the Abyss under his leadership is a threat to her own plans of universal, capricious rule. Furthermore, she wishes to steal his powers over darkness as well as his control of a wide array of Abyssal layers. While the Demiurge of Shadows in turn may regard her dismissively at best and has made her prowess a running joke in Az’zagrat at the same time, he is secretly more than a little jealous of the fact that her Drow, if anything, are drastically increasing in both power and reach.  

Her relations with Orcus are far worse than they are with Graz'zt. As the Demon Prince of the Undead, when Orcus thinks of the Drow, the first words that occur to him are ‘raw material’ and he suspects that Kiaransalee is Lolth’s tool against him. In this he is partially right-Lolth has done her utmost to manipulate the Revenancer and Orcus into endless confrontations, hoping to weaken Orcus and keep Kiaransalee in a state of dependence to her largesse. As far as her plan is concerned, she regards Kiaransalee’s assassination as some progress, since the disappearance of Orcus gave Lolth an outstanding opportunity to ‘acquire’ and subvert some of Orcus’ possessions for herself, although of course not entirely successful. Should Orcus ever learn the full extent of Lolth’s involvement he will march on the Demonweb Pits with all his strength and try and wipe the Drow out of existence after killing Lolth.  

Pale Night loathes Lolth; not only because Pale Night considers her distant relative amateurish, but also because of Lolth’s success in causing the war in Arborea. At the same time, neither Pale Night or Lolth know about their true relationship. Lolth has captured one of her agents and knows that there is something ancient observing her own webs of power and deceit, although she has yet to place a name to it. All she knows for now is that Pale Night is the consort of Pazuzu, the former consort of Baphomet, and a lot more than most think she is.  

Like all rules concerning Lolth, there is a notable exception: this rule is broken in terms of Lolth’s relationship with the Demiurge Merrshaulk. The exact nature of their relationship lends itself to great speculation, but Abyssal Lords that rule territory for Merrshaulk generally accept Drow visitors and ‘ambassadors’; in turn, yuan-ti are often about as welcome in Drow cities as any non-Drow could be-which is to say that they at least don’t get killed until they get too entangled in plots or fail to make themselves useful as trading partners and sources of information.  

In comparison, Demon Lords and Princes whose domains are more abstract (such as knowledge or pain) she tends to get along better with, if only while she studies how best to steal their resources and worshippers for herself. She has already fomented two attempts to conquer the Terminal Archive belonging to Astaroth Diabolos. Both attacks were eventually traced to a Demon Lord (since deceased) that not-coincidentally, Lolth had emnity with. Furthermore, her current consort, Arcarnius, is a powerful psion in his own right, in addition to his capability for providing Lolth with further information on Pale Night.  

Relations with other pantheons are also quite varied. Lolth’s few vaguely reliable deific allies include Malar and Loviatar, the Mistress of Pain. In the case of the latter significant overlap exists in terms their methods which suits Lolth perfectly as it adds to the confusion over her true status. Although all of the denizens of the Upper Planes can count Lolth and her followers as enemies, the Seldarine particularly despise Lolth and the Drow who have chosen to follow her depravity with a passion that has at times been their undoing. Gruumsh did (eventually) figure out that Lolth manipulated him into confronting Corellon in order to buy time for the Drow loyal to her to attempt to conquer Arborea. Not surprisingly, he is still angry with her.  

Lolth’s status even with the deities that are ostensibly under her sway is convoluted. Recognizing a similarly warped mind in Kiaransalee when the Revenancer was a comparatively minor lich, Lolth encouraged her madness and depravity, both to eliminate those elves from Kiaransalee’s homeland who were becoming suspicious of her disguise as Araushnee, and also to develop a potential ally. At the same time (and not surprisingly), Kiaransalee and Lolth mutually hate each other. Only the menace of Lolth and Kiaransalee’s many common enemies keeps them cooperating in any effective manner and prevents the constant conspiring between their followers from turning into outright warfare in the Demonweb Pits. Selvetarm, in comparison, may be far more (outwardly) cooperative but Lolth knows well that he chafes in his subservience to her and so has prepared a wide array of defenses and contingency plans in order to keep him in line.  

The true form of Lolth is that of an large spider 10’ wide and 1.5’ tall with an hourglass-shaped block of red glyphs located on the top of her abdomen and an exoskeleton the color of polished obsidian. Her entire body is wreathed in crawling spiders with the exceptions of her eyes, fangs, mouth and spinnerets. Her mouth, composed of two perfectly shaped Drow lips, is located above two large fangs pointed downwards, and below her eight crimson eyes arranged in two rows with three in the top row, five in the bottom row.  

When Lolth interacts with the Drow she typically carries Lolth’s Love and takes the form of a darkly beautiful female Drow or a Drow-spider hybrid wearing nothing but her Crown of Spiders. In any humanoid form that Lolth takes what will always stand out are her crimson, smoldering eyes, a slightly mocking smile, and bouts of spiteful laughter that are more common after she has succeeded in destroying or controlling something or someone.  

**Ravaged Form-Arachnid Mastery(Ex):** Lolth may control up to 170 HD of arachnids or arachnid-related monsters within 11 miles of her person. For the purposes of her Arachnid Mastery any sentient creature that has been Judged by her or has been polymorphed into an arachnid counts as an arachnid, although the latter recieves a Will saving throw at –10 penalty (DC 57). She may also use the spells _giant vermin, speak with spiders,_ and _spiderclimb_ at will in any form and any creature controlled in this manner gets the Fiendish template.  

**Ravaged Form-Arachnoid:** The true form of Lolth is that of an arachnid; she has eight eyes and eight legs as a result, giving her a bonus of +24 to Search and Spot checks and a speed bonus of 30 ft.  

**Ravaged Form-Crown of Spiders:** Lolth’s body continuously exudes and generates spiders; this ability acts in the same manner as _crown of vermin_ but may be suppressed or restored as a free action by her at any time. If Lolth is in a form that is Huge or greater, however, the spiders only cover her abdomen, torso, and head and cannot attack anything within a 10’ radius. However, attacks on these parts of her body will provoke an attack from the Crown.  

**Ravaged Form–Digestion:** Should Lolth successfully bite an opponent and remain attached to them then each round they must make a Fort save (DC 56) or else their life has been drained out of them, resulting in 2d4 levels lost and healing Lolth for 5 hp/level lost by the victim. If Lolth does not have enough time to ‘properly’ take the body to her web for further experimentation, she will deliberately inject a bit of her venom into them just to make resurrection attempts that much harder.  

**Ravaged Form–Exoskeleton:** Lolth’s exoskeleton gives her a +2 Armor Class bonus.  

**Ravaged Form–Improved Darkvision:** Lolth sees an additional 120’ feet in the dark.  

**Ravaged Form-Kiss of the Demon Queen:** Once a day Lolth may choose to kiss an opponent with horrific results.  

A victim must make a Will save DC 56; if they have fewer than 16 HD then they take 2d4 vile Wisdom damage, 2d4 vile Intelligence damage and are _dominated_ one week for each point by which they failed the saving throw. A victim with more than 16 HD will not take Wisdom and Intelligence damage from Lolth’s Kiss, but is vulnerable to the _dominate_ effect and can only be controlled for one day for each point by which they failed the saving throw. This ability does not work on any deity or cosmic entity with equivalent or higher divine or virtual divine rank. A victim so dominated will obey Lolth or any of her manifestations such as through the Favor of Lolth.  

Any victim kissed is permanently penalized against any of Lolth’s further Special Abilities or psionic powers with a –10 Will penalty. The power of Lolth’s Kiss may only be broken through the casting of a carefully worded _wish_ on the victim followed by an _atonement_ spell. Otherwise they will be compelled to find the Demon Queen in order to betray those who had the audacity to challenge her power.  

Lolth may only have 16 individuals dominated in this manner at any given time; should she attempt to use her kiss on someone over this limit then they will take no damage from it and will have a +6 bonus to any saves against further uses of her powers for a month.  

**Ravaged Form-Magical Power:** Lolth may use _shapechange_ as a spell-like ability three times a day.  

**Ravaged Form-Salient Divine Ability: Know Secrets** Lolth can learn a creature’s entire history (including any embarrassing or vital secrets it might know) just by looking at it. This ability is similar to the _legend lore_ spell, except that it delivers instant results and the subject is allowed a Will save (DC 37) to avoid the effect.  

**Ravaged Form-Spinnerets:**Eight times a day the Demon Queen of Spiders may spin a web of Lolthsilk. These attacks resembles the web spell with the following exceptions: the webs are permanent, nonmagical, and cannot be dispelled except by Lolth as a free action when she is in visual range. Lolthsilk is shimmering and black-although it is called silk and serves much the same function, it is nothing of the sort as much as it is an expression of Lolth’s twisted mind given physical form. As such, although a Lolthsilk web only possesses 14 HP and a hardness of 10, it also possesses the same resistances as she does. Lolth can never become entangled in her own webbing and her fangs will automatically penetrate it.  

The DC’s for evading or breaking free from the webs are 26 and 32 respectively and in addition, a Lolthsilk web is coated with a toxin that deals 1d6 points of damage per round of contact (Fort DC 13 for half damage).  

Lolth may use webbing shot from one of her spinnerets in the following manner:  

Immobilizing Web: Lolth can shoot a sheet web from her spinneret at a range of 50 feet. An immobilizing web released in this manner is 60 feet square.  

Entangling Web: Lolth may focus a stream of webbing towards a single opponent up to 40 feet away and attempt to entangle them. Once the webbing has hardened, she may drag an opponent back to her at a rate of 10 feet/turn if they fail a contested Strength roll.  

Lolth’s spinnerets are highly mobile and may shoot either in front of Lolth or behind her.  

**Ravaged Form-Spiteful Gaze:** 3/day Lolth may focus the sheer hatred that she possesses for males into a baleful glare. All males who meet her crimson eyes must make a Will save DC 56 or be under the influence of a greater curse of her choosing.  

**Ravaged Form-Venomous Bite:** Virulent Poison (Fort DC 54). Lolth may choose not to inject venom into a wound if she wishes to play with her food first. However, should she inject a victim, then the toxin does an initial 1d8 Strength damage and a secondary 2d8 Strength damage as it dissolves their muscle tissue. The toxin itself lingers in the corpse of anyone killed during the initial or second round and must be removed before any resurrection attempts or else risk re-envenomation.  

**Abyssal Vehemence (Ex)**: Lolth’s physical presence is so disgusting that it causes lesser creatures to succumb to her hate and need to spread destruction and terror. All creatures within 600 feet of Lolth must succeed in a Will save 57\. Those who succumb to Lolth’s gross presence suffer one of the two following effects:  
Fright: Affected beings become shaken and suffer a –2 morale penalty on attack rolls, saves, and checks. The merest glance or gesture by Lolth makes them frightened, and they flee as quickly as they can, although they can choose the path of their flight.  
Madness: Lolth’s physical presence the grotesque evil incarnate in her being drives lesser beings insane per the insanity spell. The being remains stuck in a state of madness for one day for every point by which she failed the saving throw, after which time the victim is allowed another save. The madness exists until the victim successfully saves or the appropriate spells are cast by a 31st level being to purge the insanity effect.  
Lolth can make her servants, “worshippers,” beings of Chaotic Evil alignment, or a mixture of all three types immune to this effect as a free action. This immunity lasts one day or until Lolth dismisses it. However, Lolth cannot determine which effect takes place; there is a 50% chance each time Abyssal Vehemence is used that one or the other effect will impact near by victims.  
Other Demiurge and beings possessing divine ranks or virtual divine ranks equal to or higher than Lolth’s virtual divine rank are immune.  

Lolth can sense anything within one mile around the mentioning of her name, titles, or an item of importance to her. This power is barred from places associated with gods of goodness, the personal redoubts of the other Demiurges or any being that possesses divine rank or virtual divine rank.  

**Call Demons (Sp):** Thrice per day, Lolth may call Demons. Like all Demiurge, Lolth is under no special restriction for calling any kind of Demon, and may call up to 90 HD of these creatures per attempt. When she is in the Demonweb Pits she will typically call one or two Advanced Yochlols, which are also known as the Handmaidens of Lolth due to their origins and permanent state of servitude to her. In a combat situation Lolth will call Succubi for use as scouts and Mariliths as officers instead. Only in truly desperate circumstances will Lolth call Balors.  

**Call Drow(Sp):** Thrice per day, Lolth may call on 90 HD worth of Drow, who will be yanked away from whatever they are doing and automatically _gated_ to where Lolth is currently located. Her typical tactic is to summon high-ranking spellcasters to her location of which she can call two or three at once; they may then open additional _gates_ in order to bring the rest of her followers.  

**Call Spiders(Sp):** Thrice per day, Lolth may call on 90 HD worth of evil aligned intelligent arachnids, or nonsentient arachnids. Lolth’s breeding programs have been responsible for the creation of a wide array of bizarre arachnid creatures to act as her warriors.  

**Cosmic Corruption (Su):** So heinous is Lolth’s presence that she may corrupt an entire area with but a thought. Once per day as a standard action, Lolth may unhallow an area equal to 2100 feet. Lolth can apply the following spells to the unhallow effect (some of which are not listed as part of the unhallow spell in the Player’s Handbook): bane, bestow curse, contagion, deeper darkness, dispel magic, silence. Lolth will typically choose to curse all males that enter her unhallowed areas with –4 to all attack bonuses and saves, although there are circumstances in which she will choose contagion or dispel magic.  

The forces of righteousness disgust Lolth, who finds goodness and holiness repellent enough to give her pause. As a result, Lolth avoids hallowed ground. If Lolth finds it necessary to enter a hallowed site, she must make a Will DC save equal to 30 + the divine rank of the represented god + the god’s Charisma modifier; Lolth cannot use her spell resistance to overcome this effect. If Lolth succeeds in entering the hallowed area, the area immediately becomes unhallowed. Once Lolth breaches holy ground, the god in question is immediately alerted to her presence and will often (DM’s discretion) send an avatar or arrive in person to deal with the intrusion.  

**Divine Decadence (Ex):** Although not a god, Lolth possesses power that rivals that of true divine beings. Lolth possesses a virtual divine rank of 11 as described in the “Virtual Divine Ranks and Cosmic Entities Defined” article. On the Prime Material Plane or in the Ethereal Plane, Lolth can affect the land within 11 miles of her person as the divine ability Godly Realm described in Deities and Demigods, while in the Abyss she may affect the land within 16 miles of her person. Lolth’s preferences, as incarnated in her Web, are to make bizarre spatial changes, massive earthquakes to drag entire cities underground (where she feels more comfortable attacking), and the creation of utter darkness as if the stars and sun had never existed.  

**Demiurge Qualities (Ex):** Lolth is immune to electricity and poison; she possesses acid resistance 10 and cold and fire resistance 30\. Lolth may engage in telepathic communication with any creature within 100 feet and possesses blindsight within 500 feet. Lolth constantly detects good, detects magic, and true sees as a 31st level Sorcerer; she possesses immunity to polymorphing, petrification, or any other attack to alter her form. Lolth is not subject to energy drain, ability drain, or ability damage; she is also immune to mind-affecting effects. Lolth is immortal and cannot die from natural causes. Lolth does not age, and does not need to eat, sleep, or breathe.  

**Demon Goddess (Ex):** Lolth, out of all of the Demiurge, has the largest cult dedicated to her worship-namely a transplanar empire whose members in good standing are trained to follow her every whim. Drow follow Lolth or they die because otherwise the Drow loyal to Lolth hunt them down and kill them. Accordingly, Lolth’s priestesses run most large cities of the Drow as vicious matriarchal theocracies in which their power is only bounded by what they can dominate or warp without earning the disfavor of Lolth or sometimes, given her tendencies, her interests. The Drow worshippers of Lolth are infamous throughout the planes and due to their continual drive for expansionism seem to have a presence on (or rather, under) most of the well-known Prime Material Planes, a very large proportion of the lesser known planes, and just about any Plane that has a significant Underdark and isn’t intrinsically associated with good or law.  

The precise details of Lolth worship differ from city to city (in fact, Lolth often uses her powers to create subtle doctrinal differences in order to ‘test’ the Drow and pit them against each other to determine which is more fervent in their support for her). However, commonalities include:  

The superiority of the Drow over all other species, and Lolth over all other gods. Drow theology often includes an inverted version of the story of Lolth and Corellon in which he despised Lolth for her greatness compared to him.  

Spread the doctrine of Lolth to all creation. As the doctrine of Lolth is the superiority of the Drow that worship her, this means to spread themselves until they control all of the Prime Material Planes, and in fact, all Planes everywhere.  

Sacrifice to retain the favor of the Goddess Matron. The exact nature of the sacrifice varies, but typical victims include any good or good-aligned creatures that can be caught (especially elves and fey), or an individual’s family or ‘friends’. Sacrificial procedures range from slaughter in battle or assassination, to various forms of magical immolation, to extended torture sessions.  

Spiders and arachnids are holy as they are reflections of the Goddess Matron’s beauty. To kill a spider in a Drow city or near a Drow is to incur their unbridled wrath lest Lolth’s disfavor fall upon them.  

As a being of contradictions, however, there are times when Lolth herself walks obscure material planes deliberately for the purpose of spreading her message of capricious domination and knowledge to those vulnerable to it’s allure. For reasons lost to the universe aeons ago, these individuals are always elven. The results of these forays end up as Drow.  

Lolth may grant her worshippers spells among the following domains: Corruption, Evil, Darkness, Knowledge. Clerics of Lolth are typically known by titles such as Arachnes.  

Beyond the Drow, however, there are a wide array of other beings from virtually every other evil species not aligned with the Hells that have at least one or two representatives that worship her. If she suspects that a being may be ‘useful’ she has no hesitation about having her Drow make arrangements to give them transport to the place where they will do the most damage.  

**Entropic Wave (Su):** Lolth can unleash an explosion of corrupt, destructive, Abyssal power in the form of a wave that extends from her body. Lolth may use her Entropic Wave 11/day, dealing 19d12 points of damage. Lolth’s Entropic Wave explodes in a radius of 110 feet; victims caught in the wave may attempt a Reflex save DC 46 for half damage. Lolth’s Entropic Wave appears as a blackish-blue wall of interwoven arachnid legs that it’s few survivors describe as having a million acid-tipped spider claws crawling through their innards. Entropic Wave ignores mortal magic like anti-magic field, but may only remove one layer of prismatics per blast. Walls of force are not affected by Entropic Wave, while Divine Shields suffer full damage.  

**Learned Spell Immunity (Su):** If Lolth is affected by a spell cast by a particular spellcaster, she becomes immune to that spell when cast by that spellcaster.  

**Spell-Like Abilities:** At will—_animate dead, black tentacles, blasphemy, blur, charm person, chain lightning, cloudkill, create undead, darkness, deeper darkness, desecrate, destruction, detect chaos, detect good, detect law, detect magic, dispel good, distort summons, fear, forcecage, greater dispel magic, harm, hold person, greater invisibility, magic circle against good, magic circle against law, mirror image, morality undone, polymorph, protection from good, pyrotechnics, read magic, scramble portal, scrying, shatter, spectral hand, suggestion, summon monster IX_ (evil only), _symbol of death, telekinesis, greater teleport_ (self plus 1,000 pounds), _unhallow, unholy aura, unholy blight, wrack_ 6/day-_flesh to stone, fireball_ (delayed blast), _horrid wilting, implosion, inflict critical wounds_(mass), _temporal stasis_, 3/day, _power word-kill, power word-stun, ruin_ 1/day—_analyze dweomer, fire storm, greater ruin, peripety, planeshift, trap the soul_ 1/week-_Disjunction, Mass spider*, mindrape, seething eyebane_. Caster level 66th; save DC 27 + spell level. The DCs are Charisma-based. Lolth may cast all spells from the domain of Evil with a +1 caster level bonus. These spells are included in the list above.  

* Mass spider functions in all ways as Mass Frog. See the ELH for the precise details.  

**Spell Suck (Su):** If Lolth bites a foe, the foe loses one of its highest-level prepared spells or one of the spell slots for this day that it has not used. The victim chooses the prepared spell to lose. If the victim has no prepared spells or unused spell slots (either because it has exhausted its spellcasting for the day or because the victim is not a spellcaster), the bite instead deals 2 points of temporary Intelligence damage.  

**Favor/Disfavor of Lolth(Su):** 17/day Lolth may manifest her favor and disfavor through objects or persons of importance to her. Typical manifestations include a crimson pair of eyes, a smirking pair of lips, or an object becoming wreathed in black flames. While Lolth may use her _true seeing_ through such an object, she may only channel one special ability or spell into a manifestation and may not manifest through that same object or person until the next day. Lolth’s favor may confer any of the following benefits to an individual:  

nondetection  
sadism  
spiderclimb  
undetectable alignment  
+4 AC  
+2 to Intelligence or Charisma  
+10 to Knowledge (arcana, planes, or psionics)  
+10 Craft (poisonmaking)  
Sacrificial Knowledge  

Lolth may also grant to those who call upon her even greater favors once in their lifetime:  

Eight lies (undetectable by anyone unless they can cast _zone of truth_ or a similar spell to defeat the effect at a caster level higher than Lolth’s)  
Immunity to mind-altering effects and charms except Lolth’s.  
4 spells 9th level or lower that can be used as spell-like abilities.  
Half of all damage done for a single day is unholy.  

Should Lolth, however, feel disfavor she may opt to send a single creature loyal to her through an object, or channel the following spell-like abilities through it:  

Special Abilities: Weaver of Lies  
Spells: _bestow greater curse, darkbolt, gate, pyrokinesis, shatter_  

Lolth’s fickleness in terms of her favor is legendary. Often, even if the summoning procedure is correct to attract her ‘favor’ she will still foul an item and send a Demon she dislikes or wants to get rid of through a gate as a test to see how a summoner will deal with them. No aid from Lolth (if it comes at all) ever comes free; she expects a sacrifice in advance for each favor and an individual who recieves a greater favor from her and uses it in a way that pleases her is typically taken to the Demonweb Pits for ‘improvement’ to becomes a Yochlol. Individuals who fail to please Lolth are transformed into Driders and cast out of Drow society.  

This power is blocked from the personal redoubts of other Demiurges, places of good, or places that are hallowed to beings of greater divine or virtual divine ranking than her.  

Any being that worships Lolth, has recieved benefits through the Favor of Lolth, or has been killed through the Kiss of the Demon Queen may be judged by Lolth. If they are found to be weak (by her twisted standards) then she may choose to punish them accordingly. If slain by her then the victim must make a final Will save (DC 56) at the moment of death. Should they fail then the soul of the victim will be transported to the nearest Soul Weaver, where they will be used as building material for Lolth’s web.  

Any attempt to resurrect the body of someone Judged unworthy by Lolth instead brings them into unlife instead as an uncontrolled Bodak unless the resurrection attempt takes place at the location where their soul was incorporated into the web. Even if the location of the unworthy soul is known, the resurrection may only be attempted by a 31st or higher level Cleric.  

If Lolth is pleased with how someone has used her gifts, then at the moment of death their soul is transported to the Demonweb Pits and turned into a Yochlol. This, however, is extremely rare; perhaps on the order of one exceptionally depraved Arachne in a single decade.  

**Goddess Matron(Su):** Over the ages, Lolth has amassed an exceptional amount of mental and mystical power that she may use to further her own quest for rulership over all things. Lolth may cast spells as a 45th level Cleric with a caster level of 49th for the purposes of defeating spell resistance due to the feats Spell Penetration and Greater Spell Penetration, or manifest powers as a 45th level Telepath, allowing her to cast 7 epic spells/day with a maximal Spellcraft DC of 93 and manifest 7 epic powers/day with a maximal Psicraft DC of 93 respectively. The saving throws against Lolth’s abilities are 22+level of the spell and are 25+the level of the power involved. Lolth may additionally channel up to 45 power points into a single manifestation and use 503 power points in a single day.  

Lolth’s epic spells are typically used to breed creatures to better serve her foul will (of which she has several horrific rituals specifically developed for such purposes), and to control those who may be useful to her purposes. In comparison, her epic powers are used to cause mass delusions in order to better obtain the worship and obedience of all around her.  

Clerical Spells: 10/8+1/8+1/8+1/8+1/7+1/6+1/6+1/6+1/6+1/1\. Lolth has access to the Domains of Darkness* and Evil.  

* As described in the Book of Vile Darkness  

**Weaver of Lies(Ex):** Lolth is one of the most treacherous and manipulative creatures in existence. As such, she has access to several different powers that allow her to decieve and ensnare not only the individuals around her, but the items that they depend upon in order to attempt to protect themselves from her machinations.  

17 times a day, Lolth may tell any being within earshot a lie and make a Diplomacy check. If the victim fails a Will check afterwards, then for every day that they have failed it they believe completely and to the bottom of their heart the lie that Lolth has spoken to them. Only a being of greater or equivalent Virtual Divine Rank or true Divine Rank may even attempt to convince the victim differently from the mistruth that she has spoken, however the victim may make a new check every day spent in the Upper Planes with a +5 bonus to Will/day strictly for the purpose of discerning the truth of Lolth’s statements. This is a mind-altering sonic effect.  

Any magical item within Lolth’s sensory range that she has studied through a _analyze dweomer_ or Appraised, she may attempt to command through an Appraise check with the DC equal to bonuses+number of special abilities. If the item is intelligent then the Appraise check has a DC equal to the Ego rating+level of crafter when the item was built; if an item is carried then it saves at the same Will DC as it’s wielder. Should the item fail, then it will be considered an item of importance for the purposes of Lolth’s sensory abilities and may be observed like any other. Items that have been corrupted in this manner are physically identical but will resist being brought into hallowed areas. _Sense evil_ or _legend lore_ cast by a 31st level Sorcerer will reveal that the item has been corrupted somehow but not the precise details.  

If the item is brought within Lolth’s sensory range at any other time, then she may speak to it as a partial action and it’s full treachery will become evident. The item alignment will now permanently read as chaotic evil, and if intelligent, will attack any wielder who is disloyal to Lolth. Items may be cured by immersion in holy water blessed by a cleric of 31st level or higher.  

Any item built by Lolth directly, or built by an individual ‘inspired’ by her is automatically under the influence of her Weaver of Lies power. Should they be immersed in an attempt to cure them they will lose all of their special abilities permanently (although they will retain their plusses.)  

**Combat:** Lolth is a devious and horrible opponent to fight. When she chooses to do so, it is typically to advance one of her labyrinthine plots within plots. However, there are several commonalities in terms of her fighting behavior:  

Lolth prefers to use distance attacks and sacrifice relatively weak Drow with a prepared _sadism_ spell to build herself up, as well as summon in additional allies, uses psionics, and if there’s enough time, her Weaver of Lies against her attackers. Once enough chaos has been caused in her enemies along these lines, she actually attacks directly. When possible she takes victims alive in order to further her own 'projects' and leisurely extract everything worthwhile from them in the Demonweb Pits.  

While underground (which is most of the time for Lolth), she takes advantage effectively of the terrain by using spells to separate opponents through cave-ins and using her own webbing to attack opponents from surprising directions, such as from above them.  

In the rare event that she is ever caught unawares by superior opponents, she will cause as much destruction as possible in order to distract opponents, create darkness, and then gate away.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *