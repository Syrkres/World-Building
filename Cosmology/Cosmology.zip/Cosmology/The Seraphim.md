# The Seraphin, Stewards of the Upper Realms

The seraphim are the stewards of the Upper Realms. While they can and do enter into those places most holy to counsel with The Sarim, even they do not do so lightly; it is true that they return from whence lesser beings cannot, but they take extreme precautions on entering into the holiest places in the cosmos.  

The seraphim are the stewards of the ideals of good. In this, they are caretakers of great aspects that The Sarim themselves embody. Thus Aravaut embodies Faith, whilst Zadkiel holds stewardship over Prayer. As stewards, the seraphim actually have power to control, guide and/or oversee in relation to their trust.  

The seraphim choir was the first of the choirs to be organized, although The Sarim predate that event. Over the eons, various events have led to some changes in the membership of the choir, but they retain their original purpose: an appendage and aid to The Sarim in general, rather than necessarily tools of particular ethical differences in the Upper Realms. To further reflect this, the seraphim choir is headed by three angels, rather than one: the mighty Metatron, his twin Saldalphon, and the unfathomable Nafielon.  

It is rare for any angel of lesser "status" than a solar to join the ranks of the seraphim.