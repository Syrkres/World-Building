# The Kerubim, Guardians of the Upper Realms

The kerubim are the guardians of the upper realms. More specifically, they watch over the most sacred places in the upper realms, from Chronias in Heaven, to the mysterious isle where dwells Uriel.  

Though among the most powerful of the beings of good, the kerubim guard places that they themselves cannot enter - at least, they cannot enter them and return. Such a privilege is held only by the seraphim - those who have "entered in" to the various Holy of Holies - and the sarim who dwell in these places.  

Though an element of physical guardianship is implied with their duties, the kerubim are also spiritual guardians. They watch over small, yet important aspects of good. Thus Sanoi is the Defender of Life, whilst Baruch is the Kerubim Protector of Immortality. In their role as guardians, they have power to protect an ideal, without actually any right or authority to control or oversee that ideal. Such duties ultimately fall upon the shoulders of the sarim, who are the ideals themselves, or the seraphim, who act as stewards over ideals.  

More powerful members of the hashmallim, tarshishim and ophanim choirs (including solars) are sometimes called upon to take on the role of a kerub. Transcendent angels are rarely found below this choir, for those that are actively involved in the choirs.