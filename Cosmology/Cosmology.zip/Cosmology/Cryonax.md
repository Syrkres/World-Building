# Cryonax, Lord of the Ice Elementals
Huge Elemental (Cold, Extraplanar)  
Hit Dice: 40d8+600 (920 hp)  
**Initiative:** +7  
**Speed:** 40 ft., burrow (ice and snow only) 40 ft.  
**AC:** 54 (+7 deflection, +7 Dex, +7 insight, +25 natural, -2 size), touch 29, flat-footed 40  
**Base Attack/Grapple:** +30/+55  
**Attack:** Tentacle +45 melee (2d10+17 and 2d4 cold Dex plus freeze)  
**Full Attack:** 2 tentacles +45 melee (2d10+17 and 2d4 cold Dex plus freeze)  
**Space/Reach:** 15 ft. /15 ft.  
**Special Attacks:** Call cold creatures, chill aura, rebuke cold creatures, spell-like abilities  
**Special Qualities:** Damage reduction 25/-, immune to cold, Lord of Ice, regeneration 20, spell resistance 40, vulnerability to fire  
**Saves:** Fort +37, Ref +26, Will +26  
**Abilities:** Str 45, Dex 25, Con 40, Int 26, Wis 24, Cha 25  
**Skills:** Bluff +32, Climb +37, Concentration +58, Diplomacy +33, Hide +42, Intimidate +54, Jump +41, Knowledge (the planes) +50, Listen +50, Move Silently +50, Sense Motive +32, Spot +50, Survival +27 (+33 planes)  
**Feats:** Cleave, Cold Focus, Cold Spell Specialization, Combat Reflexes, Frozen Magic, Great Cleave, Greater Cold Focus, Icy Calling, Iron Will, Lightning Reflexes, Power Attack, Snowcasting  
**Epic Feats:** Epic Reflexes, Epic Will  
**Climate/Terrain:** Paraelemental Plane of Ice  
**Organization:** Solitary (Unique)  
**Challenge Rating:** 30  
**Treasure:** Triple Standard  
**Alignment:** Neutral Evil  

**_Call Cold Creatures (Sp):_** 3/day, Cryonax may call 1 monolithic ice paraelemental, 1d4 adult white dragons, 2d6 frost giants or abominable yeti, or 3d6 elder ice paraelementals.  

**Chill Aura (Su):** The air surrounding Cryonax is bitter cold, dealing 5d6 points of cold damage to everyone within 15 feet of him. Those who suffer damage from this ability must make succeed on a Fortitude save DC 45 or be _slowed_ as per the spell. The _slow_ effect lasts for 1d4 rounds after the character has stopped taking cold damage from Cryonax's aura.  

**Freeze (Ex):** Creatures struck by Cryonax's tentacles take 2d4 points of Dexterity damage. Resistance to cold reduces this damage as it would normal cold damage. (This is an exception to Cryonax's piercing cold power.) Immunity to cold prevents this damage. Those who take damage from Cryonax's tentacles must also make a Fortitude save DC 45 or be frozen in place, as a _flesh to ice_ spell. The effect wears off in 2d4 rounds. 10 points of fire damage applied to a frozen character reduces the duration of the effect by 1 round.  

**Rebuke Cold Creatures (Su):** Cryonax may rebuke or command creatures with the Cold subtype as a 40th level evil cleric rebukes undead. Nonelementals gain their Charisma modifier as "turn resistance" for the purposes of this ability.  

**Spell-like Abilities:** Always active- _detect good, see invisibility_; at will - _cone of cold, conjure ice beast IX, control temperature, frostfell slide, greater dispel magic, ice shape, ice storm, mind frost, move snow and ice, polar ray, suggestion, telekinesis, wall of coldfire, wall of ice_; 4/day - _blood snow, comprehend languages, freeze armor, mantle of the icy soul, mass frostburn, read magic, supress flame, waves of cold_; 1/day - _frostfell, ice assassin, ice rift, glacier;_ 1/week – _dire winter_ Caster level 40th, DC 17+ spell level (19+spell level for cold spells)  

**Lord of Ice:** Cryonax possesses the following traits.  
-Divine Rank 0  
-Is healed by cold damage  
-All cold damage dealt by Cryonax is considered _piercing cold_.  
-Weapons that sucessfully strike Cryonax take 5d6 points of cold damage. This damage is not quartered like normal for cold and objects. Weapons that are enchanted with cold or fire (such as a _flametongue_) do not take this damage.  

**Regeneration (Ex):** Fire deals normal damage to Cryonax. When in an area of extreme cold (-50 degrees F), Cryonax's rate of regeneration is doubled.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *