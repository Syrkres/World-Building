# Pale Night, Demon Queen of Ravens, Mother of Darkness
Demiurge  
Medium-Sized Outsider (Chaotic, Evil, Extraplanar)  
**Hit Dice:** 55d8 (infernal) + 20d6 (rogue) + 10d6 (void incarnate) + 935 (1555 hp)  
**Initiative:** +23 (+15 Dexterity, +8 Superior Initiative)  
**Speed:** 110 ft., fly 270 feet (perfect)  
**AC:** 96 (+37 natural, +19 deflection, +15 Dexterity, +15 profane), touch 59, flat-footed 96  
**Base Attack/Grapple:** +70/+79  
**Attack:** Fingernails +79 (1d8+9; 18-20x3)  
**Full Attack:** Fingernails +79/+74/+69/+64 (1d8+13; 18-20x3)  
**Space/Reach:** 5ft/5ft  
**Special Attacks:** Abyssal Vehemence, call Demons, call fiendish dire ravens, call consort, Cosmic Corruption, Entropic Wave, spell-like abilities, spells, sneak attack +10d6, crippling strike, null strike, Black Melody, Dark Wind  
**Special Qualities:** Demon Prince Qualities; Decadent Divinity; Demon God; Ravaged Forms; DR 25/cold iron, epic, good, and lawful; SR 74; trapfinding, trap sense +6, uncanny dodge, improved uncanny dodge, evasion, slippery mind, improved evasion, defensive roll, blank aura, void presence, mettle of fortitude, blank mind, mettle of will, improved mettle of fortitude, empty form, improved mettle of will, Princess of Ravens, Blasphemous Joining  
**Saves:** Fort +55 Ref +61 Will +59  
**Abilities:** Str 28, Dex 40, Con 33, Int 35, Wis 40, Cha 48  
**Skills:** Balance +78, Bluff +79, Concentration +98, Diplomacy +85, Disable Device +61, Disguise +83, Escape Artist +77, Forgery +72, Gather Information +78, Hide +82, Jump +65, Knowledge (arcana) +115, Knowledge (history) +80, Knowledge (religion) +67, Knowledge (the planes) +97, Listen +79, Move Silently +88, Perform (Oratory) +60, Scry +74, Search +82, Sense Motive +67, Sleight of Hand +70, Spellcraft +128, Spot +84, Survival +83, Tumble +100  
**Feats:** Combat Casting, Eschew Materials, Spell Penetration, Greater Spell Penetration, Improved Initiative, Quicken Spell, Dodge, Lightning Reflexes, Greater Spell Penetration, Weapon Finesse, Skill Focus (Spellcraft), Combat Reflexes, Blind-Fight (domain power), Heighten Spell  
**Epic Feats:** Blinding Speed, Epic Spell Penetration, Epic Spellcasting, Improved Combat Casting, Ignore Material Components, Superior Initiative, Epic Dodge, Dexterous Fortitude, Epic Skill Focus (Spellcraft), Automatic Quicken Spell (x6), Improived Heighten Spell  
**Climate/Terrain:** Any land and underground (Random Layer in The Abyss)  
**Organization:** Unique (Solitary) or flock (Pale Night, 100-300,000 ravens)  
**Challenge Rating:** 85  

Whispers are abound in the cosmos, whispers of an ancient evil thought destroyed. These whispers say this great evil is manipulating events on the primes, the hells, and even the great skies above towards it’s own dark goals. These whispers are never more than that, for those who speak out loud are silenced. Heaven has yet to hear these whispers, but when it does, soon no doubt, the cosmos will shake, and the celestial host will be roused, for heaven has once ignored these whispers, a mistake that cost them dearly….  

Pale Night, the Demon Queen of Ravens, Mother of Darkness. An enigmatic being forgotten by creation. Pale Night has been a blight on the multiverse since the creation of the primes, and has shaken the foundations of the multiverse to their core. Her beginnings are relatively unknown, some believe she was a fallen celestial, others that she was a demon lady of sexual domination, either way she was relatively unimportant in the scheme of things. This all changed when Pale Night discovered a great artifact known as the Midnight Void. The Midnight Void corrupts all that touches it, and Pale Night could not resist it’s power. She disappeared from the multiverse for a millennia, gathering the Artifact’s secrets and making them her own. When she returned Pale Night was a powerful entity, almost her entire self changed, but she remembered one thing from the time before, that sex can give power.  

Pale Night became the consort of a being known only as Chaos (some debate this was Demogorgon, but either way she is sometimes called Old Night for her relationship with this being), she leeched off it’s power to further her own gains, and was cast out. Pale Night moved on, realizing great power could be achieved in this way, and eventually her priorities changed… and so did she. Pale Night became a Demiurge seeking to control others, whether sexually or not. Her long line of consorts spawned some of the most powerful demons in creation, including Graz'zt, Demon Prince of Shadows, Vucarik of Chains, and Lupercio, Baron of Sloth.  

Year later, for reasons unknown, Pale Night developed a hatred of the Realms Above unparalled, and began using her manipulative powers to form a great abyssal army, nearly infinite in numbers. And yet Heaven hasd faced many great threats before, and they knew such an army could not breach the Gates of Heaven, and so they offered no challenge. Day by day the Abyssal army dwindled, hundreds of thousands deserting and dying, and Heaven was confident that soon it would be completely gone.  
However, on the thirteenth day of the siege, Heaven was betrayed by one of their own. The great Seraph Sedirenite, Lord of the Hunt opened the gates, allowing the vile hordes of the Abyss to pour through. They were intent on despoiling Paradise, but that was not to be. Pale Night heself was betrayed by her son Graz'zt, who abandoned her at this crucial moment, taking with him half the demonic army. His mother's screams echoed throughout the cosmos as he left to carve out his own abyssal kingdom. Seeing this great betrayal, the hosts of Heaven rallied behind the very Seraph responsible for opening the gates to evil. They drove her remaining forces out and closed the gates, assuming Pale Night to be dead. Sedirenite, who had twice betrayed, once good, once evil, eventually joined the ranks of the Lords of Freedom.  

But Pale Night was not destroyed, only her physical form shattered, her malevolent spirit eventually reforming. Pale Night swore vengeance against her son Graz'zt, against her former lover Sedirenite, against all of creation. But, she has remained hidden, waiting and regaining strength. She has enslaved hundreds of mortal rulers across the primes, bending them to her will, yet hiding it. She has had many consorts, dominating them and leeching off their resources. There are those in heaven who suspect she has survived, and seek out the signs of her return, Sedirenite among them. They fear and dread the day she comes for heaven.  

Pale Night is now forced to compete with her son, Graz'zt, because both have the same ultimate goal, uniting the lower planes and destroying heaven. However, while Graz'zt favors a more direct approach, Pale Night works from behind the scenes. Yet Graz'zt is unaware of his competition, and some of his most trusted servants are slaves of Pale Night’s. Pale Night is partially responsible for his loss of power, in that she helped persuade Iggwilv to summon and hold Graz'zt prisoner on a prime world, where Iggwilv could sire a child. To this day, Graz'zt remains ignorant of his mother's survival, or her role in his imprisonment.  

Also, Pale Night greatly fears and hates the Prince of Demons, Demogorgon, for his power and his great intellect. She knows he is totally insane (even more so than most demons), and will stop at nothing to destroy the cosmos. But she hesitates in her attempts to destroy him, because she both fears him, and sees him as a possible ally. Demogorgon makes attempts to halt her power growth, but she is aware and takes necessary step to prevent this, just as she attempts subtly to sabotage his efforts, to no avail. But is fated that one day they will meet, but what comes from it no one can predict.  

In recent years as her reach extends across the primes, Pale Night has developed an affinity with birds, especially ravens. Her few servants believe the reason is because her newest consort, the fellow demiurge Pazuzu, is strongly associated with flying creatures. Either way she has learned how to use these small, mostly unnoticed creatures to spy on holy orders, and cause havoc on the primes. But now word is spreading, and ravens are being hunted by the Knights of Baphomet, her last consort, for he is angry and jealous that she left him for “some demonic pixie”. Both her and Pazuzu are amused, but if Baphomet in any way endangers her or her secrets…. Pazuzu is still unaware of her true nature, believing her to be some lesser demonic entity.  

Pale Night’s physical appearance is probably the least demonic of all demons, and many have underestimated her for it. She appears as a stunningly beautiful human or elf woman with raven black hair, piercing gray eyes, and a perfect figure. She is always wrapped in the Midnight Void, which takes the appearance of shifting gray cloak on the outside, and appears to lead into the nether realm when you glimpse the inside.  

**The Tower of Ravens**  

Pale Night’s personal enclave is the Tower of Ravens, a great shadowy monolith taking many forms and names. It’s original home was the triple layer of Azz’grat, and when Pale Night was betrayed, Graz'zt came home to sit on her dark throne, he found her palace keeping him out. It soon uprooted itself from the city, killing thousands of demons in the process, and plane shifted away. Graz'zt presumed it had found its own freedom, and never laid eyes on the tower again.  

The Tower of Ravens is in reality an ex-suitor, a Demon Lord that has been bound into construct form and compelled to slavish loyalty to Pale Night, it can assume the terrain of it’s surroundings. When within the maze of Baphomet, it took the form of a tall spidery tower, walking above the maze, picking out loners for food, or other evil purposes. Now, Pale Night consorts with Pazuzu, the tower has taken the form of a mile long airship, similar to the shape of a demonic raven, bristling with weapons.  

**Combat**  

Pale Night rarely enters combat herself, leaving it to lesser beings, and usually retreats to the impregnable Tower of Ravens. On the occasions that she succumbs to bloodlust or has some unknown purpose for fighting, she makes a very formidable opponent.  

Pale Night often opens combat at a distance, using her spells and leeched abilities to weaken her foes. She then summons Dark Winds before closing to melee. In melee combat she will Swarm opponents while the winds weaken and confuse them. If faced with stiff resistance, she retreats to a distance, calling her concubine, and filling the area with demons and demonic ravens. Then she will either leave, becoming uninterested, or enter the fray again with different tactics.  

**Divine Decadence (Ex):** Although not a god, Pale Night possesses power that rivals that of true divine beings. Pale Night possesses a virtual divine rank of 18 as described in the “Virtual Divine Ranks and Cosmic Entities Defined” article. On the Prime Material Plane or in the Ethereal Plane, Pale Night can affect the land within 18 miles of her person as the divine ability Godly Realm described in Deities and Demigods. In most cases, Pale Night will seek to cause tremendous damage, changing gravity and magic traits, and occasionally blanketing the area with a bone numbing chill.  

**Demon Prince Qualities (Ex):** Pale Night is immune to electricity and poison; she possesses acid, cold, and fire resistance 10\. Pale Night may engage in telepathic communication with any creature within 100 feet. Pale Night constantly detects good, detects magic, and true sees as a 31st level Sorcerer; she possesses immunity to polymorphing, petrification, or any other attack to alter her form. Pale Night is not subject to energy drain, ability drain, or ability damage; she is also immune to mind-affecting effects.  
Pale Night can sense anything within one mile around the mentioning of her name, titles, or an item of importance to her. This power is barred from places associated with gods of goodness, the personal redoubts of Demiurges or any being that possesses divine rank or virtual divine rank.  
Pale Night is immortal and cannot die from natural causes; she does not age, and does not need to eat, sleep, or breathe.  

**Abyssal Vehemence (Ex):** Pale Night’s physical presence is so disgusting that is causes lesser creatures to succumb to her hate and need to spread destruction and terror. All creatures within 600 feet of Pale Night must succeed in a Will save 56\. Those who succumb to Pale Night’s gross presence suffer one of the two following effects:  
_Fright:_ Affected beings become shaken and suffer a –2 morale penalty on attack rolls, saves, and checks. The merest glance or gesture by Pale Night makes them frightened, and they flee as quickly as they can, although they can choose the path of their flight.  
_Madness:_ The grotesque evil incarnate in Pale Night’s physical presence drives lesser beings insane per the insanity spell. The being remains stuck in a state of madness for one day for every point by which she failed the saving throw, after which time the victim is allowed another save. The madness exists until the victim successfully saves or the appropriate spells are cast by a 31st level being to purge the insanity effect.  
Pale Night can make her servants, “worshippers,” beings of Chaotic Evil alignment, or a mixture of all three types immune to this effect as a free action. This immunity lasts one day or until Pale Night dismisses it. However, Pale Night cannot determine which effect takes place; there is a 50% chance each time Abyssal Vehemence is used that one or the other effect will impact near by victims.  
Other Demiurge and beings possessing divine ranks or virtual divine ranks equal to or higher than Pale Night’s virtual divine rank are immune.  

**_Call Demons (Sp):_** Thrice per day, Pale Night may call Demons. Like all Demiurge, Pale Night is under no special restriction for calling any kind of Demon, and may call up to 90 HD of these creatures per attempt. Pale Night has an tendency to call Glabrezus for their deceitful ways, but if things go badly Pale Night will summon Balors.  

**_Call Fiendish Dire Ravens (Sp):_** Thrice per day, Pale Night may call on 90 HD worth of fiendish dire ravens (22 ravens). The stats for these creatures are below.  

**_Call Concubine (Sp):_** Once per week, Pale Night may call her concubine, whatever it might be. She does this reluctantly, knowing the her concubines dislike coming at beck and call. Once summoned, a concubine is under the compulsion to grant her a wish or give her aid, but not to the point where it might be harmful to itself.  

**Cosmic Corruption (Su):** So heinous is Pale Night’s presence that she may corrupt an entire area with but a thought. Once per day as a standard action, Pale Night may unhallow an area equal to 1925 feet. Pale Night can apply the following spells to the unhallow effect (some of which are not listed as part of the unhallow spell in the Player’s Handbook): bane, bestow curse, contagion, deeper darkness, dispel magic, silence. In most situations, Pale Night will select dispel magic.  

The forces of righteousness disgust Pale Night, who finds goodness and holiness repellent enough to give her pause. As a result, Pale Night avoids hallowed ground. If Pale Night finds it necessary to enter a hallowed site, she must make a Will DC save equal to 30 + the divine rank of the represented god + the god’s Charisma modifier; Pale Night cannot use her spell resistance to overcome this effect. If Pale Night succeeds in entering the hallowed area, the area immediately becomes unhallowed. Once Pale Night breaches holy ground, the god in question is immediately alerted to her presence and will almost always (DM’s discretion) arrive in person to deal with The Princess of Ravens.  

**Demon God (Ex):** Even though she is among the greatest of the Demiurge, Pale Night has very few worshipers. Across the entire cosmos Pale Night has fewer than a thousand worships, but all of them are powerful. The reason so few mortals venerate her is because of the great lengths she has taken to hide herself from creation. She only has a small cadre of Demons and other followers, all of them completely loyal, almost to the point of losing their own identities. Whether mortal or not, clerics of Pale Night go by many different names; Childen of Darkness and Ravens are two of the most common. Clerics of Pale Night have access to the Chaos, Darkness, Evil, and Trickery domains. The worshipers of Pale Night have no common goal except to sow the seeds of chaos and darkness.  

**Entropic Wave (Su):** Pale Night can unleash an explosion of corrupt, destructive, Abyssal power in the form of a wave that extends from her person. Pale Night may use her Entropic Wave 12/day, dealing 22d12 points of damage. Pale Night’s Entropic Wave explodes in a radius of 120 feet; victims caught in the wave may attempt a Reflex save DC 48 for half damage. Pale Night’s Entropic Wave appears as a huge flight of ravens, their blood-tipped beaks issuing a dreadful cry. Those struck by the Wave that managed to survive claim that they felt as if their bodies were being picked apart by the savage birds. Such people have a tendency to flinch every time they see a raven. Entropic Wave ignores mortal magic like anti-magic field, but may only remove one layer of prismatics per blast. Walls of force are not affected by Entropic Wave, while Divine Shields suffer full damage.  

**Ravaged Form - Sorcerous Might (Sp):** Pale Night is a sorceress of great and terrible power, and casts arcane spells as a 21st level sorcerer, with the benefits of several spell knowledge and improved spell capacity feats. She also receives a +15 bonus to Spellcraft and Knowledge (arcana).  

**Ravaged Form - Epic Magic Power: _enslave_** _(Sp):_ Once per day as a standard action, Pale Night can cast enslave. She does not need to roll a Spellcraft check. When Pale Night calls on this effect, she makes a permanent thrall of any living creature. See the Epic Level Handbook for more information on enslave and Epic Spells. Pale Night often uses this to enslave mortal rulers, and important nobles across the cosmos.  

**Ravaged Form - Medium-Sized:** Pale Night is the size of a normal human.  

**Ravaged Form - Alternate Form: Swarm of Ravens (Su):** Three times per day as a standard action Pale Night may assume the form of a Colossal sized raven swarm. While in raven form Pale Night is immune to physical damage (because there are hundreds of thousands of ravens in her swarm), spells or abilities that target fewer than 100 individuals, all her attacks automatically hit, dealing 12d6 damage, and have the following qualities for overcoming DR: Epic, Chaotic, Evil, Adamantine. Also Pale Night may not use spells, spell-like abilities, or other special abilities, she retains all special qualities. When in swarm form Pale Night can occupy any area of 50 feet by 50 feet, regardless of other creatures being there, and may attack each creature in her occupied area once per round. As a free action Pale Night may split the swarm into 10,000 ravens, each holding her essence, and unless they are all killed, she lives. She may resume her standard form as a standard action, whether in swarm or a single raven.  
Distraction (Ex): Any living creature vulnerable to the swarms attack that begins its turn in the swarm’s square is nauseated for 1 round; a Fortitude save DC 56 negates. Spellcasting or concentrating on a spell in this area requires a Concentration check (DC 20 + spell level). Using skills that require patience or concentration requires a DC 20 Concentration check.  

**Ravaged Form - Abyssal Talons:** Pale Night has short razor-sharp fingernails, tainted with her evil. When in humanoid form, Pale Night’s fingernails are deadly weapons and are treated as Epic, Chaotic, Evil, and Adamantine for the purposes of DR.  

**Ravaged Form - Creeping Shadow (Su):** Anything hit by Pale Night’s swarm attack must make a Fortitude save DC 56, or begin to lose it’s body to the shadow. A creature that fails takes 3d6 strength and dexterity damage as their body deteriorates and must make a second save, this time Will of 56, or go permanently insane. The victim must continue to make Fortitude of 56 saves every six days or take another 3d6 strength and dexterity damage until he is cured (see below) or dies. This vileness begins to turn the blood in the veins black (which shows through most skins), and eventually the extremities as well. Only a Miracle or Remove Curse spell cast by a 31st level cleric , cosmic entity, or god can end this process.  

**Spell-Like Abilities:** At Will -- _animate dead, blasphemy, blur, charm person, create undead, damning darkness, darkbolt, darkness, darkvision, deeper darkness, desecrate, destruction, detect good, detect law, detect magic, dispel good, displacement, dread word, dream, ethereal jaunt, Evard’s black tentacles, fear, forbidden speech, greater dispel magic, grim revenge, harm, hold person, improved invisibility, magic circle against good, magic circle against law, major image, morality undone, plane shift, read magic, screen, scrying, shadow walk, suggestion, symbol of death, telekinesis, teleport without error, unhallow, unholy aura, unholy blight, unhallow, utterdark, wall of force_. 6/day -- _implosion, polymorph any object, soul’s treasure lost, wall of deadly chains, wave of pain, word of chaos[i/]. 3/day -- [i]power word-kill, power word-stun, ruin_. 1/day -- _demand, enervation, greater ruin, hellball, mass hold monster, meteor swarm, Mordenkainen‘s disjunction, time stop_. 1/week -- _gate, mind rape, refuge, vision_  
Pale Night also casts spells from the Darkness domain as detailed in the Book of Vile Darkness at will; these spells are included in the list above. These abilities are as spells cast by a 61st level Sorcerer (save DC 29 + spell level).  

**Demon Queen of Ravens (Su):** Over the many ages, Pale Night has begun to exert some limited control over nature, corrupting it’s natural beauty into a twisted abyssal reflection. Her first ‘achievement’ was domination over ravens. All ravens within 666 feet are immediately under her control, and temporarily gain the fiendish template. Furthermore she may inhabit the body of any raven in Creation 3/day for one hour. While in the body of a raven she may enter holy sites and sanctuaries without any hesitation, but only for six minutes per transformation. This does not unhallow these sites, and the god in question is not alerted if she leaves before the six minute time period expires. While in raven form she may cast in spell or spell-like ability she knows through the raven.  

**Blasphemous Joining (Su):** Pale Night has had many consorts over the millennia, and through this terrible ritual bind them to her. Pale Night receives 1d3 of her consorts special abilities or qualities, may summon the consort, and has complete access to its realm. Also she may use the Soul Link power on her consort. She has never consorted with anything that has less power than a demon prince, but her consorts are not always demons. At least one has been a celestial who has since fallen and become a demon. In return, she may grant her consort an wish a day, sexual favors, and most valuable of all - her expert advice.  
Also Pale Night may leech off of others' souls. The ritual that establishes this link lasts one hour, and the target does not have to be willing, or even knowing. Cosmic entities and gods of higher VDvR or DvR are immune to this ability. Pale Night may only try to establish the link once on a particular creature, and must overcome it’s spell resistance .* Pale Night’s consorts are always linked to her, this ends when she rejects them or otherwise ends the consortship. The ritual must have the willing (may be duped, even dominated, or forced by contract) sacrifice of a mortal. Pale Night may only have six links at a time, and may drop one to add another. Once per day, Pale Night may leech this link, temporarily granting her any spell**, spell-like ability**, feat**, skill ranks in a single skill, or natural attack the subject might have; she may only choose one of those. Once per week Pale Night may leech a special ability or quality***. It acts as if the creature had used that ability (so if a spell, it is used up, if it was already used up she cannot access it).The subject might never realize what is happening, and that is the way Pale Night likes it.  
* - The creature receives no save, as the ritual is not directly harming it.  
** - Spells and spell-like abilities are converted over to chaotic and evil versions. If it cannot be converted Pale Night may use as-is.  
*** - Special abilities and qualities may only be used once (if it has a no duration and is an effect then it remains for one week) and are modified by the DM to be chaotic and evil.  

Pale Night has gained the following special abilities and qualities from her current consort, Pazuzu:  
**Foul Air (Ex):** In many ways, Pazuzu is the patron of evil flying creatures. His very presence empowers them and they obey virtually any command his issues. Any and all evil flying creatures (save Fiends), like Harpies, Perytons, and even chromatic Dragons with 20 or fewer HD obey Pazuzu as if charmed so long as they are within 600 feet of the Demiurge of Abyssal Air. Neutral creatures of up to 30 HD behave in the same manner. Furthermore, Pazuzu can grant any evil flying creatures regardless of HD gain maximum hit points per die and receive +6 circumstance bonuses to attack rolls, damage, and saving throws 3/day for up to 12 rounds each time while within 600 feet. Good creatures do not fare as well as their evil counterparts. 3/day, Pazuzu can cause all good aligned flying creatures (including Celestials) to make a Will saving throw DC 42; those that fail suffer severe nausea from the evil in the air, suffering -6 circumstance penalties to attack rolls, damage, and saving throws while within 600 feet of Pazuzu. This affliction lasts for 12 rounds. Foul Air does not affect beings that do not fly “naturally.” Thus, a Human under the affects of a fly spell would not be affected by either element associated with Foul Air.  

**Winds of Disease (Ex):** Perhaps Pazuzu’s most feared attack, Winds of Disease allows the Demiurge of Abyssal Air to spread a veritable plague to all mortal creatures within its area of effect. 1/day, Pazuzu may cause a seemingly harmless, if forceful, blast of air to extend from his body. All mortals within 600 feet of Pazuzu have potentially contracted 2d8+1 of the diseases listed on p. 75 of the Dungeon Master’s Guide or the Book of Vile Darkness. So potent is power that even beings typically immune to disease, like Paladins, run a 50% chance of contracting something (such beings need to make a percentile check for each infection). After determining how many and which diseases the victim contracted, a separate Fortitude save DC 42 must be made for each potential infection. From this point, follow the normal rules for diseases and their effects. Bear in mind that some of these diseases are contagious and can spread rapidly.  

**Black Melody (Su):** Six times per day, Pale Night may sing a haunting melody, worming her way inside her enemies’ heads. When Pale Night sings this song up to 13 creatures who hear it must make a Will save DC 56 or become one of Pale Night’s “sleeper agents”. Those affected may act normally, and are in fact still in control until Pale Night decides to use them. When she uses them she gives them a mental command (which is relayed to anywhere in the multiverse), if any of them believe it is harmful to itself, then it gets to make a second Will save DC 56, if it succeeds, then it is out of her control, if it fails it must follow the order. The order wears off if not completed in 66 days. Pale Night may only have 13 sleeper agents at a time.  

**Dark Winds (Su):** Thrice per day, as a standard action, Pale Night may call upon dark winds. All creatures within 600 feet, excepting Pale Night and those of her choosing, are buffeted by tornado force winds and a changing environment. Every round a creature is within the winds, it makes a Reflex save DC 56 or is affected by one of the following:  
1d% - effect  
1-30 - No Effect  
31-40 - 3d6 vile* strength damage  
41-50 - 3d6 vile* dexterity damage  
51-60 - 3d6 vile* constitution damage  
61-70 - 3d6 vile* intelligence damage  
71-80 - 3d6 vile* wisdom damage  
81-90 - 3d6 vile* charisma damage  
91-100 - 1d6 vile* damage to each ability score  
In addition, a creature affected also takes 6d6* sonic damage per round and must make a Will save DC 56 or the howling winds drive him insane (as the spell insanity, but only a 31st level cleric, cosmic entity, or god can remove it). The Dark Winds last for 13 rounds.  
* This damage may only heal, or be healed on consecrated or hallowed ground, and ignores the Damage Reduction of good-aligned creatures. Also this damage may not reduce an ability below 1.  

Caster Level 21st; Spell DC 29+level  
**Spells Known:** 9/5/5/4/4/4/3/3/3/3 + any 5 **Epic Spells Known:** up to DC 138  

**Spells Per Day (0-19th level):** 6/11/11/11/10/10/10/10/9/9/4/3/3/3/3/2/2/2/2 **Epic Spell Per Day:** 8  

0-18th level spells are automatically quickened.  

Fiendish Dire Raven  
Medium-Sized Animal  
]HD: 4d10+8 (30 hp)  
**Initiative:** +7  
**Speed:** 20 ft., fly 50 ft. good  
**AC:** 22 (+7 dex, +5 natural); touch 17; flat-footed 15  
**Base Attack/Grapple:** +4/+6  
**Attack:** Claw +11 (1d6+3 treated as magic)  
**Full Attack:** 2 Claws +11 (1d6+2 treated as magic) and Peck +6 (1d8+1 treated as magic)  
**Space/Reach:** 5ft/5ft  
**Special Attacks:** Smite Good (+4 damage)  
**Special Qualities:** Low-light vision, Dark vision (60 ft), DR 5/magic, Fire and Cold resistance 5, SR 9  
**Saves:** Fort +6 Ref +11 Will +3  
**Abilities:** Str 14 Dex 24 Con 14 Int 6 Wis 14 Cha 6  
**Skills:** Listen +5, Spot +6  
**Feats:** Weapon Finesse, Flyby Attack  
**Environment:** The Infinite Layers of the Abyss)  
**Organization:** Solitary or Flock (5-22)  
**CR:** 3  
**Alignment:** Always Chaotic Evil  
**Advancement:** 5-6 medium, 7-10 large  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *