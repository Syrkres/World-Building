# Tiamat, The Chromatic Dragon, Queen of Dragons, Sentinel of the First
Archdevil Advanced Red Dragon (Age Catagory 28)  
**Type:** Colossal+ Dragon (Lawful, Evil, Extraplanar)  
**Hit Die:** 90d12 + 2430 (3510 hp)  
**Initiative:** +16 (+8 dexterity, +8 superior initiative)  
**Speed:** 40 ft., fly 250 ft, clumsy (or fly 200, perfect)  
**Armor Class:** 120 (-8 size, +25 deflection, +8 dexterity, +89 natural, +6 profane), touch 31, flatfooted 112  
**Base Attack/Grapple:** +90/+145  
**Attack:** Bite +125 melee (9d8+35)  
**Full Attack:** Up to 5 Bites +125 melee (9d8+35), 2 Claws +123 melee (6d6+17), 2 Wings +123 melee (6d6+17), 1 Tail Slap +123 melee (6d8+52 and poison)  
**Space/Reach:** 30 ft./ 20 ft. (30 ft. bite)  
**Special Attacks:** Breath Weapons, call devils, charm reptiles, corrupt water, create/destroy water, crush (8d6+52), diabolical adaption - [assume alternate form, call consort, command dragons, The Chromatic Dragon], diabolical aura, freezing fog, the presence of hell, sound imitation, spell-like abilities, spells, tail sweep (3d8+52 and poison).  
**Special Qualities:** Blindsense, diabolical adaption - [dragon god, mistress of elements, sentinel of the first, spell immunity], ice-walking, keen senses, Tiamat qualities, water breathing.  
**Saves:** Fort +87, Ref +68, Wil +76  
**Abilities:** Str 80, Dex 26, Con 65, Int 40, Wis 42, Cha 60.  
**Skills (2046):** Appraise +108, Bluff +118, Concentration +120, Diplomacy +148, Escape Artist +101, Hide +85, Intimidate +128, Jump +128, Knowledge (Arcana) +108, Knowledge (History) +108, Knowledge (Nature) +108, Knowledge (Nobility and Royalty) +108, Knowledge (the Planes) +108, Knowledge (Religion) +108, Listen +109, Move Silently +101, Search +108, Sense Motive +109, Spellcraft +118 (+128 for scrolls) (+128 for epic spells if variant rule in force), Spot +109, Swim +128, Use Magic Device +118 (+128 for scrolls).  
**Feats (24):** Corrupt Spell-like Ability (B), Dark Speech (B), Cleave, Combat Casting, Combat Reflexes, Empower Spell, Eschew Materials, Extend Spell, Flyby Attack, Great Cleave, Heighten Spell, Improved Grapple, Improved Initiative, Improved Natural Attack (Bite), Improved Sunder, Maximise Spell, Multiattack, Power Attack, Quicken Spell, Silent Spell, Snatch, Still Spell, Innate Spell (_heightened_ Miracle {11th level}), Innate Spell (_empowered_ Energy Drain), Quicken Spell-like Ability (_heightened_ Miracle {11th level}), Quicken Spell-like Ability (_empowered_ Energy Drain)  
**Epic Feats (7):** Epic Spellcasting, Expeditious Metamagic, Improved Combat Casting, Improved Heighten Spell, Improved Spell Capacity x10 (B), Penetrate Damage Reduction (Adamantine), Penetrate Damage Reduction (Cold Iron), Superior Initiative  
**Enviroment:** Avernus, or the Material Plane  
**Organisation:** Tiamat, and five chromatic Great Wyrms of different colours.  
**CR:** 67  

**Combat:**  

Tiamats weapons count as adamantine, cold iron, epic, evil, lawful, and silver for the purposes of penetrating damage reduction.  

**Special Abilities:**  

**Blindsense (Ex):** Tiamat can pinpoint creatures within a distance of 60 feet. Opponents Tiamat can’t actually see still have total concealment against the dragon.  

**Breath Weapons (Su):** Each of Tiamat's heads (see the **The Chromatic Dragon** Diabolical Adaption) can use a different breath weapon once every 1d4 rounds. One head can produce a line of acid, one a line of lightning, one a cone of acid, one a cone of fire, and one a cone of cold. Each of these do 56d10 of the appropriate kind of damage, with a reflex save DC 82 for half. A line is 5 feet high, 5 feet wide, and 140 feet long. The cone is 70 feet long, and is that high and wide at its broadest point.  

**Call Devils (Sp):** As a standard action, Tiamat can attempt to call Devils. The Arch-Devil may call up to three times a day, 18 Lemures, 9 Erinyes or Barbazu, 7 Osyluths or Hamatulas, 6 Cornugons or Gelugons, or 3 Pit Fiends. Unlike most other Archdevils, Tiamat is not outcast from hell, so her call is always answered. Since these Devils are called, they have the ability to summon other Devils as their Monster Manual descriptions allow. Tiamat is capable of trying to call Devils not listed above, but in the same limited quantity based upon CR, she commonly calls upon her own servants, the abishai. Call Devils functions as a 9th level spell.  

**Charm Reptiles (Sp):** Tiamat can use this ability three times per day. It works as a mass charm spell that affects only reptilian animals. Tiamat can communicate with any charmed reptiles as though casting a speak with animals spell. This ability is the equivalent of a 1st-level spell.  

**Corrupt Water (Sp):** Once per day Tiamat can stagnate 10 cubic feet of water, making it become still, foul, and unable to support animal life. The ability spoils liquids containing water. Magic items (such as potions) and items in a creature’s possession must succeed on a Will save (DC 82) or become fouled. This ability is the equivalent of a 1st-level spell. It has a range of 840 ft.  

**Create/Destroy Water (Sp):** Tiamat can use this ability three times per day. It works like the create water spell, except that Tiamat can decide to destroy water instead of creating it, which automatically spoils unattended liquids containing water. Magic items (such as potions) and items in a creature’s possession must succeed on a Will save (DC 80) or be ruined. This ability is the equivalent of a 1st-level spell.  

**Crush (Ex):** This special attack Tiamat to land on opponents as a standard action, using its whole body to crush them, when flying or jumping. Crush attacks are effective only against opponents of Huge size or smaller (though she can attempt normal overrun or grapple attacks against larger opponents). A crush attack affects as many creatures as can fit under Tiamat’s body. Creatures in the affected area must succeed on a Reflex save (DC 82) or be pinned, automatically taking bludgeoning damage during the next round unless Tiamat moves off them. If Tiamat chooses to maintain the pin, treat it as a normal grapple attack. Pinned opponents take damage from the crush each round if they don’t escape. A crush attack deals 8d6+52 damage.  

**Diabolical Adaption - Assume Alternate Form (Su):** Tiamat is one of the most active archdevils on the prime, and frequently walks the worlds in the shape of an attractive human or elven woman, or as a lesser dragon. To facilatate this, she can assume the form of any female creature of the dragon, humanoid, monstrous humanoid, or giant types, between colossal+ and medium sized size, as if by a shapechange spell cast by a 99th level sorcerer, with the following exceptions. Tiamat uses all her physical characteristics and her natural armor, modified for size changes, in her alternate form. She also keeps the following supernatural abilities; Assume Draconic Form, Mistress of Elements, Sentinel of the First, The Presence of Hell, and See in Darkness.  

**Diabolical Adaption - Call Consort (Su):** Tiamat may call one of her consorts to her aid once per day. (Tiamat's consorts are Age category 22 dragons, one of each chromatic color.)  

**Diabolical Adaption - Command Dragons (Ex):** Tiamat expects, and receives, unquestioning obediance from other dragons. All creatures of the dragon type within 840 ft of her suffer a _charm_ effect, unless they pass a Will save (DC 80). She can also command up to 10 evil creatures of the dragon type per day, in a manner similar to that of a dominate monster effect, except that this is not a mind-affecting effect. The victim receives a Will save (DC 80) to avoid the effect, and is allowed a new save if forced to do something against its nature. Once established, the link is peremenrant, and is not blocked by interplanar distance or by any ward effect created by any being with DvR/VDvR of 11 or less.  

**Diabolical Adaption - Dragon God (Ex):** Since her deposition from the throne of Avernus, Tiamat has clawed her way to the status of the god of chromatic dragons and evil dragon-like creatures, and has received commensurate powers. She possesses a VDvR of 11, and can grant clerical spells and those from the destruction, evil, law, and trickery domains. Tiamat is an exception to the normal clergy alignment rules, in that she also grants spells to chaotic evil creatures of the dragon type. She adds the spells from one these domains (trickery) to the list of spell-like abilities she can cast 9/day. She also sense any event which impacts on the welfare of evil dragons, as long as it affects at least 500 dragons.  

**Diabolical Adaption - Mistress of Elements (Su):** Tiamat's control over chromatic dragons extends to some limited control over the elements with which they're associated. This allows Tiamat to substitute the following energy types for one another in spells and spell-like abilities; acid, cold, electricity, and fire.  

**Diabolical Adaption - Sentinel of the First (Su):** As the guradian of Avernus, Tiamat has the ability to detect uninivited guests to the layer. As such, when on Avernusm she detects the entrance of any chaotic or good aligned beings on to the layer, and knows the location of entrance to within one mile. This ability can not be blocked by any effect of less than 9th level.  

**Diabolical Adaption - Spell Immunity (Ex):** Tiamat is immune to all spell-like ability, spells, or powers of 5th level or lower  

**Diabolical Adaption - The Chromatic Dragon (Ex):** As the mistress of evil dragons and their kin, Tiamat embodies a number of their greatest attributes. Like the hydra, she possesses 5 heads, each resembling one of the common chromatic dragons, and her tail is tipped with a wyvern's stinger. This has the following game effects:  

Tiamat has the benefitial SQ and SA, including the elemental immunities, of all of the chromatic dragon types, black, blue, green, red, and white. These abilities are based off her own Age category. She has none of the weaknesses associated with these lesser dragons however.  

Tiamat can use any spell-like ability possessed by one of the dragon types 5 times a day.  

Any skill which is a class skill for one of the dragon types is also a class skill for Tiamat.  

Every round each of Tiamat's five heads can bite, use the appropriate breath weapon, or use a spell-like ability, even if she has already moved or charged in that round.  

Anyone struck by one of Tiamat's tail attacks must save vs. poison DC 82, or suffer 3d8 primary and 3d8 secondary constitution damage.  

**Diabolical Aura (Ex):** Tiamat's presence is so vile that it causes lesser beings to cower or pay homage to the might of the evil she represents. All within 90 feet of her must succeed at a Will save (DC 80) or suffer one of the two following effects as determined by Tiamat (who can change the effect, or discontinue it, as a free action):  
Cower: Affected beings cower before Tiamat's might. They can defend themselves normally but take no actions.  
Induce Fear: Affected beings become panicked and suffer a -4 morale penalty on attack rolls, saves, and checks. The merest glance or gesture from Tiamat makes them frightened, and they flee from it as quickly as they can. A panicked creature has a 50% chance to drop what it’s holding, chooses its path randomly (as long as it’s getting away from immediate danger), and flees any other dangers that confront it. If cornered, a panicked creature cowers.  
Tiamat can make her servants, worshippers, beings of Lawful Evil alignment, or a mixture of all three types immune to this effect as a free action. This immunity lasts one day or until Tiamat dismisses it.  

Higher ranked divine beings are immune to Tiamat’s diabolical aura.  

**Freezing Fog (Sp):** Tiamat can create a freezing fog three times per day. It is similar to a solid fog spell but also causes a rime of slippery ice to form on any surface the fog touches, creating the effect of a grease spell. Tiamat is immune to the grease effect because of her icewalking ability. This ability is the equivalent of a 5th-level spell.  

**Icewalking (Ex):** This ability works like the spider climb spell, but the surfaces Tiamat climbs must be icy. It is always in effect.  

**Keen Senses (Ex):** Tiamat sees four times as well a human in shadowy illumination and twice as well in normal light. It also has darkvision out to 120 feet.  

**The Presence of Hell (Su):** Tiamat's presence is so terrible that it can corrupt an entire area with but a thought. Once per day as a standard action, Tiamat may unhallow the surrounding area in a radius of 2700 ft. from her. Tiamat can determine which spell to attach to the unhallow as listed in the Player’s Handbook. The duration and all associated effects of the unhallow and adjoined spell are based a caster level of 99.  

Although Tiamat detests the forces of righteousness, she also fears them. As a result, she finds it difficult to enter any hallowed site. When attempting to enter a hallowed site she must make a Will save {DC equal to 40 + the divine rank of the represented god (if unknown, assume the highest possible numeric value of the divine ranks) + the god’s Charisma modifier (if this is unknown, assume a +9)}; Tiamat cannot use her spell resistance to overcome this effect. If she succeeds in entering the hallowed area, the area immediately becomes unhallowed as described above. Once Tiamat breaches holy ground, the god in question is immediately alerted to her presence and will often (DM’s discretion) send a proxy or an avatar to deal with the intrusion.  

**See in Darkness (Su):** Tiamat can see perfectly in darkness of any kind, even that created by a deeper darkness spell.  

**Skills:** Appraise, Bluff, Concentration, Diplomacy, Escape Artist, Hide, Intimidate, Jump, Knowledge (any), Listen, Move Silently, Search, Sense Motive, Spellcraft, Spot, Swim, and Use Magic Device are class skills for Tiamat.  

**Sound Imitation (Ex):** Tiamat can mimic any voice or sound she has heard, anytime she likes. Listeners must succeed on a Will save (DC 80) to detect the ruse.  

**Spell-like Abilities:** Tiamat possesses the following spell-like abilities: at will: blasphemy, charm monster, deeper darkness, delayed blast fireball, desecrate, detect chaos, detect good, detect magic, flame strike, greater dispel magic, greater invisibility, greater teleport, magic circle against chaos, magic circle against good, mirage arcana, persistent image, polymorph, raise dead, suggestion, symbol of pain, unhallow, unholy aura, wall of fire. 1/round: _empowered_ energy drain, _heightened_ miracle {11th level}. 28/day: locate object. 9/day: confusion, disguise self, false vision, invisibility, mislead, nondetection, polymorph any object, screen, time stop. 5/day: command plants, control weather, discern location, dominate person, find the path, fog cloud, gust of wind, hallucinatory terrain, insect plague, plant growth, veil, ventriloquism, wall of ice. 3/day: destruction, firestorm, meteor swarm. 1/day: hellball. 1/week: wish.  
The spell-like abilities are cast as a 99th level Sorcerer.  

**Spells:** Tiamat casts spells as a 51 st level sorcerer. Spells per day: 6/11/11/11/11/10/10/10/10/9/4/4/4/3/3/3/3/2/2\. Spells known: DC 35: Arcane Mark, Prestigation, Resistance, Dancing Lights, Ghost Sound, Guidance, Create Water, Read Magic. DC 36: Bless Water, Detect Chaos, Divine Favour, Identify, Magic Missile, DC 37: Detect Thoughts, Cat's Grace, Misdirection, Make Whole. DC 38: Consecrate, Dispel Magic, Magic Vestment, Fireball, Shrink Item. DC 40: Ice Storm, Wall of Fire, Death Ward, Dismissal. DC 41: Righteous Might, Cone of Cold, Prying Eyes, True Seeing. DC 43: Blade Barrier, Mass Bull's Strength, Mass Bear's Endurance. DC 43: Greater Arcane Sight, Delayed Blast Fireball, Prismatic Spray. DC 44 Polar Ray, Temporal Stasis, Polymorph any Object. DC 45 Energy Drain, Miracle, Mage's Disjunction. Tiamat can cast 9 epic spells per day, and is believed to know a large number of epic spells, including some summon dragons to aid her, such as Greater Dragon Knight, general utility spells, such as Greater Planeshift, and some purely offensive, such as Word of Annihilation-Creation.  

**Tail Sweep (Ex):** This special attack allows Tiamat to sweep with her tail as a standard action. The sweep affects a half-circle with a radius of 40 feet, extending from an intersection on the edge of the dragon’s space in any direction. Creatures within the swept area are affected if they are large size or smaller. A tail sweep automatically deals 3d8+52 damage and can poison the target. Affected creatures can attempt Reflex saves to take half damage (DC 82).  

**Tiamat Qualities:** Tiamat possesses the following special qualities.  

• Immunity to acid, cold, electricity, fire, paralysis, poison, and sleep effects.  
• Telepathy.  
• Damage Reduction: DR of 25/epic, good, and silver.  
• Regeneration (Ex): Regeneration 27 unless struch by a blessed or holy weapon of at least +6 enchantment.  
• Spell Resistance 79.  
• Arch-Devil Awareness: Tiamat can sense anything within one mile around the mentioning of its name, titles, or an item of importance to it for up to one hour after the event. This power is barred from places associated with gods of goodness, the Lords of the Nine, and beings with divine ranks or virtual divine ranks of 1 or higher.  
• Divine Rank 0: As part of the higher-level nobility of Hell, and a god of dragonkind, Tiamat possesses a degree of might unknown to mortals and common Devils. Tiamat is immune to polymorphing, petrification, or any other attack that alters her form. She is not subject to energy drain, ability drain, or ability damage. Tiamat is immune to mind-affecting effects. She is immortal and cannot die from natural causes. Tiamat does not age, and she do not need to eat, sleep, or breathe. The only way for Tiamat to die is via special circumstances.  
• For the purpose of gate and similar spells, Tiamat is a unique creature.  

**Water Breathing (Ex):** Tiamat can breathe underwater indefinitely and can freely use her breath weapons, spells, and other abilities while submerged, her fire breath emerging as a cone of superheated steam which does fire damage.  

_**New Material:**_  

**Expeditious Metamagic [Epic]:**  

**Prereqs:** Cha 30, Improved Metamagic, Spellcraft 34 ranks, ability to cast 9th level spells, ability to cast spells without preparation.  

**Benefit:** When you use metamagic, you no longer take a full round in which to apply the feat. The casting time of the spell is the same as it would be for those who prepare their spells.  

**Normal:** Sorcerers, bards and other casters who do not prepare their spells must take a full round action if they cast a metamagiced spell.  

_**Word of Annihilation-Creation**_  

Conjuration (Teleportation)  
**Spellcraft DC:** 127  
**Components:** V  
**Casting Time:** 1 action  
**Range:** 1200 ft.  
**Area:** 40\. ft radius spread.  
**Duration:** Instantaneous  
**Saving Throw:** Fortitude half.  
**Spell Resistance:** Yes, special, see below.  
**To Develop:** 1,143,000 gp; 23 days; 45,720 XP. Seed: _Destroy_ (DC 29), 1 action casting time (DC +20), +20 to overcome SR (DC +40), change from target to area (DC +10), change from area to radius 20 ft. (DC +2), change from 20 ft. radius to 40 ft. radius (DC +4), no somatic components (DC +2), add 10 dice of damage (DC +20).  

By speaking a word of power in the Dark Speech, Tiamat renders the target area down into its base elements and rebuilds it in a fashion more to her liking. All creatures within the area suffer 30d6 points of damage, and Tiamat receives a +20 unnamed bonus to overcome spell resistance.  

_**Greater Dragon Knight**_  

Conjuration (Summoning) [Fire]  
**Spellcraft DC:** 118  
**Components:** V, S  
**Casting Time:** 1 quickened action  
**Range:** 75 ft.  
**Effect:** One summoned great wyrm red dragon.  
**Duration:** 200 rounds (D)  
**Saving Throw:** None  
**Spell Resistance:** No  
**To Develop:** 1,062,000 gp; 22 days; 42,480 XP. Seed: _Summon_ (DC 14), quickened spell (DC +28), summon creature other than outsider (DC +10), summon CR 26 creature (DC +48), increase duration by 900% (DC +18).  

This spell, castable as a quickened action, summons one great wyrm red dragon. It appears where Tiamat specifies and acts to follows her wishes to the best of its abilities.  

_**Greater Planeshift**_  

Conjuration (Teleportation)  
**Spellcraft DC:** 57  
**Components:** V, S  
**Casting Time:** 1 quickened action  
**Range:** Personal  
**Duration:** Instantaneous  
**Saving Throw:** None  
**Spell Resistance:** No  
**To Develop:** 513,000 gp; 11 days; 20,520 XP. Seed: _Transport_ (DC 27), change range to personal (DC -2), quickened spell (DC +28), interplanar travel (DC +4)  

This spell, castable as a quickened action, transports Tiamat and up to 50 lb. of carried gear to any other location reachable via the Astral Plane. To use this spell, Tiamat must have a reliable description of the place she is seeking to go. If she attempts to travel to a place based on unreliable or misleading information she simply disappears and the reappears at her original location.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *