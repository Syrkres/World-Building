# Rahab, Demon Prince
**Rahab** (Vepar, Sorath, Dagon)  
The Demon Prince of the Lightless Depths, the Deep One, the Lord of the Deeps, Mariner's Bane, the Bringer of Storms  
**Symbol**: A single round eye with no iris or pupil.  

**Gargantuan Outsider (Chaotic, Evil, Extraplanar)**  
**Hit Dice:** 39d8 (outsider) plus 20d4 (sorcerer) plus 10d6 (ur-priest) plus 6d6 (fiend of corruption) plus 600 (1088 hp)  
**Initiative:** +14 (+6 Dex +8 Superior Initiative)  
**Speed:** 60 ft., swim 110 ft.  
**AC:** 55 (-4 size, +6 Dex +23 natural +9 profane, +11 deflection), touch 32, flat-footed 49  
**Base Attack:** +57/+90  
**Attacks:** +71 melee primary oral tentacle and +69 melee 3 secondary oral tentacles or +67 melee primary arm/leg tentacle and +65 melee 9 secondary arm/leg tentacles or melee touch +64 or ranged touch +59  
**Full Attack:** +71 melee primary oral tentacle (2d6 plus +15 plus +1 (vile)) and +69 melee 3 secondary oral tentacles (2d6 plus +7 plus +1 (vile)) or +67 melee primary arm/leg tentacle (2d6 plus +11 plus +1 (vile)) and +65 melee 9 secondary arm/leg tentacles (2d6 plus +5 plus +1 (vile)) or melee touch +64 or ranged touch +59  
**Face/Reach:** 40 ft. by 40 ft./40 ft.  
**Special Attacks:** Absorb Souls, Abyssal Fury, Bounty of the Sea, Breath Weapon, Call Demons, Fiend’s Favor, geas 1/day, Horrid Form, mark of justice 1/day, Ravaged Forms (Poisonous Slime), soul bargain, spells, spell-like abilities, steal spell-like ability, suggestion 3/day, temptation  
**Special Qualities:** Break Summoning, Corrupting Presence, DR 25/cold iron and good, Demon Prince Qualities, Divine Interloper, divine spell resistance, fast healing 15/+3 cold iron or good, Fiendish Graft, fire vulnerability, grant wish 1/day, immunity to electricity, acid, and poison, immunity to water, major creation 3/day, mind shielding, Ravaged Forms (Alternate Form, Chromatophores, Enormous Eye, Tauric), resistances (fire, cold) 20, siphon spell power, SR 55, water mastery.  
**Saves:** Fort +47 Ref +45 Will +50  
**Abilities:** Str 33, Dex 22, Con 26, Int 23, Wis 32, Cha 33  
**Skills:** Bluff +69, Concentration +59, Diplomacy +51, Disguise +36, Escape Artist +36, Hide +31, Intimidate +89, Listen +26, Knowledge (arcana) +56, Knowledge (nature) +26, Knowledge (religion) +81, Knowledge (the planes) +61, Move Silently +36, Sense Motive +46, Speak Languages (Abyssal, Aquan, Celestial, Common, Infernal), Spellcraft +49, Spot +34, Survival +56 (+62 extraplanar, +60 find/follow tracks), Swim +89  
**Feats:** Combat Reflexes, Corrupt Spell-like Ability (B), Dark Speech, Empower Spell, Empower Spell-like Ability, Eschew Material Components (B), Heighten Spell, Improved Grapple, Improved Initiative, Malign Spell Focus, Multiattack, Quicken Spell, Still Spell, Vile Natural Attack (B), Violate Spell (polar ray), Weapon Focus (tentacles)  
**Epic Feats:** Automatic Quicken Spell(x3), Automatic Still Spell(x3), Epic Weapon Focus (tentacles), Expeditious Metamagic, Ignore Material Components, Improved Metamagic, Multispell, Superior Initiative, Vile Deathstrike  
**Climate/Terrain:** The Lightless Depths (Layer 871 of the Abyss)  
**Organization:** Solitary (Unique)  
**Challenge Rating:** 47  
**Treasure:** Quadruple Standard  
**Alignment:** Chaotic Evil  
**Advancement:** N/A  

One of the most dreadful of the horrors of the Abyss, Rahab, the Demon Prince of the Lightless Depths, is a tentacled monstrosity that desires nothing less than the domination of all seas. One of the oldest demons in existance, the primordial horror that is Rahab is a creature of slime, darkness, and insanity that only the strongest of wills can stand to look upon without losing their mind.  

Rahab's realm is the 873rd layer of the Abyss: the Lightless Depths. A water-filled realm, the Depths are literally without light: anyone without darkvision can see absolutely nothing in this layer. Here, Rahab swims through the black abyss, devouring the souls of those foolish or insane enough to call him their master. Unlike most other Demon Princes, Rahab shares his realm with several other powerful beings, including a number of myrmyxicuses. At one time he fought for his layer with dread King of the Deep, a demonic entity once beholden to the will of the now-dead goddess Takhisis, but the King was slain by heroes on the world of Krynn, and now Rahab's dominion over the Depths is unquestioned. It is likely that various other unique demons call the Depths home as well. These lesser horrors generally leave Rahab alone, and flee before his might when he approaches.  

Like many fiends, Rahab is known by many names. Some of his followers speak of him as Vepar and others as Sorath. Some cultists know him as Dagon, but that name rightfully belongs to one of Hell's devils.  

Because their "portfolios" overlap in regards to the slimy dwellers of the deep, Rahab is a sworn enemy of both the Demiurge Demogorgon and the dread Hadean god Panzuriel, but because of Rahab's relative weakness, clashes between their forces tend to be rare. Among the other powers he has made an enemy of are Sekolah of the sahuagin; Blibdoolpoolp of the kuo-toa; Eadro of the merfolk and locathah; Deep Sashelas of the elves; the Elemental Prince Ben-Hadar; and the human gods Aegir, Umberlee, and Poseidon. Of these, Poseidon is by far his deadliest rival: the Sea Father has sworn an oath to rid his oceans of Rahab's evil influence. It is common for Poseidon to recruit powerful heroes to brave the Lightless Depths and spy on his cultists' doings in the hopes that some headway might be made in his war against the demon. The Duke of Hell known as Dagon loathes Rahab as well for allowing the demon's followers to know him as Dagon.  

Unsurprisingly, Rahab has virtually no friends. The only ally he has is Olhydra, the Princess of Evil Water. Because of the distance between their realms, however, and Olhydra's fickle nature, he has not found her a very reliable ally.  

The goals of Rahab are the destruction of good sea life (such as aquatic elves) and the domination of neutral and evil denizens of the oceans. He has many worshippers among the creatures of slime and muck that dwell on the seabed: koprus, anguiliians, kuo-toas, ixitxachitls, rogue sahuagin, and even some renegade merfolk pay Rahab homage. All of these races have their own unique, foul rites that they perform in Rahab's name.  

Rahab has a fairly widespread following of human cultists on the Prime Material Plane. Many a coastal fishing town has found itself at the mercy of a poor harvest and turned to Rahab-worship in hopes of rectifying the situation. Indeed, Rahab frequently rewards his worshippers with greater catches of fish and harvests of grain, as well as gifts of gold. Such cultists make a common practice of summoning their demonic master to their plane of existance and offering a living sacrifice - indeed, Rahab actually encourages his followers to summon him. Such conjurations give him an opportunity to spread his corruption, transforming his worshippers into maddened inhuman reflections of their old selves, creatures of slime as hideous as their master. Such summonings typically involve a blood sacrifice and the destruction of a small golden pyramid inscribed on each face with his unholy symbol.  

Rahab is truly hideous. Only vaguely humanoid in shape, the Demon Prince of the Lightless Depths is a gargantuan cephalopoid monster. He looks something like a bloated, rubbery octopus, with a head like a human skull, a single cyclopean eye with no pupil set in its center. In place of a mouth, Rahab has a mass of ten-foot-long tentacles that dangle writhing from his head. Rahab has two huge tentacle-arms like those of an octopus that branch at each of their midpoints into ten squirming appendages. From his 'waist' depend twenty or more tentacles. His overall color is a dark green-brown, but Rahab can change his color to suit his whim. In addition to this hideous form, he can also change at will into a handsome merman some twenty feet from head to tail, with dark green skin and green-brown scales; he adopts this shape when summoned to the Prime by his human followers.  

**Combat**  
**Ravaged Form-Alternate Form:** At will, Rahab may shift forms into a a handsome merman some twenty feet from head to tail, with dark green skin and green-brown scales. The statistics for this form have been included in the block above.  

**Ravaged Form-Chromatophores:** Rahab may freely change the color of his rubbery exterior to better match his surroundings, or even blend into them perfectly, allowing him to simulate an invisibility spell in this manner although this effect cannot be dispelled.Rahab additionally recieves a +10 bonus on all Hide checks as long as he is underwater.  

**Ravaged Form-Enormous Eye:** Rahab’s enormous single eye enables him to see well in the incredible depths in which he is home; as a result, Rahab has 120 ft. darkvision and a +4 bonus to all Spot checks.  

**Ravaged Form-Oral Tentacles:** The four tentacles located below Rahab’s enormous eye and concealing his mouth are stronger than the rest of his tentacles, and as a result, have a +8 Str bonus; this has been taken into account in terms of his attack statistics.  

**Ravaged Form-Poisonous Slime:** Rahab’s entire body exudes toxic slime; as a result, creatures which touch Rahab or have the slime injected into their wounds must make a Fort save DC 55 or else take 1d10 initial Con damage and a second 1d10 Con damage one minute later.  

**Ravaged Form-Tauric:** Rahab’s torso trails off into 20 different 30-40 foot long tentacles. As a result, this provides him with a 100-foot speed bonus to his swim speed, and he may attack opponents with up to 5 of these additionally tentacles at a time in any given direction.  

**Ravaged Form-Tough Skinned:** Rahab’s slippery exterior grants him a +3 bonus to his natural AC.  

**Spell-like abilities:** at will: black tentacles, blasphemy, chain lightning, cloudkill, cone of cold, control water, deeper darkness, desecrate, destruction, detect good, detect law, dream, drown, greater dispel magic, fear, harm, mirror sending, read magic, shrivelling, suggestion, suggestion (mass), telekinesis, teleport without error (self plus 50 pounds), tongues, tongue tendrils, unhallow, unholy aura, unholy blight, wall of ice. 6/day: bestow curse, control weather, implosion, word of chaos. 3/day: power word (stun), symbol of death, summon monster IX (aquatic/water-based monsters only). 1/day: crushing hand, entice gift, ruin, trap the soul. 1/week: astral projection, greater ruin, slow. Rahab casts his spell-like abilities at 81st level. Saving throws against Rahab’s spell-like abilities is DC 21 + spell level. The saving throw DC’s are Charisma-based.  

**Abyssal Fury (Ex):** Rahab’s physical presence is so disgusting that is causes lesser creatures to succumb to his hate and need to spread destruction and terror. All creatures within 60 feet of Rahab must succeed in a Will save 58\. Those who succumb to Rahab’s gross presence suffer one of the two following effects:  

_Fright:_ Affected beings become shaken and suffer a -2 morale penalty on attack rolls, saves, and checks. The merest glance or gesture by Dagon makes them frightened, and they flee as quickly as they can, although they can choose the path of their flight.  

_Madness:_ The grotesque evil incarnate in Rahab’s being drives lesser beings insane per the insanity spell. The being remains stuck in a state of madness for one day for every point by which she failed the saving throw, after which time the victim is allowed another save. The madness exists until the victim successfully saves or the appropriate spells are cast by a 21st level being to purge the insanity effect.  
Rahab can make his servants, “worshippers,” beings of Chaotic Evil alignment, or a mixture of all three types immune to this effect as a free action. This immunity lasts one day or until Rahab dismisses it. However, Rahab cannot determine which effect takes place; there is a 50% chance each time Abyssal Fury is used that one or the other effect will impact near by victims.  

**Call Demons (Sp):** Two times a day Rahab may call up to 50 HD of Demons to aid it. When in an aquatic environment (which is virtually all of the time) he will call Myrmyxicuses and Advanced Wastriliths, which serve him out quickly out of the sheer terror that he also invokes in them due to his appearance. If he has been angered by something that dwells on land, he will call Balors instead and tell them to destroy the source of his ire, and then leave.  

**Corrupting Presence (Su):** Rahab’s presence is so heinous that it may corrupt an entire area with but a thought. Once per day as a standard action, Rahab may unhallow an area with a radius equal to 2625 feet centered around it. Rahab can apply the following spells to the unhallow effect (some of which are not listed as part of the unhallow spell in the Player’s Handbook): bane, bestow curse, contagion, deeper darkness, dispel magic, silence. In most situations, Rahab will select dispel magic.  

The forces of righteousness disgust Rahab, who finds goodness repellent enough to give it pause. As a result, Rahab avoids hallowed ground. If Rahab finds it necessary to enter a hallowed site, it must make a Will DC save equal to 40 + the divine rank of the represented god + the god’s Charisma modifier; Rahab cannot use it’s spell resistance to overcome this effect. If Rahab succeeds in entering the hallowed area, the area immediately becomes unhallowed. Once Rahab breaches holy ground, the god in question is immediately alerted to his presence and will often (DM’s discretion) send a proxy or an avatar to deal with the intrusion.  

**Demon Prince Qualities (Ex):** Rahab is immune to electricity and poison; he possesses cold and fire resistance 20\. Rahab may engage in telepathic communication with any creature within 100 feet. Rahab constantly detects good, detects magic, and true sees as a 31st level Sorcerer; he possesses immunity to polymorphing, petrification, or any other attack to alter his form. Rahab is not subject to energy drain, ability drain, or ability damage; he is also immune to mind-affecting effects. Rahab additionally possesses fast healing 15 unless struck by a cold iron or holy weapon of at least +3 enhancement.  

Rahab can sense anything within one mile around the mentioning of his name, titles, or an item of importance to him. This power is barred from places associated with gods of goodness, the personal redoubts of Demiurges or any being that possesses divine rank or virtual divine rank.  

Rahab is immortal and cannot die from natural causes; it does not age, and does not need to eat, sleep, or breathe.  

**Divine Interloper (Ex):** Rahab cults are likely to appear in remote, coastal communities where individuals are likely to respond to the offer of salvation from potential starvation in desperate situations. Typically Rahab will find an individual who is most likely to respond to his particular calling and bless them first by enacting his fiend of corruption powers upon them. Once this is done, he then continues to entice them with his Bounty of the Seas if they are incapable of spellcasting and then uses them as a ‘messenger’ to the entire community of the powers and knowledge that can be acquired through abandoning any faiths that they previously held, and worshipping Rahab instead. Rahab grants spells from the domains of Chaos, Evil, Luck, and Water, and demands as sacrifices the worshippers of what his chosen considers to be ‘rival’ gods. Since in the communities where Rahab is most likely to hold sway there are relatively few individuals in the first place, this rapidly turns into a spasm of paranoia as the surviving and relatively mortal beings try to keep themselves from being the sacrificed and offer up others instead. Sacrifices made to Rahab are typically offered to him as a snack before he makes any blessings.  

**Breath Weapon (Su):** Rahab may blast his opponents with a cone of boiling water, doing 3d10 points of damage in a 60 foot cone once every 1d4 rounds. (Ref save DC 55 for half damage).  

**Break Summoning (Ex):** If summoned, he can make an opposed Wisdom check to break from the summoning. If it succeeds, he will typically use his powers to control the being that summoned him and force them to join him, or else devour them right there.  

**Immunity to Water (Ex):** Rahab is immune to any form of attack that is based on water.  

**Water Mastery (Ex):** Rahab gains a +1 bonus on it’s attack and damage rolls if it and it’s opponent are touching water.  

**Sorcerer spells/day (Sp):** 6/9/9/9/8/8/8/8/7/7 Spells known: 0th level: acid splash, arcane mark, ghost sound, mage hand, no light, prestidigitation, slash tongue, touch of fatigue, unnerving gaze. 1st level: animate rope, bestow wound, ray of enfeeblement, shocking grasp, suspend disease. 2nd level: acid arrow, misdirection, resist energy, touch of idiocy, wither limb. 3rd level: dread word, evil eye, reality blind, water breathing. 4th level: abyssal might, contagion, corrupt summons, damning darkness. 5th level: baleful polymorph, cone of cold, mind fog, mirage arcana. 6th level: geas, chain lightning, disintegrate. 7th level: spell turning, scrying (greater), limited wish. 8th level: demand, horrid wilting, polar ray. 9th level: gate, energy drain, weird. Rahab casts his spells at 20th level.  

**Ur-Priest spells/day (Sp):** 6/8/8/7/6/6/6/5/3/2\. Rahab casts his Ur-priest spells at 23rd level. Saving throws against Rahab’s Ur-Priest spells is 21 + spell level. The saving throw DC’s are Wisdom-based. Rahab additionally rebukes undead as a 10th level Cleric.  

**Divine spell resistance (Su):** Rahab has spell resistance 20 against the divine spells and spell-like abilities of outsiders.  

**Siphon Spell Power (Ex):** Once a day Rahab may sacrifice two (or more) lower-level spell slots and use those slots to prepare a higher level spell. The levels of the lower-level slots are totaled, then reduced to three-quarters (round down) to determine the level of the extra higher-level spell slot.  

**Steal Spell-like Ability (Su):** Once each day, when a creature with spell-like abilities is within 50 feet of Rahab, he can choose of the creature’s spell-like abilities for himself. He can use the spell-like ability as often as the creature can or three times a day, whichever is less, and he uses it as the creature does with regard to the caster level and save DC’s. The ability only lasts for 24 hours, and the creature with the spell-like ability does not lose access to it when Rahab steals it. The attempt automatically fails if Rahab attempts to steal a supernatural rather than a spell-like ability.  

**Fiend’s Favor (Su):** Once a day, Rahab can grant a touched creature a +3 bonus to one of it’s ability scores. This bonus stacks with any other bonus a creature may have, and lasts for one day. When the effect expires, the creature takes a -3 penalty to the same ability score for the next day. Antoher application of fiend’s favor not only negates the penalty, but restores the bonus.  

**Mind Shielding (Su):** Rahab is completely immune to detect thoughts, discern lies, and any attempt to magically discern it’s alignment.  

**Mark of Justice (Sp):** Once a day Rahab can use the spell mark of justice as a 75th level Cleric.  

**Fiendish Graft (Su):** Once a month Rahab can bestow a fiendish graft or symbiont on a willing mortal.  

**Geas (Sp):** Rahab can use geas once a day as a 75th level Sorcerer.  

**Temptation (Su):** Rahab has the ability to offer good creatures the opportunity to change their alignment to evil. This works like the redemption or temptation function of the atonement spell, and Rahab can use this ability whenever the opportunity arises.  

**Grant Wish (Sp):** Once a day Rahab can grant a wish to a mortal as the 9th level spell as a 75th level Sorcerer.  

**Soul Bargain (Su):** Rahab can enter a binding agreement with a mortal, at the cost of the mortal’s soul. The mortal victim must enter into the soul bargain willingly. Upon the mortal’s death (by any means), their soul is transferred to a gem (prepared as with the soul bind spell when the bargain is forged), even if the gem and the mortal are not on the same plane at the time. The bargain requires 1 hour to complete, and is utterly inviolable once forged. The only way to escape a soul bargain is to recover the gem after the mortal’s death and break it, freeing their soul and allowing them to be restored to life through the normal means.  

**Absorb Souls (Ex):** Any being that touches the oral tentacles of Rahab risks having their souls absorbed through them. Beings which touch the tentacles, either through Rahab placing them there, or through accidentally contact, must make a Strength check DC 41 or else become held fast to the adhesive slime coating them. Over the course of the next rounds, victims must make a Fort save DC 55 or else take 1d4 negative levels as the tentacles absorb the victim slowly and in horrible, wracking pain, leaving nothing behind. Living creatures completely absorbed in this manner are unrecoverable except through the aid of a deity with the Hand of Life SDA.  

**Bounty of the Sea (Su):** Rahab’s most infamous power, he may call upon the Lightless Depths themselves to bring forth blessings of power and wealth upon those that sacrifice to him. In order to recieve the Bounty of the Sea, individuals partaking of the ceremony must melt down the holy symbols of all other religions within a region, and then reforge the melted gold and metal involved into an unholy symbol of Rahab which is typically a golden pyramid with the baleful eye of Rahab carved into two sides of it. This icon must then be destroyed in order to recieve Rahab’s horrific blessings. Those who pay homage to Rahab may recieve any of the following benefits:  

_Bounty of Life:_ Rahab has imparted to his worshippers the strength to survive in order to spread his power over the Prime Material Planes. As a result, individuals partaking of the ceremony recieve a +6 profane bonus to Survival in an aquatic environment. They may also receive up to one week’s worth of food, typically in the form of edible fish or grain.  

_Bounty of Success:_ Rahab has imparted to his worshippers a tiny fraction of his knowledge of the watery realms and the incomprehensible depths they contain. All individuals partaking of the ceremony recieve a +6 profane bonus on Profession checks if the profession involved requires prowess in an aquatic environment, such as sailor or fisherman. Rahab may additionally grant his worshippers a +6 profane bonus to all Craft (shipbuilding) checks.  

_Bounty of Good Fortune:_ The oceans contain untold wealth that has been lost to the worlds over millions of years. Rahab may bring forth a fraction of this wealth to his worshippers and grant those who pray to him 10,000 gp. Gold recieved through Rahab’s Bounty of the Sea appears as golden coins that wash up on the shore of the nearest ocean of where the ceremony took place, or appear in rivers or other bodies of water. All of these coins are tainted by Rahab’s foul evil, and the symbol of Rahab can clearly be seen on them through the use of true seeing; although there is nothing apparently wrong with them otherwise unless detect evil is cast on them by a 31st level good-aligned caster.  

The penalties of the Bounty of the Sea are also enacted upon anyone who eats fish caught by or grain harvested by an individual who has participated in one of Rahab’s ceremonies, or who possesses more than 100 gp of gold coins possessing the symbol of Rahab knowingly or unknowingly.  

However, to be ‘blessed’ by Rahab carries a horrific price. At the end of each month after individuals have partaken of the Bounty of the Sea in some form, all individuals involved turn more ichthyoid in nature, gaining another physical feature according to the table below and additionally must make a Will save DC 58 or else have their alignment slide one step towards Chaotic Evil.  

00-10 Lidless eyes  
11-20 Hands turn into fins. The transformed may not cast any spells unless they can be prepared stilled.  
21-30 Lower legs fuse and turn into a single tentacle. The transformed gains a 20 foot bonus to their swim speed, but their land speed is halved.  
31-40 Dorsal fin.  
41-50 A set of tentacles grow inside the transformed’s mouth, making it impossible for them to speak normally, and incapable of casting spells unless they can be prepared silenced. By exposing their tentacles, however, they gain a +4 bonus on Intimidate checks.  
51-60 Slime. The outer layer of skin of the transformed turns into toxic slime, doing 1d4 points of Con damage (Fort save 20) to anyone who touches or ingests it.  
61-70 Gills. The transformed becomes unable to breathe air and suffocates outside of water as a terrestrial creature would drown in water.  
71-80 Aquatic. The transformed becomes unable to survive outside of water longer than 5 minutes, and begins to dehydrate causing horrible pain after longer than that.  
81-90 Horrible nightmares. The transformed experiences horrible nightmares of their impending doom every night as the spell.  
91-100 Arms turn into tentacles. The transformed may make a natural attack with them based on their size as described in the half-fiend chart in the _Monster Manual_  

Each feature of a victim’s transformation not only damages the body of the mortal, but also their soul. As a result, they take a cumulative -4 penalty on further saves to resist any of Rahab’s powers or future transformations.  

Should a victim be ‘blessed’ by Rahab three times, they must make a final Will save DC 58; failure indicates that they lose their mortality and are compelled to swim into the sea, where the Lightless Depths claims them forever as one of Rahab’s petitioners. This will occur during particular astrological alignments. (For game purposes, treat as 1d6 months away from arriving in any giving village or town containing a Rahab cult). Even beings that manage to avoid the outward transformations from their involvement with Rahab are still vulnerable to the final compulsion to join it in the Lightless Depths as well as the cumulative penalties.  

Eventually, there is nothing left but empty villages and the stench of rotting fish.  

Beings that have recieved benefits from Rahab in this manner may only be liberated from the physical deformities and impending horror of their fates through the use of an atonement cast by a 31st level caster or higher, then followed by a polymorph spell.  

**Horrid Form (Su):** The actual physical form of Rahab is so damaging to the minds of those who behold him that they must make a Will save DC 58 or else take 1d4 Wisdom drain. So hideous is he that even a proper representation of his form has a lesser effect; as a result, sculptures or other artistic representations of Rahab that have been constructed that try and represent him (Craft (sculptor) DC 35) accurately damage the sanity of both the artist and those who observe it, doing 1d4 Wisdom damage (Will save DC 48). Creatures that successfully make their saving throws against the power of Rahab’s Horrid Form are immune to it for only a single day, such is its potency. Beings that have paid homage to Rahab recieve a +4 profane bonus to the save.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *