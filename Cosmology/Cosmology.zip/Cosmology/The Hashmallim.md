# The Hashmallim

The hashmallim are the judges and enforcers of the Realms Above. The choir was formed at the insistence of the Virtues of the Mount, to fill the role of overseeing the Celestial Compact and its regulations. The hashmallim are primarily found in Arcadia, Celestia and Bytopia, but can be found in any place in the Realms Above, depending on its particular duties at that time.  

Hashmallim are the least likely to be found away from the Upper Realms, their interpretation of the Celestial Compact generally precluding such an approach. However, this also means that they are the most stalwart guardians of the Realms Above, working well together in strictly defined units for specific purposes. They fill the gap left by roving ophanim and their tarshishim advisors, ensuring that evil that attempts to enter the Realms Above is swiftly judged and penalty served. The individual powers of hashmallim thus lean towards the punishment, or condemnation, of evil.  

Those malakim which have a stronger leaning towards law generally gravitate towards this choir, until promotion occurs into warden hashmal form. From there, the soul that fulfills the measure of its purpose may advance to justice and then to throne in terms of power and responsibility.  

Angels included: The middle to high range of archons would be found in this choir as naturalized members. The hashmallim choir would also have some deva, planetar and solar members. Naturalized ophanim would be rare to crossover to this choir, but this does still occur.