# Erevan Ilesere
The Trickster, the Chameleon, the Green Changeling, the Ever-shifting Shapechanger, the Fey Jester, the Jack of the Seelie Court  
Intermediate Elven Deity  
Symbol: Starburst with asymmetrical rays  
Home Plane: Arvandor  
Alignment: Chaotic neutral  
Portfolio: Mischief, change, rogues  
Worshipers: Bards, elves, revelers, rogues, sorcerers, tricksters  
Cleric Alignments: CE, CG, CN  
Domains: Chaos, Elf, Luck, Trickery  
Favoured Weapon: “Quickstrike” (short sword)  

**Erevan Ilesere**  
Rogue 20/ Sorcerer 10/Ranger 5/Divine Seeker 5  
Medium-size outsider (Chaos)  
Divine Rank: 12  
Hit Dice: 20d8+140 (outsider) + 20d6+140 (Rog) + 10d4+70 (Sor) + 5d10+35 (Rgr) + 5d6+35 (Skr) (820 hp)  
Initiative: +20, always first (+16 Dex, +4 Improved Initiative, Supreme Initiative)  
Speed: 60 ft.  
AC: 75 (+16 Dex, +12 divine, +25 deflection, +12 natural)  
Attacks: +5 knock-back, sweeping longsword +59/+54/+49/+44 and +5 keen, speed short sword +59/+59/+54/+49; or spell +64 melee touch or +71 ranged touch.  
Damage: +5 knock-back, sweeping longsword 1d8+13/17-20 and +5 keen speed short sword 1d6+13/15-20; or by spell.  
Face/Reach: 5 ft. by 5 ft./5 ft.  
Special Attacks: Domain powers, salient divine abilities, spell-like abilities.  
Special Qualities: Moon elf racial abilities, animal companion (up to 5 HD), crippling strike, defensive roll, divine aura (1,200 ft., DC 34), divine immunities, divine perseverance, DR 47/+4, familiars (cats), favoured enemies (drow +2, evil outsiders +1), fire resistance 32, godly realm (10 miles Outer Plane, 1,200 ft. Material Plane), improved evasion, locate creature 1/day, locate object 1/day, obscure object 1/day, opportunist, plane shift at will, remote communication 12 miles, sacred defence +2, sanctuary 1/day, sneak attack +15d6, spontaneous casting of divine spells, SR 44, uncanny dodge (Dex bonus to AC, can’t be flanked, +4 against traps), teleport without error at will, thwart glyph, understand, speak and read all languages and speak directly to all beings within 12 miles.  
Saves: Fort +51, Ref +60, Will +51  
Abilities: Str 26, Dex 42, Con 24, Int 35, Wis 25, Cha 35  
Skills: Appraise +59, Animal Empathy +49, Balance +63, Bluff +59, Climb +56, Concentration +54, Decipher Script +59, Diplomacy +59, Disable Device +59, Disguise +59, Escape Artist +63, Forgery +59, Gather Information +59, Handle Animal +51, Heal +54, Hide +63, Innuendo +54, Intimidate +59, Intuit Direction +54, Jump +58, Knowledge (arcana) +59, Knowledge (nature) +59, Listen +56, Move Silently +65, Open Lock +63, Pick Pocket +63, Search +59, Spellcraft +59, Spot +56, Tumble +65, Use Magic Device +59, Use Rope +63, Wilderness Lore +49.  
Feats: Acrobatic, Alertness, Combat Casting, Dodge, Eschew Materials, Expertise, Extend Spell, Eyes in the Back of Your Head, Greater Two-Weapon Fighting, Improved Critical (longsword), Improved Critical (short sword), Improved Disarm, Improved Initiative, Improved Two-Weapon Fighting, Maximize Spell, Persistent Spell, Point Blank Shot, Quick Draw, Quicker than the Eye, Superior Expertise, Track, Weapon Focus (longsword), Weapon Focus (short sword).  

Divine Immunities: Ability damage, ability drain, acid, cold, death effects, disease, disintegration, electricity, energy drain, mind-affecting effects, paralysis, poison, sleep, stunning, transmutation, imprisonment, banishment.  
Salient Divine Abilities: Alter Form, Alter Reality, Alter Size, Avatar, Battlesense, Divine Blast, Divine Dodge, Divine Glibness, Divine Rogue, Divine Sneak Attack, Extra Domain (Elf), Power of Luck, Shapechange, Supreme Initiative, Wave of Chaos.  
Domain Powers: Cast chaos spells at +1 caster level; 12/day reroll any one roll made.  
Spell-like Abilities: Erevan uses these abilities as a 24th-level caster, except for chaos spells, which he uses as a 26th-level caster. The save DC’s are 34 + spell level. aid, animate objects, antipathy, break enchantment, cat’s grace, change self, chaos hammer, cloak of chaos, commune with nature, confusion, dispel law, entropic shield, false vision, find the path, freedom of movement, holy aura, invisibility, liveoak, magic circle against law, mind blank, miracle, mislead, nondetection, polymorph any object, prismatic sphere, protection from elements, protection from law, repulsion, screen, shatter, snare, spell turning, summon monster IX (as chaos spell only), sunburst, time stop, tree stride, true strike, word of chaos.  
Ranger Spells/day: 2 (level 1); base DC 17 + spell level.  
Sorcerer Spells known: 9/5/4/3/2/1.  
Sorcerer Spells/day: 6/6/6/6/5/3; base DC 22 + spell level.  
Possessions: Erevan attacks with Mischief in his one hand and Quickstrike in his off hand. Quickstrike is a +5 short sword with the keen and speed abilities, Mischief a +5 longsword with the sweeping and knock-back abilities. If hard pressed, however, he prefers to use Quickstrike as his main weapon as it is lighter and easier to conceal.  
Caster level: 25th; Weight: 4 lb. and Caster level 25th; weight 3 lb.  

**Other Divine Powers**  
As an intermediate god, Erevan Ilesere automatically receives a 20 on any check. He treats a 1 on an attack roll or saving throw normally and not as an automatic failure and is immortal.  
Senses: Erevan can see, hear, touch and smell at a distance of twelve miles. As a standard action, he can perceive anything within one mile of his worshippers, holy sites, objects or any location where one of his titles or name was spoken in the last hour. He can extend his senses to up to ten locations simultaneously. He can block the sensing powers of deities of up to his rank at two such remote locations at once for 10 hours.  
Portfolio Sense: Erevan is automatically aware when any elf commits an act of mischief or stealth.  
Automatic Actions: Erevan can use Bluff, Diplomacy, Escape Artist, Pick Pocket, and Search if the DC for the check is 25 or less. He can perform up to ten such actions per round.  
Create Magic Items: As Erevan is the god of mischief and change, he can create any magic item that has a chaotic or random effect as well as any item that aids in stealth, as long as the item’s price does not exceed 200,000gp.  

**Avatars**  
Erevan appears different every time he sends an avatar to the Realms… Sometimes he’s an elf, at others he’s a brownie, pixie, sprite or other sylvan creature. He sends avatars to check up on his faithful and to aid them if necessary. Erevan is always accompanied bij Avachel, an aspect of the draconic deity Hlal, who is also known as Aasterinian, the dragon's god of trickery.  
Avatar of Erevan: As Erevan except as follows; divine rank 6; AC 67; Atk +53/+48/+43/+38 (1d8+13/17-20, +5 knock-back, sweeping longsword) and +53/+53/+48/+43 (1d6+13/15-20, +5 keen, speed short sword); or +55 melee touch or +62 ranged touch; SQ Divine aura (600 ft., DC 28), DR 41/+4, fire resistance 26, SR 38; SV Fort +45, Ref +54, Will +55; all skill modifiers are reduced by six.  
Salient Divine Abilities: Alter Form, Alter Size, Divine Dodge, Divine Glibness, Divine Rogue, Extra Domain (Elf), Shapechange, Supreme Initiative  
Spell-like abilities: Caster level 16th, saving throw DC 28 + spell level.  

While his following is not as large as those of the other elven deities, Erevan still commands his share of attention from the elves, particularly those engaged in thieving.  

Erevan is fickle, an utterly unpredictable deity who can change his appearance at will. He enjoys causing trouble for its own sake, but his pranks are rarely either helpful or deadly. His favorite tactic is to change his height to any size between one inch and six feet. Regardless of how he appears at any given time, Erevan will always wear green somewhere upon his person.  

Followers of Erevan are usually quite unpredictable themselves, and very independent. Many of them are thieves or have thieving as one of their multiple classes.