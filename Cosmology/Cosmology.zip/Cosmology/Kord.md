# Kord 
**The Brawler**  
**Intermediate Deity**  
**Symbol:** A star of spears and maces  
**Home Plane**: Ysgard  
**Alignment**: Chaotic Good  
**Portfolio:** Strength, Athletics, sports, brawling, courage  
**Cleric Alignments**: CG, NG, LG  
Domains: Chaos, Luck, Good, Strength  
**Favored Weapon**: Greatsword  

**Fighter 20/Barbarian 30/Mighty Contender 10**  
**Medium Size Outsider (Chaotic, Extraplanar, Good)**  
**Divine Rank**: 14  
**HD**: 30d10+30d12+1200 (1,860 hp)  
**Initiative:** +14 (+10 Dex, +4 Improved Initiative)  
**Speed**: 70 ft. (14 squares)  
**AC:** 73 (+10 Dex, +14 divine, +10 deflection, +29 natural), touch 44, flat-footed 63  
**Base Attack/Grapple** +40/+116  
**Attack:** _Kelmar_ +99 melee (2d6+56/17-20/x2); or unarmed strike +81 melee (1d3+27); or spell +81 melee touch or +64 ranged touch.  
**Full Attack:** _Kelmar_ +99/+94/+89/+84 melee (2d6+56/17-20/x2); or unarmed strike +81/+76/+71/+66 melee (1d3+27); or spell +81 melee touch or +64 ranged touch.  
**Face/Reach:** 5 ft./5 ft.  
**Special Attacks:** Domain powers, feat of power 1/day, salient divine abilities, spell-like abilities, surge of power 1/day, surge of strength 30/day.  
**Special Qualities:** Divine aura (1400 ft., DC 34), divine immunities, DR 25/epic and silver, DR 8/-, fire resistance 19, sonic resistance 19, fast healing 34, godly communication, godly realm, fast movement, uncanny dodge (never flat footed, can‘t be flanked, +10 trap sense), SR 76, understand, read, and speak all languages and speak directly to all beings with 14 miles.  
**Saves:** Fort +66, Ref +50, Will +43.  
**Abilities:** Str 64, Dex 31, Con 51, Int 14, Wis 15, Cha 30  
**Skills:** Balance+44, Bluff +48, Climb +76, Concentration +40, Diplomacy +50, Escape Artist +50, Intimidate +72, Jump +73, Knowledge (Religion) +26, Listen +44, Move Silently +34, Perform (athletics) +50, Ride +30, Search +39, Sense Motive +39, Spot +44, Swim +79, Tumble +64, Wilderness Lore +39\. *Always receives a 20 on checks.  
**Feats:** Cleave, Combat Expertise, Combat Reflexes, Deflect Arrows, Diehard, Dodge, Endurance, Great Cleave, Greater Weapon Focus (greatsword), Greater Weapon Specialization (greatsword), Improved Bull Rush, Improved Critical (greatsword), Improved Critical (unarmed strike), Improved Disarm, Improved Grapple, Improved Initiative, Improved Sunder, Improved Unarmed Strike, Mobility, Power Attack, Spring Attack, Weapon Focus (greatsword), Weapon Focus (unarmed strike), Weapon Specialization (greatsword), Weapon Specialization (unarmed strike), Whirlwind Attack  
**Epic Feats:** Dire Charge, Epic Weapon Focus (greatsword), Epic Weapon Specialization (greatsword), Exceptional Deflection, Infinite Deflection, Legendary Wrestler, Reflect Arrows, Spellcasting Harrier, Terrifying Rage.  
**Salient Divine Abilities:** Alter Size (B), Area Divine Shield, Avatar (B), Banestrike (dragons), Divine Battle Mastery, Divine Blast (13/day, 14 miles, 24d12 damage), Divine Blessing (Strength), Divine Fast Healing, Divine Inspiration (Courage), Divine Rage, Divine Shield (23/day, 140 points), Divine Weapon Focus (greatsword), Divine Weapon Specialization (greatsword), Extra Domain (Luck), Extra Energy Resistance (sonic), Gift of Life, Indomitable Strength, Irresistible Blows (greatsword, DC 44).  
**Environment:** Ysgard  
**Organization:** Unique  
**Challenge Rating:** 52  
**Treasure:** _Kelmar_  
**Alignment:** Chaotic Good  
**Advancement:** N/A  
**Level Adjustment:** N/A  

- **Contender spells per day:** 5/5/4/2\. Caster level 5th; save DC 12 + spell level.  
- **Divine Immunities:** Ability damage, ability drain, acid, cold, death effects, disease, disintegration, electricity, energy drain, mind affecting effects, paralysis, poison, sleep, stunning, transmutation, imprisonment, banishment.  
- **Divine Rage:** The following changes are in effect while Kord rages: AC 68; hp 2,160; Atk _Kelmar_ +104 melee (2d6+64) or unarmed strike +86 melee (1d3+31); Fort +71, Will +48; fire and sonic resistance 29, SR 86; Str 74, Con 61; all Strength and Constitution-based skills increase by +5\. Kord can use his rage 14/day, and it lasts for up to 1 hour at a time (though he may end it earlier). He is not winded afterwards.  
- **Domain Abilities:** Cast Good and Chaos spells at +1 caster level; 14/day may reroll a die roll.  
- **Feat of Power** 1/day, during a Surge of Strength, Kord may add +36 to his Strength score for the first round of the surge.  
- **Surge of Power** 1/day, during a Surge of Strength, Kord may add +36 to his Strength score for the duration of the surge.  
- **Surge of Strength**: 30/day, Kord may add +24 to his Strength score for 1d4+1 rounds.  
- **Spell Like Abilities:** Caster level 74th, save DC 44 + spell level. At will - aid, animate objects, Bigby's clenched fist, Bigby's crushing hand, Bigby's grasping hand, blade barrier, break enchantment, bull's strength, chaos hammer, cloak of chaos, dispel evil, dispel law, endure elements, entropic shield, freedom of movement, holy aura, holy smite, holy word, magic circle against evil, magic circle against law, magic vestment, miracle, mislead, moment of prescience, protection from energy, protection from evil, protection from law, righteous might, shatter, spell immunity, spell turning, stoneskin, summon monster IX (as a chaos or good spell only)_, word of chaos_.  

**Possessions:** Kelmar is an intelligent _+8 dragon dread greatsword_. It has Intelligence and Wisdom scores of 25, and a Charisma of 30\. _Kelmar_ can speak and communicate telepathically. It possesses the following powers, usable at will: _detect evil, detect magic, detect law, find traps, locate object_ (120 ft. radius), and _true seeing_. It can _detect thoughts_ 3/day and cast _heal_ 2/day on its wielder. 1/day, it can smite an evil dragon (+10 attack, +20 damage). _Kelmar_ has a special purpose to slay lawful evil dragons. When it strikes such a creature, the dragon must make a Will save (DC 40) or die instantly. It has an Ego of 68.  

**Other Divine Powers:**  

**Alter Reality**: Kord can use _wish_ with regard to any action that involves bravery, strength or athletic contests, save by duplicating other spells. It is a standard action for Kord to alter reality in this fashion. Kord may also add +10 to his damage rolls 14/day, for one round at a time, as a free action.  
**Senses:** Kord can see, hear, touch, and smell at a distance of fourteen miles. As a standard action, Kord can perceive anything within fourteen miles of his servants or worshippers, holy sites, objects, or any location where one of his titles or name was spoken in the last hour. He can extend his senses up to 10 locations at once. He may block the sensing power of dieties of his rank or lower in up to two locations at once for 14 hours.  
**Portfolio Sense:** Kord can sense any act of courage the instant it happens and retains the sensation for fourteen weeks after the event occurs. He is likewise aware of any athletic contest or accomplishment of physical prowess.  
**Automatic Action:** Kord can use any Strength or Dexterity as a free action if the DC for the task is 25 or lower. He may not use any skills that require movement. He can perform up to 10 such free actions each round.  
**Magic Items:** Kord can create simple or martial magic weapons and items that boost physical abilities as long as the item’s market price does not exceed 200,000 gp.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *