# Horned Sheperd (CR 23)  
_A massive, muscular man with pitch-black skin and ice-blue hair hovers in the air. Crowning his head amid his wild hair is a pair of immense deer antlers. He wears only a loincloth and carries a wooden shepherd's crook._  

Usually LN Large Fey  
**Init** +9; **Senses** _deathwatch_, low-light vision, _see invisibility_, threshold sense, _true seeing;_ Listen +49, Spot +49  
**Aura** fear aura (300 ft., DC 32); **Languages** Sylvan  
**AC** 44, touch 18, flat-footed 35 (+9 Dex, +26 natural, -1 size); Dodge, Mobility  
**hp** 337 (27 HD); **DR** 20/cold iron and epic  
**Immune** alignment-based effects, effects which imprison or banish, mind-affecting effects, sonic, soul-based effects  
**Resist** Endurance, evasion; **SR** 38 (15 + CR)  
**Fort** +18, **Ref** +24, **Will** +26  
**Speed** 60 ft., fly 80 ft. (perfect) (16 squares)  
**Melee** _shepherd's crook_ +32/+27/+22 (1d8+26/19-20 (remove soul Fort DC 36 on critical)) and gore +31 (2d8+13/15-20/x3); or  
**Melee** gore +33 (2d8+20/15-20/x3) and 2 slams +24 (1d8+6)  
**Space** 10 ft.; **Reach** 10 ft.  
**Base Atk** +13; **Grp** +30  
**Atk Options** Combat Expertise, favored enemy aberrations +2, favored enemy outsiders (chaotic) +2, favored enemy outsiders (evil) +4, favored enemy outsiders (good) +4, favored enemy undead +6, Spring Attack  
**Special Actions** fell the prey, whistle  

**Druid Spells Prepared** (CL 20th):  
9th (4/day)—_foresight, mass heal_ (x3)  
8th (5/day)—_earthquake, mass inflict critical wounds_ (DC 29), _sunburst_ (x2, DC 29), _whirlwind_ (DC 29)  
7th (5/day)—_animate plants_ (x2, DC 28), _aura of vitality_ (SC 18), _greater scrying_ (DC 28), _sunbeam_ (DC 28)  
6th (5/day)—_heal_ (x2), _mass bear's endurance, undeath to death_ (x2, DC 27)  
5th (6/day)—_call lightning storm_ (DC 26), _control winds_ (DC 26), _death ward, insect plague, tree stride, wall of thorns_  
4th (7/day)—_commune with nature, cure critical wounds_ (x2), _freedom of movement_ (x2), _nondetection, rusting grasp_ (+25 melee touch)  
3rd (7/day)—_darkvision, halt undead_ (DC 24), _plant growth_ (x2), _speak with dead, water breathing, wind wall_ (DC 24)  
2nd (7/day)—_barkskin, bear's endurance, cat’s grace, owl's wisdom, snare_ (DC 23), _speak with plants, tree shape_  
1st (7/day)—_delay poison, entangle_ (x3, DC 22), _faerie fire, resist energy, speak with animals_  
0th (6/day)—_cure minor wounds, detect magic_ (x2), _light, purify food and drink, touch of fatigue_ (+25 melee touch, DC 21)  
**Spell-like Abilities** (CL 27th):  
Always active—_deathwatch, see invisibility, true seeing_  
At will—_discern location, greater shout_ (DC 28), _haste, reincarnate, revivify_ (SC 176), _true strike_  
3/day—_antilife shell, dimensional anchor_ (+23 ranged touch), quickened _greater dispel magic, mass cure serious wounds, veil_ (DC 26)  
1/day—_control weather_, quickened _mage's disjunction_ (DC 28), _mass bull’s strength, waves of exhaustion_  
**Abilities** Str 37, Dex 29, Con 29, Int 22, Wis 32, Cha 28  
**SQ** Animal companion, camouflage, combat style, fade, hide in plain sight, master huntsman, spectral presence, swift tracker, wild empathy +33, woodland stride  
**Feats** Ability Focus (whistle), Combat Expertise, Dodge (B), Endurance (B), Flyby Attack, Improved Critical (gore), Improved Critical (quarterstaff), Improved Trip, Mobility (B), Multiattack, Quicken Spell-Like Ability (_greater dispel magic_), Quicken Spell-Like Ability (_mage's disjunction_), Spring Attack (B), Track (B), Weapon Focus (gore)  
**Epic Feats** –  
**Skills** Concentration +39, Diplomacy +43, Hide +35*, Intimidate +39, Knowledge (geography) +36, Knowledge (nature) +40, Listen +49, Move Silently +38, Search +14, Sense Motive +41, Spellcraft +36, Spot +49, Survival +49 (+53 in aboveground natural areas, to avoid getting lost, and to avoid natural hazards; +57 to avoid getting lost or avoid natural hazards in aboveground natural areas)  
**Possessions** _shepherd's crook_  

**Augmented Critical (Ex)** A horned shepherd’s gore threatens a critical hit on a natural attack roll of 18-20, dealing triple damage on a successful critical. This horned shepherd’s gore threatens a critical on a roll of 15-20, due to having the Improved Critical feat. It deals an additional 2d6 damage on a critical hit, due to having the Overwhelming Critical feat.  

**Combat Style (Ex)** Horned shepherds have a unique combat style, which they use instead of the combat styles offered in the Player’s Handbook. A horned shepherd’s combat style grants it the Dodge, Mobility, and Spring Attack feats as long as it is wearing no armor or light armor.  

**Fade (Su)** A horned shepherd can become incorporeal as a move action. Ending this effect is a free action. While incorporeal, the horned shepherd loses its natural armor bonus but gains a +7 deflection bonus to its Armor Class. It may still harm corporeal foes normally, as if its weapons had the ghost touch property.  

**Fear Aura (Su)** Any mortal creature that can see or hear a horned shepherd from within 300 feet must succeed on a Will save (DC 32) or be affected as if by _fear_ (caster level 27th). A creature that succeeds on his save against this effect can’t be affected by that horned shepherd’s fear aura for 24 hours. Fey are immune to this aura. The save DC is Charisma-based.  

**Fell the Prey (Ex)** As a standard action, a horned shepherd may make a single attack that deals normal weapon damage. If it strikes a flat-footed opponent within 30 feet, the creature must attempt a Fortitude save (DC 34) or be killed or paralyzed (the shepherd's choice). Creatures paralyzed by the attack recover after 27 rounds. This attack cannot be made as part of a full attack action. Creatures protected from sneak attacks or critical hits are likewise protected from this effect. This is not a death effect. The save DC is Wisdom-based; the duration of the paralysis is HD-based.  

**Immaculate Soul (Ex)** A horned shepherd's soul cannot be affected by spells or special effects (such as _trap the soul_) except for the abilities of other horned shepherds. A horned shepherd is also immune to mind-affecting effects, alignment-based effects, and effects which imprison or banish it.  

**Master Huntsman (Ex)** A horned shepherd can track creatures protected by trackless step, _pass without trace_, and similar effects, though the DC to track them is increased by the caster level of the effect (or the Hit Dice of the effect’s originator, if it has no caster level). In addition, it has all the class abilities of a ranger whose level is 3/4 its racial Hit Dice. For a hunter with 27 HD (effective ranger level 20th), this grants it the following abilities: animal companion, camouflage, combat style, combat style mastery, Endurance, evasion, 5 favored enemies, hide in plain sight, improved combat style, spellcasting, swift tracker, Track, wild empathy, and woodland stride. A horned shepherd gains a +6 racial bonus on wild empathy checks. Horned shepherds normally have animal companions as merely helpers or friends, instead relying solely on cú sídhe for tactical support; Harvesters often choose crows, vultures, or other carrion birds, while Sowers usually choose horses or storks.  

**Remove Soul** A creature with a soul (generally, any living creature or sentient undead) that is dealt a critical hit by a _shepherd’s crook_ must succeed on a Fortitude save (DC 36) or have its soul is pulled free from its life-force (and body, if it has one) by the hook. This kills living creatures and destroys undead. A horned shepherd which pulls a soul free through this ability may bind the soul in the crook as a part of removing the soul from the body. A creature’s natural immunity to critical hits does not protect it from this effect (though it does protect the creature from extra damage due to the critical hit). Other sources of protection from critical hits, such as fortification, are effective in protecting against this effect. This is not a death effect. The save DC is Strength-based.  

A construct with a controlling spirit, such as a golem, can be affected by this ability, but it gains a +8 bonus on its saving throw. A creature whose body and soul are a single unit (most elementals and non-native outsiders) is not slain by this effect if it fails its save, but instead has its physical form disrupted, inflicting 2d8 points of Constitution damage.  

**Spectral Presence (Ex)** A horned shepherd’s natural armor and natural and manufactured weapons function normally against incorporeal foes as if they had the ghost touch property. A horned shepherd can perceive incorporeal creatures and disembodied souls with all its senses normally and to interact physically with them.  

**Spells** A horned shepherd casts spells as an 20th-level druid. It can prepare and cast ranger spells in these slots, as well as necromancy and conjuration (healing) spells from the cleric and sorcerer/wizard spell lists.  

**Threshold Sense (Ex)** A horned shepherd can sense dying creatures, creatures soon to be born or die of old age (within the next 24 hours), creatures which have died within the last 24 hours, incorporeal creatures, and disembodied souls at a range of 10 miles. This sense reveals approximate distance and direction, but does not pinpoint a creature. A horned shepherd can constantly discern of the health of those it can sense as if through _deathwatch_.  

**Whistle (Su)** A horned shepherd can produce a chilling, piercing whistle, which is fully audible at a range of 1 mile. The shepherd can produce stronger effects by whistling for a longer amount of time. For any of these effects, the shepherd may choose to take control of all disembodied souls who hear for the next 24 hours, normally compelling them to fly to the shepherd. A creature whose body and soul form a single unit (most elementals and non-native outsiders) who hears a charming whistle must succeed on a Will save (DC 34) or be likewise charmed.  

The shepherd may choose for any number of creatures to be immune to the effects of its whistle. Additionally, the whistle can alert all fey who hear to the shepherd's exact location. The shepherd may indicate to those fey (by the tone of the whistle) "danger", "help", "stay", “come", or no particular message. The save DCs are Charisma-based, and include a +2 bonus from Ability Focus.  

_Bloodchilling_ All creatures other than fey who can hear the whistle become shaken if they have fewer Hit Dice than the horned shepherd and fail a Will save (DC 34). This whistle is a move action.  

_Breathstealing_ If the shepherd whistles as a standard action, all creatures within 300 feet which hear the shepherd must succeed on a Will save (DC 34) or be paralyzed with fear for 27 rounds. All creatures further than 300 feet but more than 1 mile away must save or be shaken, as per a bloodchilling whistle.  

_Heartstopping_ If the shepherd whistles as a full-round action, instead all creatures with souls (generally, living creatures and sentient undead) within 60 feet must succeed on a Fortitude save (DC 34) or have their souls pull free of their life-force (and body, if they have one) to answer the shepherd’s call. This slays living creatures and destroys undead. Those who succeed instead suffer 13d8 sonic damage. This is not a death effect.  

A creature whose body and soul form a single unit does not risk death, but must instead make a Will save at a -4 penalty or be charmed as described above. A construct with a controlling spirit can be affected by this effect, but it gains a +8 bonus on its saving throw. A creature without a soul is affected as if by a breathstealing whistle, as are creatures further than 60 feet but within 300 feet. Creatures further than 300 feet but within 1 mile are affected as if by a bloodchilling whistle.  

**Skills** A horned shepherd gains a +8 racial bonus on Listen, Search, Spot, and Survival checks.  
* A horned shepherd gains a +8 circumstance bonus on Hide checks in shadowy or darkened areas.  

**SHEPHERD'S CROOK**  
A horned shepherd’s crook functions as a _+7 quarterstaff_. Due to its shape, a crook can be used to make trip attacks; if the horned shepherd would be tripped while making an attempt, it may drop the crook to avoid being tripped. The shepherd can use its crook to use _soul bind_ as a spell-like ability (caster level equals the shepherd's HD) as a move action, trapping the soul within the staff. The staff cannot be destroyed while the shepherd lives, but splinters instantly upon his death, freeing any trapped souls. A shepherd’s staff can hold up to eight souls.  

A horned shepherd can _reincarnate_ bound souls, even against their will, as a full-round action (Will DC 32 negates, using the modifier they had in life). If a creature is reincarnated this way, it returns to life permanently charmed with the shepherd. This is a supernatural effect, and cannot be dispelled. Only a _wish_ or _miracle_ can undo the charm effect, and a separate spell is needed to restore the victim to his original form. The save DC is Charisma-based.  

Due to its unusual design, any creature other than a horned shepherd requires the apporpriate Exotic Weapon Proficiency to wield a shepherd's crook without suffering nonproficiency penalties.  

Since only those with the most potential are chosen to become horned shepherds, members of this racial class are assumed to have the elite array. The horned shepherd presented here had these ability scores as a horned hunter, before racial bonuses: Str 12, Dex 13, Con 8, Int 10, Wis 15, Cha 14\. It used its ability score increase from attaining its 24th Hit Die to increase its Wisdom.  

A horned shepherd’s natural weapons are considered epic weapons for the purpose of overcoming damage reduction. Its horns are +7 magic weapons, but lose their magic if it loses them.  

**STRATEGY AND TACTICS**  
Horned shepherds tend to avoid combat in favor of more important pursuits, but will enter a fight if they think it is the quickest way to be rid of an obstacle. When they have a few moments to prepare, horned shepherds usually cast enhancement spells on itself and its allies. They rely on incorporeality to get such a chance even if they are surprised by fleeing and then returning after they are prepared. Once the shepherd feels ready, it will enter combat incorporeally to test the capabilities of its foes with a heartstopping whistle. If the battle lasts long enough for the shepherd to be seriously wounded, it will use its druid spells to heal itself and its allies, preferably in hiding.  

Horned shepherds usually work with cú sídhe, and are often encountered with a number of these allies. They sometimes work alone, and very rarely they congregate in groups of six.  

**SAMPLE ENCOUNTER**  
Horned shepherds are usually busy with important matters, and it is often possible for PCs to talk their way out of conflict with one.  
_EL 23:_ A lone horned shepherd comes to collect the soul of a great druid who has just died; the druid's family wants to raise him instead of letting him pass on, and ask the party to get rid of the shepherd.  
_EL 24:_ A horned shepherd with three sluagh sídhe is chasing down the souls of a flock of legendary birds which all died suddenly in Annwn. If the party gets in the way even inadvertantly, they are likely to be testy and dangerous. If the party is helpful, the horned shepherd asks the party to find out what caused the flock to die.  

**ECOLOGY**  
Horned shepherds are much like the rest of their race, except that they are focused on their duty of protecting the cycle of souls. They still hunt when they get the opportunity. They congregate much more rarely than common horned hunters, normally only once every seven years. Even then, only six in a given world will ever meet at once, leaving the seventh to remain vigilant in the world while they are occupied.  
**Environment:** Horned shepherds go anywhere and everywhere in the Tree of Life to tend to their duties, including underwater. They like to make their homes at the edges of forests in Annwn, near portals to both Ladinion and the Mortal Coil.  
**Typical Physical Characteristics:** A horned shepherd looks just like any other horned hunter, except that it always carries its special staff.  
**Alignment:** Horned hunters pay little attention to alignment, but they tend to be lawful due to their meticulous and methodical guardianship of the Great Cycle.  

**HORNED SHEPHERD LORE**  
Characters with ranks in Knowledge (nature) can learn more about horned shepherds. When a character makes a successful skill check, the following lore is revealed, including the information from lower DCs.  
Code:  
Knowledge (nature)  
DC Results  
28 This creature is a horned hunter. It is said to be as good as any mortal ranger at any hunting task, even replicating many ranger class features.  
33 This is a horned shepherd, a specially trained horned hunter. It is renowned for its magical whistles, which can freeze enemies in their tracks or even kill those who hear.  
38 Horned shepherds are strongly associated with spirits. It is said they can even become intangible like a spirit.  
43 A horned shepherd's soul is shielded from magical effects. Reveals immaculate soul immunities.  

**SOCIETY**  
While horned hunters prefer to spend time hunting for pleasure, they also hold themselves to be subject to the solemn duty of protecting the natural cycle of reincarnation. To fulfill this duty, horned hunters of particular reverence are given the task of overseeing either the collection of dead souls or the distribution of new souls. Once these special horned hunters have completed their training, they become known as horned shepherds.  

Horned shepherds extend their mission of soul-management to their cú sídhe followers, and cú sídhe are usually thrilled at the prospect of assisting in such an important part of the Great Cycle. A given horned shepherd will specialize in either Sowing or Harvesting souls. Sowers are maintained by horned shepherds of the Seelie Court, and Harvesters are members of the Unseelie Court. It is said that exactly seven horned shepherds tend to each Mortal Coil (the ratio of Sowers to Harvesters depends upon the state of the world), and that should all seven come together in a hunt, it would mean the final end for that world.  

**SAMPLE LAIR**  
Not sure about lairs yet.  

**TYPICAL TREASURE**  
Horned shepherds accumulate treasure as is normal for a creature of its Challenge Rating, normally possessing the equivalent of about 106,000 gp. A shepherd rarely uses this treasure, preferring to hide it away and cherish these items as trophies of successful hunts. Particularly common are valuable hides and body parts, as well as magic armor and weapons.  

**HORNED SHEPHERDS WITH CLASS LEVELS**  
The horned shepherd's favored class is druid. A horned shepherd with ranger levels adds 3/4 its racial Hit Dice to its ranger levels to determine its class features. A horned shepherd's spellcasting counts as both druid and ranger spellcasting, so a shepherd with levels of ranger and/or druid does not have a separate selection of spells for each class, but instead increases its druid caster level by half its ranger levels and all its druid levels. Horned shepherds are among the very few fey which are known to become clerics from time to time. Horned shepherd clerics worship the Great Cycle and gain spells from the Air, Fey, Life, and Repose domains.  

**ADVANCED HORNED SHEPHERDS**  
Horned shepherds can advance by Hit Dice through age or experience, exactly like other horned hunters.  

A horned shepherd continues to gain all the benefits of the ranger class, as a ranger of 3/4 its Hit Dice, as it increases in racial Hit Dice. This includes epic bonus feats but not spellcasting. Instead, its druid caster level is equal to 3/4 its racial Hit Dice.  

**HORNED SHEPHERDS IN MIDLORR**  
The seven horned shepherds of Midlorr: no info yet.  


* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *