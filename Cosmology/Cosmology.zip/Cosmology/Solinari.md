# Solinari, The might hand, God's Eye
_The Mighty Hand, God’s Eye, Beacon, the Ivory Disk_  
**Intermediate Deity**  
**Symbol** white or silver circle or sphere; the white moon  
**Home Plane** the Mortal Coil (the moon Solinari)  
**Alignment** lawful good  
**Aliases** Solin, White-Eye (Goodlund, Balifor)  
**Superior** none (formerly Paladine); the High God  
**Allies** Lunitari, Nuitari  
**Foes** none  
**Servants** Wizards of the White Robes  
**Servitor Creatures**  
**Manifestations**  
**Signs of Favor**  
**Worshippers** good wizards and sorcerers  
**Cleric Alignments** none (does not grant divine spells)  
**Speciality Priests** Arcane Devotees  
**Holy Days** High Sanctions of Solinari, the Night of the Eye  
**Portfolio** good magic, arcane knowledge, abjuration, divination  
**Domains** Good, Knowledge, Magic, Protection, Purification  
**Favored Weapon** _Staff of Solinari_ (_+1 spell-storing quarterstaff_)  

Solinari is the hand of white magic, the patron deity of all the White Robe Wizards of High Sorcery. Solinari’s primary ambition is to spread magic throughout the world, and to bring more worthy mages to the Order of the White Robes. He works closely with his cousins Lunitari and Nuitari to protect and foster magic on Krynn.  

Unlike the other gods, Solinari does not have a clerical order dedicated to his worship. Instead, he serves as the patron deity for the White Robe Wizards of High Sorcery. Solinari’s followers are taught that magic is a gift to be shared with the world, used for the benefit of all. Mages of the White Robes are frequently found on expeditions in the company of clerics of Mishakal and Paladine. White Robe wizards seek out lost libraries and magical items in an effort to increase their knowledge and to expand the use of magic in the world. They come to the aid of others when their magic or expertise may be needed.  

Solinari’s followers do not observe holy days, but are particularly aware of the phases of the silver moon that bears Solinari’s name and is the symbol of his care for his followers. The moon Solinari reaches its point of High Sanction once every 36 days, causing the power of his followers to increase during this phase of the lunar cycle. The Night of the Eye—a rare event when all three of the moons are in alignment—is the height of magical power on Krynn and is a sacred day for all mages, as their power is at its strongest.  

Solinari is the son of Mishakal and Paladine, the younger brother of the twin deities, Kir-Jolith and Habbakuk. Solinari’s followers are opposed to the goals pursued by the followers of Nuitari, but both sides will cooperate to ensure the continued existence and expansion of magic in the world.  

**S**OLINARI (CR 57)  
Male Wizard 25/White Robe 30/Archmage 5  
LG Medium Outsider (Extraplanar, Good, Human)  
**Init** 33; **Senses** 15 miles, 10 locations; Clearsight, Listen +96, See Magic, Spot +96; portfolio sense  
**Aura** divine aura (DC 44); **Languages** all (including non-verbal languages); Words of Creation  
________________________________________________________________________________  
________________  

**AC** 73, touch 43, flat-footed 64 (+9 deflection, +9 Dex, +15 divine, +30 natural)  
**hp** 900 (60d4 + 660); divine shield 150, **DR** 35/epic and silver  
**Immune** ability damage*, ability drain*, _antimagic_, banishment*, charms, compulsions, death effects*, disease*, disintegration*, energy drain*, fire, imprisonment*, morale effects, paralysis*, patterns, phantasms, poison*, rebuking*, sleep*, sonic, stunning*, transmutation*, turning*  
* Bypassed with successful rank check  
**Resist** electricity 35, +1 vs. abjurations, +5 vs. divinations, +8 resistance vs. spells; **SR** 77  
**Fort** +51 **Ref** +49 **Will** +70  
________________________________________________________________________________  
________________  

**Speed** 60 ft. (12 squares)  
**Melee** _Staff of Solinari_ +49/+44 melee (1d6 + 10) or  
**Melee** spell +49/+44 touch  
**Ranged** _arcane fire_ +54/+49 ranged touch (15d10 + 10/spell level; 1,000 ft.) or  
**Ranged** spell +54/+49 touch  
**Base Atk** +30; **Grp** +49  
**Special Actions** alter reality, domain powers, metamagic effect, mastery of counterspelling  
**Combat Gear** _Staff of Solinari_  
________________________________________________________________________________  
________________  

**Arcane Spells** (CL 61st, 62nd for good, white; prohibited schools black, red)  
23rd (6/day; DC 57; white magic DC 65)  
22nd (6/day; DC 56/64)  
21st (6/day; DC 55/63)  
20th (6/day; DC 54/62)  
19th (7/day; DC 53/61)  
18th (7/day; DC 52/60)  
17th (7/day; DC 51/59)  
16th (7/day; DC 50/58)  
15th (8/day; DC 49/57)  
14th (8/day; DC 48/56)  
13th (7/day; DC 47/55)  
12th (8/day; DC 46/54)  
11th (7/day; DC 45/53)  
10th (8/day; DC 44/52)  
9th (9/day; DC 43/51)  
8th (11/day; DC 42/50)  
7th (9/day; DC 41/49)  
6th (11/day; DC 40/48)  
5th (12/day; DC 39/47)  
4th (13/day; DC 38/46)  
3rd (13/day; DC 37/45)  
2nd (13/day; DC 36/44)  
1st (14/day; DC 35/43)  
0 (14/day; DC 34/42)  
**Epic Spells per Day** 6 (DC 44; white magic DC 52)  
**Spell-like Abilities** (CL 75th)  
Always active—_antimagic field_, _foresight_, _holy aura_ (DC 43), _mind blank_, _protection from spells_, _true seeing_  
At will—_aid_, _blade barrier_, _castigate_ (DC 39), _clairaudience/clairvoyance_, _dance of the unicorn_, _deific vengeance_ (DC 37), _detect secret doors_, _detect thoughts_ (DC 37), _discern location_ (DC 43), _dispel evil_, _dispel magic_, _divination_, _find the path_, _fires of purity_ (DC 41), _greater teleport_, _greater visage of the deity_, _holy word_ (DC 42), _holy smite_ (DC 39), _imbue with spell ability_, _legend lore_, _mage’s disjunction_ (DC 44), _magic aura_, _magic circle against evil_, _nimbus of light_ (DC 36), _planeshift_, _prismatic sphere_ (DC 44), _protection from energy_, _protection from evil_, _recitation_, _repulsion_ (DC 42), _righteous wrath of the faithful_, _sanctuary_ (DC 36), _shield other_, _spell immunity_, _spell resistance_, _spell turning_, _summon monster IX_ (good creatures only), _sunburst_ (DC 43)  
________________________________________________________________________________  
________________  

**Divine Rank** 15  
**Abilities** Str 19, Dex 29, Con 32, Int 54, Wis 46, Cha 29  
**SQ** arcane focus (white magic), arcane research +15, familiar, immortality, mastery of counterspelling, mastery of elements, mastery of shaping, metamagic effect 27/day, moon magic, true mastery of counterspelling, true mastery of elements, true mastery of shaping, spell power +3, tower resources  
**Feats** Augment Spell, Consecrate Spell, Cooperative Spell, Craft Contingent Spell, Craft Magic Arms and Armor, Craft Rod, Craft Staff, Craft Wondrous Item, Energize Spell, Energy Abjuration, Flash Casting, Fortify Spell, Greater Spell Focus (white magic), Heighten Spell, Improved Initiative, Insightful Divination, Purify Spell, Quicken Spell, Radiant Spell, Scribe Scroll, Skill Focus (spellcraft), Spell Focus (all), Spell Mastery (all), Spell Penetration, Spellcasting Prodigy (white robe), Words of Creation  
**Epic Feats** Craft Epic Contingent Spell, Craft Epic Arms and Armor, Craft Epic Rod, Craft Epic Staff, Craft Epic Wondrous Item, Enhance Spell, Epic Skill Focus (spellcraft), Epic Spell Focus (white magic), Epic Spellcasting, Focused Penetration (white magic), Multispell x4, Scribe Epic Scroll  
**Salient Divine Abilities** Arcane Mastery, Automatic Metamagic (quicken spell), Clearsight, Craft Artifact, Divine Archmage (15th level), Divine Shield, Divine Spell Focus (white magic), Divine Spellcasting, Divine White Robe, Know Secrets, Magic of Defense, Magic of Radiance, Magic of Resistance, Magic of Sustenance, Magic of Truth, See Magic, Spontaneous Arcane Spells, White Magic  
**Skills** Concentration 109, Craft (alchemy) 120, Craft (bookbinding) 88, Craft (calligraphy) 88, Decipher Script 88, Diplomacy 75, Forgery 88, Gather Information 75, Heal 98, Intimidate 75, Knowledge (arcana) 135, Knowledge (geography) 120, Knowledge (history) 120, Knowledge (nature) 120, Knowledge (nobility and royalty) 120, Knowledge (the planes) 120, Knowledge (psionics) 120, Knowledge (religion) 120, Listen 116, Profession (apothecary) 84, Profession (herbalist) 84, Profession (librarian) 84, Search 120, Sense Motive 116, Spot 116, Spellcraft 148, Use Magic Device 107  
**Possessions** _Staff of Solinari, white robe of Solinari_  
**Spellbook** all arcane spells of allowed schools, all divine spells of abjuration and divination schools; Arcane Mastery  
**Epic Spells Known** most spells up to DC 148; abjuration and divination spells can make full use of the _heal_ and _life_ seeds  
________________________________________________________________________________  
________________  

**Alter Reality** Solinari can use _wish_ with regard to his portfolio. This ability costs no experience points, and requires a standard action to implement. In effect, Solinari can duplicate practically any spell effect, so long as the effect fits within his sphere of influence. When he attempts to alter reality in opposition to another deity’s altering, he must succeed at an opposed rank check. Solinari can also use alter reality to cast any _cure_ spell at will as a standard action. He can apply metamagic feats to the spells if desired, but doing so requires him to forego using alter reality for 1 round for each level the feat would normally add to the equivalent spell.  

As a free action, Solinari can assume any size from Fine to Colossal. He also can change the size of up to 100 pounds of objects he touches. His familiar can change size with him if Solinari touches it, but its weight counts against this weight limit. This ability allows Solinari to assume any proportions from the size of a grain of sand up to as much as 1,600 feet tall. A radical change in size can have great impact on his combat ability. His Strength, Armor Class, attack bonus, and damage dealt with weapons changes according to the size he assumes. Solinari’s Strength score can never be reduced to less than 1 through this ability. Also note that use of this divine ability does not affect all of Solinari’s characteristics.  

**Domain Powers** Solinari uses scrolls, wands, and other devices with spell completion or spell trigger activation as a 68th-level wizard, and casts abjuration, divination, and good spells at +1 caster level. In addition, fifteen times per day he can grant someone he touches a +7 resistance bonus on her next saving throw. Activating this ability is a standard action.  

**Moon Magic** Solinari and his cousins have invested sizable portions of their power into the moons that bear their names, in order to grant magic to their followers. Because of this, their arcane power fluctuates slightly based on the phases of the moons. When Solinari is at High Sanction, the mighty hand casts spells at +2 caster level and with saving throw DCs against his spells increased by +2\. When it is at Low Sanction, Solinari casts spells at –2 caster level and with saving throw DCs against their spells decreased by –2\. During the waxing and waning periods around the quarter moon, he casts spells at his normal caster level and DC.  

The alignment of two or all three moons has an even greater effect on the power of the gods of magic, as their arcane energies interact and synergize. When Solinari and another moon are in conjunction, Solinari and his respective cousin both cast spells at +2 caster level and with saving throw DCs for their spells increased by +2\. When all three moons come into alignment, the three cousins all cast spells at +3 caster levels and with saving throw DCs for their spells increased by +3\. These bonuses stack with any bonus or penalty in place for the phase of the moons. Every 504 days (exactly 1 1/2 years), a time known as the Night of the Eye, all three moons come into conjunction at High Sanction, granting +6 bonuses to all three deities. This is the height of arcane magic on Krynn.  
________________________________________________________________________________  
________________  

Solinari always get a result of 20 on any check, provided he needs to make a check at all. Calculate success, failure, or other effects accordingly.  

**Automatic Actions** Concentration, Craft (bookbinding), Craft (calligraphy), Knowledge (arcana), Knowledge (history), Knowledge (nature), Knowledge (nobility and royalty), Knowledge (the planes), Knowledge (religion), Listen, Sense Motive, Spot, Spellcraft; 25 DC; 10 swift actions/round (5 spells).  

**Create Magic Items** good or neutral items; 200,000 gp max; half creation cost.  
________________________________________________________________________________  
________________  

**Divine White Robe (Di)** Solinari can cast one additional abjuration spell and one additional divination spell per level. He reduces the cost for enhancing his white magic spells with metamagic by –3 spell levels (minimum +0). In addition, his white magic spells are so intense that they are capable of damaging creatures normally unharmed by or resistant to their effects. Solinari’s white magic spells completely ignore any resistance to their effects a creature possesses, bypassing this resistance and affecting the target as if it did not possess any resistance at all. The creature is still entitled to whatever other defenses the spell allows (such as saving throws and spell resistance).  

Creature normally immune to the spell effects can be affected by Solinari’s white magic as well. If a white magic spell normally allows a save for half or partial effects, the creature is unaffected on a successful save and only suffers half or partial effects on a failed save. Creatures with physiological immunities to white magic (such as a mindless creature’s immunity to mind-affecting effects) are aware that Solinari’s spells are more powerful than normal, but they remain unaffected by the attack. Creatures with a special vulnerability to white magic suffer twice the spell’s normal effects (if applicable).  

**Magic of Defense (Di)** All of Solinari’s abjuration spells are enlarged, extended, and empowered, as if by the metamagic feats, but do not use a higher-level slot.  

**Magic of Radiance (Di)** All of Solinari’s spells that deal hit point damage are imbued with radiant energy. Half of the damage dealt by his spells come from this radiant energy, and is therefore not subject to being reduced by protection from energy or similar magic. The remainder of the damage dealt is normal for the spell. Against undead, a spell modified in this way deals half again as much damage as normal (double the radiant energy damage). As a side effect, radiant spells give off as much illumination as a _daylight_ spell of 60th caster level, and this light lingers in the area for one round after the end of the spell’s duration (or one round for an instantaneous spell).  

Any spell affected by this ability can also be enhanced with the Radiant Spell metamagic feat, regardless of its descriptor. Also, any spell affected by this ability activates Solinari’s Flash Casting feat.  

**Magic of Resistance (Di)** Solinari adds 15 to the maximum caster level of all _dispel_ spells he casts. In addition, he gains Epic Counterspell as a bonus feat and can use his spell-like abilities as counterspells in addition to his normal spells.  

**Magic of Sustenance (Di)** Solinari automatically succeeds on all Concentration checks made to cast spells despite damage, distraction, motion, entanglement or grappling, or weather conditions. This includes all Concentration checks for spellcasting, concentrating on an active spell, or directing a spell, except for casting defensively when threatened by an opponent.  

**Magic of Truth (Di)** All of Solinari’s divination spells are enlarged, extended, and widened, as if by the metamagic feats, but do not use a higher-level slot.  

**White Magic (Di)** As the original and greatest White Robed wizard, Solinari considers the two schools of white magic to be one. He may select white magic as the focus for any school-based ability or feat, and apply the benefits separately to both abjuration and divination. In addition, he can cast all abjuration and divination spells from any spell list as arcane wizard spells.  

He has specialized in white magic as a wizard and gains one additional abjuration spell and one additional divination spell per level. He has Greater Spell Focus, Epic Spell Focus, Divine Spell Focus, and Focused Penetration (white magic), and applies the caster level increases to both abjuration and divination spells. In specializing in white magic, Solinari has sacrificed all four schools of the other Orders of High Sorcery as restricted schools (enchantment, illusion, necromancy, and transmutation).  
_________________  
If you're not cheating, you're not trying hard enough.  

Go tell the Spartans, passerby,  
That here, by Spartan law, we lie  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *