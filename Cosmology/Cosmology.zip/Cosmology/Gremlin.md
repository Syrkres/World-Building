# Gremlin (CR 3)  
_What appears to be a shriveled, ugly goblin stands before you. It wears only rags._  
Often N Tiny Fey  
**Init** +5; **Senses** low-light vision, scent; Listen +5, Spot +0  
**Languages** Common, Draconic, Gnome, Goblin, Sylvan  
**AC** 18, touch 17, flat-footed 13 (+5 Dex, +1 natural, +2 size)  
**hp** 7 (2 HD); **DR** 5/cold iron  
**SR** 19 (16 + CR)  
**Fort** +0, **Ref** +8, **Will** +3  
**Speed** 20 ft. (4 squares); Run  
**Melee** adamantine dagger +1 (1d2-3); or  
**Ranged** adamantine dart +9 (1d2-3)  
**Space** 2-1/2 ft.; **Reach** 0 ft.  
**Base Atk** +1; **Grp** -10  
**Atk Options** ruinous strike  
**Spell-like Abilities** (CL 5th):  
At will—_ghost sound, understand object_  
3/day—_bestow curse_ (+0 melee touch, DC 14), _shatter_ (DC 12)  
1/day—_dimension door, fabricate_  
**Abilities** Str 4, Dex 20, Con 10, Int 16, Wis 11, Cha 11  
**SQ** greater invisibility  
**Feats** Run  
**Skills** Concentration +4, Craft (any two) +9, Disable Device +12, Hide +14, Knowledge (architecture and engineering) +12, Listen +5, Move Silently +10, Open Lock +10, Search +8 (+10 to find secret doors and compartments), Sleight of Hand +10, Tumble +6  
**Advancement** 3-6 HD (Tiny); **Favored Class** rogue; **LA** ?  
**Possessions** adamantine dagger, adamantine dart (x13)  

**Greater Invisibility (Su)** A gremlin remains invisible even when it attacks. This ability is constant, but the gremlin may suppress or resume it as a free action.  

**Ruinous Strike (Ex)** A gremlin can find and exploit weaknesses in enemies’ armor, weapons, and other carried objects much like a rogue can exploit weaknesses with a sneak attack. Any time that a gremlin catches an enemy flat-footed (or otherwise denied his Dexterity bonus to Armor Class), it may make a ruinous strike against an object carried or held by that enemy. This attack does not provoke an attack of opportunity. A ruinous strike deals an additional 1d6 points of damage to the object and all of the damage from the attack ignores hardness.  

A gremlin may also make a ruinous strike against an unattended object or against a construct. Objects and constructs without Dexterity scores need not be flanked or denied their Dexterity bonus to armor class. A ruinous strike’s damage ignores damage reduction as well as hardness.  

**Skills** Gremlins receive a +4 racial bonus on Craft, Disable Device, and Knowledge (architecture and engineering).  

**STRATEGY AND TACTICS**  
Gremlins far prefer to use trickery over engaging in direct combat. They are almost never encountered alone; usually, they travel in gangs of 3 to 8 members.  

**SAMPLE ENCOUNTER**  
A gang of three gremlins decides to make off with the party's higher-quality gear and destroy it during the night.  
_EL 6:_ Three gremlins are involved.  
_EL 8:_ Five gremlins are involved.  

**ECOLOGY**  
Gremlins live in huge colonies in Faerie where they train to destroy technology, vex mortals, and craft items for other fey. As fey, their metabolism is not limited to the physical - they can gain energy from the fun of harming mortals or building things, and need little rest or food while carrying on like this. They only make short excursions to the Mortal Coil, though, preferring to spend the majority of their time with other gremlins.  

Some rumors claim that gremlins are the ancestors of both the gnomes and the goblins. Both races find the idea to be disgusting and preposterous, but no gremlin has ever denied the possibility. A similar (and contested) rumor claims that gremlin-dragon interbreeding produced the kobolds.  
**Environment:** Gremlins can be found in most any environment, but on the Mortal Coil they prefer to stick near major metropolitan areas and military bases (where they can do the most damage) and near select, vibrant natural places where they can be helpful to animals and fey who use tools. They may also be found in the region of the Mortal Coil which coexists with their colony in Faerie. They are rarely found in small mortal communities or in sparce natural settings.  
**Typical Physical Characteristics:** A gremlin appears much like a shriveled, ugly goblin with dark skin and big, pointed ears. Gremlins stand anywhere from 1 to 1-1/2 feet tall and weigh between 5 and 7 pounds.  
**Alignment:** Gremlin culture encourages versatility and discovery, which causes chaotic tendencies, but also encourages community, which causes lawful tendencies. As a result, gremlins may be any alignment, but are most often neutral.  

**GREMLIN LORE**  
Characters with ranks in Knowledge (nature) can learn more about gremlins. When a character makes a successful skill check, the following lore is revealed, including the information from lower DCs.  
Code:  
Knowledge (nature)  
DC Results  
13 This is a fey creature known as a gremlin. It is able to move about invisibly, and even remain invisible when it attacks.  
18 Gremlins can easily destroy most any object, particularly if they can catch the object's owner off-guard.  
23 Gremlins are associated with bad luck, and can bestow curses.  

**SOCIETY**  
Gremlins are unusual among the fey in their interests - they like to learn about mortal inventions. They use this learning to help them destroy those devices. They are also known to spread bad luck in general. Few mortals ever learn the reason for the severity of this animosity - gremlins' hatred of technology is typical of fey, but no others are as fervent in fighting it as gremlins are.  

Though it is little-known to non-fey, gremlins are creative as well as destructive. They are regarded highly as smiths and craftsmen among the fey. They also champion the use of tools in nature (such as birds who use cactus needles to spear worms and apes who catch ants with sticks) and may help animals who depend on such tools; this affinity makes them particularly appalled by the extremes to which mortals have taken tools and leads them to sabotage all technological advances among mortals that they deem to be excessive (generally, anything which extends beyond the technological level of the middle ages).  

Superficially, gremlin culture seems almost military in its training and community life, but in truth individuality is in no way suppressed. In fact, gremlins distinguish themselves by showing creativity, adaptability, and individuality.  

**TYPICAL TREASURE**  
Gremlins have standard treasure for their Challenge Rating. They are prone to be found with technological devices that they have not yet destroyed.  

**GREMLINS AS CHARACTERS**  
Gremlins are apt to adventure in order to search out great technological achievements to destroy. They also like to rob mortals of items which could be useful to themselves. Gremlin clerics (an extreme rarity) choose from the Craft, Destruction, Fey, and Trickery domains.  

**ADVANCED GREMLINS**  
A gremlin’s ruinous strike damage increases by 1 die with every odd Hit Die added.  

**GREMLINS IN MIDLORR**  
Gremlins have been spotted around Worm's Wood.  

Disclaimer: After reviewing preliminary fluff, Kain has said that he wouldn't violently oppose gremlins as fey, but that he'd prefer them as goblinoids instead (something they've never actually been in D&D before). Of course, there's no reason we couldn't change the creature type, but I simply think they're more interesting as fey. Also, the seemingly obsessive and unprovoked destruction of technology is a very fey thing (and the creature type makes it very easy to explain). I should note that their roots in legend (little monsters that broke airplanes in WWI) was rather sparse, and so I have expanded the flavor for use as fey.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *