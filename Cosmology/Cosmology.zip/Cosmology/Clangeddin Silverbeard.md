# Clangeddin Silverbeard, Father of Battle
_Father of Battle, Lord of the Twin Axes, the Giantkiller, the Goblinbane, the Wyrmslayer, the Rock of Battle_  
**Intermediate Dwarven Deity**  
**Symbol:** Two crossed battleaxes  
**Home Plane:** Mount Clangeddin, Arcadia  
**Alignment:** Lawful good  
**Portfolio:** Battle, war, valor, bravery, honor in battle  
**Worshipers:** Barbarians, dwarven defenders, dwarves, fighters, monks, paladins, soldiers, strategists, tacticians, warriors  
**Cleric Alignments:** LG, LN, NG  
**Domains:** Dwarf, Good, Law, Strength, War  
**Favored Weapon:** "Giantbane" (battleaxe)  

**CLANGEDDIN SILVERBEARD**  
Fighter 30, Paladin 20, Dwarven Defender 10  
Medium Outsider (Good, Lawful)  
**Divine Rank:** 13  
**Hit Dice:** 30d10+570 (Ftr) plus 20d10+320 (Pal) plus 10d12+160 (Def) (1670 hp)  
**Initiative:** +15 (+7 Dex, +8 Superior Initiative)  
**Speed:** 60 ft. (12 squares)  
**Armor Class:** 83 (+7 Dex, +13 armor, +13 divine, +28 natural, +10 deflection, +2 shield), touch 40, flat-footed 76  
**Base Att/Grapple:** +40/+69  
**Attack:** _Giantbane_ +97 melee touch or ranged touch (1d8+44/19-20/x3) or _Goblincleaver_ +97 melee touch or ranged touch (1d8+44/19-20/x2); or spell +69 melee touch or +60 ranged touch.  
**Full Attack:** _Giantbane_ +95/+90/+85/+80 melee touch or ranged touch (1d8+44/19-20/x3) and _Goblincleaver_ +95/+90/+85/+80 melee touch or ranged touch (1d8+36/19-20/x3); or by spell.  
**Space/Reach:** 5 ft./5 ft.  
**Special Attacks:** Salient divine abilities, smite evil 5/day, spell-like abilities, turn undead 13/day.  
**Special Qualities:** Aura of courage, aura of good, defensive stance 5/day, _detect evil_, divine aura (1300 ft., DC 33), divine grace, divine health, divine immunities, DR 30/epic, evil and adamantine (6/--), dwarf traits, fire resistance 18, godly realm (10 miles Outer Plane, 1300 ft. Material Plane), _greater teleport_ at will, lay on hands, _plane shift_ at will, remote communication 13 miles, special mount, _remove disease_ 5/week, SR 75, trap sense +2, uncanny dodge, understand, speak, and read all languages and speak directly to all beings within 13 miles.  
**Saves:** Fort +73, Ref +60, Will +60  
**Abilities:** Str 43, Dex 24, Con 42, Int 19, Wis 25, Cha 30  
**Skills:** Appraise +27 (+31 armor, +29 metal, +29 stone, +31 weapons), Bluff +43, Concentration +49, Climb +55, Craft (armorsmithing) +50, Craft (weaponsmithing) +50, Diplomacy +45, Disguise +23 (+25 acting), Handle Animal +28, Heal +40, Intimidate +58, Jump +55, Listen +42, Ride +27, Sense Motive +50, Spot +40, Swim +41, Tumble +25.  
*Always recieves a 20 on checks.  
**Feats:** Combat Expertise, Combat Reflexes, Cleave, Dodge, Endurance, Great Cleave, Great Fortitude, Great Smiting, Greater Two-Weapon Fighting, Greater Weapon Focus (battleaxe), Greater Weapon Specialization (battleaxe), Improved Combat Expertise, Improved Initiative, Improved Toughness, Improved Two-Weapon Defense, Improved Two-Weapon Fighting, Improved Sunder, Improved Unarmed Strike, Mobility, Power Attack, Power Critical (battleaxe), Spring Attack, Two-Weapon Defense, Two-Weapon Fighting, Weapon Focus (battleaxe), Whirlwind Attack.  
**Epic Feats:** Bulwark of Defense, Devastating Critical (battleaxe), Dire Charge, Epic Reflexes, Epic Weapon Focus (battleaxe), Epic Weapon Specialization (battleaxe), Epic Toughness, Epic Will, Overwhelming Critical (battleaxe), Perfect Two-Weapon Fighting, Spellcasting Harrier, Superior Initiative, Two-Weapon Rend.  
**Environment:** Mount Clangeddin  
**Organization:** Unique  
**Challenge Rating:** 54  
**Treasure:** _Giantbane_, _Goblincleaver_, _+10 chain mail_  
**Alignment:** Lawful good  
**Advancement:** --  
**Level Adjustment:** --  

- **Dwarf Traits:** +1 bonus on attack rolls against orcs and goblinoids; +2 bonus on Will saves against spells and spell-like abilities; +2 bonus on Fortitude saves against all poisons; +4 dodge bonus against giants; darkvision; stability (+4 bonus to resist being bull rushed or tripped when standing firmly on the ground); stonecunning (+2 racial bonus on checks to notice unusual stonework; can make a check for unusual stonework as though actively searching when within 10 feet and can use the Search skill to find stonework traps as a rogue can; intuit depth); +2 racial bonus on Appraise checks and Craft or Profession checks related to stone or metal.  
- **Defensive Stance:** When he needs to, Clangeddin can become a stalwart bastion of defense. In this defensive stance, Clangeddin gains phenomenal strength and durability, but cannot move from the spot he is defending at more than 5 ft. per round. Clangeddin may maintain this stance for up to 22 rounds, or end it voluntarily prior to this limit. He may only activate this ability during his action.  
- The following changes are in effect as long as Clangeddin mantains a defensive stance: HP 1850; AC 89 (touch 46, flat-footed 82); Atk _Giantbane_ +97/+92/+87/+82 melee touch or ranged touch (1d8+46/19-20/x3) and _Goblincleaver_ +97/+92/+87/+82 melee touch or ranged touch (1d8+37/19-20/x3); SV Fort +80, Ref +64, Will +64; Str 47, Con 48; Concentration +52, Climb +57, Jump +57, Swim +43.  
- **Divine Immunities:** Ability damage, ability drain, acid, cold, death effects, disease, disintegration, electricity, energy drain, mind-affecting effects, paralysis, poison, _sleep_, stunning, transmutation, _imprisonment_, _banishment_.  
- **Divine Power:** Clangeddin is a living embodiment of power, and ancient divine magics flow through his veins. As such, mortal items are of virtually no use to him, being so much weaker than her own innate powers. Clangeddin gains no benefit from a deflection, enhancement, resistance, insight, sacred or profane bonus that is less than +13\. Note that this only applies to bonuses that affect Clangeddin himself; weaponry and armor is unaffected by this.  
- **Salient Divine Abilities:** Annihilating Strike (DC 39), Banestrike (giants), Banestrike (goblinoids), Battle Hymn*, Battlesense, Divine Armor Mastery, Divine Battle Mastery, Divine Blessing (strength), Divine Shield, Divine Weapon Mastery, Divine Weapon Focus (battleaxe), Divine Weapon Specialization (battleaxe), Extra Domain (strength), Increased Damage Reduction, Irresistable Blows (battleaxe), Warrior's Touch*.  
*Unique abilities, described below.  
- **Alter Reality:** Clangeddin can use the _wish_ spell with regard to his portfolio, save for the replication of other spells. This ability costs Clangeddin no XP, and requires a standard action to implement. As a free action 13/day, for one round at a time, Clangeddin may add +10 to all damage rolls, or +10 to his effective caster level.  
- **Domain Powers:** Cast good spells at +1 caster level; cast law spells at +1 caster level; feat of strength 1/day (gain a +20 enhancement bonus to Strength for one round).  
- **Spell-Like Abilities:** Clangeddin uses these abilities as a 73th-level caster, except for good spells and law spells, which he uses as a 74th-level caster. The save DCs are 43 + spell level. _aid, bear's endurance, Bigby's clenched fist, Bigby's crushing hand, Bigby's grasping hand, blade barrier, bull's strength, calm emotions, dictum, dispel chaos, dispel evil, divine power, elemental swarm_ (as earth spell only)_, enlarge person, fabricate, flame strike, greater magic weapon, gylph of warding, hold monster, holy aura, holy smite, holy word, magic circle against chaos, magic circle against evil, magic vestment, magic weapon, order's wrath, power word blind, power word kill, power word stun, protection from chaos, protection from evil, protection from spells, righteous might, spell immunity, stone tell, shield of law, spirtual weapon, stoneskin, summon monster IX_ (as good or law spell only).  
- **Spells:** As a 10th level paladin (20th with alter reality).  
- **Paladin Spells Per Day (levels 1-4):** (5/5/5/4; base DC = 17 + spell level).  
- ***Battle Hymn (unique salient divine ability):** Clangeddin is fond of singing while fighting, with the intent of both unnerving his opponents and uplifting his allies. Whenever Clangeddin sings, which he may do as a free action at will if he is engaged in a battle, his opponents suffer a -2 morale penalty on all attack rolls, damage rolls, saving throws, and skill checks, while his allies recieve a +4 morale bonus on all attack rolls, damage rolls, saving throws, and skill checks. The targets must be able to clearly hear Clangeddin's voice. This ability has a range of 1300 ft., and lasts for 13 rounds even after Clangeddin stops singing.  
- ***Warrior's Touch (unique salient divine ability):** Clangeddin's touch can, at will, mend any metal weapon or armor as though it had never been broken, even restoring missing pieces. Any weapon the Father of Battle touches gains a +13 sacred bonus to attack rolls for 13 rounds thereafter, a power Clangeddin typically uses to aid dwarves he is fighting alongside. (Reflected in the scores for his own weapons, above).  
- **Possessions:** Clangeddin wields _Giantbane_, a _+7 mithral giant dread battleaxe_, and _Goblincleaver_, a _+7 mithral goblinoid dread battleaxe_. (_Caster Levels:_ 60th; _Weight:_ 6 lb. each). Instead of or in addition to using them in melee combat, Clangeddin can throw his axes out to 300 ft. (no range increment) without penalty, and treats this as a melee attack rather than a ranged one. After striking, each axe magically returns to his hands. He wears rusted steel _+8 chain mail_ that has seen many a battle. (_Caster Level:_ 60th; _Weight:_ 40 lb.)  

**Other Divine Powers**  
- As an intermediate deity, Clangeddin automatically recieves a die roll of 20 on any check. He treats a 1 on an attack roll or saving throw normally and not as an automatic failure. He is immortal.  
- **Senses:** Clangeddin can see (using normal vision or darkvision), hear, touch, and smell at a distance of 13 miles. As a standard action, he can perceive anything within 13 miles of his worshippers, holy sites, objects, or any location where one of his titles or name was spoken in the last hour. He can extend his senses to up to ten locations at once. He can block the sensing power of deities of his rank or lower at up to two remote locations at once for 13 hours.  
- **Portfolio Sense:** Clangeddin can sense any act of dwarven courage, valor or honor the instant it happens and retains the sensation for thirteen weeks after the event occurs. He is likewise aware of any battle that involves dwarves.  
- **Automatic Actions:** Clangeddin can use any Strength-based skill as a free action if the DC for the task is 25 or lower. He may not use any skills that require movement. He can perform up to 10 such free actions each round.  
- **Create Magic Items:** Clangeddin can any magical weapons or armor as long as the item’s market price does not exceed 200,000 gp.  

**Avatars**  
- The typical avatar of Clangeddin appears as a tall, middle-aged, burly dwarf, fierce and indomitable in his battered, bloodstained, and rusty chain mail. Bald and silver-bearded, he is always alert, his eyes darting here and there, his gaze as sharp as that of a hunting hawk, and his smile ever-present.  
- He appears at the site of major, epic battles, and by fighting and singing inspires dwarven warriors to victory. He is swift to humble and humilitate any who overcome by cowardly or deceitful means, and never backs down from a fight.  

* * *

A great creation of <a href="" http:="" community.dicefreaks.com="" ""="" target="" _blank""="">DiceFreaks</a> and copied here for reference.

* * *