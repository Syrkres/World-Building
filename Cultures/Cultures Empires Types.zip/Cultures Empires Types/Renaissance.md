---
fileType: Culture
cultureType: Renaissance
---
# Renaissance
Art, literature, and technology all flower in this setting. A wealthy merchant class has risen to contest the landed nobility's hold on power. In many places, the increasing strength of towns and cities leads to a new age of mercantile city-states.