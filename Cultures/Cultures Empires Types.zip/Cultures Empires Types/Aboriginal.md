---
fileType: Culture
cultureType: Aboriginal
---
# Aboriginal
Tribes or dans of hunter-gatherers inhabit the land, with few fixed settlements and very little agriculture. Technology is typically Stone Age or equivalent. Some campaigns with a Native American flavor may fall into this category. Aboriginal peoples are likely to have highly developed oral traditions and value systems.