---
fileType: Culture
cultureType: Egyptian
---
# Egyptian
The campaign has an ancient Egyptian flavor to it. This category may also include the Sumerian or Babylonian empires, if you prefer.