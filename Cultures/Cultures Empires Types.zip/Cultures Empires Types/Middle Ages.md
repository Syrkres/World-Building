---
fileType: Culture
cultureType: Middle Ages
---
# Middle Ages
It is an age of chivalry and castles. Power lies in the hands of the landed nobility and the various churches or temples of the realm. The classic AD&D setting, this presents a fantastic kingdom of knights and ladies.