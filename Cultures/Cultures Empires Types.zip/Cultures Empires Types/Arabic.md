---
fileType: Culture
cultureType: Aboriginal
---
# Arabic
The campaign has a fantastic Arabian feel, modelled after A Thousand and One Nights or the stories of Sinbad. The AL-QADIM game setting is an excellent resource for campaigns
of this type.