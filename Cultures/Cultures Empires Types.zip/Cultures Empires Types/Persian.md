---
fileType: Culture
cultureType: Persian
---
# Persian
Resembling the Persian Empire, satraps wield power in scattered city-states. Persia's culture and flavor fell somewhere between Arabic, Indian, and Central Asian culture.