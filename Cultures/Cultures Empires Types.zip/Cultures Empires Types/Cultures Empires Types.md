# Cultures and Empire Types


```dataview
table without ID file.link AS Cultures
from ""
where fileType="Culture"
```