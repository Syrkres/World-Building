---
fileType: Culture
cultureType: African
---
# African
The realm is modelled after one of the tribelands or kingdoms of pre-colonial Africa. The ivory kingdoms of the Middle Ages, ancient Ethiopia or Zimbabwe, or the more recent Zulu empire represent good examples.