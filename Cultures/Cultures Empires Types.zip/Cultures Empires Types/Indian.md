---
fileType: Culture
cultureType: Indian
---
# Indian
The campaign is modeled after medieval India. India's social structure was feudal in nature, with an amazing number of independent rajahs, moguls, and princes each governing over one of hundreds of small kingdoms