---
fileType: Culture
cultureType: Savage
---
# Savage
For our purposes, the chief difference between a savage culture and a barbaric culture is the degree of organization. Generally, savage peoples do not recognize any king or over-chieftain, while barbaric peoples often build tribal federations or crude kingdoms. Savages probably have a  lower technology than barbaric peoples, but may equal or exceed them in social development.