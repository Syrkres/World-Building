---
fileType: Culture
cultureType: Asian
---
# Asian
The kingdom is modelled after the horsemen and conquerors of the Central Asian steppes, including the Mongols, Tartars, Uighurs, and other such groups. They are likely to be nomadic herdsmen with a strong central organization; by the late Middle Ages, some of these conquerors settled down in the lands their forefathers had conquered. The FORGOTTEN REALMS campaign expansion The Horde proves useful here.