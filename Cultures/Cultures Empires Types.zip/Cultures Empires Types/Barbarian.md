---
fileType: Culture
cultureType: Barbarian
---
# Barbarian
The realm is a tribal group or kingdom of people considered barbarians by their neighbors. These can be historical barbarians such as the Celts, Picts, or ancient Germans, or you may prefer to mold your kingdom after fantastic barbarians such as Robert E. Howard's Cimmeria. The Complete Barbarian's Handbook may be a good resource for your campaign.