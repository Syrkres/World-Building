---
fileType: Culture
cultureType: Viking
---
# Viking
While the Vikings of northern Europe could probably be considered barbarians, the modern player's strong recognition of their culture merits their inclusion.