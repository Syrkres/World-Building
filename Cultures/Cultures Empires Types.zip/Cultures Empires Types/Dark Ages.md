---
fileType: Culture
cultureType: Dark Ages
---
# Dark Ages
In this setting, the landed nobility and the feudal system have not fully developed. Instead, kings are little more than chieftains surrounded by warbands and bodyguards. Parts of Eastern or Northern Europe remained at this level hundreds of years after western and southern Europe had developed. Charlemagne's Paladins depicts Europe in the Dark Ages.