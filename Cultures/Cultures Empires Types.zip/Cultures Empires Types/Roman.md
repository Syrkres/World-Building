---
fileType: Culture
cultureType: Roman
---
# Roman
The major kingdom of the campaign is patterned after the Roman Empire. Naturally, the historical accessory The Glory of Rome is the best resource for setting an AD&D game in this realm.