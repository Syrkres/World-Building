---
fileType: Culture
cultureType: Oriental
---
# Oriental
The kingdom resembles Feudal Japan or China, with samurai and warlords ruling through a feudal land-holding system. Oriental Adventures and Kara-Tur may be useful references for building an oriental campaign.