genName {race}

__
```
^genName  ?([a-zA-Z]*) ?(m*|f*|male*|female*)$
```
__
```js
if ($2 = "m") {
    $2 = "male";
} else if ($2 = "f") {
    $2 = "female";
}
const {Names} = customJS;
var result = Names.generateFullName($1, $2);

return result;
```
__
genName {race name: text} {gender: m|f|male|female} - Randomly generates a name based on race.
  - __Parameters:__
    - __race__ (Optional) The race you are searching for (human/halfling/half-elf/etc). 
    - __gender__ (Optional) The gender you are looking for (m|f|male|female). Race must be passed in to pass in gender.
  - __Examples:__
    - `;;genName halfling female::`
    - `;;genName halfling::`
    - `;;genName::`
 

