<%*
const {Names} = customJS;
let nameListString = Names.listNameArray()
const nameArray = nameListString.split(",");
let name = await  tp.system.suggester(nameArray, nameArray)
nameSrc = name
_%>
<%*
let qcGender = await  tp.system.suggester(["male", "female"], ["male", "female"])
gender = qcGender
_%>
<%*
generatedName = Names.generateFullName(nameSrc, qcGender)
_%>
<% generatedName %>