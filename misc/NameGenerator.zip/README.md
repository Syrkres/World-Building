# [[Name generator]] 
This archive includes three files (plus Readme.md - this file)
- Names.js  - a customJS script to generate names randomly.
- Generate Name.md - Template to prompt for race and gender.
- genName.sfile.md - Inline Script to generate a name randomly.
