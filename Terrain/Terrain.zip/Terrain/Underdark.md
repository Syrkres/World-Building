---
fileType: Terrain
terrainType: Underdark
---
# Underdark
The Underdark is a subterranean realm of enormous size inhabited by many different types of creatures such as drow, mind flayers, and aboleths. It extends far beyond the dungeons created by surface dwellers, and consists of caverns, tunnels and large complexes.