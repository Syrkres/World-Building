---
fileType: Terrain
terrainType: Forest
---
# Forest
The term forest is that of an area of land largely or completely covered by trees, usually in a temperate or colder climate.
