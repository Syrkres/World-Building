---
fileType: Terrain
terrainType: Jungle
---
# Jungle
A jungle is a dense, tangled, near-impenetrable tropical rainforest, the sort that is found in pulpy adventure stories (in which case it is full of aggressive jaguars, poisonous snakes, stinging insects, hostile natives, and a thousand other hazards).
