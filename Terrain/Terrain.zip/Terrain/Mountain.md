---
fileType: Terrain
terrainType: Mountain
---
# Mountain
A large natural elevation of the earth's surface rising abruptly from the surrounding level; a large steep hill.