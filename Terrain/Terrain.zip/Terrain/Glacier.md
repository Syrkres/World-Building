---
fileType: Terrain
terrainType: Glacier
---
# Glacier
A slowly moving mass or river of ice formed by the accumulation and compaction of snow on mountains.