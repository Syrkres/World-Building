---
fileType: Terrain
terrainType: Arctic
---
# Arctic
Arctic lands are extreme fluctuations between summer and winter temperatures; permanent snow and ice in the high country and grasses, sedges, and low shrubs in the lowlands; and permanently frozen ground (permafrost), the surface layer of which is subject to summer thawing.