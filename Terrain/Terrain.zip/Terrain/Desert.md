---
fileType: Terrain
terrainType: Desert
---
# Desert
A desert is a type of terrain with little to no vegetation. This is normally because it also has very little water, although other factors, such as poisoning with salt and similar substances, or just extreme exhaustion of the soil may also be a factor.
