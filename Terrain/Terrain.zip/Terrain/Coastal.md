---
fileType: Terrain
terrainType: Coastal
---
# Coastal
The area where land meets the ocean, or as a line that forms the boundary between the land and the ocean or a lake.