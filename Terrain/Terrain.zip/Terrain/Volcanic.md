---
fileType: Terrain
terrainType: Volcanic
---
# Volcanic
Volcanic plains are vast, smooth plains formed by extensive volcanic flooding from fissure vents or volcanic centers, showing a variety of small-scale volcanic features.