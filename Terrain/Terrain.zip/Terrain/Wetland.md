---
fileType: Terrain
terrainType: Wetland
---
# Wetland
A wetland or swamp is a region that mixes solid land with shallow bodies of water. The water is very slow moving, and covered by abundant vegetation which in some cases may be hard to distinguish from solid land merely by looking at it, thus making movement very difficult without (flat) boats. 