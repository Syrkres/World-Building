---
fileType: Terrain
terrainType: Grasslands
---
# Grasslands
A large open area of country covered with grass, especially one used for grazing.