---
fileType: Terrain
terrainType: Valley
---
# Valley
A valley is a stretched-out groove in the land, usually formed by streams or rivers. A valley often begins with high ground on three sides, and usually has a course of running water through it.